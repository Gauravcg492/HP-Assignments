package x10.array;


/**
 * Implementation of a 1-D DistArray that distributes its data elements
 * over the places in its PlaceGroup in a 1-D blocked fashion.
 */
@x10.runtime.impl.java.X10Generated
public class DistArray_Block_1<$T> extends x10.array.DistArray<$T> implements x10.core.fun.Fun_0_1, x10.serialization.X10JavaSerializable
{
    public static final x10.rtt.RuntimeType<DistArray_Block_1> $RTT = 
        x10.rtt.NamedType.<DistArray_Block_1> make("x10.array.DistArray_Block_1",
                                                   DistArray_Block_1.class,
                                                   1,
                                                   new x10.rtt.Type[] {
                                                       x10.rtt.ParameterizedType.make(x10.core.fun.Fun_0_1.$RTT, x10.rtt.Types.LONG, x10.rtt.UnresolvedType.PARAM(0)),
                                                       x10.rtt.ParameterizedType.make(x10.array.DistArray.$RTT, x10.rtt.UnresolvedType.PARAM(0))
                                                   });
    
    public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
    
    public x10.rtt.Type<?> $getParam(int i) { if (i == 0) return $T; return null; }
    
    private Object writeReplace() throws java.io.ObjectStreamException {
        return new x10.serialization.SerializationProxy(this);
    }
    
    public static <$T> x10.serialization.X10JavaSerializable $_deserialize_body(x10.array.DistArray_Block_1<$T> $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
        x10.array.DistArray.$_deserialize_body($_obj, $deserializer);
        $_obj.$T = (x10.rtt.Type) $deserializer.readObject();
        $_obj.globalIndices = $deserializer.readObject();
        
        /* fields with @TransientInitExpr annotations */
        $_obj.localIndices = $_obj.reloadLocalIndices();
        $_obj.maxLocalIndex = $_obj.reloadMaxLocalIndex$O();
        $_obj.minLocalIndex = $_obj.reloadMinLocalIndex$O();
        
        return $_obj;
    }
    
    public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
        x10.array.DistArray_Block_1 $_obj = new x10.array.DistArray_Block_1((java.lang.System[]) null, (x10.rtt.Type) null);
        $deserializer.record_reference($_obj);
        return $_deserialize_body($_obj, $deserializer);
    }
    
    public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
        super.$_serialize($serializer);
        $serializer.write(this.$T);
        $serializer.write(this.globalIndices);
        
    }
    
    // constructor just for allocation
    public DistArray_Block_1(final java.lang.System[] $dummy, final x10.rtt.Type $T) {
        super($dummy, $T);
        x10.array.DistArray_Block_1.$initParams(this, $T);
        
    }
    
    // dispatcher for method abstract public (Z1)=>U.operator()(a1:Z1){}:U
    public java.lang.Object $apply(final java.lang.Object a1, final x10.rtt.Type t1) {
        if (t1.equals(x10.rtt.Types.LONG)) { return $apply$G(x10.core.Long.$unbox(a1)); }
        if (t1.equals(x10.lang.Point.$RTT)) { return $apply$G((x10.lang.Point)a1); }
        throw new java.lang.Error("dispatch mechanism not completely implemented for contra-variant types.");
    }
    
    // bridge for method abstract public x10.array.DistArray[T].operator()=(p:x10.lang.Point{self.rank==this(:x10.array.DistArray).rank()}, v:T){}:T{self==v}
    final public $T $set__1x10$array$DistArray$$T$G(x10.lang.Point a1, $T a2) {
        return $set__1x10$array$DistArray_Block_1$$T$G(a1, a2);
    }
    
    private x10.rtt.Type $T;
    
    // initializer of type parameters
    public static void $initParams(final DistArray_Block_1 $this, final x10.rtt.Type $T) {
        $this.$T = $T;
        
    }
    // synthetic type for parameter mangling
    public static final class __2$1x10$lang$Long$3x10$array$DistArray_Block_1$$T$2 {}
    // synthetic type for parameter mangling
    public static final class __1$1x10$lang$Long$3x10$array$DistArray_Block_1$$T$2 {}
    

    
    
    //#line 25 "x10/array/DistArray_Block_1.x10"
    final public long rank$O() {
        
        //#line 25 "x10/array/DistArray_Block_1.x10"
        return 1L;
    }
    
    
    //#line 27 "x10/array/DistArray_Block_1.x10"
    public x10.array.DenseIterationSpace_1 globalIndices;
    
    //#line 30 "x10/array/DistArray_Block_1.x10"
    public transient x10.array.DenseIterationSpace_1 localIndices;
    
    
    //#line 31 "x10/array/DistArray_Block_1.x10"
    final public x10.array.DenseIterationSpace_1 reloadLocalIndices() {
        
        //#line 32 "x10/array/DistArray_Block_1.x10"
        final x10.lang.PlaceLocalHandle t$108164 = ((x10.lang.PlaceLocalHandle)(this.localHandle));
        
        //#line 32 "x10/array/DistArray_Block_1.x10"
        final x10.array.LocalState t$108165 = ((x10.lang.PlaceLocalHandle<x10.array.LocalState<$T>>)t$108164).$apply$G();
        
        //#line 32 "x10/array/DistArray_Block_1.x10"
        final x10.array.LocalState_B1 ls = x10.rtt.Types.<x10.array.LocalState_B1<$T>> cast(t$108165,x10.rtt.ParameterizedType.make(x10.array.LocalState_B1.$RTT, $T));
        
        //#line 33 "x10/array/DistArray_Block_1.x10"
        final boolean t$108167 = ((ls) != (null));
        
        //#line 33 "x10/array/DistArray_Block_1.x10"
        x10.array.DenseIterationSpace_1 t$108168 =  null;
        
        //#line 33 "x10/array/DistArray_Block_1.x10"
        if (t$108167) {
            
            //#line 33 "x10/array/DistArray_Block_1.x10"
            final x10.array.Dist_Block_1 t$108166 = ((x10.array.Dist_Block_1)(((x10.array.LocalState_B1<$T>)ls).dist));
            
            //#line 33 "x10/array/DistArray_Block_1.x10"
            t$108168 = ((x10.array.DenseIterationSpace_1)(t$108166.localIndices));
        } else {
            
            //#line 33 "x10/array/DistArray_Block_1.x10"
            final x10.array.DenseIterationSpace_1 alloc$108068 = ((x10.array.DenseIterationSpace_1)(new x10.array.DenseIterationSpace_1((java.lang.System[]) null)));
            
            //#line 33 "x10/array/DistArray_Block_1.x10"
            alloc$108068.x10$array$DenseIterationSpace_1$$init$S(((long)(0L)), ((long)(-1L)));
            
            //#line 33 "x10/array/DistArray_Block_1.x10"
            t$108168 = ((x10.array.DenseIterationSpace_1)(alloc$108068));
        }
        
        //#line 33 "x10/array/DistArray_Block_1.x10"
        return t$108168;
    }
    
    
    //#line 37 "x10/array/DistArray_Block_1.x10"
    public transient long minLocalIndex;
    
    
    //#line 38 "x10/array/DistArray_Block_1.x10"
    final public long reloadMinLocalIndex$O() {
        
        //#line 38 "x10/array/DistArray_Block_1.x10"
        final x10.array.DenseIterationSpace_1 t$108170 = ((x10.array.DenseIterationSpace_1)(this.localIndices));
        
        //#line 38 "x10/array/DistArray_Block_1.x10"
        final long t$108171 = t$108170.min$O((long)(0L));
        
        //#line 38 "x10/array/DistArray_Block_1.x10"
        return t$108171;
    }
    
    
    //#line 41 "x10/array/DistArray_Block_1.x10"
    public transient long maxLocalIndex;
    
    
    //#line 42 "x10/array/DistArray_Block_1.x10"
    final public long reloadMaxLocalIndex$O() {
        
        //#line 42 "x10/array/DistArray_Block_1.x10"
        final x10.array.DenseIterationSpace_1 t$108172 = ((x10.array.DenseIterationSpace_1)(this.localIndices));
        
        //#line 42 "x10/array/DistArray_Block_1.x10"
        final long t$108173 = t$108172.max$O((long)(0L));
        
        //#line 42 "x10/array/DistArray_Block_1.x10"
        return t$108173;
    }
    
    
    //#line 53 "x10/array/DistArray_Block_1.x10"
    /**
     * Construct a n-element block distributed DistArray
     * whose data is distributed over pg and initialized using
     * the init function.
     *
     * @param n number of elements 
     * @param pg the PlaceGroup to use to distibute the elements.
     * @param init the element initialization function
     */
    // creation method for java code (1-phase java constructor)
    public DistArray_Block_1(final x10.rtt.Type $T, final long n, final x10.lang.PlaceGroup pg, final x10.core.fun.Fun_0_1<x10.core.Long,$T> init, __2$1x10$lang$Long$3x10$array$DistArray_Block_1$$T$2 $dummy) {
        this((java.lang.System[]) null, $T);
        x10$array$DistArray_Block_1$$init$S(n, pg, init, (x10.array.DistArray_Block_1.__2$1x10$lang$Long$3x10$array$DistArray_Block_1$$T$2) null);
    }
    
    // constructor for non-virtual call
    final public x10.array.DistArray_Block_1<$T> x10$array$DistArray_Block_1$$init$S(final long n, final x10.lang.PlaceGroup pg, final x10.core.fun.Fun_0_1<x10.core.Long,$T> init, __2$1x10$lang$Long$3x10$array$DistArray_Block_1$$T$2 $dummy) {
         {
            
            //#line 54 "x10/array/DistArray_Block_1.x10"
            final x10.core.fun.Fun_0_0 t$108278 = ((x10.core.fun.Fun_0_0)(new x10.array.DistArray_Block_1.$Closure$11<$T>($T, pg, n, init, (x10.array.DistArray_Block_1.$Closure$11.__2$1x10$lang$Long$3x10$array$DistArray_Block_1$$Closure$11$$T$2) null)));
            
            //#line 225 . "x10/array/DistArray_Block_1.x10"
            final boolean t$108281 = ((n) < (((long)(0L))));
            
            //#line 225 . "x10/array/DistArray_Block_1.x10"
            if (t$108281) {
                
                //#line 225 . "x10/array/DistArray_Block_1.x10"
                x10.array.DistArray.raiseNegativeArraySizeException();
            }
            
            //#line 54 "x10/array/DistArray_Block_1.x10"
            /*super.*/x10$array$DistArray$$init$S(((x10.lang.PlaceGroup)(pg)), ((x10.core.fun.Fun_0_0)(t$108278)), n, (x10.array.DistArray.__1$1x10$array$LocalState$1x10$array$DistArray$$T$2$2) null);
            
            //#line 53 "x10/array/DistArray_Block_1.x10"
            
            
            //#line 55 "x10/array/DistArray_Block_1.x10"
            final x10.array.DenseIterationSpace_1 alloc$108069 = ((x10.array.DenseIterationSpace_1)(new x10.array.DenseIterationSpace_1((java.lang.System[]) null)));
            
            //#line 55 "x10/array/DistArray_Block_1.x10"
            final long t$108283 = ((n) - (((long)(1L))));
            
            //#line 55 "x10/array/DistArray_Block_1.x10"
            alloc$108069.x10$array$DenseIterationSpace_1$$init$S(((long)(0L)), t$108283);
            
            //#line 55 "x10/array/DistArray_Block_1.x10"
            ((x10.array.DistArray_Block_1<$T>)this).globalIndices = ((x10.array.DenseIterationSpace_1)(alloc$108069));
            
            //#line 56 "x10/array/DistArray_Block_1.x10"
            final x10.array.DenseIterationSpace_1 t$108178 = ((x10.array.DenseIterationSpace_1)(this.reloadLocalIndices()));
            
            //#line 56 "x10/array/DistArray_Block_1.x10"
            ((x10.array.DistArray_Block_1<$T>)this).localIndices = ((x10.array.DenseIterationSpace_1)(t$108178));
            
            //#line 57 "x10/array/DistArray_Block_1.x10"
            final x10.array.DistArray_Block_1 this$108126 = ((x10.array.DistArray_Block_1)(this));
            
            //#line 38 . "x10/array/DistArray_Block_1.x10"
            final x10.array.DenseIterationSpace_1 t$108179 = ((x10.array.DenseIterationSpace_1)(((x10.array.DistArray_Block_1<$T>)this$108126).localIndices));
            
            //#line 38 . "x10/array/DistArray_Block_1.x10"
            final long t$108180 = t$108179.min$O((long)(0L));
            
            //#line 57 "x10/array/DistArray_Block_1.x10"
            ((x10.array.DistArray_Block_1<$T>)this).minLocalIndex = t$108180;
            
            //#line 58 "x10/array/DistArray_Block_1.x10"
            final x10.array.DistArray_Block_1 this$108128 = ((x10.array.DistArray_Block_1)(this));
            
            //#line 42 . "x10/array/DistArray_Block_1.x10"
            final x10.array.DenseIterationSpace_1 t$108181 = ((x10.array.DenseIterationSpace_1)(((x10.array.DistArray_Block_1<$T>)this$108128).localIndices));
            
            //#line 42 . "x10/array/DistArray_Block_1.x10"
            final long t$108182 = t$108181.max$O((long)(0L));
            
            //#line 58 "x10/array/DistArray_Block_1.x10"
            ((x10.array.DistArray_Block_1<$T>)this).maxLocalIndex = t$108182;
        }
        return this;
    }
    
    
    
    //#line 70 "x10/array/DistArray_Block_1.x10"
    /**
     * Construct a n-element block distributed DistArray
     * whose data is distributed over Place.places() and 
     * initialized using the provided init closure.
     *
     * @param n number of elements
     * @param init the element initialization function
     */
    // creation method for java code (1-phase java constructor)
    public DistArray_Block_1(final x10.rtt.Type $T, final long n, final x10.core.fun.Fun_0_1<x10.core.Long,$T> init, __1$1x10$lang$Long$3x10$array$DistArray_Block_1$$T$2 $dummy) {
        this((java.lang.System[]) null, $T);
        x10$array$DistArray_Block_1$$init$S(n, init, (x10.array.DistArray_Block_1.__1$1x10$lang$Long$3x10$array$DistArray_Block_1$$T$2) null);
    }
    
    // constructor for non-virtual call
    final public x10.array.DistArray_Block_1<$T> x10$array$DistArray_Block_1$$init$S(final long n, final x10.core.fun.Fun_0_1<x10.core.Long,$T> init, __1$1x10$lang$Long$3x10$array$DistArray_Block_1$$T$2 $dummy) {
         {
            
            //#line 71 "x10/array/DistArray_Block_1.x10"
            final x10.lang.PlaceGroup t$108183 = ((x10.lang.PlaceGroup)(x10.lang.Place.places()));
            
            //#line 71 "x10/array/DistArray_Block_1.x10"
            /*this.*/x10$array$DistArray_Block_1$$init$S(((long)(n)), t$108183, ((x10.core.fun.Fun_0_1)(init)), (x10.array.DistArray_Block_1.__2$1x10$lang$Long$3x10$array$DistArray_Block_1$$T$2) null);
        }
        return this;
    }
    
    
    
    //#line 82 "x10/array/DistArray_Block_1.x10"
    /**
     * Construct a n-elmenent block distributed DistArray
     * whose data is distributed over pg and zero-initialized.
     *
     * @param n number of elements 
     * @param pg the PlaceGroup to use to distibute the elements.
     */
    // creation method for java code (1-phase java constructor)
    public DistArray_Block_1(final x10.rtt.Type $T, final long n, final x10.lang.PlaceGroup pg) {
        this((java.lang.System[]) null, $T);
        x10$array$DistArray_Block_1$$init$S(n, pg);
    }
    
    // constructor for non-virtual call
    final public x10.array.DistArray_Block_1<$T> x10$array$DistArray_Block_1$$init$S(final long n, final x10.lang.PlaceGroup pg) {
         {
            
            //#line 83 "x10/array/DistArray_Block_1.x10"
            final x10.core.fun.Fun_0_1 t$108185 = ((x10.core.fun.Fun_0_1)(new x10.array.DistArray_Block_1.$Closure$12<$T>($T)));
            
            //#line 83 "x10/array/DistArray_Block_1.x10"
            /*this.*/x10$array$DistArray_Block_1$$init$S(((long)(n)), ((x10.lang.PlaceGroup)(pg)), ((x10.core.fun.Fun_0_1)(t$108185)), (x10.array.DistArray_Block_1.__2$1x10$lang$Long$3x10$array$DistArray_Block_1$$T$2) null);
        }
        return this;
    }
    
    
    
    //#line 94 "x10/array/DistArray_Block_1.x10"
    /**
     * Construct a n-element block distributed DistArray
     * whose data is distributed over Place.places() and 
     * zero-initialized.
     *
     * @param n number of elements
     */
    // creation method for java code (1-phase java constructor)
    public DistArray_Block_1(final x10.rtt.Type $T, final long n) {
        this((java.lang.System[]) null, $T);
        x10$array$DistArray_Block_1$$init$S(n);
    }
    
    // constructor for non-virtual call
    final public x10.array.DistArray_Block_1<$T> x10$array$DistArray_Block_1$$init$S(final long n) {
         {
            
            //#line 95 "x10/array/DistArray_Block_1.x10"
            final x10.lang.PlaceGroup t$108187 = ((x10.lang.PlaceGroup)(x10.lang.Place.places()));
            
            //#line 95 "x10/array/DistArray_Block_1.x10"
            final x10.core.fun.Fun_0_1 t$108188 = ((x10.core.fun.Fun_0_1)(new x10.array.DistArray_Block_1.$Closure$13<$T>($T)));
            
            //#line 95 "x10/array/DistArray_Block_1.x10"
            /*this.*/x10$array$DistArray_Block_1$$init$S(((long)(n)), t$108187, ((x10.core.fun.Fun_0_1)(t$108188)), (x10.array.DistArray_Block_1.__2$1x10$lang$Long$3x10$array$DistArray_Block_1$$T$2) null);
        }
        return this;
    }
    
    
    
    //#line 104 "x10/array/DistArray_Block_1.x10"
    /**
     * Get an IterationSpace that represents all Points contained in
     * the global iteration space (valid indices) of the DistArray.
     * @return an IterationSpace for the DistArray
     */
    final public x10.array.DenseIterationSpace_1 globalIndices() {
        
        //#line 104 "x10/array/DistArray_Block_1.x10"
        final x10.array.DenseIterationSpace_1 t$108189 = ((x10.array.DenseIterationSpace_1)(this.globalIndices));
        
        //#line 104 "x10/array/DistArray_Block_1.x10"
        return t$108189;
    }
    
    
    //#line 112 "x10/array/DistArray_Block_1.x10"
    /**
     * Get an IterationSpace that represents all Points contained in
     * the local iteration space (valid indices) of the DistArray at the current Place.
     * @return an IterationSpace for the local portion of the DistArray
     */
    final public x10.array.DenseIterationSpace_1 localIndices() {
        
        //#line 112 "x10/array/DistArray_Block_1.x10"
        final x10.array.DenseIterationSpace_1 t$108190 = ((x10.array.DenseIterationSpace_1)(this.localIndices));
        
        //#line 112 "x10/array/DistArray_Block_1.x10"
        return t$108190;
    }
    
    
    //#line 124 "x10/array/DistArray_Block_1.x10"
    /**
     * Return the Place which contains the data for the argument
     * index or Place.INVALID_PLACE if the Point is not in the globalIndices
     * of this DistArray
     *
     * @param i the index 
     * @return the Place where i is a valid index in the DistArray; 
     *          will return Place.INVALID_PLACE if i is not contained in globalIndices
     */
    final public x10.lang.Place place(final long i) {
        
        //#line 125 "x10/array/DistArray_Block_1.x10"
        final x10.array.DenseIterationSpace_1 t$108191 = ((x10.array.DenseIterationSpace_1)(this.globalIndices));
        
        //#line 125 "x10/array/DistArray_Block_1.x10"
        final x10.lang.PlaceGroup this$108130 = ((x10.lang.PlaceGroup)(this.placeGroup));
        
        //#line 35 . "x10/lang/PlaceGroup.x10"
        final long t$108192 = this$108130.numPlaces$O();
        
        //#line 125 "x10/array/DistArray_Block_1.x10"
        final long tmp = x10.array.BlockingUtils.mapIndexToBlockPartition$O(((x10.array.IterationSpace)(t$108191)), (long)(t$108192), (long)(i));
        
        //#line 126 "x10/array/DistArray_Block_1.x10"
        final boolean t$108194 = ((long) tmp) == ((long) -1L);
        
        //#line 126 "x10/array/DistArray_Block_1.x10"
        x10.lang.Place t$108195 =  null;
        
        //#line 126 "x10/array/DistArray_Block_1.x10"
        if (t$108194) {
            
            //#line 126 "x10/array/DistArray_Block_1.x10"
            t$108195 = x10.lang.Place.get$INVALID_PLACE();
        } else {
            
            //#line 126 "x10/array/DistArray_Block_1.x10"
            final x10.lang.PlaceGroup t$108193 = ((x10.lang.PlaceGroup)(this.placeGroup));
            
            //#line 126 "x10/array/DistArray_Block_1.x10"
            t$108195 = t$108193.$apply((long)(tmp));
        }
        
        //#line 126 "x10/array/DistArray_Block_1.x10"
        return t$108195;
    }
    
    
    //#line 139 "x10/array/DistArray_Block_1.x10"
    /**
     * Return the Place which contains the data for the argument
     * Point or Place.INVALID_PLACE if the Point is not in the globalIndices
     * of this DistArray
     *
     * @param p the Point to lookup
     * @return the Place where p is a valid index in the DistArray; 
     *          will return Place.INVALID_PLACE if p is not contained in globalIndices
     */
    final public x10.lang.Place place(final x10.lang.Point p) {
        
        //#line 139 "x10/array/DistArray_Block_1.x10"
        final long t$108197 = p.$apply$O((long)(0L));
        
        //#line 139 "x10/array/DistArray_Block_1.x10"
        final x10.lang.Place t$108198 = this.place((long)(t$108197));
        
        //#line 139 "x10/array/DistArray_Block_1.x10"
        return t$108198;
    }
    
    
    //#line 149 "x10/array/DistArray_Block_1.x10"
    /**
     * Return the element of this array corresponding to the given index.
     * 
     * @param i the given index
     * @return the element of this array corresponding to the given index.
     * @see #set(T, Long)
     */
    final public $T $apply$G(final long i) {
        
        //#line 151 "x10/array/DistArray_Block_1.x10"
        final long t$108284 = this.minLocalIndex;
        
        //#line 151 "x10/array/DistArray_Block_1.x10"
        boolean t$108285 = ((i) < (((long)(t$108284))));
        
        //#line 151 "x10/array/DistArray_Block_1.x10"
        if (!(t$108285)) {
            
            //#line 151 "x10/array/DistArray_Block_1.x10"
            final long t$108286 = this.maxLocalIndex;
            
            //#line 151 "x10/array/DistArray_Block_1.x10"
            t$108285 = ((i) > (((long)(t$108286))));
        }
        
        //#line 151 "x10/array/DistArray_Block_1.x10"
        if (t$108285) {
            
            //#line 152 "x10/array/DistArray_Block_1.x10"
            boolean t$108288 = ((i) < (((long)(0L))));
            
            //#line 152 "x10/array/DistArray_Block_1.x10"
            if (!(t$108288)) {
                
                //#line 152 "x10/array/DistArray_Block_1.x10"
                final long t$108289 = this.size;
                
                //#line 152 "x10/array/DistArray_Block_1.x10"
                t$108288 = ((i) >= (((long)(t$108289))));
            }
            
            //#line 152 "x10/array/DistArray_Block_1.x10"
            if (t$108288) {
                
                //#line 152 "x10/array/DistArray_Block_1.x10"
                x10.array.DistArray.raiseBoundsError((long)(i));
            }
            
            //#line 153 "x10/array/DistArray_Block_1.x10"
            x10.array.DistArray.raisePlaceError((long)(i));
        }
        
        //#line 156 "x10/array/DistArray_Block_1.x10"
        final x10.core.Rail r$108132 = ((x10.core.Rail)(this.raw));
        
        //#line 156 "x10/array/DistArray_Block_1.x10"
        final long t$108206 = this.minLocalIndex;
        
        //#line 156 "x10/array/DistArray_Block_1.x10"
        final long i$108133 = ((i) - (((long)(t$108206))));
        
        //#line 38 . "x10/lang/Unsafe.x10"
        final $T t$108207 = (($T)(((x10.core.Rail<$T>)r$108132).$apply$G((long)(i$108133))));
        
        //#line 156 "x10/array/DistArray_Block_1.x10"
        return t$108207;
    }
    
    
    //#line 167 "x10/array/DistArray_Block_1.x10"
    /**
     * Return the element of this array corresponding to the given Point.
     * 
     * @param p the given Point
     * @return the element of this array corresponding to the given Point.
     * @see #set(T, Point)
     */
    final public $T $apply$G(final x10.lang.Point p) {
        
        //#line 167 "x10/array/DistArray_Block_1.x10"
        final x10.array.DistArray_Block_1 this$108136 = ((x10.array.DistArray_Block_1)(this));
        
        //#line 167 "x10/array/DistArray_Block_1.x10"
        final long i$108135 = p.$apply$O((long)(0L));
        
        //#line 151 . "x10/array/DistArray_Block_1.x10"
        final long t$108291 = ((x10.array.DistArray_Block_1<$T>)this$108136).minLocalIndex;
        
        //#line 151 . "x10/array/DistArray_Block_1.x10"
        boolean t$108292 = ((i$108135) < (((long)(t$108291))));
        
        //#line 151 . "x10/array/DistArray_Block_1.x10"
        if (!(t$108292)) {
            
            //#line 151 . "x10/array/DistArray_Block_1.x10"
            final long t$108293 = ((x10.array.DistArray_Block_1<$T>)this$108136).maxLocalIndex;
            
            //#line 151 . "x10/array/DistArray_Block_1.x10"
            t$108292 = ((i$108135) > (((long)(t$108293))));
        }
        
        //#line 151 . "x10/array/DistArray_Block_1.x10"
        if (t$108292) {
            
            //#line 152 . "x10/array/DistArray_Block_1.x10"
            boolean t$108295 = ((i$108135) < (((long)(0L))));
            
            //#line 152 . "x10/array/DistArray_Block_1.x10"
            if (!(t$108295)) {
                
                //#line 152 . "x10/array/DistArray_Block_1.x10"
                final long t$108296 = ((x10.array.DistArray<$T>)this$108136).size;
                
                //#line 152 . "x10/array/DistArray_Block_1.x10"
                t$108295 = ((i$108135) >= (((long)(t$108296))));
            }
            
            //#line 152 . "x10/array/DistArray_Block_1.x10"
            if (t$108295) {
                
                //#line 152 . "x10/array/DistArray_Block_1.x10"
                x10.array.DistArray.raiseBoundsError((long)(i$108135));
            }
            
            //#line 153 . "x10/array/DistArray_Block_1.x10"
            x10.array.DistArray.raisePlaceError((long)(i$108135));
        }
        
        //#line 156 . "x10/array/DistArray_Block_1.x10"
        final x10.core.Rail r$108138 = ((x10.core.Rail)(((x10.array.DistArray<$T>)this$108136).raw));
        
        //#line 156 . "x10/array/DistArray_Block_1.x10"
        final long t$108215 = ((x10.array.DistArray_Block_1<$T>)this$108136).minLocalIndex;
        
        //#line 156 . "x10/array/DistArray_Block_1.x10"
        final long i$108139 = ((i$108135) - (((long)(t$108215))));
        
        //#line 38 .. "x10/lang/Unsafe.x10"
        final $T t$108216 = (($T)(((x10.core.Rail<$T>)r$108138).$apply$G((long)(i$108139))));
        
        //#line 167 "x10/array/DistArray_Block_1.x10"
        return t$108216;
    }
    
    
    //#line 179 "x10/array/DistArray_Block_1.x10"
    /**
     * Set the element of this array corresponding to the given index to the given value.
     * Return the new value of the element.
     * 
     * @param v the given value
     * @param i the given index 
     * @return the new value of the element of this array corresponding to the given index.
     * @see #operator(Long)
     */
    final public $T $set__1x10$array$DistArray_Block_1$$T$G(final long i, final $T v) {
        
        //#line 181 "x10/array/DistArray_Block_1.x10"
        final long t$108298 = this.minLocalIndex;
        
        //#line 181 "x10/array/DistArray_Block_1.x10"
        boolean t$108299 = ((i) < (((long)(t$108298))));
        
        //#line 181 "x10/array/DistArray_Block_1.x10"
        if (!(t$108299)) {
            
            //#line 181 "x10/array/DistArray_Block_1.x10"
            final long t$108300 = this.maxLocalIndex;
            
            //#line 181 "x10/array/DistArray_Block_1.x10"
            t$108299 = ((i) > (((long)(t$108300))));
        }
        
        //#line 181 "x10/array/DistArray_Block_1.x10"
        if (t$108299) {
            
            //#line 182 "x10/array/DistArray_Block_1.x10"
            boolean t$108302 = ((i) < (((long)(0L))));
            
            //#line 182 "x10/array/DistArray_Block_1.x10"
            if (!(t$108302)) {
                
                //#line 182 "x10/array/DistArray_Block_1.x10"
                final long t$108303 = this.size;
                
                //#line 182 "x10/array/DistArray_Block_1.x10"
                t$108302 = ((i) >= (((long)(t$108303))));
            }
            
            //#line 182 "x10/array/DistArray_Block_1.x10"
            if (t$108302) {
                
                //#line 182 "x10/array/DistArray_Block_1.x10"
                x10.array.DistArray.raiseBoundsError((long)(i));
            }
            
            //#line 183 "x10/array/DistArray_Block_1.x10"
            x10.array.DistArray.raisePlaceError((long)(i));
        }
        
        //#line 186 "x10/array/DistArray_Block_1.x10"
        final x10.core.Rail r$108141 = ((x10.core.Rail)(this.raw));
        
        //#line 186 "x10/array/DistArray_Block_1.x10"
        final long t$108224 = this.minLocalIndex;
        
        //#line 186 "x10/array/DistArray_Block_1.x10"
        final long i$108142 = ((i) - (((long)(t$108224))));
        
        //#line 42 . "x10/lang/Unsafe.x10"
        ((x10.core.Rail<$T>)r$108141).$set__1x10$lang$Rail$$T$G((long)(i$108142), (($T)(v)));
        
        //#line 186 "x10/array/DistArray_Block_1.x10"
        return (($T)
                 v);
    }
    
    
    //#line 199 "x10/array/DistArray_Block_1.x10"
    /**
     * Set the element of this array corresponding to the given Point to the given value.
     * Return the new value of the element.
     * 
     * @param v the given value
     * @param p the given Point
     * @return the new value of the element of this array corresponding to the given Point.
     * @see #operator(Long)
     */
    final public $T $set__1x10$array$DistArray_Block_1$$T$G(final x10.lang.Point p, final $T v) {
        
        //#line 199 "x10/array/DistArray_Block_1.x10"
        final x10.array.DistArray_Block_1 this$108147 = ((x10.array.DistArray_Block_1)(this));
        
        //#line 199 "x10/array/DistArray_Block_1.x10"
        final long i$108145 = p.$apply$O((long)(0L));
        
        //#line 181 . "x10/array/DistArray_Block_1.x10"
        final long t$108305 = ((x10.array.DistArray_Block_1<$T>)this$108147).minLocalIndex;
        
        //#line 181 . "x10/array/DistArray_Block_1.x10"
        boolean t$108306 = ((i$108145) < (((long)(t$108305))));
        
        //#line 181 . "x10/array/DistArray_Block_1.x10"
        if (!(t$108306)) {
            
            //#line 181 . "x10/array/DistArray_Block_1.x10"
            final long t$108307 = ((x10.array.DistArray_Block_1<$T>)this$108147).maxLocalIndex;
            
            //#line 181 . "x10/array/DistArray_Block_1.x10"
            t$108306 = ((i$108145) > (((long)(t$108307))));
        }
        
        //#line 181 . "x10/array/DistArray_Block_1.x10"
        if (t$108306) {
            
            //#line 182 . "x10/array/DistArray_Block_1.x10"
            boolean t$108309 = ((i$108145) < (((long)(0L))));
            
            //#line 182 . "x10/array/DistArray_Block_1.x10"
            if (!(t$108309)) {
                
                //#line 182 . "x10/array/DistArray_Block_1.x10"
                final long t$108310 = ((x10.array.DistArray<$T>)this$108147).size;
                
                //#line 182 . "x10/array/DistArray_Block_1.x10"
                t$108309 = ((i$108145) >= (((long)(t$108310))));
            }
            
            //#line 182 . "x10/array/DistArray_Block_1.x10"
            if (t$108309) {
                
                //#line 182 . "x10/array/DistArray_Block_1.x10"
                x10.array.DistArray.raiseBoundsError((long)(i$108145));
            }
            
            //#line 183 . "x10/array/DistArray_Block_1.x10"
            x10.array.DistArray.raisePlaceError((long)(i$108145));
        }
        
        //#line 186 . "x10/array/DistArray_Block_1.x10"
        final x10.core.Rail r$108149 = ((x10.core.Rail)(((x10.array.DistArray<$T>)this$108147).raw));
        
        //#line 186 . "x10/array/DistArray_Block_1.x10"
        final long t$108232 = ((x10.array.DistArray_Block_1<$T>)this$108147).minLocalIndex;
        
        //#line 186 . "x10/array/DistArray_Block_1.x10"
        final long i$108150 = ((i$108145) - (((long)(t$108232))));
        
        //#line 42 .. "x10/lang/Unsafe.x10"
        ((x10.core.Rail<$T>)r$108149).$set__1x10$lang$Rail$$T$G((long)(i$108150), (($T)(v)));
        
        //#line 199 "x10/array/DistArray_Block_1.x10"
        return (($T)
                 v);
    }
    
    
    //#line 208 "x10/array/DistArray_Block_1.x10"
    /**
     * Returns the specified rectangular patch of this Array as a Rail.
     * 
     * @param space the DenseIterationSpace representing the portion of this array to copy
     * @throws ArrayIndexOutOfBoundsException if the specified region is not
     *        contained in this array
     */
    public x10.core.Rail getPatch(final x10.array.IterationSpace space) {
        
        //#line 209 "x10/array/DistArray_Block_1.x10"
        final x10.array.DenseIterationSpace_1 r = ((x10.array.DenseIterationSpace_1)(x10.rtt.Types.<x10.array.DenseIterationSpace_1> cast(space,x10.array.DenseIterationSpace_1.$RTT)));
        
        //#line 211 "x10/array/DistArray_Block_1.x10"
        final x10.array.DenseIterationSpace_1 t$108233 = ((x10.array.DenseIterationSpace_1)(this.localIndices));
        
        //#line 211 "x10/array/DistArray_Block_1.x10"
        final long t$108234 = t$108233.min;
        
        //#line 211 "x10/array/DistArray_Block_1.x10"
        final long t$108235 = r.min;
        
        //#line 211 "x10/array/DistArray_Block_1.x10"
        boolean t$108239 = ((t$108234) <= (((long)(t$108235))));
        
        //#line 211 "x10/array/DistArray_Block_1.x10"
        if (t$108239) {
            
            //#line 211 "x10/array/DistArray_Block_1.x10"
            final long t$108237 = r.max;
            
            //#line 211 "x10/array/DistArray_Block_1.x10"
            final x10.array.DenseIterationSpace_1 t$108236 = ((x10.array.DenseIterationSpace_1)(this.localIndices));
            
            //#line 211 "x10/array/DistArray_Block_1.x10"
            final long t$108238 = t$108236.max;
            
            //#line 211 "x10/array/DistArray_Block_1.x10"
            t$108239 = ((t$108237) <= (((long)(t$108238))));
        }
        
        //#line 211 "x10/array/DistArray_Block_1.x10"
        final boolean t$108246 = !(t$108239);
        
        //#line 210 "x10/array/DistArray_Block_1.x10"
        if (t$108246) {
            
            //#line 212 "x10/array/DistArray_Block_1.x10"
            final java.lang.String t$108241 = (("patch to copy: ") + (r));
            
            //#line 212 "x10/array/DistArray_Block_1.x10"
            final java.lang.String t$108242 = ((t$108241) + (" not contained in local indices: "));
            
            //#line 212 "x10/array/DistArray_Block_1.x10"
            final x10.array.DenseIterationSpace_1 t$108243 = ((x10.array.DenseIterationSpace_1)(this.localIndices));
            
            //#line 212 "x10/array/DistArray_Block_1.x10"
            final java.lang.String t$108244 = ((t$108242) + (t$108243));
            
            //#line 212 "x10/array/DistArray_Block_1.x10"
            final java.lang.ArrayIndexOutOfBoundsException t$108245 = ((java.lang.ArrayIndexOutOfBoundsException)(new java.lang.ArrayIndexOutOfBoundsException(t$108244)));
            
            //#line 212 "x10/array/DistArray_Block_1.x10"
            throw t$108245;
        }
        
        //#line 215 "x10/array/DistArray_Block_1.x10"
        final x10.array.DenseIterationSpace_1 t$108247 = ((x10.array.DenseIterationSpace_1)(this.localIndices));
        
        //#line 215 "x10/array/DistArray_Block_1.x10"
        final long min = t$108247.min$O((long)(0L));
        
        //#line 49 . "x10/array/DenseIterationSpace_1.x10"
        final long t$108248 = r.max;
        
        //#line 49 . "x10/array/DenseIterationSpace_1.x10"
        final long t$108249 = r.min;
        
        //#line 49 . "x10/array/DenseIterationSpace_1.x10"
        final long t$108250 = ((t$108248) - (((long)(t$108249))));
        
        //#line 49 . "x10/array/DenseIterationSpace_1.x10"
        final long t$108251 = ((t$108250) + (((long)(1L))));
        
        //#line 216 "x10/array/DistArray_Block_1.x10"
        final x10.core.Rail patch = ((x10.core.Rail)(x10.core.Rail.<$T>makeUnsafe($T, ((long)(t$108251)), false)));
        
        //#line 217 "x10/array/DistArray_Block_1.x10"
        long patchIndex = 0L;
        
        //#line 218 "x10/array/DistArray_Block_1.x10"
        final long i$108073min$108325 = r.min$O((long)(0L));
        
        //#line 218 "x10/array/DistArray_Block_1.x10"
        final long i$108073max$108326 = r.max$O((long)(0L));
        
        //#line 218 "x10/array/DistArray_Block_1.x10"
        long i$108321 = i$108073min$108325;
        
        //#line 218 "x10/array/DistArray_Block_1.x10"
        for (;
             true;
             ) {
            
            //#line 218 "x10/array/DistArray_Block_1.x10"
            final boolean t$108323 = ((i$108321) <= (((long)(i$108073max$108326))));
            
            //#line 218 "x10/array/DistArray_Block_1.x10"
            if (!(t$108323)) {
                
                //#line 218 "x10/array/DistArray_Block_1.x10"
                break;
            }
            
            //#line 219 "x10/array/DistArray_Block_1.x10"
            final long pre$108312 = patchIndex;
            
            //#line 219 "x10/array/DistArray_Block_1.x10"
            final long t$108314 = ((patchIndex) + (((long)(1L))));
            
            //#line 219 "x10/array/DistArray_Block_1.x10"
            patchIndex = t$108314;
            
            //#line 219 "x10/array/DistArray_Block_1.x10"
            final x10.core.Rail t$108315 = ((x10.core.Rail)(this.raw));
            
            //#line 219 "x10/array/DistArray_Block_1.x10"
            final long t$108316 = ((i$108321) - (((long)(min))));
            
            //#line 219 "x10/array/DistArray_Block_1.x10"
            final $T t$108317 = (($T)(((x10.core.Rail<$T>)t$108315).$apply$G((long)(t$108316))));
            
            //#line 219 "x10/array/DistArray_Block_1.x10"
            ((x10.core.Rail<$T>)patch).$set__1x10$lang$Rail$$T$G((long)(pre$108312), (($T)(t$108317)));
            
            //#line 218 "x10/array/DistArray_Block_1.x10"
            final long t$108320 = ((i$108321) + (((long)(1L))));
            
            //#line 218 "x10/array/DistArray_Block_1.x10"
            i$108321 = t$108320;
        }
        
        //#line 221 "x10/array/DistArray_Block_1.x10"
        return patch;
    }
    
    
    //#line 224 "x10/array/DistArray_Block_1.x10"
    private static long validateSize$O(final long n) {
        
        //#line 225 "x10/array/DistArray_Block_1.x10"
        final boolean t$108262 = ((n) < (((long)(0L))));
        
        //#line 225 "x10/array/DistArray_Block_1.x10"
        if (t$108262) {
            
            //#line 225 "x10/array/DistArray_Block_1.x10"
            x10.array.DistArray.raiseNegativeArraySizeException();
        }
        
        //#line 226 "x10/array/DistArray_Block_1.x10"
        return n;
    }
    
    public static long validateSize$P$O(final long n) {
        return x10.array.DistArray_Block_1.validateSize$O((long)(n));
    }
    
    
    //#line 23 "x10/array/DistArray_Block_1.x10"
    final public x10.array.DistArray_Block_1 x10$array$DistArray_Block_1$$this$x10$array$DistArray_Block_1() {
        
        //#line 23 "x10/array/DistArray_Block_1.x10"
        return x10.array.DistArray_Block_1.this;
    }
    
    
    //#line 23 "x10/array/DistArray_Block_1.x10"
    final public void __fieldInitializers_x10_array_DistArray_Block_1() {
        
    }
    
    @x10.runtime.impl.java.X10Generated
    final public static class $Closure$11<$T> extends x10.core.Ref implements x10.core.fun.Fun_0_0, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<$Closure$11> $RTT = 
            x10.rtt.StaticFunType.<$Closure$11> make($Closure$11.class,
                                                     1,
                                                     new x10.rtt.Type[] {
                                                         x10.rtt.ParameterizedType.make(x10.core.fun.Fun_0_0.$RTT, x10.rtt.ParameterizedType.make(x10.array.LocalState_B1.$RTT, x10.rtt.UnresolvedType.PARAM(0)))
                                                     });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { if (i == 0) return $T; return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static <$T> x10.serialization.X10JavaSerializable $_deserialize_body(x10.array.DistArray_Block_1.$Closure$11<$T> $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            $_obj.$T = (x10.rtt.Type) $deserializer.readObject();
            $_obj.init = $deserializer.readObject();
            $_obj.n = $deserializer.readLong();
            $_obj.pg = $deserializer.readObject();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.array.DistArray_Block_1.$Closure$11 $_obj = new x10.array.DistArray_Block_1.$Closure$11((java.lang.System[]) null, (x10.rtt.Type) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            $serializer.write(this.$T);
            $serializer.write(this.init);
            $serializer.write(this.n);
            $serializer.write(this.pg);
            
        }
        
        // constructor just for allocation
        public $Closure$11(final java.lang.System[] $dummy, final x10.rtt.Type $T) {
            x10.array.DistArray_Block_1.$Closure$11.$initParams(this, $T);
            
        }
        
        // bridge for method abstract public ()=>U.operator()():U
        public x10.array.LocalState_B1 $apply$G() {
            return $apply();
        }
        
        private x10.rtt.Type $T;
        
        // initializer of type parameters
        public static void $initParams(final $Closure$11 $this, final x10.rtt.Type $T) {
            $this.$T = $T;
            
        }
        // synthetic type for parameter mangling
        public static final class __2$1x10$lang$Long$3x10$array$DistArray_Block_1$$Closure$11$$T$2 {}
        
    
        
        public x10.array.LocalState_B1 $apply() {
            
            //#line 54 "x10/array/DistArray_Block_1.x10"
            final x10.array.LocalState_B1 t$108279 = x10.array.LocalState_B1.<$T> make__2$1x10$lang$Long$3x10$array$LocalState_B1$$S$2($T, ((x10.lang.PlaceGroup)(this.pg)), (long)(this.n), ((x10.core.fun.Fun_0_1)(this.init)));
            
            //#line 54 "x10/array/DistArray_Block_1.x10"
            return t$108279;
        }
        
        public x10.lang.PlaceGroup pg;
        public long n;
        public x10.core.fun.Fun_0_1<x10.core.Long,$T> init;
        
        public $Closure$11(final x10.rtt.Type $T, final x10.lang.PlaceGroup pg, final long n, final x10.core.fun.Fun_0_1<x10.core.Long,$T> init, __2$1x10$lang$Long$3x10$array$DistArray_Block_1$$Closure$11$$T$2 $dummy) {
            x10.array.DistArray_Block_1.$Closure$11.$initParams(this, $T);
             {
                ((x10.array.DistArray_Block_1.$Closure$11<$T>)this).pg = ((x10.lang.PlaceGroup)(pg));
                ((x10.array.DistArray_Block_1.$Closure$11<$T>)this).n = n;
                ((x10.array.DistArray_Block_1.$Closure$11<$T>)this).init = ((x10.core.fun.Fun_0_1)(init));
            }
        }
        
    }
    
    @x10.runtime.impl.java.X10Generated
    final public static class $Closure$12<$T> extends x10.core.Ref implements x10.core.fun.Fun_0_1, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<$Closure$12> $RTT = 
            x10.rtt.StaticFunType.<$Closure$12> make($Closure$12.class,
                                                     1,
                                                     new x10.rtt.Type[] {
                                                         x10.rtt.ParameterizedType.make(x10.core.fun.Fun_0_1.$RTT, x10.rtt.Types.LONG, x10.rtt.UnresolvedType.PARAM(0))
                                                     });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { if (i == 0) return $T; return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static <$T> x10.serialization.X10JavaSerializable $_deserialize_body(x10.array.DistArray_Block_1.$Closure$12<$T> $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            $_obj.$T = (x10.rtt.Type) $deserializer.readObject();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.array.DistArray_Block_1.$Closure$12 $_obj = new x10.array.DistArray_Block_1.$Closure$12((java.lang.System[]) null, (x10.rtt.Type) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            $serializer.write(this.$T);
            
        }
        
        // constructor just for allocation
        public $Closure$12(final java.lang.System[] $dummy, final x10.rtt.Type $T) {
            x10.array.DistArray_Block_1.$Closure$12.$initParams(this, $T);
            
        }
        
        // dispatcher for method abstract public (Z1)=>U.operator()(a1:Z1):U
        public java.lang.Object $apply(final java.lang.Object a1, final x10.rtt.Type t1) {
            return $apply$G(x10.core.Long.$unbox(a1));
            
        }
        
        private x10.rtt.Type $T;
        
        // initializer of type parameters
        public static void $initParams(final $Closure$12 $this, final x10.rtt.Type $T) {
            $this.$T = $T;
            
        }
        
    
        
        public $T $apply$G(final long id$73) {
            
            //#line 83 "x10/array/DistArray_Block_1.x10"
            final $T t$108184 = (($T)(($T) x10.rtt.Types.zeroValue($T)));
            
            //#line 83 "x10/array/DistArray_Block_1.x10"
            return t$108184;
        }
        
        public $Closure$12(final x10.rtt.Type $T) {
            x10.array.DistArray_Block_1.$Closure$12.$initParams(this, $T);
             {
                
            }
        }
        
    }
    
    @x10.runtime.impl.java.X10Generated
    final public static class $Closure$13<$T> extends x10.core.Ref implements x10.core.fun.Fun_0_1, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<$Closure$13> $RTT = 
            x10.rtt.StaticFunType.<$Closure$13> make($Closure$13.class,
                                                     1,
                                                     new x10.rtt.Type[] {
                                                         x10.rtt.ParameterizedType.make(x10.core.fun.Fun_0_1.$RTT, x10.rtt.Types.LONG, x10.rtt.UnresolvedType.PARAM(0))
                                                     });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { if (i == 0) return $T; return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static <$T> x10.serialization.X10JavaSerializable $_deserialize_body(x10.array.DistArray_Block_1.$Closure$13<$T> $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            $_obj.$T = (x10.rtt.Type) $deserializer.readObject();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.array.DistArray_Block_1.$Closure$13 $_obj = new x10.array.DistArray_Block_1.$Closure$13((java.lang.System[]) null, (x10.rtt.Type) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            $serializer.write(this.$T);
            
        }
        
        // constructor just for allocation
        public $Closure$13(final java.lang.System[] $dummy, final x10.rtt.Type $T) {
            x10.array.DistArray_Block_1.$Closure$13.$initParams(this, $T);
            
        }
        
        // dispatcher for method abstract public (Z1)=>U.operator()(a1:Z1):U
        public java.lang.Object $apply(final java.lang.Object a1, final x10.rtt.Type t1) {
            return $apply$G(x10.core.Long.$unbox(a1));
            
        }
        
        private x10.rtt.Type $T;
        
        // initializer of type parameters
        public static void $initParams(final $Closure$13 $this, final x10.rtt.Type $T) {
            $this.$T = $T;
            
        }
        
    
        
        public $T $apply$G(final long id$74) {
            
            //#line 95 "x10/array/DistArray_Block_1.x10"
            final $T t$108186 = (($T)(($T) x10.rtt.Types.zeroValue($T)));
            
            //#line 95 "x10/array/DistArray_Block_1.x10"
            return t$108186;
        }
        
        public $Closure$13(final x10.rtt.Type $T) {
            x10.array.DistArray_Block_1.$Closure$13.$initParams(this, $T);
             {
                
            }
        }
        
    }
    
}


