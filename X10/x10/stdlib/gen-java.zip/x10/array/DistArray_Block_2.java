package x10.array;


/**
 * Implementation of a 2-D DistArray that distributes its data elements
 * over the places in its PlaceGroup by distributing the first dimension 
 * in a 1-D blocked fashion.
 */
@x10.runtime.impl.java.X10Generated
public class DistArray_Block_2<$T> extends x10.array.DistArray<$T> implements x10.core.fun.Fun_0_2, x10.serialization.X10JavaSerializable
{
    public static final x10.rtt.RuntimeType<DistArray_Block_2> $RTT = 
        x10.rtt.NamedType.<DistArray_Block_2> make("x10.array.DistArray_Block_2",
                                                   DistArray_Block_2.class,
                                                   1,
                                                   new x10.rtt.Type[] {
                                                       x10.rtt.ParameterizedType.make(x10.core.fun.Fun_0_2.$RTT, x10.rtt.Types.LONG, x10.rtt.Types.LONG, x10.rtt.UnresolvedType.PARAM(0)),
                                                       x10.rtt.ParameterizedType.make(x10.array.DistArray.$RTT, x10.rtt.UnresolvedType.PARAM(0))
                                                   });
    
    public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
    
    public x10.rtt.Type<?> $getParam(int i) { if (i == 0) return $T; return null; }
    
    private Object writeReplace() throws java.io.ObjectStreamException {
        return new x10.serialization.SerializationProxy(this);
    }
    
    public static <$T> x10.serialization.X10JavaSerializable $_deserialize_body(x10.array.DistArray_Block_2<$T> $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
        x10.array.DistArray.$_deserialize_body($_obj, $deserializer);
        $_obj.$T = (x10.rtt.Type) $deserializer.readObject();
        $_obj.globalIndices = $deserializer.readObject();
        $_obj.numElems_1 = $deserializer.readLong();
        $_obj.numElems_2 = $deserializer.readLong();
        
        /* fields with @TransientInitExpr annotations */
        $_obj.localIndices = $_obj.reloadLocalIndices();
        $_obj.minIndex_1 = $_obj.reloadMinIndex_1$O();
        $_obj.numElemsLocal_1 = $_obj.reloadNumElemsLocal_1$O();
        
        return $_obj;
    }
    
    public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
        x10.array.DistArray_Block_2 $_obj = new x10.array.DistArray_Block_2((java.lang.System[]) null, (x10.rtt.Type) null);
        $deserializer.record_reference($_obj);
        return $_deserialize_body($_obj, $deserializer);
    }
    
    public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
        super.$_serialize($serializer);
        $serializer.write(this.$T);
        $serializer.write(this.globalIndices);
        $serializer.write(this.numElems_1);
        $serializer.write(this.numElems_2);
        
    }
    
    // constructor just for allocation
    public DistArray_Block_2(final java.lang.System[] $dummy, final x10.rtt.Type $T) {
        super($dummy, $T);
        x10.array.DistArray_Block_2.$initParams(this, $T);
        
    }
    
    // dispatcher for method abstract public (Z1,Z2)=>U.operator()(a1:Z1, a2:Z2){}:U
    public java.lang.Object $apply(final java.lang.Object a1, final x10.rtt.Type t1, final java.lang.Object a2, final x10.rtt.Type t2) {
        return $apply$G(x10.core.Long.$unbox(a1), x10.core.Long.$unbox(a2));
        
    }
    
    // bridge for method abstract public x10.array.DistArray[T].operator()=(p:x10.lang.Point{self.rank==this(:x10.array.DistArray).rank()}, v:T){}:T{self==v}
    final public $T $set__1x10$array$DistArray$$T$G(x10.lang.Point a1, $T a2) {
        return $set__1x10$array$DistArray_Block_2$$T$G(a1, a2);
    }
    
    private x10.rtt.Type $T;
    
    // initializer of type parameters
    public static void $initParams(final DistArray_Block_2 $this, final x10.rtt.Type $T) {
        $this.$T = $T;
        
    }
    // synthetic type for parameter mangling
    public static final class __3$1x10$lang$Long$3x10$lang$Long$3x10$array$DistArray_Block_2$$T$2 {}
    // synthetic type for parameter mangling
    public static final class __2$1x10$lang$Long$3x10$lang$Long$3x10$array$DistArray_Block_2$$T$2 {}
    

    
    
    //#line 26 "x10/array/DistArray_Block_2.x10"
    final public long rank$O() {
        
        //#line 26 "x10/array/DistArray_Block_2.x10"
        return 2L;
    }
    
    
    //#line 28 "x10/array/DistArray_Block_2.x10"
    public x10.array.DenseIterationSpace_2 globalIndices;
    
    //#line 30 "x10/array/DistArray_Block_2.x10"
    public long numElems_1;
    
    //#line 32 "x10/array/DistArray_Block_2.x10"
    public long numElems_2;
    
    //#line 35 "x10/array/DistArray_Block_2.x10"
    public transient x10.array.DenseIterationSpace_2 localIndices;
    
    
    //#line 36 "x10/array/DistArray_Block_2.x10"
    final public x10.array.DenseIterationSpace_2 reloadLocalIndices() {
        
        //#line 38 "x10/array/DistArray_Block_2.x10"
        final x10.lang.PlaceLocalHandle t$108842 = ((x10.lang.PlaceLocalHandle)(this.localHandle));
        
        //#line 38 "x10/array/DistArray_Block_2.x10"
        final x10.array.LocalState t$108843 = ((x10.lang.PlaceLocalHandle<x10.array.LocalState<$T>>)t$108842).$apply$G();
        
        //#line 38 "x10/array/DistArray_Block_2.x10"
        final x10.array.LocalState_B2 ls = x10.rtt.Types.<x10.array.LocalState_B2<$T>> cast(t$108843,x10.rtt.ParameterizedType.make(x10.array.LocalState_B2.$RTT, $T));
        
        //#line 39 "x10/array/DistArray_Block_2.x10"
        final boolean t$108845 = ((ls) != (null));
        
        //#line 39 "x10/array/DistArray_Block_2.x10"
        x10.array.DenseIterationSpace_2 t$108846 =  null;
        
        //#line 39 "x10/array/DistArray_Block_2.x10"
        if (t$108845) {
            
            //#line 39 "x10/array/DistArray_Block_2.x10"
            final x10.array.Dist_Block_2 t$108844 = ((x10.array.Dist_Block_2)(((x10.array.LocalState_B2<$T>)ls).dist));
            
            //#line 39 "x10/array/DistArray_Block_2.x10"
            t$108846 = ((x10.array.DenseIterationSpace_2)(t$108844.localIndices));
        } else {
            
            //#line 39 "x10/array/DistArray_Block_2.x10"
            final x10.array.DenseIterationSpace_2 alloc$108680 = ((x10.array.DenseIterationSpace_2)(new x10.array.DenseIterationSpace_2((java.lang.System[]) null)));
            
            //#line 39 "x10/array/DistArray_Block_2.x10"
            alloc$108680.x10$array$DenseIterationSpace_2$$init$S(((long)(0L)), ((long)(0L)), ((long)(-1L)), ((long)(-1L)));
            
            //#line 39 "x10/array/DistArray_Block_2.x10"
            t$108846 = ((x10.array.DenseIterationSpace_2)(alloc$108680));
        }
        
        //#line 39 "x10/array/DistArray_Block_2.x10"
        return t$108846;
    }
    
    
    //#line 43 "x10/array/DistArray_Block_2.x10"
    public transient long minIndex_1;
    
    
    //#line 44 "x10/array/DistArray_Block_2.x10"
    final public long reloadMinIndex_1$O() {
        
        //#line 44 "x10/array/DistArray_Block_2.x10"
        final x10.array.DenseIterationSpace_2 t$108848 = ((x10.array.DenseIterationSpace_2)(this.localIndices));
        
        //#line 44 "x10/array/DistArray_Block_2.x10"
        final long t$108849 = t$108848.min$O((long)(0L));
        
        //#line 44 "x10/array/DistArray_Block_2.x10"
        return t$108849;
    }
    
    
    //#line 47 "x10/array/DistArray_Block_2.x10"
    public transient long numElemsLocal_1;
    
    
    //#line 48 "x10/array/DistArray_Block_2.x10"
    final public long reloadNumElemsLocal_1$O() {
        
        //#line 48 "x10/array/DistArray_Block_2.x10"
        final x10.array.DenseIterationSpace_2 t$108850 = ((x10.array.DenseIterationSpace_2)(this.localIndices));
        
        //#line 48 "x10/array/DistArray_Block_2.x10"
        final long t$108851 = t$108850.max$O((long)(0L));
        
        //#line 48 "x10/array/DistArray_Block_2.x10"
        final long t$108852 = this.minIndex_1;
        
        //#line 48 "x10/array/DistArray_Block_2.x10"
        final long t$108853 = ((t$108851) - (((long)(t$108852))));
        
        //#line 48 "x10/array/DistArray_Block_2.x10"
        final long t$108854 = ((t$108853) + (((long)(1L))));
        
        //#line 48 "x10/array/DistArray_Block_2.x10"
        return t$108854;
    }
    
    
    //#line 60 "x10/array/DistArray_Block_2.x10"
    /**
     * Construct a m by n block distributed DistArray
     * whose data is distributed over pg and initialized using
     * the init function.
     *
     * @param m number of elements in the first dimension
     * @param n number of elements in the second dimension
     * @param pg the PlaceGroup to use to distibute the elements.
     * @param init the element initialization function
     */
    // creation method for java code (1-phase java constructor)
    public DistArray_Block_2(final x10.rtt.Type $T, final long m, final long n, final x10.lang.PlaceGroup pg, final x10.core.fun.Fun_0_2<x10.core.Long,x10.core.Long,$T> init, __3$1x10$lang$Long$3x10$lang$Long$3x10$array$DistArray_Block_2$$T$2 $dummy) {
        this((java.lang.System[]) null, $T);
        x10$array$DistArray_Block_2$$init$S(m, n, pg, init, (x10.array.DistArray_Block_2.__3$1x10$lang$Long$3x10$lang$Long$3x10$array$DistArray_Block_2$$T$2) null);
    }
    
    // constructor for non-virtual call
    final public x10.array.DistArray_Block_2<$T> x10$array$DistArray_Block_2$$init$S(final long m, final long n, final x10.lang.PlaceGroup pg, final x10.core.fun.Fun_0_2<x10.core.Long,x10.core.Long,$T> init, __3$1x10$lang$Long$3x10$lang$Long$3x10$array$DistArray_Block_2$$T$2 $dummy) {
         {
            
            //#line 61 "x10/array/DistArray_Block_2.x10"
            final x10.core.fun.Fun_0_0 t$108995 = ((x10.core.fun.Fun_0_0)(new x10.array.DistArray_Block_2.$Closure$14<$T>($T, pg, m, n, init, (x10.array.DistArray_Block_2.$Closure$14.__3$1x10$lang$Long$3x10$lang$Long$3x10$array$DistArray_Block_2$$Closure$14$$T$2) null)));
            
            //#line 257 . "x10/array/DistArray_Block_2.x10"
            boolean t$108999 = ((m) < (((long)(0L))));
            
            //#line 257 . "x10/array/DistArray_Block_2.x10"
            if (!(t$108999)) {
                
                //#line 257 . "x10/array/DistArray_Block_2.x10"
                t$108999 = ((n) < (((long)(0L))));
            }
            
            //#line 257 . "x10/array/DistArray_Block_2.x10"
            if (t$108999) {
                
                //#line 257 . "x10/array/DistArray_Block_2.x10"
                x10.array.DistArray.raiseNegativeArraySizeException();
            }
            
            //#line 258 . "x10/array/DistArray_Block_2.x10"
            final long t$109001 = ((m) * (((long)(n))));
            
            //#line 61 "x10/array/DistArray_Block_2.x10"
            /*super.*/x10$array$DistArray$$init$S(((x10.lang.PlaceGroup)(pg)), ((x10.core.fun.Fun_0_0)(t$108995)), t$109001, (x10.array.DistArray.__1$1x10$array$LocalState$1x10$array$DistArray$$T$2$2) null);
            
            //#line 60 "x10/array/DistArray_Block_2.x10"
            
            
            //#line 62 "x10/array/DistArray_Block_2.x10"
            final x10.array.DenseIterationSpace_2 alloc$108681 = ((x10.array.DenseIterationSpace_2)(new x10.array.DenseIterationSpace_2((java.lang.System[]) null)));
            
            //#line 62 "x10/array/DistArray_Block_2.x10"
            final long t$109003 = ((m) - (((long)(1L))));
            
            //#line 62 "x10/array/DistArray_Block_2.x10"
            final long t$109004 = ((n) - (((long)(1L))));
            
            //#line 62 "x10/array/DistArray_Block_2.x10"
            alloc$108681.x10$array$DenseIterationSpace_2$$init$S(((long)(0L)), ((long)(0L)), t$109003, t$109004);
            
            //#line 62 "x10/array/DistArray_Block_2.x10"
            ((x10.array.DistArray_Block_2<$T>)this).globalIndices = ((x10.array.DenseIterationSpace_2)(alloc$108681));
            
            //#line 63 "x10/array/DistArray_Block_2.x10"
            ((x10.array.DistArray_Block_2<$T>)this).numElems_1 = m;
            
            //#line 64 "x10/array/DistArray_Block_2.x10"
            ((x10.array.DistArray_Block_2<$T>)this).numElems_2 = n;
            
            //#line 65 "x10/array/DistArray_Block_2.x10"
            final x10.array.DenseIterationSpace_2 t$108862 = ((x10.array.DenseIterationSpace_2)(this.reloadLocalIndices()));
            
            //#line 65 "x10/array/DistArray_Block_2.x10"
            ((x10.array.DistArray_Block_2<$T>)this).localIndices = ((x10.array.DenseIterationSpace_2)(t$108862));
            
            //#line 66 "x10/array/DistArray_Block_2.x10"
            final x10.array.DistArray_Block_2 this$108788 = ((x10.array.DistArray_Block_2)(this));
            
            //#line 44 . "x10/array/DistArray_Block_2.x10"
            final x10.array.DenseIterationSpace_2 t$108863 = ((x10.array.DenseIterationSpace_2)(((x10.array.DistArray_Block_2<$T>)this$108788).localIndices));
            
            //#line 44 . "x10/array/DistArray_Block_2.x10"
            final long t$108864 = t$108863.min$O((long)(0L));
            
            //#line 66 "x10/array/DistArray_Block_2.x10"
            ((x10.array.DistArray_Block_2<$T>)this).minIndex_1 = t$108864;
            
            //#line 67 "x10/array/DistArray_Block_2.x10"
            final long t$108865 = this.reloadNumElemsLocal_1$O();
            
            //#line 67 "x10/array/DistArray_Block_2.x10"
            ((x10.array.DistArray_Block_2<$T>)this).numElemsLocal_1 = t$108865;
        }
        return this;
    }
    
    
    
    //#line 80 "x10/array/DistArray_Block_2.x10"
    /**
     * Construct a m by n block distributed DistArray
     * whose data is distributed over Place.places() and 
     * initialized using the provided init closure.
     *
     * @param m number of elements in the first dimension
     * @param n number of elements in the second dimension
     * @param init the element initialization function
     */
    // creation method for java code (1-phase java constructor)
    public DistArray_Block_2(final x10.rtt.Type $T, final long m, final long n, final x10.core.fun.Fun_0_2<x10.core.Long,x10.core.Long,$T> init, __2$1x10$lang$Long$3x10$lang$Long$3x10$array$DistArray_Block_2$$T$2 $dummy) {
        this((java.lang.System[]) null, $T);
        x10$array$DistArray_Block_2$$init$S(m, n, init, (x10.array.DistArray_Block_2.__2$1x10$lang$Long$3x10$lang$Long$3x10$array$DistArray_Block_2$$T$2) null);
    }
    
    // constructor for non-virtual call
    final public x10.array.DistArray_Block_2<$T> x10$array$DistArray_Block_2$$init$S(final long m, final long n, final x10.core.fun.Fun_0_2<x10.core.Long,x10.core.Long,$T> init, __2$1x10$lang$Long$3x10$lang$Long$3x10$array$DistArray_Block_2$$T$2 $dummy) {
         {
            
            //#line 81 "x10/array/DistArray_Block_2.x10"
            final x10.lang.PlaceGroup t$108866 = ((x10.lang.PlaceGroup)(x10.lang.Place.places()));
            
            //#line 81 "x10/array/DistArray_Block_2.x10"
            /*this.*/x10$array$DistArray_Block_2$$init$S(((long)(m)), ((long)(n)), t$108866, ((x10.core.fun.Fun_0_2)(init)), (x10.array.DistArray_Block_2.__3$1x10$lang$Long$3x10$lang$Long$3x10$array$DistArray_Block_2$$T$2) null);
        }
        return this;
    }
    
    
    
    //#line 93 "x10/array/DistArray_Block_2.x10"
    /**
     * Construct a m by n block distributed DistArray
     * whose data is distributed over pg and zero-initialized.
     *
     * @param m number of elements in the first dimension
     * @param n number of elements in the second dimension
     * @param pg the PlaceGroup to use to distibute the elements.
     */
    // creation method for java code (1-phase java constructor)
    public DistArray_Block_2(final x10.rtt.Type $T, final long m, final long n, final x10.lang.PlaceGroup pg) {
        this((java.lang.System[]) null, $T);
        x10$array$DistArray_Block_2$$init$S(m, n, pg);
    }
    
    // constructor for non-virtual call
    final public x10.array.DistArray_Block_2<$T> x10$array$DistArray_Block_2$$init$S(final long m, final long n, final x10.lang.PlaceGroup pg) {
         {
            
            //#line 94 "x10/array/DistArray_Block_2.x10"
            final x10.core.fun.Fun_0_2 t$108868 = ((x10.core.fun.Fun_0_2)(new x10.array.DistArray_Block_2.$Closure$15<$T>($T)));
            
            //#line 94 "x10/array/DistArray_Block_2.x10"
            /*this.*/x10$array$DistArray_Block_2$$init$S(((long)(m)), ((long)(n)), ((x10.lang.PlaceGroup)(pg)), ((x10.core.fun.Fun_0_2)(t$108868)), (x10.array.DistArray_Block_2.__3$1x10$lang$Long$3x10$lang$Long$3x10$array$DistArray_Block_2$$T$2) null);
        }
        return this;
    }
    
    
    
    //#line 106 "x10/array/DistArray_Block_2.x10"
    /**
     * Construct a m by n block distributed DistArray
     * whose data is distributed over Place.places() and 
     * zero-initialized.
     *
     * @param m number of elements in the first dimension
     * @param n number of elements in the second dimension
     */
    // creation method for java code (1-phase java constructor)
    public DistArray_Block_2(final x10.rtt.Type $T, final long m, final long n) {
        this((java.lang.System[]) null, $T);
        x10$array$DistArray_Block_2$$init$S(m, n);
    }
    
    // constructor for non-virtual call
    final public x10.array.DistArray_Block_2<$T> x10$array$DistArray_Block_2$$init$S(final long m, final long n) {
         {
            
            //#line 107 "x10/array/DistArray_Block_2.x10"
            final x10.lang.PlaceGroup t$108870 = ((x10.lang.PlaceGroup)(x10.lang.Place.places()));
            
            //#line 107 "x10/array/DistArray_Block_2.x10"
            final x10.core.fun.Fun_0_2 t$108871 = ((x10.core.fun.Fun_0_2)(new x10.array.DistArray_Block_2.$Closure$16<$T>($T)));
            
            //#line 107 "x10/array/DistArray_Block_2.x10"
            /*this.*/x10$array$DistArray_Block_2$$init$S(((long)(m)), ((long)(n)), t$108870, ((x10.core.fun.Fun_0_2)(t$108871)), (x10.array.DistArray_Block_2.__3$1x10$lang$Long$3x10$lang$Long$3x10$array$DistArray_Block_2$$T$2) null);
        }
        return this;
    }
    
    
    
    //#line 116 "x10/array/DistArray_Block_2.x10"
    /**
     * Get an IterationSpace that represents all Points contained in
     * the global iteration space (valid indices) of the DistArray.
     * @return an IterationSpace for the DistArray
     */
    final public x10.array.DenseIterationSpace_2 globalIndices() {
        
        //#line 116 "x10/array/DistArray_Block_2.x10"
        final x10.array.DenseIterationSpace_2 t$108872 = ((x10.array.DenseIterationSpace_2)(this.globalIndices));
        
        //#line 116 "x10/array/DistArray_Block_2.x10"
        return t$108872;
    }
    
    
    //#line 124 "x10/array/DistArray_Block_2.x10"
    /**
     * Get an IterationSpace that represents all Points contained in
     * the local iteration space (valid indices) of the DistArray at the current Place.
     * @return an IterationSpace for the local portion of the DistArray
     */
    final public x10.array.DenseIterationSpace_2 localIndices() {
        
        //#line 124 "x10/array/DistArray_Block_2.x10"
        final x10.array.DenseIterationSpace_2 t$108873 = ((x10.array.DenseIterationSpace_2)(this.localIndices));
        
        //#line 124 "x10/array/DistArray_Block_2.x10"
        return t$108873;
    }
    
    
    //#line 137 "x10/array/DistArray_Block_2.x10"
    /**
     * Return the Place which contains the data for the argument
     * index or Place.INVALID_PLACE if the Point is not in the globalIndices
     * of this DistArray
     *
     * @param i the index in the first dimension
     * @param j the index in the second dimension
     * @return the Place where (i,j) is a valid index in the DistArray; 
     *          will return Place.INVALID_PLACE if (i,j) is not contained in globalIndices
     */
    final public x10.lang.Place place(final long i, final long j) {
        
        //#line 138 "x10/array/DistArray_Block_2.x10"
        boolean t$108875 = ((j) < (((long)(0L))));
        
        //#line 138 "x10/array/DistArray_Block_2.x10"
        if (!(t$108875)) {
            
            //#line 138 "x10/array/DistArray_Block_2.x10"
            final long t$108874 = this.numElems_2;
            
            //#line 138 "x10/array/DistArray_Block_2.x10"
            t$108875 = ((j) >= (((long)(t$108874))));
        }
        
        //#line 138 "x10/array/DistArray_Block_2.x10"
        if (t$108875) {
            
            //#line 138 "x10/array/DistArray_Block_2.x10"
            final x10.lang.Place t$108876 = ((x10.lang.Place)(x10.lang.Place.get$INVALID_PLACE()));
            
            //#line 138 "x10/array/DistArray_Block_2.x10"
            return t$108876;
        }
        
        //#line 139 "x10/array/DistArray_Block_2.x10"
        final long t$108878 = this.numElems_1;
        
        //#line 139 "x10/array/DistArray_Block_2.x10"
        final long t$108879 = ((t$108878) - (((long)(1L))));
        
        //#line 139 "x10/array/DistArray_Block_2.x10"
        final x10.lang.PlaceGroup this$108790 = ((x10.lang.PlaceGroup)(this.placeGroup));
        
        //#line 35 . "x10/lang/PlaceGroup.x10"
        final long t$108880 = this$108790.numPlaces$O();
        
        //#line 139 "x10/array/DistArray_Block_2.x10"
        final long tmp = x10.array.BlockingUtils.mapIndexToBlockPartition$O((long)(0L), (long)(t$108879), (long)(t$108880), (long)(i));
        
        //#line 140 "x10/array/DistArray_Block_2.x10"
        final boolean t$108882 = ((long) tmp) == ((long) -1L);
        
        //#line 140 "x10/array/DistArray_Block_2.x10"
        x10.lang.Place t$108883 =  null;
        
        //#line 140 "x10/array/DistArray_Block_2.x10"
        if (t$108882) {
            
            //#line 140 "x10/array/DistArray_Block_2.x10"
            t$108883 = x10.lang.Place.get$INVALID_PLACE();
        } else {
            
            //#line 140 "x10/array/DistArray_Block_2.x10"
            final x10.lang.PlaceGroup t$108881 = ((x10.lang.PlaceGroup)(this.placeGroup));
            
            //#line 140 "x10/array/DistArray_Block_2.x10"
            t$108883 = t$108881.$apply((long)(tmp));
        }
        
        //#line 140 "x10/array/DistArray_Block_2.x10"
        return t$108883;
    }
    
    
    //#line 153 "x10/array/DistArray_Block_2.x10"
    /**
     * Return the Place which contains the data for the argument
     * Point or Place.INVALID_PLACE if the Point is not in the globalIndices
     * of this DistArray
     *
     * @param p the Point to lookup
     * @return the Place where p is a valid index in the DistArray; 
     *          will return Place.INVALID_PLACE if p is not contained in globalIndices
     */
    final public x10.lang.Place place(final x10.lang.Point p) {
        
        //#line 153 "x10/array/DistArray_Block_2.x10"
        final long t$108885 = p.$apply$O((long)(0L));
        
        //#line 153 "x10/array/DistArray_Block_2.x10"
        final long t$108886 = p.$apply$O((long)(1L));
        
        //#line 153 "x10/array/DistArray_Block_2.x10"
        final x10.lang.Place t$108887 = this.place((long)(t$108885), (long)(t$108886));
        
        //#line 153 "x10/array/DistArray_Block_2.x10"
        return t$108887;
    }
    
    
    //#line 164 "x10/array/DistArray_Block_2.x10"
    /**
     * Return the element of this array corresponding to the given index.
     * 
     * @param i the given index in the first dimension
     * @param j the given index in the second dimension
     * @return the element of this array corresponding to the given index.
     * @see #set(T, Long, Long)
     */
    final public $T $apply$G(final long i, final long j) {
        
        //#line 165 "x10/array/DistArray_Block_2.x10"
        this.validateIndex((long)(i), (long)(j));
        
        //#line 166 "x10/array/DistArray_Block_2.x10"
        final x10.core.Rail r$108796 = ((x10.core.Rail)(this.raw));
        
        //#line 166 "x10/array/DistArray_Block_2.x10"
        final x10.array.DistArray_Block_2 this$108794 = ((x10.array.DistArray_Block_2)(this));
        
        //#line 228 . "x10/array/DistArray_Block_2.x10"
        final long t$108888 = ((x10.array.DistArray_Block_2<$T>)this$108794).minIndex_1;
        
        //#line 228 . "x10/array/DistArray_Block_2.x10"
        final long t$108889 = ((i) - (((long)(t$108888))));
        
        //#line 228 . "x10/array/DistArray_Block_2.x10"
        final long t$108890 = ((x10.array.DistArray_Block_2<$T>)this$108794).numElems_2;
        
        //#line 228 . "x10/array/DistArray_Block_2.x10"
        final long t$108891 = ((t$108889) * (((long)(t$108890))));
        
        //#line 166 "x10/array/DistArray_Block_2.x10"
        final long i$108797 = ((j) + (((long)(t$108891))));
        
        //#line 38 . "x10/lang/Unsafe.x10"
        final $T t$108892 = (($T)(((x10.core.Rail<$T>)r$108796).$apply$G((long)(i$108797))));
        
        //#line 166 "x10/array/DistArray_Block_2.x10"
        return t$108892;
    }
    
    
    //#line 177 "x10/array/DistArray_Block_2.x10"
    /**
     * Return the element of this array corresponding to the given Point.
     * 
     * @param p the given Point
     * @return the element of this array corresponding to the given Point.
     * @see #set(T, Point)
     */
    final public $T $apply$G(final x10.lang.Point p) {
        
        //#line 177 "x10/array/DistArray_Block_2.x10"
        final x10.array.DistArray_Block_2 this$108801 = ((x10.array.DistArray_Block_2)(this));
        
        //#line 177 "x10/array/DistArray_Block_2.x10"
        final long i$108799 = p.$apply$O((long)(0L));
        
        //#line 177 "x10/array/DistArray_Block_2.x10"
        final long j$108800 = p.$apply$O((long)(1L));
        
        //#line 165 . "x10/array/DistArray_Block_2.x10"
        ((x10.array.DistArray_Block_2<$T>)this$108801).validateIndex((long)(i$108799), (long)(j$108800));
        
        //#line 166 . "x10/array/DistArray_Block_2.x10"
        final x10.core.Rail r$108806 = ((x10.core.Rail)(((x10.array.DistArray<$T>)this$108801).raw));
        
        //#line 228 .. "x10/array/DistArray_Block_2.x10"
        final long t$108893 = ((x10.array.DistArray_Block_2<$T>)this$108801).minIndex_1;
        
        //#line 228 .. "x10/array/DistArray_Block_2.x10"
        final long t$108894 = ((i$108799) - (((long)(t$108893))));
        
        //#line 228 .. "x10/array/DistArray_Block_2.x10"
        final long t$108895 = ((x10.array.DistArray_Block_2<$T>)this$108801).numElems_2;
        
        //#line 228 .. "x10/array/DistArray_Block_2.x10"
        final long t$108896 = ((t$108894) * (((long)(t$108895))));
        
        //#line 166 . "x10/array/DistArray_Block_2.x10"
        final long i$108807 = ((j$108800) + (((long)(t$108896))));
        
        //#line 38 .. "x10/lang/Unsafe.x10"
        final $T t$108897 = (($T)(((x10.core.Rail<$T>)r$108806).$apply$G((long)(i$108807))));
        
        //#line 177 "x10/array/DistArray_Block_2.x10"
        return t$108897;
    }
    
    
    //#line 190 "x10/array/DistArray_Block_2.x10"
    /**
     * Set the element of this array corresponding to the given index to the given value.
     * Return the new value of the element.
     * 
     * @param v the given value
     * @param i the given index in the first dimension
     * @param j the given index in the second dimension
     * @return the new value of the element of this array corresponding to the given index.
     * @see #operator(Long, Long)
     */
    final public $T $set__2x10$array$DistArray_Block_2$$T$G(final long i, final long j, final $T v) {
        
        //#line 191 "x10/array/DistArray_Block_2.x10"
        this.validateIndex((long)(i), (long)(j));
        
        //#line 192 "x10/array/DistArray_Block_2.x10"
        final x10.core.Rail r$108813 = ((x10.core.Rail)(this.raw));
        
        //#line 192 "x10/array/DistArray_Block_2.x10"
        final x10.array.DistArray_Block_2 this$108811 = ((x10.array.DistArray_Block_2)(this));
        
        //#line 228 . "x10/array/DistArray_Block_2.x10"
        final long t$108898 = ((x10.array.DistArray_Block_2<$T>)this$108811).minIndex_1;
        
        //#line 228 . "x10/array/DistArray_Block_2.x10"
        final long t$108899 = ((i) - (((long)(t$108898))));
        
        //#line 228 . "x10/array/DistArray_Block_2.x10"
        final long t$108900 = ((x10.array.DistArray_Block_2<$T>)this$108811).numElems_2;
        
        //#line 228 . "x10/array/DistArray_Block_2.x10"
        final long t$108901 = ((t$108899) * (((long)(t$108900))));
        
        //#line 192 "x10/array/DistArray_Block_2.x10"
        final long i$108814 = ((j) + (((long)(t$108901))));
        
        //#line 42 . "x10/lang/Unsafe.x10"
        ((x10.core.Rail<$T>)r$108813).$set__1x10$lang$Rail$$T$G((long)(i$108814), (($T)(v)));
        
        //#line 192 "x10/array/DistArray_Block_2.x10"
        return (($T)
                 v);
    }
    
    
    //#line 205 "x10/array/DistArray_Block_2.x10"
    /**
     * Set the element of this array corresponding to the given Point to the given value.
     * Return the new value of the element.
     * 
     * @param v the given value
     * @param p the given Point
     * @return the new value of the element of this array corresponding to the given Point.
     * @see #operator(Point)
     */
    final public $T $set__1x10$array$DistArray_Block_2$$T$G(final x10.lang.Point p, final $T v) {
        
        //#line 205 "x10/array/DistArray_Block_2.x10"
        final x10.array.DistArray_Block_2 this$108820 = ((x10.array.DistArray_Block_2)(this));
        
        //#line 205 "x10/array/DistArray_Block_2.x10"
        final long i$108817 = p.$apply$O((long)(0L));
        
        //#line 205 "x10/array/DistArray_Block_2.x10"
        final long j$108818 = p.$apply$O((long)(1L));
        
        //#line 191 . "x10/array/DistArray_Block_2.x10"
        ((x10.array.DistArray_Block_2<$T>)this$108820).validateIndex((long)(i$108817), (long)(j$108818));
        
        //#line 192 . "x10/array/DistArray_Block_2.x10"
        final x10.core.Rail r$108825 = ((x10.core.Rail)(((x10.array.DistArray<$T>)this$108820).raw));
        
        //#line 228 .. "x10/array/DistArray_Block_2.x10"
        final long t$108902 = ((x10.array.DistArray_Block_2<$T>)this$108820).minIndex_1;
        
        //#line 228 .. "x10/array/DistArray_Block_2.x10"
        final long t$108903 = ((i$108817) - (((long)(t$108902))));
        
        //#line 228 .. "x10/array/DistArray_Block_2.x10"
        final long t$108904 = ((x10.array.DistArray_Block_2<$T>)this$108820).numElems_2;
        
        //#line 228 .. "x10/array/DistArray_Block_2.x10"
        final long t$108905 = ((t$108903) * (((long)(t$108904))));
        
        //#line 192 . "x10/array/DistArray_Block_2.x10"
        final long i$108826 = ((j$108818) + (((long)(t$108905))));
        
        //#line 42 .. "x10/lang/Unsafe.x10"
        ((x10.core.Rail<$T>)r$108825).$set__1x10$lang$Rail$$T$G((long)(i$108826), (($T)(v)));
        
        //#line 205 "x10/array/DistArray_Block_2.x10"
        return (($T)
                 v);
    }
    
    
    //#line 213 "x10/array/DistArray_Block_2.x10"
    final public void validateIndex(final long i, final long j) {
        
        //#line 215 "x10/array/DistArray_Block_2.x10"
        boolean t$108907 = ((j) < (((long)(0L))));
        
        //#line 215 "x10/array/DistArray_Block_2.x10"
        if (!(t$108907)) {
            
            //#line 215 "x10/array/DistArray_Block_2.x10"
            final long t$108906 = this.numElems_2;
            
            //#line 215 "x10/array/DistArray_Block_2.x10"
            t$108907 = ((j) >= (((long)(t$108906))));
        }
        
        //#line 215 "x10/array/DistArray_Block_2.x10"
        if (t$108907) {
            
            //#line 216 "x10/array/DistArray_Block_2.x10"
            x10.array.DistArray.raiseBoundsError((long)(i), (long)(j));
        }
        
        //#line 218 "x10/array/DistArray_Block_2.x10"
        final long t$108909 = this.minIndex_1;
        
        //#line 218 "x10/array/DistArray_Block_2.x10"
        boolean t$108913 = ((i) < (((long)(t$108909))));
        
        //#line 218 "x10/array/DistArray_Block_2.x10"
        if (!(t$108913)) {
            
            //#line 218 "x10/array/DistArray_Block_2.x10"
            final long t$108910 = this.minIndex_1;
            
            //#line 218 "x10/array/DistArray_Block_2.x10"
            final long t$108911 = this.numElemsLocal_1;
            
            //#line 218 "x10/array/DistArray_Block_2.x10"
            final long t$108912 = ((t$108910) + (((long)(t$108911))));
            
            //#line 218 "x10/array/DistArray_Block_2.x10"
            t$108913 = ((i) >= (((long)(t$108912))));
        }
        
        //#line 218 "x10/array/DistArray_Block_2.x10"
        if (t$108913) {
            
            //#line 219 "x10/array/DistArray_Block_2.x10"
            boolean t$108915 = ((i) < (((long)(0L))));
            
            //#line 219 "x10/array/DistArray_Block_2.x10"
            if (!(t$108915)) {
                
                //#line 219 "x10/array/DistArray_Block_2.x10"
                final long t$108914 = this.numElems_1;
                
                //#line 219 "x10/array/DistArray_Block_2.x10"
                t$108915 = ((i) >= (((long)(t$108914))));
            }
            
            //#line 219 "x10/array/DistArray_Block_2.x10"
            if (t$108915) {
                
                //#line 220 "x10/array/DistArray_Block_2.x10"
                x10.array.DistArray.raiseBoundsError((long)(i), (long)(j));
            }
            
            //#line 222 "x10/array/DistArray_Block_2.x10"
            x10.array.DistArray.raisePlaceError((long)(i), (long)(j));
        }
    }
    
    
    //#line 227 "x10/array/DistArray_Block_2.x10"
    final public long offset$O(final long i, final long j) {
        
        //#line 228 "x10/array/DistArray_Block_2.x10"
        final long t$108918 = this.minIndex_1;
        
        //#line 228 "x10/array/DistArray_Block_2.x10"
        final long t$108919 = ((i) - (((long)(t$108918))));
        
        //#line 228 "x10/array/DistArray_Block_2.x10"
        final long t$108920 = this.numElems_2;
        
        //#line 228 "x10/array/DistArray_Block_2.x10"
        final long t$108921 = ((t$108919) * (((long)(t$108920))));
        
        //#line 228 "x10/array/DistArray_Block_2.x10"
        final long t$108922 = ((j) + (((long)(t$108921))));
        
        //#line 228 "x10/array/DistArray_Block_2.x10"
        return t$108922;
    }
    
    
    //#line 239 "x10/array/DistArray_Block_2.x10"
    /**
     * Returns the specified rectangular patch of this array as a Rail.
     * 
     * @param space the IterationSpace representing the portion of this array to copy
     * @see offset
     * @throws ArrayIndexOutOfBoundsException if the specified region is not
     *        contained in this array
     */
    public x10.core.Rail getPatch(final x10.array.IterationSpace space) {
        
        //#line 240 "x10/array/DistArray_Block_2.x10"
        final x10.array.DenseIterationSpace_2 r = ((x10.array.DenseIterationSpace_2)(x10.rtt.Types.<x10.array.DenseIterationSpace_2> cast(space,x10.array.DenseIterationSpace_2.$RTT)));
        
        //#line 243 "x10/array/DistArray_Block_2.x10"
        final x10.array.DenseIterationSpace_2 t$108923 = ((x10.array.DenseIterationSpace_2)(this.localIndices));
        
        //#line 243 "x10/array/DistArray_Block_2.x10"
        final long t$108924 = t$108923.min0;
        
        //#line 243 "x10/array/DistArray_Block_2.x10"
        final long t$108925 = r.min0;
        
        //#line 243 "x10/array/DistArray_Block_2.x10"
        boolean t$108929 = ((t$108924) <= (((long)(t$108925))));
        
        //#line 243 "x10/array/DistArray_Block_2.x10"
        if (t$108929) {
            
            //#line 243 "x10/array/DistArray_Block_2.x10"
            final long t$108927 = r.max0;
            
            //#line 243 "x10/array/DistArray_Block_2.x10"
            final x10.array.DenseIterationSpace_2 t$108926 = ((x10.array.DenseIterationSpace_2)(this.localIndices));
            
            //#line 243 "x10/array/DistArray_Block_2.x10"
            final long t$108928 = t$108926.max0;
            
            //#line 243 "x10/array/DistArray_Block_2.x10"
            t$108929 = ((t$108927) <= (((long)(t$108928))));
        }
        
        //#line 243 "x10/array/DistArray_Block_2.x10"
        boolean t$108933 = t$108929;
        
        //#line 243 "x10/array/DistArray_Block_2.x10"
        if (t$108929) {
            
            //#line 244 "x10/array/DistArray_Block_2.x10"
            final x10.array.DenseIterationSpace_2 t$108930 = ((x10.array.DenseIterationSpace_2)(this.localIndices));
            
            //#line 244 "x10/array/DistArray_Block_2.x10"
            final long t$108931 = t$108930.min1;
            
            //#line 244 "x10/array/DistArray_Block_2.x10"
            final long t$108932 = r.min1;
            
            //#line 243 "x10/array/DistArray_Block_2.x10"
            t$108933 = ((t$108931) <= (((long)(t$108932))));
        }
        
        //#line 243 "x10/array/DistArray_Block_2.x10"
        boolean t$108937 = t$108933;
        
        //#line 243 "x10/array/DistArray_Block_2.x10"
        if (t$108933) {
            
            //#line 244 "x10/array/DistArray_Block_2.x10"
            final long t$108935 = r.max1;
            
            //#line 244 "x10/array/DistArray_Block_2.x10"
            final x10.array.DenseIterationSpace_2 t$108934 = ((x10.array.DenseIterationSpace_2)(this.localIndices));
            
            //#line 244 "x10/array/DistArray_Block_2.x10"
            final long t$108936 = t$108934.max1;
            
            //#line 243 "x10/array/DistArray_Block_2.x10"
            t$108937 = ((t$108935) <= (((long)(t$108936))));
        }
        
        //#line 243 "x10/array/DistArray_Block_2.x10"
        final boolean t$108944 = !(t$108937);
        
        //#line 242 "x10/array/DistArray_Block_2.x10"
        if (t$108944) {
            
            //#line 245 "x10/array/DistArray_Block_2.x10"
            final java.lang.String t$108939 = (("patch to copy: ") + (r));
            
            //#line 245 "x10/array/DistArray_Block_2.x10"
            final java.lang.String t$108940 = ((t$108939) + (" not contained in local indices: "));
            
            //#line 245 "x10/array/DistArray_Block_2.x10"
            final x10.array.DenseIterationSpace_2 t$108941 = ((x10.array.DenseIterationSpace_2)(this.localIndices));
            
            //#line 245 "x10/array/DistArray_Block_2.x10"
            final java.lang.String t$108942 = ((t$108940) + (t$108941));
            
            //#line 245 "x10/array/DistArray_Block_2.x10"
            final java.lang.ArrayIndexOutOfBoundsException t$108943 = ((java.lang.ArrayIndexOutOfBoundsException)(new java.lang.ArrayIndexOutOfBoundsException(t$108942)));
            
            //#line 245 "x10/array/DistArray_Block_2.x10"
            throw t$108943;
        }
        
        //#line 248 "x10/array/DistArray_Block_2.x10"
        final long t$108945 = r.size$O();
        
        //#line 248 "x10/array/DistArray_Block_2.x10"
        final x10.core.Rail patch = ((x10.core.Rail)(x10.core.Rail.<$T>makeUnsafe($T, ((long)(t$108945)), false)));
        
        //#line 249 "x10/array/DistArray_Block_2.x10"
        long patchIndex = 0L;
        
        //#line 250 "x10/array/DistArray_Block_2.x10"
        final long i1$108685min$109031 = r.min$O((long)(1L));
        
        //#line 250 "x10/array/DistArray_Block_2.x10"
        final long i1$108685max$109032 = r.max$O((long)(1L));
        
        //#line 250 "x10/array/DistArray_Block_2.x10"
        final long i0$108716min$109033 = r.min$O((long)(0L));
        
        //#line 250 "x10/array/DistArray_Block_2.x10"
        final long i0$108716max$109034 = r.max$O((long)(0L));
        
        //#line 250 "x10/array/DistArray_Block_2.x10"
        long i$109027 = i0$108716min$109033;
        
        //#line 250 "x10/array/DistArray_Block_2.x10"
        for (;
             true;
             ) {
            
            //#line 250 "x10/array/DistArray_Block_2.x10"
            final boolean t$109029 = ((i$109027) <= (((long)(i0$108716max$109034))));
            
            //#line 250 "x10/array/DistArray_Block_2.x10"
            if (!(t$109029)) {
                
                //#line 250 "x10/array/DistArray_Block_2.x10"
                break;
            }
            
            //#line 250 "x10/array/DistArray_Block_2.x10"
            long i$109021 = i1$108685min$109031;
            
            //#line 250 "x10/array/DistArray_Block_2.x10"
            for (;
                 true;
                 ) {
                
                //#line 250 "x10/array/DistArray_Block_2.x10"
                final boolean t$109023 = ((i$109021) <= (((long)(i1$108685max$109032))));
                
                //#line 250 "x10/array/DistArray_Block_2.x10"
                if (!(t$109023)) {
                    
                    //#line 250 "x10/array/DistArray_Block_2.x10"
                    break;
                }
                
                //#line 251 "x10/array/DistArray_Block_2.x10"
                final long pre$109005 = patchIndex;
                
                //#line 251 "x10/array/DistArray_Block_2.x10"
                final long t$109007 = ((patchIndex) + (((long)(1L))));
                
                //#line 251 "x10/array/DistArray_Block_2.x10"
                patchIndex = t$109007;
                
                //#line 251 "x10/array/DistArray_Block_2.x10"
                final x10.core.Rail t$109008 = ((x10.core.Rail)(this.raw));
                
                //#line 251 "x10/array/DistArray_Block_2.x10"
                final x10.array.DistArray_Block_2 this$109009 = ((x10.array.DistArray_Block_2)(this));
                
                //#line 228 . "x10/array/DistArray_Block_2.x10"
                final long t$109012 = ((x10.array.DistArray_Block_2<$T>)this$109009).minIndex_1;
                
                //#line 228 . "x10/array/DistArray_Block_2.x10"
                final long t$109013 = ((i$109027) - (((long)(t$109012))));
                
                //#line 228 . "x10/array/DistArray_Block_2.x10"
                final long t$109014 = ((x10.array.DistArray_Block_2<$T>)this$109009).numElems_2;
                
                //#line 228 . "x10/array/DistArray_Block_2.x10"
                final long t$109015 = ((t$109013) * (((long)(t$109014))));
                
                //#line 228 . "x10/array/DistArray_Block_2.x10"
                final long t$109016 = ((i$109021) + (((long)(t$109015))));
                
                //#line 251 "x10/array/DistArray_Block_2.x10"
                final $T t$109017 = (($T)(((x10.core.Rail<$T>)t$109008).$apply$G((long)(t$109016))));
                
                //#line 251 "x10/array/DistArray_Block_2.x10"
                ((x10.core.Rail<$T>)patch).$set__1x10$lang$Rail$$T$G((long)(pre$109005), (($T)(t$109017)));
                
                //#line 250 "x10/array/DistArray_Block_2.x10"
                final long t$109020 = ((i$109021) + (((long)(1L))));
                
                //#line 250 "x10/array/DistArray_Block_2.x10"
                i$109021 = t$109020;
            }
            
            //#line 250 "x10/array/DistArray_Block_2.x10"
            final long t$109026 = ((i$109027) + (((long)(1L))));
            
            //#line 250 "x10/array/DistArray_Block_2.x10"
            i$109027 = t$109026;
        }
        
        //#line 253 "x10/array/DistArray_Block_2.x10"
        return patch;
    }
    
    
    //#line 256 "x10/array/DistArray_Block_2.x10"
    private static long validateSize$O(final long m, final long n) {
        
        //#line 257 "x10/array/DistArray_Block_2.x10"
        boolean t$108965 = ((m) < (((long)(0L))));
        
        //#line 257 "x10/array/DistArray_Block_2.x10"
        if (!(t$108965)) {
            
            //#line 257 "x10/array/DistArray_Block_2.x10"
            t$108965 = ((n) < (((long)(0L))));
        }
        
        //#line 257 "x10/array/DistArray_Block_2.x10"
        if (t$108965) {
            
            //#line 257 "x10/array/DistArray_Block_2.x10"
            x10.array.DistArray.raiseNegativeArraySizeException();
        }
        
        //#line 258 "x10/array/DistArray_Block_2.x10"
        final long t$108967 = ((m) * (((long)(n))));
        
        //#line 258 "x10/array/DistArray_Block_2.x10"
        return t$108967;
    }
    
    public static long validateSize$P$O(final long m, final long n) {
        return x10.array.DistArray_Block_2.validateSize$O((long)(m), (long)(n));
    }
    
    
    //#line 24 "x10/array/DistArray_Block_2.x10"
    final public x10.array.DistArray_Block_2 x10$array$DistArray_Block_2$$this$x10$array$DistArray_Block_2() {
        
        //#line 24 "x10/array/DistArray_Block_2.x10"
        return x10.array.DistArray_Block_2.this;
    }
    
    
    //#line 24 "x10/array/DistArray_Block_2.x10"
    final public void __fieldInitializers_x10_array_DistArray_Block_2() {
        
    }
    
    @x10.runtime.impl.java.X10Generated
    final public static class $Closure$14<$T> extends x10.core.Ref implements x10.core.fun.Fun_0_0, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<$Closure$14> $RTT = 
            x10.rtt.StaticFunType.<$Closure$14> make($Closure$14.class,
                                                     1,
                                                     new x10.rtt.Type[] {
                                                         x10.rtt.ParameterizedType.make(x10.core.fun.Fun_0_0.$RTT, x10.rtt.ParameterizedType.make(x10.array.LocalState_B2.$RTT, x10.rtt.UnresolvedType.PARAM(0)))
                                                     });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { if (i == 0) return $T; return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static <$T> x10.serialization.X10JavaSerializable $_deserialize_body(x10.array.DistArray_Block_2.$Closure$14<$T> $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            $_obj.$T = (x10.rtt.Type) $deserializer.readObject();
            $_obj.init = $deserializer.readObject();
            $_obj.m = $deserializer.readLong();
            $_obj.n = $deserializer.readLong();
            $_obj.pg = $deserializer.readObject();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.array.DistArray_Block_2.$Closure$14 $_obj = new x10.array.DistArray_Block_2.$Closure$14((java.lang.System[]) null, (x10.rtt.Type) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            $serializer.write(this.$T);
            $serializer.write(this.init);
            $serializer.write(this.m);
            $serializer.write(this.n);
            $serializer.write(this.pg);
            
        }
        
        // constructor just for allocation
        public $Closure$14(final java.lang.System[] $dummy, final x10.rtt.Type $T) {
            x10.array.DistArray_Block_2.$Closure$14.$initParams(this, $T);
            
        }
        
        // bridge for method abstract public ()=>U.operator()():U
        public x10.array.LocalState_B2 $apply$G() {
            return $apply();
        }
        
        private x10.rtt.Type $T;
        
        // initializer of type parameters
        public static void $initParams(final $Closure$14 $this, final x10.rtt.Type $T) {
            $this.$T = $T;
            
        }
        // synthetic type for parameter mangling
        public static final class __3$1x10$lang$Long$3x10$lang$Long$3x10$array$DistArray_Block_2$$Closure$14$$T$2 {}
        
    
        
        public x10.array.LocalState_B2 $apply() {
            
            //#line 61 "x10/array/DistArray_Block_2.x10"
            final x10.array.LocalState_B2 t$108996 = x10.array.LocalState_B2.<$T> make__3$1x10$lang$Long$3x10$lang$Long$3x10$array$LocalState_B2$$S$2($T, ((x10.lang.PlaceGroup)(this.pg)), (long)(this.m), (long)(this.n), ((x10.core.fun.Fun_0_2)(this.init)));
            
            //#line 61 "x10/array/DistArray_Block_2.x10"
            return t$108996;
        }
        
        public x10.lang.PlaceGroup pg;
        public long m;
        public long n;
        public x10.core.fun.Fun_0_2<x10.core.Long,x10.core.Long,$T> init;
        
        public $Closure$14(final x10.rtt.Type $T, final x10.lang.PlaceGroup pg, final long m, final long n, final x10.core.fun.Fun_0_2<x10.core.Long,x10.core.Long,$T> init, __3$1x10$lang$Long$3x10$lang$Long$3x10$array$DistArray_Block_2$$Closure$14$$T$2 $dummy) {
            x10.array.DistArray_Block_2.$Closure$14.$initParams(this, $T);
             {
                ((x10.array.DistArray_Block_2.$Closure$14<$T>)this).pg = ((x10.lang.PlaceGroup)(pg));
                ((x10.array.DistArray_Block_2.$Closure$14<$T>)this).m = m;
                ((x10.array.DistArray_Block_2.$Closure$14<$T>)this).n = n;
                ((x10.array.DistArray_Block_2.$Closure$14<$T>)this).init = ((x10.core.fun.Fun_0_2)(init));
            }
        }
        
    }
    
    @x10.runtime.impl.java.X10Generated
    final public static class $Closure$15<$T> extends x10.core.Ref implements x10.core.fun.Fun_0_2, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<$Closure$15> $RTT = 
            x10.rtt.StaticFunType.<$Closure$15> make($Closure$15.class,
                                                     1,
                                                     new x10.rtt.Type[] {
                                                         x10.rtt.ParameterizedType.make(x10.core.fun.Fun_0_2.$RTT, x10.rtt.Types.LONG, x10.rtt.Types.LONG, x10.rtt.UnresolvedType.PARAM(0))
                                                     });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { if (i == 0) return $T; return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static <$T> x10.serialization.X10JavaSerializable $_deserialize_body(x10.array.DistArray_Block_2.$Closure$15<$T> $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            $_obj.$T = (x10.rtt.Type) $deserializer.readObject();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.array.DistArray_Block_2.$Closure$15 $_obj = new x10.array.DistArray_Block_2.$Closure$15((java.lang.System[]) null, (x10.rtt.Type) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            $serializer.write(this.$T);
            
        }
        
        // constructor just for allocation
        public $Closure$15(final java.lang.System[] $dummy, final x10.rtt.Type $T) {
            x10.array.DistArray_Block_2.$Closure$15.$initParams(this, $T);
            
        }
        
        // dispatcher for method abstract public (Z1,Z2)=>U.operator()(a1:Z1, a2:Z2):U
        public java.lang.Object $apply(final java.lang.Object a1, final x10.rtt.Type t1, final java.lang.Object a2, final x10.rtt.Type t2) {
            return $apply$G(x10.core.Long.$unbox(a1), x10.core.Long.$unbox(a2));
            
        }
        
        private x10.rtt.Type $T;
        
        // initializer of type parameters
        public static void $initParams(final $Closure$15 $this, final x10.rtt.Type $T) {
            $this.$T = $T;
            
        }
        
    
        
        public $T $apply$G(final long id$83, final long id$84) {
            
            //#line 94 "x10/array/DistArray_Block_2.x10"
            final $T t$108867 = (($T)(($T) x10.rtt.Types.zeroValue($T)));
            
            //#line 94 "x10/array/DistArray_Block_2.x10"
            return t$108867;
        }
        
        public $Closure$15(final x10.rtt.Type $T) {
            x10.array.DistArray_Block_2.$Closure$15.$initParams(this, $T);
             {
                
            }
        }
        
    }
    
    @x10.runtime.impl.java.X10Generated
    final public static class $Closure$16<$T> extends x10.core.Ref implements x10.core.fun.Fun_0_2, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<$Closure$16> $RTT = 
            x10.rtt.StaticFunType.<$Closure$16> make($Closure$16.class,
                                                     1,
                                                     new x10.rtt.Type[] {
                                                         x10.rtt.ParameterizedType.make(x10.core.fun.Fun_0_2.$RTT, x10.rtt.Types.LONG, x10.rtt.Types.LONG, x10.rtt.UnresolvedType.PARAM(0))
                                                     });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { if (i == 0) return $T; return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static <$T> x10.serialization.X10JavaSerializable $_deserialize_body(x10.array.DistArray_Block_2.$Closure$16<$T> $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            $_obj.$T = (x10.rtt.Type) $deserializer.readObject();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.array.DistArray_Block_2.$Closure$16 $_obj = new x10.array.DistArray_Block_2.$Closure$16((java.lang.System[]) null, (x10.rtt.Type) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            $serializer.write(this.$T);
            
        }
        
        // constructor just for allocation
        public $Closure$16(final java.lang.System[] $dummy, final x10.rtt.Type $T) {
            x10.array.DistArray_Block_2.$Closure$16.$initParams(this, $T);
            
        }
        
        // dispatcher for method abstract public (Z1,Z2)=>U.operator()(a1:Z1, a2:Z2):U
        public java.lang.Object $apply(final java.lang.Object a1, final x10.rtt.Type t1, final java.lang.Object a2, final x10.rtt.Type t2) {
            return $apply$G(x10.core.Long.$unbox(a1), x10.core.Long.$unbox(a2));
            
        }
        
        private x10.rtt.Type $T;
        
        // initializer of type parameters
        public static void $initParams(final $Closure$16 $this, final x10.rtt.Type $T) {
            $this.$T = $T;
            
        }
        
    
        
        public $T $apply$G(final long id$85, final long id$86) {
            
            //#line 107 "x10/array/DistArray_Block_2.x10"
            final $T t$108869 = (($T)(($T) x10.rtt.Types.zeroValue($T)));
            
            //#line 107 "x10/array/DistArray_Block_2.x10"
            return t$108869;
        }
        
        public $Closure$16(final x10.rtt.Type $T) {
            x10.array.DistArray_Block_2.$Closure$16.$initParams(this, $T);
             {
                
            }
        }
        
    }
    
}


