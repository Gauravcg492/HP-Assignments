package x10.array;


/**
 * Implementation of a 3-D DistArray that distributes its data elements
 * over the places in its PlaceGroup in a 2-D blocked fashion.
 */
@x10.runtime.impl.java.X10Generated
public class DistArray_BlockBlock_3<$T> extends x10.array.DistArray<$T> implements x10.core.fun.Fun_0_3, x10.serialization.X10JavaSerializable
{
    public static final x10.rtt.RuntimeType<DistArray_BlockBlock_3> $RTT = 
        x10.rtt.NamedType.<DistArray_BlockBlock_3> make("x10.array.DistArray_BlockBlock_3",
                                                        DistArray_BlockBlock_3.class,
                                                        1,
                                                        new x10.rtt.Type[] {
                                                            x10.rtt.ParameterizedType.make(x10.core.fun.Fun_0_3.$RTT, x10.rtt.Types.LONG, x10.rtt.Types.LONG, x10.rtt.Types.LONG, x10.rtt.UnresolvedType.PARAM(0)),
                                                            x10.rtt.ParameterizedType.make(x10.array.DistArray.$RTT, x10.rtt.UnresolvedType.PARAM(0))
                                                        });
    
    public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
    
    public x10.rtt.Type<?> $getParam(int i) { if (i == 0) return $T; return null; }
    
    private Object writeReplace() throws java.io.ObjectStreamException {
        return new x10.serialization.SerializationProxy(this);
    }
    
    public static <$T> x10.serialization.X10JavaSerializable $_deserialize_body(x10.array.DistArray_BlockBlock_3<$T> $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
        x10.array.DistArray.$_deserialize_body($_obj, $deserializer);
        $_obj.$T = (x10.rtt.Type) $deserializer.readObject();
        $_obj.globalIndices = $deserializer.readObject();
        $_obj.numElems_1 = $deserializer.readLong();
        $_obj.numElems_2 = $deserializer.readLong();
        $_obj.numElems_3 = $deserializer.readLong();
        
        /* fields with @TransientInitExpr annotations */
        $_obj.localIndices = $_obj.reloadLocalIndices();
        $_obj.minIndex_1 = $_obj.reloadMinIndex_1$O();
        $_obj.minIndex_2 = $_obj.reloadMinIndex_2$O();
        $_obj.numElemsLocal_1 = $_obj.reloadNumElemsLocal_1$O();
        $_obj.numElemsLocal_2 = $_obj.reloadNumElemsLocal_2$O();
        
        return $_obj;
    }
    
    public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
        x10.array.DistArray_BlockBlock_3 $_obj = new x10.array.DistArray_BlockBlock_3((java.lang.System[]) null, (x10.rtt.Type) null);
        $deserializer.record_reference($_obj);
        return $_deserialize_body($_obj, $deserializer);
    }
    
    public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
        super.$_serialize($serializer);
        $serializer.write(this.$T);
        $serializer.write(this.globalIndices);
        $serializer.write(this.numElems_1);
        $serializer.write(this.numElems_2);
        $serializer.write(this.numElems_3);
        
    }
    
    // constructor just for allocation
    public DistArray_BlockBlock_3(final java.lang.System[] $dummy, final x10.rtt.Type $T) {
        super($dummy, $T);
        x10.array.DistArray_BlockBlock_3.$initParams(this, $T);
        
    }
    
    // dispatcher for method abstract public (Z1,Z2,Z3)=>U.operator()(a1:Z1, a2:Z2, a3:Z3){}:U
    public java.lang.Object $apply(final java.lang.Object a1, final x10.rtt.Type t1, final java.lang.Object a2, final x10.rtt.Type t2, final java.lang.Object a3, final x10.rtt.Type t3) {
        return $apply$G(x10.core.Long.$unbox(a1), x10.core.Long.$unbox(a2), x10.core.Long.$unbox(a3));
        
    }
    
    // bridge for method abstract public x10.array.DistArray[T].operator()=(p:x10.lang.Point{self.rank==this(:x10.array.DistArray).rank()}, v:T){}:T{self==v}
    final public $T $set__1x10$array$DistArray$$T$G(x10.lang.Point a1, $T a2) {
        return $set__1x10$array$DistArray_BlockBlock_3$$T$G(a1, a2);
    }
    
    private x10.rtt.Type $T;
    
    // initializer of type parameters
    public static void $initParams(final DistArray_BlockBlock_3 $this, final x10.rtt.Type $T) {
        $this.$T = $T;
        
    }
    // synthetic type for parameter mangling
    public static final class __4$1x10$lang$Long$3x10$lang$Long$3x10$lang$Long$3x10$array$DistArray_BlockBlock_3$$T$2 {}
    // synthetic type for parameter mangling
    public static final class __3$1x10$lang$Long$3x10$lang$Long$3x10$lang$Long$3x10$array$DistArray_BlockBlock_3$$T$2 {}
    

    
    
    //#line 25 "x10/array/DistArray_BlockBlock_3.x10"
    final public long rank$O() {
        
        //#line 25 "x10/array/DistArray_BlockBlock_3.x10"
        return 3L;
    }
    
    
    //#line 27 "x10/array/DistArray_BlockBlock_3.x10"
    public x10.array.DenseIterationSpace_3 globalIndices;
    
    //#line 29 "x10/array/DistArray_BlockBlock_3.x10"
    public long numElems_1;
    
    //#line 31 "x10/array/DistArray_BlockBlock_3.x10"
    public long numElems_2;
    
    //#line 33 "x10/array/DistArray_BlockBlock_3.x10"
    public long numElems_3;
    
    //#line 36 "x10/array/DistArray_BlockBlock_3.x10"
    public transient x10.array.DenseIterationSpace_3 localIndices;
    
    
    //#line 37 "x10/array/DistArray_BlockBlock_3.x10"
    final public x10.array.DenseIterationSpace_3 reloadLocalIndices() {
        
        //#line 39 "x10/array/DistArray_BlockBlock_3.x10"
        final x10.lang.PlaceLocalHandle t$107536 = ((x10.lang.PlaceLocalHandle)(this.localHandle));
        
        //#line 39 "x10/array/DistArray_BlockBlock_3.x10"
        final x10.array.LocalState t$107537 = ((x10.lang.PlaceLocalHandle<x10.array.LocalState<$T>>)t$107536).$apply$G();
        
        //#line 39 "x10/array/DistArray_BlockBlock_3.x10"
        final x10.array.LocalState_BB3 ls = x10.rtt.Types.<x10.array.LocalState_BB3<$T>> cast(t$107537,x10.rtt.ParameterizedType.make(x10.array.LocalState_BB3.$RTT, $T));
        
        //#line 40 "x10/array/DistArray_BlockBlock_3.x10"
        final boolean t$107539 = ((ls) != (null));
        
        //#line 40 "x10/array/DistArray_BlockBlock_3.x10"
        x10.array.DenseIterationSpace_3 t$107540 =  null;
        
        //#line 40 "x10/array/DistArray_BlockBlock_3.x10"
        if (t$107539) {
            
            //#line 40 "x10/array/DistArray_BlockBlock_3.x10"
            final x10.array.Dist_BlockBlock_3 t$107538 = ((x10.array.Dist_BlockBlock_3)(((x10.array.LocalState_BB3<$T>)ls).dist));
            
            //#line 40 "x10/array/DistArray_BlockBlock_3.x10"
            t$107540 = ((x10.array.DenseIterationSpace_3)(t$107538.localIndices));
        } else {
            
            //#line 40 "x10/array/DistArray_BlockBlock_3.x10"
            final x10.array.DenseIterationSpace_3 alloc$107315 = ((x10.array.DenseIterationSpace_3)(new x10.array.DenseIterationSpace_3((java.lang.System[]) null)));
            
            //#line 40 "x10/array/DistArray_BlockBlock_3.x10"
            alloc$107315.x10$array$DenseIterationSpace_3$$init$S(((long)(0L)), ((long)(0L)), ((long)(0L)), ((long)(-1L)), ((long)(-1L)), ((long)(-1L)));
            
            //#line 40 "x10/array/DistArray_BlockBlock_3.x10"
            t$107540 = ((x10.array.DenseIterationSpace_3)(alloc$107315));
        }
        
        //#line 40 "x10/array/DistArray_BlockBlock_3.x10"
        return t$107540;
    }
    
    
    //#line 44 "x10/array/DistArray_BlockBlock_3.x10"
    public transient long minIndex_1;
    
    
    //#line 45 "x10/array/DistArray_BlockBlock_3.x10"
    final public long reloadMinIndex_1$O() {
        
        //#line 45 "x10/array/DistArray_BlockBlock_3.x10"
        final x10.array.DenseIterationSpace_3 t$107542 = ((x10.array.DenseIterationSpace_3)(this.localIndices));
        
        //#line 45 "x10/array/DistArray_BlockBlock_3.x10"
        final long t$107543 = t$107542.min$O((long)(0L));
        
        //#line 45 "x10/array/DistArray_BlockBlock_3.x10"
        return t$107543;
    }
    
    
    //#line 48 "x10/array/DistArray_BlockBlock_3.x10"
    public transient long minIndex_2;
    
    
    //#line 49 "x10/array/DistArray_BlockBlock_3.x10"
    final public long reloadMinIndex_2$O() {
        
        //#line 49 "x10/array/DistArray_BlockBlock_3.x10"
        final x10.array.DenseIterationSpace_3 t$107544 = ((x10.array.DenseIterationSpace_3)(this.localIndices));
        
        //#line 49 "x10/array/DistArray_BlockBlock_3.x10"
        final long t$107545 = t$107544.min$O((long)(1L));
        
        //#line 49 "x10/array/DistArray_BlockBlock_3.x10"
        return t$107545;
    }
    
    
    //#line 52 "x10/array/DistArray_BlockBlock_3.x10"
    public transient long numElemsLocal_1;
    
    
    //#line 53 "x10/array/DistArray_BlockBlock_3.x10"
    final public long reloadNumElemsLocal_1$O() {
        
        //#line 53 "x10/array/DistArray_BlockBlock_3.x10"
        final x10.array.DenseIterationSpace_3 t$107546 = ((x10.array.DenseIterationSpace_3)(this.localIndices));
        
        //#line 53 "x10/array/DistArray_BlockBlock_3.x10"
        final long t$107547 = t$107546.max$O((long)(0L));
        
        //#line 53 "x10/array/DistArray_BlockBlock_3.x10"
        final long t$107548 = this.minIndex_1;
        
        //#line 53 "x10/array/DistArray_BlockBlock_3.x10"
        final long t$107549 = ((t$107547) - (((long)(t$107548))));
        
        //#line 53 "x10/array/DistArray_BlockBlock_3.x10"
        final long t$107550 = ((t$107549) + (((long)(1L))));
        
        //#line 53 "x10/array/DistArray_BlockBlock_3.x10"
        return t$107550;
    }
    
    
    //#line 56 "x10/array/DistArray_BlockBlock_3.x10"
    public transient long numElemsLocal_2;
    
    
    //#line 57 "x10/array/DistArray_BlockBlock_3.x10"
    final public long reloadNumElemsLocal_2$O() {
        
        //#line 57 "x10/array/DistArray_BlockBlock_3.x10"
        final x10.array.DenseIterationSpace_3 t$107551 = ((x10.array.DenseIterationSpace_3)(this.localIndices));
        
        //#line 57 "x10/array/DistArray_BlockBlock_3.x10"
        final long t$107552 = t$107551.max$O((long)(1L));
        
        //#line 57 "x10/array/DistArray_BlockBlock_3.x10"
        final long t$107553 = this.minIndex_2;
        
        //#line 57 "x10/array/DistArray_BlockBlock_3.x10"
        final long t$107554 = ((t$107552) - (((long)(t$107553))));
        
        //#line 57 "x10/array/DistArray_BlockBlock_3.x10"
        final long t$107555 = ((t$107554) + (((long)(1L))));
        
        //#line 57 "x10/array/DistArray_BlockBlock_3.x10"
        return t$107555;
    }
    
    
    //#line 70 "x10/array/DistArray_BlockBlock_3.x10"
    /**
     * Construct a m by n by p block-block distributed DistArray
     * whose data is distributed over pg and initialized using
     * the init function.
     *
     * @param m number of elements in the first dimension
     * @param n number of elements in the second dimension
     * @param p number of elements in the third dimension
     * @param pg the PlaceGroup to use to distibute the elements.
     * @param init the element initialization function
     */
    // creation method for java code (1-phase java constructor)
    public DistArray_BlockBlock_3(final x10.rtt.Type $T, final long m, final long n, final long p, final x10.lang.PlaceGroup pg, final x10.core.fun.Fun_0_3<x10.core.Long,x10.core.Long,x10.core.Long,$T> init, __4$1x10$lang$Long$3x10$lang$Long$3x10$lang$Long$3x10$array$DistArray_BlockBlock_3$$T$2 $dummy) {
        this((java.lang.System[]) null, $T);
        x10$array$DistArray_BlockBlock_3$$init$S(m, n, p, pg, init, (x10.array.DistArray_BlockBlock_3.__4$1x10$lang$Long$3x10$lang$Long$3x10$lang$Long$3x10$array$DistArray_BlockBlock_3$$T$2) null);
    }
    
    // constructor for non-virtual call
    final public x10.array.DistArray_BlockBlock_3<$T> x10$array$DistArray_BlockBlock_3$$init$S(final long m, final long n, final long p, final x10.lang.PlaceGroup pg, final x10.core.fun.Fun_0_3<x10.core.Long,x10.core.Long,x10.core.Long,$T> init, __4$1x10$lang$Long$3x10$lang$Long$3x10$lang$Long$3x10$array$DistArray_BlockBlock_3$$T$2 $dummy) {
         {
            
            //#line 71 "x10/array/DistArray_BlockBlock_3.x10"
            final x10.core.fun.Fun_0_0 t$107768 = ((x10.core.fun.Fun_0_0)(new x10.array.DistArray_BlockBlock_3.$Closure$8<$T>($T, pg, m, n, p, init, (x10.array.DistArray_BlockBlock_3.$Closure$8.__4$1x10$lang$Long$3x10$lang$Long$3x10$lang$Long$3x10$array$DistArray_BlockBlock_3$$Closure$8$$T$2) null)));
            
            //#line 278 . "x10/array/DistArray_BlockBlock_3.x10"
            boolean t$107773 = ((m) < (((long)(0L))));
            
            //#line 278 . "x10/array/DistArray_BlockBlock_3.x10"
            if (!(t$107773)) {
                
                //#line 278 . "x10/array/DistArray_BlockBlock_3.x10"
                t$107773 = ((n) < (((long)(0L))));
            }
            
            //#line 278 . "x10/array/DistArray_BlockBlock_3.x10"
            boolean t$107774 = t$107773;
            
            //#line 278 . "x10/array/DistArray_BlockBlock_3.x10"
            if (!(t$107773)) {
                
                //#line 278 . "x10/array/DistArray_BlockBlock_3.x10"
                t$107774 = ((p) < (((long)(0L))));
            }
            
            //#line 278 . "x10/array/DistArray_BlockBlock_3.x10"
            if (t$107774) {
                
                //#line 278 . "x10/array/DistArray_BlockBlock_3.x10"
                x10.array.DistArray.raiseNegativeArraySizeException();
            }
            
            //#line 279 . "x10/array/DistArray_BlockBlock_3.x10"
            final long t$107776 = ((m) * (((long)(n))));
            
            //#line 279 . "x10/array/DistArray_BlockBlock_3.x10"
            final long t$107777 = ((t$107776) * (((long)(p))));
            
            //#line 71 "x10/array/DistArray_BlockBlock_3.x10"
            /*super.*/x10$array$DistArray$$init$S(((x10.lang.PlaceGroup)(pg)), ((x10.core.fun.Fun_0_0)(t$107768)), t$107777, (x10.array.DistArray.__1$1x10$array$LocalState$1x10$array$DistArray$$T$2$2) null);
            
            //#line 70 "x10/array/DistArray_BlockBlock_3.x10"
            
            
            //#line 72 "x10/array/DistArray_BlockBlock_3.x10"
            final x10.array.DenseIterationSpace_3 alloc$107316 = ((x10.array.DenseIterationSpace_3)(new x10.array.DenseIterationSpace_3((java.lang.System[]) null)));
            
            //#line 72 "x10/array/DistArray_BlockBlock_3.x10"
            final long t$107779 = ((m) - (((long)(1L))));
            
            //#line 72 "x10/array/DistArray_BlockBlock_3.x10"
            final long t$107780 = ((n) - (((long)(1L))));
            
            //#line 72 "x10/array/DistArray_BlockBlock_3.x10"
            final long t$107781 = ((p) - (((long)(1L))));
            
            //#line 72 "x10/array/DistArray_BlockBlock_3.x10"
            alloc$107316.x10$array$DenseIterationSpace_3$$init$S(((long)(0L)), ((long)(0L)), ((long)(0L)), t$107779, t$107780, t$107781);
            
            //#line 72 "x10/array/DistArray_BlockBlock_3.x10"
            ((x10.array.DistArray_BlockBlock_3<$T>)this).globalIndices = ((x10.array.DenseIterationSpace_3)(alloc$107316));
            
            //#line 73 "x10/array/DistArray_BlockBlock_3.x10"
            ((x10.array.DistArray_BlockBlock_3<$T>)this).numElems_1 = m;
            
            //#line 74 "x10/array/DistArray_BlockBlock_3.x10"
            ((x10.array.DistArray_BlockBlock_3<$T>)this).numElems_2 = n;
            
            //#line 75 "x10/array/DistArray_BlockBlock_3.x10"
            ((x10.array.DistArray_BlockBlock_3<$T>)this).numElems_3 = p;
            
            //#line 76 "x10/array/DistArray_BlockBlock_3.x10"
            final x10.array.DenseIterationSpace_3 t$107566 = ((x10.array.DenseIterationSpace_3)(this.reloadLocalIndices()));
            
            //#line 76 "x10/array/DistArray_BlockBlock_3.x10"
            ((x10.array.DistArray_BlockBlock_3<$T>)this).localIndices = ((x10.array.DenseIterationSpace_3)(t$107566));
            
            //#line 77 "x10/array/DistArray_BlockBlock_3.x10"
            final x10.array.DistArray_BlockBlock_3 this$107473 = ((x10.array.DistArray_BlockBlock_3)(this));
            
            //#line 45 . "x10/array/DistArray_BlockBlock_3.x10"
            final x10.array.DenseIterationSpace_3 t$107567 = ((x10.array.DenseIterationSpace_3)(((x10.array.DistArray_BlockBlock_3<$T>)this$107473).localIndices));
            
            //#line 45 . "x10/array/DistArray_BlockBlock_3.x10"
            final long t$107568 = t$107567.min$O((long)(0L));
            
            //#line 77 "x10/array/DistArray_BlockBlock_3.x10"
            ((x10.array.DistArray_BlockBlock_3<$T>)this).minIndex_1 = t$107568;
            
            //#line 78 "x10/array/DistArray_BlockBlock_3.x10"
            final x10.array.DistArray_BlockBlock_3 this$107475 = ((x10.array.DistArray_BlockBlock_3)(this));
            
            //#line 49 . "x10/array/DistArray_BlockBlock_3.x10"
            final x10.array.DenseIterationSpace_3 t$107569 = ((x10.array.DenseIterationSpace_3)(((x10.array.DistArray_BlockBlock_3<$T>)this$107475).localIndices));
            
            //#line 49 . "x10/array/DistArray_BlockBlock_3.x10"
            final long t$107570 = t$107569.min$O((long)(1L));
            
            //#line 78 "x10/array/DistArray_BlockBlock_3.x10"
            ((x10.array.DistArray_BlockBlock_3<$T>)this).minIndex_2 = t$107570;
            
            //#line 79 "x10/array/DistArray_BlockBlock_3.x10"
            final long t$107571 = this.reloadNumElemsLocal_1$O();
            
            //#line 79 "x10/array/DistArray_BlockBlock_3.x10"
            ((x10.array.DistArray_BlockBlock_3<$T>)this).numElemsLocal_1 = t$107571;
            
            //#line 80 "x10/array/DistArray_BlockBlock_3.x10"
            final long t$107572 = this.reloadNumElemsLocal_2$O();
            
            //#line 80 "x10/array/DistArray_BlockBlock_3.x10"
            ((x10.array.DistArray_BlockBlock_3<$T>)this).numElemsLocal_2 = t$107572;
        }
        return this;
    }
    
    
    
    //#line 94 "x10/array/DistArray_BlockBlock_3.x10"
    /**
     * Construct a m by n by p block-block distributed DistArray
     * whose data is distributed over Place.places() and 
     * initialized using the provided init closure.
     *
     * @param m number of elements in the first dimension
     * @param n number of elements in the second dimension
     * @param p number of elements in the third dimension
     * @param init the element initialization function
     */
    // creation method for java code (1-phase java constructor)
    public DistArray_BlockBlock_3(final x10.rtt.Type $T, final long m, final long n, final long p, final x10.core.fun.Fun_0_3<x10.core.Long,x10.core.Long,x10.core.Long,$T> init, __3$1x10$lang$Long$3x10$lang$Long$3x10$lang$Long$3x10$array$DistArray_BlockBlock_3$$T$2 $dummy) {
        this((java.lang.System[]) null, $T);
        x10$array$DistArray_BlockBlock_3$$init$S(m, n, p, init, (x10.array.DistArray_BlockBlock_3.__3$1x10$lang$Long$3x10$lang$Long$3x10$lang$Long$3x10$array$DistArray_BlockBlock_3$$T$2) null);
    }
    
    // constructor for non-virtual call
    final public x10.array.DistArray_BlockBlock_3<$T> x10$array$DistArray_BlockBlock_3$$init$S(final long m, final long n, final long p, final x10.core.fun.Fun_0_3<x10.core.Long,x10.core.Long,x10.core.Long,$T> init, __3$1x10$lang$Long$3x10$lang$Long$3x10$lang$Long$3x10$array$DistArray_BlockBlock_3$$T$2 $dummy) {
         {
            
            //#line 95 "x10/array/DistArray_BlockBlock_3.x10"
            final x10.lang.PlaceGroup t$107573 = ((x10.lang.PlaceGroup)(x10.lang.Place.places()));
            
            //#line 95 "x10/array/DistArray_BlockBlock_3.x10"
            /*this.*/x10$array$DistArray_BlockBlock_3$$init$S(((long)(m)), ((long)(n)), ((long)(p)), t$107573, ((x10.core.fun.Fun_0_3)(init)), (x10.array.DistArray_BlockBlock_3.__4$1x10$lang$Long$3x10$lang$Long$3x10$lang$Long$3x10$array$DistArray_BlockBlock_3$$T$2) null);
        }
        return this;
    }
    
    
    
    //#line 108 "x10/array/DistArray_BlockBlock_3.x10"
    /**
     * Construct a m by n by p block-block distributed DistArray
     * whose data is distributed over pg and zero-initialized.
     *
     * @param m number of elements in the first dimension
     * @param n number of elements in the second dimension
     * @param p number of elements in the third dimension
     * @param pg the PlaceGroup to use to distibute the elements.
     */
    // creation method for java code (1-phase java constructor)
    public DistArray_BlockBlock_3(final x10.rtt.Type $T, final long m, final long n, final long p, final x10.lang.PlaceGroup pg) {
        this((java.lang.System[]) null, $T);
        x10$array$DistArray_BlockBlock_3$$init$S(m, n, p, pg);
    }
    
    // constructor for non-virtual call
    final public x10.array.DistArray_BlockBlock_3<$T> x10$array$DistArray_BlockBlock_3$$init$S(final long m, final long n, final long p, final x10.lang.PlaceGroup pg) {
         {
            
            //#line 109 "x10/array/DistArray_BlockBlock_3.x10"
            final x10.core.fun.Fun_0_3 t$107575 = ((x10.core.fun.Fun_0_3)(new x10.array.DistArray_BlockBlock_3.$Closure$9<$T>($T)));
            
            //#line 109 "x10/array/DistArray_BlockBlock_3.x10"
            /*this.*/x10$array$DistArray_BlockBlock_3$$init$S(((long)(m)), ((long)(n)), ((long)(p)), ((x10.lang.PlaceGroup)(pg)), ((x10.core.fun.Fun_0_3)(t$107575)), (x10.array.DistArray_BlockBlock_3.__4$1x10$lang$Long$3x10$lang$Long$3x10$lang$Long$3x10$array$DistArray_BlockBlock_3$$T$2) null);
        }
        return this;
    }
    
    
    
    //#line 122 "x10/array/DistArray_BlockBlock_3.x10"
    /**
     * Construct a m by n by p block-block distributed DistArray
     * whose data is distributed over Place.places() and 
     * zero-initialized.
     *
     * @param m number of elements in the first dimension
     * @param n number of elements in the second dimension
     * @param p number of elements in the third dimension
     */
    // creation method for java code (1-phase java constructor)
    public DistArray_BlockBlock_3(final x10.rtt.Type $T, final long m, final long n, final long p) {
        this((java.lang.System[]) null, $T);
        x10$array$DistArray_BlockBlock_3$$init$S(m, n, p);
    }
    
    // constructor for non-virtual call
    final public x10.array.DistArray_BlockBlock_3<$T> x10$array$DistArray_BlockBlock_3$$init$S(final long m, final long n, final long p) {
         {
            
            //#line 123 "x10/array/DistArray_BlockBlock_3.x10"
            final x10.lang.PlaceGroup t$107577 = ((x10.lang.PlaceGroup)(x10.lang.Place.places()));
            
            //#line 123 "x10/array/DistArray_BlockBlock_3.x10"
            final x10.core.fun.Fun_0_3 t$107578 = ((x10.core.fun.Fun_0_3)(new x10.array.DistArray_BlockBlock_3.$Closure$10<$T>($T)));
            
            //#line 123 "x10/array/DistArray_BlockBlock_3.x10"
            /*this.*/x10$array$DistArray_BlockBlock_3$$init$S(((long)(m)), ((long)(n)), ((long)(p)), t$107577, ((x10.core.fun.Fun_0_3)(t$107578)), (x10.array.DistArray_BlockBlock_3.__4$1x10$lang$Long$3x10$lang$Long$3x10$lang$Long$3x10$array$DistArray_BlockBlock_3$$T$2) null);
        }
        return this;
    }
    
    
    
    //#line 132 "x10/array/DistArray_BlockBlock_3.x10"
    /**
     * Get an IterationSpace that represents all Points contained in
     * the global iteration space (valid indices) of the DistArray.
     * @return an IterationSpace for the DistArray
     */
    final public x10.array.DenseIterationSpace_3 globalIndices() {
        
        //#line 132 "x10/array/DistArray_BlockBlock_3.x10"
        final x10.array.DenseIterationSpace_3 t$107579 = ((x10.array.DenseIterationSpace_3)(this.globalIndices));
        
        //#line 132 "x10/array/DistArray_BlockBlock_3.x10"
        return t$107579;
    }
    
    
    //#line 140 "x10/array/DistArray_BlockBlock_3.x10"
    /**
     * Get an IterationSpace that represents all Points contained in
     * the local iteration space (valid indices) of the DistArray at the current Place.
     * @return an IterationSpace for the local portion of the DistArray
     */
    final public x10.array.DenseIterationSpace_3 localIndices() {
        
        //#line 140 "x10/array/DistArray_BlockBlock_3.x10"
        final x10.array.DenseIterationSpace_3 t$107580 = ((x10.array.DenseIterationSpace_3)(this.localIndices));
        
        //#line 140 "x10/array/DistArray_BlockBlock_3.x10"
        return t$107580;
    }
    
    
    //#line 154 "x10/array/DistArray_BlockBlock_3.x10"
    /**
     * Return the Place which contains the data for the argument
     * index or Place.INVALID_PLACE if the Point is not in the globalIndices
     * of this DistArray
     *
     * @param i the index in the first dimension
     * @param j the index in the second dimension
     * @param k the index in the third dimension
     * @return the Place where (i,j,k) is a valid index in the DistArray; 
     *          will return Place.INVALID_PLACE if (i,j,k) is not contained in globalIndices
     */
    final public x10.lang.Place place(final long i, final long j, final long k) {
        
        //#line 155 "x10/array/DistArray_BlockBlock_3.x10"
        boolean t$107582 = ((k) < (((long)(0L))));
        
        //#line 155 "x10/array/DistArray_BlockBlock_3.x10"
        if (!(t$107582)) {
            
            //#line 155 "x10/array/DistArray_BlockBlock_3.x10"
            final long t$107581 = this.numElems_3;
            
            //#line 155 "x10/array/DistArray_BlockBlock_3.x10"
            t$107582 = ((k) >= (((long)(t$107581))));
        }
        
        //#line 155 "x10/array/DistArray_BlockBlock_3.x10"
        if (t$107582) {
            
            //#line 155 "x10/array/DistArray_BlockBlock_3.x10"
            final x10.lang.Place t$107583 = ((x10.lang.Place)(x10.lang.Place.get$INVALID_PLACE()));
            
            //#line 155 "x10/array/DistArray_BlockBlock_3.x10"
            return t$107583;
        }
        
        //#line 156 "x10/array/DistArray_BlockBlock_3.x10"
        final long t$107585 = this.numElems_1;
        
        //#line 156 "x10/array/DistArray_BlockBlock_3.x10"
        final long t$107587 = ((t$107585) - (((long)(1L))));
        
        //#line 156 "x10/array/DistArray_BlockBlock_3.x10"
        final long t$107586 = this.numElems_2;
        
        //#line 156 "x10/array/DistArray_BlockBlock_3.x10"
        final long t$107588 = ((t$107586) - (((long)(1L))));
        
        //#line 156 "x10/array/DistArray_BlockBlock_3.x10"
        final x10.lang.PlaceGroup this$107477 = ((x10.lang.PlaceGroup)(this.placeGroup));
        
        //#line 35 . "x10/lang/PlaceGroup.x10"
        final long t$107589 = this$107477.numPlaces$O();
        
        //#line 156 "x10/array/DistArray_BlockBlock_3.x10"
        final long tmp = x10.array.BlockingUtils.mapIndexToBlockBlockPartition$O((long)(0L), (long)(0L), (long)(t$107587), (long)(t$107588), (long)(t$107589), (long)(i), (long)(j));
        
        //#line 157 "x10/array/DistArray_BlockBlock_3.x10"
        final boolean t$107591 = ((long) tmp) == ((long) -1L);
        
        //#line 157 "x10/array/DistArray_BlockBlock_3.x10"
        x10.lang.Place t$107592 =  null;
        
        //#line 157 "x10/array/DistArray_BlockBlock_3.x10"
        if (t$107591) {
            
            //#line 157 "x10/array/DistArray_BlockBlock_3.x10"
            t$107592 = x10.lang.Place.get$INVALID_PLACE();
        } else {
            
            //#line 157 "x10/array/DistArray_BlockBlock_3.x10"
            final x10.lang.PlaceGroup t$107590 = ((x10.lang.PlaceGroup)(this.placeGroup));
            
            //#line 157 "x10/array/DistArray_BlockBlock_3.x10"
            t$107592 = t$107590.$apply((long)(tmp));
        }
        
        //#line 157 "x10/array/DistArray_BlockBlock_3.x10"
        return t$107592;
    }
    
    
    //#line 170 "x10/array/DistArray_BlockBlock_3.x10"
    /**
     * Return the Place which contains the data for the argument
     * Point or Place.INVALID_PLACE if the Point is not in the globalIndices
     * of this DistArray
     *
     * @param p the Point to lookup
     * @return the Place where p is a valid index in the DistArray; 
     *          will return Place.INVALID_PLACE if p is not contained in globalIndices
     */
    final public x10.lang.Place place(final x10.lang.Point p) {
        
        //#line 170 "x10/array/DistArray_BlockBlock_3.x10"
        final long t$107594 = p.$apply$O((long)(0L));
        
        //#line 170 "x10/array/DistArray_BlockBlock_3.x10"
        final long t$107595 = p.$apply$O((long)(1L));
        
        //#line 170 "x10/array/DistArray_BlockBlock_3.x10"
        final long t$107596 = p.$apply$O((long)(2L));
        
        //#line 170 "x10/array/DistArray_BlockBlock_3.x10"
        final x10.lang.Place t$107597 = this.place((long)(t$107594), (long)(t$107595), (long)(t$107596));
        
        //#line 170 "x10/array/DistArray_BlockBlock_3.x10"
        return t$107597;
    }
    
    
    //#line 182 "x10/array/DistArray_BlockBlock_3.x10"
    /**
     * Return the element of this array corresponding to the given index.
     * 
     * @param i the given index in the first dimension
     * @param j the given index in the second dimension
     * @param k the given index in the third dimension
     * @return the element of this array corresponding to the given index.
     * @see #set(T, Long, Long, Long)
     */
    final public $T $apply$G(final long i, final long j, final long k) {
        
        //#line 183 "x10/array/DistArray_BlockBlock_3.x10"
        this.validateIndex((long)(i), (long)(j), (long)(k));
        
        //#line 184 "x10/array/DistArray_BlockBlock_3.x10"
        final x10.core.Rail r$107484 = ((x10.core.Rail)(this.raw));
        
        //#line 184 "x10/array/DistArray_BlockBlock_3.x10"
        final x10.array.DistArray_BlockBlock_3 this$107482 = ((x10.array.DistArray_BlockBlock_3)(this));
        
        //#line 248 . "x10/array/DistArray_BlockBlock_3.x10"
        final long t$107604 = ((x10.array.DistArray_BlockBlock_3<$T>)this$107482).numElems_3;
        
        //#line 248 . "x10/array/DistArray_BlockBlock_3.x10"
        final long t$107598 = ((x10.array.DistArray_BlockBlock_3<$T>)this$107482).minIndex_2;
        
        //#line 248 . "x10/array/DistArray_BlockBlock_3.x10"
        final long t$107602 = ((j) - (((long)(t$107598))));
        
        //#line 248 . "x10/array/DistArray_BlockBlock_3.x10"
        final long t$107600 = ((x10.array.DistArray_BlockBlock_3<$T>)this$107482).numElemsLocal_2;
        
        //#line 248 . "x10/array/DistArray_BlockBlock_3.x10"
        final long t$107599 = ((x10.array.DistArray_BlockBlock_3<$T>)this$107482).minIndex_1;
        
        //#line 248 . "x10/array/DistArray_BlockBlock_3.x10"
        final long t$107601 = ((i) - (((long)(t$107599))));
        
        //#line 248 . "x10/array/DistArray_BlockBlock_3.x10"
        final long t$107603 = ((t$107600) * (((long)(t$107601))));
        
        //#line 248 . "x10/array/DistArray_BlockBlock_3.x10"
        final long t$107605 = ((t$107602) + (((long)(t$107603))));
        
        //#line 248 . "x10/array/DistArray_BlockBlock_3.x10"
        final long t$107606 = ((t$107604) * (((long)(t$107605))));
        
        //#line 184 "x10/array/DistArray_BlockBlock_3.x10"
        final long i$107485 = ((k) + (((long)(t$107606))));
        
        //#line 38 . "x10/lang/Unsafe.x10"
        final $T t$107607 = (($T)(((x10.core.Rail<$T>)r$107484).$apply$G((long)(i$107485))));
        
        //#line 184 "x10/array/DistArray_BlockBlock_3.x10"
        return t$107607;
    }
    
    
    //#line 195 "x10/array/DistArray_BlockBlock_3.x10"
    /**
     * Return the element of this array corresponding to the given Point.
     * 
     * @param p the given Point
     * @return the element of this array corresponding to the given Point.
     * @see #set(T, Point)
     */
    final public $T $apply$G(final x10.lang.Point p) {
        
        //#line 195 "x10/array/DistArray_BlockBlock_3.x10"
        final x10.array.DistArray_BlockBlock_3 this$107490 = ((x10.array.DistArray_BlockBlock_3)(this));
        
        //#line 195 "x10/array/DistArray_BlockBlock_3.x10"
        final long i$107487 = p.$apply$O((long)(0L));
        
        //#line 195 "x10/array/DistArray_BlockBlock_3.x10"
        final long j$107488 = p.$apply$O((long)(1L));
        
        //#line 195 "x10/array/DistArray_BlockBlock_3.x10"
        final long k$107489 = p.$apply$O((long)(2L));
        
        //#line 183 . "x10/array/DistArray_BlockBlock_3.x10"
        ((x10.array.DistArray_BlockBlock_3<$T>)this$107490).validateIndex((long)(i$107487), (long)(j$107488), (long)(k$107489));
        
        //#line 184 . "x10/array/DistArray_BlockBlock_3.x10"
        final x10.core.Rail r$107496 = ((x10.core.Rail)(((x10.array.DistArray<$T>)this$107490).raw));
        
        //#line 248 .. "x10/array/DistArray_BlockBlock_3.x10"
        final long t$107614 = ((x10.array.DistArray_BlockBlock_3<$T>)this$107490).numElems_3;
        
        //#line 248 .. "x10/array/DistArray_BlockBlock_3.x10"
        final long t$107608 = ((x10.array.DistArray_BlockBlock_3<$T>)this$107490).minIndex_2;
        
        //#line 248 .. "x10/array/DistArray_BlockBlock_3.x10"
        final long t$107612 = ((j$107488) - (((long)(t$107608))));
        
        //#line 248 .. "x10/array/DistArray_BlockBlock_3.x10"
        final long t$107610 = ((x10.array.DistArray_BlockBlock_3<$T>)this$107490).numElemsLocal_2;
        
        //#line 248 .. "x10/array/DistArray_BlockBlock_3.x10"
        final long t$107609 = ((x10.array.DistArray_BlockBlock_3<$T>)this$107490).minIndex_1;
        
        //#line 248 .. "x10/array/DistArray_BlockBlock_3.x10"
        final long t$107611 = ((i$107487) - (((long)(t$107609))));
        
        //#line 248 .. "x10/array/DistArray_BlockBlock_3.x10"
        final long t$107613 = ((t$107610) * (((long)(t$107611))));
        
        //#line 248 .. "x10/array/DistArray_BlockBlock_3.x10"
        final long t$107615 = ((t$107612) + (((long)(t$107613))));
        
        //#line 248 .. "x10/array/DistArray_BlockBlock_3.x10"
        final long t$107616 = ((t$107614) * (((long)(t$107615))));
        
        //#line 184 . "x10/array/DistArray_BlockBlock_3.x10"
        final long i$107497 = ((k$107489) + (((long)(t$107616))));
        
        //#line 38 .. "x10/lang/Unsafe.x10"
        final $T t$107617 = (($T)(((x10.core.Rail<$T>)r$107496).$apply$G((long)(i$107497))));
        
        //#line 195 "x10/array/DistArray_BlockBlock_3.x10"
        return t$107617;
    }
    
    
    //#line 209 "x10/array/DistArray_BlockBlock_3.x10"
    /**
     * Set the element of this array corresponding to the given index to the given value.
     * Return the new value of the element.
     * 
     * @param v the given value
     * @param i the given index in the first dimension
     * @param j the given index in the second dimension
     * @param k the given index in the third dimension
     * @return the new value of the element of this array corresponding to the given index.
     * @see #operator(Long, Long, Long)
     */
    final public $T $set__3x10$array$DistArray_BlockBlock_3$$T$G(final long i, final long j, final long k, final $T v) {
        
        //#line 210 "x10/array/DistArray_BlockBlock_3.x10"
        this.validateIndex((long)(i), (long)(j), (long)(k));
        
        //#line 211 "x10/array/DistArray_BlockBlock_3.x10"
        final x10.core.Rail r$107504 = ((x10.core.Rail)(this.raw));
        
        //#line 211 "x10/array/DistArray_BlockBlock_3.x10"
        final x10.array.DistArray_BlockBlock_3 this$107502 = ((x10.array.DistArray_BlockBlock_3)(this));
        
        //#line 248 . "x10/array/DistArray_BlockBlock_3.x10"
        final long t$107624 = ((x10.array.DistArray_BlockBlock_3<$T>)this$107502).numElems_3;
        
        //#line 248 . "x10/array/DistArray_BlockBlock_3.x10"
        final long t$107618 = ((x10.array.DistArray_BlockBlock_3<$T>)this$107502).minIndex_2;
        
        //#line 248 . "x10/array/DistArray_BlockBlock_3.x10"
        final long t$107622 = ((j) - (((long)(t$107618))));
        
        //#line 248 . "x10/array/DistArray_BlockBlock_3.x10"
        final long t$107620 = ((x10.array.DistArray_BlockBlock_3<$T>)this$107502).numElemsLocal_2;
        
        //#line 248 . "x10/array/DistArray_BlockBlock_3.x10"
        final long t$107619 = ((x10.array.DistArray_BlockBlock_3<$T>)this$107502).minIndex_1;
        
        //#line 248 . "x10/array/DistArray_BlockBlock_3.x10"
        final long t$107621 = ((i) - (((long)(t$107619))));
        
        //#line 248 . "x10/array/DistArray_BlockBlock_3.x10"
        final long t$107623 = ((t$107620) * (((long)(t$107621))));
        
        //#line 248 . "x10/array/DistArray_BlockBlock_3.x10"
        final long t$107625 = ((t$107622) + (((long)(t$107623))));
        
        //#line 248 . "x10/array/DistArray_BlockBlock_3.x10"
        final long t$107626 = ((t$107624) * (((long)(t$107625))));
        
        //#line 211 "x10/array/DistArray_BlockBlock_3.x10"
        final long i$107505 = ((k) + (((long)(t$107626))));
        
        //#line 42 . "x10/lang/Unsafe.x10"
        ((x10.core.Rail<$T>)r$107504).$set__1x10$lang$Rail$$T$G((long)(i$107505), (($T)(v)));
        
        //#line 211 "x10/array/DistArray_BlockBlock_3.x10"
        return (($T)
                 v);
    }
    
    
    //#line 224 "x10/array/DistArray_BlockBlock_3.x10"
    /**
     * Set the element of this array corresponding to the given Point to the given value.
     * Return the new value of the element.
     * 
     * @param v the given value
     * @param p the given Point
     * @return the new value of the element of this array corresponding to the given Point.
     * @see #operator(Point)
     */
    final public $T $set__1x10$array$DistArray_BlockBlock_3$$T$G(final x10.lang.Point p, final $T v) {
        
        //#line 224 "x10/array/DistArray_BlockBlock_3.x10"
        final x10.array.DistArray_BlockBlock_3 this$107512 = ((x10.array.DistArray_BlockBlock_3)(this));
        
        //#line 224 "x10/array/DistArray_BlockBlock_3.x10"
        final long i$107508 = p.$apply$O((long)(0L));
        
        //#line 224 "x10/array/DistArray_BlockBlock_3.x10"
        final long j$107509 = p.$apply$O((long)(1L));
        
        //#line 224 "x10/array/DistArray_BlockBlock_3.x10"
        final long k$107510 = p.$apply$O((long)(2L));
        
        //#line 210 . "x10/array/DistArray_BlockBlock_3.x10"
        ((x10.array.DistArray_BlockBlock_3<$T>)this$107512).validateIndex((long)(i$107508), (long)(j$107509), (long)(k$107510));
        
        //#line 211 . "x10/array/DistArray_BlockBlock_3.x10"
        final x10.core.Rail r$107518 = ((x10.core.Rail)(((x10.array.DistArray<$T>)this$107512).raw));
        
        //#line 248 .. "x10/array/DistArray_BlockBlock_3.x10"
        final long t$107633 = ((x10.array.DistArray_BlockBlock_3<$T>)this$107512).numElems_3;
        
        //#line 248 .. "x10/array/DistArray_BlockBlock_3.x10"
        final long t$107627 = ((x10.array.DistArray_BlockBlock_3<$T>)this$107512).minIndex_2;
        
        //#line 248 .. "x10/array/DistArray_BlockBlock_3.x10"
        final long t$107631 = ((j$107509) - (((long)(t$107627))));
        
        //#line 248 .. "x10/array/DistArray_BlockBlock_3.x10"
        final long t$107629 = ((x10.array.DistArray_BlockBlock_3<$T>)this$107512).numElemsLocal_2;
        
        //#line 248 .. "x10/array/DistArray_BlockBlock_3.x10"
        final long t$107628 = ((x10.array.DistArray_BlockBlock_3<$T>)this$107512).minIndex_1;
        
        //#line 248 .. "x10/array/DistArray_BlockBlock_3.x10"
        final long t$107630 = ((i$107508) - (((long)(t$107628))));
        
        //#line 248 .. "x10/array/DistArray_BlockBlock_3.x10"
        final long t$107632 = ((t$107629) * (((long)(t$107630))));
        
        //#line 248 .. "x10/array/DistArray_BlockBlock_3.x10"
        final long t$107634 = ((t$107631) + (((long)(t$107632))));
        
        //#line 248 .. "x10/array/DistArray_BlockBlock_3.x10"
        final long t$107635 = ((t$107633) * (((long)(t$107634))));
        
        //#line 211 . "x10/array/DistArray_BlockBlock_3.x10"
        final long i$107519 = ((k$107510) + (((long)(t$107635))));
        
        //#line 42 .. "x10/lang/Unsafe.x10"
        ((x10.core.Rail<$T>)r$107518).$set__1x10$lang$Rail$$T$G((long)(i$107519), (($T)(v)));
        
        //#line 224 "x10/array/DistArray_BlockBlock_3.x10"
        return (($T)
                 v);
    }
    
    
    //#line 232 "x10/array/DistArray_BlockBlock_3.x10"
    final public void validateIndex(final long i, final long j, final long k) {
        
        //#line 234 "x10/array/DistArray_BlockBlock_3.x10"
        boolean t$107637 = ((k) < (((long)(0L))));
        
        //#line 234 "x10/array/DistArray_BlockBlock_3.x10"
        if (!(t$107637)) {
            
            //#line 234 "x10/array/DistArray_BlockBlock_3.x10"
            final long t$107636 = this.numElems_3;
            
            //#line 234 "x10/array/DistArray_BlockBlock_3.x10"
            t$107637 = ((k) >= (((long)(t$107636))));
        }
        
        //#line 234 "x10/array/DistArray_BlockBlock_3.x10"
        if (t$107637) {
            
            //#line 235 "x10/array/DistArray_BlockBlock_3.x10"
            x10.array.DistArray.raiseBoundsError((long)(i), (long)(j), (long)(k));
        }
        
        //#line 237 "x10/array/DistArray_BlockBlock_3.x10"
        final long t$107639 = this.minIndex_1;
        
        //#line 237 "x10/array/DistArray_BlockBlock_3.x10"
        boolean t$107643 = ((i) < (((long)(t$107639))));
        
        //#line 237 "x10/array/DistArray_BlockBlock_3.x10"
        if (!(t$107643)) {
            
            //#line 237 "x10/array/DistArray_BlockBlock_3.x10"
            final long t$107640 = this.minIndex_1;
            
            //#line 237 "x10/array/DistArray_BlockBlock_3.x10"
            final long t$107641 = this.numElemsLocal_1;
            
            //#line 237 "x10/array/DistArray_BlockBlock_3.x10"
            final long t$107642 = ((t$107640) + (((long)(t$107641))));
            
            //#line 237 "x10/array/DistArray_BlockBlock_3.x10"
            t$107643 = ((i) >= (((long)(t$107642))));
        }
        
        //#line 237 "x10/array/DistArray_BlockBlock_3.x10"
        boolean t$107645 = t$107643;
        
        //#line 237 "x10/array/DistArray_BlockBlock_3.x10"
        if (!(t$107643)) {
            
            //#line 238 "x10/array/DistArray_BlockBlock_3.x10"
            final long t$107644 = this.minIndex_2;
            
            //#line 237 "x10/array/DistArray_BlockBlock_3.x10"
            t$107645 = ((j) < (((long)(t$107644))));
        }
        
        //#line 237 "x10/array/DistArray_BlockBlock_3.x10"
        boolean t$107649 = t$107645;
        
        //#line 237 "x10/array/DistArray_BlockBlock_3.x10"
        if (!(t$107645)) {
            
            //#line 238 "x10/array/DistArray_BlockBlock_3.x10"
            final long t$107646 = this.minIndex_2;
            
            //#line 238 "x10/array/DistArray_BlockBlock_3.x10"
            final long t$107647 = this.numElemsLocal_2;
            
            //#line 238 "x10/array/DistArray_BlockBlock_3.x10"
            final long t$107648 = ((t$107646) + (((long)(t$107647))));
            
            //#line 237 "x10/array/DistArray_BlockBlock_3.x10"
            t$107649 = ((j) >= (((long)(t$107648))));
        }
        
        //#line 237 "x10/array/DistArray_BlockBlock_3.x10"
        if (t$107649) {
            
            //#line 239 "x10/array/DistArray_BlockBlock_3.x10"
            boolean t$107651 = ((i) < (((long)(0L))));
            
            //#line 239 "x10/array/DistArray_BlockBlock_3.x10"
            if (!(t$107651)) {
                
                //#line 239 "x10/array/DistArray_BlockBlock_3.x10"
                final long t$107650 = this.numElems_1;
                
                //#line 239 "x10/array/DistArray_BlockBlock_3.x10"
                t$107651 = ((i) >= (((long)(t$107650))));
            }
            
            //#line 239 "x10/array/DistArray_BlockBlock_3.x10"
            boolean t$107652 = t$107651;
            
            //#line 239 "x10/array/DistArray_BlockBlock_3.x10"
            if (!(t$107651)) {
                
                //#line 239 "x10/array/DistArray_BlockBlock_3.x10"
                t$107652 = ((j) < (((long)(0L))));
            }
            
            //#line 239 "x10/array/DistArray_BlockBlock_3.x10"
            boolean t$107654 = t$107652;
            
            //#line 239 "x10/array/DistArray_BlockBlock_3.x10"
            if (!(t$107652)) {
                
                //#line 239 "x10/array/DistArray_BlockBlock_3.x10"
                final long t$107653 = this.numElems_2;
                
                //#line 239 "x10/array/DistArray_BlockBlock_3.x10"
                t$107654 = ((j) >= (((long)(t$107653))));
            }
            
            //#line 239 "x10/array/DistArray_BlockBlock_3.x10"
            if (t$107654) {
                
                //#line 240 "x10/array/DistArray_BlockBlock_3.x10"
                x10.array.DistArray.raiseBoundsError((long)(i), (long)(j), (long)(k));
            }
            
            //#line 242 "x10/array/DistArray_BlockBlock_3.x10"
            x10.array.DistArray.raisePlaceError((long)(i), (long)(j), (long)(k));
        }
    }
    
    
    //#line 247 "x10/array/DistArray_BlockBlock_3.x10"
    final public long offset$O(final long i, final long j, final long k) {
        
        //#line 248 "x10/array/DistArray_BlockBlock_3.x10"
        final long t$107663 = this.numElems_3;
        
        //#line 248 "x10/array/DistArray_BlockBlock_3.x10"
        final long t$107657 = this.minIndex_2;
        
        //#line 248 "x10/array/DistArray_BlockBlock_3.x10"
        final long t$107661 = ((j) - (((long)(t$107657))));
        
        //#line 248 "x10/array/DistArray_BlockBlock_3.x10"
        final long t$107659 = this.numElemsLocal_2;
        
        //#line 248 "x10/array/DistArray_BlockBlock_3.x10"
        final long t$107658 = this.minIndex_1;
        
        //#line 248 "x10/array/DistArray_BlockBlock_3.x10"
        final long t$107660 = ((i) - (((long)(t$107658))));
        
        //#line 248 "x10/array/DistArray_BlockBlock_3.x10"
        final long t$107662 = ((t$107659) * (((long)(t$107660))));
        
        //#line 248 "x10/array/DistArray_BlockBlock_3.x10"
        final long t$107664 = ((t$107661) + (((long)(t$107662))));
        
        //#line 248 "x10/array/DistArray_BlockBlock_3.x10"
        final long t$107665 = ((t$107663) * (((long)(t$107664))));
        
        //#line 248 "x10/array/DistArray_BlockBlock_3.x10"
        final long t$107666 = ((k) + (((long)(t$107665))));
        
        //#line 248 "x10/array/DistArray_BlockBlock_3.x10"
        return t$107666;
    }
    
    
    //#line 259 "x10/array/DistArray_BlockBlock_3.x10"
    /**
     * Returns the specified rectangular patch of this array as a Rail.
     * 
     * @param space the IterationSpace representing the portion of this array to copy
     * @see offset
     * @throws ArrayIndexOutOfBoundsException if the specified region is not
     *        contained in this array
     */
    public x10.core.Rail getPatch(final x10.array.IterationSpace space) {
        
        //#line 260 "x10/array/DistArray_BlockBlock_3.x10"
        final x10.array.DenseIterationSpace_3 r = ((x10.array.DenseIterationSpace_3)(x10.rtt.Types.<x10.array.DenseIterationSpace_3> cast(space,x10.array.DenseIterationSpace_3.$RTT)));
        
        //#line 263 "x10/array/DistArray_BlockBlock_3.x10"
        final x10.array.DenseIterationSpace_3 t$107667 = ((x10.array.DenseIterationSpace_3)(this.localIndices));
        
        //#line 263 "x10/array/DistArray_BlockBlock_3.x10"
        final long t$107668 = t$107667.min0;
        
        //#line 263 "x10/array/DistArray_BlockBlock_3.x10"
        final long t$107669 = r.min0;
        
        //#line 263 "x10/array/DistArray_BlockBlock_3.x10"
        boolean t$107673 = ((t$107668) <= (((long)(t$107669))));
        
        //#line 263 "x10/array/DistArray_BlockBlock_3.x10"
        if (t$107673) {
            
            //#line 263 "x10/array/DistArray_BlockBlock_3.x10"
            final long t$107671 = r.max0;
            
            //#line 263 "x10/array/DistArray_BlockBlock_3.x10"
            final x10.array.DenseIterationSpace_3 t$107670 = ((x10.array.DenseIterationSpace_3)(this.localIndices));
            
            //#line 263 "x10/array/DistArray_BlockBlock_3.x10"
            final long t$107672 = t$107670.max0;
            
            //#line 263 "x10/array/DistArray_BlockBlock_3.x10"
            t$107673 = ((t$107671) <= (((long)(t$107672))));
        }
        
        //#line 263 "x10/array/DistArray_BlockBlock_3.x10"
        boolean t$107677 = t$107673;
        
        //#line 263 "x10/array/DistArray_BlockBlock_3.x10"
        if (t$107673) {
            
            //#line 264 "x10/array/DistArray_BlockBlock_3.x10"
            final x10.array.DenseIterationSpace_3 t$107674 = ((x10.array.DenseIterationSpace_3)(this.localIndices));
            
            //#line 264 "x10/array/DistArray_BlockBlock_3.x10"
            final long t$107675 = t$107674.min1;
            
            //#line 264 "x10/array/DistArray_BlockBlock_3.x10"
            final long t$107676 = r.min1;
            
            //#line 263 "x10/array/DistArray_BlockBlock_3.x10"
            t$107677 = ((t$107675) <= (((long)(t$107676))));
        }
        
        //#line 263 "x10/array/DistArray_BlockBlock_3.x10"
        boolean t$107681 = t$107677;
        
        //#line 263 "x10/array/DistArray_BlockBlock_3.x10"
        if (t$107677) {
            
            //#line 264 "x10/array/DistArray_BlockBlock_3.x10"
            final long t$107679 = r.max1;
            
            //#line 264 "x10/array/DistArray_BlockBlock_3.x10"
            final x10.array.DenseIterationSpace_3 t$107678 = ((x10.array.DenseIterationSpace_3)(this.localIndices));
            
            //#line 264 "x10/array/DistArray_BlockBlock_3.x10"
            final long t$107680 = t$107678.max1;
            
            //#line 263 "x10/array/DistArray_BlockBlock_3.x10"
            t$107681 = ((t$107679) <= (((long)(t$107680))));
        }
        
        //#line 263 "x10/array/DistArray_BlockBlock_3.x10"
        boolean t$107685 = t$107681;
        
        //#line 263 "x10/array/DistArray_BlockBlock_3.x10"
        if (t$107681) {
            
            //#line 265 "x10/array/DistArray_BlockBlock_3.x10"
            final x10.array.DenseIterationSpace_3 t$107682 = ((x10.array.DenseIterationSpace_3)(this.localIndices));
            
            //#line 265 "x10/array/DistArray_BlockBlock_3.x10"
            final long t$107683 = t$107682.min2;
            
            //#line 265 "x10/array/DistArray_BlockBlock_3.x10"
            final long t$107684 = r.min2;
            
            //#line 263 "x10/array/DistArray_BlockBlock_3.x10"
            t$107685 = ((t$107683) <= (((long)(t$107684))));
        }
        
        //#line 263 "x10/array/DistArray_BlockBlock_3.x10"
        boolean t$107689 = t$107685;
        
        //#line 263 "x10/array/DistArray_BlockBlock_3.x10"
        if (t$107685) {
            
            //#line 265 "x10/array/DistArray_BlockBlock_3.x10"
            final long t$107687 = r.max2;
            
            //#line 265 "x10/array/DistArray_BlockBlock_3.x10"
            final x10.array.DenseIterationSpace_3 t$107686 = ((x10.array.DenseIterationSpace_3)(this.localIndices));
            
            //#line 265 "x10/array/DistArray_BlockBlock_3.x10"
            final long t$107688 = t$107686.max2;
            
            //#line 263 "x10/array/DistArray_BlockBlock_3.x10"
            t$107689 = ((t$107687) <= (((long)(t$107688))));
        }
        
        //#line 263 "x10/array/DistArray_BlockBlock_3.x10"
        final boolean t$107696 = !(t$107689);
        
        //#line 262 "x10/array/DistArray_BlockBlock_3.x10"
        if (t$107696) {
            
            //#line 266 "x10/array/DistArray_BlockBlock_3.x10"
            final java.lang.String t$107691 = (("patch to copy: ") + (r));
            
            //#line 266 "x10/array/DistArray_BlockBlock_3.x10"
            final java.lang.String t$107692 = ((t$107691) + (" not contained in local indices: "));
            
            //#line 266 "x10/array/DistArray_BlockBlock_3.x10"
            final x10.array.DenseIterationSpace_3 t$107693 = ((x10.array.DenseIterationSpace_3)(this.localIndices));
            
            //#line 266 "x10/array/DistArray_BlockBlock_3.x10"
            final java.lang.String t$107694 = ((t$107692) + (t$107693));
            
            //#line 266 "x10/array/DistArray_BlockBlock_3.x10"
            final java.lang.ArrayIndexOutOfBoundsException t$107695 = ((java.lang.ArrayIndexOutOfBoundsException)(new java.lang.ArrayIndexOutOfBoundsException(t$107694)));
            
            //#line 266 "x10/array/DistArray_BlockBlock_3.x10"
            throw t$107695;
        }
        
        //#line 269 "x10/array/DistArray_BlockBlock_3.x10"
        final long t$107697 = r.size$O();
        
        //#line 269 "x10/array/DistArray_BlockBlock_3.x10"
        final x10.core.Rail patch = ((x10.core.Rail)(x10.core.Rail.<$T>makeUnsafe($T, ((long)(t$107697)), false)));
        
        //#line 270 "x10/array/DistArray_BlockBlock_3.x10"
        long patchIndex = 0L;
        
        //#line 271 "x10/array/DistArray_BlockBlock_3.x10"
        final long i2$107320min$107820 = r.min$O((long)(2L));
        
        //#line 271 "x10/array/DistArray_BlockBlock_3.x10"
        final long i2$107320max$107821 = r.max$O((long)(2L));
        
        //#line 271 "x10/array/DistArray_BlockBlock_3.x10"
        final long i1$107351min$107822 = r.min$O((long)(1L));
        
        //#line 271 "x10/array/DistArray_BlockBlock_3.x10"
        final long i1$107351max$107823 = r.max$O((long)(1L));
        
        //#line 271 "x10/array/DistArray_BlockBlock_3.x10"
        final long i0$107382min$107824 = r.min$O((long)(0L));
        
        //#line 271 "x10/array/DistArray_BlockBlock_3.x10"
        final long i0$107382max$107825 = r.max$O((long)(0L));
        
        //#line 271 "x10/array/DistArray_BlockBlock_3.x10"
        long i$107816 = i0$107382min$107824;
        
        //#line 271 "x10/array/DistArray_BlockBlock_3.x10"
        for (;
             true;
             ) {
            
            //#line 271 "x10/array/DistArray_BlockBlock_3.x10"
            final boolean t$107818 = ((i$107816) <= (((long)(i0$107382max$107825))));
            
            //#line 271 "x10/array/DistArray_BlockBlock_3.x10"
            if (!(t$107818)) {
                
                //#line 271 "x10/array/DistArray_BlockBlock_3.x10"
                break;
            }
            
            //#line 271 "x10/array/DistArray_BlockBlock_3.x10"
            long i$107810 = i1$107351min$107822;
            
            //#line 271 "x10/array/DistArray_BlockBlock_3.x10"
            for (;
                 true;
                 ) {
                
                //#line 271 "x10/array/DistArray_BlockBlock_3.x10"
                final boolean t$107812 = ((i$107810) <= (((long)(i1$107351max$107823))));
                
                //#line 271 "x10/array/DistArray_BlockBlock_3.x10"
                if (!(t$107812)) {
                    
                    //#line 271 "x10/array/DistArray_BlockBlock_3.x10"
                    break;
                }
                
                //#line 271 "x10/array/DistArray_BlockBlock_3.x10"
                long i$107804 = i2$107320min$107820;
                
                //#line 271 "x10/array/DistArray_BlockBlock_3.x10"
                for (;
                     true;
                     ) {
                    
                    //#line 271 "x10/array/DistArray_BlockBlock_3.x10"
                    final boolean t$107806 = ((i$107804) <= (((long)(i2$107320max$107821))));
                    
                    //#line 271 "x10/array/DistArray_BlockBlock_3.x10"
                    if (!(t$107806)) {
                        
                        //#line 271 "x10/array/DistArray_BlockBlock_3.x10"
                        break;
                    }
                    
                    //#line 272 "x10/array/DistArray_BlockBlock_3.x10"
                    final long pre$107782 = patchIndex;
                    
                    //#line 272 "x10/array/DistArray_BlockBlock_3.x10"
                    final long t$107784 = ((patchIndex) + (((long)(1L))));
                    
                    //#line 272 "x10/array/DistArray_BlockBlock_3.x10"
                    patchIndex = t$107784;
                    
                    //#line 272 "x10/array/DistArray_BlockBlock_3.x10"
                    final x10.core.Rail t$107785 = ((x10.core.Rail)(this.raw));
                    
                    //#line 272 "x10/array/DistArray_BlockBlock_3.x10"
                    final x10.array.DistArray_BlockBlock_3 this$107786 = ((x10.array.DistArray_BlockBlock_3)(this));
                    
                    //#line 248 . "x10/array/DistArray_BlockBlock_3.x10"
                    final long t$107790 = ((x10.array.DistArray_BlockBlock_3<$T>)this$107786).numElems_3;
                    
                    //#line 248 . "x10/array/DistArray_BlockBlock_3.x10"
                    final long t$107791 = ((x10.array.DistArray_BlockBlock_3<$T>)this$107786).minIndex_2;
                    
                    //#line 248 . "x10/array/DistArray_BlockBlock_3.x10"
                    final long t$107792 = ((i$107810) - (((long)(t$107791))));
                    
                    //#line 248 . "x10/array/DistArray_BlockBlock_3.x10"
                    final long t$107793 = ((x10.array.DistArray_BlockBlock_3<$T>)this$107786).numElemsLocal_2;
                    
                    //#line 248 . "x10/array/DistArray_BlockBlock_3.x10"
                    final long t$107794 = ((x10.array.DistArray_BlockBlock_3<$T>)this$107786).minIndex_1;
                    
                    //#line 248 . "x10/array/DistArray_BlockBlock_3.x10"
                    final long t$107795 = ((i$107816) - (((long)(t$107794))));
                    
                    //#line 248 . "x10/array/DistArray_BlockBlock_3.x10"
                    final long t$107796 = ((t$107793) * (((long)(t$107795))));
                    
                    //#line 248 . "x10/array/DistArray_BlockBlock_3.x10"
                    final long t$107797 = ((t$107792) + (((long)(t$107796))));
                    
                    //#line 248 . "x10/array/DistArray_BlockBlock_3.x10"
                    final long t$107798 = ((t$107790) * (((long)(t$107797))));
                    
                    //#line 248 . "x10/array/DistArray_BlockBlock_3.x10"
                    final long t$107799 = ((i$107804) + (((long)(t$107798))));
                    
                    //#line 272 "x10/array/DistArray_BlockBlock_3.x10"
                    final $T t$107800 = (($T)(((x10.core.Rail<$T>)t$107785).$apply$G((long)(t$107799))));
                    
                    //#line 272 "x10/array/DistArray_BlockBlock_3.x10"
                    ((x10.core.Rail<$T>)patch).$set__1x10$lang$Rail$$T$G((long)(pre$107782), (($T)(t$107800)));
                    
                    //#line 271 "x10/array/DistArray_BlockBlock_3.x10"
                    final long t$107803 = ((i$107804) + (((long)(1L))));
                    
                    //#line 271 "x10/array/DistArray_BlockBlock_3.x10"
                    i$107804 = t$107803;
                }
                
                //#line 271 "x10/array/DistArray_BlockBlock_3.x10"
                final long t$107809 = ((i$107810) + (((long)(1L))));
                
                //#line 271 "x10/array/DistArray_BlockBlock_3.x10"
                i$107810 = t$107809;
            }
            
            //#line 271 "x10/array/DistArray_BlockBlock_3.x10"
            final long t$107815 = ((i$107816) + (((long)(1L))));
            
            //#line 271 "x10/array/DistArray_BlockBlock_3.x10"
            i$107816 = t$107815;
        }
        
        //#line 274 "x10/array/DistArray_BlockBlock_3.x10"
        return patch;
    }
    
    
    //#line 277 "x10/array/DistArray_BlockBlock_3.x10"
    private static long validateSize$O(final long m, final long n, final long p) {
        
        //#line 278 "x10/array/DistArray_BlockBlock_3.x10"
        boolean t$107727 = ((m) < (((long)(0L))));
        
        //#line 278 "x10/array/DistArray_BlockBlock_3.x10"
        if (!(t$107727)) {
            
            //#line 278 "x10/array/DistArray_BlockBlock_3.x10"
            t$107727 = ((n) < (((long)(0L))));
        }
        
        //#line 278 "x10/array/DistArray_BlockBlock_3.x10"
        boolean t$107728 = t$107727;
        
        //#line 278 "x10/array/DistArray_BlockBlock_3.x10"
        if (!(t$107727)) {
            
            //#line 278 "x10/array/DistArray_BlockBlock_3.x10"
            t$107728 = ((p) < (((long)(0L))));
        }
        
        //#line 278 "x10/array/DistArray_BlockBlock_3.x10"
        if (t$107728) {
            
            //#line 278 "x10/array/DistArray_BlockBlock_3.x10"
            x10.array.DistArray.raiseNegativeArraySizeException();
        }
        
        //#line 279 "x10/array/DistArray_BlockBlock_3.x10"
        final long t$107730 = ((m) * (((long)(n))));
        
        //#line 279 "x10/array/DistArray_BlockBlock_3.x10"
        final long t$107731 = ((t$107730) * (((long)(p))));
        
        //#line 279 "x10/array/DistArray_BlockBlock_3.x10"
        return t$107731;
    }
    
    public static long validateSize$P$O(final long m, final long n, final long p) {
        return x10.array.DistArray_BlockBlock_3.validateSize$O((long)(m), (long)(n), (long)(p));
    }
    
    
    //#line 23 "x10/array/DistArray_BlockBlock_3.x10"
    final public x10.array.DistArray_BlockBlock_3 x10$array$DistArray_BlockBlock_3$$this$x10$array$DistArray_BlockBlock_3() {
        
        //#line 23 "x10/array/DistArray_BlockBlock_3.x10"
        return x10.array.DistArray_BlockBlock_3.this;
    }
    
    
    //#line 23 "x10/array/DistArray_BlockBlock_3.x10"
    final public void __fieldInitializers_x10_array_DistArray_BlockBlock_3() {
        
    }
    
    @x10.runtime.impl.java.X10Generated
    final public static class $Closure$8<$T> extends x10.core.Ref implements x10.core.fun.Fun_0_0, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<$Closure$8> $RTT = 
            x10.rtt.StaticFunType.<$Closure$8> make($Closure$8.class,
                                                    1,
                                                    new x10.rtt.Type[] {
                                                        x10.rtt.ParameterizedType.make(x10.core.fun.Fun_0_0.$RTT, x10.rtt.ParameterizedType.make(x10.array.LocalState_BB3.$RTT, x10.rtt.UnresolvedType.PARAM(0)))
                                                    });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { if (i == 0) return $T; return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static <$T> x10.serialization.X10JavaSerializable $_deserialize_body(x10.array.DistArray_BlockBlock_3.$Closure$8<$T> $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            $_obj.$T = (x10.rtt.Type) $deserializer.readObject();
            $_obj.init = $deserializer.readObject();
            $_obj.m = $deserializer.readLong();
            $_obj.n = $deserializer.readLong();
            $_obj.p = $deserializer.readLong();
            $_obj.pg = $deserializer.readObject();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.array.DistArray_BlockBlock_3.$Closure$8 $_obj = new x10.array.DistArray_BlockBlock_3.$Closure$8((java.lang.System[]) null, (x10.rtt.Type) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            $serializer.write(this.$T);
            $serializer.write(this.init);
            $serializer.write(this.m);
            $serializer.write(this.n);
            $serializer.write(this.p);
            $serializer.write(this.pg);
            
        }
        
        // constructor just for allocation
        public $Closure$8(final java.lang.System[] $dummy, final x10.rtt.Type $T) {
            x10.array.DistArray_BlockBlock_3.$Closure$8.$initParams(this, $T);
            
        }
        
        // bridge for method abstract public ()=>U.operator()():U
        public x10.array.LocalState_BB3 $apply$G() {
            return $apply();
        }
        
        private x10.rtt.Type $T;
        
        // initializer of type parameters
        public static void $initParams(final $Closure$8 $this, final x10.rtt.Type $T) {
            $this.$T = $T;
            
        }
        // synthetic type for parameter mangling
        public static final class __4$1x10$lang$Long$3x10$lang$Long$3x10$lang$Long$3x10$array$DistArray_BlockBlock_3$$Closure$8$$T$2 {}
        
    
        
        public x10.array.LocalState_BB3 $apply() {
            
            //#line 71 "x10/array/DistArray_BlockBlock_3.x10"
            final x10.array.LocalState_BB3 t$107769 = x10.array.LocalState_BB3.<$T> make__4$1x10$lang$Long$3x10$lang$Long$3x10$lang$Long$3x10$array$LocalState_BB3$$S$2($T, ((x10.lang.PlaceGroup)(this.pg)), (long)(this.m), (long)(this.n), (long)(this.p), ((x10.core.fun.Fun_0_3)(this.init)));
            
            //#line 71 "x10/array/DistArray_BlockBlock_3.x10"
            return t$107769;
        }
        
        public x10.lang.PlaceGroup pg;
        public long m;
        public long n;
        public long p;
        public x10.core.fun.Fun_0_3<x10.core.Long,x10.core.Long,x10.core.Long,$T> init;
        
        public $Closure$8(final x10.rtt.Type $T, final x10.lang.PlaceGroup pg, final long m, final long n, final long p, final x10.core.fun.Fun_0_3<x10.core.Long,x10.core.Long,x10.core.Long,$T> init, __4$1x10$lang$Long$3x10$lang$Long$3x10$lang$Long$3x10$array$DistArray_BlockBlock_3$$Closure$8$$T$2 $dummy) {
            x10.array.DistArray_BlockBlock_3.$Closure$8.$initParams(this, $T);
             {
                ((x10.array.DistArray_BlockBlock_3.$Closure$8<$T>)this).pg = ((x10.lang.PlaceGroup)(pg));
                ((x10.array.DistArray_BlockBlock_3.$Closure$8<$T>)this).m = m;
                ((x10.array.DistArray_BlockBlock_3.$Closure$8<$T>)this).n = n;
                ((x10.array.DistArray_BlockBlock_3.$Closure$8<$T>)this).p = p;
                ((x10.array.DistArray_BlockBlock_3.$Closure$8<$T>)this).init = ((x10.core.fun.Fun_0_3)(init));
            }
        }
        
    }
    
    @x10.runtime.impl.java.X10Generated
    final public static class $Closure$9<$T> extends x10.core.Ref implements x10.core.fun.Fun_0_3, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<$Closure$9> $RTT = 
            x10.rtt.StaticFunType.<$Closure$9> make($Closure$9.class,
                                                    1,
                                                    new x10.rtt.Type[] {
                                                        x10.rtt.ParameterizedType.make(x10.core.fun.Fun_0_3.$RTT, x10.rtt.Types.LONG, x10.rtt.Types.LONG, x10.rtt.Types.LONG, x10.rtt.UnresolvedType.PARAM(0))
                                                    });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { if (i == 0) return $T; return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static <$T> x10.serialization.X10JavaSerializable $_deserialize_body(x10.array.DistArray_BlockBlock_3.$Closure$9<$T> $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            $_obj.$T = (x10.rtt.Type) $deserializer.readObject();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.array.DistArray_BlockBlock_3.$Closure$9 $_obj = new x10.array.DistArray_BlockBlock_3.$Closure$9((java.lang.System[]) null, (x10.rtt.Type) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            $serializer.write(this.$T);
            
        }
        
        // constructor just for allocation
        public $Closure$9(final java.lang.System[] $dummy, final x10.rtt.Type $T) {
            x10.array.DistArray_BlockBlock_3.$Closure$9.$initParams(this, $T);
            
        }
        
        // dispatcher for method abstract public (Z1,Z2,Z3)=>U.operator()(a1:Z1, a2:Z2, a3:Z3):U
        public java.lang.Object $apply(final java.lang.Object a1, final x10.rtt.Type t1, final java.lang.Object a2, final x10.rtt.Type t2, final java.lang.Object a3, final x10.rtt.Type t3) {
            return $apply$G(x10.core.Long.$unbox(a1), x10.core.Long.$unbox(a2), x10.core.Long.$unbox(a3));
            
        }
        
        private x10.rtt.Type $T;
        
        // initializer of type parameters
        public static void $initParams(final $Closure$9 $this, final x10.rtt.Type $T) {
            $this.$T = $T;
            
        }
        
    
        
        public $T $apply$G(final long id$60, final long id$61, final long id$62) {
            
            //#line 109 "x10/array/DistArray_BlockBlock_3.x10"
            final $T t$107574 = (($T)(($T) x10.rtt.Types.zeroValue($T)));
            
            //#line 109 "x10/array/DistArray_BlockBlock_3.x10"
            return t$107574;
        }
        
        public $Closure$9(final x10.rtt.Type $T) {
            x10.array.DistArray_BlockBlock_3.$Closure$9.$initParams(this, $T);
             {
                
            }
        }
        
    }
    
    @x10.runtime.impl.java.X10Generated
    final public static class $Closure$10<$T> extends x10.core.Ref implements x10.core.fun.Fun_0_3, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<$Closure$10> $RTT = 
            x10.rtt.StaticFunType.<$Closure$10> make($Closure$10.class,
                                                     1,
                                                     new x10.rtt.Type[] {
                                                         x10.rtt.ParameterizedType.make(x10.core.fun.Fun_0_3.$RTT, x10.rtt.Types.LONG, x10.rtt.Types.LONG, x10.rtt.Types.LONG, x10.rtt.UnresolvedType.PARAM(0))
                                                     });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { if (i == 0) return $T; return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static <$T> x10.serialization.X10JavaSerializable $_deserialize_body(x10.array.DistArray_BlockBlock_3.$Closure$10<$T> $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            $_obj.$T = (x10.rtt.Type) $deserializer.readObject();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.array.DistArray_BlockBlock_3.$Closure$10 $_obj = new x10.array.DistArray_BlockBlock_3.$Closure$10((java.lang.System[]) null, (x10.rtt.Type) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            $serializer.write(this.$T);
            
        }
        
        // constructor just for allocation
        public $Closure$10(final java.lang.System[] $dummy, final x10.rtt.Type $T) {
            x10.array.DistArray_BlockBlock_3.$Closure$10.$initParams(this, $T);
            
        }
        
        // dispatcher for method abstract public (Z1,Z2,Z3)=>U.operator()(a1:Z1, a2:Z2, a3:Z3):U
        public java.lang.Object $apply(final java.lang.Object a1, final x10.rtt.Type t1, final java.lang.Object a2, final x10.rtt.Type t2, final java.lang.Object a3, final x10.rtt.Type t3) {
            return $apply$G(x10.core.Long.$unbox(a1), x10.core.Long.$unbox(a2), x10.core.Long.$unbox(a3));
            
        }
        
        private x10.rtt.Type $T;
        
        // initializer of type parameters
        public static void $initParams(final $Closure$10 $this, final x10.rtt.Type $T) {
            $this.$T = $T;
            
        }
        
    
        
        public $T $apply$G(final long id$63, final long id$64, final long id$65) {
            
            //#line 123 "x10/array/DistArray_BlockBlock_3.x10"
            final $T t$107576 = (($T)(($T) x10.rtt.Types.zeroValue($T)));
            
            //#line 123 "x10/array/DistArray_BlockBlock_3.x10"
            return t$107576;
        }
        
        public $Closure$10(final x10.rtt.Type $T) {
            x10.array.DistArray_BlockBlock_3.$Closure$10.$initParams(this, $T);
             {
                
            }
        }
        
    }
    
}


