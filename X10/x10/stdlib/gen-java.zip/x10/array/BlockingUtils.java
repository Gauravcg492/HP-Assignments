package x10.array;

/**
 * Utility functions for blocking iteration spaces.
 * Can be used both for computing local iteration spaces for 
 * distributed arrays and for tiling iteration spaces for concurrency within
 * a single place. 
 */
@x10.runtime.impl.java.X10Generated
public class BlockingUtils extends x10.core.Ref implements x10.serialization.X10JavaSerializable
{
    public static final x10.rtt.RuntimeType<BlockingUtils> $RTT = 
        x10.rtt.NamedType.<BlockingUtils> make("x10.array.BlockingUtils",
                                               BlockingUtils.class);
    
    public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
    
    public x10.rtt.Type<?> $getParam(int i) { return null; }
    
    private Object writeReplace() throws java.io.ObjectStreamException {
        return new x10.serialization.SerializationProxy(this);
    }
    
    public static x10.serialization.X10JavaSerializable $_deserialize_body(x10.array.BlockingUtils $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
        return $_obj;
    }
    
    public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
        x10.array.BlockingUtils $_obj = new x10.array.BlockingUtils((java.lang.System[]) null);
        $deserializer.record_reference($_obj);
        return $_deserialize_body($_obj, $deserializer);
    }
    
    public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
        
    }
    
    // constructor just for allocation
    public BlockingUtils(final java.lang.System[] $dummy) {
        
    }
    
    

    
    
    //#line 43 "x10/array/BlockingUtils.x10"
    /**
     * A Block distribution takes a rank-1 iteration space
     * and distributes all points contained in the bounding box of the 
     * space roughly evenly into the requested number of units.
     * If the input iteration space is dense, then the returned iteration space will
     * only contain points that were also contained in the input iteration space.
     * If the input iteration space is not dense, then the returned iteration space
     * may contain points that were NOT in the input iteration space (and thus depending
     * on the application may require additional filtering before being used).
     * 
     * @param is the iteration space to partition
     * @param n is the total number of partitions desired
     * @return the IterationSpace representing the ith partition
     */
    public static x10.core.Rail partitionBlock(final x10.array.IterationSpace is, final long n) {
        
        //#line 44 "x10/array/BlockingUtils.x10"
        final x10.core.fun.Fun_0_1 t$104291 = ((x10.core.fun.Fun_0_1)(new x10.array.BlockingUtils.$Closure$0(is, n)));
        
        //#line 44 "x10/array/BlockingUtils.x10"
        final x10.core.Rail t$104292 = ((x10.core.Rail)(new x10.core.Rail<x10.array.DenseIterationSpace_1>(x10.array.DenseIterationSpace_1.$RTT, ((long)(n)), ((x10.core.fun.Fun_0_1)(t$104291)), (x10.core.Rail.__1$1x10$lang$Long$3x10$lang$Rail$$T$2) null)));
        
        //#line 44 "x10/array/BlockingUtils.x10"
        return t$104292;
    }
    
    
    //#line 65 "x10/array/BlockingUtils.x10"
    /**
     * A Block distribution takes a rank-1 iteration space
     * and distributes all points contained in the bounding box of the 
     * space roughly evenly into the requested number of units.
     * If the input iteration space is dense, then the returned iteration space will
     * only contain points that were also contained in the input iteration space.
     * If the input iteration space is not dense, then the returned iteration space
     * may contain points that were NOT in the input iteration space (and thus depending
     * on the application may require additional filtering before being used).
     * 
     * This utility method computes and returns the ith element in such a distribution.
     *
     * @param is the iteration space to partition
     * @param n is the total number of partitions desired
     * @param i is the index of the partition requested
     * @return the IterationSpace representing the ith partition
     */
    public static x10.array.DenseIterationSpace_1 partitionBlock(final x10.array.IterationSpace is, final long n, final long i) {
        
        //#line 66 "x10/array/BlockingUtils.x10"
        final long t$104293 = is.min$O((long)(0L));
        
        //#line 66 "x10/array/BlockingUtils.x10"
        final long t$104294 = is.max$O((long)(0L));
        
        //#line 66 "x10/array/BlockingUtils.x10"
        final x10.array.DenseIterationSpace_1 t$104295 = ((x10.array.DenseIterationSpace_1)(x10.array.BlockingUtils.partitionBlock((long)(t$104293), (long)(t$104294), (long)(n), (long)(i))));
        
        //#line 66 "x10/array/BlockingUtils.x10"
        return t$104295;
    }
    
    
    //#line 88 "x10/array/BlockingUtils.x10"
    /**
     * A Block distribution takes a rank-1 iteration space
     * and distributes all points contained in the bounding box of the 
     * space roughly evenly into the requested number of units.
     * If the input iteration space is dense, then the returned iteration space will
     * only contain points that were also contained in the input iteration space.
     * If the input iteration space is not dense, then the returned iteration space
     * may contain points that were NOT in the input iteration space (and thus depending
     * on the application may require additional filtering before being used).
     * 
     * This utility method computes and returns the ith element in such a distribution.
     *
     * @param min is the minimum element in the iteration space to partition
     * @param max is the maximum element in the iteration space to partition
     * @param n is the total number of partitions desired
     * @param i is the index of the partition requested
     * @return the IterationSpace representing the ith partition
     */
    public static x10.array.DenseIterationSpace_1 partitionBlock(final long min, final long max, final long n, final long i) {
        
        //#line 89 "x10/array/BlockingUtils.x10"
        final long t$104296 = ((max) - (((long)(min))));
        
        //#line 89 "x10/array/BlockingUtils.x10"
        final long numElems = ((t$104296) + (((long)(1L))));
        
        //#line 90 "x10/array/BlockingUtils.x10"
        final boolean t$104298 = ((numElems) < (((long)(1L))));
        
        //#line 90 "x10/array/BlockingUtils.x10"
        if (t$104298) {
            
            //#line 90 "x10/array/BlockingUtils.x10"
            final x10.array.DenseIterationSpace_1 t$104297 = ((x10.array.DenseIterationSpace_1)(x10.array.DenseIterationSpace_1.get$EMPTY()));
            
            //#line 90 "x10/array/BlockingUtils.x10"
            return t$104297;
        }
        
        //#line 91 "x10/array/BlockingUtils.x10"
        final long blockSize = ((numElems) / (((long)(n))));
        
        //#line 92 "x10/array/BlockingUtils.x10"
        final long t$104299 = ((n) * (((long)(blockSize))));
        
        //#line 92 "x10/array/BlockingUtils.x10"
        final long leftOver = ((numElems) - (((long)(t$104299))));
        
        //#line 93 "x10/array/BlockingUtils.x10"
        final long t$104300 = ((blockSize) * (((long)(i))));
        
        //#line 93 "x10/array/BlockingUtils.x10"
        final long t$104303 = ((min) + (((long)(t$104300))));
        
        //#line 93 "x10/array/BlockingUtils.x10"
        final boolean t$104301 = ((i) < (((long)(leftOver))));
        
        //#line 93 "x10/array/BlockingUtils.x10"
        long t$104302 =  0;
        
        //#line 93 "x10/array/BlockingUtils.x10"
        if (t$104301) {
            
            //#line 93 "x10/array/BlockingUtils.x10"
            t$104302 = i;
        } else {
            
            //#line 93 "x10/array/BlockingUtils.x10"
            t$104302 = leftOver;
        }
        
        //#line 93 "x10/array/BlockingUtils.x10"
        final long low = ((t$104303) + (((long)(t$104302))));
        
        //#line 94 "x10/array/BlockingUtils.x10"
        final long t$104307 = ((low) + (((long)(blockSize))));
        
        //#line 94 "x10/array/BlockingUtils.x10"
        final boolean t$104305 = ((i) < (((long)(leftOver))));
        
        //#line 94 "x10/array/BlockingUtils.x10"
        long t$104306 =  0;
        
        //#line 94 "x10/array/BlockingUtils.x10"
        if (t$104305) {
            
            //#line 94 "x10/array/BlockingUtils.x10"
            t$104306 = 0L;
        } else {
            
            //#line 94 "x10/array/BlockingUtils.x10"
            t$104306 = -1L;
        }
        
        //#line 94 "x10/array/BlockingUtils.x10"
        final long hi = ((t$104307) + (((long)(t$104306))));
        
        //#line 95 "x10/array/BlockingUtils.x10"
        final x10.array.DenseIterationSpace_1 alloc$103630 = ((x10.array.DenseIterationSpace_1)(new x10.array.DenseIterationSpace_1((java.lang.System[]) null)));
        
        //#line 95 "x10/array/BlockingUtils.x10"
        alloc$103630.x10$array$DenseIterationSpace_1$$init$S(((long)(low)), ((long)(hi)));
        
        //#line 95 "x10/array/BlockingUtils.x10"
        return alloc$103630;
    }
    
    
    //#line 117 "x10/array/BlockingUtils.x10"
    /**
     * A Block distribution takes a rank-1 iteration space
     * and distributes all points contained in the bounding box of the 
     * space roughly evenly into the requested number of units.
     * If the input iteration space is dense, then the returned iteration space will
     * only contain points that were also contained in the input iteration space.
     * If the input iteration space is not dense, then the returned iteration space
     * may contain points that were NOT in the input iteration space (and thus depending
     * on the application may require additional filtering before being used).
     * 
     * This utility method computes which partition an argument index would be placed.
     *
     * @param is the iteration space to partition
     * @param n is the total number of partitions desired
     * @param i the given index 
     * @return the partition number into which i is mapped by the distribution
     *         (or -1 if not contained in the bounding box of the argument iteration space)
     */
    public static long mapIndexToBlockPartition$O(final x10.array.IterationSpace is, final long n, final long i) {
        
        //#line 118 "x10/array/BlockingUtils.x10"
        is.min$O((long)(0L));
        
        //#line 119 "x10/array/BlockingUtils.x10"
        is.max$O((long)(0L));
        
        //#line 120 "x10/array/BlockingUtils.x10"
        final long t$104309 = is.min$O((long)(0L));
        
        //#line 120 "x10/array/BlockingUtils.x10"
        final long t$104310 = is.max$O((long)(0L));
        
        //#line 120 "x10/array/BlockingUtils.x10"
        final long t$104311 = x10.array.BlockingUtils.mapIndexToBlockPartition$O((long)(t$104309), (long)(t$104310), (long)(n), (long)(i));
        
        //#line 120 "x10/array/BlockingUtils.x10"
        return t$104311;
    }
    
    
    //#line 143 "x10/array/BlockingUtils.x10"
    /**
     * A Block distribution takes a rank-1 iteration space
     * and distributes all points contained in the bounding box of the 
     * space roughly evenly into the requested number of units.
     * If the input iteration space is dense, then the returned iteration space will
     * only contain points that were also contained in the input iteration space.
     * If the input iteration space is not dense, then the returned iteration space
     * may contain points that were NOT in the input iteration space (and thus depending
     * on the application may require additional filtering before being used).
     * 
     * This utility method computes which partition an argument index would be placed.
     *
     * @param min is the minimum element in the iteration space to partition
     * @param max is the maximum element in the iteration space to partition
     * @param n is the total number of partitions desired
     * @param i the given index 
     * @return the partition number into which i is mapped by the distribution
     *         (or -1 if not contained in the bounding box of the argument iteration space)
     */
    public static long mapIndexToBlockPartition$O(final long min, final long max, final long n, final long i) {
        
        //#line 144 "x10/array/BlockingUtils.x10"
        boolean t$104312 = ((i) < (((long)(min))));
        
        //#line 144 "x10/array/BlockingUtils.x10"
        if (!(t$104312)) {
            
            //#line 144 "x10/array/BlockingUtils.x10"
            t$104312 = ((i) > (((long)(max))));
        }
        
        //#line 144 "x10/array/BlockingUtils.x10"
        if (t$104312) {
            
            //#line 144 "x10/array/BlockingUtils.x10"
            return -1L;
        }
        
        //#line 145 "x10/array/BlockingUtils.x10"
        final long t$104314 = ((max) - (((long)(min))));
        
        //#line 145 "x10/array/BlockingUtils.x10"
        final long numElems = ((t$104314) + (((long)(1L))));
        
        //#line 146 "x10/array/BlockingUtils.x10"
        final long blockSize = ((numElems) / (((long)(n))));
        
        //#line 147 "x10/array/BlockingUtils.x10"
        final long t$104315 = ((n) * (((long)(blockSize))));
        
        //#line 147 "x10/array/BlockingUtils.x10"
        final long leftOver = ((numElems) - (((long)(t$104315))));
        
        //#line 148 "x10/array/BlockingUtils.x10"
        final long normalizedIndex = ((i) - (((long)(min))));
        
        //#line 149 "x10/array/BlockingUtils.x10"
        final long t$104316 = ((blockSize) + (((long)(1L))));
        
        //#line 149 "x10/array/BlockingUtils.x10"
        final long nominalIndex = ((normalizedIndex) / (((long)(t$104316))));
        
        //#line 150 "x10/array/BlockingUtils.x10"
        final boolean t$104320 = ((nominalIndex) < (((long)(leftOver))));
        
        //#line 150 "x10/array/BlockingUtils.x10"
        if (t$104320) {
            
            //#line 151 "x10/array/BlockingUtils.x10"
            return nominalIndex;
        } else {
            
            //#line 153 "x10/array/BlockingUtils.x10"
            final long indexFromTop = ((max) - (((long)(i))));
            
            //#line 154 "x10/array/BlockingUtils.x10"
            final long t$104317 = ((n) - (((long)(1L))));
            
            //#line 154 "x10/array/BlockingUtils.x10"
            final long t$104318 = ((indexFromTop) / (((long)(blockSize))));
            
            //#line 154 "x10/array/BlockingUtils.x10"
            final long t$104319 = ((t$104317) - (((long)(t$104318))));
            
            //#line 154 "x10/array/BlockingUtils.x10"
            return t$104319;
        }
    }
    
    
    //#line 179 "x10/array/BlockingUtils.x10"
    /**
     * A BlockBlock distribution takes a rank-2 iteration space
     * and distributes all points contained in the bounding box of the 
     * space roughly evenly into the requested number of units in 2-d grid.
     * If the input iteration space is dense, then the returned iteration space will
     * only contain points that were also contained in the input iteration space.
     * If the input iteration space is not dense, then the returned iteration space
     * may contain points that were NOT in the input iteration space (and thus depending
     * on the application may require additional filtering before being used).
     * 
     * @param is the iteration space to partition
     * @param n is the total number of partitions desired
     * @return the IterationSpace representing the ith partition
     */
    public static x10.core.Rail partitionBlockBlock(final x10.array.IterationSpace is, final long n) {
        
        //#line 180 "x10/array/BlockingUtils.x10"
        final x10.core.fun.Fun_0_1 t$104322 = ((x10.core.fun.Fun_0_1)(new x10.array.BlockingUtils.$Closure$1(is, n)));
        
        //#line 180 "x10/array/BlockingUtils.x10"
        final x10.core.Rail t$104323 = ((x10.core.Rail)(new x10.core.Rail<x10.array.DenseIterationSpace_2>(x10.array.DenseIterationSpace_2.$RTT, ((long)(n)), ((x10.core.fun.Fun_0_1)(t$104322)), (x10.core.Rail.__1$1x10$lang$Long$3x10$lang$Rail$$T$2) null)));
        
        //#line 180 "x10/array/BlockingUtils.x10"
        return t$104323;
    }
    
    
    //#line 201 "x10/array/BlockingUtils.x10"
    /**
     * A BlockBlock distribution takes a rank-2 iteration space
     * and distributes all points contained in the bounding box of the 
     * space roughly evenly into the requested number of units in 2-d grid.
     * If the input iteration space is dense, then the returned iteration space will
     * only contain points that were also contained in the input iteration space.
     * If the input iteration space is not dense, then the returned iteration space
     * may contain points that were NOT in the input iteration space (and thus depending
     * on the application may require additional filtering before being used).
     * 
     * This utility method computes and returns the ith element in such a distribution.
     *
     * @param is the iteration space to partition
     * @param n is the total number of partitions desired
     * @param i is the index of the partition requested
     * @return the IterationSpace representing the ith partition
     */
    public static x10.array.DenseIterationSpace_2 partitionBlockBlock(final x10.array.IterationSpace is, final long n, final long i) {
        
        //#line 202 "x10/array/BlockingUtils.x10"
        final long min0 = is.min$O((long)(0L));
        
        //#line 203 "x10/array/BlockingUtils.x10"
        final long max0 = is.max$O((long)(0L));
        
        //#line 204 "x10/array/BlockingUtils.x10"
        final long min1 = is.min$O((long)(1L));
        
        //#line 205 "x10/array/BlockingUtils.x10"
        final long max1 = is.max$O((long)(1L));
        
        //#line 206 "x10/array/BlockingUtils.x10"
        final x10.array.DenseIterationSpace_2 t$104324 = ((x10.array.DenseIterationSpace_2)(x10.array.BlockingUtils.partitionBlockBlock((long)(min0), (long)(min1), (long)(max0), (long)(max1), (long)(n), (long)(i))));
        
        //#line 206 "x10/array/BlockingUtils.x10"
        return t$104324;
    }
    
    
    //#line 230 "x10/array/BlockingUtils.x10"
    /**
     * A BlockBlock distribution takes a rank-2 iteration space
     * and distributes all points contained in the bounding box of the 
     * space roughly evenly into the requested number of units in 2-d grid.
     * If the input iteration space is dense, then the returned iteration space will
     * only contain points that were also contained in the input iteration space.
     * If the input iteration space is not dense, then the returned iteration space
     * may contain points that were NOT in the input iteration space (and thus depending
     * on the application may require additional filtering before being used).
     * 
     * This utility method computes and returns the ith element in such a distribution.
     *
     * param min0 is the min index of the first dimension
     * param min1 is the min index of the second dimension
     * param max0 is the max index of the first dimension
     * param max1 is the max index of the second dimension
     * @param n is the total number of partitions desired
     * @param i is the index of the partition requested
     * @return the IterationSpace representing the ith partition
     */
    public static x10.array.DenseIterationSpace_2 partitionBlockBlock(final long min0, final long min1, final long max0, final long max1, final long n, final long i) {
        
        //#line 232 "x10/array/BlockingUtils.x10"
        final long t$104325 = ((max0) - (((long)(min0))));
        
        //#line 232 "x10/array/BlockingUtils.x10"
        final long size0 = ((t$104325) + (((long)(1L))));
        
        //#line 233 "x10/array/BlockingUtils.x10"
        final long t$104326 = ((max1) - (((long)(min1))));
        
        //#line 233 "x10/array/BlockingUtils.x10"
        final long size1 = ((t$104326) + (((long)(1L))));
        
        //#line 235 "x10/array/BlockingUtils.x10"
        boolean t$104327 = ((size0) < (((long)(1L))));
        
        //#line 235 "x10/array/BlockingUtils.x10"
        if (!(t$104327)) {
            
            //#line 235 "x10/array/BlockingUtils.x10"
            t$104327 = ((size1) < (((long)(1L))));
        }
        
        //#line 235 "x10/array/BlockingUtils.x10"
        if (t$104327) {
            
            //#line 235 "x10/array/BlockingUtils.x10"
            final x10.array.DenseIterationSpace_2 t$104328 = ((x10.array.DenseIterationSpace_2)(x10.array.DenseIterationSpace_2.get$EMPTY()));
            
            //#line 235 "x10/array/BlockingUtils.x10"
            return t$104328;
        }
        
        //#line 236 "x10/array/BlockingUtils.x10"
        final boolean t$104332 = ((long) size0) == ((long) 1L);
        
        //#line 236 "x10/array/BlockingUtils.x10"
        if (t$104332) {
            
            //#line 237 "x10/array/BlockingUtils.x10"
            final x10.array.DenseIterationSpace_1 is1 = ((x10.array.DenseIterationSpace_1)(x10.array.BlockingUtils.partitionBlock((long)(min1), (long)(max1), (long)(n), (long)(i))));
            
            //#line 238 "x10/array/BlockingUtils.x10"
            final x10.array.DenseIterationSpace_2 alloc$103631 = ((x10.array.DenseIterationSpace_2)(new x10.array.DenseIterationSpace_2((java.lang.System[]) null)));
            
            //#line 238 "x10/array/BlockingUtils.x10"
            final long t$104441 = is1.min$O((long)(0L));
            
            //#line 238 "x10/array/BlockingUtils.x10"
            final long t$104442 = is1.max$O((long)(0L));
            
            //#line 238 "x10/array/BlockingUtils.x10"
            alloc$103631.x10$array$DenseIterationSpace_2$$init$S(((long)(min0)), t$104441, ((long)(max0)), t$104442);
            
            //#line 238 "x10/array/BlockingUtils.x10"
            return alloc$103631;
        }
        
        //#line 240 "x10/array/BlockingUtils.x10"
        final boolean t$104335 = ((long) size1) == ((long) 1L);
        
        //#line 240 "x10/array/BlockingUtils.x10"
        if (t$104335) {
            
            //#line 241 "x10/array/BlockingUtils.x10"
            final x10.array.DenseIterationSpace_1 is0 = ((x10.array.DenseIterationSpace_1)(x10.array.BlockingUtils.partitionBlock((long)(min0), (long)(max0), (long)(n), (long)(i))));
            
            //#line 242 "x10/array/BlockingUtils.x10"
            final x10.array.DenseIterationSpace_2 alloc$103632 = ((x10.array.DenseIterationSpace_2)(new x10.array.DenseIterationSpace_2((java.lang.System[]) null)));
            
            //#line 242 "x10/array/BlockingUtils.x10"
            final long t$104443 = is0.min$O((long)(0L));
            
            //#line 242 "x10/array/BlockingUtils.x10"
            final long t$104444 = is0.max$O((long)(0L));
            
            //#line 242 "x10/array/BlockingUtils.x10"
            alloc$103632.x10$array$DenseIterationSpace_2$$init$S(t$104443, ((long)(min1)), t$104444, ((long)(max1)));
            
            //#line 242 "x10/array/BlockingUtils.x10"
            return alloc$103632;
        }
        
        //#line 245 "x10/array/BlockingUtils.x10"
        final long t$104336 = ((size0) % (((long)(2L))));
        
        //#line 245 "x10/array/BlockingUtils.x10"
        final boolean t$104337 = ((long) t$104336) == ((long) 0L);
        
        //#line 245 "x10/array/BlockingUtils.x10"
        long t$104338 =  0;
        
        //#line 245 "x10/array/BlockingUtils.x10"
        if (t$104337) {
            
            //#line 245 "x10/array/BlockingUtils.x10"
            t$104338 = size0;
        } else {
            
            //#line 245 "x10/array/BlockingUtils.x10"
            t$104338 = ((size0) - (((long)(1L))));
        }
        
        //#line 246 "x10/array/BlockingUtils.x10"
        final long t$104339 = ((t$104338) * (((long)(size1))));
        
        //#line 246 "x10/array/BlockingUtils.x10"
        final long P = java.lang.Math.min(((long)(n)),((long)(t$104339)));
        
        //#line 247 "x10/array/BlockingUtils.x10"
        final boolean t$104341 = ((i) >= (((long)(P))));
        
        //#line 247 "x10/array/BlockingUtils.x10"
        if (t$104341) {
            
            //#line 247 "x10/array/BlockingUtils.x10"
            final x10.array.DenseIterationSpace_2 t$104340 = ((x10.array.DenseIterationSpace_2)(x10.array.DenseIterationSpace_2.get$EMPTY()));
            
            //#line 247 "x10/array/BlockingUtils.x10"
            return t$104340;
        }
        
        //#line 249 "x10/array/BlockingUtils.x10"
        final double t$104342 = ((double)(long)(((long)(P))));
        
        //#line 249 "x10/array/BlockingUtils.x10"
        final double t$104343 = java.lang.Math.log(((double)(t$104342)));
        
        //#line 249 "x10/array/BlockingUtils.x10"
        final double t$104344 = java.lang.Math.log(((double)(2.0)));
        
        //#line 249 "x10/array/BlockingUtils.x10"
        final double t$104345 = ((t$104343) / (((double)(t$104344))));
        
        //#line 249 "x10/array/BlockingUtils.x10"
        final double t$104346 = ((t$104345) / (((double)(2.0))));
        
        //#line 249 "x10/array/BlockingUtils.x10"
        final double t$104347 = java.lang.Math.ceil(((double)(t$104346)));
        
        //#line 249 "x10/array/BlockingUtils.x10"
        final long t$104348 = ((long)(double)(((double)(t$104347))));
        
        //#line 249 "x10/array/BlockingUtils.x10"
        final long t$104349 = x10.lang.Math.pow2$O((long)(t$104348));
        
        //#line 249 "x10/array/BlockingUtils.x10"
        final long divisions0 = java.lang.Math.min(((long)(t$104338)),((long)(t$104349)));
        
        //#line 250 "x10/array/BlockingUtils.x10"
        final double t$104350 = ((double)(long)(((long)(P))));
        
        //#line 250 "x10/array/BlockingUtils.x10"
        final double t$104351 = ((double)(long)(((long)(divisions0))));
        
        //#line 250 "x10/array/BlockingUtils.x10"
        final double t$104352 = ((t$104350) / (((double)(t$104351))));
        
        //#line 250 "x10/array/BlockingUtils.x10"
        final double t$104353 = java.lang.Math.ceil(((double)(t$104352)));
        
        //#line 250 "x10/array/BlockingUtils.x10"
        final long t$104354 = ((long)(double)(((double)(t$104353))));
        
        //#line 250 "x10/array/BlockingUtils.x10"
        final long divisions1 = java.lang.Math.min(((long)(size1)),((long)(t$104354)));
        
        //#line 251 "x10/array/BlockingUtils.x10"
        final long t$104355 = ((divisions0) * (((long)(divisions1))));
        
        //#line 251 "x10/array/BlockingUtils.x10"
        final long leftOver = ((t$104355) - (((long)(P))));
        
        //#line 252 "x10/array/BlockingUtils.x10"
        final long t$104356 = ((divisions0) % (((long)(2L))));
        
        //#line 252 "x10/array/BlockingUtils.x10"
        final boolean t$104359 = ((long) t$104356) == ((long) 0L);
        
        //#line 252 "x10/array/BlockingUtils.x10"
        long t$104360 =  0;
        
        //#line 252 "x10/array/BlockingUtils.x10"
        if (t$104359) {
            
            //#line 252 "x10/array/BlockingUtils.x10"
            t$104360 = 0L;
        } else {
            
            //#line 252 "x10/array/BlockingUtils.x10"
            final long t$104357 = ((i) * (((long)(2L))));
            
            //#line 252 "x10/array/BlockingUtils.x10"
            final long t$104358 = ((divisions0) + (((long)(1L))));
            
            //#line 252 "x10/array/BlockingUtils.x10"
            t$104360 = ((t$104357) / (((long)(t$104358))));
        }
        
        //#line 254 "x10/array/BlockingUtils.x10"
        final boolean t$104364 = ((i) < (((long)(leftOver))));
        
        //#line 254 "x10/array/BlockingUtils.x10"
        long t$104365 =  0;
        
        //#line 254 "x10/array/BlockingUtils.x10"
        if (t$104364) {
            
            //#line 254 "x10/array/BlockingUtils.x10"
            final long t$104361 = ((i) * (((long)(2L))));
            
            //#line 254 "x10/array/BlockingUtils.x10"
            final long t$104362 = ((t$104361) - (((long)(t$104360))));
            
            //#line 254 "x10/array/BlockingUtils.x10"
            t$104365 = ((t$104362) % (((long)(divisions0))));
        } else {
            
            //#line 254 "x10/array/BlockingUtils.x10"
            final long t$104363 = ((i) + (((long)(leftOver))));
            
            //#line 254 "x10/array/BlockingUtils.x10"
            t$104365 = ((t$104363) % (((long)(divisions0))));
        }
        
        //#line 255 "x10/array/BlockingUtils.x10"
        final boolean t$104368 = ((i) < (((long)(leftOver))));
        
        //#line 255 "x10/array/BlockingUtils.x10"
        long t$104369 =  0;
        
        //#line 255 "x10/array/BlockingUtils.x10"
        if (t$104368) {
            
            //#line 255 "x10/array/BlockingUtils.x10"
            final long t$104366 = ((i) * (((long)(2L))));
            
            //#line 255 "x10/array/BlockingUtils.x10"
            t$104369 = ((t$104366) / (((long)(divisions0))));
        } else {
            
            //#line 255 "x10/array/BlockingUtils.x10"
            final long t$104367 = ((i) + (((long)(leftOver))));
            
            //#line 255 "x10/array/BlockingUtils.x10"
            t$104369 = ((t$104367) / (((long)(divisions0))));
        }
        
        //#line 257 "x10/array/BlockingUtils.x10"
        final long t$104370 = ((t$104365) * (((long)(size0))));
        
        //#line 257 "x10/array/BlockingUtils.x10"
        final double t$104371 = ((double)(long)(((long)(t$104370))));
        
        //#line 257 "x10/array/BlockingUtils.x10"
        final double t$104372 = ((double)(long)(((long)(divisions0))));
        
        //#line 257 "x10/array/BlockingUtils.x10"
        final double t$104373 = ((t$104371) / (((double)(t$104372))));
        
        //#line 257 "x10/array/BlockingUtils.x10"
        final double t$104374 = java.lang.Math.ceil(((double)(t$104373)));
        
        //#line 257 "x10/array/BlockingUtils.x10"
        final long t$104375 = ((long)(double)(((double)(t$104374))));
        
        //#line 257 "x10/array/BlockingUtils.x10"
        final long low0 = ((min0) + (((long)(t$104375))));
        
        //#line 258 "x10/array/BlockingUtils.x10"
        final boolean t$104376 = ((i) < (((long)(leftOver))));
        
        //#line 258 "x10/array/BlockingUtils.x10"
        long t$104377 =  0;
        
        //#line 258 "x10/array/BlockingUtils.x10"
        if (t$104376) {
            
            //#line 258 "x10/array/BlockingUtils.x10"
            t$104377 = 2L;
        } else {
            
            //#line 258 "x10/array/BlockingUtils.x10"
            t$104377 = 1L;
        }
        
        //#line 258 "x10/array/BlockingUtils.x10"
        final long blockHi0 = ((t$104365) + (((long)(t$104377))));
        
        //#line 259 "x10/array/BlockingUtils.x10"
        final long t$104379 = ((blockHi0) * (((long)(size0))));
        
        //#line 259 "x10/array/BlockingUtils.x10"
        final double t$104380 = ((double)(long)(((long)(t$104379))));
        
        //#line 259 "x10/array/BlockingUtils.x10"
        final double t$104381 = ((double)(long)(((long)(divisions0))));
        
        //#line 259 "x10/array/BlockingUtils.x10"
        final double t$104382 = ((t$104380) / (((double)(t$104381))));
        
        //#line 259 "x10/array/BlockingUtils.x10"
        final double t$104383 = java.lang.Math.ceil(((double)(t$104382)));
        
        //#line 259 "x10/array/BlockingUtils.x10"
        final long t$104384 = ((long)(double)(((double)(t$104383))));
        
        //#line 259 "x10/array/BlockingUtils.x10"
        final long t$104385 = ((min0) + (((long)(t$104384))));
        
        //#line 259 "x10/array/BlockingUtils.x10"
        final long hi0 = ((t$104385) - (((long)(1L))));
        
        //#line 261 "x10/array/BlockingUtils.x10"
        final long t$104386 = ((t$104369) * (((long)(size1))));
        
        //#line 261 "x10/array/BlockingUtils.x10"
        final double t$104387 = ((double)(long)(((long)(t$104386))));
        
        //#line 261 "x10/array/BlockingUtils.x10"
        final double t$104388 = ((double)(long)(((long)(divisions1))));
        
        //#line 261 "x10/array/BlockingUtils.x10"
        final double t$104389 = ((t$104387) / (((double)(t$104388))));
        
        //#line 261 "x10/array/BlockingUtils.x10"
        final double t$104390 = java.lang.Math.ceil(((double)(t$104389)));
        
        //#line 261 "x10/array/BlockingUtils.x10"
        final long t$104391 = ((long)(double)(((double)(t$104390))));
        
        //#line 261 "x10/array/BlockingUtils.x10"
        final long low1 = ((min1) + (((long)(t$104391))));
        
        //#line 262 "x10/array/BlockingUtils.x10"
        final long t$104392 = ((t$104369) + (((long)(1L))));
        
        //#line 262 "x10/array/BlockingUtils.x10"
        final long t$104393 = ((t$104392) * (((long)(size1))));
        
        //#line 262 "x10/array/BlockingUtils.x10"
        final double t$104394 = ((double)(long)(((long)(t$104393))));
        
        //#line 262 "x10/array/BlockingUtils.x10"
        final double t$104395 = ((double)(long)(((long)(divisions1))));
        
        //#line 262 "x10/array/BlockingUtils.x10"
        final double t$104396 = ((t$104394) / (((double)(t$104395))));
        
        //#line 262 "x10/array/BlockingUtils.x10"
        final double t$104397 = java.lang.Math.ceil(((double)(t$104396)));
        
        //#line 262 "x10/array/BlockingUtils.x10"
        final long t$104398 = ((long)(double)(((double)(t$104397))));
        
        //#line 262 "x10/array/BlockingUtils.x10"
        final long t$104399 = ((min1) + (((long)(t$104398))));
        
        //#line 262 "x10/array/BlockingUtils.x10"
        final long hi1 = ((t$104399) - (((long)(1L))));
        
        //#line 264 "x10/array/BlockingUtils.x10"
        final x10.array.DenseIterationSpace_2 alloc$103633 = ((x10.array.DenseIterationSpace_2)(new x10.array.DenseIterationSpace_2((java.lang.System[]) null)));
        
        //#line 264 "x10/array/BlockingUtils.x10"
        alloc$103633.x10$array$DenseIterationSpace_2$$init$S(((long)(low0)), ((long)(low1)), ((long)(hi0)), ((long)(hi1)));
        
        //#line 264 "x10/array/BlockingUtils.x10"
        return alloc$103633;
    }
    
    
    //#line 287 "x10/array/BlockingUtils.x10"
    /**
     * A BlockBlock distribution takes a rank-2 iteration space
     * and distributes all points contained in the bounding box of the 
     * space roughly evenly into the requested number of units in 2-d grid.
     * If the input iteration space is dense, then the returned iteration space will
     * only contain points that were also contained in the input iteration space.
     * If the input iteration space is not dense, then the returned iteration space
     * may contain points that were NOT in the input iteration space (and thus depending
     * on the application may require additional filtering before being used).
     * 
     * This utility method computes which partition an argument index would be placed.
     *
     * @param is the iteration space to partition
     * @param n is the total number of partitions desired
     * @param i the given index in the first dimension
     * @param j the given index in the second dimension
     * @return the partition number into which (i,j) is mapped by the distribution
     *         (or -1 if not contained in the bounding box of the argument iteration space)
     */
    public static long mapIndexToBlockBlockPartition$O(final x10.array.IterationSpace is, final long n, final long i, final long j) {
        
        //#line 288 "x10/array/BlockingUtils.x10"
        final long min0 = is.min$O((long)(0L));
        
        //#line 289 "x10/array/BlockingUtils.x10"
        final long max0 = is.max$O((long)(0L));
        
        //#line 290 "x10/array/BlockingUtils.x10"
        final long min1 = is.min$O((long)(1L));
        
        //#line 291 "x10/array/BlockingUtils.x10"
        final long max1 = is.max$O((long)(1L));
        
        //#line 292 "x10/array/BlockingUtils.x10"
        final long t$104400 = x10.array.BlockingUtils.mapIndexToBlockBlockPartition$O((long)(min0), (long)(min1), (long)(max0), (long)(max1), (long)(n), (long)(i), (long)(j));
        
        //#line 292 "x10/array/BlockingUtils.x10"
        return t$104400;
    }
    
    
    //#line 318 "x10/array/BlockingUtils.x10"
    /**
     * A BlockBlock distribution takes a rank-2 iteration space
     * and distributes all points contained in the bounding box of the 
     * space roughly evenly into the requested number of units in 2-d grid.
     * If the input iteration space is dense, then the returned iteration space will
     * only contain points that were also contained in the input iteration space.
     * If the input iteration space is not dense, then the returned iteration space
     * may contain points that were NOT in the input iteration space (and thus depending
     * on the application may require additional filtering before being used).
     * 
     * This utility method computes which partition an argument index would be placed.
     *
     * param min0 is the min index of the first dimension
     * param min1 is the min index of the second dimension
     * param max0 is the max index of the first dimension
     * param max1 is the max index of the second dimension
     * @param n is the total number of partitions desired
     * @param i the given index in the first dimension
     * @param j the given index in the second dimension
     * @return the partition number into which (i,j) is mapped by the distribution
     *         (or -1 if not contained in the bounding box of the argument iteration space)
     */
    public static long mapIndexToBlockBlockPartition$O(final long min0, final long min1, final long max0, final long max1, final long n, final long i, final long j) {
        
        //#line 320 "x10/array/BlockingUtils.x10"
        boolean t$104401 = ((i) < (((long)(min0))));
        
        //#line 320 "x10/array/BlockingUtils.x10"
        if (!(t$104401)) {
            
            //#line 320 "x10/array/BlockingUtils.x10"
            t$104401 = ((i) > (((long)(max0))));
        }
        
        //#line 320 "x10/array/BlockingUtils.x10"
        boolean t$104402 = t$104401;
        
        //#line 320 "x10/array/BlockingUtils.x10"
        if (!(t$104401)) {
            
            //#line 320 "x10/array/BlockingUtils.x10"
            t$104402 = ((j) < (((long)(min1))));
        }
        
        //#line 320 "x10/array/BlockingUtils.x10"
        boolean t$104403 = t$104402;
        
        //#line 320 "x10/array/BlockingUtils.x10"
        if (!(t$104402)) {
            
            //#line 320 "x10/array/BlockingUtils.x10"
            t$104403 = ((j) > (((long)(max1))));
        }
        
        //#line 320 "x10/array/BlockingUtils.x10"
        if (t$104403) {
            
            //#line 320 "x10/array/BlockingUtils.x10"
            return -1L;
        }
        
        //#line 322 "x10/array/BlockingUtils.x10"
        final long t$104405 = ((max0) - (((long)(min0))));
        
        //#line 322 "x10/array/BlockingUtils.x10"
        final long size0 = ((t$104405) + (((long)(1L))));
        
        //#line 323 "x10/array/BlockingUtils.x10"
        final long t$104406 = ((max1) - (((long)(min1))));
        
        //#line 323 "x10/array/BlockingUtils.x10"
        final long size1 = ((t$104406) + (((long)(1L))));
        
        //#line 325 "x10/array/BlockingUtils.x10"
        final boolean t$104408 = ((long) size0) == ((long) 1L);
        
        //#line 325 "x10/array/BlockingUtils.x10"
        if (t$104408) {
            
            //#line 326 "x10/array/BlockingUtils.x10"
            final long t$104407 = x10.array.BlockingUtils.mapIndexToBlockPartition$O((long)(min1), (long)(max1), (long)(n), (long)(j));
            
            //#line 326 "x10/array/BlockingUtils.x10"
            return t$104407;
        }
        
        //#line 328 "x10/array/BlockingUtils.x10"
        final boolean t$104410 = ((long) size1) == ((long) 1L);
        
        //#line 328 "x10/array/BlockingUtils.x10"
        if (t$104410) {
            
            //#line 329 "x10/array/BlockingUtils.x10"
            final long t$104409 = x10.array.BlockingUtils.mapIndexToBlockPartition$O((long)(min0), (long)(max0), (long)(n), (long)(i));
            
            //#line 329 "x10/array/BlockingUtils.x10"
            return t$104409;
        }
        
        //#line 332 "x10/array/BlockingUtils.x10"
        final long t$104411 = ((size0) % (((long)(2L))));
        
        //#line 332 "x10/array/BlockingUtils.x10"
        final boolean t$104412 = ((long) t$104411) == ((long) 0L);
        
        //#line 332 "x10/array/BlockingUtils.x10"
        long t$104413 =  0;
        
        //#line 332 "x10/array/BlockingUtils.x10"
        if (t$104412) {
            
            //#line 332 "x10/array/BlockingUtils.x10"
            t$104413 = size0;
        } else {
            
            //#line 332 "x10/array/BlockingUtils.x10"
            t$104413 = ((size0) - (((long)(1L))));
        }
        
        //#line 333 "x10/array/BlockingUtils.x10"
        final long t$104414 = ((t$104413) * (((long)(size1))));
        
        //#line 333 "x10/array/BlockingUtils.x10"
        final long P = java.lang.Math.min(((long)(n)),((long)(t$104414)));
        
        //#line 334 "x10/array/BlockingUtils.x10"
        final double t$104415 = ((double)(long)(((long)(P))));
        
        //#line 334 "x10/array/BlockingUtils.x10"
        final double t$104416 = java.lang.Math.log(((double)(t$104415)));
        
        //#line 334 "x10/array/BlockingUtils.x10"
        final double t$104417 = java.lang.Math.log(((double)(2.0)));
        
        //#line 334 "x10/array/BlockingUtils.x10"
        final double t$104418 = ((t$104416) / (((double)(t$104417))));
        
        //#line 334 "x10/array/BlockingUtils.x10"
        final double t$104419 = ((t$104418) / (((double)(2.0))));
        
        //#line 334 "x10/array/BlockingUtils.x10"
        final double t$104420 = java.lang.Math.ceil(((double)(t$104419)));
        
        //#line 334 "x10/array/BlockingUtils.x10"
        final long t$104421 = ((long)(double)(((double)(t$104420))));
        
        //#line 334 "x10/array/BlockingUtils.x10"
        final long t$104422 = x10.lang.Math.pow2$O((long)(t$104421));
        
        //#line 334 "x10/array/BlockingUtils.x10"
        final long divisions0 = java.lang.Math.min(((long)(t$104413)),((long)(t$104422)));
        
        //#line 335 "x10/array/BlockingUtils.x10"
        final double t$104423 = ((double)(long)(((long)(P))));
        
        //#line 335 "x10/array/BlockingUtils.x10"
        final double t$104424 = ((double)(long)(((long)(divisions0))));
        
        //#line 335 "x10/array/BlockingUtils.x10"
        final double t$104425 = ((t$104423) / (((double)(t$104424))));
        
        //#line 335 "x10/array/BlockingUtils.x10"
        final double t$104426 = java.lang.Math.ceil(((double)(t$104425)));
        
        //#line 335 "x10/array/BlockingUtils.x10"
        final long t$104427 = ((long)(double)(((double)(t$104426))));
        
        //#line 335 "x10/array/BlockingUtils.x10"
        final long divisions1 = java.lang.Math.min(((long)(size1)),((long)(t$104427)));
        
        //#line 336 "x10/array/BlockingUtils.x10"
        final long numBlocks = ((divisions0) * (((long)(divisions1))));
        
        //#line 337 "x10/array/BlockingUtils.x10"
        final long leftOver = ((numBlocks) - (((long)(P))));
        
        //#line 339 "x10/array/BlockingUtils.x10"
        final boolean t$104430 = ((long) divisions0) == ((long) 1L);
        
        //#line 339 "x10/array/BlockingUtils.x10"
        long t$104431 =  0;
        
        //#line 339 "x10/array/BlockingUtils.x10"
        if (t$104430) {
            
            //#line 339 "x10/array/BlockingUtils.x10"
            t$104431 = 0L;
        } else {
            
            //#line 339 "x10/array/BlockingUtils.x10"
            final long t$104428 = ((i) - (((long)(min0))));
            
            //#line 339 "x10/array/BlockingUtils.x10"
            final long t$104429 = ((t$104428) * (((long)(divisions0))));
            
            //#line 339 "x10/array/BlockingUtils.x10"
            t$104431 = ((t$104429) / (((long)(size0))));
        }
        
        //#line 340 "x10/array/BlockingUtils.x10"
        final boolean t$104434 = ((long) divisions1) == ((long) 1L);
        
        //#line 340 "x10/array/BlockingUtils.x10"
        long t$104435 =  0;
        
        //#line 340 "x10/array/BlockingUtils.x10"
        if (t$104434) {
            
            //#line 340 "x10/array/BlockingUtils.x10"
            t$104435 = 0L;
        } else {
            
            //#line 340 "x10/array/BlockingUtils.x10"
            final long t$104432 = ((j) - (((long)(min1))));
            
            //#line 340 "x10/array/BlockingUtils.x10"
            final long t$104433 = ((t$104432) * (((long)(divisions1))));
            
            //#line 340 "x10/array/BlockingUtils.x10"
            t$104435 = ((t$104433) / (((long)(size1))));
        }
        
        //#line 341 "x10/array/BlockingUtils.x10"
        final long t$104436 = ((t$104435) * (((long)(divisions0))));
        
        //#line 341 "x10/array/BlockingUtils.x10"
        final long blockIndex = ((t$104436) + (((long)(t$104431))));
        
        //#line 343 "x10/array/BlockingUtils.x10"
        final long t$104437 = ((leftOver) * (((long)(2L))));
        
        //#line 343 "x10/array/BlockingUtils.x10"
        final boolean t$104440 = ((blockIndex) <= (((long)(t$104437))));
        
        //#line 343 "x10/array/BlockingUtils.x10"
        if (t$104440) {
            
            //#line 344 "x10/array/BlockingUtils.x10"
            final long t$104438 = ((blockIndex) / (((long)(2L))));
            
            //#line 344 "x10/array/BlockingUtils.x10"
            return t$104438;
        } else {
            
            //#line 346 "x10/array/BlockingUtils.x10"
            final long t$104439 = ((blockIndex) - (((long)(leftOver))));
            
            //#line 346 "x10/array/BlockingUtils.x10"
            return t$104439;
        }
    }
    
    
    //#line 21 "x10/array/BlockingUtils.x10"
    final public x10.array.BlockingUtils x10$array$BlockingUtils$$this$x10$array$BlockingUtils() {
        
        //#line 21 "x10/array/BlockingUtils.x10"
        return x10.array.BlockingUtils.this;
    }
    
    
    //#line 21 "x10/array/BlockingUtils.x10"
    // creation method for java code (1-phase java constructor)
    public BlockingUtils() {
        this((java.lang.System[]) null);
        x10$array$BlockingUtils$$init$S();
    }
    
    // constructor for non-virtual call
    final public x10.array.BlockingUtils x10$array$BlockingUtils$$init$S() {
         {
            
            //#line 21 "x10/array/BlockingUtils.x10"
            
        }
        return this;
    }
    
    
    
    //#line 21 "x10/array/BlockingUtils.x10"
    final public void __fieldInitializers_x10_array_BlockingUtils() {
        
    }
    
    @x10.runtime.impl.java.X10Generated
    final public static class $Closure$0 extends x10.core.Ref implements x10.core.fun.Fun_0_1, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<$Closure$0> $RTT = 
            x10.rtt.StaticFunType.<$Closure$0> make($Closure$0.class,
                                                    new x10.rtt.Type[] {
                                                        x10.rtt.ParameterizedType.make(x10.core.fun.Fun_0_1.$RTT, x10.rtt.Types.LONG, x10.array.DenseIterationSpace_1.$RTT)
                                                    });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static x10.serialization.X10JavaSerializable $_deserialize_body(x10.array.BlockingUtils.$Closure$0 $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            $_obj.is = $deserializer.readObject();
            $_obj.n = $deserializer.readLong();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.array.BlockingUtils.$Closure$0 $_obj = new x10.array.BlockingUtils.$Closure$0((java.lang.System[]) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            $serializer.write(this.is);
            $serializer.write(this.n);
            
        }
        
        // constructor just for allocation
        public $Closure$0(final java.lang.System[] $dummy) {
            
        }
        
        // dispatcher for method abstract public (Z1)=>U.operator()(a1:Z1):U
        public java.lang.Object $apply(final java.lang.Object a1, final x10.rtt.Type t1) {
            return $apply(x10.core.Long.$unbox(a1));
            
        }
        
        
    
        
        public x10.array.DenseIterationSpace_1 $apply(final long i) {
            
            //#line 44 "x10/array/BlockingUtils.x10"
            final x10.array.DenseIterationSpace_1 t$104290 = ((x10.array.DenseIterationSpace_1)(x10.array.BlockingUtils.partitionBlock(((x10.array.IterationSpace)(this.is)), (long)(this.n), (long)(i))));
            
            //#line 44 "x10/array/BlockingUtils.x10"
            return t$104290;
        }
        
        public x10.array.IterationSpace is;
        public long n;
        
        public $Closure$0(final x10.array.IterationSpace is, final long n) {
             {
                this.is = ((x10.array.IterationSpace)(is));
                this.n = n;
            }
        }
        
    }
    
    @x10.runtime.impl.java.X10Generated
    final public static class $Closure$1 extends x10.core.Ref implements x10.core.fun.Fun_0_1, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<$Closure$1> $RTT = 
            x10.rtt.StaticFunType.<$Closure$1> make($Closure$1.class,
                                                    new x10.rtt.Type[] {
                                                        x10.rtt.ParameterizedType.make(x10.core.fun.Fun_0_1.$RTT, x10.rtt.Types.LONG, x10.array.DenseIterationSpace_2.$RTT)
                                                    });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static x10.serialization.X10JavaSerializable $_deserialize_body(x10.array.BlockingUtils.$Closure$1 $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            $_obj.is = $deserializer.readObject();
            $_obj.n = $deserializer.readLong();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.array.BlockingUtils.$Closure$1 $_obj = new x10.array.BlockingUtils.$Closure$1((java.lang.System[]) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            $serializer.write(this.is);
            $serializer.write(this.n);
            
        }
        
        // constructor just for allocation
        public $Closure$1(final java.lang.System[] $dummy) {
            
        }
        
        // dispatcher for method abstract public (Z1)=>U.operator()(a1:Z1):U
        public java.lang.Object $apply(final java.lang.Object a1, final x10.rtt.Type t1) {
            return $apply(x10.core.Long.$unbox(a1));
            
        }
        
        
    
        
        public x10.array.DenseIterationSpace_2 $apply(final long i) {
            
            //#line 180 "x10/array/BlockingUtils.x10"
            final x10.array.DenseIterationSpace_2 t$104321 = ((x10.array.DenseIterationSpace_2)(x10.array.BlockingUtils.partitionBlockBlock(((x10.array.IterationSpace)(this.is)), (long)(this.n), (long)(i))));
            
            //#line 180 "x10/array/BlockingUtils.x10"
            return t$104321;
        }
        
        public x10.array.IterationSpace is;
        public long n;
        
        public $Closure$1(final x10.array.IterationSpace is, final long n) {
             {
                this.is = ((x10.array.IterationSpace)(is));
                this.n = n;
            }
        }
        
    }
    
}

