package x10.array;


/**
 * Represents the distribution of the Points of an IterationSpace(1) 
 * over the Places in its PlaceGroup in a 1-D blocked fashion.
 */
@x10.runtime.impl.java.X10Generated
public class Dist_Block_1 extends x10.array.Dist implements x10.serialization.X10JavaSerializable
{
    public static final x10.rtt.RuntimeType<Dist_Block_1> $RTT = 
        x10.rtt.NamedType.<Dist_Block_1> make("x10.array.Dist_Block_1",
                                              Dist_Block_1.class,
                                              new x10.rtt.Type[] {
                                                  x10.array.Dist.$RTT
                                              });
    
    public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
    
    public x10.rtt.Type<?> $getParam(int i) { return null; }
    
    private Object writeReplace() throws java.io.ObjectStreamException {
        return new x10.serialization.SerializationProxy(this);
    }
    
    public static x10.serialization.X10JavaSerializable $_deserialize_body(x10.array.Dist_Block_1 $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
        x10.array.Dist.$_deserialize_body($_obj, $deserializer);
        $_obj.globalIndices = $deserializer.readObject();
        
        /* fields with @TransientInitExpr annotations */
        $_obj.localIndices = $_obj.computeLocalIndices();
        
        return $_obj;
    }
    
    public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
        x10.array.Dist_Block_1 $_obj = new x10.array.Dist_Block_1((java.lang.System[]) null);
        $deserializer.record_reference($_obj);
        return $_deserialize_body($_obj, $deserializer);
    }
    
    public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
        super.$_serialize($serializer);
        $serializer.write(this.globalIndices);
        
    }
    
    // constructor just for allocation
    public Dist_Block_1(final java.lang.System[] $dummy) {
        super($dummy);
        
    }
    
    

    
    //#line 22 "x10/array/Dist_Block_1.x10"
    public x10.array.DenseIterationSpace_1 globalIndices;
    
    //#line 25 "x10/array/Dist_Block_1.x10"
    public transient x10.array.DenseIterationSpace_1 localIndices;
    
    
    //#line 26 "x10/array/Dist_Block_1.x10"
    final public x10.array.DenseIterationSpace_1 computeLocalIndices() {
        
        //#line 27 "x10/array/Dist_Block_1.x10"
        final x10.array.DenseIterationSpace_1 t$110328 = ((x10.array.DenseIterationSpace_1)(this.globalIndices));
        
        //#line 27 "x10/array/Dist_Block_1.x10"
        final x10.lang.PlaceGroup t$110326 = ((x10.lang.PlaceGroup)(this.pg));
        
        //#line 27 "x10/array/Dist_Block_1.x10"
        final long t$110329 = t$110326.numPlaces$O();
        
        //#line 27 "x10/array/Dist_Block_1.x10"
        final x10.lang.PlaceGroup t$110327 = ((x10.lang.PlaceGroup)(this.pg));
        
        //#line 27 "x10/array/Dist_Block_1.x10"
        final long t$110330 = t$110327.indexOf$O(((x10.lang.Place)(x10.x10rt.X10RT.here())));
        
        //#line 27 "x10/array/Dist_Block_1.x10"
        final x10.array.DenseIterationSpace_1 t$110331 = ((x10.array.DenseIterationSpace_1)(x10.array.BlockingUtils.partitionBlock(((x10.array.IterationSpace)(t$110328)), (long)(t$110329), (long)(t$110330))));
        
        //#line 27 "x10/array/Dist_Block_1.x10"
        return t$110331;
    }
    
    
    //#line 30 "x10/array/Dist_Block_1.x10"
    // creation method for java code (1-phase java constructor)
    public Dist_Block_1(final x10.lang.PlaceGroup pg, final x10.array.DenseIterationSpace_1 is) {
        this((java.lang.System[]) null);
        x10$array$Dist_Block_1$$init$S(pg, is);
    }
    
    // constructor for non-virtual call
    final public x10.array.Dist_Block_1 x10$array$Dist_Block_1$$init$S(final x10.lang.PlaceGroup pg, final x10.array.DenseIterationSpace_1 is) {
         {
            
            //#line 31 "x10/array/Dist_Block_1.x10"
            final x10.array.Dist this$110321 = ((x10.array.Dist)(this));
            
            //#line 31 "x10/array/Dist_Block_1.x10"
            final x10.array.IterationSpace is$110320 = ((x10.array.IterationSpace)(((x10.array.IterationSpace)
                                                                                     is)));
            
            //#line 26 . "x10/array/Dist.x10"
            this$110321.pg = ((x10.lang.PlaceGroup)(pg));
            
            //#line 26 . "x10/array/Dist.x10"
            this$110321.is = ((x10.array.IterationSpace)(is$110320));
            
            //#line 30 "x10/array/Dist_Block_1.x10"
            
            
            //#line 32 "x10/array/Dist_Block_1.x10"
            this.globalIndices = ((x10.array.DenseIterationSpace_1)(is));
            
            //#line 33 "x10/array/Dist_Block_1.x10"
            final x10.array.DenseIterationSpace_1 t$110332 = ((x10.array.DenseIterationSpace_1)(this.computeLocalIndices()));
            
            //#line 33 "x10/array/Dist_Block_1.x10"
            this.localIndices = ((x10.array.DenseIterationSpace_1)(t$110332));
        }
        return this;
    }
    
    
    
    //#line 21 "x10/array/Dist_Block_1.x10"
    final public x10.array.Dist_Block_1 x10$array$Dist_Block_1$$this$x10$array$Dist_Block_1() {
        
        //#line 21 "x10/array/Dist_Block_1.x10"
        return x10.array.Dist_Block_1.this;
    }
    
    
    //#line 21 "x10/array/Dist_Block_1.x10"
    final public void __fieldInitializers_x10_array_Dist_Block_1() {
        
    }
}

