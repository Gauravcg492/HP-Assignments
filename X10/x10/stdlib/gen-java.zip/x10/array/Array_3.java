package x10.array;


/**
 * Implementation of 3-dimensional Array using row-major ordering.
 */
@x10.runtime.impl.java.X10Generated
final public class Array_3<$T> extends x10.array.Array<$T> implements x10.core.fun.Fun_0_3, x10.serialization.X10JavaSerializable
{
    public static final x10.rtt.RuntimeType<Array_3> $RTT = 
        x10.rtt.NamedType.<Array_3> make("x10.array.Array_3",
                                         Array_3.class,
                                         1,
                                         new x10.rtt.Type[] {
                                             x10.rtt.ParameterizedType.make(x10.core.fun.Fun_0_3.$RTT, x10.rtt.Types.LONG, x10.rtt.Types.LONG, x10.rtt.Types.LONG, x10.rtt.UnresolvedType.PARAM(0)),
                                             x10.rtt.ParameterizedType.make(x10.array.Array.$RTT, x10.rtt.UnresolvedType.PARAM(0))
                                         });
    
    public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
    
    public x10.rtt.Type<?> $getParam(int i) { if (i == 0) return $T; return null; }
    
    private Object writeReplace() throws java.io.ObjectStreamException {
        return new x10.serialization.SerializationProxy(this);
    }
    
    public static <$T> x10.serialization.X10JavaSerializable $_deserialize_body(x10.array.Array_3<$T> $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
        x10.array.Array.$_deserialize_body($_obj, $deserializer);
        $_obj.$T = (x10.rtt.Type) $deserializer.readObject();
        $_obj.numElems_1 = $deserializer.readLong();
        $_obj.numElems_2 = $deserializer.readLong();
        $_obj.numElems_3 = $deserializer.readLong();
        return $_obj;
    }
    
    public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
        x10.array.Array_3 $_obj = new x10.array.Array_3((java.lang.System[]) null, (x10.rtt.Type) null);
        $deserializer.record_reference($_obj);
        return $_deserialize_body($_obj, $deserializer);
    }
    
    public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
        super.$_serialize($serializer);
        $serializer.write(this.$T);
        $serializer.write(this.numElems_1);
        $serializer.write(this.numElems_2);
        $serializer.write(this.numElems_3);
        
    }
    
    // constructor just for allocation
    public Array_3(final java.lang.System[] $dummy, final x10.rtt.Type $T) {
        super($dummy, $T);
        x10.array.Array_3.$initParams(this, $T);
        
    }
    
    // dispatcher for method abstract public (Z1,Z2,Z3)=>U.operator()(a1:Z1, a2:Z2, a3:Z3){}:U
    public java.lang.Object $apply(final java.lang.Object a1, final x10.rtt.Type t1, final java.lang.Object a2, final x10.rtt.Type t2, final java.lang.Object a3, final x10.rtt.Type t3) {
        return $apply$G(x10.core.Long.$unbox(a1), x10.core.Long.$unbox(a2), x10.core.Long.$unbox(a3));
        
    }
    
    // bridge for method abstract public x10.array.Array[T].operator()=(p:x10.lang.Point{self.rank==this(:x10.array.Array).rank()}, v:T){}:T{self==v}
    public $T $set__1x10$array$Array$$T$G(x10.lang.Point a1, $T a2) {
        return $set__1x10$array$Array_3$$T$G(a1, a2);
    }
    
    private x10.rtt.Type $T;
    
    // initializer of type parameters
    public static void $initParams(final Array_3 $this, final x10.rtt.Type $T) {
        $this.$T = $T;
        
    }
    // synthetic type for parameter mangling
    public static final class __3x10$array$Array_3$$T {}
    // synthetic type for parameter mangling
    public static final class __3$1x10$lang$Long$3x10$lang$Long$3x10$lang$Long$3x10$array$Array_3$$T$2 {}
    // synthetic type for parameter mangling
    public static final class __0$1x10$array$Array_3$$T$2 {}
    
    // properties
    
    //#line 25 "x10/array/Array_3.x10"
    /**
         * The number of elements in rank 1 (indexed 0..(numElems_1-1))
         */
    public long numElems_1;
    
    //#line 30 "x10/array/Array_3.x10"
    /**
         * The number of elements in rank 2 (indexed 0..(numElems_2-1)).
         */
    public long numElems_2;
    
    //#line 35 "x10/array/Array_3.x10"
    /**
         * The number of elements in rank 3 (indexed 0..(numElems_3-1)).
         */
    public long numElems_3;
    

    
    
    //#line 41 "x10/array/Array_3.x10"
    /**
     * @return the rank (dimensionality) of the Array
     */
    final public long rank$O() {
        
        //#line 41 "x10/array/Array_3.x10"
        return 3L;
    }
    
    
    //#line 47 "x10/array/Array_3.x10"
    /**
     * Construct a 3-dimensional array with indices [0..m-1][0..n-1][0..p-1] 
     * whose elements are zero-initialized.
     */
    // creation method for java code (1-phase java constructor)
    public Array_3(final x10.rtt.Type $T, final long m, final long n, final long p) {
        this((java.lang.System[]) null, $T);
        x10$array$Array_3$$init$S(m, n, p);
    }
    
    // constructor for non-virtual call
    final public x10.array.Array_3<$T> x10$array$Array_3$$init$S(final long m, final long n, final long p) {
         {
            
            //#line 214 . "x10/array/Array_3.x10"
            boolean t$100970 = ((m) < (((long)(0L))));
            
            //#line 214 . "x10/array/Array_3.x10"
            if (!(t$100970)) {
                
                //#line 214 . "x10/array/Array_3.x10"
                t$100970 = ((n) < (((long)(0L))));
            }
            
            //#line 214 . "x10/array/Array_3.x10"
            boolean t$100971 = t$100970;
            
            //#line 214 . "x10/array/Array_3.x10"
            if (!(t$100970)) {
                
                //#line 214 . "x10/array/Array_3.x10"
                t$100971 = ((p) < (((long)(0L))));
            }
            
            //#line 214 . "x10/array/Array_3.x10"
            if (t$100971) {
                
                //#line 214 . "x10/array/Array_3.x10"
                x10.array.Array.raiseNegativeArraySizeException();
            }
            
            //#line 215 . "x10/array/Array_3.x10"
            final long t$100973 = ((m) * (((long)(n))));
            
            //#line 215 . "x10/array/Array_3.x10"
            final long t$100974 = ((t$100973) * (((long)(p))));
            
            //#line 48 "x10/array/Array_3.x10"
            /*super.*/x10$array$Array$$init$S(t$100974, ((boolean)(true)));
            
            //#line 49 "x10/array/Array_3.x10"
            this.numElems_1 = m;
            this.numElems_2 = n;
            this.numElems_3 = p;
            
        }
        return this;
    }
    
    
    
    //#line 56 "x10/array/Array_3.x10"
    /**
     * Construct a 3-dimensional array with indices [0..m-1][0..n-1][0..p-1] 
     * whose elements are initialized to init.
     */
    // creation method for java code (1-phase java constructor)
    public Array_3(final x10.rtt.Type $T, final long m, final long n, final long p, final $T init, __3x10$array$Array_3$$T $dummy) {
        this((java.lang.System[]) null, $T);
        x10$array$Array_3$$init$S(m, n, p, init, (x10.array.Array_3.__3x10$array$Array_3$$T) null);
    }
    
    // constructor for non-virtual call
    final public x10.array.Array_3<$T> x10$array$Array_3$$init$S(final long m, final long n, final long p, final $T init, __3x10$array$Array_3$$T $dummy) {
         {
            
            //#line 214 . "x10/array/Array_3.x10"
            boolean t$100979 = ((m) < (((long)(0L))));
            
            //#line 214 . "x10/array/Array_3.x10"
            if (!(t$100979)) {
                
                //#line 214 . "x10/array/Array_3.x10"
                t$100979 = ((n) < (((long)(0L))));
            }
            
            //#line 214 . "x10/array/Array_3.x10"
            boolean t$100980 = t$100979;
            
            //#line 214 . "x10/array/Array_3.x10"
            if (!(t$100979)) {
                
                //#line 214 . "x10/array/Array_3.x10"
                t$100980 = ((p) < (((long)(0L))));
            }
            
            //#line 214 . "x10/array/Array_3.x10"
            if (t$100980) {
                
                //#line 214 . "x10/array/Array_3.x10"
                x10.array.Array.raiseNegativeArraySizeException();
            }
            
            //#line 215 . "x10/array/Array_3.x10"
            final long t$100982 = ((m) * (((long)(n))));
            
            //#line 215 . "x10/array/Array_3.x10"
            final long t$100983 = ((t$100982) * (((long)(p))));
            
            //#line 57 "x10/array/Array_3.x10"
            /*super.*/x10$array$Array$$init$S(t$100983, ((boolean)(false)));
            
            //#line 58 "x10/array/Array_3.x10"
            this.numElems_1 = m;
            this.numElems_2 = n;
            this.numElems_3 = p;
            
            
            //#line 59 "x10/array/Array_3.x10"
            final x10.core.Rail t$100794 = ((x10.core.Rail)(this.raw));
            
            //#line 59 "x10/array/Array_3.x10"
            ((x10.core.Rail<$T>)t$100794).fill__0x10$lang$Rail$$T((($T)(init)));
        }
        return this;
    }
    
    
    
    //#line 66 "x10/array/Array_3.x10"
    /**
     * Construct a 3-dimensional array with indices [0..m-1][0..n-1][0..p-1] 
     * whose elements are initialized to the value returned by the init closure for each index.
     */
    // creation method for java code (1-phase java constructor)
    public Array_3(final x10.rtt.Type $T, final long m, final long n, final long p, final x10.core.fun.Fun_0_3<x10.core.Long,x10.core.Long,x10.core.Long,$T> init, __3$1x10$lang$Long$3x10$lang$Long$3x10$lang$Long$3x10$array$Array_3$$T$2 $dummy) {
        this((java.lang.System[]) null, $T);
        x10$array$Array_3$$init$S(m, n, p, init, (x10.array.Array_3.__3$1x10$lang$Long$3x10$lang$Long$3x10$lang$Long$3x10$array$Array_3$$T$2) null);
    }
    
    // constructor for non-virtual call
    final public x10.array.Array_3<$T> x10$array$Array_3$$init$S(final long m, final long n, final long p, final x10.core.fun.Fun_0_3<x10.core.Long,x10.core.Long,x10.core.Long,$T> init, __3$1x10$lang$Long$3x10$lang$Long$3x10$lang$Long$3x10$array$Array_3$$T$2 $dummy) {
         {
            
            //#line 214 . "x10/array/Array_3.x10"
            boolean t$101020 = ((m) < (((long)(0L))));
            
            //#line 214 . "x10/array/Array_3.x10"
            if (!(t$101020)) {
                
                //#line 214 . "x10/array/Array_3.x10"
                t$101020 = ((n) < (((long)(0L))));
            }
            
            //#line 214 . "x10/array/Array_3.x10"
            boolean t$101021 = t$101020;
            
            //#line 214 . "x10/array/Array_3.x10"
            if (!(t$101020)) {
                
                //#line 214 . "x10/array/Array_3.x10"
                t$101021 = ((p) < (((long)(0L))));
            }
            
            //#line 214 . "x10/array/Array_3.x10"
            if (t$101021) {
                
                //#line 214 . "x10/array/Array_3.x10"
                x10.array.Array.raiseNegativeArraySizeException();
            }
            
            //#line 215 . "x10/array/Array_3.x10"
            final long t$101023 = ((m) * (((long)(n))));
            
            //#line 215 . "x10/array/Array_3.x10"
            final long t$101024 = ((t$101023) * (((long)(p))));
            
            //#line 67 "x10/array/Array_3.x10"
            /*super.*/x10$array$Array$$init$S(t$101024, ((boolean)(false)));
            
            //#line 68 "x10/array/Array_3.x10"
            this.numElems_1 = m;
            this.numElems_2 = n;
            this.numElems_3 = p;
            
            
            //#line 69 "x10/array/Array_3.x10"
            final long i$100197max$101026 = ((m) - (((long)(1L))));
            
            //#line 69 "x10/array/Array_3.x10"
            long i$101014 = 0L;
            
            //#line 69 "x10/array/Array_3.x10"
            for (;
                 true;
                 ) {
                
                //#line 69 "x10/array/Array_3.x10"
                final boolean t$101016 = ((i$101014) <= (((long)(i$100197max$101026))));
                
                //#line 69 "x10/array/Array_3.x10"
                if (!(t$101016)) {
                    
                    //#line 69 "x10/array/Array_3.x10"
                    break;
                }
                
                //#line 70 "x10/array/Array_3.x10"
                final long i$100179max$101010 = ((n) - (((long)(1L))));
                
                //#line 70 "x10/array/Array_3.x10"
                long i$101007 = 0L;
                
                //#line 70 "x10/array/Array_3.x10"
                for (;
                     true;
                     ) {
                    
                    //#line 70 "x10/array/Array_3.x10"
                    final boolean t$101009 = ((i$101007) <= (((long)(i$100179max$101010))));
                    
                    //#line 70 "x10/array/Array_3.x10"
                    if (!(t$101009)) {
                        
                        //#line 70 "x10/array/Array_3.x10"
                        break;
                    }
                    
                    //#line 71 "x10/array/Array_3.x10"
                    final long i$100161max$101003 = ((p) - (((long)(1L))));
                    
                    //#line 71 "x10/array/Array_3.x10"
                    long i$101000 = 0L;
                    
                    //#line 71 "x10/array/Array_3.x10"
                    for (;
                         true;
                         ) {
                        
                        //#line 71 "x10/array/Array_3.x10"
                        final boolean t$101002 = ((i$101000) <= (((long)(i$100161max$101003))));
                        
                        //#line 71 "x10/array/Array_3.x10"
                        if (!(t$101002)) {
                            
                            //#line 71 "x10/array/Array_3.x10"
                            break;
                        }
                        
                        //#line 72 "x10/array/Array_3.x10"
                        final x10.core.Rail t$100985 = ((x10.core.Rail)(this.raw));
                        
                        //#line 72 "x10/array/Array_3.x10"
                        final x10.array.Array_3 this$100986 = ((x10.array.Array_3)(this));
                        
                        //#line 151 . "x10/array/Array_3.x10"
                        final long t$100990 = ((x10.array.Array_3<$T>)this$100986).numElems_3;
                        
                        //#line 151 . "x10/array/Array_3.x10"
                        final long t$100991 = ((x10.array.Array_3<$T>)this$100986).numElems_2;
                        
                        //#line 151 . "x10/array/Array_3.x10"
                        final long t$100992 = ((i$101014) * (((long)(t$100991))));
                        
                        //#line 151 . "x10/array/Array_3.x10"
                        final long t$100993 = ((i$101007) + (((long)(t$100992))));
                        
                        //#line 151 . "x10/array/Array_3.x10"
                        final long t$100994 = ((t$100990) * (((long)(t$100993))));
                        
                        //#line 151 . "x10/array/Array_3.x10"
                        final long t$100995 = ((i$101000) + (((long)(t$100994))));
                        
                        //#line 72 "x10/array/Array_3.x10"
                        final $T t$100996 = (($T)((($T)
                                                    ((x10.core.fun.Fun_0_3<x10.core.Long,x10.core.Long,x10.core.Long,$T>)init).$apply(x10.core.Long.$box(i$101014), x10.rtt.Types.LONG, x10.core.Long.$box(i$101007), x10.rtt.Types.LONG, x10.core.Long.$box(i$101000), x10.rtt.Types.LONG))));
                        
                        //#line 72 "x10/array/Array_3.x10"
                        ((x10.core.Rail<$T>)t$100985).$set__1x10$lang$Rail$$T$G((long)(t$100995), (($T)(t$100996)));
                        
                        //#line 71 "x10/array/Array_3.x10"
                        final long t$100999 = ((i$101000) + (((long)(1L))));
                        
                        //#line 71 "x10/array/Array_3.x10"
                        i$101000 = t$100999;
                    }
                    
                    //#line 70 "x10/array/Array_3.x10"
                    final long t$101006 = ((i$101007) + (((long)(1L))));
                    
                    //#line 70 "x10/array/Array_3.x10"
                    i$101007 = t$101006;
                }
                
                //#line 69 "x10/array/Array_3.x10"
                final long t$101013 = ((i$101014) + (((long)(1L))));
                
                //#line 69 "x10/array/Array_3.x10"
                i$101014 = t$101013;
            }
        }
        return this;
    }
    
    
    
    //#line 82 "x10/array/Array_3.x10"
    /**
     * Construct a new 3-dimensional array by copying all elements of src
     * @param src The source array to copy
     */
    // creation method for java code (1-phase java constructor)
    public Array_3(final x10.rtt.Type $T, final x10.array.Array_3<$T> src, __0$1x10$array$Array_3$$T$2 $dummy) {
        this((java.lang.System[]) null, $T);
        x10$array$Array_3$$init$S(src, (x10.array.Array_3.__0$1x10$array$Array_3$$T$2) null);
    }
    
    // constructor for non-virtual call
    final public x10.array.Array_3<$T> x10$array$Array_3$$init$S(final x10.array.Array_3<$T> src, __0$1x10$array$Array_3$$T$2 $dummy) {
         {
            
            //#line 83 "x10/array/Array_3.x10"
            final x10.array.Array this$100292 = ((x10.array.Array)(this));
            
            //#line 83 "x10/array/Array_3.x10"
            final x10.core.Rail t$100823 = ((x10.core.Rail)(((x10.array.Array<$T>)src).raw));
            
            //#line 83 "x10/array/Array_3.x10"
            final x10.core.Rail r$100291 = ((x10.core.Rail)(new x10.core.Rail<$T>($T, ((x10.core.Rail)(t$100823)), (x10.core.Rail.__0$1x10$lang$Rail$$T$2) null)));
            
            //#line 65 . "x10/array/Array.x10"
            final long t$101027 = ((x10.core.Rail<$T>)r$100291).size;
            
            //#line 65 . "x10/array/Array.x10"
            ((x10.array.Array<$T>)this$100292).size = t$101027;
            
            //#line 66 . "x10/array/Array.x10"
            ((x10.array.Array<$T>)this$100292).raw = ((x10.core.Rail)(r$100291));
            
            //#line 84 "x10/array/Array_3.x10"
            final long t$101028 = ((x10.array.Array_3<$T>)src).numElems_1;
            
            //#line 84 "x10/array/Array_3.x10"
            final long t$101029 = ((x10.array.Array_3<$T>)src).numElems_2;
            
            //#line 84 "x10/array/Array_3.x10"
            final long t$101030 = ((x10.array.Array_3<$T>)src).numElems_3;
            
            //#line 84 "x10/array/Array_3.x10"
            this.numElems_1 = t$101028;
            this.numElems_2 = t$101029;
            this.numElems_3 = t$101030;
            
        }
        return this;
    }
    
    
    
    //#line 88 "x10/array/Array_3.x10"
    // creation method for java code (1-phase java constructor)
    public Array_3(final x10.rtt.Type $T, final x10.core.Rail<$T> r, final long m, final long n, final long p, __0$1x10$array$Array_3$$T$2 $dummy) {
        this((java.lang.System[]) null, $T);
        x10$array$Array_3$$init$S(r, m, n, p, (x10.array.Array_3.__0$1x10$array$Array_3$$T$2) null);
    }
    
    // constructor for non-virtual call
    final public x10.array.Array_3<$T> x10$array$Array_3$$init$S(final x10.core.Rail<$T> r, final long m, final long n, final long p, __0$1x10$array$Array_3$$T$2 $dummy) {
         {
            
            //#line 89 "x10/array/Array_3.x10"
            final x10.array.Array this$100298 = ((x10.array.Array)(this));
            
            //#line 65 . "x10/array/Array.x10"
            final long t$101032 = ((x10.core.Rail<$T>)r).size;
            
            //#line 65 . "x10/array/Array.x10"
            ((x10.array.Array<$T>)this$100298).size = t$101032;
            
            //#line 66 . "x10/array/Array.x10"
            ((x10.array.Array<$T>)this$100298).raw = ((x10.core.Rail)(r));
            
            //#line 90 "x10/array/Array_3.x10"
            this.numElems_1 = m;
            this.numElems_2 = n;
            this.numElems_3 = p;
            
        }
        return this;
    }
    
    
    
    //#line 96 "x10/array/Array_3.x10"
    /**
     * Construct an Array_3 view over an existing Rail
     */
    public static <$T>x10.array.Array_3 makeView__0$1x10$array$Array_3$$T$2(final x10.rtt.Type $T, final x10.core.Rail<$T> r, final long m, final long n, final long p) {
        
        //#line 97 "x10/array/Array_3.x10"
        final long t$100829 = ((n) * (((long)(m))));
        
        //#line 97 "x10/array/Array_3.x10"
        final long size = ((t$100829) * (((long)(p))));
        
        //#line 98 "x10/array/Array_3.x10"
        final long t$100830 = ((x10.core.Rail<$T>)r).size;
        
        //#line 98 "x10/array/Array_3.x10"
        final boolean t$100840 = ((long) size) != ((long) t$100830);
        
        //#line 98 "x10/array/Array_3.x10"
        if (t$100840) {
            
            //#line 98 "x10/array/Array_3.x10"
            final java.lang.String t$100831 = (("size mismatch: ") + ((x10.core.Long.$box(m))));
            
            //#line 98 "x10/array/Array_3.x10"
            final java.lang.String t$100832 = ((t$100831) + (" * "));
            
            //#line 98 "x10/array/Array_3.x10"
            final java.lang.String t$100833 = ((t$100832) + ((x10.core.Long.$box(n))));
            
            //#line 98 "x10/array/Array_3.x10"
            final java.lang.String t$100834 = ((t$100833) + (" * "));
            
            //#line 98 "x10/array/Array_3.x10"
            final java.lang.String t$100835 = ((t$100834) + ((x10.core.Long.$box(p))));
            
            //#line 98 "x10/array/Array_3.x10"
            final java.lang.String t$100836 = ((t$100835) + (" != "));
            
            //#line 98 "x10/array/Array_3.x10"
            final long t$100837 = ((x10.core.Rail<$T>)r).size;
            
            //#line 98 "x10/array/Array_3.x10"
            final java.lang.String t$100838 = ((t$100836) + ((x10.core.Long.$box(t$100837))));
            
            //#line 98 "x10/array/Array_3.x10"
            final x10.lang.IllegalOperationException t$100839 = ((x10.lang.IllegalOperationException)(new x10.lang.IllegalOperationException(t$100838)));
            
            //#line 98 "x10/array/Array_3.x10"
            throw t$100839;
        }
        
        //#line 99 "x10/array/Array_3.x10"
        final x10.array.Array_3 alloc$100158 = ((x10.array.Array_3)(new x10.array.Array_3<$T>((java.lang.System[]) null, $T)));
        
        //#line 99 "x10/array/Array_3.x10"
        alloc$100158.x10$array$Array_3$$init$S(((x10.core.Rail)(r)), ((long)(m)), ((long)(n)), ((long)(p)), (x10.array.Array_3.__0$1x10$array$Array_3$$T$2) null);
        
        //#line 99 "x10/array/Array_3.x10"
        return alloc$100158;
    }
    
    
    //#line 108 "x10/array/Array_3.x10"
    /**
     * Return the string representation of this array.
     * 
     * @return the string representation of this array.
     */
    public java.lang.String toString() {
        
        //#line 109 "x10/array/Array_3.x10"
        final java.lang.String t$100841 = this.toString((long)(10L));
        
        //#line 109 "x10/array/Array_3.x10"
        return t$100841;
    }
    
    
    //#line 118 "x10/array/Array_3.x10"
    /**
     * Return the string representation of this array.
     *
     * @param limit maximum number of elements to print
     * @return the string representation of this array.
     */
    public java.lang.String toString(final long limit) {
        
        //#line 119 "x10/array/Array_3.x10"
        final x10.util.StringBuilder sb = ((x10.util.StringBuilder)(new x10.util.StringBuilder((java.lang.System[]) null)));
        
        //#line 119 "x10/array/Array_3.x10"
        sb.x10$util$StringBuilder$$init$S();
        
        //#line 120 "x10/array/Array_3.x10"
        sb.add(((java.lang.String)("[")));
        
        //#line 121 "x10/array/Array_3.x10"
        long printed = 0L;
        
        //#line 122 "x10/array/Array_3.x10"
        final long t$101091 = this.numElems_1;
        
        //#line 122 "x10/array/Array_3.x10"
        final long i$100251max$101092 = ((t$101091) - (((long)(1L))));
        
        //#line 122 "x10/array/Array_3.x10"
        long i$101087 = 0L;
        
        //#line 122 "x10/array/Array_3.x10"
        outer$101088: 
        //#line 122 "x10/array/Array_3.x10"
        for (;
             true;
             ) {
            
            //#line 122 "x10/array/Array_3.x10"
            final boolean t$101090 = ((i$101087) <= (((long)(i$100251max$101092))));
            
            //#line 122 "x10/array/Array_3.x10"
            if (!(t$101090)) {
                
                //#line 122 "x10/array/Array_3.x10"
                break;
            }
            
            //#line 123 "x10/array/Array_3.x10"
            final long t$101082 = this.numElems_2;
            
            //#line 123 "x10/array/Array_3.x10"
            final long i$100233max$101083 = ((t$101082) - (((long)(1L))));
            
            //#line 123 "x10/array/Array_3.x10"
            long i$101079 = 0L;
            
            //#line 123 "x10/array/Array_3.x10"
            for (;
                 true;
                 ) {
                
                //#line 123 "x10/array/Array_3.x10"
                final boolean t$101081 = ((i$101079) <= (((long)(i$100233max$101083))));
                
                //#line 123 "x10/array/Array_3.x10"
                if (!(t$101081)) {
                    
                    //#line 123 "x10/array/Array_3.x10"
                    break;
                }
                
                //#line 124 "x10/array/Array_3.x10"
                final long t$101069 = this.numElems_3;
                
                //#line 124 "x10/array/Array_3.x10"
                final long i$100215max$101070 = ((t$101069) - (((long)(1L))));
                
                //#line 124 "x10/array/Array_3.x10"
                long i$101066 = 0L;
                
                //#line 124 "x10/array/Array_3.x10"
                for (;
                     true;
                     ) {
                    
                    //#line 124 "x10/array/Array_3.x10"
                    final boolean t$101068 = ((i$101066) <= (((long)(i$100215max$101070))));
                    
                    //#line 124 "x10/array/Array_3.x10"
                    if (!(t$101068)) {
                        
                        //#line 124 "x10/array/Array_3.x10"
                        break;
                    }
                    
                    //#line 125 "x10/array/Array_3.x10"
                    final boolean t$101034 = ((long) i$101066) != ((long) 0L);
                    
                    //#line 125 "x10/array/Array_3.x10"
                    if (t$101034) {
                        
                        //#line 125 "x10/array/Array_3.x10"
                        sb.add(((java.lang.String)(", ")));
                    }
                    
                    //#line 126 "x10/array/Array_3.x10"
                    final x10.array.Array_3 this$101035 = ((x10.array.Array_3)(this));
                    
                    //#line 164 . "x10/array/Array_3.x10"
                    boolean t$101039 = ((i$101087) < (((long)(0L))));
                    
                    //#line 164 . "x10/array/Array_3.x10"
                    if (!(t$101039)) {
                        
                        //#line 164 . "x10/array/Array_3.x10"
                        final long t$101040 = ((x10.array.Array_3<$T>)this$101035).numElems_1;
                        
                        //#line 164 . "x10/array/Array_3.x10"
                        t$101039 = ((i$101087) >= (((long)(t$101040))));
                    }
                    
                    //#line 164 . "x10/array/Array_3.x10"
                    boolean t$101041 = t$101039;
                    
                    //#line 164 . "x10/array/Array_3.x10"
                    if (!(t$101039)) {
                        
                        //#line 164 . "x10/array/Array_3.x10"
                        t$101041 = ((i$101079) < (((long)(0L))));
                    }
                    
                    //#line 164 . "x10/array/Array_3.x10"
                    boolean t$101042 = t$101041;
                    
                    //#line 164 . "x10/array/Array_3.x10"
                    if (!(t$101041)) {
                        
                        //#line 165 . "x10/array/Array_3.x10"
                        final long t$101043 = ((x10.array.Array_3<$T>)this$101035).numElems_2;
                        
                        //#line 164 . "x10/array/Array_3.x10"
                        t$101042 = ((i$101079) >= (((long)(t$101043))));
                    }
                    
                    //#line 164 . "x10/array/Array_3.x10"
                    boolean t$101044 = t$101042;
                    
                    //#line 164 . "x10/array/Array_3.x10"
                    if (!(t$101042)) {
                        
                        //#line 164 . "x10/array/Array_3.x10"
                        t$101044 = ((i$101066) < (((long)(0L))));
                    }
                    
                    //#line 164 . "x10/array/Array_3.x10"
                    boolean t$101045 = t$101044;
                    
                    //#line 164 . "x10/array/Array_3.x10"
                    if (!(t$101044)) {
                        
                        //#line 166 . "x10/array/Array_3.x10"
                        final long t$101046 = ((x10.array.Array_3<$T>)this$101035).numElems_3;
                        
                        //#line 164 . "x10/array/Array_3.x10"
                        t$101045 = ((i$101066) >= (((long)(t$101046))));
                    }
                    
                    //#line 164 . "x10/array/Array_3.x10"
                    if (t$101045) {
                        
                        //#line 167 . "x10/array/Array_3.x10"
                        x10.array.Array.raiseBoundsError((long)(i$101087), (long)(i$101079), (long)(i$101066));
                    }
                    
                    //#line 169 . "x10/array/Array_3.x10"
                    final x10.core.Rail r$101048 = ((x10.core.Rail)(((x10.array.Array<$T>)this$101035).raw));
                    
                    //#line 151 .. "x10/array/Array_3.x10"
                    final long t$101052 = ((x10.array.Array_3<$T>)this$101035).numElems_3;
                    
                    //#line 151 .. "x10/array/Array_3.x10"
                    final long t$101053 = ((x10.array.Array_3<$T>)this$101035).numElems_2;
                    
                    //#line 151 .. "x10/array/Array_3.x10"
                    final long t$101054 = ((i$101087) * (((long)(t$101053))));
                    
                    //#line 151 .. "x10/array/Array_3.x10"
                    final long t$101055 = ((i$101079) + (((long)(t$101054))));
                    
                    //#line 151 .. "x10/array/Array_3.x10"
                    final long t$101056 = ((t$101052) * (((long)(t$101055))));
                    
                    //#line 169 . "x10/array/Array_3.x10"
                    final long i$101057 = ((i$101066) + (((long)(t$101056))));
                    
                    //#line 38 .. "x10/lang/Unsafe.x10"
                    final $T t$101058 = (($T)(((x10.core.Rail<$T>)r$101048).$apply$G((long)(i$101057))));
                    
                    //#line 126 "x10/array/Array_3.x10"
                    sb.add(((java.lang.Object)(t$101058)));
                    
                    //#line 127 "x10/array/Array_3.x10"
                    final long t$101060 = ((printed) + (((long)(1L))));
                    
                    //#line 127 "x10/array/Array_3.x10"
                    final long t$101061 = printed = t$101060;
                    
                    //#line 127 "x10/array/Array_3.x10"
                    final boolean t$101062 = ((t$101061) > (((long)(limit))));
                    
                    //#line 127 "x10/array/Array_3.x10"
                    if (t$101062) {
                        
                        //#line 127 "x10/array/Array_3.x10"
                        break outer$101088;
                    }
                    
                    //#line 124 "x10/array/Array_3.x10"
                    final long t$101065 = ((i$101066) + (((long)(1L))));
                    
                    //#line 124 "x10/array/Array_3.x10"
                    i$101066 = t$101065;
                }
                
                //#line 129 "x10/array/Array_3.x10"
                final long t$101071 = this.numElems_2;
                
                //#line 129 "x10/array/Array_3.x10"
                final long t$101072 = ((t$101071) - (((long)(1L))));
                
                //#line 129 "x10/array/Array_3.x10"
                final boolean t$101073 = ((long) i$101079) == ((long) t$101072);
                
                //#line 129 "x10/array/Array_3.x10"
                java.lang.String t$101074 =  null;
                
                //#line 129 "x10/array/Array_3.x10"
                if (t$101073) {
                    
                    //#line 129 "x10/array/Array_3.x10"
                    t$101074 = ";; ";
                } else {
                    
                    //#line 129 "x10/array/Array_3.x10"
                    t$101074 = "; ";
                }
                
                //#line 129 "x10/array/Array_3.x10"
                sb.add(((java.lang.String)(t$101074)));
                
                //#line 123 "x10/array/Array_3.x10"
                final long t$101078 = ((i$101079) + (((long)(1L))));
                
                //#line 123 "x10/array/Array_3.x10"
                i$101079 = t$101078;
            }
            
            //#line 122 "x10/array/Array_3.x10"
            final long t$101086 = ((i$101087) + (((long)(1L))));
            
            //#line 122 "x10/array/Array_3.x10"
            i$101087 = t$101086;
        }
        
        //#line 132 "x10/array/Array_3.x10"
        final long t$100885 = this.size;
        
        //#line 132 "x10/array/Array_3.x10"
        final boolean t$100890 = ((limit) < (((long)(t$100885))));
        
        //#line 132 "x10/array/Array_3.x10"
        if (t$100890) {
            
            //#line 133 "x10/array/Array_3.x10"
            final long t$100886 = this.size;
            
            //#line 133 "x10/array/Array_3.x10"
            final long t$100887 = ((t$100886) - (((long)(limit))));
            
            //#line 133 "x10/array/Array_3.x10"
            final java.lang.String t$100888 = (("...(omitted ") + ((x10.core.Long.$box(t$100887))));
            
            //#line 133 "x10/array/Array_3.x10"
            final java.lang.String t$100889 = ((t$100888) + (" elements)"));
            
            //#line 133 "x10/array/Array_3.x10"
            sb.add(((java.lang.String)(t$100889)));
        }
        
        //#line 135 "x10/array/Array_3.x10"
        sb.add(((java.lang.String)("]")));
        
        //#line 136 "x10/array/Array_3.x10"
        final java.lang.String t$100891 = sb.toString();
        
        //#line 136 "x10/array/Array_3.x10"
        return t$100891;
    }
    
    
    //#line 142 "x10/array/Array_3.x10"
    /**
     * @return an IterationSpace containing all valid Points for indexing this Array.
     */
    public x10.array.DenseIterationSpace_3 indices() {
        
        //#line 143 "x10/array/Array_3.x10"
        final x10.array.DenseIterationSpace_3 alloc$100159 = ((x10.array.DenseIterationSpace_3)(new x10.array.DenseIterationSpace_3((java.lang.System[]) null)));
        
        //#line 143 "x10/array/Array_3.x10"
        final long t$101093 = this.numElems_1;
        
        //#line 143 "x10/array/Array_3.x10"
        final long t$101094 = ((t$101093) - (((long)(1L))));
        
        //#line 143 "x10/array/Array_3.x10"
        final long t$101095 = this.numElems_2;
        
        //#line 143 "x10/array/Array_3.x10"
        final long t$101096 = ((t$101095) - (((long)(1L))));
        
        //#line 143 "x10/array/Array_3.x10"
        final long t$101097 = this.numElems_3;
        
        //#line 143 "x10/array/Array_3.x10"
        final long t$101098 = ((t$101097) - (((long)(1L))));
        
        //#line 143 "x10/array/Array_3.x10"
        alloc$100159.x10$array$DenseIterationSpace_3$$init$S(((long)(0L)), ((long)(0L)), ((long)(0L)), t$101094, t$101096, t$101098);
        
        //#line 143 "x10/array/Array_3.x10"
        return alloc$100159;
    }
    
    
    //#line 150 "x10/array/Array_3.x10"
    /**
     * Map a 3-D (i,j,k) index into a 1-D index into the backing Rail
     * returned by raw(). Uses row-major ordering.
     */
    public long offset$O(final long i, final long j, final long k) {
        
        //#line 151 "x10/array/Array_3.x10"
        final long t$100900 = this.numElems_3;
        
        //#line 151 "x10/array/Array_3.x10"
        final long t$100898 = this.numElems_2;
        
        //#line 151 "x10/array/Array_3.x10"
        final long t$100899 = ((i) * (((long)(t$100898))));
        
        //#line 151 "x10/array/Array_3.x10"
        final long t$100901 = ((j) + (((long)(t$100899))));
        
        //#line 151 "x10/array/Array_3.x10"
        final long t$100902 = ((t$100900) * (((long)(t$100901))));
        
        //#line 151 "x10/array/Array_3.x10"
        final long t$100903 = ((k) + (((long)(t$100902))));
        
        //#line 151 "x10/array/Array_3.x10"
        return t$100903;
    }
    
    
    //#line 163 "x10/array/Array_3.x10"
    /**
     * Return the element of this array corresponding to the given triple of indices.
     * 
     * @param i the given index in the first dimension
     * @param j the given index in the second dimension
     * @param k the given index in the third dimension
     * @return the element of this array corresponding to the given triple of indices.
     * @see #set(T, Long, Long, Long)
     */
    public $T $apply$G(final long i, final long j, final long k) {
        
        //#line 164 "x10/array/Array_3.x10"
        boolean t$100905 = ((i) < (((long)(0L))));
        
        //#line 164 "x10/array/Array_3.x10"
        if (!(t$100905)) {
            
            //#line 164 "x10/array/Array_3.x10"
            final long t$100904 = this.numElems_1;
            
            //#line 164 "x10/array/Array_3.x10"
            t$100905 = ((i) >= (((long)(t$100904))));
        }
        
        //#line 164 "x10/array/Array_3.x10"
        boolean t$100906 = t$100905;
        
        //#line 164 "x10/array/Array_3.x10"
        if (!(t$100905)) {
            
            //#line 164 "x10/array/Array_3.x10"
            t$100906 = ((j) < (((long)(0L))));
        }
        
        //#line 164 "x10/array/Array_3.x10"
        boolean t$100908 = t$100906;
        
        //#line 164 "x10/array/Array_3.x10"
        if (!(t$100906)) {
            
            //#line 165 "x10/array/Array_3.x10"
            final long t$100907 = this.numElems_2;
            
            //#line 164 "x10/array/Array_3.x10"
            t$100908 = ((j) >= (((long)(t$100907))));
        }
        
        //#line 164 "x10/array/Array_3.x10"
        boolean t$100909 = t$100908;
        
        //#line 164 "x10/array/Array_3.x10"
        if (!(t$100908)) {
            
            //#line 164 "x10/array/Array_3.x10"
            t$100909 = ((k) < (((long)(0L))));
        }
        
        //#line 164 "x10/array/Array_3.x10"
        boolean t$100911 = t$100909;
        
        //#line 164 "x10/array/Array_3.x10"
        if (!(t$100909)) {
            
            //#line 166 "x10/array/Array_3.x10"
            final long t$100910 = this.numElems_3;
            
            //#line 164 "x10/array/Array_3.x10"
            t$100911 = ((k) >= (((long)(t$100910))));
        }
        
        //#line 164 "x10/array/Array_3.x10"
        if (t$100911) {
            
            //#line 167 "x10/array/Array_3.x10"
            x10.array.Array.raiseBoundsError((long)(i), (long)(j), (long)(k));
        }
        
        //#line 169 "x10/array/Array_3.x10"
        final x10.core.Rail r$100746 = ((x10.core.Rail)(this.raw));
        
        //#line 169 "x10/array/Array_3.x10"
        final x10.array.Array_3 this$100744 = ((x10.array.Array_3)(this));
        
        //#line 151 . "x10/array/Array_3.x10"
        final long t$100915 = ((x10.array.Array_3<$T>)this$100744).numElems_3;
        
        //#line 151 . "x10/array/Array_3.x10"
        final long t$100913 = ((x10.array.Array_3<$T>)this$100744).numElems_2;
        
        //#line 151 . "x10/array/Array_3.x10"
        final long t$100914 = ((i) * (((long)(t$100913))));
        
        //#line 151 . "x10/array/Array_3.x10"
        final long t$100916 = ((j) + (((long)(t$100914))));
        
        //#line 151 . "x10/array/Array_3.x10"
        final long t$100917 = ((t$100915) * (((long)(t$100916))));
        
        //#line 169 "x10/array/Array_3.x10"
        final long i$100747 = ((k) + (((long)(t$100917))));
        
        //#line 38 . "x10/lang/Unsafe.x10"
        final $T t$100918 = (($T)(((x10.core.Rail<$T>)r$100746).$apply$G((long)(i$100747))));
        
        //#line 169 "x10/array/Array_3.x10"
        return t$100918;
    }
    
    
    //#line 179 "x10/array/Array_3.x10"
    /**
     * Return the element of this array corresponding to the given Point.
     * 
     * @param p the given Point
     * @return the element of this array corresponding to the given Point.
     * @see #set(T, Point)
     */
    public $T $apply$G(final x10.lang.Point p) {
        
        //#line 179 "x10/array/Array_3.x10"
        final x10.array.Array_3 this$100752 = ((x10.array.Array_3)(this));
        
        //#line 179 "x10/array/Array_3.x10"
        final long i$100749 = p.$apply$O((long)(0L));
        
        //#line 179 "x10/array/Array_3.x10"
        final long j$100750 = p.$apply$O((long)(1L));
        
        //#line 179 "x10/array/Array_3.x10"
        final long k$100751 = p.$apply$O((long)(2L));
        
        //#line 164 . "x10/array/Array_3.x10"
        boolean t$100920 = ((i$100749) < (((long)(0L))));
        
        //#line 164 . "x10/array/Array_3.x10"
        if (!(t$100920)) {
            
            //#line 164 . "x10/array/Array_3.x10"
            final long t$100919 = ((x10.array.Array_3<$T>)this$100752).numElems_1;
            
            //#line 164 . "x10/array/Array_3.x10"
            t$100920 = ((i$100749) >= (((long)(t$100919))));
        }
        
        //#line 164 . "x10/array/Array_3.x10"
        boolean t$100921 = t$100920;
        
        //#line 164 . "x10/array/Array_3.x10"
        if (!(t$100920)) {
            
            //#line 164 . "x10/array/Array_3.x10"
            t$100921 = ((j$100750) < (((long)(0L))));
        }
        
        //#line 164 . "x10/array/Array_3.x10"
        boolean t$100923 = t$100921;
        
        //#line 164 . "x10/array/Array_3.x10"
        if (!(t$100921)) {
            
            //#line 165 . "x10/array/Array_3.x10"
            final long t$100922 = ((x10.array.Array_3<$T>)this$100752).numElems_2;
            
            //#line 164 . "x10/array/Array_3.x10"
            t$100923 = ((j$100750) >= (((long)(t$100922))));
        }
        
        //#line 164 . "x10/array/Array_3.x10"
        boolean t$100924 = t$100923;
        
        //#line 164 . "x10/array/Array_3.x10"
        if (!(t$100923)) {
            
            //#line 164 . "x10/array/Array_3.x10"
            t$100924 = ((k$100751) < (((long)(0L))));
        }
        
        //#line 164 . "x10/array/Array_3.x10"
        boolean t$100926 = t$100924;
        
        //#line 164 . "x10/array/Array_3.x10"
        if (!(t$100924)) {
            
            //#line 166 . "x10/array/Array_3.x10"
            final long t$100925 = ((x10.array.Array_3<$T>)this$100752).numElems_3;
            
            //#line 164 . "x10/array/Array_3.x10"
            t$100926 = ((k$100751) >= (((long)(t$100925))));
        }
        
        //#line 164 . "x10/array/Array_3.x10"
        if (t$100926) {
            
            //#line 167 . "x10/array/Array_3.x10"
            x10.array.Array.raiseBoundsError((long)(i$100749), (long)(j$100750), (long)(k$100751));
        }
        
        //#line 169 . "x10/array/Array_3.x10"
        final x10.core.Rail r$100758 = ((x10.core.Rail)(((x10.array.Array<$T>)this$100752).raw));
        
        //#line 151 .. "x10/array/Array_3.x10"
        final long t$100930 = ((x10.array.Array_3<$T>)this$100752).numElems_3;
        
        //#line 151 .. "x10/array/Array_3.x10"
        final long t$100928 = ((x10.array.Array_3<$T>)this$100752).numElems_2;
        
        //#line 151 .. "x10/array/Array_3.x10"
        final long t$100929 = ((i$100749) * (((long)(t$100928))));
        
        //#line 151 .. "x10/array/Array_3.x10"
        final long t$100931 = ((j$100750) + (((long)(t$100929))));
        
        //#line 151 .. "x10/array/Array_3.x10"
        final long t$100932 = ((t$100930) * (((long)(t$100931))));
        
        //#line 169 . "x10/array/Array_3.x10"
        final long i$100759 = ((k$100751) + (((long)(t$100932))));
        
        //#line 38 .. "x10/lang/Unsafe.x10"
        final $T t$100933 = (($T)(((x10.core.Rail<$T>)r$100758).$apply$G((long)(i$100759))));
        
        //#line 179 "x10/array/Array_3.x10"
        return t$100933;
    }
    
    
    //#line 192 "x10/array/Array_3.x10"
    /**
     * Set the element of this array corresponding to the given triple of indices to the given value.
     * Return the new value of the element.
     * 
     * @param v the given value
     * @param i the given index in the first dimension
     * @param j the given index in the second dimension
     * @param k the given index in the third dimension
     * @return the new value of the element of this array corresponding to the given triple of indices.
     * @see #operator(Long, Long, Long)
     */
    public $T $set__3x10$array$Array_3$$T$G(final long i, final long j, final long k, final $T v) {
        
        //#line 193 "x10/array/Array_3.x10"
        boolean t$100935 = ((i) < (((long)(0L))));
        
        //#line 193 "x10/array/Array_3.x10"
        if (!(t$100935)) {
            
            //#line 193 "x10/array/Array_3.x10"
            final long t$100934 = this.numElems_1;
            
            //#line 193 "x10/array/Array_3.x10"
            t$100935 = ((i) >= (((long)(t$100934))));
        }
        
        //#line 193 "x10/array/Array_3.x10"
        boolean t$100936 = t$100935;
        
        //#line 193 "x10/array/Array_3.x10"
        if (!(t$100935)) {
            
            //#line 193 "x10/array/Array_3.x10"
            t$100936 = ((j) < (((long)(0L))));
        }
        
        //#line 193 "x10/array/Array_3.x10"
        boolean t$100938 = t$100936;
        
        //#line 193 "x10/array/Array_3.x10"
        if (!(t$100936)) {
            
            //#line 194 "x10/array/Array_3.x10"
            final long t$100937 = this.numElems_2;
            
            //#line 193 "x10/array/Array_3.x10"
            t$100938 = ((j) >= (((long)(t$100937))));
        }
        
        //#line 193 "x10/array/Array_3.x10"
        boolean t$100939 = t$100938;
        
        //#line 193 "x10/array/Array_3.x10"
        if (!(t$100938)) {
            
            //#line 193 "x10/array/Array_3.x10"
            t$100939 = ((k) < (((long)(0L))));
        }
        
        //#line 193 "x10/array/Array_3.x10"
        boolean t$100941 = t$100939;
        
        //#line 193 "x10/array/Array_3.x10"
        if (!(t$100939)) {
            
            //#line 195 "x10/array/Array_3.x10"
            final long t$100940 = this.numElems_3;
            
            //#line 193 "x10/array/Array_3.x10"
            t$100941 = ((k) >= (((long)(t$100940))));
        }
        
        //#line 193 "x10/array/Array_3.x10"
        if (t$100941) {
            
            //#line 196 "x10/array/Array_3.x10"
            x10.array.Array.raiseBoundsError((long)(i), (long)(j), (long)(k));
        }
        
        //#line 198 "x10/array/Array_3.x10"
        final x10.core.Rail r$100766 = ((x10.core.Rail)(this.raw));
        
        //#line 198 "x10/array/Array_3.x10"
        final x10.array.Array_3 this$100764 = ((x10.array.Array_3)(this));
        
        //#line 151 . "x10/array/Array_3.x10"
        final long t$100945 = ((x10.array.Array_3<$T>)this$100764).numElems_3;
        
        //#line 151 . "x10/array/Array_3.x10"
        final long t$100943 = ((x10.array.Array_3<$T>)this$100764).numElems_2;
        
        //#line 151 . "x10/array/Array_3.x10"
        final long t$100944 = ((i) * (((long)(t$100943))));
        
        //#line 151 . "x10/array/Array_3.x10"
        final long t$100946 = ((j) + (((long)(t$100944))));
        
        //#line 151 . "x10/array/Array_3.x10"
        final long t$100947 = ((t$100945) * (((long)(t$100946))));
        
        //#line 198 "x10/array/Array_3.x10"
        final long i$100767 = ((k) + (((long)(t$100947))));
        
        //#line 42 . "x10/lang/Unsafe.x10"
        ((x10.core.Rail<$T>)r$100766).$set__1x10$lang$Rail$$T$G((long)(i$100767), (($T)(v)));
        
        //#line 198 "x10/array/Array_3.x10"
        return (($T)
                 v);
    }
    
    
    //#line 210 "x10/array/Array_3.x10"
    /**
     * Set the element of this array corresponding to the given Point to the given value.
     * Return the new value of the element.
     * 
     * @param v the given value
     * @param p the given Point
     * @return the new value of the element of this array corresponding to the given Point.
     * @see #operator(Point)
     */
    public $T $set__1x10$array$Array_3$$T$G(final x10.lang.Point p, final $T v) {
        
        //#line 210 "x10/array/Array_3.x10"
        final x10.array.Array_3 this$100774 = ((x10.array.Array_3)(this));
        
        //#line 210 "x10/array/Array_3.x10"
        final long i$100770 = p.$apply$O((long)(0L));
        
        //#line 210 "x10/array/Array_3.x10"
        final long j$100771 = p.$apply$O((long)(1L));
        
        //#line 210 "x10/array/Array_3.x10"
        final long k$100772 = p.$apply$O((long)(2L));
        
        //#line 193 . "x10/array/Array_3.x10"
        boolean t$100949 = ((i$100770) < (((long)(0L))));
        
        //#line 193 . "x10/array/Array_3.x10"
        if (!(t$100949)) {
            
            //#line 193 . "x10/array/Array_3.x10"
            final long t$100948 = ((x10.array.Array_3<$T>)this$100774).numElems_1;
            
            //#line 193 . "x10/array/Array_3.x10"
            t$100949 = ((i$100770) >= (((long)(t$100948))));
        }
        
        //#line 193 . "x10/array/Array_3.x10"
        boolean t$100950 = t$100949;
        
        //#line 193 . "x10/array/Array_3.x10"
        if (!(t$100949)) {
            
            //#line 193 . "x10/array/Array_3.x10"
            t$100950 = ((j$100771) < (((long)(0L))));
        }
        
        //#line 193 . "x10/array/Array_3.x10"
        boolean t$100952 = t$100950;
        
        //#line 193 . "x10/array/Array_3.x10"
        if (!(t$100950)) {
            
            //#line 194 . "x10/array/Array_3.x10"
            final long t$100951 = ((x10.array.Array_3<$T>)this$100774).numElems_2;
            
            //#line 193 . "x10/array/Array_3.x10"
            t$100952 = ((j$100771) >= (((long)(t$100951))));
        }
        
        //#line 193 . "x10/array/Array_3.x10"
        boolean t$100953 = t$100952;
        
        //#line 193 . "x10/array/Array_3.x10"
        if (!(t$100952)) {
            
            //#line 193 . "x10/array/Array_3.x10"
            t$100953 = ((k$100772) < (((long)(0L))));
        }
        
        //#line 193 . "x10/array/Array_3.x10"
        boolean t$100955 = t$100953;
        
        //#line 193 . "x10/array/Array_3.x10"
        if (!(t$100953)) {
            
            //#line 195 . "x10/array/Array_3.x10"
            final long t$100954 = ((x10.array.Array_3<$T>)this$100774).numElems_3;
            
            //#line 193 . "x10/array/Array_3.x10"
            t$100955 = ((k$100772) >= (((long)(t$100954))));
        }
        
        //#line 193 . "x10/array/Array_3.x10"
        if (t$100955) {
            
            //#line 196 . "x10/array/Array_3.x10"
            x10.array.Array.raiseBoundsError((long)(i$100770), (long)(j$100771), (long)(k$100772));
        }
        
        //#line 198 . "x10/array/Array_3.x10"
        final x10.core.Rail r$100780 = ((x10.core.Rail)(((x10.array.Array<$T>)this$100774).raw));
        
        //#line 151 .. "x10/array/Array_3.x10"
        final long t$100959 = ((x10.array.Array_3<$T>)this$100774).numElems_3;
        
        //#line 151 .. "x10/array/Array_3.x10"
        final long t$100957 = ((x10.array.Array_3<$T>)this$100774).numElems_2;
        
        //#line 151 .. "x10/array/Array_3.x10"
        final long t$100958 = ((i$100770) * (((long)(t$100957))));
        
        //#line 151 .. "x10/array/Array_3.x10"
        final long t$100960 = ((j$100771) + (((long)(t$100958))));
        
        //#line 151 .. "x10/array/Array_3.x10"
        final long t$100961 = ((t$100959) * (((long)(t$100960))));
        
        //#line 198 . "x10/array/Array_3.x10"
        final long i$100781 = ((k$100772) + (((long)(t$100961))));
        
        //#line 42 .. "x10/lang/Unsafe.x10"
        ((x10.core.Rail<$T>)r$100780).$set__1x10$lang$Rail$$T$G((long)(i$100781), (($T)(v)));
        
        //#line 210 "x10/array/Array_3.x10"
        return (($T)
                 v);
    }
    
    
    //#line 213 "x10/array/Array_3.x10"
    private static long validateSize$O(final long m, final long n, final long p) {
        
        //#line 214 "x10/array/Array_3.x10"
        boolean t$100962 = ((m) < (((long)(0L))));
        
        //#line 214 "x10/array/Array_3.x10"
        if (!(t$100962)) {
            
            //#line 214 "x10/array/Array_3.x10"
            t$100962 = ((n) < (((long)(0L))));
        }
        
        //#line 214 "x10/array/Array_3.x10"
        boolean t$100963 = t$100962;
        
        //#line 214 "x10/array/Array_3.x10"
        if (!(t$100962)) {
            
            //#line 214 "x10/array/Array_3.x10"
            t$100963 = ((p) < (((long)(0L))));
        }
        
        //#line 214 "x10/array/Array_3.x10"
        if (t$100963) {
            
            //#line 214 "x10/array/Array_3.x10"
            x10.array.Array.raiseNegativeArraySizeException();
        }
        
        //#line 215 "x10/array/Array_3.x10"
        final long t$100965 = ((m) * (((long)(n))));
        
        //#line 215 "x10/array/Array_3.x10"
        final long t$100966 = ((t$100965) * (((long)(p))));
        
        //#line 215 "x10/array/Array_3.x10"
        return t$100966;
    }
    
    public static long validateSize$P$O(final long m, final long n, final long p) {
        return x10.array.Array_3.validateSize$O((long)(m), (long)(n), (long)(p));
    }
    
    
    //#line 21 "x10/array/Array_3.x10"
    final public x10.array.Array_3 x10$array$Array_3$$this$x10$array$Array_3() {
        
        //#line 21 "x10/array/Array_3.x10"
        return x10.array.Array_3.this;
    }
    
    
    //#line 21 "x10/array/Array_3.x10"
    final public void __fieldInitializers_x10_array_Array_3() {
        
    }
}

