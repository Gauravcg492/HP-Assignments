package x10.array;


/**
 * Represents the distribution of the Points of an IterationSpace(2) 
 * over the Places in its PlaceGroup by block-block distributing the
 * dimensions of the IterationSpace.
 */
@x10.runtime.impl.java.X10Generated
public class Dist_BlockBlock_2 extends x10.array.Dist implements x10.serialization.X10JavaSerializable
{
    public static final x10.rtt.RuntimeType<Dist_BlockBlock_2> $RTT = 
        x10.rtt.NamedType.<Dist_BlockBlock_2> make("x10.array.Dist_BlockBlock_2",
                                                   Dist_BlockBlock_2.class,
                                                   new x10.rtt.Type[] {
                                                       x10.array.Dist.$RTT
                                                   });
    
    public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
    
    public x10.rtt.Type<?> $getParam(int i) { return null; }
    
    private Object writeReplace() throws java.io.ObjectStreamException {
        return new x10.serialization.SerializationProxy(this);
    }
    
    public static x10.serialization.X10JavaSerializable $_deserialize_body(x10.array.Dist_BlockBlock_2 $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
        x10.array.Dist.$_deserialize_body($_obj, $deserializer);
        $_obj.globalIndices = $deserializer.readObject();
        
        /* fields with @TransientInitExpr annotations */
        $_obj.localIndices = $_obj.computeLocalIndices();
        
        return $_obj;
    }
    
    public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
        x10.array.Dist_BlockBlock_2 $_obj = new x10.array.Dist_BlockBlock_2((java.lang.System[]) null);
        $deserializer.record_reference($_obj);
        return $_deserialize_body($_obj, $deserializer);
    }
    
    public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
        super.$_serialize($serializer);
        $serializer.write(this.globalIndices);
        
    }
    
    // constructor just for allocation
    public Dist_BlockBlock_2(final java.lang.System[] $dummy) {
        super($dummy);
        
    }
    
    

    
    //#line 23 "x10/array/Dist_BlockBlock_2.x10"
    public x10.array.DenseIterationSpace_2 globalIndices;
    
    //#line 26 "x10/array/Dist_BlockBlock_2.x10"
    public transient x10.array.DenseIterationSpace_2 localIndices;
    
    
    //#line 27 "x10/array/Dist_BlockBlock_2.x10"
    final public x10.array.DenseIterationSpace_2 computeLocalIndices() {
        
        //#line 28 "x10/array/Dist_BlockBlock_2.x10"
        final x10.array.DenseIterationSpace_2 t$110276 = ((x10.array.DenseIterationSpace_2)(this.globalIndices));
        
        //#line 28 "x10/array/Dist_BlockBlock_2.x10"
        final x10.lang.PlaceGroup t$110274 = ((x10.lang.PlaceGroup)(this.pg));
        
        //#line 28 "x10/array/Dist_BlockBlock_2.x10"
        final long t$110277 = t$110274.numPlaces$O();
        
        //#line 28 "x10/array/Dist_BlockBlock_2.x10"
        final x10.lang.PlaceGroup t$110275 = ((x10.lang.PlaceGroup)(this.pg));
        
        //#line 28 "x10/array/Dist_BlockBlock_2.x10"
        final long t$110278 = t$110275.indexOf$O(((x10.lang.Place)(x10.x10rt.X10RT.here())));
        
        //#line 28 "x10/array/Dist_BlockBlock_2.x10"
        final x10.array.DenseIterationSpace_2 t$110279 = ((x10.array.DenseIterationSpace_2)(x10.array.BlockingUtils.partitionBlockBlock(((x10.array.IterationSpace)(t$110276)), (long)(t$110277), (long)(t$110278))));
        
        //#line 28 "x10/array/Dist_BlockBlock_2.x10"
        return t$110279;
    }
    
    
    //#line 31 "x10/array/Dist_BlockBlock_2.x10"
    // creation method for java code (1-phase java constructor)
    public Dist_BlockBlock_2(final x10.lang.PlaceGroup pg, final x10.array.DenseIterationSpace_2 is) {
        this((java.lang.System[]) null);
        x10$array$Dist_BlockBlock_2$$init$S(pg, is);
    }
    
    // constructor for non-virtual call
    final public x10.array.Dist_BlockBlock_2 x10$array$Dist_BlockBlock_2$$init$S(final x10.lang.PlaceGroup pg, final x10.array.DenseIterationSpace_2 is) {
         {
            
            //#line 32 "x10/array/Dist_BlockBlock_2.x10"
            final x10.array.Dist this$110269 = ((x10.array.Dist)(this));
            
            //#line 32 "x10/array/Dist_BlockBlock_2.x10"
            final x10.array.IterationSpace is$110268 = ((x10.array.IterationSpace)(((x10.array.IterationSpace)
                                                                                     is)));
            
            //#line 26 . "x10/array/Dist.x10"
            this$110269.pg = ((x10.lang.PlaceGroup)(pg));
            
            //#line 26 . "x10/array/Dist.x10"
            this$110269.is = ((x10.array.IterationSpace)(is$110268));
            
            //#line 31 "x10/array/Dist_BlockBlock_2.x10"
            
            
            //#line 33 "x10/array/Dist_BlockBlock_2.x10"
            this.globalIndices = ((x10.array.DenseIterationSpace_2)(is));
            
            //#line 34 "x10/array/Dist_BlockBlock_2.x10"
            final x10.array.DenseIterationSpace_2 t$110280 = ((x10.array.DenseIterationSpace_2)(this.computeLocalIndices()));
            
            //#line 34 "x10/array/Dist_BlockBlock_2.x10"
            this.localIndices = ((x10.array.DenseIterationSpace_2)(t$110280));
        }
        return this;
    }
    
    
    
    //#line 22 "x10/array/Dist_BlockBlock_2.x10"
    final public x10.array.Dist_BlockBlock_2 x10$array$Dist_BlockBlock_2$$this$x10$array$Dist_BlockBlock_2() {
        
        //#line 22 "x10/array/Dist_BlockBlock_2.x10"
        return x10.array.Dist_BlockBlock_2.this;
    }
    
    
    //#line 22 "x10/array/Dist_BlockBlock_2.x10"
    final public void __fieldInitializers_x10_array_Dist_BlockBlock_2() {
        
    }
}

