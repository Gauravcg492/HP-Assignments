package x10.array;


/**
 * Implementation of a 2-D DistArray that distributes its data elements
 * over the places in its PlaceGroup in a 2-D blocked fashion.
 */
@x10.runtime.impl.java.X10Generated
public class DistArray_BlockBlock_2<$T> extends x10.array.DistArray<$T> implements x10.core.fun.Fun_0_2, x10.serialization.X10JavaSerializable
{
    public static final x10.rtt.RuntimeType<DistArray_BlockBlock_2> $RTT = 
        x10.rtt.NamedType.<DistArray_BlockBlock_2> make("x10.array.DistArray_BlockBlock_2",
                                                        DistArray_BlockBlock_2.class,
                                                        1,
                                                        new x10.rtt.Type[] {
                                                            x10.rtt.ParameterizedType.make(x10.core.fun.Fun_0_2.$RTT, x10.rtt.Types.LONG, x10.rtt.Types.LONG, x10.rtt.UnresolvedType.PARAM(0)),
                                                            x10.rtt.ParameterizedType.make(x10.array.DistArray.$RTT, x10.rtt.UnresolvedType.PARAM(0))
                                                        });
    
    public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
    
    public x10.rtt.Type<?> $getParam(int i) { if (i == 0) return $T; return null; }
    
    private Object writeReplace() throws java.io.ObjectStreamException {
        return new x10.serialization.SerializationProxy(this);
    }
    
    public static <$T> x10.serialization.X10JavaSerializable $_deserialize_body(x10.array.DistArray_BlockBlock_2<$T> $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
        x10.array.DistArray.$_deserialize_body($_obj, $deserializer);
        $_obj.$T = (x10.rtt.Type) $deserializer.readObject();
        $_obj.globalIndices = $deserializer.readObject();
        $_obj.numElems_1 = $deserializer.readLong();
        $_obj.numElems_2 = $deserializer.readLong();
        
        /* fields with @TransientInitExpr annotations */
        $_obj.localIndices = $_obj.reloadLocalIndices();
        $_obj.minIndex_1 = $_obj.reloadMinIndex_1$O();
        $_obj.minIndex_2 = $_obj.reloadMinIndex_2$O();
        $_obj.numElemsLocal_1 = $_obj.reloadNumElemsLocal_1$O();
        $_obj.numElemsLocal_2 = $_obj.reloadNumElemsLocal_2$O();
        
        return $_obj;
    }
    
    public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
        x10.array.DistArray_BlockBlock_2 $_obj = new x10.array.DistArray_BlockBlock_2((java.lang.System[]) null, (x10.rtt.Type) null);
        $deserializer.record_reference($_obj);
        return $_deserialize_body($_obj, $deserializer);
    }
    
    public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
        super.$_serialize($serializer);
        $serializer.write(this.$T);
        $serializer.write(this.globalIndices);
        $serializer.write(this.numElems_1);
        $serializer.write(this.numElems_2);
        
    }
    
    // constructor just for allocation
    public DistArray_BlockBlock_2(final java.lang.System[] $dummy, final x10.rtt.Type $T) {
        super($dummy, $T);
        x10.array.DistArray_BlockBlock_2.$initParams(this, $T);
        
    }
    
    // dispatcher for method abstract public (Z1,Z2)=>U.operator()(a1:Z1, a2:Z2){}:U
    public java.lang.Object $apply(final java.lang.Object a1, final x10.rtt.Type t1, final java.lang.Object a2, final x10.rtt.Type t2) {
        return $apply$G(x10.core.Long.$unbox(a1), x10.core.Long.$unbox(a2));
        
    }
    
    // bridge for method abstract public x10.array.DistArray[T].operator()=(p:x10.lang.Point{self.rank==this(:x10.array.DistArray).rank()}, v:T){}:T{self==v}
    final public $T $set__1x10$array$DistArray$$T$G(x10.lang.Point a1, $T a2) {
        return $set__1x10$array$DistArray_BlockBlock_2$$T$G(a1, a2);
    }
    
    private x10.rtt.Type $T;
    
    // initializer of type parameters
    public static void $initParams(final DistArray_BlockBlock_2 $this, final x10.rtt.Type $T) {
        $this.$T = $T;
        
    }
    // synthetic type for parameter mangling
    public static final class __3$1x10$lang$Long$3x10$lang$Long$3x10$array$DistArray_BlockBlock_2$$T$2 {}
    // synthetic type for parameter mangling
    public static final class __2$1x10$lang$Long$3x10$lang$Long$3x10$array$DistArray_BlockBlock_2$$T$2 {}
    

    
    
    //#line 25 "x10/array/DistArray_BlockBlock_2.x10"
    final public long rank$O() {
        
        //#line 25 "x10/array/DistArray_BlockBlock_2.x10"
        return 2L;
    }
    
    
    //#line 27 "x10/array/DistArray_BlockBlock_2.x10"
    public x10.array.DenseIterationSpace_2 globalIndices;
    
    //#line 29 "x10/array/DistArray_BlockBlock_2.x10"
    public long numElems_1;
    
    //#line 31 "x10/array/DistArray_BlockBlock_2.x10"
    public long numElems_2;
    
    //#line 34 "x10/array/DistArray_BlockBlock_2.x10"
    public transient x10.array.DenseIterationSpace_2 localIndices;
    
    
    //#line 35 "x10/array/DistArray_BlockBlock_2.x10"
    final public x10.array.DenseIterationSpace_2 reloadLocalIndices() {
        
        //#line 37 "x10/array/DistArray_BlockBlock_2.x10"
        final x10.lang.PlaceLocalHandle t$106569 = ((x10.lang.PlaceLocalHandle)(this.localHandle));
        
        //#line 37 "x10/array/DistArray_BlockBlock_2.x10"
        final x10.array.LocalState t$106570 = ((x10.lang.PlaceLocalHandle<x10.array.LocalState<$T>>)t$106569).$apply$G();
        
        //#line 37 "x10/array/DistArray_BlockBlock_2.x10"
        final x10.array.LocalState_BB2 ls = x10.rtt.Types.<x10.array.LocalState_BB2<$T>> cast(t$106570,x10.rtt.ParameterizedType.make(x10.array.LocalState_BB2.$RTT, $T));
        
        //#line 38 "x10/array/DistArray_BlockBlock_2.x10"
        final boolean t$106572 = ((ls) != (null));
        
        //#line 38 "x10/array/DistArray_BlockBlock_2.x10"
        x10.array.DenseIterationSpace_2 t$106573 =  null;
        
        //#line 38 "x10/array/DistArray_BlockBlock_2.x10"
        if (t$106572) {
            
            //#line 38 "x10/array/DistArray_BlockBlock_2.x10"
            final x10.array.Dist_BlockBlock_2 t$106571 = ((x10.array.Dist_BlockBlock_2)(((x10.array.LocalState_BB2<$T>)ls).dist));
            
            //#line 38 "x10/array/DistArray_BlockBlock_2.x10"
            t$106573 = ((x10.array.DenseIterationSpace_2)(t$106571.localIndices));
        } else {
            
            //#line 38 "x10/array/DistArray_BlockBlock_2.x10"
            final x10.array.DenseIterationSpace_2 alloc$106304 = ((x10.array.DenseIterationSpace_2)(new x10.array.DenseIterationSpace_2((java.lang.System[]) null)));
            
            //#line 38 "x10/array/DistArray_BlockBlock_2.x10"
            alloc$106304.x10$array$DenseIterationSpace_2$$init$S(((long)(0L)), ((long)(0L)), ((long)(-1L)), ((long)(-1L)));
            
            //#line 38 "x10/array/DistArray_BlockBlock_2.x10"
            t$106573 = ((x10.array.DenseIterationSpace_2)(alloc$106304));
        }
        
        //#line 38 "x10/array/DistArray_BlockBlock_2.x10"
        return t$106573;
    }
    
    
    //#line 42 "x10/array/DistArray_BlockBlock_2.x10"
    public transient long minIndex_1;
    
    
    //#line 43 "x10/array/DistArray_BlockBlock_2.x10"
    final public long reloadMinIndex_1$O() {
        
        //#line 43 "x10/array/DistArray_BlockBlock_2.x10"
        final x10.array.DenseIterationSpace_2 t$106575 = ((x10.array.DenseIterationSpace_2)(this.localIndices));
        
        //#line 43 "x10/array/DistArray_BlockBlock_2.x10"
        final long t$106576 = t$106575.min$O((long)(0L));
        
        //#line 43 "x10/array/DistArray_BlockBlock_2.x10"
        return t$106576;
    }
    
    
    //#line 46 "x10/array/DistArray_BlockBlock_2.x10"
    public transient long minIndex_2;
    
    
    //#line 47 "x10/array/DistArray_BlockBlock_2.x10"
    final public long reloadMinIndex_2$O() {
        
        //#line 47 "x10/array/DistArray_BlockBlock_2.x10"
        final x10.array.DenseIterationSpace_2 t$106577 = ((x10.array.DenseIterationSpace_2)(this.localIndices));
        
        //#line 47 "x10/array/DistArray_BlockBlock_2.x10"
        final long t$106578 = t$106577.min$O((long)(1L));
        
        //#line 47 "x10/array/DistArray_BlockBlock_2.x10"
        return t$106578;
    }
    
    
    //#line 50 "x10/array/DistArray_BlockBlock_2.x10"
    public transient long numElemsLocal_1;
    
    
    //#line 51 "x10/array/DistArray_BlockBlock_2.x10"
    final public long reloadNumElemsLocal_1$O() {
        
        //#line 51 "x10/array/DistArray_BlockBlock_2.x10"
        final x10.array.DenseIterationSpace_2 t$106579 = ((x10.array.DenseIterationSpace_2)(this.localIndices));
        
        //#line 51 "x10/array/DistArray_BlockBlock_2.x10"
        final long t$106580 = t$106579.max$O((long)(0L));
        
        //#line 51 "x10/array/DistArray_BlockBlock_2.x10"
        final long t$106581 = this.minIndex_1;
        
        //#line 51 "x10/array/DistArray_BlockBlock_2.x10"
        final long t$106582 = ((t$106580) - (((long)(t$106581))));
        
        //#line 51 "x10/array/DistArray_BlockBlock_2.x10"
        final long t$106583 = ((t$106582) + (((long)(1L))));
        
        //#line 51 "x10/array/DistArray_BlockBlock_2.x10"
        return t$106583;
    }
    
    
    //#line 54 "x10/array/DistArray_BlockBlock_2.x10"
    public transient long numElemsLocal_2;
    
    
    //#line 55 "x10/array/DistArray_BlockBlock_2.x10"
    final public long reloadNumElemsLocal_2$O() {
        
        //#line 55 "x10/array/DistArray_BlockBlock_2.x10"
        final x10.array.DenseIterationSpace_2 t$106584 = ((x10.array.DenseIterationSpace_2)(this.localIndices));
        
        //#line 55 "x10/array/DistArray_BlockBlock_2.x10"
        final long t$106585 = t$106584.max$O((long)(1L));
        
        //#line 55 "x10/array/DistArray_BlockBlock_2.x10"
        final long t$106586 = this.minIndex_2;
        
        //#line 55 "x10/array/DistArray_BlockBlock_2.x10"
        final long t$106587 = ((t$106585) - (((long)(t$106586))));
        
        //#line 55 "x10/array/DistArray_BlockBlock_2.x10"
        final long t$106588 = ((t$106587) + (((long)(1L))));
        
        //#line 55 "x10/array/DistArray_BlockBlock_2.x10"
        return t$106588;
    }
    
    
    //#line 67 "x10/array/DistArray_BlockBlock_2.x10"
    /**
     * Construct a m by n block-block distributed DistArray
     * whose data is distributed over pg and initialized using
     * the init function.
     *
     * @param m number of elements in the first dimension
     * @param n number of elements in the second dimension
     * @param pg the PlaceGroup to use to distibute the elements.
     * @param init the element initialization function
     */
    // creation method for java code (1-phase java constructor)
    public DistArray_BlockBlock_2(final x10.rtt.Type $T, final long m, final long n, final x10.lang.PlaceGroup pg, final x10.core.fun.Fun_0_2<x10.core.Long,x10.core.Long,$T> init, __3$1x10$lang$Long$3x10$lang$Long$3x10$array$DistArray_BlockBlock_2$$T$2 $dummy) {
        this((java.lang.System[]) null, $T);
        x10$array$DistArray_BlockBlock_2$$init$S(m, n, pg, init, (x10.array.DistArray_BlockBlock_2.__3$1x10$lang$Long$3x10$lang$Long$3x10$array$DistArray_BlockBlock_2$$T$2) null);
    }
    
    // constructor for non-virtual call
    final public x10.array.DistArray_BlockBlock_2<$T> x10$array$DistArray_BlockBlock_2$$init$S(final long m, final long n, final x10.lang.PlaceGroup pg, final x10.core.fun.Fun_0_2<x10.core.Long,x10.core.Long,$T> init, __3$1x10$lang$Long$3x10$lang$Long$3x10$array$DistArray_BlockBlock_2$$T$2 $dummy) {
         {
            
            //#line 68 "x10/array/DistArray_BlockBlock_2.x10"
            final x10.core.fun.Fun_0_0 t$106745 = ((x10.core.fun.Fun_0_0)(new x10.array.DistArray_BlockBlock_2.$Closure$5<$T>($T, pg, m, n, init, (x10.array.DistArray_BlockBlock_2.$Closure$5.__3$1x10$lang$Long$3x10$lang$Long$3x10$array$DistArray_BlockBlock_2$$Closure$5$$T$2) null)));
            
            //#line 263 . "x10/array/DistArray_BlockBlock_2.x10"
            boolean t$106749 = ((m) < (((long)(0L))));
            
            //#line 263 . "x10/array/DistArray_BlockBlock_2.x10"
            if (!(t$106749)) {
                
                //#line 263 . "x10/array/DistArray_BlockBlock_2.x10"
                t$106749 = ((n) < (((long)(0L))));
            }
            
            //#line 263 . "x10/array/DistArray_BlockBlock_2.x10"
            if (t$106749) {
                
                //#line 263 . "x10/array/DistArray_BlockBlock_2.x10"
                x10.array.DistArray.raiseNegativeArraySizeException();
            }
            
            //#line 264 . "x10/array/DistArray_BlockBlock_2.x10"
            final long t$106751 = ((m) * (((long)(n))));
            
            //#line 68 "x10/array/DistArray_BlockBlock_2.x10"
            /*super.*/x10$array$DistArray$$init$S(((x10.lang.PlaceGroup)(pg)), ((x10.core.fun.Fun_0_0)(t$106745)), t$106751, (x10.array.DistArray.__1$1x10$array$LocalState$1x10$array$DistArray$$T$2$2) null);
            
            //#line 67 "x10/array/DistArray_BlockBlock_2.x10"
            
            
            //#line 69 "x10/array/DistArray_BlockBlock_2.x10"
            final x10.array.DenseIterationSpace_2 alloc$106305 = ((x10.array.DenseIterationSpace_2)(new x10.array.DenseIterationSpace_2((java.lang.System[]) null)));
            
            //#line 69 "x10/array/DistArray_BlockBlock_2.x10"
            final long t$106753 = ((m) - (((long)(1L))));
            
            //#line 69 "x10/array/DistArray_BlockBlock_2.x10"
            final long t$106754 = ((n) - (((long)(1L))));
            
            //#line 69 "x10/array/DistArray_BlockBlock_2.x10"
            alloc$106305.x10$array$DenseIterationSpace_2$$init$S(((long)(0L)), ((long)(0L)), t$106753, t$106754);
            
            //#line 69 "x10/array/DistArray_BlockBlock_2.x10"
            ((x10.array.DistArray_BlockBlock_2<$T>)this).globalIndices = ((x10.array.DenseIterationSpace_2)(alloc$106305));
            
            //#line 70 "x10/array/DistArray_BlockBlock_2.x10"
            ((x10.array.DistArray_BlockBlock_2<$T>)this).numElems_1 = m;
            
            //#line 71 "x10/array/DistArray_BlockBlock_2.x10"
            ((x10.array.DistArray_BlockBlock_2<$T>)this).numElems_2 = n;
            
            //#line 72 "x10/array/DistArray_BlockBlock_2.x10"
            final x10.array.DenseIterationSpace_2 t$106596 = ((x10.array.DenseIterationSpace_2)(this.reloadLocalIndices()));
            
            //#line 72 "x10/array/DistArray_BlockBlock_2.x10"
            ((x10.array.DistArray_BlockBlock_2<$T>)this).localIndices = ((x10.array.DenseIterationSpace_2)(t$106596));
            
            //#line 73 "x10/array/DistArray_BlockBlock_2.x10"
            final x10.array.DistArray_BlockBlock_2 this$106412 = ((x10.array.DistArray_BlockBlock_2)(this));
            
            //#line 43 . "x10/array/DistArray_BlockBlock_2.x10"
            final x10.array.DenseIterationSpace_2 t$106597 = ((x10.array.DenseIterationSpace_2)(((x10.array.DistArray_BlockBlock_2<$T>)this$106412).localIndices));
            
            //#line 43 . "x10/array/DistArray_BlockBlock_2.x10"
            final long t$106598 = t$106597.min$O((long)(0L));
            
            //#line 73 "x10/array/DistArray_BlockBlock_2.x10"
            ((x10.array.DistArray_BlockBlock_2<$T>)this).minIndex_1 = t$106598;
            
            //#line 74 "x10/array/DistArray_BlockBlock_2.x10"
            final x10.array.DistArray_BlockBlock_2 this$106414 = ((x10.array.DistArray_BlockBlock_2)(this));
            
            //#line 47 . "x10/array/DistArray_BlockBlock_2.x10"
            final x10.array.DenseIterationSpace_2 t$106599 = ((x10.array.DenseIterationSpace_2)(((x10.array.DistArray_BlockBlock_2<$T>)this$106414).localIndices));
            
            //#line 47 . "x10/array/DistArray_BlockBlock_2.x10"
            final long t$106600 = t$106599.min$O((long)(1L));
            
            //#line 74 "x10/array/DistArray_BlockBlock_2.x10"
            ((x10.array.DistArray_BlockBlock_2<$T>)this).minIndex_2 = t$106600;
            
            //#line 75 "x10/array/DistArray_BlockBlock_2.x10"
            final long t$106601 = this.reloadNumElemsLocal_1$O();
            
            //#line 75 "x10/array/DistArray_BlockBlock_2.x10"
            ((x10.array.DistArray_BlockBlock_2<$T>)this).numElemsLocal_1 = t$106601;
            
            //#line 76 "x10/array/DistArray_BlockBlock_2.x10"
            final long t$106602 = this.reloadNumElemsLocal_2$O();
            
            //#line 76 "x10/array/DistArray_BlockBlock_2.x10"
            ((x10.array.DistArray_BlockBlock_2<$T>)this).numElemsLocal_2 = t$106602;
        }
        return this;
    }
    
    
    
    //#line 89 "x10/array/DistArray_BlockBlock_2.x10"
    /**
     * Construct a m by n block-block distributed DistArray
     * whose data is distributed over Place.places() and 
     * initialized using the provided init closure.
     *
     * @param m number of elements in the first dimension
     * @param n number of elements in the second dimension
     * @param init the element initialization function
     */
    // creation method for java code (1-phase java constructor)
    public DistArray_BlockBlock_2(final x10.rtt.Type $T, final long m, final long n, final x10.core.fun.Fun_0_2<x10.core.Long,x10.core.Long,$T> init, __2$1x10$lang$Long$3x10$lang$Long$3x10$array$DistArray_BlockBlock_2$$T$2 $dummy) {
        this((java.lang.System[]) null, $T);
        x10$array$DistArray_BlockBlock_2$$init$S(m, n, init, (x10.array.DistArray_BlockBlock_2.__2$1x10$lang$Long$3x10$lang$Long$3x10$array$DistArray_BlockBlock_2$$T$2) null);
    }
    
    // constructor for non-virtual call
    final public x10.array.DistArray_BlockBlock_2<$T> x10$array$DistArray_BlockBlock_2$$init$S(final long m, final long n, final x10.core.fun.Fun_0_2<x10.core.Long,x10.core.Long,$T> init, __2$1x10$lang$Long$3x10$lang$Long$3x10$array$DistArray_BlockBlock_2$$T$2 $dummy) {
         {
            
            //#line 90 "x10/array/DistArray_BlockBlock_2.x10"
            final x10.lang.PlaceGroup t$106603 = ((x10.lang.PlaceGroup)(x10.lang.Place.places()));
            
            //#line 90 "x10/array/DistArray_BlockBlock_2.x10"
            /*this.*/x10$array$DistArray_BlockBlock_2$$init$S(((long)(m)), ((long)(n)), t$106603, ((x10.core.fun.Fun_0_2)(init)), (x10.array.DistArray_BlockBlock_2.__3$1x10$lang$Long$3x10$lang$Long$3x10$array$DistArray_BlockBlock_2$$T$2) null);
        }
        return this;
    }
    
    
    
    //#line 102 "x10/array/DistArray_BlockBlock_2.x10"
    /**
     * Construct a m by n block-block distributed DistArray
     * whose data is distributed over pg and zero-initialized.
     *
     * @param m number of elements in the first dimension
     * @param n number of elements in the second dimension
     * @param pg the PlaceGroup to use to distibute the elements.
     */
    // creation method for java code (1-phase java constructor)
    public DistArray_BlockBlock_2(final x10.rtt.Type $T, final long m, final long n, final x10.lang.PlaceGroup pg) {
        this((java.lang.System[]) null, $T);
        x10$array$DistArray_BlockBlock_2$$init$S(m, n, pg);
    }
    
    // constructor for non-virtual call
    final public x10.array.DistArray_BlockBlock_2<$T> x10$array$DistArray_BlockBlock_2$$init$S(final long m, final long n, final x10.lang.PlaceGroup pg) {
         {
            
            //#line 103 "x10/array/DistArray_BlockBlock_2.x10"
            final x10.core.fun.Fun_0_2 t$106605 = ((x10.core.fun.Fun_0_2)(new x10.array.DistArray_BlockBlock_2.$Closure$6<$T>($T)));
            
            //#line 103 "x10/array/DistArray_BlockBlock_2.x10"
            /*this.*/x10$array$DistArray_BlockBlock_2$$init$S(((long)(m)), ((long)(n)), ((x10.lang.PlaceGroup)(pg)), ((x10.core.fun.Fun_0_2)(t$106605)), (x10.array.DistArray_BlockBlock_2.__3$1x10$lang$Long$3x10$lang$Long$3x10$array$DistArray_BlockBlock_2$$T$2) null);
        }
        return this;
    }
    
    
    
    //#line 115 "x10/array/DistArray_BlockBlock_2.x10"
    /**
     * Construct a m by n block-block distributed DistArray
     * whose data is distributed over Place.places() and 
     * zero-initialized.
     *
     * @param m number of elements in the first dimension
     * @param n number of elements in the second dimension
     */
    // creation method for java code (1-phase java constructor)
    public DistArray_BlockBlock_2(final x10.rtt.Type $T, final long m, final long n) {
        this((java.lang.System[]) null, $T);
        x10$array$DistArray_BlockBlock_2$$init$S(m, n);
    }
    
    // constructor for non-virtual call
    final public x10.array.DistArray_BlockBlock_2<$T> x10$array$DistArray_BlockBlock_2$$init$S(final long m, final long n) {
         {
            
            //#line 116 "x10/array/DistArray_BlockBlock_2.x10"
            final x10.lang.PlaceGroup t$106607 = ((x10.lang.PlaceGroup)(x10.lang.Place.places()));
            
            //#line 116 "x10/array/DistArray_BlockBlock_2.x10"
            final x10.core.fun.Fun_0_2 t$106608 = ((x10.core.fun.Fun_0_2)(new x10.array.DistArray_BlockBlock_2.$Closure$7<$T>($T)));
            
            //#line 116 "x10/array/DistArray_BlockBlock_2.x10"
            /*this.*/x10$array$DistArray_BlockBlock_2$$init$S(((long)(m)), ((long)(n)), t$106607, ((x10.core.fun.Fun_0_2)(t$106608)), (x10.array.DistArray_BlockBlock_2.__3$1x10$lang$Long$3x10$lang$Long$3x10$array$DistArray_BlockBlock_2$$T$2) null);
        }
        return this;
    }
    
    
    
    //#line 125 "x10/array/DistArray_BlockBlock_2.x10"
    /**
     * Get an IterationSpace that represents all Points contained in
     * the global iteration space (valid indices) of the DistArray.
     * @return an IterationSpace for the DistArray
     */
    final public x10.array.DenseIterationSpace_2 globalIndices() {
        
        //#line 125 "x10/array/DistArray_BlockBlock_2.x10"
        final x10.array.DenseIterationSpace_2 t$106609 = ((x10.array.DenseIterationSpace_2)(this.globalIndices));
        
        //#line 125 "x10/array/DistArray_BlockBlock_2.x10"
        return t$106609;
    }
    
    
    //#line 133 "x10/array/DistArray_BlockBlock_2.x10"
    /**
     * Get an IterationSpace that represents all Points contained in
     * the local iteration space (valid indices) of the DistArray at the current Place.
     * @return an IterationSpace for the local portion of the DistArray
     */
    final public x10.array.DenseIterationSpace_2 localIndices() {
        
        //#line 133 "x10/array/DistArray_BlockBlock_2.x10"
        final x10.array.DenseIterationSpace_2 t$106610 = ((x10.array.DenseIterationSpace_2)(this.localIndices));
        
        //#line 133 "x10/array/DistArray_BlockBlock_2.x10"
        return t$106610;
    }
    
    
    //#line 146 "x10/array/DistArray_BlockBlock_2.x10"
    /**
     * Return the Place which contains the data for the argument
     * index or Place.INVALID_PLACE if the Point is not in the globalIndices
     * of this DistArray
     *
     * @param i the index in the first dimension
     * @param j the index in the second dimension
     * @return the Place where (i,j) is a valid index in the DistArray; 
     *          will return Place.INVALID_PLACE if (i,j) is not contained in globalIndices
     */
    final public x10.lang.Place place(final long i, final long j) {
        
        //#line 147 "x10/array/DistArray_BlockBlock_2.x10"
        final x10.array.DenseIterationSpace_2 t$106611 = ((x10.array.DenseIterationSpace_2)(this.globalIndices));
        
        //#line 147 "x10/array/DistArray_BlockBlock_2.x10"
        final x10.lang.PlaceGroup this$106518 = ((x10.lang.PlaceGroup)(this.placeGroup));
        
        //#line 35 . "x10/lang/PlaceGroup.x10"
        final long t$106612 = this$106518.numPlaces$O();
        
        //#line 147 "x10/array/DistArray_BlockBlock_2.x10"
        final long tmp = x10.array.BlockingUtils.mapIndexToBlockBlockPartition$O(((x10.array.IterationSpace)(t$106611)), (long)(t$106612), (long)(i), (long)(j));
        
        //#line 148 "x10/array/DistArray_BlockBlock_2.x10"
        final boolean t$106614 = ((long) tmp) == ((long) -1L);
        
        //#line 148 "x10/array/DistArray_BlockBlock_2.x10"
        x10.lang.Place t$106615 =  null;
        
        //#line 148 "x10/array/DistArray_BlockBlock_2.x10"
        if (t$106614) {
            
            //#line 148 "x10/array/DistArray_BlockBlock_2.x10"
            t$106615 = x10.lang.Place.get$INVALID_PLACE();
        } else {
            
            //#line 148 "x10/array/DistArray_BlockBlock_2.x10"
            final x10.lang.PlaceGroup t$106613 = ((x10.lang.PlaceGroup)(this.placeGroup));
            
            //#line 148 "x10/array/DistArray_BlockBlock_2.x10"
            t$106615 = t$106613.$apply((long)(tmp));
        }
        
        //#line 148 "x10/array/DistArray_BlockBlock_2.x10"
        return t$106615;
    }
    
    
    //#line 161 "x10/array/DistArray_BlockBlock_2.x10"
    /**
     * Return the Place which contains the data for the argument
     * Point or Place.INVALID_PLACE if the Point is not in the globalIndices
     * of this DistArray
     *
     * @param p the Point to lookup
     * @return the Place where p is a valid index in the DistArray; 
     *          will return Place.INVALID_PLACE if p is not contained in globalIndices
     */
    final public x10.lang.Place place(final x10.lang.Point p) {
        
        //#line 161 "x10/array/DistArray_BlockBlock_2.x10"
        final long t$106617 = p.$apply$O((long)(0L));
        
        //#line 161 "x10/array/DistArray_BlockBlock_2.x10"
        final long t$106618 = p.$apply$O((long)(1L));
        
        //#line 161 "x10/array/DistArray_BlockBlock_2.x10"
        final x10.lang.Place t$106619 = this.place((long)(t$106617), (long)(t$106618));
        
        //#line 161 "x10/array/DistArray_BlockBlock_2.x10"
        return t$106619;
    }
    
    
    //#line 172 "x10/array/DistArray_BlockBlock_2.x10"
    /**
     * Return the element of this array corresponding to the given index.
     * 
     * @param i the given index in the first dimension
     * @param j the given index in the second dimension
     * @return the element of this array corresponding to the given index.
     * @see #set(T, Long, Long)
     */
    final public $T $apply$G(final long i, final long j) {
        
        //#line 173 "x10/array/DistArray_BlockBlock_2.x10"
        this.validateIndex((long)(i), (long)(j));
        
        //#line 174 "x10/array/DistArray_BlockBlock_2.x10"
        final x10.core.Rail r$106524 = ((x10.core.Rail)(this.raw));
        
        //#line 174 "x10/array/DistArray_BlockBlock_2.x10"
        final x10.array.DistArray_BlockBlock_2 this$106522 = ((x10.array.DistArray_BlockBlock_2)(this));
        
        //#line 234 . "x10/array/DistArray_BlockBlock_2.x10"
        final long t$106620 = ((x10.array.DistArray_BlockBlock_2<$T>)this$106522).minIndex_2;
        
        //#line 234 . "x10/array/DistArray_BlockBlock_2.x10"
        final long t$106624 = ((j) - (((long)(t$106620))));
        
        //#line 234 . "x10/array/DistArray_BlockBlock_2.x10"
        final long t$106621 = ((x10.array.DistArray_BlockBlock_2<$T>)this$106522).minIndex_1;
        
        //#line 234 . "x10/array/DistArray_BlockBlock_2.x10"
        final long t$106622 = ((i) - (((long)(t$106621))));
        
        //#line 234 . "x10/array/DistArray_BlockBlock_2.x10"
        final long t$106623 = ((x10.array.DistArray_BlockBlock_2<$T>)this$106522).numElemsLocal_2;
        
        //#line 234 . "x10/array/DistArray_BlockBlock_2.x10"
        final long t$106625 = ((t$106622) * (((long)(t$106623))));
        
        //#line 174 "x10/array/DistArray_BlockBlock_2.x10"
        final long i$106525 = ((t$106624) + (((long)(t$106625))));
        
        //#line 38 . "x10/lang/Unsafe.x10"
        final $T t$106626 = (($T)(((x10.core.Rail<$T>)r$106524).$apply$G((long)(i$106525))));
        
        //#line 174 "x10/array/DistArray_BlockBlock_2.x10"
        return t$106626;
    }
    
    
    //#line 185 "x10/array/DistArray_BlockBlock_2.x10"
    /**
     * Return the element of this array corresponding to the given Point.
     * 
     * @param p the given Point
     * @return the element of this array corresponding to the given Point.
     * @see #set(T, Point)
     */
    final public $T $apply$G(final x10.lang.Point p) {
        
        //#line 185 "x10/array/DistArray_BlockBlock_2.x10"
        final x10.array.DistArray_BlockBlock_2 this$106529 = ((x10.array.DistArray_BlockBlock_2)(this));
        
        //#line 185 "x10/array/DistArray_BlockBlock_2.x10"
        final long i$106527 = p.$apply$O((long)(0L));
        
        //#line 185 "x10/array/DistArray_BlockBlock_2.x10"
        final long j$106528 = p.$apply$O((long)(1L));
        
        //#line 173 . "x10/array/DistArray_BlockBlock_2.x10"
        ((x10.array.DistArray_BlockBlock_2<$T>)this$106529).validateIndex((long)(i$106527), (long)(j$106528));
        
        //#line 174 . "x10/array/DistArray_BlockBlock_2.x10"
        final x10.core.Rail r$106534 = ((x10.core.Rail)(((x10.array.DistArray<$T>)this$106529).raw));
        
        //#line 234 .. "x10/array/DistArray_BlockBlock_2.x10"
        final long t$106627 = ((x10.array.DistArray_BlockBlock_2<$T>)this$106529).minIndex_2;
        
        //#line 234 .. "x10/array/DistArray_BlockBlock_2.x10"
        final long t$106631 = ((j$106528) - (((long)(t$106627))));
        
        //#line 234 .. "x10/array/DistArray_BlockBlock_2.x10"
        final long t$106628 = ((x10.array.DistArray_BlockBlock_2<$T>)this$106529).minIndex_1;
        
        //#line 234 .. "x10/array/DistArray_BlockBlock_2.x10"
        final long t$106629 = ((i$106527) - (((long)(t$106628))));
        
        //#line 234 .. "x10/array/DistArray_BlockBlock_2.x10"
        final long t$106630 = ((x10.array.DistArray_BlockBlock_2<$T>)this$106529).numElemsLocal_2;
        
        //#line 234 .. "x10/array/DistArray_BlockBlock_2.x10"
        final long t$106632 = ((t$106629) * (((long)(t$106630))));
        
        //#line 174 . "x10/array/DistArray_BlockBlock_2.x10"
        final long i$106535 = ((t$106631) + (((long)(t$106632))));
        
        //#line 38 .. "x10/lang/Unsafe.x10"
        final $T t$106633 = (($T)(((x10.core.Rail<$T>)r$106534).$apply$G((long)(i$106535))));
        
        //#line 185 "x10/array/DistArray_BlockBlock_2.x10"
        return t$106633;
    }
    
    
    //#line 198 "x10/array/DistArray_BlockBlock_2.x10"
    /**
     * Set the element of this array corresponding to the given index to the given value.
     * Return the new value of the element.
     * 
     * @param v the given value
     * @param i the given index in the first dimension
     * @param j the given index in the second dimension
     * @return the new value of the element of this array corresponding to the given index.
     * @see #operator(Long, Long)
     */
    final public $T $set__2x10$array$DistArray_BlockBlock_2$$T$G(final long i, final long j, final $T v) {
        
        //#line 199 "x10/array/DistArray_BlockBlock_2.x10"
        this.validateIndex((long)(i), (long)(j));
        
        //#line 200 "x10/array/DistArray_BlockBlock_2.x10"
        final x10.core.Rail r$106541 = ((x10.core.Rail)(this.raw));
        
        //#line 200 "x10/array/DistArray_BlockBlock_2.x10"
        final x10.array.DistArray_BlockBlock_2 this$106539 = ((x10.array.DistArray_BlockBlock_2)(this));
        
        //#line 234 . "x10/array/DistArray_BlockBlock_2.x10"
        final long t$106634 = ((x10.array.DistArray_BlockBlock_2<$T>)this$106539).minIndex_2;
        
        //#line 234 . "x10/array/DistArray_BlockBlock_2.x10"
        final long t$106638 = ((j) - (((long)(t$106634))));
        
        //#line 234 . "x10/array/DistArray_BlockBlock_2.x10"
        final long t$106635 = ((x10.array.DistArray_BlockBlock_2<$T>)this$106539).minIndex_1;
        
        //#line 234 . "x10/array/DistArray_BlockBlock_2.x10"
        final long t$106636 = ((i) - (((long)(t$106635))));
        
        //#line 234 . "x10/array/DistArray_BlockBlock_2.x10"
        final long t$106637 = ((x10.array.DistArray_BlockBlock_2<$T>)this$106539).numElemsLocal_2;
        
        //#line 234 . "x10/array/DistArray_BlockBlock_2.x10"
        final long t$106639 = ((t$106636) * (((long)(t$106637))));
        
        //#line 200 "x10/array/DistArray_BlockBlock_2.x10"
        final long i$106542 = ((t$106638) + (((long)(t$106639))));
        
        //#line 42 . "x10/lang/Unsafe.x10"
        ((x10.core.Rail<$T>)r$106541).$set__1x10$lang$Rail$$T$G((long)(i$106542), (($T)(v)));
        
        //#line 200 "x10/array/DistArray_BlockBlock_2.x10"
        return (($T)
                 v);
    }
    
    
    //#line 213 "x10/array/DistArray_BlockBlock_2.x10"
    /**
     * Set the element of this array corresponding to the given Point to the given value.
     * Return the new value of the element.
     * 
     * @param v the given value
     * @param p the given Point
     * @return the new value of the element of this array corresponding to the given Point.
     * @see #operator(Point)
     */
    final public $T $set__1x10$array$DistArray_BlockBlock_2$$T$G(final x10.lang.Point p, final $T v) {
        
        //#line 213 "x10/array/DistArray_BlockBlock_2.x10"
        final x10.array.DistArray_BlockBlock_2 this$106548 = ((x10.array.DistArray_BlockBlock_2)(this));
        
        //#line 213 "x10/array/DistArray_BlockBlock_2.x10"
        final long i$106545 = p.$apply$O((long)(0L));
        
        //#line 213 "x10/array/DistArray_BlockBlock_2.x10"
        final long j$106546 = p.$apply$O((long)(1L));
        
        //#line 199 . "x10/array/DistArray_BlockBlock_2.x10"
        ((x10.array.DistArray_BlockBlock_2<$T>)this$106548).validateIndex((long)(i$106545), (long)(j$106546));
        
        //#line 200 . "x10/array/DistArray_BlockBlock_2.x10"
        final x10.core.Rail r$106553 = ((x10.core.Rail)(((x10.array.DistArray<$T>)this$106548).raw));
        
        //#line 234 .. "x10/array/DistArray_BlockBlock_2.x10"
        final long t$106640 = ((x10.array.DistArray_BlockBlock_2<$T>)this$106548).minIndex_2;
        
        //#line 234 .. "x10/array/DistArray_BlockBlock_2.x10"
        final long t$106644 = ((j$106546) - (((long)(t$106640))));
        
        //#line 234 .. "x10/array/DistArray_BlockBlock_2.x10"
        final long t$106641 = ((x10.array.DistArray_BlockBlock_2<$T>)this$106548).minIndex_1;
        
        //#line 234 .. "x10/array/DistArray_BlockBlock_2.x10"
        final long t$106642 = ((i$106545) - (((long)(t$106641))));
        
        //#line 234 .. "x10/array/DistArray_BlockBlock_2.x10"
        final long t$106643 = ((x10.array.DistArray_BlockBlock_2<$T>)this$106548).numElemsLocal_2;
        
        //#line 234 .. "x10/array/DistArray_BlockBlock_2.x10"
        final long t$106645 = ((t$106642) * (((long)(t$106643))));
        
        //#line 200 . "x10/array/DistArray_BlockBlock_2.x10"
        final long i$106554 = ((t$106644) + (((long)(t$106645))));
        
        //#line 42 .. "x10/lang/Unsafe.x10"
        ((x10.core.Rail<$T>)r$106553).$set__1x10$lang$Rail$$T$G((long)(i$106554), (($T)(v)));
        
        //#line 213 "x10/array/DistArray_BlockBlock_2.x10"
        return (($T)
                 v);
    }
    
    
    //#line 221 "x10/array/DistArray_BlockBlock_2.x10"
    final public void validateIndex(final long i, final long j) {
        
        //#line 223 "x10/array/DistArray_BlockBlock_2.x10"
        final long t$106646 = this.minIndex_1;
        
        //#line 223 "x10/array/DistArray_BlockBlock_2.x10"
        boolean t$106650 = ((i) < (((long)(t$106646))));
        
        //#line 223 "x10/array/DistArray_BlockBlock_2.x10"
        if (!(t$106650)) {
            
            //#line 223 "x10/array/DistArray_BlockBlock_2.x10"
            final long t$106647 = this.minIndex_1;
            
            //#line 223 "x10/array/DistArray_BlockBlock_2.x10"
            final long t$106648 = this.numElemsLocal_1;
            
            //#line 223 "x10/array/DistArray_BlockBlock_2.x10"
            final long t$106649 = ((t$106647) + (((long)(t$106648))));
            
            //#line 223 "x10/array/DistArray_BlockBlock_2.x10"
            t$106650 = ((i) >= (((long)(t$106649))));
        }
        
        //#line 223 "x10/array/DistArray_BlockBlock_2.x10"
        boolean t$106652 = t$106650;
        
        //#line 223 "x10/array/DistArray_BlockBlock_2.x10"
        if (!(t$106650)) {
            
            //#line 224 "x10/array/DistArray_BlockBlock_2.x10"
            final long t$106651 = this.minIndex_2;
            
            //#line 223 "x10/array/DistArray_BlockBlock_2.x10"
            t$106652 = ((j) < (((long)(t$106651))));
        }
        
        //#line 223 "x10/array/DistArray_BlockBlock_2.x10"
        boolean t$106656 = t$106652;
        
        //#line 223 "x10/array/DistArray_BlockBlock_2.x10"
        if (!(t$106652)) {
            
            //#line 224 "x10/array/DistArray_BlockBlock_2.x10"
            final long t$106653 = this.minIndex_2;
            
            //#line 224 "x10/array/DistArray_BlockBlock_2.x10"
            final long t$106654 = this.numElemsLocal_2;
            
            //#line 224 "x10/array/DistArray_BlockBlock_2.x10"
            final long t$106655 = ((t$106653) + (((long)(t$106654))));
            
            //#line 223 "x10/array/DistArray_BlockBlock_2.x10"
            t$106656 = ((j) >= (((long)(t$106655))));
        }
        
        //#line 223 "x10/array/DistArray_BlockBlock_2.x10"
        if (t$106656) {
            
            //#line 225 "x10/array/DistArray_BlockBlock_2.x10"
            boolean t$106658 = ((i) < (((long)(0L))));
            
            //#line 225 "x10/array/DistArray_BlockBlock_2.x10"
            if (!(t$106658)) {
                
                //#line 225 "x10/array/DistArray_BlockBlock_2.x10"
                final long t$106657 = this.numElems_1;
                
                //#line 225 "x10/array/DistArray_BlockBlock_2.x10"
                t$106658 = ((i) >= (((long)(t$106657))));
            }
            
            //#line 225 "x10/array/DistArray_BlockBlock_2.x10"
            boolean t$106659 = t$106658;
            
            //#line 225 "x10/array/DistArray_BlockBlock_2.x10"
            if (!(t$106658)) {
                
                //#line 225 "x10/array/DistArray_BlockBlock_2.x10"
                t$106659 = ((j) < (((long)(0L))));
            }
            
            //#line 225 "x10/array/DistArray_BlockBlock_2.x10"
            boolean t$106661 = t$106659;
            
            //#line 225 "x10/array/DistArray_BlockBlock_2.x10"
            if (!(t$106659)) {
                
                //#line 225 "x10/array/DistArray_BlockBlock_2.x10"
                final long t$106660 = this.numElems_2;
                
                //#line 225 "x10/array/DistArray_BlockBlock_2.x10"
                t$106661 = ((j) >= (((long)(t$106660))));
            }
            
            //#line 225 "x10/array/DistArray_BlockBlock_2.x10"
            if (t$106661) {
                
                //#line 226 "x10/array/DistArray_BlockBlock_2.x10"
                x10.array.DistArray.raiseBoundsError((long)(i), (long)(j));
            }
            
            //#line 228 "x10/array/DistArray_BlockBlock_2.x10"
            x10.array.DistArray.raisePlaceError((long)(i), (long)(j));
        }
    }
    
    
    //#line 233 "x10/array/DistArray_BlockBlock_2.x10"
    final public long offset$O(final long i, final long j) {
        
        //#line 234 "x10/array/DistArray_BlockBlock_2.x10"
        final long t$106664 = this.minIndex_2;
        
        //#line 234 "x10/array/DistArray_BlockBlock_2.x10"
        final long t$106668 = ((j) - (((long)(t$106664))));
        
        //#line 234 "x10/array/DistArray_BlockBlock_2.x10"
        final long t$106665 = this.minIndex_1;
        
        //#line 234 "x10/array/DistArray_BlockBlock_2.x10"
        final long t$106666 = ((i) - (((long)(t$106665))));
        
        //#line 234 "x10/array/DistArray_BlockBlock_2.x10"
        final long t$106667 = this.numElemsLocal_2;
        
        //#line 234 "x10/array/DistArray_BlockBlock_2.x10"
        final long t$106669 = ((t$106666) * (((long)(t$106667))));
        
        //#line 234 "x10/array/DistArray_BlockBlock_2.x10"
        final long t$106670 = ((t$106668) + (((long)(t$106669))));
        
        //#line 234 "x10/array/DistArray_BlockBlock_2.x10"
        return t$106670;
    }
    
    
    //#line 245 "x10/array/DistArray_BlockBlock_2.x10"
    /**
     * Returns the specified rectangular patch of this array as a Rail.
     * 
     * @param space the IterationSpace representing the portion of this array to copy
     * @see offset
     * @throws ArrayIndexOutOfBoundsException if the specified region is not
     *        contained in this array
     */
    public x10.core.Rail getPatch(final x10.array.IterationSpace space) {
        
        //#line 246 "x10/array/DistArray_BlockBlock_2.x10"
        final x10.array.DenseIterationSpace_2 r = ((x10.array.DenseIterationSpace_2)(x10.rtt.Types.<x10.array.DenseIterationSpace_2> cast(space,x10.array.DenseIterationSpace_2.$RTT)));
        
        //#line 249 "x10/array/DistArray_BlockBlock_2.x10"
        final x10.array.DenseIterationSpace_2 t$106671 = ((x10.array.DenseIterationSpace_2)(this.localIndices));
        
        //#line 249 "x10/array/DistArray_BlockBlock_2.x10"
        final long t$106672 = t$106671.min0;
        
        //#line 249 "x10/array/DistArray_BlockBlock_2.x10"
        final long t$106673 = r.min0;
        
        //#line 249 "x10/array/DistArray_BlockBlock_2.x10"
        boolean t$106677 = ((t$106672) <= (((long)(t$106673))));
        
        //#line 249 "x10/array/DistArray_BlockBlock_2.x10"
        if (t$106677) {
            
            //#line 249 "x10/array/DistArray_BlockBlock_2.x10"
            final long t$106675 = r.max0;
            
            //#line 249 "x10/array/DistArray_BlockBlock_2.x10"
            final x10.array.DenseIterationSpace_2 t$106674 = ((x10.array.DenseIterationSpace_2)(this.localIndices));
            
            //#line 249 "x10/array/DistArray_BlockBlock_2.x10"
            final long t$106676 = t$106674.max0;
            
            //#line 249 "x10/array/DistArray_BlockBlock_2.x10"
            t$106677 = ((t$106675) <= (((long)(t$106676))));
        }
        
        //#line 249 "x10/array/DistArray_BlockBlock_2.x10"
        boolean t$106681 = t$106677;
        
        //#line 249 "x10/array/DistArray_BlockBlock_2.x10"
        if (t$106677) {
            
            //#line 250 "x10/array/DistArray_BlockBlock_2.x10"
            final x10.array.DenseIterationSpace_2 t$106678 = ((x10.array.DenseIterationSpace_2)(this.localIndices));
            
            //#line 250 "x10/array/DistArray_BlockBlock_2.x10"
            final long t$106679 = t$106678.min1;
            
            //#line 250 "x10/array/DistArray_BlockBlock_2.x10"
            final long t$106680 = r.min1;
            
            //#line 249 "x10/array/DistArray_BlockBlock_2.x10"
            t$106681 = ((t$106679) <= (((long)(t$106680))));
        }
        
        //#line 249 "x10/array/DistArray_BlockBlock_2.x10"
        boolean t$106685 = t$106681;
        
        //#line 249 "x10/array/DistArray_BlockBlock_2.x10"
        if (t$106681) {
            
            //#line 250 "x10/array/DistArray_BlockBlock_2.x10"
            final long t$106683 = r.max1;
            
            //#line 250 "x10/array/DistArray_BlockBlock_2.x10"
            final x10.array.DenseIterationSpace_2 t$106682 = ((x10.array.DenseIterationSpace_2)(this.localIndices));
            
            //#line 250 "x10/array/DistArray_BlockBlock_2.x10"
            final long t$106684 = t$106682.max1;
            
            //#line 249 "x10/array/DistArray_BlockBlock_2.x10"
            t$106685 = ((t$106683) <= (((long)(t$106684))));
        }
        
        //#line 249 "x10/array/DistArray_BlockBlock_2.x10"
        final boolean t$106692 = !(t$106685);
        
        //#line 248 "x10/array/DistArray_BlockBlock_2.x10"
        if (t$106692) {
            
            //#line 251 "x10/array/DistArray_BlockBlock_2.x10"
            final java.lang.String t$106687 = (("patch to copy: ") + (r));
            
            //#line 251 "x10/array/DistArray_BlockBlock_2.x10"
            final java.lang.String t$106688 = ((t$106687) + (" not contained in local indices: "));
            
            //#line 251 "x10/array/DistArray_BlockBlock_2.x10"
            final x10.array.DenseIterationSpace_2 t$106689 = ((x10.array.DenseIterationSpace_2)(this.localIndices));
            
            //#line 251 "x10/array/DistArray_BlockBlock_2.x10"
            final java.lang.String t$106690 = ((t$106688) + (t$106689));
            
            //#line 251 "x10/array/DistArray_BlockBlock_2.x10"
            final java.lang.ArrayIndexOutOfBoundsException t$106691 = ((java.lang.ArrayIndexOutOfBoundsException)(new java.lang.ArrayIndexOutOfBoundsException(t$106690)));
            
            //#line 251 "x10/array/DistArray_BlockBlock_2.x10"
            throw t$106691;
        }
        
        //#line 254 "x10/array/DistArray_BlockBlock_2.x10"
        final long t$106693 = r.size$O();
        
        //#line 254 "x10/array/DistArray_BlockBlock_2.x10"
        final x10.core.Rail patch = ((x10.core.Rail)(x10.core.Rail.<$T>makeUnsafe($T, ((long)(t$106693)), false)));
        
        //#line 255 "x10/array/DistArray_BlockBlock_2.x10"
        long patchIndex = 0L;
        
        //#line 256 "x10/array/DistArray_BlockBlock_2.x10"
        final long i1$106309min$106783 = r.min$O((long)(1L));
        
        //#line 256 "x10/array/DistArray_BlockBlock_2.x10"
        final long i1$106309max$106784 = r.max$O((long)(1L));
        
        //#line 256 "x10/array/DistArray_BlockBlock_2.x10"
        final long i0$106340min$106785 = r.min$O((long)(0L));
        
        //#line 256 "x10/array/DistArray_BlockBlock_2.x10"
        final long i0$106340max$106786 = r.max$O((long)(0L));
        
        //#line 256 "x10/array/DistArray_BlockBlock_2.x10"
        long i$106779 = i0$106340min$106785;
        
        //#line 256 "x10/array/DistArray_BlockBlock_2.x10"
        for (;
             true;
             ) {
            
            //#line 256 "x10/array/DistArray_BlockBlock_2.x10"
            final boolean t$106781 = ((i$106779) <= (((long)(i0$106340max$106786))));
            
            //#line 256 "x10/array/DistArray_BlockBlock_2.x10"
            if (!(t$106781)) {
                
                //#line 256 "x10/array/DistArray_BlockBlock_2.x10"
                break;
            }
            
            //#line 256 "x10/array/DistArray_BlockBlock_2.x10"
            long i$106773 = i1$106309min$106783;
            
            //#line 256 "x10/array/DistArray_BlockBlock_2.x10"
            for (;
                 true;
                 ) {
                
                //#line 256 "x10/array/DistArray_BlockBlock_2.x10"
                final boolean t$106775 = ((i$106773) <= (((long)(i1$106309max$106784))));
                
                //#line 256 "x10/array/DistArray_BlockBlock_2.x10"
                if (!(t$106775)) {
                    
                    //#line 256 "x10/array/DistArray_BlockBlock_2.x10"
                    break;
                }
                
                //#line 257 "x10/array/DistArray_BlockBlock_2.x10"
                final long pre$106755 = patchIndex;
                
                //#line 257 "x10/array/DistArray_BlockBlock_2.x10"
                final long t$106757 = ((patchIndex) + (((long)(1L))));
                
                //#line 257 "x10/array/DistArray_BlockBlock_2.x10"
                patchIndex = t$106757;
                
                //#line 257 "x10/array/DistArray_BlockBlock_2.x10"
                final x10.core.Rail t$106758 = ((x10.core.Rail)(this.raw));
                
                //#line 257 "x10/array/DistArray_BlockBlock_2.x10"
                final x10.array.DistArray_BlockBlock_2 this$106759 = ((x10.array.DistArray_BlockBlock_2)(this));
                
                //#line 234 . "x10/array/DistArray_BlockBlock_2.x10"
                final long t$106762 = ((x10.array.DistArray_BlockBlock_2<$T>)this$106759).minIndex_2;
                
                //#line 234 . "x10/array/DistArray_BlockBlock_2.x10"
                final long t$106763 = ((i$106773) - (((long)(t$106762))));
                
                //#line 234 . "x10/array/DistArray_BlockBlock_2.x10"
                final long t$106764 = ((x10.array.DistArray_BlockBlock_2<$T>)this$106759).minIndex_1;
                
                //#line 234 . "x10/array/DistArray_BlockBlock_2.x10"
                final long t$106765 = ((i$106779) - (((long)(t$106764))));
                
                //#line 234 . "x10/array/DistArray_BlockBlock_2.x10"
                final long t$106766 = ((x10.array.DistArray_BlockBlock_2<$T>)this$106759).numElemsLocal_2;
                
                //#line 234 . "x10/array/DistArray_BlockBlock_2.x10"
                final long t$106767 = ((t$106765) * (((long)(t$106766))));
                
                //#line 234 . "x10/array/DistArray_BlockBlock_2.x10"
                final long t$106768 = ((t$106763) + (((long)(t$106767))));
                
                //#line 257 "x10/array/DistArray_BlockBlock_2.x10"
                final $T t$106769 = (($T)(((x10.core.Rail<$T>)t$106758).$apply$G((long)(t$106768))));
                
                //#line 257 "x10/array/DistArray_BlockBlock_2.x10"
                ((x10.core.Rail<$T>)patch).$set__1x10$lang$Rail$$T$G((long)(pre$106755), (($T)(t$106769)));
                
                //#line 256 "x10/array/DistArray_BlockBlock_2.x10"
                final long t$106772 = ((i$106773) + (((long)(1L))));
                
                //#line 256 "x10/array/DistArray_BlockBlock_2.x10"
                i$106773 = t$106772;
            }
            
            //#line 256 "x10/array/DistArray_BlockBlock_2.x10"
            final long t$106778 = ((i$106779) + (((long)(1L))));
            
            //#line 256 "x10/array/DistArray_BlockBlock_2.x10"
            i$106779 = t$106778;
        }
        
        //#line 259 "x10/array/DistArray_BlockBlock_2.x10"
        return patch;
    }
    
    
    //#line 262 "x10/array/DistArray_BlockBlock_2.x10"
    private static long validateSize$O(final long m, final long n) {
        
        //#line 263 "x10/array/DistArray_BlockBlock_2.x10"
        boolean t$106715 = ((m) < (((long)(0L))));
        
        //#line 263 "x10/array/DistArray_BlockBlock_2.x10"
        if (!(t$106715)) {
            
            //#line 263 "x10/array/DistArray_BlockBlock_2.x10"
            t$106715 = ((n) < (((long)(0L))));
        }
        
        //#line 263 "x10/array/DistArray_BlockBlock_2.x10"
        if (t$106715) {
            
            //#line 263 "x10/array/DistArray_BlockBlock_2.x10"
            x10.array.DistArray.raiseNegativeArraySizeException();
        }
        
        //#line 264 "x10/array/DistArray_BlockBlock_2.x10"
        final long t$106717 = ((m) * (((long)(n))));
        
        //#line 264 "x10/array/DistArray_BlockBlock_2.x10"
        return t$106717;
    }
    
    public static long validateSize$P$O(final long m, final long n) {
        return x10.array.DistArray_BlockBlock_2.validateSize$O((long)(m), (long)(n));
    }
    
    
    //#line 23 "x10/array/DistArray_BlockBlock_2.x10"
    final public x10.array.DistArray_BlockBlock_2 x10$array$DistArray_BlockBlock_2$$this$x10$array$DistArray_BlockBlock_2() {
        
        //#line 23 "x10/array/DistArray_BlockBlock_2.x10"
        return x10.array.DistArray_BlockBlock_2.this;
    }
    
    
    //#line 23 "x10/array/DistArray_BlockBlock_2.x10"
    final public void __fieldInitializers_x10_array_DistArray_BlockBlock_2() {
        
    }
    
    @x10.runtime.impl.java.X10Generated
    final public static class $Closure$5<$T> extends x10.core.Ref implements x10.core.fun.Fun_0_0, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<$Closure$5> $RTT = 
            x10.rtt.StaticFunType.<$Closure$5> make($Closure$5.class,
                                                    1,
                                                    new x10.rtt.Type[] {
                                                        x10.rtt.ParameterizedType.make(x10.core.fun.Fun_0_0.$RTT, x10.rtt.ParameterizedType.make(x10.array.LocalState_BB2.$RTT, x10.rtt.UnresolvedType.PARAM(0)))
                                                    });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { if (i == 0) return $T; return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static <$T> x10.serialization.X10JavaSerializable $_deserialize_body(x10.array.DistArray_BlockBlock_2.$Closure$5<$T> $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            $_obj.$T = (x10.rtt.Type) $deserializer.readObject();
            $_obj.init = $deserializer.readObject();
            $_obj.m = $deserializer.readLong();
            $_obj.n = $deserializer.readLong();
            $_obj.pg = $deserializer.readObject();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.array.DistArray_BlockBlock_2.$Closure$5 $_obj = new x10.array.DistArray_BlockBlock_2.$Closure$5((java.lang.System[]) null, (x10.rtt.Type) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            $serializer.write(this.$T);
            $serializer.write(this.init);
            $serializer.write(this.m);
            $serializer.write(this.n);
            $serializer.write(this.pg);
            
        }
        
        // constructor just for allocation
        public $Closure$5(final java.lang.System[] $dummy, final x10.rtt.Type $T) {
            x10.array.DistArray_BlockBlock_2.$Closure$5.$initParams(this, $T);
            
        }
        
        // bridge for method abstract public ()=>U.operator()():U
        public x10.array.LocalState_BB2 $apply$G() {
            return $apply();
        }
        
        private x10.rtt.Type $T;
        
        // initializer of type parameters
        public static void $initParams(final $Closure$5 $this, final x10.rtt.Type $T) {
            $this.$T = $T;
            
        }
        // synthetic type for parameter mangling
        public static final class __3$1x10$lang$Long$3x10$lang$Long$3x10$array$DistArray_BlockBlock_2$$Closure$5$$T$2 {}
        
    
        
        public x10.array.LocalState_BB2 $apply() {
            
            //#line 68 "x10/array/DistArray_BlockBlock_2.x10"
            final x10.array.LocalState_BB2 t$106746 = x10.array.LocalState_BB2.<$T> make__3$1x10$lang$Long$3x10$lang$Long$3x10$array$LocalState_BB2$$S$2($T, ((x10.lang.PlaceGroup)(this.pg)), (long)(this.m), (long)(this.n), ((x10.core.fun.Fun_0_2)(this.init)));
            
            //#line 68 "x10/array/DistArray_BlockBlock_2.x10"
            return t$106746;
        }
        
        public x10.lang.PlaceGroup pg;
        public long m;
        public long n;
        public x10.core.fun.Fun_0_2<x10.core.Long,x10.core.Long,$T> init;
        
        public $Closure$5(final x10.rtt.Type $T, final x10.lang.PlaceGroup pg, final long m, final long n, final x10.core.fun.Fun_0_2<x10.core.Long,x10.core.Long,$T> init, __3$1x10$lang$Long$3x10$lang$Long$3x10$array$DistArray_BlockBlock_2$$Closure$5$$T$2 $dummy) {
            x10.array.DistArray_BlockBlock_2.$Closure$5.$initParams(this, $T);
             {
                ((x10.array.DistArray_BlockBlock_2.$Closure$5<$T>)this).pg = ((x10.lang.PlaceGroup)(pg));
                ((x10.array.DistArray_BlockBlock_2.$Closure$5<$T>)this).m = m;
                ((x10.array.DistArray_BlockBlock_2.$Closure$5<$T>)this).n = n;
                ((x10.array.DistArray_BlockBlock_2.$Closure$5<$T>)this).init = ((x10.core.fun.Fun_0_2)(init));
            }
        }
        
    }
    
    @x10.runtime.impl.java.X10Generated
    final public static class $Closure$6<$T> extends x10.core.Ref implements x10.core.fun.Fun_0_2, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<$Closure$6> $RTT = 
            x10.rtt.StaticFunType.<$Closure$6> make($Closure$6.class,
                                                    1,
                                                    new x10.rtt.Type[] {
                                                        x10.rtt.ParameterizedType.make(x10.core.fun.Fun_0_2.$RTT, x10.rtt.Types.LONG, x10.rtt.Types.LONG, x10.rtt.UnresolvedType.PARAM(0))
                                                    });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { if (i == 0) return $T; return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static <$T> x10.serialization.X10JavaSerializable $_deserialize_body(x10.array.DistArray_BlockBlock_2.$Closure$6<$T> $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            $_obj.$T = (x10.rtt.Type) $deserializer.readObject();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.array.DistArray_BlockBlock_2.$Closure$6 $_obj = new x10.array.DistArray_BlockBlock_2.$Closure$6((java.lang.System[]) null, (x10.rtt.Type) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            $serializer.write(this.$T);
            
        }
        
        // constructor just for allocation
        public $Closure$6(final java.lang.System[] $dummy, final x10.rtt.Type $T) {
            x10.array.DistArray_BlockBlock_2.$Closure$6.$initParams(this, $T);
            
        }
        
        // dispatcher for method abstract public (Z1,Z2)=>U.operator()(a1:Z1, a2:Z2):U
        public java.lang.Object $apply(final java.lang.Object a1, final x10.rtt.Type t1, final java.lang.Object a2, final x10.rtt.Type t2) {
            return $apply$G(x10.core.Long.$unbox(a1), x10.core.Long.$unbox(a2));
            
        }
        
        private x10.rtt.Type $T;
        
        // initializer of type parameters
        public static void $initParams(final $Closure$6 $this, final x10.rtt.Type $T) {
            $this.$T = $T;
            
        }
        
    
        
        public $T $apply$G(final long id$44, final long id$45) {
            
            //#line 103 "x10/array/DistArray_BlockBlock_2.x10"
            final $T t$106604 = (($T)(($T) x10.rtt.Types.zeroValue($T)));
            
            //#line 103 "x10/array/DistArray_BlockBlock_2.x10"
            return t$106604;
        }
        
        public $Closure$6(final x10.rtt.Type $T) {
            x10.array.DistArray_BlockBlock_2.$Closure$6.$initParams(this, $T);
             {
                
            }
        }
        
    }
    
    @x10.runtime.impl.java.X10Generated
    final public static class $Closure$7<$T> extends x10.core.Ref implements x10.core.fun.Fun_0_2, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<$Closure$7> $RTT = 
            x10.rtt.StaticFunType.<$Closure$7> make($Closure$7.class,
                                                    1,
                                                    new x10.rtt.Type[] {
                                                        x10.rtt.ParameterizedType.make(x10.core.fun.Fun_0_2.$RTT, x10.rtt.Types.LONG, x10.rtt.Types.LONG, x10.rtt.UnresolvedType.PARAM(0))
                                                    });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { if (i == 0) return $T; return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static <$T> x10.serialization.X10JavaSerializable $_deserialize_body(x10.array.DistArray_BlockBlock_2.$Closure$7<$T> $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            $_obj.$T = (x10.rtt.Type) $deserializer.readObject();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.array.DistArray_BlockBlock_2.$Closure$7 $_obj = new x10.array.DistArray_BlockBlock_2.$Closure$7((java.lang.System[]) null, (x10.rtt.Type) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            $serializer.write(this.$T);
            
        }
        
        // constructor just for allocation
        public $Closure$7(final java.lang.System[] $dummy, final x10.rtt.Type $T) {
            x10.array.DistArray_BlockBlock_2.$Closure$7.$initParams(this, $T);
            
        }
        
        // dispatcher for method abstract public (Z1,Z2)=>U.operator()(a1:Z1, a2:Z2):U
        public java.lang.Object $apply(final java.lang.Object a1, final x10.rtt.Type t1, final java.lang.Object a2, final x10.rtt.Type t2) {
            return $apply$G(x10.core.Long.$unbox(a1), x10.core.Long.$unbox(a2));
            
        }
        
        private x10.rtt.Type $T;
        
        // initializer of type parameters
        public static void $initParams(final $Closure$7 $this, final x10.rtt.Type $T) {
            $this.$T = $T;
            
        }
        
    
        
        public $T $apply$G(final long id$46, final long id$47) {
            
            //#line 116 "x10/array/DistArray_BlockBlock_2.x10"
            final $T t$106606 = (($T)(($T) x10.rtt.Types.zeroValue($T)));
            
            //#line 116 "x10/array/DistArray_BlockBlock_2.x10"
            return t$106606;
        }
        
        public $Closure$7(final x10.rtt.Type $T) {
            x10.array.DistArray_BlockBlock_2.$Closure$7.$initParams(this, $T);
             {
                
            }
        }
        
    }
    
}


