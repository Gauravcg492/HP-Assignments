package x10.array;

/**
 * A Dist represents a function mapping Points in an IterationSpace
 * to Places in a PlaceGroup. 
 * 
 * @see DistArray
 * @see IterationSpace
 * @see PlaceGroup
 */
@x10.runtime.impl.java.X10Generated
abstract public class Dist extends x10.core.Ref implements x10.serialization.X10JavaSerializable
{
    public static final x10.rtt.RuntimeType<Dist> $RTT = 
        x10.rtt.NamedType.<Dist> make("x10.array.Dist",
                                      Dist.class);
    
    public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
    
    public x10.rtt.Type<?> $getParam(int i) { return null; }
    
    public static x10.serialization.X10JavaSerializable $_deserialize_body(x10.array.Dist $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
        $_obj.is = $deserializer.readObject();
        $_obj.pg = $deserializer.readObject();
        return $_obj;
    }
    
    public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
        return null;
    }
    
    public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
        $serializer.write(this.is);
        $serializer.write(this.pg);
        
    }
    
    // constructor just for allocation
    public Dist(final java.lang.System[] $dummy) {
        
    }
    
    
    // properties
    
    //#line 22 "x10/array/Dist.x10"
    public x10.lang.PlaceGroup pg;
    
    //#line 22 "x10/array/Dist.x10"
    public x10.array.IterationSpace is;
    

    
    
    //#line 23 "x10/array/Dist.x10"
    final public long rank$O() {
        
        //#line 23 "x10/array/Dist.x10"
        final x10.array.IterationSpace t$104866 = ((x10.array.IterationSpace)(this.is));
        
        //#line 23 "x10/array/Dist.x10"
        final long t$104867 = t$104866.rank;
        
        //#line 23 "x10/array/Dist.x10"
        return t$104867;
    }
    
    
    //#line 25 "x10/array/Dist.x10"
    
    // constructor for non-virtual call
    final public x10.array.Dist x10$array$Dist$$init$S(final x10.lang.PlaceGroup pg, final x10.array.IterationSpace is) {
         {
            
            //#line 26 "x10/array/Dist.x10"
            this.pg = ((x10.lang.PlaceGroup)(pg));
            this.is = ((x10.array.IterationSpace)(is));
            
        }
        return this;
    }
    
    
    
    //#line 22 "x10/array/Dist.x10"
    final public x10.array.Dist x10$array$Dist$$this$x10$array$Dist() {
        
        //#line 22 "x10/array/Dist.x10"
        return x10.array.Dist.this;
    }
    
    
    //#line 22 "x10/array/Dist.x10"
    final public void __fieldInitializers_x10_array_Dist() {
        
    }
}


