package x10.array;


/**
 * Implementation of 4-dimensional Array using row-major ordering.
 */
@x10.runtime.impl.java.X10Generated
final public class Array_4<$T> extends x10.array.Array<$T> implements x10.core.fun.Fun_0_4, x10.serialization.X10JavaSerializable
{
    public static final x10.rtt.RuntimeType<Array_4> $RTT = 
        x10.rtt.NamedType.<Array_4> make("x10.array.Array_4",
                                         Array_4.class,
                                         1,
                                         new x10.rtt.Type[] {
                                             x10.rtt.ParameterizedType.make(x10.core.fun.Fun_0_4.$RTT, x10.rtt.Types.LONG, x10.rtt.Types.LONG, x10.rtt.Types.LONG, x10.rtt.Types.LONG, x10.rtt.UnresolvedType.PARAM(0)),
                                             x10.rtt.ParameterizedType.make(x10.array.Array.$RTT, x10.rtt.UnresolvedType.PARAM(0))
                                         });
    
    public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
    
    public x10.rtt.Type<?> $getParam(int i) { if (i == 0) return $T; return null; }
    
    private Object writeReplace() throws java.io.ObjectStreamException {
        return new x10.serialization.SerializationProxy(this);
    }
    
    public static <$T> x10.serialization.X10JavaSerializable $_deserialize_body(x10.array.Array_4<$T> $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
        x10.array.Array.$_deserialize_body($_obj, $deserializer);
        $_obj.$T = (x10.rtt.Type) $deserializer.readObject();
        $_obj.numElems_1 = $deserializer.readLong();
        $_obj.numElems_2 = $deserializer.readLong();
        $_obj.numElems_3 = $deserializer.readLong();
        $_obj.numElems_4 = $deserializer.readLong();
        return $_obj;
    }
    
    public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
        x10.array.Array_4 $_obj = new x10.array.Array_4((java.lang.System[]) null, (x10.rtt.Type) null);
        $deserializer.record_reference($_obj);
        return $_deserialize_body($_obj, $deserializer);
    }
    
    public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
        super.$_serialize($serializer);
        $serializer.write(this.$T);
        $serializer.write(this.numElems_1);
        $serializer.write(this.numElems_2);
        $serializer.write(this.numElems_3);
        $serializer.write(this.numElems_4);
        
    }
    
    // constructor just for allocation
    public Array_4(final java.lang.System[] $dummy, final x10.rtt.Type $T) {
        super($dummy, $T);
        x10.array.Array_4.$initParams(this, $T);
        
    }
    
    // dispatcher for method abstract public (Z1,Z2,Z3,Z4)=>U.operator()(a1:Z1, a2:Z2, a3:Z3, a4:Z4){}:U
    public java.lang.Object $apply(final java.lang.Object a1, final x10.rtt.Type t1, final java.lang.Object a2, final x10.rtt.Type t2, final java.lang.Object a3, final x10.rtt.Type t3, final java.lang.Object a4, final x10.rtt.Type t4) {
        return $apply$G(x10.core.Long.$unbox(a1), x10.core.Long.$unbox(a2), x10.core.Long.$unbox(a3), x10.core.Long.$unbox(a4));
        
    }
    
    // bridge for method abstract public x10.array.Array[T].operator()=(p:x10.lang.Point{self.rank==this(:x10.array.Array).rank()}, v:T){}:T{self==v}
    public $T $set__1x10$array$Array$$T$G(x10.lang.Point a1, $T a2) {
        return $set__1x10$array$Array_4$$T$G(a1, a2);
    }
    
    private x10.rtt.Type $T;
    
    // initializer of type parameters
    public static void $initParams(final Array_4 $this, final x10.rtt.Type $T) {
        $this.$T = $T;
        
    }
    // synthetic type for parameter mangling
    public static final class __4x10$array$Array_4$$T {}
    // synthetic type for parameter mangling
    public static final class __4$1x10$lang$Long$3x10$lang$Long$3x10$lang$Long$3x10$lang$Long$3x10$array$Array_4$$T$2 {}
    // synthetic type for parameter mangling
    public static final class __0$1x10$array$Array_4$$T$2 {}
    
    // properties
    
    //#line 25 "x10/array/Array_4.x10"
    /**
         * The number of elements in rank 1 (indexed 0..(numElems_1-1))
         */
    public long numElems_1;
    
    //#line 30 "x10/array/Array_4.x10"
    /**
         * The number of elements in rank 2 (indexed 0..(numElems_2-1)).
         */
    public long numElems_2;
    
    //#line 35 "x10/array/Array_4.x10"
    /**
         * The number of elements in rank 3 (indexed 0..(numElems_3-1)).
         */
    public long numElems_3;
    
    //#line 40 "x10/array/Array_4.x10"
    /**
         * The number of elements in rank 4 (indexed 0..(numElems_4-1)).
         */
    public long numElems_4;
    

    
    
    //#line 46 "x10/array/Array_4.x10"
    /**
     * @return the rank (dimensionality) of the Array
     */
    final public long rank$O() {
        
        //#line 46 "x10/array/Array_4.x10"
        return 4L;
    }
    
    
    //#line 52 "x10/array/Array_4.x10"
    /**
     * Construct a 4-dimensional array with indices [0..m-1][0..n-1][0..p-1][0..q-1]
     * whose elements are zero-initialized.
     */
    // creation method for java code (1-phase java constructor)
    public Array_4(final x10.rtt.Type $T, final long m, final long n, final long p, final long q) {
        this((java.lang.System[]) null, $T);
        x10$array$Array_4$$init$S(m, n, p, q);
    }
    
    // constructor for non-virtual call
    final public x10.array.Array_4<$T> x10$array$Array_4$$init$S(final long m, final long n, final long p, final long q) {
         {
            
            //#line 228 . "x10/array/Array_4.x10"
            boolean t$102767 = ((m) < (((long)(0L))));
            
            //#line 228 . "x10/array/Array_4.x10"
            if (!(t$102767)) {
                
                //#line 228 . "x10/array/Array_4.x10"
                t$102767 = ((n) < (((long)(0L))));
            }
            
            //#line 228 . "x10/array/Array_4.x10"
            boolean t$102768 = t$102767;
            
            //#line 228 . "x10/array/Array_4.x10"
            if (!(t$102767)) {
                
                //#line 228 . "x10/array/Array_4.x10"
                t$102768 = ((p) < (((long)(0L))));
            }
            
            //#line 228 . "x10/array/Array_4.x10"
            boolean t$102769 = t$102768;
            
            //#line 228 . "x10/array/Array_4.x10"
            if (!(t$102768)) {
                
                //#line 228 . "x10/array/Array_4.x10"
                t$102769 = ((q) < (((long)(0L))));
            }
            
            //#line 228 . "x10/array/Array_4.x10"
            if (t$102769) {
                
                //#line 228 . "x10/array/Array_4.x10"
                x10.array.Array.raiseNegativeArraySizeException();
            }
            
            //#line 229 . "x10/array/Array_4.x10"
            final long t$102771 = ((m) * (((long)(n))));
            
            //#line 229 . "x10/array/Array_4.x10"
            final long t$102772 = ((t$102771) * (((long)(p))));
            
            //#line 229 . "x10/array/Array_4.x10"
            final long t$102773 = ((t$102772) * (((long)(q))));
            
            //#line 53 "x10/array/Array_4.x10"
            /*super.*/x10$array$Array$$init$S(t$102773, ((boolean)(true)));
            
            //#line 54 "x10/array/Array_4.x10"
            this.numElems_1 = m;
            this.numElems_2 = n;
            this.numElems_3 = p;
            this.numElems_4 = q;
            
        }
        return this;
    }
    
    
    
    //#line 61 "x10/array/Array_4.x10"
    /**
     * Construct a 4-dimensional array with indices [0..m-1][0..n-1][0..p-1][0..q-1]
     * whose elements are initialized to init.
     */
    // creation method for java code (1-phase java constructor)
    public Array_4(final x10.rtt.Type $T, final long m, final long n, final long p, final long q, final $T init, __4x10$array$Array_4$$T $dummy) {
        this((java.lang.System[]) null, $T);
        x10$array$Array_4$$init$S(m, n, p, q, init, (x10.array.Array_4.__4x10$array$Array_4$$T) null);
    }
    
    // constructor for non-virtual call
    final public x10.array.Array_4<$T> x10$array$Array_4$$init$S(final long m, final long n, final long p, final long q, final $T init, __4x10$array$Array_4$$T $dummy) {
         {
            
            //#line 228 . "x10/array/Array_4.x10"
            boolean t$102779 = ((m) < (((long)(0L))));
            
            //#line 228 . "x10/array/Array_4.x10"
            if (!(t$102779)) {
                
                //#line 228 . "x10/array/Array_4.x10"
                t$102779 = ((n) < (((long)(0L))));
            }
            
            //#line 228 . "x10/array/Array_4.x10"
            boolean t$102780 = t$102779;
            
            //#line 228 . "x10/array/Array_4.x10"
            if (!(t$102779)) {
                
                //#line 228 . "x10/array/Array_4.x10"
                t$102780 = ((p) < (((long)(0L))));
            }
            
            //#line 228 . "x10/array/Array_4.x10"
            boolean t$102781 = t$102780;
            
            //#line 228 . "x10/array/Array_4.x10"
            if (!(t$102780)) {
                
                //#line 228 . "x10/array/Array_4.x10"
                t$102781 = ((q) < (((long)(0L))));
            }
            
            //#line 228 . "x10/array/Array_4.x10"
            if (t$102781) {
                
                //#line 228 . "x10/array/Array_4.x10"
                x10.array.Array.raiseNegativeArraySizeException();
            }
            
            //#line 229 . "x10/array/Array_4.x10"
            final long t$102783 = ((m) * (((long)(n))));
            
            //#line 229 . "x10/array/Array_4.x10"
            final long t$102784 = ((t$102783) * (((long)(p))));
            
            //#line 229 . "x10/array/Array_4.x10"
            final long t$102785 = ((t$102784) * (((long)(q))));
            
            //#line 62 "x10/array/Array_4.x10"
            /*super.*/x10$array$Array$$init$S(t$102785, ((boolean)(false)));
            
            //#line 63 "x10/array/Array_4.x10"
            this.numElems_1 = m;
            this.numElems_2 = n;
            this.numElems_3 = p;
            this.numElems_4 = q;
            
            
            //#line 64 "x10/array/Array_4.x10"
            final x10.core.Rail t$102528 = ((x10.core.Rail)(this.raw));
            
            //#line 64 "x10/array/Array_4.x10"
            ((x10.core.Rail<$T>)t$102528).fill__0x10$lang$Rail$$T((($T)(init)));
        }
        return this;
    }
    
    
    
    //#line 71 "x10/array/Array_4.x10"
    /**
     * Construct a 4-dimensional array with indices [0..m-1][0..n-1][0..p-1][0..q-1]
     * whose elements are initialized to the value returned by the init closure for each index.
     */
    // creation method for java code (1-phase java constructor)
    public Array_4(final x10.rtt.Type $T, final long m, final long n, final long p, final long q, final x10.core.fun.Fun_0_4<x10.core.Long,x10.core.Long,x10.core.Long,x10.core.Long,$T> init, __4$1x10$lang$Long$3x10$lang$Long$3x10$lang$Long$3x10$lang$Long$3x10$array$Array_4$$T$2 $dummy) {
        this((java.lang.System[]) null, $T);
        x10$array$Array_4$$init$S(m, n, p, q, init, (x10.array.Array_4.__4$1x10$lang$Long$3x10$lang$Long$3x10$lang$Long$3x10$lang$Long$3x10$array$Array_4$$T$2) null);
    }
    
    // constructor for non-virtual call
    final public x10.array.Array_4<$T> x10$array$Array_4$$init$S(final long m, final long n, final long p, final long q, final x10.core.fun.Fun_0_4<x10.core.Long,x10.core.Long,x10.core.Long,x10.core.Long,$T> init, __4$1x10$lang$Long$3x10$lang$Long$3x10$lang$Long$3x10$lang$Long$3x10$array$Array_4$$T$2 $dummy) {
         {
            
            //#line 228 . "x10/array/Array_4.x10"
            boolean t$102834 = ((m) < (((long)(0L))));
            
            //#line 228 . "x10/array/Array_4.x10"
            if (!(t$102834)) {
                
                //#line 228 . "x10/array/Array_4.x10"
                t$102834 = ((n) < (((long)(0L))));
            }
            
            //#line 228 . "x10/array/Array_4.x10"
            boolean t$102835 = t$102834;
            
            //#line 228 . "x10/array/Array_4.x10"
            if (!(t$102834)) {
                
                //#line 228 . "x10/array/Array_4.x10"
                t$102835 = ((p) < (((long)(0L))));
            }
            
            //#line 228 . "x10/array/Array_4.x10"
            boolean t$102836 = t$102835;
            
            //#line 228 . "x10/array/Array_4.x10"
            if (!(t$102835)) {
                
                //#line 228 . "x10/array/Array_4.x10"
                t$102836 = ((q) < (((long)(0L))));
            }
            
            //#line 228 . "x10/array/Array_4.x10"
            if (t$102836) {
                
                //#line 228 . "x10/array/Array_4.x10"
                x10.array.Array.raiseNegativeArraySizeException();
            }
            
            //#line 229 . "x10/array/Array_4.x10"
            final long t$102838 = ((m) * (((long)(n))));
            
            //#line 229 . "x10/array/Array_4.x10"
            final long t$102839 = ((t$102838) * (((long)(p))));
            
            //#line 229 . "x10/array/Array_4.x10"
            final long t$102840 = ((t$102839) * (((long)(q))));
            
            //#line 72 "x10/array/Array_4.x10"
            /*super.*/x10$array$Array$$init$S(t$102840, ((boolean)(false)));
            
            //#line 73 "x10/array/Array_4.x10"
            this.numElems_1 = m;
            this.numElems_2 = n;
            this.numElems_3 = p;
            this.numElems_4 = q;
            
            
            //#line 74 "x10/array/Array_4.x10"
            final long i$101757max$102842 = ((m) - (((long)(1L))));
            
            //#line 74 "x10/array/Array_4.x10"
            long i$102827 = 0L;
            
            //#line 74 "x10/array/Array_4.x10"
            for (;
                 true;
                 ) {
                
                //#line 74 "x10/array/Array_4.x10"
                final boolean t$102829 = ((i$102827) <= (((long)(i$101757max$102842))));
                
                //#line 74 "x10/array/Array_4.x10"
                if (!(t$102829)) {
                    
                    //#line 74 "x10/array/Array_4.x10"
                    break;
                }
                
                //#line 75 "x10/array/Array_4.x10"
                final long i$101739max$102823 = ((n) - (((long)(1L))));
                
                //#line 75 "x10/array/Array_4.x10"
                long i$102820 = 0L;
                
                //#line 75 "x10/array/Array_4.x10"
                for (;
                     true;
                     ) {
                    
                    //#line 75 "x10/array/Array_4.x10"
                    final boolean t$102822 = ((i$102820) <= (((long)(i$101739max$102823))));
                    
                    //#line 75 "x10/array/Array_4.x10"
                    if (!(t$102822)) {
                        
                        //#line 75 "x10/array/Array_4.x10"
                        break;
                    }
                    
                    //#line 76 "x10/array/Array_4.x10"
                    final long i$101721max$102816 = ((p) - (((long)(1L))));
                    
                    //#line 76 "x10/array/Array_4.x10"
                    long i$102813 = 0L;
                    
                    //#line 76 "x10/array/Array_4.x10"
                    for (;
                         true;
                         ) {
                        
                        //#line 76 "x10/array/Array_4.x10"
                        final boolean t$102815 = ((i$102813) <= (((long)(i$101721max$102816))));
                        
                        //#line 76 "x10/array/Array_4.x10"
                        if (!(t$102815)) {
                            
                            //#line 76 "x10/array/Array_4.x10"
                            break;
                        }
                        
                        //#line 77 "x10/array/Array_4.x10"
                        final long i$101703max$102809 = ((q) - (((long)(1L))));
                        
                        //#line 77 "x10/array/Array_4.x10"
                        long i$102806 = 0L;
                        
                        //#line 77 "x10/array/Array_4.x10"
                        for (;
                             true;
                             ) {
                            
                            //#line 77 "x10/array/Array_4.x10"
                            final boolean t$102808 = ((i$102806) <= (((long)(i$101703max$102809))));
                            
                            //#line 77 "x10/array/Array_4.x10"
                            if (!(t$102808)) {
                                
                                //#line 77 "x10/array/Array_4.x10"
                                break;
                            }
                            
                            //#line 78 "x10/array/Array_4.x10"
                            final x10.core.Rail t$102787 = ((x10.core.Rail)(this.raw));
                            
                            //#line 78 "x10/array/Array_4.x10"
                            final x10.array.Array_4 this$102788 = ((x10.array.Array_4)(this));
                            
                            //#line 161 . "x10/array/Array_4.x10"
                            final long t$102793 = ((x10.array.Array_4<$T>)this$102788).numElems_4;
                            
                            //#line 161 . "x10/array/Array_4.x10"
                            final long t$102794 = ((x10.array.Array_4<$T>)this$102788).numElems_3;
                            
                            //#line 161 . "x10/array/Array_4.x10"
                            final long t$102795 = ((x10.array.Array_4<$T>)this$102788).numElems_2;
                            
                            //#line 161 . "x10/array/Array_4.x10"
                            final long t$102796 = ((i$102827) * (((long)(t$102795))));
                            
                            //#line 161 . "x10/array/Array_4.x10"
                            final long t$102797 = ((i$102820) + (((long)(t$102796))));
                            
                            //#line 161 . "x10/array/Array_4.x10"
                            final long t$102798 = ((t$102794) * (((long)(t$102797))));
                            
                            //#line 161 . "x10/array/Array_4.x10"
                            final long t$102799 = ((i$102813) + (((long)(t$102798))));
                            
                            //#line 161 . "x10/array/Array_4.x10"
                            final long t$102800 = ((t$102793) * (((long)(t$102799))));
                            
                            //#line 161 . "x10/array/Array_4.x10"
                            final long t$102801 = ((i$102806) + (((long)(t$102800))));
                            
                            //#line 78 "x10/array/Array_4.x10"
                            final $T t$102802 = (($T)((($T)
                                                        ((x10.core.fun.Fun_0_4<x10.core.Long,x10.core.Long,x10.core.Long,x10.core.Long,$T>)init).$apply(x10.core.Long.$box(i$102827), x10.rtt.Types.LONG, x10.core.Long.$box(i$102820), x10.rtt.Types.LONG, x10.core.Long.$box(i$102813), x10.rtt.Types.LONG, x10.core.Long.$box(i$102806), x10.rtt.Types.LONG))));
                            
                            //#line 78 "x10/array/Array_4.x10"
                            ((x10.core.Rail<$T>)t$102787).$set__1x10$lang$Rail$$T$G((long)(t$102801), (($T)(t$102802)));
                            
                            //#line 77 "x10/array/Array_4.x10"
                            final long t$102805 = ((i$102806) + (((long)(1L))));
                            
                            //#line 77 "x10/array/Array_4.x10"
                            i$102806 = t$102805;
                        }
                        
                        //#line 76 "x10/array/Array_4.x10"
                        final long t$102812 = ((i$102813) + (((long)(1L))));
                        
                        //#line 76 "x10/array/Array_4.x10"
                        i$102813 = t$102812;
                    }
                    
                    //#line 75 "x10/array/Array_4.x10"
                    final long t$102819 = ((i$102820) + (((long)(1L))));
                    
                    //#line 75 "x10/array/Array_4.x10"
                    i$102820 = t$102819;
                }
                
                //#line 74 "x10/array/Array_4.x10"
                final long t$102826 = ((i$102827) + (((long)(1L))));
                
                //#line 74 "x10/array/Array_4.x10"
                i$102827 = t$102826;
            }
        }
        return this;
    }
    
    
    
    //#line 89 "x10/array/Array_4.x10"
    /**
     * Construct a new 4-dimensional array by copying all elements of src
     * @param src The source array to copy
     */
    // creation method for java code (1-phase java constructor)
    public Array_4(final x10.rtt.Type $T, final x10.array.Array_4<$T> src, __0$1x10$array$Array_4$$T$2 $dummy) {
        this((java.lang.System[]) null, $T);
        x10$array$Array_4$$init$S(src, (x10.array.Array_4.__0$1x10$array$Array_4$$T$2) null);
    }
    
    // constructor for non-virtual call
    final public x10.array.Array_4<$T> x10$array$Array_4$$init$S(final x10.array.Array_4<$T> src, __0$1x10$array$Array_4$$T$2 $dummy) {
         {
            
            //#line 90 "x10/array/Array_4.x10"
            final x10.array.Array this$101874 = ((x10.array.Array)(this));
            
            //#line 90 "x10/array/Array_4.x10"
            final x10.core.Rail t$102567 = ((x10.core.Rail)(((x10.array.Array<$T>)src).raw));
            
            //#line 90 "x10/array/Array_4.x10"
            final x10.core.Rail r$101873 = ((x10.core.Rail)(new x10.core.Rail<$T>($T, ((x10.core.Rail)(t$102567)), (x10.core.Rail.__0$1x10$lang$Rail$$T$2) null)));
            
            //#line 65 . "x10/array/Array.x10"
            final long t$102843 = ((x10.core.Rail<$T>)r$101873).size;
            
            //#line 65 . "x10/array/Array.x10"
            ((x10.array.Array<$T>)this$101874).size = t$102843;
            
            //#line 66 . "x10/array/Array.x10"
            ((x10.array.Array<$T>)this$101874).raw = ((x10.core.Rail)(r$101873));
            
            //#line 91 "x10/array/Array_4.x10"
            final long t$102844 = ((x10.array.Array_4<$T>)src).numElems_1;
            
            //#line 91 "x10/array/Array_4.x10"
            final long t$102845 = ((x10.array.Array_4<$T>)src).numElems_2;
            
            //#line 91 "x10/array/Array_4.x10"
            final long t$102846 = ((x10.array.Array_4<$T>)src).numElems_3;
            
            //#line 91 "x10/array/Array_4.x10"
            final long t$102847 = ((x10.array.Array_4<$T>)src).numElems_4;
            
            //#line 91 "x10/array/Array_4.x10"
            this.numElems_1 = t$102844;
            this.numElems_2 = t$102845;
            this.numElems_3 = t$102846;
            this.numElems_4 = t$102847;
            
        }
        return this;
    }
    
    
    
    //#line 95 "x10/array/Array_4.x10"
    // creation method for java code (1-phase java constructor)
    public Array_4(final x10.rtt.Type $T, final x10.core.Rail<$T> r, final long m, final long n, final long p, final long q, __0$1x10$array$Array_4$$T$2 $dummy) {
        this((java.lang.System[]) null, $T);
        x10$array$Array_4$$init$S(r, m, n, p, q, (x10.array.Array_4.__0$1x10$array$Array_4$$T$2) null);
    }
    
    // constructor for non-virtual call
    final public x10.array.Array_4<$T> x10$array$Array_4$$init$S(final x10.core.Rail<$T> r, final long m, final long n, final long p, final long q, __0$1x10$array$Array_4$$T$2 $dummy) {
         {
            
            //#line 96 "x10/array/Array_4.x10"
            final x10.array.Array this$101880 = ((x10.array.Array)(this));
            
            //#line 65 . "x10/array/Array.x10"
            final long t$102849 = ((x10.core.Rail<$T>)r).size;
            
            //#line 65 . "x10/array/Array.x10"
            ((x10.array.Array<$T>)this$101880).size = t$102849;
            
            //#line 66 . "x10/array/Array.x10"
            ((x10.array.Array<$T>)this$101880).raw = ((x10.core.Rail)(r));
            
            //#line 97 "x10/array/Array_4.x10"
            this.numElems_1 = m;
            this.numElems_2 = n;
            this.numElems_3 = p;
            this.numElems_4 = q;
            
        }
        return this;
    }
    
    
    
    //#line 103 "x10/array/Array_4.x10"
    /**
     * Construct an Array_4 view over an existing Rail
     */
    public static <$T>x10.array.Array_4 makeView__0$1x10$array$Array_4$$T$2(final x10.rtt.Type $T, final x10.core.Rail<$T> r, final long m, final long n, final long p, final long q) {
        
        //#line 104 "x10/array/Array_4.x10"
        final long t$102574 = ((n) * (((long)(m))));
        
        //#line 104 "x10/array/Array_4.x10"
        final long t$102575 = ((t$102574) * (((long)(p))));
        
        //#line 104 "x10/array/Array_4.x10"
        final long size = ((t$102575) * (((long)(q))));
        
        //#line 105 "x10/array/Array_4.x10"
        final long t$102576 = ((x10.core.Rail<$T>)r).size;
        
        //#line 105 "x10/array/Array_4.x10"
        final boolean t$102588 = ((long) size) != ((long) t$102576);
        
        //#line 105 "x10/array/Array_4.x10"
        if (t$102588) {
            
            //#line 105 "x10/array/Array_4.x10"
            final java.lang.String t$102577 = (("size mismatch: ") + ((x10.core.Long.$box(m))));
            
            //#line 105 "x10/array/Array_4.x10"
            final java.lang.String t$102578 = ((t$102577) + (" * "));
            
            //#line 105 "x10/array/Array_4.x10"
            final java.lang.String t$102579 = ((t$102578) + ((x10.core.Long.$box(n))));
            
            //#line 105 "x10/array/Array_4.x10"
            final java.lang.String t$102580 = ((t$102579) + (" * "));
            
            //#line 105 "x10/array/Array_4.x10"
            final java.lang.String t$102581 = ((t$102580) + ((x10.core.Long.$box(p))));
            
            //#line 105 "x10/array/Array_4.x10"
            final java.lang.String t$102582 = ((t$102581) + (" * "));
            
            //#line 105 "x10/array/Array_4.x10"
            final java.lang.String t$102583 = ((t$102582) + ((x10.core.Long.$box(q))));
            
            //#line 105 "x10/array/Array_4.x10"
            final java.lang.String t$102584 = ((t$102583) + (" != "));
            
            //#line 105 "x10/array/Array_4.x10"
            final long t$102585 = ((x10.core.Rail<$T>)r).size;
            
            //#line 105 "x10/array/Array_4.x10"
            final java.lang.String t$102586 = ((t$102584) + ((x10.core.Long.$box(t$102585))));
            
            //#line 105 "x10/array/Array_4.x10"
            final x10.lang.IllegalOperationException t$102587 = ((x10.lang.IllegalOperationException)(new x10.lang.IllegalOperationException(t$102586)));
            
            //#line 105 "x10/array/Array_4.x10"
            throw t$102587;
        }
        
        //#line 106 "x10/array/Array_4.x10"
        final x10.array.Array_4 alloc$101700 = ((x10.array.Array_4)(new x10.array.Array_4<$T>((java.lang.System[]) null, $T)));
        
        //#line 106 "x10/array/Array_4.x10"
        alloc$101700.x10$array$Array_4$$init$S(((x10.core.Rail)(r)), ((long)(m)), ((long)(n)), ((long)(p)), ((long)(q)), (x10.array.Array_4.__0$1x10$array$Array_4$$T$2) null);
        
        //#line 106 "x10/array/Array_4.x10"
        return alloc$101700;
    }
    
    
    //#line 115 "x10/array/Array_4.x10"
    /**
     * Return the string representation of this array.
     * 
     * @return the string representation of this array.
     */
    public java.lang.String toString() {
        
        //#line 116 "x10/array/Array_4.x10"
        final java.lang.String t$102589 = this.toString((long)(10L));
        
        //#line 116 "x10/array/Array_4.x10"
        return t$102589;
    }
    
    
    //#line 125 "x10/array/Array_4.x10"
    /**
     * Return the string representation of this array.
     *
     * @param limit maximum number of elements to print
     * @return the string representation of this array.
     */
    public java.lang.String toString(final long limit) {
        
        //#line 126 "x10/array/Array_4.x10"
        final x10.util.StringBuilder sb = ((x10.util.StringBuilder)(new x10.util.StringBuilder((java.lang.System[]) null)));
        
        //#line 126 "x10/array/Array_4.x10"
        sb.x10$util$StringBuilder$$init$S();
        
        //#line 127 "x10/array/Array_4.x10"
        sb.add(((java.lang.String)("[")));
        
        //#line 128 "x10/array/Array_4.x10"
        long printed = 0L;
        
        //#line 129 "x10/array/Array_4.x10"
        final long t$102929 = this.numElems_1;
        
        //#line 129 "x10/array/Array_4.x10"
        final long i$101829max$102930 = ((t$102929) - (((long)(1L))));
        
        //#line 129 "x10/array/Array_4.x10"
        long i$102925 = 0L;
        
        //#line 129 "x10/array/Array_4.x10"
        outer$102926: 
        //#line 129 "x10/array/Array_4.x10"
        for (;
             true;
             ) {
            
            //#line 129 "x10/array/Array_4.x10"
            final boolean t$102928 = ((i$102925) <= (((long)(i$101829max$102930))));
            
            //#line 129 "x10/array/Array_4.x10"
            if (!(t$102928)) {
                
                //#line 129 "x10/array/Array_4.x10"
                break;
            }
            
            //#line 130 "x10/array/Array_4.x10"
            final long t$102920 = this.numElems_2;
            
            //#line 130 "x10/array/Array_4.x10"
            final long i$101811max$102921 = ((t$102920) - (((long)(1L))));
            
            //#line 130 "x10/array/Array_4.x10"
            long i$102917 = 0L;
            
            //#line 130 "x10/array/Array_4.x10"
            for (;
                 true;
                 ) {
                
                //#line 130 "x10/array/Array_4.x10"
                final boolean t$102919 = ((i$102917) <= (((long)(i$101811max$102921))));
                
                //#line 130 "x10/array/Array_4.x10"
                if (!(t$102919)) {
                    
                    //#line 130 "x10/array/Array_4.x10"
                    break;
                }
                
                //#line 131 "x10/array/Array_4.x10"
                final long t$102907 = this.numElems_3;
                
                //#line 131 "x10/array/Array_4.x10"
                final long i$101793max$102908 = ((t$102907) - (((long)(1L))));
                
                //#line 131 "x10/array/Array_4.x10"
                long i$102904 = 0L;
                
                //#line 131 "x10/array/Array_4.x10"
                for (;
                     true;
                     ) {
                    
                    //#line 131 "x10/array/Array_4.x10"
                    final boolean t$102906 = ((i$102904) <= (((long)(i$101793max$102908))));
                    
                    //#line 131 "x10/array/Array_4.x10"
                    if (!(t$102906)) {
                        
                        //#line 131 "x10/array/Array_4.x10"
                        break;
                    }
                    
                    //#line 132 "x10/array/Array_4.x10"
                    final long t$102894 = this.numElems_4;
                    
                    //#line 132 "x10/array/Array_4.x10"
                    final long i$101775max$102895 = ((t$102894) - (((long)(1L))));
                    
                    //#line 132 "x10/array/Array_4.x10"
                    long i$102891 = 0L;
                    
                    //#line 132 "x10/array/Array_4.x10"
                    for (;
                         true;
                         ) {
                        
                        //#line 132 "x10/array/Array_4.x10"
                        final boolean t$102893 = ((i$102891) <= (((long)(i$101775max$102895))));
                        
                        //#line 132 "x10/array/Array_4.x10"
                        if (!(t$102893)) {
                            
                            //#line 132 "x10/array/Array_4.x10"
                            break;
                        }
                        
                        //#line 133 "x10/array/Array_4.x10"
                        final boolean t$102851 = ((long) i$102891) != ((long) 0L);
                        
                        //#line 133 "x10/array/Array_4.x10"
                        if (t$102851) {
                            
                            //#line 133 "x10/array/Array_4.x10"
                            sb.add(((java.lang.String)(", ")));
                        }
                        
                        //#line 134 "x10/array/Array_4.x10"
                        final x10.array.Array_4 this$102852 = ((x10.array.Array_4)(this));
                        
                        //#line 175 . "x10/array/Array_4.x10"
                        boolean t$102857 = ((i$102925) < (((long)(0L))));
                        
                        //#line 175 . "x10/array/Array_4.x10"
                        if (!(t$102857)) {
                            
                            //#line 175 . "x10/array/Array_4.x10"
                            final long t$102858 = ((x10.array.Array_4<$T>)this$102852).numElems_1;
                            
                            //#line 175 . "x10/array/Array_4.x10"
                            t$102857 = ((i$102925) >= (((long)(t$102858))));
                        }
                        
                        //#line 175 . "x10/array/Array_4.x10"
                        boolean t$102859 = t$102857;
                        
                        //#line 175 . "x10/array/Array_4.x10"
                        if (!(t$102857)) {
                            
                            //#line 175 . "x10/array/Array_4.x10"
                            t$102859 = ((i$102917) < (((long)(0L))));
                        }
                        
                        //#line 175 . "x10/array/Array_4.x10"
                        boolean t$102860 = t$102859;
                        
                        //#line 175 . "x10/array/Array_4.x10"
                        if (!(t$102859)) {
                            
                            //#line 176 . "x10/array/Array_4.x10"
                            final long t$102861 = ((x10.array.Array_4<$T>)this$102852).numElems_2;
                            
                            //#line 175 . "x10/array/Array_4.x10"
                            t$102860 = ((i$102917) >= (((long)(t$102861))));
                        }
                        
                        //#line 175 . "x10/array/Array_4.x10"
                        boolean t$102862 = t$102860;
                        
                        //#line 175 . "x10/array/Array_4.x10"
                        if (!(t$102860)) {
                            
                            //#line 175 . "x10/array/Array_4.x10"
                            t$102862 = ((i$102904) < (((long)(0L))));
                        }
                        
                        //#line 175 . "x10/array/Array_4.x10"
                        boolean t$102863 = t$102862;
                        
                        //#line 175 . "x10/array/Array_4.x10"
                        if (!(t$102862)) {
                            
                            //#line 177 . "x10/array/Array_4.x10"
                            final long t$102864 = ((x10.array.Array_4<$T>)this$102852).numElems_3;
                            
                            //#line 175 . "x10/array/Array_4.x10"
                            t$102863 = ((i$102904) >= (((long)(t$102864))));
                        }
                        
                        //#line 175 . "x10/array/Array_4.x10"
                        boolean t$102865 = t$102863;
                        
                        //#line 175 . "x10/array/Array_4.x10"
                        if (!(t$102863)) {
                            
                            //#line 175 . "x10/array/Array_4.x10"
                            t$102865 = ((i$102891) < (((long)(0L))));
                        }
                        
                        //#line 175 . "x10/array/Array_4.x10"
                        boolean t$102866 = t$102865;
                        
                        //#line 175 . "x10/array/Array_4.x10"
                        if (!(t$102865)) {
                            
                            //#line 178 . "x10/array/Array_4.x10"
                            final long t$102867 = ((x10.array.Array_4<$T>)this$102852).numElems_4;
                            
                            //#line 175 . "x10/array/Array_4.x10"
                            t$102866 = ((i$102891) >= (((long)(t$102867))));
                        }
                        
                        //#line 175 . "x10/array/Array_4.x10"
                        if (t$102866) {
                            
                            //#line 179 . "x10/array/Array_4.x10"
                            x10.array.Array.raiseBoundsError((long)(i$102925), (long)(i$102917), (long)(i$102904), (long)(i$102891));
                        }
                        
                        //#line 181 . "x10/array/Array_4.x10"
                        final x10.core.Rail r$102869 = ((x10.core.Rail)(((x10.array.Array<$T>)this$102852).raw));
                        
                        //#line 161 .. "x10/array/Array_4.x10"
                        final long t$102874 = ((x10.array.Array_4<$T>)this$102852).numElems_4;
                        
                        //#line 161 .. "x10/array/Array_4.x10"
                        final long t$102875 = ((x10.array.Array_4<$T>)this$102852).numElems_3;
                        
                        //#line 161 .. "x10/array/Array_4.x10"
                        final long t$102876 = ((x10.array.Array_4<$T>)this$102852).numElems_2;
                        
                        //#line 161 .. "x10/array/Array_4.x10"
                        final long t$102877 = ((i$102925) * (((long)(t$102876))));
                        
                        //#line 161 .. "x10/array/Array_4.x10"
                        final long t$102878 = ((i$102917) + (((long)(t$102877))));
                        
                        //#line 161 .. "x10/array/Array_4.x10"
                        final long t$102879 = ((t$102875) * (((long)(t$102878))));
                        
                        //#line 161 .. "x10/array/Array_4.x10"
                        final long t$102880 = ((i$102904) + (((long)(t$102879))));
                        
                        //#line 161 .. "x10/array/Array_4.x10"
                        final long t$102881 = ((t$102874) * (((long)(t$102880))));
                        
                        //#line 181 . "x10/array/Array_4.x10"
                        final long i$102882 = ((i$102891) + (((long)(t$102881))));
                        
                        //#line 38 .. "x10/lang/Unsafe.x10"
                        final $T t$102883 = (($T)(((x10.core.Rail<$T>)r$102869).$apply$G((long)(i$102882))));
                        
                        //#line 134 "x10/array/Array_4.x10"
                        sb.add(((java.lang.Object)(t$102883)));
                        
                        //#line 135 "x10/array/Array_4.x10"
                        final long t$102885 = ((printed) + (((long)(1L))));
                        
                        //#line 135 "x10/array/Array_4.x10"
                        final long t$102886 = printed = t$102885;
                        
                        //#line 135 "x10/array/Array_4.x10"
                        final boolean t$102887 = ((t$102886) > (((long)(limit))));
                        
                        //#line 135 "x10/array/Array_4.x10"
                        if (t$102887) {
                            
                            //#line 135 "x10/array/Array_4.x10"
                            break outer$102926;
                        }
                        
                        //#line 132 "x10/array/Array_4.x10"
                        final long t$102890 = ((i$102891) + (((long)(1L))));
                        
                        //#line 132 "x10/array/Array_4.x10"
                        i$102891 = t$102890;
                    }
                    
                    //#line 137 "x10/array/Array_4.x10"
                    final long t$102896 = this.numElems_3;
                    
                    //#line 137 "x10/array/Array_4.x10"
                    final long t$102897 = ((t$102896) - (((long)(1L))));
                    
                    //#line 137 "x10/array/Array_4.x10"
                    final boolean t$102898 = ((long) i$102904) == ((long) t$102897);
                    
                    //#line 137 "x10/array/Array_4.x10"
                    java.lang.String t$102899 =  null;
                    
                    //#line 137 "x10/array/Array_4.x10"
                    if (t$102898) {
                        
                        //#line 137 "x10/array/Array_4.x10"
                        t$102899 = ";; ";
                    } else {
                        
                        //#line 137 "x10/array/Array_4.x10"
                        t$102899 = "; ";
                    }
                    
                    //#line 137 "x10/array/Array_4.x10"
                    sb.add(((java.lang.String)(t$102899)));
                    
                    //#line 131 "x10/array/Array_4.x10"
                    final long t$102903 = ((i$102904) + (((long)(1L))));
                    
                    //#line 131 "x10/array/Array_4.x10"
                    i$102904 = t$102903;
                }
                
                //#line 139 "x10/array/Array_4.x10"
                final long t$102909 = this.numElems_2;
                
                //#line 139 "x10/array/Array_4.x10"
                final long t$102910 = ((t$102909) - (((long)(1L))));
                
                //#line 139 "x10/array/Array_4.x10"
                final boolean t$102911 = ((long) i$102917) == ((long) t$102910);
                
                //#line 139 "x10/array/Array_4.x10"
                java.lang.String t$102912 =  null;
                
                //#line 139 "x10/array/Array_4.x10"
                if (t$102911) {
                    
                    //#line 139 "x10/array/Array_4.x10"
                    t$102912 = ";; ";
                } else {
                    
                    //#line 139 "x10/array/Array_4.x10"
                    t$102912 = "; ";
                }
                
                //#line 139 "x10/array/Array_4.x10"
                sb.add(((java.lang.String)(t$102912)));
                
                //#line 130 "x10/array/Array_4.x10"
                final long t$102916 = ((i$102917) + (((long)(1L))));
                
                //#line 130 "x10/array/Array_4.x10"
                i$102917 = t$102916;
            }
            
            //#line 129 "x10/array/Array_4.x10"
            final long t$102924 = ((i$102925) + (((long)(1L))));
            
            //#line 129 "x10/array/Array_4.x10"
            i$102925 = t$102924;
        }
        
        //#line 142 "x10/array/Array_4.x10"
        final long t$102650 = this.size;
        
        //#line 142 "x10/array/Array_4.x10"
        final boolean t$102655 = ((limit) < (((long)(t$102650))));
        
        //#line 142 "x10/array/Array_4.x10"
        if (t$102655) {
            
            //#line 143 "x10/array/Array_4.x10"
            final long t$102651 = this.size;
            
            //#line 143 "x10/array/Array_4.x10"
            final long t$102652 = ((t$102651) - (((long)(limit))));
            
            //#line 143 "x10/array/Array_4.x10"
            final java.lang.String t$102653 = (("...(omitted ") + ((x10.core.Long.$box(t$102652))));
            
            //#line 143 "x10/array/Array_4.x10"
            final java.lang.String t$102654 = ((t$102653) + (" elements)"));
            
            //#line 143 "x10/array/Array_4.x10"
            sb.add(((java.lang.String)(t$102654)));
        }
        
        //#line 145 "x10/array/Array_4.x10"
        sb.add(((java.lang.String)("]")));
        
        //#line 146 "x10/array/Array_4.x10"
        final java.lang.String t$102656 = sb.toString();
        
        //#line 146 "x10/array/Array_4.x10"
        return t$102656;
    }
    
    
    //#line 152 "x10/array/Array_4.x10"
    /**
     * @return an IterationSpace containing all valid Points for indexing this Array.
     */
    public x10.array.DenseIterationSpace_4 indices() {
        
        //#line 153 "x10/array/Array_4.x10"
        final x10.array.DenseIterationSpace_4 alloc$101701 = ((x10.array.DenseIterationSpace_4)(new x10.array.DenseIterationSpace_4((java.lang.System[]) null)));
        
        //#line 153 "x10/array/Array_4.x10"
        final long t$102931 = this.numElems_1;
        
        //#line 153 "x10/array/Array_4.x10"
        final long t$102932 = ((t$102931) - (((long)(1L))));
        
        //#line 153 "x10/array/Array_4.x10"
        final long t$102933 = this.numElems_2;
        
        //#line 153 "x10/array/Array_4.x10"
        final long t$102934 = ((t$102933) - (((long)(1L))));
        
        //#line 153 "x10/array/Array_4.x10"
        final long t$102935 = this.numElems_3;
        
        //#line 153 "x10/array/Array_4.x10"
        final long t$102936 = ((t$102935) - (((long)(1L))));
        
        //#line 153 "x10/array/Array_4.x10"
        final long t$102937 = this.numElems_4;
        
        //#line 153 "x10/array/Array_4.x10"
        final long t$102938 = ((t$102937) - (((long)(1L))));
        
        //#line 153 "x10/array/Array_4.x10"
        alloc$101701.x10$array$DenseIterationSpace_4$$init$S(((long)(0L)), ((long)(0L)), ((long)(0L)), ((long)(0L)), t$102932, t$102934, t$102936, t$102938);
        
        //#line 153 "x10/array/Array_4.x10"
        return alloc$101701;
    }
    
    
    //#line 160 "x10/array/Array_4.x10"
    /**
     * Map a 4-D (i,j,k,l) index into a 1-D index into the backing Rail
     * returned by raw(). Uses row-major ordering.
     */
    public long offset$O(final long i, final long j, final long k, final long l) {
        
        //#line 161 "x10/array/Array_4.x10"
        final long t$102670 = this.numElems_4;
        
        //#line 161 "x10/array/Array_4.x10"
        final long t$102667 = this.numElems_3;
        
        //#line 161 "x10/array/Array_4.x10"
        final long t$102665 = this.numElems_2;
        
        //#line 161 "x10/array/Array_4.x10"
        final long t$102666 = ((i) * (((long)(t$102665))));
        
        //#line 161 "x10/array/Array_4.x10"
        final long t$102668 = ((j) + (((long)(t$102666))));
        
        //#line 161 "x10/array/Array_4.x10"
        final long t$102669 = ((t$102667) * (((long)(t$102668))));
        
        //#line 161 "x10/array/Array_4.x10"
        final long t$102671 = ((k) + (((long)(t$102669))));
        
        //#line 161 "x10/array/Array_4.x10"
        final long t$102672 = ((t$102670) * (((long)(t$102671))));
        
        //#line 161 "x10/array/Array_4.x10"
        final long t$102673 = ((l) + (((long)(t$102672))));
        
        //#line 161 "x10/array/Array_4.x10"
        return t$102673;
    }
    
    
    //#line 174 "x10/array/Array_4.x10"
    /**
     * Return the element of this array corresponding to the given triple of indices.
     * 
     * @param i the given index in the first dimension
     * @param j the given index in the second dimension
     * @param k the given index in the third dimension
     * @param l the given index in the fourth dimension
     * @return the element of this array corresponding to the given quad of indices.
     * @see #set(T, Long, Long, Long, Long)
     */
    public $T $apply$G(final long i, final long j, final long k, final long l) {
        
        //#line 175 "x10/array/Array_4.x10"
        boolean t$102675 = ((i) < (((long)(0L))));
        
        //#line 175 "x10/array/Array_4.x10"
        if (!(t$102675)) {
            
            //#line 175 "x10/array/Array_4.x10"
            final long t$102674 = this.numElems_1;
            
            //#line 175 "x10/array/Array_4.x10"
            t$102675 = ((i) >= (((long)(t$102674))));
        }
        
        //#line 175 "x10/array/Array_4.x10"
        boolean t$102676 = t$102675;
        
        //#line 175 "x10/array/Array_4.x10"
        if (!(t$102675)) {
            
            //#line 175 "x10/array/Array_4.x10"
            t$102676 = ((j) < (((long)(0L))));
        }
        
        //#line 175 "x10/array/Array_4.x10"
        boolean t$102678 = t$102676;
        
        //#line 175 "x10/array/Array_4.x10"
        if (!(t$102676)) {
            
            //#line 176 "x10/array/Array_4.x10"
            final long t$102677 = this.numElems_2;
            
            //#line 175 "x10/array/Array_4.x10"
            t$102678 = ((j) >= (((long)(t$102677))));
        }
        
        //#line 175 "x10/array/Array_4.x10"
        boolean t$102679 = t$102678;
        
        //#line 175 "x10/array/Array_4.x10"
        if (!(t$102678)) {
            
            //#line 175 "x10/array/Array_4.x10"
            t$102679 = ((k) < (((long)(0L))));
        }
        
        //#line 175 "x10/array/Array_4.x10"
        boolean t$102681 = t$102679;
        
        //#line 175 "x10/array/Array_4.x10"
        if (!(t$102679)) {
            
            //#line 177 "x10/array/Array_4.x10"
            final long t$102680 = this.numElems_3;
            
            //#line 175 "x10/array/Array_4.x10"
            t$102681 = ((k) >= (((long)(t$102680))));
        }
        
        //#line 175 "x10/array/Array_4.x10"
        boolean t$102682 = t$102681;
        
        //#line 175 "x10/array/Array_4.x10"
        if (!(t$102681)) {
            
            //#line 175 "x10/array/Array_4.x10"
            t$102682 = ((l) < (((long)(0L))));
        }
        
        //#line 175 "x10/array/Array_4.x10"
        boolean t$102684 = t$102682;
        
        //#line 175 "x10/array/Array_4.x10"
        if (!(t$102682)) {
            
            //#line 178 "x10/array/Array_4.x10"
            final long t$102683 = this.numElems_4;
            
            //#line 175 "x10/array/Array_4.x10"
            t$102684 = ((l) >= (((long)(t$102683))));
        }
        
        //#line 175 "x10/array/Array_4.x10"
        if (t$102684) {
            
            //#line 179 "x10/array/Array_4.x10"
            x10.array.Array.raiseBoundsError((long)(i), (long)(j), (long)(k), (long)(l));
        }
        
        //#line 181 "x10/array/Array_4.x10"
        final x10.core.Rail r$102471 = ((x10.core.Rail)(this.raw));
        
        //#line 181 "x10/array/Array_4.x10"
        final x10.array.Array_4 this$102469 = ((x10.array.Array_4)(this));
        
        //#line 161 . "x10/array/Array_4.x10"
        final long t$102691 = ((x10.array.Array_4<$T>)this$102469).numElems_4;
        
        //#line 161 . "x10/array/Array_4.x10"
        final long t$102688 = ((x10.array.Array_4<$T>)this$102469).numElems_3;
        
        //#line 161 . "x10/array/Array_4.x10"
        final long t$102686 = ((x10.array.Array_4<$T>)this$102469).numElems_2;
        
        //#line 161 . "x10/array/Array_4.x10"
        final long t$102687 = ((i) * (((long)(t$102686))));
        
        //#line 161 . "x10/array/Array_4.x10"
        final long t$102689 = ((j) + (((long)(t$102687))));
        
        //#line 161 . "x10/array/Array_4.x10"
        final long t$102690 = ((t$102688) * (((long)(t$102689))));
        
        //#line 161 . "x10/array/Array_4.x10"
        final long t$102692 = ((k) + (((long)(t$102690))));
        
        //#line 161 . "x10/array/Array_4.x10"
        final long t$102693 = ((t$102691) * (((long)(t$102692))));
        
        //#line 181 "x10/array/Array_4.x10"
        final long i$102472 = ((l) + (((long)(t$102693))));
        
        //#line 38 . "x10/lang/Unsafe.x10"
        final $T t$102694 = (($T)(((x10.core.Rail<$T>)r$102471).$apply$G((long)(i$102472))));
        
        //#line 181 "x10/array/Array_4.x10"
        return t$102694;
    }
    
    
    //#line 191 "x10/array/Array_4.x10"
    /**
     * Return the element of this array corresponding to the given Point.
     * 
     * @param p the given Point
     * @return the element of this array corresponding to the given Point.
     * @see #set(T, Point)
     */
    public $T $apply$G(final x10.lang.Point p) {
        
        //#line 191 "x10/array/Array_4.x10"
        final x10.array.Array_4 this$102478 = ((x10.array.Array_4)(this));
        
        //#line 191 "x10/array/Array_4.x10"
        final long i$102474 = p.$apply$O((long)(0L));
        
        //#line 191 "x10/array/Array_4.x10"
        final long j$102475 = p.$apply$O((long)(1L));
        
        //#line 191 "x10/array/Array_4.x10"
        final long k$102476 = p.$apply$O((long)(2L));
        
        //#line 191 "x10/array/Array_4.x10"
        final long l$102477 = p.$apply$O((long)(3L));
        
        //#line 175 . "x10/array/Array_4.x10"
        boolean t$102696 = ((i$102474) < (((long)(0L))));
        
        //#line 175 . "x10/array/Array_4.x10"
        if (!(t$102696)) {
            
            //#line 175 . "x10/array/Array_4.x10"
            final long t$102695 = ((x10.array.Array_4<$T>)this$102478).numElems_1;
            
            //#line 175 . "x10/array/Array_4.x10"
            t$102696 = ((i$102474) >= (((long)(t$102695))));
        }
        
        //#line 175 . "x10/array/Array_4.x10"
        boolean t$102697 = t$102696;
        
        //#line 175 . "x10/array/Array_4.x10"
        if (!(t$102696)) {
            
            //#line 175 . "x10/array/Array_4.x10"
            t$102697 = ((j$102475) < (((long)(0L))));
        }
        
        //#line 175 . "x10/array/Array_4.x10"
        boolean t$102699 = t$102697;
        
        //#line 175 . "x10/array/Array_4.x10"
        if (!(t$102697)) {
            
            //#line 176 . "x10/array/Array_4.x10"
            final long t$102698 = ((x10.array.Array_4<$T>)this$102478).numElems_2;
            
            //#line 175 . "x10/array/Array_4.x10"
            t$102699 = ((j$102475) >= (((long)(t$102698))));
        }
        
        //#line 175 . "x10/array/Array_4.x10"
        boolean t$102700 = t$102699;
        
        //#line 175 . "x10/array/Array_4.x10"
        if (!(t$102699)) {
            
            //#line 175 . "x10/array/Array_4.x10"
            t$102700 = ((k$102476) < (((long)(0L))));
        }
        
        //#line 175 . "x10/array/Array_4.x10"
        boolean t$102702 = t$102700;
        
        //#line 175 . "x10/array/Array_4.x10"
        if (!(t$102700)) {
            
            //#line 177 . "x10/array/Array_4.x10"
            final long t$102701 = ((x10.array.Array_4<$T>)this$102478).numElems_3;
            
            //#line 175 . "x10/array/Array_4.x10"
            t$102702 = ((k$102476) >= (((long)(t$102701))));
        }
        
        //#line 175 . "x10/array/Array_4.x10"
        boolean t$102703 = t$102702;
        
        //#line 175 . "x10/array/Array_4.x10"
        if (!(t$102702)) {
            
            //#line 175 . "x10/array/Array_4.x10"
            t$102703 = ((l$102477) < (((long)(0L))));
        }
        
        //#line 175 . "x10/array/Array_4.x10"
        boolean t$102705 = t$102703;
        
        //#line 175 . "x10/array/Array_4.x10"
        if (!(t$102703)) {
            
            //#line 178 . "x10/array/Array_4.x10"
            final long t$102704 = ((x10.array.Array_4<$T>)this$102478).numElems_4;
            
            //#line 175 . "x10/array/Array_4.x10"
            t$102705 = ((l$102477) >= (((long)(t$102704))));
        }
        
        //#line 175 . "x10/array/Array_4.x10"
        if (t$102705) {
            
            //#line 179 . "x10/array/Array_4.x10"
            x10.array.Array.raiseBoundsError((long)(i$102474), (long)(j$102475), (long)(k$102476), (long)(l$102477));
        }
        
        //#line 181 . "x10/array/Array_4.x10"
        final x10.core.Rail r$102485 = ((x10.core.Rail)(((x10.array.Array<$T>)this$102478).raw));
        
        //#line 161 .. "x10/array/Array_4.x10"
        final long t$102712 = ((x10.array.Array_4<$T>)this$102478).numElems_4;
        
        //#line 161 .. "x10/array/Array_4.x10"
        final long t$102709 = ((x10.array.Array_4<$T>)this$102478).numElems_3;
        
        //#line 161 .. "x10/array/Array_4.x10"
        final long t$102707 = ((x10.array.Array_4<$T>)this$102478).numElems_2;
        
        //#line 161 .. "x10/array/Array_4.x10"
        final long t$102708 = ((i$102474) * (((long)(t$102707))));
        
        //#line 161 .. "x10/array/Array_4.x10"
        final long t$102710 = ((j$102475) + (((long)(t$102708))));
        
        //#line 161 .. "x10/array/Array_4.x10"
        final long t$102711 = ((t$102709) * (((long)(t$102710))));
        
        //#line 161 .. "x10/array/Array_4.x10"
        final long t$102713 = ((k$102476) + (((long)(t$102711))));
        
        //#line 161 .. "x10/array/Array_4.x10"
        final long t$102714 = ((t$102712) * (((long)(t$102713))));
        
        //#line 181 . "x10/array/Array_4.x10"
        final long i$102486 = ((l$102477) + (((long)(t$102714))));
        
        //#line 38 .. "x10/lang/Unsafe.x10"
        final $T t$102715 = (($T)(((x10.core.Rail<$T>)r$102485).$apply$G((long)(i$102486))));
        
        //#line 191 "x10/array/Array_4.x10"
        return t$102715;
    }
    
    
    //#line 205 "x10/array/Array_4.x10"
    /**
     * Set the element of this array corresponding to the given triple of indices to the given value.
     * Return the new value of the element.
     * 
     * @param v the given value
     * @param i the given index in the first dimension
     * @param j the given index in the second dimension
     * @param k the given index in the third dimension
     * @param l the given index in the fourth dimension
     * @return the new value of the element of this array corresponding to the given quad of indices.
     * @see #operator(Long, Long, Long, Long)
     */
    public $T $set__4x10$array$Array_4$$T$G(final long i, final long j, final long k, final long l, final $T v) {
        
        //#line 206 "x10/array/Array_4.x10"
        boolean t$102717 = ((i) < (((long)(0L))));
        
        //#line 206 "x10/array/Array_4.x10"
        if (!(t$102717)) {
            
            //#line 206 "x10/array/Array_4.x10"
            final long t$102716 = this.numElems_1;
            
            //#line 206 "x10/array/Array_4.x10"
            t$102717 = ((i) >= (((long)(t$102716))));
        }
        
        //#line 206 "x10/array/Array_4.x10"
        boolean t$102718 = t$102717;
        
        //#line 206 "x10/array/Array_4.x10"
        if (!(t$102717)) {
            
            //#line 206 "x10/array/Array_4.x10"
            t$102718 = ((j) < (((long)(0L))));
        }
        
        //#line 206 "x10/array/Array_4.x10"
        boolean t$102720 = t$102718;
        
        //#line 206 "x10/array/Array_4.x10"
        if (!(t$102718)) {
            
            //#line 207 "x10/array/Array_4.x10"
            final long t$102719 = this.numElems_2;
            
            //#line 206 "x10/array/Array_4.x10"
            t$102720 = ((j) >= (((long)(t$102719))));
        }
        
        //#line 206 "x10/array/Array_4.x10"
        boolean t$102721 = t$102720;
        
        //#line 206 "x10/array/Array_4.x10"
        if (!(t$102720)) {
            
            //#line 206 "x10/array/Array_4.x10"
            t$102721 = ((k) < (((long)(0L))));
        }
        
        //#line 206 "x10/array/Array_4.x10"
        boolean t$102723 = t$102721;
        
        //#line 206 "x10/array/Array_4.x10"
        if (!(t$102721)) {
            
            //#line 208 "x10/array/Array_4.x10"
            final long t$102722 = this.numElems_3;
            
            //#line 206 "x10/array/Array_4.x10"
            t$102723 = ((k) >= (((long)(t$102722))));
        }
        
        //#line 206 "x10/array/Array_4.x10"
        boolean t$102724 = t$102723;
        
        //#line 206 "x10/array/Array_4.x10"
        if (!(t$102723)) {
            
            //#line 206 "x10/array/Array_4.x10"
            t$102724 = ((l) < (((long)(0L))));
        }
        
        //#line 206 "x10/array/Array_4.x10"
        boolean t$102726 = t$102724;
        
        //#line 206 "x10/array/Array_4.x10"
        if (!(t$102724)) {
            
            //#line 209 "x10/array/Array_4.x10"
            final long t$102725 = this.numElems_4;
            
            //#line 206 "x10/array/Array_4.x10"
            t$102726 = ((l) >= (((long)(t$102725))));
        }
        
        //#line 206 "x10/array/Array_4.x10"
        if (t$102726) {
            
            //#line 210 "x10/array/Array_4.x10"
            x10.array.Array.raiseBoundsError((long)(i), (long)(j), (long)(k), (long)(l));
        }
        
        //#line 212 "x10/array/Array_4.x10"
        final x10.core.Rail r$102494 = ((x10.core.Rail)(this.raw));
        
        //#line 212 "x10/array/Array_4.x10"
        final x10.array.Array_4 this$102492 = ((x10.array.Array_4)(this));
        
        //#line 161 . "x10/array/Array_4.x10"
        final long t$102733 = ((x10.array.Array_4<$T>)this$102492).numElems_4;
        
        //#line 161 . "x10/array/Array_4.x10"
        final long t$102730 = ((x10.array.Array_4<$T>)this$102492).numElems_3;
        
        //#line 161 . "x10/array/Array_4.x10"
        final long t$102728 = ((x10.array.Array_4<$T>)this$102492).numElems_2;
        
        //#line 161 . "x10/array/Array_4.x10"
        final long t$102729 = ((i) * (((long)(t$102728))));
        
        //#line 161 . "x10/array/Array_4.x10"
        final long t$102731 = ((j) + (((long)(t$102729))));
        
        //#line 161 . "x10/array/Array_4.x10"
        final long t$102732 = ((t$102730) * (((long)(t$102731))));
        
        //#line 161 . "x10/array/Array_4.x10"
        final long t$102734 = ((k) + (((long)(t$102732))));
        
        //#line 161 . "x10/array/Array_4.x10"
        final long t$102735 = ((t$102733) * (((long)(t$102734))));
        
        //#line 212 "x10/array/Array_4.x10"
        final long i$102495 = ((l) + (((long)(t$102735))));
        
        //#line 42 . "x10/lang/Unsafe.x10"
        ((x10.core.Rail<$T>)r$102494).$set__1x10$lang$Rail$$T$G((long)(i$102495), (($T)(v)));
        
        //#line 212 "x10/array/Array_4.x10"
        return (($T)
                 v);
    }
    
    
    //#line 224 "x10/array/Array_4.x10"
    /**
     * Set the element of this array corresponding to the given Point to the given value.
     * Return the new value of the element.
     * 
     * @param v the given value
     * @param p the given Point
     * @return the new value of the element of this array corresponding to the given Point.
     * @see #operator(Point)
     */
    public $T $set__1x10$array$Array_4$$T$G(final x10.lang.Point p, final $T v) {
        
        //#line 224 "x10/array/Array_4.x10"
        final x10.array.Array_4 this$102503 = ((x10.array.Array_4)(this));
        
        //#line 224 "x10/array/Array_4.x10"
        final long i$102498 = p.$apply$O((long)(0L));
        
        //#line 224 "x10/array/Array_4.x10"
        final long j$102499 = p.$apply$O((long)(1L));
        
        //#line 224 "x10/array/Array_4.x10"
        final long k$102500 = p.$apply$O((long)(2L));
        
        //#line 224 "x10/array/Array_4.x10"
        final long l$102501 = p.$apply$O((long)(3L));
        
        //#line 206 . "x10/array/Array_4.x10"
        boolean t$102737 = ((i$102498) < (((long)(0L))));
        
        //#line 206 . "x10/array/Array_4.x10"
        if (!(t$102737)) {
            
            //#line 206 . "x10/array/Array_4.x10"
            final long t$102736 = ((x10.array.Array_4<$T>)this$102503).numElems_1;
            
            //#line 206 . "x10/array/Array_4.x10"
            t$102737 = ((i$102498) >= (((long)(t$102736))));
        }
        
        //#line 206 . "x10/array/Array_4.x10"
        boolean t$102738 = t$102737;
        
        //#line 206 . "x10/array/Array_4.x10"
        if (!(t$102737)) {
            
            //#line 206 . "x10/array/Array_4.x10"
            t$102738 = ((j$102499) < (((long)(0L))));
        }
        
        //#line 206 . "x10/array/Array_4.x10"
        boolean t$102740 = t$102738;
        
        //#line 206 . "x10/array/Array_4.x10"
        if (!(t$102738)) {
            
            //#line 207 . "x10/array/Array_4.x10"
            final long t$102739 = ((x10.array.Array_4<$T>)this$102503).numElems_2;
            
            //#line 206 . "x10/array/Array_4.x10"
            t$102740 = ((j$102499) >= (((long)(t$102739))));
        }
        
        //#line 206 . "x10/array/Array_4.x10"
        boolean t$102741 = t$102740;
        
        //#line 206 . "x10/array/Array_4.x10"
        if (!(t$102740)) {
            
            //#line 206 . "x10/array/Array_4.x10"
            t$102741 = ((k$102500) < (((long)(0L))));
        }
        
        //#line 206 . "x10/array/Array_4.x10"
        boolean t$102743 = t$102741;
        
        //#line 206 . "x10/array/Array_4.x10"
        if (!(t$102741)) {
            
            //#line 208 . "x10/array/Array_4.x10"
            final long t$102742 = ((x10.array.Array_4<$T>)this$102503).numElems_3;
            
            //#line 206 . "x10/array/Array_4.x10"
            t$102743 = ((k$102500) >= (((long)(t$102742))));
        }
        
        //#line 206 . "x10/array/Array_4.x10"
        boolean t$102744 = t$102743;
        
        //#line 206 . "x10/array/Array_4.x10"
        if (!(t$102743)) {
            
            //#line 206 . "x10/array/Array_4.x10"
            t$102744 = ((l$102501) < (((long)(0L))));
        }
        
        //#line 206 . "x10/array/Array_4.x10"
        boolean t$102746 = t$102744;
        
        //#line 206 . "x10/array/Array_4.x10"
        if (!(t$102744)) {
            
            //#line 209 . "x10/array/Array_4.x10"
            final long t$102745 = ((x10.array.Array_4<$T>)this$102503).numElems_4;
            
            //#line 206 . "x10/array/Array_4.x10"
            t$102746 = ((l$102501) >= (((long)(t$102745))));
        }
        
        //#line 206 . "x10/array/Array_4.x10"
        if (t$102746) {
            
            //#line 210 . "x10/array/Array_4.x10"
            x10.array.Array.raiseBoundsError((long)(i$102498), (long)(j$102499), (long)(k$102500), (long)(l$102501));
        }
        
        //#line 212 . "x10/array/Array_4.x10"
        final x10.core.Rail r$102510 = ((x10.core.Rail)(((x10.array.Array<$T>)this$102503).raw));
        
        //#line 161 .. "x10/array/Array_4.x10"
        final long t$102753 = ((x10.array.Array_4<$T>)this$102503).numElems_4;
        
        //#line 161 .. "x10/array/Array_4.x10"
        final long t$102750 = ((x10.array.Array_4<$T>)this$102503).numElems_3;
        
        //#line 161 .. "x10/array/Array_4.x10"
        final long t$102748 = ((x10.array.Array_4<$T>)this$102503).numElems_2;
        
        //#line 161 .. "x10/array/Array_4.x10"
        final long t$102749 = ((i$102498) * (((long)(t$102748))));
        
        //#line 161 .. "x10/array/Array_4.x10"
        final long t$102751 = ((j$102499) + (((long)(t$102749))));
        
        //#line 161 .. "x10/array/Array_4.x10"
        final long t$102752 = ((t$102750) * (((long)(t$102751))));
        
        //#line 161 .. "x10/array/Array_4.x10"
        final long t$102754 = ((k$102500) + (((long)(t$102752))));
        
        //#line 161 .. "x10/array/Array_4.x10"
        final long t$102755 = ((t$102753) * (((long)(t$102754))));
        
        //#line 212 . "x10/array/Array_4.x10"
        final long i$102511 = ((l$102501) + (((long)(t$102755))));
        
        //#line 42 .. "x10/lang/Unsafe.x10"
        ((x10.core.Rail<$T>)r$102510).$set__1x10$lang$Rail$$T$G((long)(i$102511), (($T)(v)));
        
        //#line 224 "x10/array/Array_4.x10"
        return (($T)
                 v);
    }
    
    
    //#line 227 "x10/array/Array_4.x10"
    private static long validateSize$O(final long m, final long n, final long p, final long q) {
        
        //#line 228 "x10/array/Array_4.x10"
        boolean t$102756 = ((m) < (((long)(0L))));
        
        //#line 228 "x10/array/Array_4.x10"
        if (!(t$102756)) {
            
            //#line 228 "x10/array/Array_4.x10"
            t$102756 = ((n) < (((long)(0L))));
        }
        
        //#line 228 "x10/array/Array_4.x10"
        boolean t$102757 = t$102756;
        
        //#line 228 "x10/array/Array_4.x10"
        if (!(t$102756)) {
            
            //#line 228 "x10/array/Array_4.x10"
            t$102757 = ((p) < (((long)(0L))));
        }
        
        //#line 228 "x10/array/Array_4.x10"
        boolean t$102758 = t$102757;
        
        //#line 228 "x10/array/Array_4.x10"
        if (!(t$102757)) {
            
            //#line 228 "x10/array/Array_4.x10"
            t$102758 = ((q) < (((long)(0L))));
        }
        
        //#line 228 "x10/array/Array_4.x10"
        if (t$102758) {
            
            //#line 228 "x10/array/Array_4.x10"
            x10.array.Array.raiseNegativeArraySizeException();
        }
        
        //#line 229 "x10/array/Array_4.x10"
        final long t$102760 = ((m) * (((long)(n))));
        
        //#line 229 "x10/array/Array_4.x10"
        final long t$102761 = ((t$102760) * (((long)(p))));
        
        //#line 229 "x10/array/Array_4.x10"
        final long t$102762 = ((t$102761) * (((long)(q))));
        
        //#line 229 "x10/array/Array_4.x10"
        return t$102762;
    }
    
    public static long validateSize$P$O(final long m, final long n, final long p, final long q) {
        return x10.array.Array_4.validateSize$O((long)(m), (long)(n), (long)(p), (long)(q));
    }
    
    
    //#line 21 "x10/array/Array_4.x10"
    final public x10.array.Array_4 x10$array$Array_4$$this$x10$array$Array_4() {
        
        //#line 21 "x10/array/Array_4.x10"
        return x10.array.Array_4.this;
    }
    
    
    //#line 21 "x10/array/Array_4.x10"
    final public void __fieldInitializers_x10_array_Array_4() {
        
    }
}

