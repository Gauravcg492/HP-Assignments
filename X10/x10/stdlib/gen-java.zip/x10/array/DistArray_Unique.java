package x10.array;


/**
 * Implementation of DistArray that has exactly one element at each 
 * place in its PlaceGroup such that element i is stored at the
 * ith place as computed by the {@link x10.lang.PlaceGroup#indexOf(Place)}.
 */
@x10.runtime.impl.java.X10Generated
final public class DistArray_Unique<$T> extends x10.array.DistArray<$T> implements x10.core.fun.Fun_0_1, x10.serialization.X10JavaSerializable
{
    public static final x10.rtt.RuntimeType<DistArray_Unique> $RTT = 
        x10.rtt.NamedType.<DistArray_Unique> make("x10.array.DistArray_Unique",
                                                  DistArray_Unique.class,
                                                  1,
                                                  new x10.rtt.Type[] {
                                                      x10.rtt.ParameterizedType.make(x10.core.fun.Fun_0_1.$RTT, x10.rtt.Types.LONG, x10.rtt.UnresolvedType.PARAM(0)),
                                                      x10.rtt.ParameterizedType.make(x10.array.DistArray.$RTT, x10.rtt.UnresolvedType.PARAM(0))
                                                  });
    
    public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
    
    public x10.rtt.Type<?> $getParam(int i) { if (i == 0) return $T; return null; }
    
    private Object writeReplace() throws java.io.ObjectStreamException {
        return new x10.serialization.SerializationProxy(this);
    }
    
    public static <$T> x10.serialization.X10JavaSerializable $_deserialize_body(x10.array.DistArray_Unique<$T> $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
        x10.array.DistArray.$_deserialize_body($_obj, $deserializer);
        $_obj.$T = (x10.rtt.Type) $deserializer.readObject();
        return $_obj;
    }
    
    public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
        x10.array.DistArray_Unique $_obj = new x10.array.DistArray_Unique((java.lang.System[]) null, (x10.rtt.Type) null);
        $deserializer.record_reference($_obj);
        return $_deserialize_body($_obj, $deserializer);
    }
    
    public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
        super.$_serialize($serializer);
        $serializer.write(this.$T);
        
    }
    
    // constructor just for allocation
    public DistArray_Unique(final java.lang.System[] $dummy, final x10.rtt.Type $T) {
        super($dummy, $T);
        x10.array.DistArray_Unique.$initParams(this, $T);
        
    }
    
    // dispatcher for method abstract public (Z1)=>U.operator()(a1:Z1){}:U
    public java.lang.Object $apply(final java.lang.Object a1, final x10.rtt.Type t1) {
        if (t1.equals(x10.rtt.Types.LONG)) { return $apply$G(x10.core.Long.$unbox(a1)); }
        if (t1.equals(x10.lang.Point.$RTT)) { return $apply$G((x10.lang.Point)a1); }
        throw new java.lang.Error("dispatch mechanism not completely implemented for contra-variant types.");
    }
    
    // bridge for method abstract public x10.array.DistArray[T].operator()=(p:x10.lang.Point{self.rank==this(:x10.array.DistArray).rank()}, v:T){}:T{self==v}
    public $T $set__1x10$array$DistArray$$T$G(x10.lang.Point a1, $T a2) {
        return $set__1x10$array$DistArray_Unique$$T$G(a1, a2);
    }
    
    private x10.rtt.Type $T;
    
    // initializer of type parameters
    public static void $initParams(final DistArray_Unique $this, final x10.rtt.Type $T) {
        $this.$T = $T;
        
    }
    // synthetic type for parameter mangling
    public static final class __0$1x10$array$DistArray_Unique$$T$2 {}
    // synthetic type for parameter mangling
    public static final class __1$1x10$array$DistArray_Unique$$T$2 {}
    

    
    
    //#line 24 "x10/array/DistArray_Unique.x10"
    final public long rank$O() {
        
        //#line 24 "x10/array/DistArray_Unique.x10"
        return 1L;
    }
    
    
    //#line 29 "x10/array/DistArray_Unique.x10"
    /**
     * Construct a zero-initialized DistArray_Unique object over Place.places()
     */
    // creation method for java code (1-phase java constructor)
    public DistArray_Unique(final x10.rtt.Type $T) {
        this((java.lang.System[]) null, $T);
        x10$array$DistArray_Unique$$init$S();
    }
    
    // constructor for non-virtual call
    final public x10.array.DistArray_Unique<$T> x10$array$DistArray_Unique$$init$S() {
         {
            
            //#line 30 "x10/array/DistArray_Unique.x10"
            final x10.lang.PlaceGroup t$110160 = ((x10.lang.PlaceGroup)(x10.lang.Place.places()));
            
            //#line 30 "x10/array/DistArray_Unique.x10"
            /*this.*/x10$array$DistArray_Unique$$init$S(t$110160);
        }
        return this;
    }
    
    
    
    //#line 36 "x10/array/DistArray_Unique.x10"
    /**
     * Construct a zero-initialized DistArray_Unique object over the given PlaceGroup
     */
    // creation method for java code (1-phase java constructor)
    public DistArray_Unique(final x10.rtt.Type $T, final x10.lang.PlaceGroup pg) {
        this((java.lang.System[]) null, $T);
        x10$array$DistArray_Unique$$init$S(pg);
    }
    
    // constructor for non-virtual call
    final public x10.array.DistArray_Unique<$T> x10$array$DistArray_Unique$$init$S(final x10.lang.PlaceGroup pg) {
         {
            
            //#line 37 "x10/array/DistArray_Unique.x10"
            final x10.core.fun.Fun_0_0 t$110215 = ((x10.core.fun.Fun_0_0)(new x10.array.DistArray_Unique.$Closure$20<$T>($T, pg)));
            
            //#line 35 . "x10/lang/PlaceGroup.x10"
            final long t$110220 = pg.numPlaces$O();
            
            //#line 37 "x10/array/DistArray_Unique.x10"
            /*super.*/x10$array$DistArray$$init$S(((x10.lang.PlaceGroup)(pg)), ((x10.core.fun.Fun_0_0)(t$110215)), t$110220, (x10.array.DistArray.__1$1x10$array$LocalState$1x10$array$DistArray$$T$2$2) null);
            
            //#line 36 "x10/array/DistArray_Unique.x10"
            
        }
        return this;
    }
    
    
    
    //#line 45 "x10/array/DistArray_Unique.x10"
    /**
     * Construct a DistArray_Unique object over Place.places() using the
     * given initialization function.
     */
    // creation method for java code (1-phase java constructor)
    public DistArray_Unique(final x10.rtt.Type $T, final x10.core.fun.Fun_0_0<$T> init, __0$1x10$array$DistArray_Unique$$T$2 $dummy) {
        this((java.lang.System[]) null, $T);
        x10$array$DistArray_Unique$$init$S(init, (x10.array.DistArray_Unique.__0$1x10$array$DistArray_Unique$$T$2) null);
    }
    
    // constructor for non-virtual call
    final public x10.array.DistArray_Unique<$T> x10$array$DistArray_Unique$$init$S(final x10.core.fun.Fun_0_0<$T> init, __0$1x10$array$DistArray_Unique$$T$2 $dummy) {
         {
            
            //#line 46 "x10/array/DistArray_Unique.x10"
            final x10.lang.PlaceGroup t$110163 = ((x10.lang.PlaceGroup)(x10.lang.Place.places()));
            
            //#line 46 "x10/array/DistArray_Unique.x10"
            /*this.*/x10$array$DistArray_Unique$$init$S(t$110163, ((x10.core.fun.Fun_0_0)(init)), (x10.array.DistArray_Unique.__1$1x10$array$DistArray_Unique$$T$2) null);
        }
        return this;
    }
    
    
    
    //#line 53 "x10/array/DistArray_Unique.x10"
    /**
     * Construct a DistArray_Unique object using the given PlaceGroup and
     * initialization function.
     */
    // creation method for java code (1-phase java constructor)
    public DistArray_Unique(final x10.rtt.Type $T, final x10.lang.PlaceGroup pg, final x10.core.fun.Fun_0_0<$T> init, __1$1x10$array$DistArray_Unique$$T$2 $dummy) {
        this((java.lang.System[]) null, $T);
        x10$array$DistArray_Unique$$init$S(pg, init, (x10.array.DistArray_Unique.__1$1x10$array$DistArray_Unique$$T$2) null);
    }
    
    // constructor for non-virtual call
    final public x10.array.DistArray_Unique<$T> x10$array$DistArray_Unique$$init$S(final x10.lang.PlaceGroup pg, final x10.core.fun.Fun_0_0<$T> init, __1$1x10$array$DistArray_Unique$$T$2 $dummy) {
         {
            
            //#line 54 "x10/array/DistArray_Unique.x10"
            final x10.core.fun.Fun_0_0 t$110222 = ((x10.core.fun.Fun_0_0)(new x10.array.DistArray_Unique.$Closure$21<$T>($T, init, pg, (x10.array.DistArray_Unique.$Closure$21.__0$1x10$array$DistArray_Unique$$Closure$21$$T$2) null)));
            
            //#line 35 . "x10/lang/PlaceGroup.x10"
            final long t$110228 = pg.numPlaces$O();
            
            //#line 54 "x10/array/DistArray_Unique.x10"
            /*super.*/x10$array$DistArray$$init$S(((x10.lang.PlaceGroup)(pg)), ((x10.core.fun.Fun_0_0)(t$110222)), t$110228, (x10.array.DistArray.__1$1x10$array$LocalState$1x10$array$DistArray$$T$2$2) null);
            
            //#line 53 "x10/array/DistArray_Unique.x10"
            
        }
        return this;
    }
    
    
    
    //#line 62 "x10/array/DistArray_Unique.x10"
    /**
     * Get an IterationSpace that represents all Points contained in
     * the global iteration space (valid indices) of the DistArray.
     * @return an IterationSpace for the DistArray
     */
    public x10.array.DenseIterationSpace_1 globalIndices() {
        
        //#line 63 "x10/array/DistArray_Unique.x10"
        final x10.array.DenseIterationSpace_1 alloc$110109 = ((x10.array.DenseIterationSpace_1)(new x10.array.DenseIterationSpace_1((java.lang.System[]) null)));
        
        //#line 63 "x10/array/DistArray_Unique.x10"
        final x10.lang.PlaceGroup this$110230 = ((x10.lang.PlaceGroup)(this.placeGroup));
        
        //#line 35 . "x10/lang/PlaceGroup.x10"
        final long t$110231 = this$110230.numPlaces$O();
        
        //#line 63 "x10/array/DistArray_Unique.x10"
        final long t$110232 = ((t$110231) - (((long)(1L))));
        
        //#line 63 "x10/array/DistArray_Unique.x10"
        alloc$110109.x10$array$DenseIterationSpace_1$$init$S(((long)(0L)), t$110232);
        
        //#line 63 "x10/array/DistArray_Unique.x10"
        return alloc$110109;
    }
    
    
    //#line 71 "x10/array/DistArray_Unique.x10"
    /**
     * Get an IterationSpace that represents all Points contained in
     * the local iteration space (valid indices) of the DistArray at the current Place.
     * @return an IterationSpace for the Array
     */
    public x10.array.DenseIterationSpace_1 localIndices() {
        
        //#line 72 "x10/array/DistArray_Unique.x10"
        final x10.lang.PlaceGroup t$110169 = ((x10.lang.PlaceGroup)(this.placeGroup));
        
        //#line 72 "x10/array/DistArray_Unique.x10"
        final long idx = t$110169.indexOf$O(((x10.lang.Place)(x10.x10rt.X10RT.here())));
        
        //#line 73 "x10/array/DistArray_Unique.x10"
        final x10.array.DenseIterationSpace_1 alloc$110110 = ((x10.array.DenseIterationSpace_1)(new x10.array.DenseIterationSpace_1((java.lang.System[]) null)));
        
        //#line 73 "x10/array/DistArray_Unique.x10"
        alloc$110110.x10$array$DenseIterationSpace_1$$init$S(((long)(idx)), ((long)(idx)));
        
        //#line 73 "x10/array/DistArray_Unique.x10"
        return alloc$110110;
    }
    
    
    //#line 85 "x10/array/DistArray_Unique.x10"
    /**
     * Return the Place which contains the data for the argument
     * index or Place.INVALID_PLACE if the Point is not in the globalIndices
     * of this DistArray
     *
     * @param i the index to lookup
     * @return the Place where i is a valid index in the DistArray; 
     *          will return Place.INVALID_PLACE if i is not contained in globalIndices
     */
    public x10.lang.Place place(final long i) {
        
        //#line 85 "x10/array/DistArray_Unique.x10"
        boolean t$110171 = ((i) >= (((long)(0L))));
        
        //#line 85 "x10/array/DistArray_Unique.x10"
        if (t$110171) {
            
            //#line 85 "x10/array/DistArray_Unique.x10"
            final x10.lang.PlaceGroup this$110131 = ((x10.lang.PlaceGroup)(this.placeGroup));
            
            //#line 35 . "x10/lang/PlaceGroup.x10"
            final long t$110170 = this$110131.numPlaces$O();
            
            //#line 85 "x10/array/DistArray_Unique.x10"
            t$110171 = ((i) < (((long)(t$110170))));
        }
        
        //#line 85 "x10/array/DistArray_Unique.x10"
        x10.lang.Place t$110174 =  null;
        
        //#line 85 "x10/array/DistArray_Unique.x10"
        if (t$110171) {
            
            //#line 85 "x10/array/DistArray_Unique.x10"
            final x10.lang.PlaceGroup t$110172 = ((x10.lang.PlaceGroup)(this.placeGroup));
            
            //#line 85 "x10/array/DistArray_Unique.x10"
            t$110174 = t$110172.$apply((long)(i));
        } else {
            
            //#line 85 "x10/array/DistArray_Unique.x10"
            t$110174 = x10.lang.Place.get$INVALID_PLACE();
        }
        
        //#line 85 "x10/array/DistArray_Unique.x10"
        return t$110174;
    }
    
    
    //#line 97 "x10/array/DistArray_Unique.x10"
    /**
     * Return the Place which contains the data for the argument
     * Point or Place.INVALID_PLACE if the Point is not in the globalIndices
     * of this DistArray
     *
     * @param p the Point to lookup
     * @return the Place where p is a valid index in the DistArray; 
     *          will return Place.INVALID_PLACE if p is not contained in globalIndices
     */
    public x10.lang.Place place(final x10.lang.Point p) {
        
        //#line 97 "x10/array/DistArray_Unique.x10"
        final long t$110176 = p.$apply$O((long)(0L));
        
        //#line 97 "x10/array/DistArray_Unique.x10"
        final x10.lang.Place t$110177 = this.place((long)(t$110176));
        
        //#line 97 "x10/array/DistArray_Unique.x10"
        return t$110177;
    }
    
    
    //#line 107 "x10/array/DistArray_Unique.x10"
    /**
     * Return the element of this array corresponding to the given index.
     * 
     * @param i the given index in the first dimension
     * @return the element of this array corresponding to the given index.
     * @see #set(T, Long)
     */
    public $T $apply$G(final long i) {
        
        //#line 108 "x10/array/DistArray_Unique.x10"
        final x10.array.DistArray_Unique this$110240 = ((x10.array.DistArray_Unique)(this));
        
        //#line 159 . "x10/array/DistArray_Unique.x10"
        final x10.lang.PlaceGroup t$110233 = ((x10.lang.PlaceGroup)(((x10.array.DistArray<$T>)this$110240).placeGroup));
        
        //#line 159 . "x10/array/DistArray_Unique.x10"
        final long t$110234 = t$110233.indexOf$O(((x10.lang.Place)(x10.x10rt.X10RT.here())));
        
        //#line 159 . "x10/array/DistArray_Unique.x10"
        final boolean t$110235 = ((long) t$110234) != ((long) i);
        
        //#line 159 . "x10/array/DistArray_Unique.x10"
        if (t$110235) {
            
            //#line 160 . "x10/array/DistArray_Unique.x10"
            boolean t$110236 = ((i) < (((long)(0L))));
            
            //#line 160 . "x10/array/DistArray_Unique.x10"
            if (!(t$110236)) {
                
                //#line 160 . "x10/array/DistArray_Unique.x10"
                final x10.lang.PlaceGroup this$110237 = ((x10.lang.PlaceGroup)(((x10.array.DistArray<$T>)this$110240).placeGroup));
                
                //#line 35 .. "x10/lang/PlaceGroup.x10"
                final long t$110238 = this$110237.numPlaces$O();
                
                //#line 160 . "x10/array/DistArray_Unique.x10"
                t$110236 = ((i) >= (((long)(t$110238))));
            }
            
            //#line 160 . "x10/array/DistArray_Unique.x10"
            if (t$110236) {
                
                //#line 160 . "x10/array/DistArray_Unique.x10"
                x10.array.DistArray.raiseBoundsError((long)(i));
            }
            
            //#line 161 . "x10/array/DistArray_Unique.x10"
            x10.array.DistArray.raisePlaceError((long)(i));
        }
        
        //#line 109 "x10/array/DistArray_Unique.x10"
        final x10.core.Rail t$110184 = ((x10.core.Rail)(this.raw));
        
        //#line 109 "x10/array/DistArray_Unique.x10"
        final $T t$110185 = (($T)(((x10.core.Rail<$T>)t$110184).$apply$G((long)(0L))));
        
        //#line 109 "x10/array/DistArray_Unique.x10"
        return t$110185;
    }
    
    
    //#line 119 "x10/array/DistArray_Unique.x10"
    /**
     * Return the element of this array corresponding to the given Point.
     * 
     * @param p the given Point
     * @return the element of this array corresponding to the given Point.
     * @see #set(T, Point)
     */
    public $T $apply$G(final x10.lang.Point p) {
        
        //#line 119 "x10/array/DistArray_Unique.x10"
        final x10.array.DistArray_Unique this$110139 = ((x10.array.DistArray_Unique)(this));
        
        //#line 119 "x10/array/DistArray_Unique.x10"
        final long i$110138 = p.$apply$O((long)(0L));
        
        //#line 159 .. "x10/array/DistArray_Unique.x10"
        final x10.lang.PlaceGroup t$110242 = ((x10.lang.PlaceGroup)(((x10.array.DistArray<$T>)this$110139).placeGroup));
        
        //#line 159 .. "x10/array/DistArray_Unique.x10"
        final long t$110243 = t$110242.indexOf$O(((x10.lang.Place)(x10.x10rt.X10RT.here())));
        
        //#line 159 .. "x10/array/DistArray_Unique.x10"
        final boolean t$110244 = ((long) t$110243) != ((long) i$110138);
        
        //#line 159 .. "x10/array/DistArray_Unique.x10"
        if (t$110244) {
            
            //#line 160 .. "x10/array/DistArray_Unique.x10"
            boolean t$110245 = ((i$110138) < (((long)(0L))));
            
            //#line 160 .. "x10/array/DistArray_Unique.x10"
            if (!(t$110245)) {
                
                //#line 160 .. "x10/array/DistArray_Unique.x10"
                final x10.lang.PlaceGroup this$110246 = ((x10.lang.PlaceGroup)(((x10.array.DistArray<$T>)this$110139).placeGroup));
                
                //#line 35 ... "x10/lang/PlaceGroup.x10"
                final long t$110247 = this$110246.numPlaces$O();
                
                //#line 160 .. "x10/array/DistArray_Unique.x10"
                t$110245 = ((i$110138) >= (((long)(t$110247))));
            }
            
            //#line 160 .. "x10/array/DistArray_Unique.x10"
            if (t$110245) {
                
                //#line 160 .. "x10/array/DistArray_Unique.x10"
                x10.array.DistArray.raiseBoundsError((long)(i$110138));
            }
            
            //#line 161 .. "x10/array/DistArray_Unique.x10"
            x10.array.DistArray.raisePlaceError((long)(i$110138));
        }
        
        //#line 109 . "x10/array/DistArray_Unique.x10"
        final x10.core.Rail t$110192 = ((x10.core.Rail)(((x10.array.DistArray<$T>)this$110139).raw));
        
        //#line 109 . "x10/array/DistArray_Unique.x10"
        final $T t$110193 = (($T)(((x10.core.Rail<$T>)t$110192).$apply$G((long)(0L))));
        
        //#line 119 "x10/array/DistArray_Unique.x10"
        return t$110193;
    }
    
    
    //#line 131 "x10/array/DistArray_Unique.x10"
    /**
     * Set the element of this array corresponding to the given index to the given value.
     * Return the new value of the element.
     * 
     * @param v the given value
     * @param i the given index in the first dimension
     * @return the new value of the element of this array corresponding to the given index.
     * @see #operator(Long)
     */
    public $T $set__1x10$array$DistArray_Unique$$T$G(final long i, final $T v) {
        
        //#line 132 "x10/array/DistArray_Unique.x10"
        final x10.array.DistArray_Unique this$110257 = ((x10.array.DistArray_Unique)(this));
        
        //#line 159 . "x10/array/DistArray_Unique.x10"
        final x10.lang.PlaceGroup t$110250 = ((x10.lang.PlaceGroup)(((x10.array.DistArray<$T>)this$110257).placeGroup));
        
        //#line 159 . "x10/array/DistArray_Unique.x10"
        final long t$110251 = t$110250.indexOf$O(((x10.lang.Place)(x10.x10rt.X10RT.here())));
        
        //#line 159 . "x10/array/DistArray_Unique.x10"
        final boolean t$110252 = ((long) t$110251) != ((long) i);
        
        //#line 159 . "x10/array/DistArray_Unique.x10"
        if (t$110252) {
            
            //#line 160 . "x10/array/DistArray_Unique.x10"
            boolean t$110253 = ((i) < (((long)(0L))));
            
            //#line 160 . "x10/array/DistArray_Unique.x10"
            if (!(t$110253)) {
                
                //#line 160 . "x10/array/DistArray_Unique.x10"
                final x10.lang.PlaceGroup this$110254 = ((x10.lang.PlaceGroup)(((x10.array.DistArray<$T>)this$110257).placeGroup));
                
                //#line 35 .. "x10/lang/PlaceGroup.x10"
                final long t$110255 = this$110254.numPlaces$O();
                
                //#line 160 . "x10/array/DistArray_Unique.x10"
                t$110253 = ((i) >= (((long)(t$110255))));
            }
            
            //#line 160 . "x10/array/DistArray_Unique.x10"
            if (t$110253) {
                
                //#line 160 . "x10/array/DistArray_Unique.x10"
                x10.array.DistArray.raiseBoundsError((long)(i));
            }
            
            //#line 161 . "x10/array/DistArray_Unique.x10"
            x10.array.DistArray.raisePlaceError((long)(i));
        }
        
        //#line 133 "x10/array/DistArray_Unique.x10"
        final x10.core.Rail t$110200 = ((x10.core.Rail)(this.raw));
        
        //#line 133 "x10/array/DistArray_Unique.x10"
        ((x10.core.Rail<$T>)t$110200).$set__1x10$lang$Rail$$T$G((long)(0L), (($T)(v)));
        
        //#line 134 "x10/array/DistArray_Unique.x10"
        return v;
    }
    
    
    //#line 146 "x10/array/DistArray_Unique.x10"
    /**
     * Set the element of this array corresponding to the given Point to the given value.
     * Return the new value of the element.
     * 
     * @param v the given value
     * @param p the given Point
     * @return the new value of the element of this array corresponding to the given Point.
     * @see #operator(Point)
     */
    public $T $set__1x10$array$DistArray_Unique$$T$G(final x10.lang.Point p, final $T v) {
        
        //#line 146 "x10/array/DistArray_Unique.x10"
        final x10.array.DistArray_Unique this$110152 = ((x10.array.DistArray_Unique)(this));
        
        //#line 146 "x10/array/DistArray_Unique.x10"
        final long i$110150 = p.$apply$O((long)(0L));
        
        //#line 159 .. "x10/array/DistArray_Unique.x10"
        final x10.lang.PlaceGroup t$110259 = ((x10.lang.PlaceGroup)(((x10.array.DistArray<$T>)this$110152).placeGroup));
        
        //#line 159 .. "x10/array/DistArray_Unique.x10"
        final long t$110260 = t$110259.indexOf$O(((x10.lang.Place)(x10.x10rt.X10RT.here())));
        
        //#line 159 .. "x10/array/DistArray_Unique.x10"
        final boolean t$110261 = ((long) t$110260) != ((long) i$110150);
        
        //#line 159 .. "x10/array/DistArray_Unique.x10"
        if (t$110261) {
            
            //#line 160 .. "x10/array/DistArray_Unique.x10"
            boolean t$110262 = ((i$110150) < (((long)(0L))));
            
            //#line 160 .. "x10/array/DistArray_Unique.x10"
            if (!(t$110262)) {
                
                //#line 160 .. "x10/array/DistArray_Unique.x10"
                final x10.lang.PlaceGroup this$110263 = ((x10.lang.PlaceGroup)(((x10.array.DistArray<$T>)this$110152).placeGroup));
                
                //#line 35 ... "x10/lang/PlaceGroup.x10"
                final long t$110264 = this$110263.numPlaces$O();
                
                //#line 160 .. "x10/array/DistArray_Unique.x10"
                t$110262 = ((i$110150) >= (((long)(t$110264))));
            }
            
            //#line 160 .. "x10/array/DistArray_Unique.x10"
            if (t$110262) {
                
                //#line 160 .. "x10/array/DistArray_Unique.x10"
                x10.array.DistArray.raiseBoundsError((long)(i$110150));
            }
            
            //#line 161 .. "x10/array/DistArray_Unique.x10"
            x10.array.DistArray.raisePlaceError((long)(i$110150));
        }
        
        //#line 133 . "x10/array/DistArray_Unique.x10"
        final x10.core.Rail t$110207 = ((x10.core.Rail)(((x10.array.DistArray<$T>)this$110152).raw));
        
        //#line 133 . "x10/array/DistArray_Unique.x10"
        ((x10.core.Rail<$T>)t$110207).$set__1x10$lang$Rail$$T$G((long)(0L), (($T)(v)));
        
        //#line 146 "x10/array/DistArray_Unique.x10"
        return (($T)
                 v);
    }
    
    
    //#line 148 "x10/array/DistArray_Unique.x10"
    public x10.core.Rail getPatch(final x10.array.IterationSpace space) {
        
        //#line 149 "x10/array/DistArray_Unique.x10"
        final java.lang.UnsupportedOperationException t$110208 = ((java.lang.UnsupportedOperationException)(new java.lang.UnsupportedOperationException("getPatch not supported for DistArray_Unique")));
        
        //#line 149 "x10/array/DistArray_Unique.x10"
        throw t$110208;
    }
    
    
    //#line 157 "x10/array/DistArray_Unique.x10"
    private void validateIndex(final long i) {
        
        //#line 159 "x10/array/DistArray_Unique.x10"
        final x10.lang.PlaceGroup t$110209 = ((x10.lang.PlaceGroup)(this.placeGroup));
        
        //#line 159 "x10/array/DistArray_Unique.x10"
        final long t$110210 = t$110209.indexOf$O(((x10.lang.Place)(x10.x10rt.X10RT.here())));
        
        //#line 159 "x10/array/DistArray_Unique.x10"
        final boolean t$110214 = ((long) t$110210) != ((long) i);
        
        //#line 159 "x10/array/DistArray_Unique.x10"
        if (t$110214) {
            
            //#line 160 "x10/array/DistArray_Unique.x10"
            boolean t$110212 = ((i) < (((long)(0L))));
            
            //#line 160 "x10/array/DistArray_Unique.x10"
            if (!(t$110212)) {
                
                //#line 160 "x10/array/DistArray_Unique.x10"
                final x10.lang.PlaceGroup this$110158 = ((x10.lang.PlaceGroup)(this.placeGroup));
                
                //#line 35 . "x10/lang/PlaceGroup.x10"
                final long t$110211 = this$110158.numPlaces$O();
                
                //#line 160 "x10/array/DistArray_Unique.x10"
                t$110212 = ((i) >= (((long)(t$110211))));
            }
            
            //#line 160 "x10/array/DistArray_Unique.x10"
            if (t$110212) {
                
                //#line 160 "x10/array/DistArray_Unique.x10"
                x10.array.DistArray.raiseBoundsError((long)(i));
            }
            
            //#line 161 "x10/array/DistArray_Unique.x10"
            x10.array.DistArray.raisePlaceError((long)(i));
        }
    }
    
    public static <$T>void validateIndex$P__1$1x10$array$DistArray_Unique$$T$2(final x10.rtt.Type $T, final long i, final x10.array.DistArray_Unique<$T> DistArray_Unique) {
        ((x10.array.DistArray_Unique<$T>)DistArray_Unique).validateIndex((long)(i));
    }
    
    
    //#line 22 "x10/array/DistArray_Unique.x10"
    final public x10.array.DistArray_Unique x10$array$DistArray_Unique$$this$x10$array$DistArray_Unique() {
        
        //#line 22 "x10/array/DistArray_Unique.x10"
        return x10.array.DistArray_Unique.this;
    }
    
    
    //#line 22 "x10/array/DistArray_Unique.x10"
    final public void __fieldInitializers_x10_array_DistArray_Unique() {
        
    }
    
    @x10.runtime.impl.java.X10Generated
    final public static class $Closure$20<$T> extends x10.core.Ref implements x10.core.fun.Fun_0_0, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<$Closure$20> $RTT = 
            x10.rtt.StaticFunType.<$Closure$20> make($Closure$20.class,
                                                     1,
                                                     new x10.rtt.Type[] {
                                                         x10.rtt.ParameterizedType.make(x10.core.fun.Fun_0_0.$RTT, x10.rtt.ParameterizedType.make(x10.array.LocalState.$RTT, x10.rtt.UnresolvedType.PARAM(0)))
                                                     });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { if (i == 0) return $T; return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static <$T> x10.serialization.X10JavaSerializable $_deserialize_body(x10.array.DistArray_Unique.$Closure$20<$T> $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            $_obj.$T = (x10.rtt.Type) $deserializer.readObject();
            $_obj.pg = $deserializer.readObject();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.array.DistArray_Unique.$Closure$20 $_obj = new x10.array.DistArray_Unique.$Closure$20((java.lang.System[]) null, (x10.rtt.Type) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            $serializer.write(this.$T);
            $serializer.write(this.pg);
            
        }
        
        // constructor just for allocation
        public $Closure$20(final java.lang.System[] $dummy, final x10.rtt.Type $T) {
            x10.array.DistArray_Unique.$Closure$20.$initParams(this, $T);
            
        }
        
        // bridge for method abstract public ()=>U.operator()():U
        public x10.array.LocalState $apply$G() {
            return $apply();
        }
        
        private x10.rtt.Type $T;
        
        // initializer of type parameters
        public static void $initParams(final $Closure$20 $this, final x10.rtt.Type $T) {
            $this.$T = $T;
            
        }
        
    
        
        public x10.array.LocalState $apply() {
            
            //#line 37 "x10/array/DistArray_Unique.x10"
            final x10.array.LocalState alloc$110216 = ((x10.array.LocalState)(new x10.array.LocalState<$T>((java.lang.System[]) null, $T)));
            
            //#line 37 "x10/array/DistArray_Unique.x10"
            final x10.core.Rail rail$110218 = ((x10.core.Rail)(new x10.core.Rail<$T>($T, ((long)(1L)))));
            
            //#line 37 "x10/array/DistArray_Unique.x10"
            final long size$110219 = this.pg.numPlaces$O();
            
            //#line 301 . "x10/array/DistArray.x10"
            ((x10.array.LocalState<$T>)alloc$110216).pg = ((x10.lang.PlaceGroup)(this.pg));
            
            //#line 301 . "x10/array/DistArray.x10"
            ((x10.array.LocalState<$T>)alloc$110216).rail = ((x10.core.Rail)(rail$110218));
            
            //#line 301 . "x10/array/DistArray.x10"
            ((x10.array.LocalState<$T>)alloc$110216).size = size$110219;
            
            //#line 37 "x10/array/DistArray_Unique.x10"
            return alloc$110216;
        }
        
        public x10.lang.PlaceGroup pg;
        
        public $Closure$20(final x10.rtt.Type $T, final x10.lang.PlaceGroup pg) {
            x10.array.DistArray_Unique.$Closure$20.$initParams(this, $T);
             {
                ((x10.array.DistArray_Unique.$Closure$20<$T>)this).pg = ((x10.lang.PlaceGroup)(pg));
            }
        }
        
    }
    
    @x10.runtime.impl.java.X10Generated
    final public static class $Closure$21<$T> extends x10.core.Ref implements x10.core.fun.Fun_0_0, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<$Closure$21> $RTT = 
            x10.rtt.StaticFunType.<$Closure$21> make($Closure$21.class,
                                                     1,
                                                     new x10.rtt.Type[] {
                                                         x10.rtt.ParameterizedType.make(x10.core.fun.Fun_0_0.$RTT, x10.rtt.ParameterizedType.make(x10.array.LocalState.$RTT, x10.rtt.UnresolvedType.PARAM(0)))
                                                     });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { if (i == 0) return $T; return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static <$T> x10.serialization.X10JavaSerializable $_deserialize_body(x10.array.DistArray_Unique.$Closure$21<$T> $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            $_obj.$T = (x10.rtt.Type) $deserializer.readObject();
            $_obj.init = $deserializer.readObject();
            $_obj.pg = $deserializer.readObject();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.array.DistArray_Unique.$Closure$21 $_obj = new x10.array.DistArray_Unique.$Closure$21((java.lang.System[]) null, (x10.rtt.Type) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            $serializer.write(this.$T);
            $serializer.write(this.init);
            $serializer.write(this.pg);
            
        }
        
        // constructor just for allocation
        public $Closure$21(final java.lang.System[] $dummy, final x10.rtt.Type $T) {
            x10.array.DistArray_Unique.$Closure$21.$initParams(this, $T);
            
        }
        
        // bridge for method abstract public ()=>U.operator()():U
        public x10.array.LocalState $apply$G() {
            return $apply();
        }
        
        private x10.rtt.Type $T;
        
        // initializer of type parameters
        public static void $initParams(final $Closure$21 $this, final x10.rtt.Type $T) {
            $this.$T = $T;
            
        }
        // synthetic type for parameter mangling
        public static final class __0$1x10$array$DistArray_Unique$$Closure$21$$T$2 {}
        
    
        
        public x10.array.LocalState $apply() {
            
            //#line 54 "x10/array/DistArray_Unique.x10"
            final x10.array.LocalState alloc$110223 = ((x10.array.LocalState)(new x10.array.LocalState<$T>((java.lang.System[]) null, $T)));
            
            //#line 54 "x10/array/DistArray_Unique.x10"
            final $T t$110225 = (($T)(((x10.core.fun.Fun_0_0<$T>)this.init).$apply$G()));
            
            //#line 54 "x10/array/DistArray_Unique.x10"
            final x10.core.Rail rail$110226 = ((x10.core.Rail)(new x10.core.Rail<$T>($T, ((long)(1L)), t$110225, (x10.core.Rail.__1x10$lang$Rail$$T) null)));
            
            //#line 54 "x10/array/DistArray_Unique.x10"
            final long size$110227 = this.pg.numPlaces$O();
            
            //#line 301 . "x10/array/DistArray.x10"
            ((x10.array.LocalState<$T>)alloc$110223).pg = ((x10.lang.PlaceGroup)(this.pg));
            
            //#line 301 . "x10/array/DistArray.x10"
            ((x10.array.LocalState<$T>)alloc$110223).rail = ((x10.core.Rail)(rail$110226));
            
            //#line 301 . "x10/array/DistArray.x10"
            ((x10.array.LocalState<$T>)alloc$110223).size = size$110227;
            
            //#line 54 "x10/array/DistArray_Unique.x10"
            return alloc$110223;
        }
        
        public x10.core.fun.Fun_0_0<$T> init;
        public x10.lang.PlaceGroup pg;
        
        public $Closure$21(final x10.rtt.Type $T, final x10.core.fun.Fun_0_0<$T> init, final x10.lang.PlaceGroup pg, __0$1x10$array$DistArray_Unique$$Closure$21$$T$2 $dummy) {
            x10.array.DistArray_Unique.$Closure$21.$initParams(this, $T);
             {
                ((x10.array.DistArray_Unique.$Closure$21<$T>)this).init = ((x10.core.fun.Fun_0_0)(init));
                ((x10.array.DistArray_Unique.$Closure$21<$T>)this).pg = ((x10.lang.PlaceGroup)(pg));
            }
        }
        
    }
    
}

