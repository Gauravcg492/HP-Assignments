package x10.array;


/**
 * <p> This class provides a high-performance implementation of
 * a simple multi-dimensional Array that maps long indices to values.  
 * This array implementation only supports zero-based, dense indexing.
 * For example, a two dimensional array of N by M elements is indexed by 
 * (0..N-1,0..M-1).</p>
 * 
 * <p> Related classes in this package {@link DistArray} provide a similar
 * simple array abstraction whose data is distributed across multiple
 * places.</p>
 * 
 * <p>The {@link x10.lang.Rail} class also provides a similar, high-performance
 * implementation of a one dimensional array.  The expectation should be that
 * a Array_1 and a Rail should have very similar performance characteristics,
 * although the Array_1 has an additional wrapper object and thus may have
 * marginally lower performance in some situations.</p>
 * 
 * <p>A more general, but lower performance, array abstraction is provided 
 * by {@link x10.regionarray.Array} and {@link x10.regionarray.DistArray} which support 
 * more general indexing operations via user-extensible {@link x10.regionarray.Region}s 
 * and {@link x10.regionarray.Dist}s. See the package documentation of {@link x10.regionarray}
 * for more details.</p>
 */
@x10.runtime.impl.java.X10Generated
abstract public class Array<$T> extends x10.core.Ref implements x10.lang.Iterable, x10.core.fun.Fun_0_1, x10.serialization.X10JavaSerializable
{
    public static final x10.rtt.RuntimeType<Array> $RTT = 
        x10.rtt.NamedType.<Array> make("x10.array.Array",
                                       Array.class,
                                       1,
                                       new x10.rtt.Type[] {
                                           x10.rtt.ParameterizedType.make(x10.lang.Iterable.$RTT, x10.rtt.UnresolvedType.PARAM(0)),
                                           x10.rtt.ParameterizedType.make(x10.core.fun.Fun_0_1.$RTT, x10.lang.Point.$RTT, x10.rtt.UnresolvedType.PARAM(0))
                                       });
    
    public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
    
    public x10.rtt.Type<?> $getParam(int i) { if (i == 0) return $T; return null; }
    
    public static <$T> x10.serialization.X10JavaSerializable $_deserialize_body(x10.array.Array<$T> $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
        $_obj.$T = (x10.rtt.Type) $deserializer.readObject();
        $_obj.raw = $deserializer.readObject();
        $_obj.size = $deserializer.readLong();
        return $_obj;
    }
    
    public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
        return null;
    }
    
    public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
        $serializer.write(this.$T);
        $serializer.write(this.raw);
        $serializer.write(this.size);
        
    }
    
    // constructor just for allocation
    public Array(final java.lang.System[] $dummy, final x10.rtt.Type $T) {
        x10.array.Array.$initParams(this, $T);
        
    }
    
    // dispatcher for method abstract public (Z1)=>U.operator()(a1:Z1){}:U
    public java.lang.Object $apply(final java.lang.Object a1, final x10.rtt.Type t1) {
        return $apply$G((x10.lang.Point)a1);
        
    }
    
    private x10.rtt.Type $T;
    
    // initializer of type parameters
    public static void $initParams(final Array $this, final x10.rtt.Type $T) {
        $this.$T = $T;
        
    }
    // synthetic type for parameter mangling
    public static final class __0$1x10$array$Array$$T$2 {}
    
    // properties
    
    //#line 46 "x10/array/Array.x10"
    /**
         * The number of data values in the array.
         */
    public long size;
    

    
    
    //#line 52 "x10/array/Array.x10"
    /**
     * @return the rank (dimensionality) of the Array
     */
    abstract public long rank$O();
    
    
    //#line 57 "x10/array/Array.x10"
    /**
     * The backing storage for the array's elements
     */
    public x10.core.Rail<$T> raw;
    
    
    //#line 59 "x10/array/Array.x10"
    
    // constructor for non-virtual call
    final public x10.array.Array<$T> x10$array$Array$$init$S(final long s, final boolean zero) {
         {
            
            //#line 60 "x10/array/Array.x10"
            this.size = s;
            
            
            //#line 61 "x10/array/Array.x10"
            x10.core.Rail t$97621 =  null;
            
            //#line 61 "x10/array/Array.x10"
            if (zero) {
                
                //#line 61 "x10/array/Array.x10"
                t$97621 = ((x10.core.Rail)(x10.core.Rail.<$T>makeUnsafe($T, ((long)(s)), true)));
            } else {
                
                //#line 61 "x10/array/Array.x10"
                t$97621 = ((x10.core.Rail)(x10.core.Rail.<$T>makeUnsafe($T, ((long)(s)), false)));
            }
            
            //#line 61 "x10/array/Array.x10"
            ((x10.array.Array<$T>)this).raw = ((x10.core.Rail)(t$97621));
        }
        return this;
    }
    
    
    
    //#line 64 "x10/array/Array.x10"
    
    // constructor for non-virtual call
    final public x10.array.Array<$T> x10$array$Array$$init$S(final x10.core.Rail<$T> r, __0$1x10$array$Array$$T$2 $dummy) {
         {
            
            //#line 65 "x10/array/Array.x10"
            final long t$97703 = ((x10.core.Rail<$T>)r).size;
            
            //#line 65 "x10/array/Array.x10"
            this.size = t$97703;
            
            
            //#line 66 "x10/array/Array.x10"
            ((x10.array.Array<$T>)this).raw = ((x10.core.Rail)(r));
        }
        return this;
    }
    
    
    
    //#line 82 "x10/array/Array.x10"
    /**
     * <p>Return the Rail[T] that is providing the backing storage for the array.
     * This method is primarily intended to be used to interface with native libraries 
     * (eg BLAS, ESSL) and to support bulk copy operations using the asyncCopy 
     * methods of Rail.</p>
     * 
     * This method should be used sparingly, since it may make client code dependent on 
     * the layout algorithm used to map rank-dimensional array indicies to 1-dimensional
     * indicies in the backing Rail.
     * 
     * @return the Rail[T] that is the backing storage for the Array object.
     */
    final public x10.core.Rail raw() {
        
        //#line 82 "x10/array/Array.x10"
        final x10.core.Rail t$97624 = ((x10.core.Rail)(this.raw));
        
        //#line 82 "x10/array/Array.x10"
        return t$97624;
    }
    
    
    //#line 90 "x10/array/Array.x10"
    /**
     * Change the Rail[T] that is providing the backing storage for the array.
     *
     * @param r the new backing storage for the array.
     */
    final public void modifyRaw__0$1x10$array$Array$$T$2(final x10.core.Rail r) {
        
        //#line 91 "x10/array/Array.x10"
        final x10.core.Rail t$97625 = ((x10.core.Rail)(this.raw));
        
        //#line 91 "x10/array/Array.x10"
        final long t$97626 = ((x10.core.Rail<$T>)t$97625).size;
        
        //#line 91 "x10/array/Array.x10"
        final long t$97627 = this.size;
        
        //#line 91 "x10/array/Array.x10"
        final boolean t$97629 = ((long) t$97626) != ((long) t$97627);
        
        //#line 91 "x10/array/Array.x10"
        if (t$97629) {
            
            //#line 91 "x10/array/Array.x10"
            final java.lang.IllegalArgumentException t$97628 = ((java.lang.IllegalArgumentException)(new java.lang.IllegalArgumentException("size mismatch")));
            
            //#line 91 "x10/array/Array.x10"
            throw t$97628;
        }
        
        //#line 92 "x10/array/Array.x10"
        final x10.core.Rail t$96805 = ((x10.core.Rail<$T>)
                                        r);
        
        //#line 92 "x10/array/Array.x10"
        final long t$97630 = ((x10.core.Rail<$T>)t$96805).size;
        
        //#line 92 "x10/array/Array.x10"
        final long t$97631 = x10.array.Array.this.size;
        
        //#line 92 "x10/array/Array.x10"
        boolean t$97632 = ((long) t$97630) == ((long) t$97631);
        
        //#line 92 "x10/array/Array.x10"
        if (t$97632) {
            
            //#line 92 "x10/array/Array.x10"
            t$97632 = ((t$96805) != (null));
        }
        
        //#line 92 "x10/array/Array.x10"
        final boolean t$97635 = !(t$97632);
        
        //#line 92 "x10/array/Array.x10"
        if (t$97635) {
            
            //#line 92 "x10/array/Array.x10"
            final x10.lang.FailedDynamicCheckException t$97634 = new x10.lang.FailedDynamicCheckException("x10.lang.Rail[T]{self.size==this(:x10.array.Array).size, self!=null}");
            
            //#line 92 "x10/array/Array.x10"
            throw t$97634;
        }
        
        //#line 92 "x10/array/Array.x10"
        ((x10.array.Array<$T>)this).raw = ((x10.core.Rail)(t$96805));
    }
    
    
    //#line 104 "x10/array/Array.x10"
    /**
     * Swap the backing storage of two arrays.
     * The two arrays must be of equal size, but do not necessarily need
     * to be the same rank or have the same dimensions.
     * This method can be used to support a "red/black" design pattern where
     * the backing Rails for the arrays are swapped at phase boundaries.
     * @param a1 the first array
     * @param a2 the second array, same size as the first
     */
    public static <$T>void swap__0$1x10$array$Array$$T$2__1$1x10$array$Array$$T$2(final x10.rtt.Type $T, final x10.array.Array<$T> a1, final x10.array.Array<$T> a2) {
        
        //#line 105 "x10/array/Array.x10"
        final x10.core.Rail tmp = ((x10.core.Rail)(((x10.array.Array<$T>)a1).raw));
        
        //#line 82 . "x10/array/Array.x10"
        final x10.core.Rail t$97636 = ((x10.core.Rail)(((x10.array.Array<$T>)a2).raw));
        
        //#line 106 "x10/array/Array.x10"
        ((x10.array.Array<$T>)a1).modifyRaw__0$1x10$array$Array$$T$2(((x10.core.Rail)(t$97636)));
        
        //#line 107 "x10/array/Array.x10"
        ((x10.array.Array<$T>)a2).modifyRaw__0$1x10$array$Array$$T$2(((x10.core.Rail)(tmp)));
    }
    
    
    //#line 116 "x10/array/Array.x10"
    /**
     * Return an iterator over the values of this array.
     * 
     * @return an iterator over the values of this array.
     * @see x10.lang.Iterable[T]#iterator()
     */
    final public x10.lang.Iterator iterator() {
        
        //#line 116 "x10/array/Array.x10"
        final x10.core.Rail t$97637 = ((x10.core.Rail)(this.raw));
        
        //#line 116 "x10/array/Array.x10"
        final x10.lang.Iterator t$97638 = ((x10.lang.Iterator<$T>)
                                            ((x10.core.Rail<$T>)t$97637).iterator());
        
        //#line 116 "x10/array/Array.x10"
        return t$97638;
    }
    
    
    //#line 124 "x10/array/Array.x10"
    /**
     * Fill all elements of the array to contain the argument value.
     * 
     * @param v the value with which to fill the array
     */
    public void fill__0x10$array$Array$$T(final $T v) {
        
        //#line 125 "x10/array/Array.x10"
        final x10.core.Rail t$97639 = ((x10.core.Rail)(this.raw));
        
        //#line 125 "x10/array/Array.x10"
        ((x10.core.Rail<$T>)t$97639).fill__0x10$lang$Rail$$T((($T)(v)));
    }
    
    
    //#line 133 "x10/array/Array.x10"
    /**
     * Fill all elements of the array with the zero value of type T 
     * @see x10.lang.Zero.get[T]()
     */
    public void clear() {
        
        //#line 134 "x10/array/Array.x10"
        final x10.core.Rail t$97640 = ((x10.core.Rail)(this.raw));
        
        //#line 134 "x10/array/Array.x10"
        ((x10.core.Rail<$T>)t$97640).clear();
    }
    
    
    //#line 148 "x10/array/Array.x10"
    /**
     * Reduce this array using the given function and the given initial value.
     * Each element of the array will be given as an argument to the reduction
     * function exactly once, but in an arbitrary order.  The reduction function
     * may be applied concurrently to implement a parallel reduction. 
     * 
     * @param op the reduction function
     * @param unit the given initial value
     * @return the final result of the reduction.
     */
    final public <$U>$U reduce__0$1x10$array$Array$$U$3x10$array$Array$$T$3x10$array$Array$$U$2__1x10$array$Array$$U$G(final x10.rtt.Type $U, final x10.core.fun.Fun_0_2 op, final $U unit) {
        
        //#line 149 "x10/array/Array.x10"
        final x10.core.Rail src$97571 = ((x10.core.Rail)(this.raw));
        
        //#line 132 . "x10/util/RailUtils.x10"
        $U accum$97574 = (($U)(unit));
        
        //#line 133 . "x10/util/RailUtils.x10"
        final long i$97460max$97715 = ((x10.core.Rail<$T>)src$97571).size;
        
        //#line 133 . "x10/util/RailUtils.x10"
        long i$97711 = 0L;
        
        //#line 133 . "x10/util/RailUtils.x10"
        for (;
             true;
             ) {
            
            //#line 133 . "x10/util/RailUtils.x10"
            final boolean t$97713 = ((i$97711) < (((long)(i$97460max$97715))));
            
            //#line 133 . "x10/util/RailUtils.x10"
            if (!(t$97713)) {
                
                //#line 133 . "x10/util/RailUtils.x10"
                break;
            }
            
            //#line 134 . "x10/util/RailUtils.x10"
            final $T t$97706 = (($T)(((x10.core.Rail<$T>)src$97571).$apply$G((long)(i$97711))));
            
            //#line 134 . "x10/util/RailUtils.x10"
            final $U t$97707 = (($U)((($U)
                                       ((x10.core.fun.Fun_0_2<$U,$T,$U>)op).$apply(accum$97574, $U, t$97706, $T))));
            
            //#line 134 . "x10/util/RailUtils.x10"
            accum$97574 = (($U)(t$97707));
            
            //#line 133 . "x10/util/RailUtils.x10"
            final long t$97710 = ((i$97711) + (((long)(1L))));
            
            //#line 133 . "x10/util/RailUtils.x10"
            i$97711 = t$97710;
        }
        
        //#line 149 "x10/array/Array.x10"
        return accum$97574;
    }
    
    
    //#line 169 "x10/array/Array.x10"
    /**
     * Map the given function onto the elements of this array
     * storing the results in the dst array. For maximum flexibility
     * of use, map does not require that the src and destination array
     * have the same dimesionality or rank, only that they have the same
     * number of elements.  When applied to arrays that use the same IterationSpace,
     * the result will be that for all <code>pt</code> in the IterationSpace
     * </code> dst(pt) == op(src(pt)) </code>.  When applied to arrays that use
     * a different iteration space, the mapping from src to dst is defined in
     * terms of the index of the backing rails, that is <code>dst.raw()(i) = op(src.raw()(i))</code>
     * for i in <code>0..(src.size()-1)</code>.
     * 
     * @param dst the destination array for the results of the map operation
     * @param op the function to apply to each element of the array
     * @return dst after updating its contents to contain the result of the map operation.
     */
    final public <$U>x10.array.Array map__0$1x10$array$Array$$U$2__1$1x10$array$Array$$T$3x10$array$Array$$U$2(final x10.rtt.Type $U, final x10.array.Array dst, final x10.core.fun.Fun_0_1 op) {
        
        //#line 170 "x10/array/Array.x10"
        final x10.core.Rail src$97581 = ((x10.core.Rail)(this.raw));
        
        //#line 170 "x10/array/Array.x10"
        final x10.core.Rail dst$97582 = ((x10.core.Rail)(((x10.array.Array<$U>)dst).raw));
        
        //#line 180 . "x10/util/RailUtils.x10"
        final long i$97498max$97725 = ((x10.core.Rail<$T>)src$97581).size;
        
        //#line 180 . "x10/util/RailUtils.x10"
        long i$97721 = 0L;
        
        //#line 180 . "x10/util/RailUtils.x10"
        for (;
             true;
             ) {
            
            //#line 180 . "x10/util/RailUtils.x10"
            final boolean t$97723 = ((i$97721) < (((long)(i$97498max$97725))));
            
            //#line 180 . "x10/util/RailUtils.x10"
            if (!(t$97723)) {
                
                //#line 180 . "x10/util/RailUtils.x10"
                break;
            }
            
            //#line 181 . "x10/util/RailUtils.x10"
            final $T t$97716 = (($T)(((x10.core.Rail<$T>)src$97581).$apply$G((long)(i$97721))));
            
            //#line 181 . "x10/util/RailUtils.x10"
            final $U t$97717 = (($U)((($U)
                                       ((x10.core.fun.Fun_0_1<$T,$U>)op).$apply(t$97716, $T))));
            
            //#line 181 . "x10/util/RailUtils.x10"
            ((x10.core.Rail<$U>)dst$97582).$set__1x10$lang$Rail$$T$G((long)(i$97721), (($U)(t$97717)));
            
            //#line 180 . "x10/util/RailUtils.x10"
            final long t$97720 = ((i$97721) + (((long)(1L))));
            
            //#line 180 . "x10/util/RailUtils.x10"
            i$97721 = t$97720;
        }
        
        //#line 171 "x10/array/Array.x10"
        return dst;
    }
    
    
    //#line 193 "x10/array/Array.x10"
    /**
     * Map the given function onto the elements of this array
     * and the argument src array storing the results in the dst array. 
     * For maximum flexibility of use, map does not require that the three arrays
     * have the same dimesionality or rank, only that they have the same
     * number of elements.  When applied to arrays that use the same IterationSpace,
     * the result will be that for all <code>pt</code> in the IterationSpace
     * </code> dst(pt) == op(this(pt), src(pt)) </code>.  When applied to arrays that use
     * a different iteration space, the mapping from src to dst is defined in
     * terms of the index of the backing rails, that is 
     * <code>dst.raw()(i) = op(this.raw()(i), src.raw()(i))</code>
     * for i in <code>0..(src.size()-1)</code>.
     * 
     * @param src2 the second source array to use as input to the map function
     * @param dst the destination array for the results of the map operation
     * @param op the function to apply to each element of the arrays
     * @return dst after updating its contents to contain the result of the map operation.
     */
    final public <$S, $U>x10.array.Array map__0$1x10$array$Array$$S$2__1$1x10$array$Array$$U$2__2$1x10$array$Array$$T$3x10$array$Array$$S$3x10$array$Array$$U$2(final x10.rtt.Type $S, final x10.rtt.Type $U, final x10.array.Array src2, final x10.array.Array dst, final x10.core.fun.Fun_0_2 op) {
        
        //#line 195 "x10/array/Array.x10"
        final x10.core.Rail src$97590 = ((x10.core.Rail)(this.raw));
        
        //#line 195 "x10/array/Array.x10"
        final x10.core.Rail src$97591 = ((x10.core.Rail)(((x10.array.Array<$S>)src2).raw));
        
        //#line 195 "x10/array/Array.x10"
        final x10.core.Rail dst$97592 = ((x10.core.Rail)(((x10.array.Array<$U>)dst).raw));
        
        //#line 203 . "x10/util/RailUtils.x10"
        final long i$97517max$97736 = ((x10.core.Rail<$T>)src$97590).size;
        
        //#line 203 . "x10/util/RailUtils.x10"
        long i$97732 = 0L;
        
        //#line 203 . "x10/util/RailUtils.x10"
        for (;
             true;
             ) {
            
            //#line 203 . "x10/util/RailUtils.x10"
            final boolean t$97734 = ((i$97732) < (((long)(i$97517max$97736))));
            
            //#line 203 . "x10/util/RailUtils.x10"
            if (!(t$97734)) {
                
                //#line 203 . "x10/util/RailUtils.x10"
                break;
            }
            
            //#line 204 . "x10/util/RailUtils.x10"
            final $T t$97726 = (($T)(((x10.core.Rail<$T>)src$97590).$apply$G((long)(i$97732))));
            
            //#line 204 . "x10/util/RailUtils.x10"
            final $S t$97727 = (($S)(((x10.core.Rail<$S>)src$97591).$apply$G((long)(i$97732))));
            
            //#line 204 . "x10/util/RailUtils.x10"
            final $U t$97728 = (($U)((($U)
                                       ((x10.core.fun.Fun_0_2<$T,$S,$U>)op).$apply(t$97726, $T, t$97727, $S))));
            
            //#line 204 . "x10/util/RailUtils.x10"
            ((x10.core.Rail<$U>)dst$97592).$set__1x10$lang$Rail$$T$G((long)(i$97732), (($U)(t$97728)));
            
            //#line 203 . "x10/util/RailUtils.x10"
            final long t$97731 = ((i$97732) + (((long)(1L))));
            
            //#line 203 . "x10/util/RailUtils.x10"
            i$97732 = t$97731;
        }
        
        //#line 196 "x10/array/Array.x10"
        return dst;
    }
    
    
    //#line 205 "x10/array/Array.x10"
    /**
     * Get an IterationSpace that represents all Points contained in
     * iteration space (valid indices) of the Array.
     * @return an IterationSpace for the Array
     */
    abstract public x10.array.IterationSpace indices();
    
    
    //#line 216 "x10/array/Array.x10"
    /**
     * Return the element of this array corresponding to the given point.
     * The rank of the given point has to be the same as the rank of this array.
     * 
     * @param p the given point
     * @return the element of this array corresponding to the given point.
     * @see #set(T, Point)
     */
    abstract public $T $apply$G(final x10.lang.Point p);
    
    
    //#line 229 "x10/array/Array.x10"
    /**
     * Set the element of this array corresponding to the given point to the given value.
     * Return the new value of the element.
     * The rank of the given point has to be the same as the rank of this array.
     * 
     * @param v the given value
     * @param p the given point
     * @return the new value of the element of this array corresponding to the given point.
     * @see #operator(Point)
     */
    abstract public $T $set__1x10$array$Array$$T$G(final x10.lang.Point p, final $T v);
    
    
    //#line 240 "x10/array/Array.x10"
    /**
     * Copy all of the values from the source Array to the destination Array.
     * The two arrays must be of equal size, but do not necessarily need
     * to be the same rank or have the same dimensions.
     *
     * @param src the source array.
     * @param dst the destination array.
     */
    public static <$T>void copy__0$1x10$array$Array$$T$2__1$1x10$array$Array$$T$2(final x10.rtt.Type $T, final x10.array.Array<$T> src, final x10.array.Array<$T> dst) {
        
        //#line 241 "x10/array/Array.x10"
        final x10.core.Rail t$97672 = ((x10.core.Rail)(((x10.array.Array<$T>)src).raw));
        
        //#line 241 "x10/array/Array.x10"
        final x10.core.Rail t$97673 = ((x10.core.Rail)(((x10.array.Array<$T>)dst).raw));
        
        //#line 241 "x10/array/Array.x10"
        final x10.core.Rail t$97671 = ((x10.core.Rail)(((x10.array.Array<$T>)src).raw));
        
        //#line 241 "x10/array/Array.x10"
        final long t$97674 = ((x10.core.Rail<$T>)t$97671).size;
        
        //#line 241 "x10/array/Array.x10"
        x10.core.Rail.<$T> copy__0$1x10$lang$Rail$$T$2__2$1x10$lang$Rail$$T$2($T, ((x10.core.Rail)(t$97672)), (long)(0L), ((x10.core.Rail)(t$97673)), (long)(0L), (long)(t$97674));
    }
    
    
    //#line 257 "x10/array/Array.x10"
    /**
     * Copy numElems values starting from srcIndex from the source Array 
     * to the destination Array starting at dstIndex.
     *
     * @param src the source array.
     * @param srcIndex the index of the first element in this array
     *        to be copied.  
     * @param dst the destination array.
     * @param dstIndex the index of the first element in the destination
     *        array where copied data elements will be stored.
     * @param numElems the number of elements to be copied.
     */
    public static <$T>void copy__0$1x10$array$Array$$T$2__2$1x10$array$Array$$T$2(final x10.rtt.Type $T, final x10.array.Array<$T> src, final long srcIndex, final x10.array.Array<$T> dst, final long dstIndex, final long numElems) {
        
        //#line 259 "x10/array/Array.x10"
        final x10.core.Rail t$97675 = ((x10.core.Rail)(((x10.array.Array<$T>)src).raw));
        
        //#line 259 "x10/array/Array.x10"
        final x10.core.Rail t$97676 = ((x10.core.Rail)(((x10.array.Array<$T>)dst).raw));
        
        //#line 259 "x10/array/Array.x10"
        x10.core.Rail.<$T> copy__0$1x10$lang$Rail$$T$2__2$1x10$lang$Rail$$T$2($T, ((x10.core.Rail)(t$97675)), (long)(srcIndex), ((x10.core.Rail)(t$97676)), (long)(dstIndex), (long)(numElems));
    }
    
    
    //#line 263 "x10/array/Array.x10"
    public static void raiseBoundsError(final long i) {
        
        //#line 264 "x10/array/Array.x10"
        final java.lang.String t$97677 = (("(") + ((x10.core.Long.$box(i))));
        
        //#line 264 "x10/array/Array.x10"
        final java.lang.String t$97678 = ((t$97677) + (") not contained in array"));
        
        //#line 264 "x10/array/Array.x10"
        final java.lang.ArrayIndexOutOfBoundsException t$97679 = ((java.lang.ArrayIndexOutOfBoundsException)(new java.lang.ArrayIndexOutOfBoundsException(t$97678)));
        
        //#line 264 "x10/array/Array.x10"
        throw t$97679;
    }
    
    
    //#line 266 "x10/array/Array.x10"
    public static void raiseBoundsError(final long i, final long j) {
        
        //#line 267 "x10/array/Array.x10"
        final java.lang.String t$97680 = (("(") + ((x10.core.Long.$box(i))));
        
        //#line 267 "x10/array/Array.x10"
        final java.lang.String t$97681 = ((t$97680) + (", "));
        
        //#line 267 "x10/array/Array.x10"
        final java.lang.String t$97682 = ((t$97681) + ((x10.core.Long.$box(j))));
        
        //#line 267 "x10/array/Array.x10"
        final java.lang.String t$97683 = ((t$97682) + (") not contained in array"));
        
        //#line 267 "x10/array/Array.x10"
        final java.lang.ArrayIndexOutOfBoundsException t$97684 = ((java.lang.ArrayIndexOutOfBoundsException)(new java.lang.ArrayIndexOutOfBoundsException(t$97683)));
        
        //#line 267 "x10/array/Array.x10"
        throw t$97684;
    }
    
    
    //#line 269 "x10/array/Array.x10"
    public static void raiseBoundsError(final long i, final long j, final long k) {
        
        //#line 270 "x10/array/Array.x10"
        final java.lang.String t$97685 = (("(") + ((x10.core.Long.$box(i))));
        
        //#line 270 "x10/array/Array.x10"
        final java.lang.String t$97686 = ((t$97685) + (", "));
        
        //#line 270 "x10/array/Array.x10"
        final java.lang.String t$97687 = ((t$97686) + ((x10.core.Long.$box(j))));
        
        //#line 270 "x10/array/Array.x10"
        final java.lang.String t$97688 = ((t$97687) + (", "));
        
        //#line 270 "x10/array/Array.x10"
        final java.lang.String t$97689 = ((t$97688) + ((x10.core.Long.$box(k))));
        
        //#line 270 "x10/array/Array.x10"
        final java.lang.String t$97690 = ((t$97689) + (") not contained in array"));
        
        //#line 270 "x10/array/Array.x10"
        final java.lang.ArrayIndexOutOfBoundsException t$97691 = ((java.lang.ArrayIndexOutOfBoundsException)(new java.lang.ArrayIndexOutOfBoundsException(t$97690)));
        
        //#line 270 "x10/array/Array.x10"
        throw t$97691;
    }
    
    
    //#line 272 "x10/array/Array.x10"
    public static void raiseBoundsError(final long i, final long j, final long k, final long l) {
        
        //#line 273 "x10/array/Array.x10"
        final java.lang.String t$97692 = (("(") + ((x10.core.Long.$box(i))));
        
        //#line 273 "x10/array/Array.x10"
        final java.lang.String t$97693 = ((t$97692) + (", "));
        
        //#line 273 "x10/array/Array.x10"
        final java.lang.String t$97694 = ((t$97693) + ((x10.core.Long.$box(j))));
        
        //#line 273 "x10/array/Array.x10"
        final java.lang.String t$97695 = ((t$97694) + (", "));
        
        //#line 273 "x10/array/Array.x10"
        final java.lang.String t$97696 = ((t$97695) + ((x10.core.Long.$box(k))));
        
        //#line 273 "x10/array/Array.x10"
        final java.lang.String t$97697 = ((t$97696) + (", "));
        
        //#line 273 "x10/array/Array.x10"
        final java.lang.String t$97698 = ((t$97697) + ((x10.core.Long.$box(l))));
        
        //#line 273 "x10/array/Array.x10"
        final java.lang.String t$97699 = ((t$97698) + (") not contained in array"));
        
        //#line 273 "x10/array/Array.x10"
        final java.lang.ArrayIndexOutOfBoundsException t$97700 = ((java.lang.ArrayIndexOutOfBoundsException)(new java.lang.ArrayIndexOutOfBoundsException(t$97699)));
        
        //#line 273 "x10/array/Array.x10"
        throw t$97700;
    }
    
    
    //#line 276 "x10/array/Array.x10"
    public static void raiseNegativeArraySizeException() {
        
        //#line 277 "x10/array/Array.x10"
        final java.lang.NegativeArraySizeException t$97701 = ((java.lang.NegativeArraySizeException)(new java.lang.NegativeArraySizeException()));
        
        //#line 277 "x10/array/Array.x10"
        throw t$97701;
    }
    
    
    //#line 42 "x10/array/Array.x10"
    final public x10.array.Array x10$array$Array$$this$x10$array$Array() {
        
        //#line 42 "x10/array/Array.x10"
        return x10.array.Array.this;
    }
    
    
    //#line 42 "x10/array/Array.x10"
    final public void __fieldInitializers_x10_array_Array() {
        
    }
}

