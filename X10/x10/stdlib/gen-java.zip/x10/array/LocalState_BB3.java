package x10.array;

@x10.runtime.impl.java.X10Generated
public class LocalState_BB3<$S> extends x10.array.LocalState<$S> implements x10.serialization.X10JavaSerializable
{
    public static final x10.rtt.RuntimeType<LocalState_BB3> $RTT = 
        x10.rtt.NamedType.<LocalState_BB3> make("x10.array.LocalState_BB3",
                                                LocalState_BB3.class,
                                                1,
                                                new x10.rtt.Type[] {
                                                    x10.rtt.ParameterizedType.make(x10.array.LocalState.$RTT, x10.rtt.UnresolvedType.PARAM(0))
                                                });
    
    public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
    
    public x10.rtt.Type<?> $getParam(int i) { if (i == 0) return $S; return null; }
    
    private Object writeReplace() throws java.io.ObjectStreamException {
        return new x10.serialization.SerializationProxy(this);
    }
    
    public static <$S> x10.serialization.X10JavaSerializable $_deserialize_body(x10.array.LocalState_BB3<$S> $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
        x10.array.LocalState.$_deserialize_body($_obj, $deserializer);
        $_obj.$S = (x10.rtt.Type) $deserializer.readObject();
        $_obj.dist = $deserializer.readObject();
        return $_obj;
    }
    
    public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
        x10.array.LocalState_BB3 $_obj = new x10.array.LocalState_BB3((java.lang.System[]) null, (x10.rtt.Type) null);
        $deserializer.record_reference($_obj);
        return $_deserialize_body($_obj, $deserializer);
    }
    
    public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
        super.$_serialize($serializer);
        $serializer.write(this.$S);
        $serializer.write(this.dist);
        
    }
    
    // constructor just for allocation
    public LocalState_BB3(final java.lang.System[] $dummy, final x10.rtt.Type $S) {
        super($dummy, $S);
        x10.array.LocalState_BB3.$initParams(this, $S);
        
    }
    
    private x10.rtt.Type $S;
    
    // initializer of type parameters
    public static void $initParams(final LocalState_BB3 $this, final x10.rtt.Type $S) {
        $this.$S = $S;
        
    }
    // synthetic type for parameter mangling
    public static final class __1$1x10$array$LocalState_BB3$$S$2 {}
    

    
    //#line 286 "x10/array/DistArray_BlockBlock_3.x10"
    public x10.array.Dist_BlockBlock_3 dist;
    
    
    //#line 288 "x10/array/DistArray_BlockBlock_3.x10"
    // creation method for java code (1-phase java constructor)
    public LocalState_BB3(final x10.rtt.Type $S, final x10.lang.PlaceGroup pg, final x10.core.Rail<$S> data, final long size, final x10.array.Dist_BlockBlock_3 d, __1$1x10$array$LocalState_BB3$$S$2 $dummy) {
        this((java.lang.System[]) null, $S);
        x10$array$LocalState_BB3$$init$S(pg, data, size, d, (x10.array.LocalState_BB3.__1$1x10$array$LocalState_BB3$$S$2) null);
    }
    
    // constructor for non-virtual call
    final public x10.array.LocalState_BB3<$S> x10$array$LocalState_BB3$$init$S(final x10.lang.PlaceGroup pg, final x10.core.Rail<$S> data, final long size, final x10.array.Dist_BlockBlock_3 d, __1$1x10$array$LocalState_BB3$$S$2 $dummy) {
         {
            
            //#line 290 "x10/array/DistArray_BlockBlock_3.x10"
            final x10.array.LocalState this$107530 = ((x10.array.LocalState)(this));
            
            //#line 301 . "x10/array/DistArray.x10"
            ((x10.array.LocalState<$S>)this$107530).pg = ((x10.lang.PlaceGroup)(pg));
            
            //#line 301 . "x10/array/DistArray.x10"
            ((x10.array.LocalState<$S>)this$107530).rail = ((x10.core.Rail)(data));
            
            //#line 301 . "x10/array/DistArray.x10"
            ((x10.array.LocalState<$S>)this$107530).size = size;
            
            //#line 288 "x10/array/DistArray_BlockBlock_3.x10"
            
            
            //#line 291 "x10/array/DistArray_BlockBlock_3.x10"
            ((x10.array.LocalState_BB3<$S>)this).dist = ((x10.array.Dist_BlockBlock_3)(d));
        }
        return this;
    }
    
    
    
    //#line 294 "x10/array/DistArray_BlockBlock_3.x10"
    public static <$S>x10.array.LocalState_BB3 make__4$1x10$lang$Long$3x10$lang$Long$3x10$lang$Long$3x10$array$LocalState_BB3$$S$2(final x10.rtt.Type $S, final x10.lang.PlaceGroup pg, final long m, final long n, final long p, final x10.core.fun.Fun_0_3<x10.core.Long,x10.core.Long,x10.core.Long,$S> init) {
        
        //#line 295 "x10/array/DistArray_BlockBlock_3.x10"
        final x10.array.DenseIterationSpace_3 globalSpace = ((x10.array.DenseIterationSpace_3)(new x10.array.DenseIterationSpace_3((java.lang.System[]) null)));
        
        //#line 295 "x10/array/DistArray_BlockBlock_3.x10"
        final long t$107857 = ((m) - (((long)(1L))));
        
        //#line 295 "x10/array/DistArray_BlockBlock_3.x10"
        final long t$107858 = ((n) - (((long)(1L))));
        
        //#line 295 "x10/array/DistArray_BlockBlock_3.x10"
        final long t$107859 = ((p) - (((long)(1L))));
        
        //#line 295 "x10/array/DistArray_BlockBlock_3.x10"
        globalSpace.x10$array$DenseIterationSpace_3$$init$S(((long)(0L)), ((long)(0L)), ((long)(0L)), t$107857, t$107858, t$107859);
        
        //#line 296 "x10/array/DistArray_BlockBlock_3.x10"
        final x10.array.Dist_BlockBlock_3 dist = ((x10.array.Dist_BlockBlock_3)(new x10.array.Dist_BlockBlock_3((java.lang.System[]) null)));
        
        //#line 296 "x10/array/DistArray_BlockBlock_3.x10"
        dist.x10$array$Dist_BlockBlock_3$$init$S(((x10.lang.PlaceGroup)(pg)), ((x10.array.DenseIterationSpace_3)(globalSpace)));
        
        //#line 298 "x10/array/DistArray_BlockBlock_3.x10"
        final x10.core.Rail data;
        
        //#line 299 "x10/array/DistArray_BlockBlock_3.x10"
        final x10.array.DenseIterationSpace_3 t$107735 = ((x10.array.DenseIterationSpace_3)(dist.localIndices));
        
        //#line 299 "x10/array/DistArray_BlockBlock_3.x10"
        final boolean t$107766 = t$107735.isEmpty$O();
        
        //#line 299 "x10/array/DistArray_BlockBlock_3.x10"
        if (t$107766) {
            
            //#line 300 "x10/array/DistArray_BlockBlock_3.x10"
            final x10.core.Rail t$107736 = ((x10.core.Rail)(new x10.core.Rail<$S>($S)));
            
            //#line 300 "x10/array/DistArray_BlockBlock_3.x10"
            data = ((x10.core.Rail)(t$107736));
        } else {
            
            //#line 302 "x10/array/DistArray_BlockBlock_3.x10"
            final x10.array.DenseIterationSpace_3 t$107737 = ((x10.array.DenseIterationSpace_3)(dist.localIndices));
            
            //#line 302 "x10/array/DistArray_BlockBlock_3.x10"
            final long low1 = t$107737.min$O((long)(0L));
            
            //#line 303 "x10/array/DistArray_BlockBlock_3.x10"
            final x10.array.DenseIterationSpace_3 t$107738 = ((x10.array.DenseIterationSpace_3)(dist.localIndices));
            
            //#line 303 "x10/array/DistArray_BlockBlock_3.x10"
            final long hi1 = t$107738.max$O((long)(0L));
            
            //#line 304 "x10/array/DistArray_BlockBlock_3.x10"
            final x10.array.DenseIterationSpace_3 t$107739 = ((x10.array.DenseIterationSpace_3)(dist.localIndices));
            
            //#line 304 "x10/array/DistArray_BlockBlock_3.x10"
            final long low2 = t$107739.min$O((long)(1L));
            
            //#line 305 "x10/array/DistArray_BlockBlock_3.x10"
            final x10.array.DenseIterationSpace_3 t$107740 = ((x10.array.DenseIterationSpace_3)(dist.localIndices));
            
            //#line 305 "x10/array/DistArray_BlockBlock_3.x10"
            final long hi2 = t$107740.max$O((long)(1L));
            
            //#line 307 "x10/array/DistArray_BlockBlock_3.x10"
            final long hi3 = ((p) - (((long)(1L))));
            
            //#line 308 "x10/array/DistArray_BlockBlock_3.x10"
            final long t$107741 = ((hi1) - (((long)(low1))));
            
            //#line 308 "x10/array/DistArray_BlockBlock_3.x10"
            final long localSize1 = ((t$107741) + (((long)(1L))));
            
            //#line 309 "x10/array/DistArray_BlockBlock_3.x10"
            final long t$107742 = ((hi2) - (((long)(low2))));
            
            //#line 309 "x10/array/DistArray_BlockBlock_3.x10"
            final long localSize2 = ((t$107742) + (((long)(1L))));
            
            //#line 311 "x10/array/DistArray_BlockBlock_3.x10"
            final long t$107743 = ((localSize1) * (((long)(localSize2))));
            
            //#line 311 "x10/array/DistArray_BlockBlock_3.x10"
            final long dataSize = ((t$107743) * (((long)(p))));
            
            //#line 312 "x10/array/DistArray_BlockBlock_3.x10"
            final x10.core.Rail t$107744 = ((x10.core.Rail)(x10.core.Rail.<$S>makeUnsafe($S, ((long)(dataSize)), false)));
            
            //#line 312 "x10/array/DistArray_BlockBlock_3.x10"
            data = ((x10.core.Rail)(t$107744));
            
            //#line 313 "x10/array/DistArray_BlockBlock_3.x10"
            long i$107852 = low1;
            
            //#line 313 "x10/array/DistArray_BlockBlock_3.x10"
            for (;
                 true;
                 ) {
                
                //#line 313 "x10/array/DistArray_BlockBlock_3.x10"
                final boolean t$107854 = ((i$107852) <= (((long)(hi1))));
                
                //#line 313 "x10/array/DistArray_BlockBlock_3.x10"
                if (!(t$107854)) {
                    
                    //#line 313 "x10/array/DistArray_BlockBlock_3.x10"
                    break;
                }
                
                //#line 314 "x10/array/DistArray_BlockBlock_3.x10"
                long i$107844 = low2;
                
                //#line 314 "x10/array/DistArray_BlockBlock_3.x10"
                for (;
                     true;
                     ) {
                    
                    //#line 314 "x10/array/DistArray_BlockBlock_3.x10"
                    final boolean t$107846 = ((i$107844) <= (((long)(hi2))));
                    
                    //#line 314 "x10/array/DistArray_BlockBlock_3.x10"
                    if (!(t$107846)) {
                        
                        //#line 314 "x10/array/DistArray_BlockBlock_3.x10"
                        break;
                    }
                    
                    //#line 315 "x10/array/DistArray_BlockBlock_3.x10"
                    long i$107837 = 0L;
                    
                    //#line 315 "x10/array/DistArray_BlockBlock_3.x10"
                    for (;
                         true;
                         ) {
                        
                        //#line 315 "x10/array/DistArray_BlockBlock_3.x10"
                        final boolean t$107839 = ((i$107837) <= (((long)(hi3))));
                        
                        //#line 315 "x10/array/DistArray_BlockBlock_3.x10"
                        if (!(t$107839)) {
                            
                            //#line 315 "x10/array/DistArray_BlockBlock_3.x10"
                            break;
                        }
                        
                        //#line 316 "x10/array/DistArray_BlockBlock_3.x10"
                        final long t$107827 = ((i$107844) - (((long)(low2))));
                        
                        //#line 316 "x10/array/DistArray_BlockBlock_3.x10"
                        final long t$107828 = ((i$107852) - (((long)(low1))));
                        
                        //#line 316 "x10/array/DistArray_BlockBlock_3.x10"
                        final long t$107829 = ((localSize2) * (((long)(t$107828))));
                        
                        //#line 316 "x10/array/DistArray_BlockBlock_3.x10"
                        final long t$107830 = ((t$107827) + (((long)(t$107829))));
                        
                        //#line 316 "x10/array/DistArray_BlockBlock_3.x10"
                        final long t$107831 = ((p) * (((long)(t$107830))));
                        
                        //#line 316 "x10/array/DistArray_BlockBlock_3.x10"
                        final long offset$107832 = ((i$107837) + (((long)(t$107831))));
                        
                        //#line 317 "x10/array/DistArray_BlockBlock_3.x10"
                        final $S t$107833 = (($S)((($S)
                                                    ((x10.core.fun.Fun_0_3<x10.core.Long,x10.core.Long,x10.core.Long,$S>)init).$apply(x10.core.Long.$box(i$107852), x10.rtt.Types.LONG, x10.core.Long.$box(i$107844), x10.rtt.Types.LONG, x10.core.Long.$box(i$107837), x10.rtt.Types.LONG))));
                        
                        //#line 317 "x10/array/DistArray_BlockBlock_3.x10"
                        ((x10.core.Rail<$S>)data).$set__1x10$lang$Rail$$T$G((long)(offset$107832), (($S)(t$107833)));
                        
                        //#line 315 "x10/array/DistArray_BlockBlock_3.x10"
                        final long t$107836 = ((i$107837) + (((long)(1L))));
                        
                        //#line 315 "x10/array/DistArray_BlockBlock_3.x10"
                        i$107837 = t$107836;
                    }
                    
                    //#line 314 "x10/array/DistArray_BlockBlock_3.x10"
                    final long t$107843 = ((i$107844) + (((long)(1L))));
                    
                    //#line 314 "x10/array/DistArray_BlockBlock_3.x10"
                    i$107844 = t$107843;
                }
                
                //#line 313 "x10/array/DistArray_BlockBlock_3.x10"
                final long t$107851 = ((i$107852) + (((long)(1L))));
                
                //#line 313 "x10/array/DistArray_BlockBlock_3.x10"
                i$107852 = t$107851;
            }
        }
        
        //#line 322 "x10/array/DistArray_BlockBlock_3.x10"
        final x10.array.LocalState_BB3 alloc$107317 = ((x10.array.LocalState_BB3)(new x10.array.LocalState_BB3<$S>((java.lang.System[]) null, $S)));
        
        //#line 322 "x10/array/DistArray_BlockBlock_3.x10"
        final long t$107860 = ((m) * (((long)(n))));
        
        //#line 322 "x10/array/DistArray_BlockBlock_3.x10"
        alloc$107317.x10$array$LocalState_BB3$$init$S(((x10.lang.PlaceGroup)(pg)), ((x10.core.Rail)(data)), t$107860, ((x10.array.Dist_BlockBlock_3)(dist)), (x10.array.LocalState_BB3.__1$1x10$array$LocalState_BB3$$S$2) null);
        
        //#line 322 "x10/array/DistArray_BlockBlock_3.x10"
        return alloc$107317;
    }
    
    
    //#line 285 "x10/array/DistArray_BlockBlock_3.x10"
    final public x10.array.LocalState_BB3 x10$array$LocalState_BB3$$this$x10$array$LocalState_BB3() {
        
        //#line 285 "x10/array/DistArray_BlockBlock_3.x10"
        return x10.array.LocalState_BB3.this;
    }
    
    
    //#line 285 "x10/array/DistArray_BlockBlock_3.x10"
    final public void __fieldInitializers_x10_array_LocalState_BB3() {
        
    }
}

