package x10.array;


/**
 * Implementation of 2-dimensional Array using row-major ordering.
 */
@x10.runtime.impl.java.X10Generated
final public class Array_2<$T> extends x10.array.Array<$T> implements x10.core.fun.Fun_0_2, x10.serialization.X10JavaSerializable
{
    public static final x10.rtt.RuntimeType<Array_2> $RTT = 
        x10.rtt.NamedType.<Array_2> make("x10.array.Array_2",
                                         Array_2.class,
                                         1,
                                         new x10.rtt.Type[] {
                                             x10.rtt.ParameterizedType.make(x10.core.fun.Fun_0_2.$RTT, x10.rtt.Types.LONG, x10.rtt.Types.LONG, x10.rtt.UnresolvedType.PARAM(0)),
                                             x10.rtt.ParameterizedType.make(x10.array.Array.$RTT, x10.rtt.UnresolvedType.PARAM(0))
                                         });
    
    public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
    
    public x10.rtt.Type<?> $getParam(int i) { if (i == 0) return $T; return null; }
    
    private Object writeReplace() throws java.io.ObjectStreamException {
        return new x10.serialization.SerializationProxy(this);
    }
    
    public static <$T> x10.serialization.X10JavaSerializable $_deserialize_body(x10.array.Array_2<$T> $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
        x10.array.Array.$_deserialize_body($_obj, $deserializer);
        $_obj.$T = (x10.rtt.Type) $deserializer.readObject();
        $_obj.numElems_1 = $deserializer.readLong();
        $_obj.numElems_2 = $deserializer.readLong();
        return $_obj;
    }
    
    public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
        x10.array.Array_2 $_obj = new x10.array.Array_2((java.lang.System[]) null, (x10.rtt.Type) null);
        $deserializer.record_reference($_obj);
        return $_deserialize_body($_obj, $deserializer);
    }
    
    public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
        super.$_serialize($serializer);
        $serializer.write(this.$T);
        $serializer.write(this.numElems_1);
        $serializer.write(this.numElems_2);
        
    }
    
    // constructor just for allocation
    public Array_2(final java.lang.System[] $dummy, final x10.rtt.Type $T) {
        super($dummy, $T);
        x10.array.Array_2.$initParams(this, $T);
        
    }
    
    // dispatcher for method abstract public (Z1,Z2)=>U.operator()(a1:Z1, a2:Z2){}:U
    public java.lang.Object $apply(final java.lang.Object a1, final x10.rtt.Type t1, final java.lang.Object a2, final x10.rtt.Type t2) {
        return $apply$G(x10.core.Long.$unbox(a1), x10.core.Long.$unbox(a2));
        
    }
    
    // bridge for method abstract public x10.array.Array[T].operator()=(p:x10.lang.Point{self.rank==this(:x10.array.Array).rank()}, v:T){}:T{self==v}
    public $T $set__1x10$array$Array$$T$G(x10.lang.Point a1, $T a2) {
        return $set__1x10$array$Array_2$$T$G(a1, a2);
    }
    
    private x10.rtt.Type $T;
    
    // initializer of type parameters
    public static void $initParams(final Array_2 $this, final x10.rtt.Type $T) {
        $this.$T = $T;
        
    }
    // synthetic type for parameter mangling
    public static final class __2x10$array$Array_2$$T {}
    // synthetic type for parameter mangling
    public static final class __2$1x10$lang$Long$3x10$lang$Long$3x10$array$Array_2$$T$2 {}
    // synthetic type for parameter mangling
    public static final class __0$1x10$array$Array_2$$T$2 {}
    
    // properties
    
    //#line 25 "x10/array/Array_2.x10"
    /**
         * The number of elements in rank 1 (indexed 0..(numElems_1-1))
         */
    public long numElems_1;
    
    //#line 30 "x10/array/Array_2.x10"
    /**
         * The number of elements in rank 2 (indexed 0..(numElems_2-1)).
         */
    public long numElems_2;
    

    
    
    //#line 36 "x10/array/Array_2.x10"
    /**
     * @return the rank (dimensionality) of the Array
     */
    final public long rank$O() {
        
        //#line 36 "x10/array/Array_2.x10"
        return 2L;
    }
    
    
    //#line 41 "x10/array/Array_2.x10"
    /**
     * Construct a 2-dimensional array with indices [0..m-1][0..n-1] whose elements are zero-initialized.
     */
    // creation method for java code (1-phase java constructor)
    public Array_2(final x10.rtt.Type $T, final long m, final long n) {
        this((java.lang.System[]) null, $T);
        x10$array$Array_2$$init$S(m, n);
    }
    
    // constructor for non-virtual call
    final public x10.array.Array_2<$T> x10$array$Array_2$$init$S(final long m, final long n) {
         {
            
            //#line 198 . "x10/array/Array_2.x10"
            boolean t$99612 = ((m) < (((long)(0L))));
            
            //#line 198 . "x10/array/Array_2.x10"
            if (!(t$99612)) {
                
                //#line 198 . "x10/array/Array_2.x10"
                t$99612 = ((n) < (((long)(0L))));
            }
            
            //#line 198 . "x10/array/Array_2.x10"
            if (t$99612) {
                
                //#line 198 . "x10/array/Array_2.x10"
                x10.array.Array.raiseNegativeArraySizeException();
            }
            
            //#line 199 . "x10/array/Array_2.x10"
            final long t$99614 = ((m) * (((long)(n))));
            
            //#line 42 "x10/array/Array_2.x10"
            /*super.*/x10$array$Array$$init$S(t$99614, ((boolean)(true)));
            
            //#line 43 "x10/array/Array_2.x10"
            this.numElems_1 = m;
            this.numElems_2 = n;
            
        }
        return this;
    }
    
    
    
    //#line 49 "x10/array/Array_2.x10"
    /**
     * Construct a 2-dimensional array with indices [0..m-1][0..n-1] whose elements are initialized to init.
     */
    // creation method for java code (1-phase java constructor)
    public Array_2(final x10.rtt.Type $T, final long m, final long n, final $T init, __2x10$array$Array_2$$T $dummy) {
        this((java.lang.System[]) null, $T);
        x10$array$Array_2$$init$S(m, n, init, (x10.array.Array_2.__2x10$array$Array_2$$T) null);
    }
    
    // constructor for non-virtual call
    final public x10.array.Array_2<$T> x10$array$Array_2$$init$S(final long m, final long n, final $T init, __2x10$array$Array_2$$T $dummy) {
         {
            
            //#line 198 . "x10/array/Array_2.x10"
            boolean t$99618 = ((m) < (((long)(0L))));
            
            //#line 198 . "x10/array/Array_2.x10"
            if (!(t$99618)) {
                
                //#line 198 . "x10/array/Array_2.x10"
                t$99618 = ((n) < (((long)(0L))));
            }
            
            //#line 198 . "x10/array/Array_2.x10"
            if (t$99618) {
                
                //#line 198 . "x10/array/Array_2.x10"
                x10.array.Array.raiseNegativeArraySizeException();
            }
            
            //#line 199 . "x10/array/Array_2.x10"
            final long t$99620 = ((m) * (((long)(n))));
            
            //#line 50 "x10/array/Array_2.x10"
            /*super.*/x10$array$Array$$init$S(t$99620, ((boolean)(false)));
            
            //#line 51 "x10/array/Array_2.x10"
            this.numElems_1 = m;
            this.numElems_2 = n;
            
            
            //#line 52 "x10/array/Array_2.x10"
            final x10.core.Rail t$99499 = ((x10.core.Rail)(this.raw));
            
            //#line 52 "x10/array/Array_2.x10"
            ((x10.core.Rail<$T>)t$99499).fill__0x10$lang$Rail$$T((($T)(init)));
        }
        return this;
    }
    
    
    
    //#line 59 "x10/array/Array_2.x10"
    /**
     * Construct a 2-dimensional array with indices [0..m-1][0..n-1] whose elements are initialized 
     * to the value returned by the init closure for each index.
     */
    // creation method for java code (1-phase java constructor)
    public Array_2(final x10.rtt.Type $T, final long m, final long n, final x10.core.fun.Fun_0_2<x10.core.Long,x10.core.Long,$T> init, __2$1x10$lang$Long$3x10$lang$Long$3x10$array$Array_2$$T$2 $dummy) {
        this((java.lang.System[]) null, $T);
        x10$array$Array_2$$init$S(m, n, init, (x10.array.Array_2.__2$1x10$lang$Long$3x10$lang$Long$3x10$array$Array_2$$T$2) null);
    }
    
    // constructor for non-virtual call
    final public x10.array.Array_2<$T> x10$array$Array_2$$init$S(final long m, final long n, final x10.core.fun.Fun_0_2<x10.core.Long,x10.core.Long,$T> init, __2$1x10$lang$Long$3x10$lang$Long$3x10$array$Array_2$$T$2 $dummy) {
         {
            
            //#line 198 . "x10/array/Array_2.x10"
            boolean t$99645 = ((m) < (((long)(0L))));
            
            //#line 198 . "x10/array/Array_2.x10"
            if (!(t$99645)) {
                
                //#line 198 . "x10/array/Array_2.x10"
                t$99645 = ((n) < (((long)(0L))));
            }
            
            //#line 198 . "x10/array/Array_2.x10"
            if (t$99645) {
                
                //#line 198 . "x10/array/Array_2.x10"
                x10.array.Array.raiseNegativeArraySizeException();
            }
            
            //#line 199 . "x10/array/Array_2.x10"
            final long t$99647 = ((m) * (((long)(n))));
            
            //#line 60 "x10/array/Array_2.x10"
            /*super.*/x10$array$Array$$init$S(t$99647, ((boolean)(false)));
            
            //#line 61 "x10/array/Array_2.x10"
            this.numElems_1 = m;
            this.numElems_2 = n;
            
            
            //#line 62 "x10/array/Array_2.x10"
            final long i$99027max$99649 = ((m) - (((long)(1L))));
            
            //#line 62 "x10/array/Array_2.x10"
            long i$99640 = 0L;
            
            //#line 62 "x10/array/Array_2.x10"
            for (;
                 true;
                 ) {
                
                //#line 62 "x10/array/Array_2.x10"
                final boolean t$99642 = ((i$99640) <= (((long)(i$99027max$99649))));
                
                //#line 62 "x10/array/Array_2.x10"
                if (!(t$99642)) {
                    
                    //#line 62 "x10/array/Array_2.x10"
                    break;
                }
                
                //#line 63 "x10/array/Array_2.x10"
                final long i$99009max$99636 = ((n) - (((long)(1L))));
                
                //#line 63 "x10/array/Array_2.x10"
                long i$99633 = 0L;
                
                //#line 63 "x10/array/Array_2.x10"
                for (;
                     true;
                     ) {
                    
                    //#line 63 "x10/array/Array_2.x10"
                    final boolean t$99635 = ((i$99633) <= (((long)(i$99009max$99636))));
                    
                    //#line 63 "x10/array/Array_2.x10"
                    if (!(t$99635)) {
                        
                        //#line 63 "x10/array/Array_2.x10"
                        break;
                    }
                    
                    //#line 64 "x10/array/Array_2.x10"
                    final x10.core.Rail t$99622 = ((x10.core.Rail)(this.raw));
                    
                    //#line 64 "x10/array/Array_2.x10"
                    final x10.array.Array_2 this$99623 = ((x10.array.Array_2)(this));
                    
                    //#line 140 . "x10/array/Array_2.x10"
                    final long t$99626 = ((x10.array.Array_2<$T>)this$99623).numElems_2;
                    
                    //#line 140 . "x10/array/Array_2.x10"
                    final long t$99627 = ((i$99640) * (((long)(t$99626))));
                    
                    //#line 140 . "x10/array/Array_2.x10"
                    final long t$99628 = ((i$99633) + (((long)(t$99627))));
                    
                    //#line 64 "x10/array/Array_2.x10"
                    final $T t$99629 = (($T)((($T)
                                               ((x10.core.fun.Fun_0_2<x10.core.Long,x10.core.Long,$T>)init).$apply(x10.core.Long.$box(i$99640), x10.rtt.Types.LONG, x10.core.Long.$box(i$99633), x10.rtt.Types.LONG))));
                    
                    //#line 64 "x10/array/Array_2.x10"
                    ((x10.core.Rail<$T>)t$99622).$set__1x10$lang$Rail$$T$G((long)(t$99628), (($T)(t$99629)));
                    
                    //#line 63 "x10/array/Array_2.x10"
                    final long t$99632 = ((i$99633) + (((long)(1L))));
                    
                    //#line 63 "x10/array/Array_2.x10"
                    i$99633 = t$99632;
                }
                
                //#line 62 "x10/array/Array_2.x10"
                final long t$99639 = ((i$99640) + (((long)(1L))));
                
                //#line 62 "x10/array/Array_2.x10"
                i$99640 = t$99639;
            }
        }
        return this;
    }
    
    
    
    //#line 73 "x10/array/Array_2.x10"
    /**
     * Construct a new 2-dimensional array by copying all elements of src
     * @param src The source array to copy
     */
    // creation method for java code (1-phase java constructor)
    public Array_2(final x10.rtt.Type $T, final x10.array.Array_2<$T> src, __0$1x10$array$Array_2$$T$2 $dummy) {
        this((java.lang.System[]) null, $T);
        x10$array$Array_2$$init$S(src, (x10.array.Array_2.__0$1x10$array$Array_2$$T$2) null);
    }
    
    // constructor for non-virtual call
    final public x10.array.Array_2<$T> x10$array$Array_2$$init$S(final x10.array.Array_2<$T> src, __0$1x10$array$Array_2$$T$2 $dummy) {
         {
            
            //#line 74 "x10/array/Array_2.x10"
            final x10.array.Array this$99100 = ((x10.array.Array)(this));
            
            //#line 74 "x10/array/Array_2.x10"
            final x10.core.Rail t$99518 = ((x10.core.Rail)(((x10.array.Array<$T>)src).raw));
            
            //#line 74 "x10/array/Array_2.x10"
            final x10.core.Rail r$99099 = ((x10.core.Rail)(new x10.core.Rail<$T>($T, ((x10.core.Rail)(t$99518)), (x10.core.Rail.__0$1x10$lang$Rail$$T$2) null)));
            
            //#line 65 . "x10/array/Array.x10"
            final long t$99650 = ((x10.core.Rail<$T>)r$99099).size;
            
            //#line 65 . "x10/array/Array.x10"
            ((x10.array.Array<$T>)this$99100).size = t$99650;
            
            //#line 66 . "x10/array/Array.x10"
            ((x10.array.Array<$T>)this$99100).raw = ((x10.core.Rail)(r$99099));
            
            //#line 75 "x10/array/Array_2.x10"
            final long t$99651 = ((x10.array.Array_2<$T>)src).numElems_1;
            
            //#line 75 "x10/array/Array_2.x10"
            final long t$99652 = ((x10.array.Array_2<$T>)src).numElems_2;
            
            //#line 75 "x10/array/Array_2.x10"
            this.numElems_1 = t$99651;
            this.numElems_2 = t$99652;
            
        }
        return this;
    }
    
    
    
    //#line 79 "x10/array/Array_2.x10"
    // creation method for java code (1-phase java constructor)
    public Array_2(final x10.rtt.Type $T, final x10.core.Rail<$T> r, final long m, final long n, __0$1x10$array$Array_2$$T$2 $dummy) {
        this((java.lang.System[]) null, $T);
        x10$array$Array_2$$init$S(r, m, n, (x10.array.Array_2.__0$1x10$array$Array_2$$T$2) null);
    }
    
    // constructor for non-virtual call
    final public x10.array.Array_2<$T> x10$array$Array_2$$init$S(final x10.core.Rail<$T> r, final long m, final long n, __0$1x10$array$Array_2$$T$2 $dummy) {
         {
            
            //#line 80 "x10/array/Array_2.x10"
            final x10.array.Array this$99106 = ((x10.array.Array)(this));
            
            //#line 65 . "x10/array/Array.x10"
            final long t$99654 = ((x10.core.Rail<$T>)r).size;
            
            //#line 65 . "x10/array/Array.x10"
            ((x10.array.Array<$T>)this$99106).size = t$99654;
            
            //#line 66 . "x10/array/Array.x10"
            ((x10.array.Array<$T>)this$99106).raw = ((x10.core.Rail)(r));
            
            //#line 81 "x10/array/Array_2.x10"
            this.numElems_1 = m;
            this.numElems_2 = n;
            
        }
        return this;
    }
    
    
    
    //#line 87 "x10/array/Array_2.x10"
    /**
     * Construct an Array_2 view over an existing Rail
     */
    public static <$T>x10.array.Array_2 makeView__0$1x10$array$Array_2$$T$2(final x10.rtt.Type $T, final x10.core.Rail<$T> r, final long m, final long n) {
        
        //#line 88 "x10/array/Array_2.x10"
        final long size = ((m) * (((long)(n))));
        
        //#line 89 "x10/array/Array_2.x10"
        final long t$99523 = ((x10.core.Rail<$T>)r).size;
        
        //#line 89 "x10/array/Array_2.x10"
        final boolean t$99531 = ((long) size) != ((long) t$99523);
        
        //#line 89 "x10/array/Array_2.x10"
        if (t$99531) {
            
            //#line 89 "x10/array/Array_2.x10"
            final java.lang.String t$99524 = (("size mismatch: ") + ((x10.core.Long.$box(m))));
            
            //#line 89 "x10/array/Array_2.x10"
            final java.lang.String t$99525 = ((t$99524) + (" * "));
            
            //#line 89 "x10/array/Array_2.x10"
            final java.lang.String t$99526 = ((t$99525) + ((x10.core.Long.$box(n))));
            
            //#line 89 "x10/array/Array_2.x10"
            final java.lang.String t$99527 = ((t$99526) + (" != "));
            
            //#line 89 "x10/array/Array_2.x10"
            final long t$99528 = ((x10.core.Rail<$T>)r).size;
            
            //#line 89 "x10/array/Array_2.x10"
            final java.lang.String t$99529 = ((t$99527) + ((x10.core.Long.$box(t$99528))));
            
            //#line 89 "x10/array/Array_2.x10"
            final x10.lang.IllegalOperationException t$99530 = ((x10.lang.IllegalOperationException)(new x10.lang.IllegalOperationException(t$99529)));
            
            //#line 89 "x10/array/Array_2.x10"
            throw t$99530;
        }
        
        //#line 90 "x10/array/Array_2.x10"
        final x10.array.Array_2 alloc$99006 = ((x10.array.Array_2)(new x10.array.Array_2<$T>((java.lang.System[]) null, $T)));
        
        //#line 90 "x10/array/Array_2.x10"
        alloc$99006.x10$array$Array_2$$init$S(((x10.core.Rail)(r)), ((long)(m)), ((long)(n)), (x10.array.Array_2.__0$1x10$array$Array_2$$T$2) null);
        
        //#line 90 "x10/array/Array_2.x10"
        return alloc$99006;
    }
    
    
    //#line 99 "x10/array/Array_2.x10"
    /**
     * Return the string representation of this array.
     * 
     * @return the string representation of this array.
     */
    public java.lang.String toString() {
        
        //#line 100 "x10/array/Array_2.x10"
        final java.lang.String t$99532 = this.toString((long)(10L));
        
        //#line 100 "x10/array/Array_2.x10"
        return t$99532;
    }
    
    
    //#line 109 "x10/array/Array_2.x10"
    /**
     * Return the string representation of this array.
     *
     * @param limit maximum number of elements to print
     * @return the string representation of this array.
     */
    public java.lang.String toString(final long limit) {
        
        //#line 110 "x10/array/Array_2.x10"
        final x10.util.StringBuilder sb = ((x10.util.StringBuilder)(new x10.util.StringBuilder((java.lang.System[]) null)));
        
        //#line 110 "x10/array/Array_2.x10"
        sb.x10$util$StringBuilder$$init$S();
        
        //#line 111 "x10/array/Array_2.x10"
        sb.add(((java.lang.String)("[")));
        
        //#line 112 "x10/array/Array_2.x10"
        long printed = 0L;
        
        //#line 113 "x10/array/Array_2.x10"
        final long t$99692 = this.numElems_1;
        
        //#line 113 "x10/array/Array_2.x10"
        final long i$99063max$99693 = ((t$99692) - (((long)(1L))));
        
        //#line 113 "x10/array/Array_2.x10"
        long i$99688 = 0L;
        
        //#line 113 "x10/array/Array_2.x10"
        outer$99689: 
        //#line 113 "x10/array/Array_2.x10"
        for (;
             true;
             ) {
            
            //#line 113 "x10/array/Array_2.x10"
            final boolean t$99691 = ((i$99688) <= (((long)(i$99063max$99693))));
            
            //#line 113 "x10/array/Array_2.x10"
            if (!(t$99691)) {
                
                //#line 113 "x10/array/Array_2.x10"
                break;
            }
            
            //#line 114 "x10/array/Array_2.x10"
            final long t$99683 = this.numElems_2;
            
            //#line 114 "x10/array/Array_2.x10"
            final long i$99045max$99684 = ((t$99683) - (((long)(1L))));
            
            //#line 114 "x10/array/Array_2.x10"
            long i$99680 = 0L;
            
            //#line 114 "x10/array/Array_2.x10"
            for (;
                 true;
                 ) {
                
                //#line 114 "x10/array/Array_2.x10"
                final boolean t$99682 = ((i$99680) <= (((long)(i$99045max$99684))));
                
                //#line 114 "x10/array/Array_2.x10"
                if (!(t$99682)) {
                    
                    //#line 114 "x10/array/Array_2.x10"
                    break;
                }
                
                //#line 115 "x10/array/Array_2.x10"
                final boolean t$99656 = ((long) i$99680) != ((long) 0L);
                
                //#line 115 "x10/array/Array_2.x10"
                if (t$99656) {
                    
                    //#line 115 "x10/array/Array_2.x10"
                    sb.add(((java.lang.String)(", ")));
                }
                
                //#line 116 "x10/array/Array_2.x10"
                final x10.array.Array_2 this$99657 = ((x10.array.Array_2)(this));
                
                //#line 152 . "x10/array/Array_2.x10"
                boolean t$99660 = ((i$99688) < (((long)(0L))));
                
                //#line 152 . "x10/array/Array_2.x10"
                if (!(t$99660)) {
                    
                    //#line 152 . "x10/array/Array_2.x10"
                    final long t$99661 = ((x10.array.Array_2<$T>)this$99657).numElems_1;
                    
                    //#line 152 . "x10/array/Array_2.x10"
                    t$99660 = ((i$99688) >= (((long)(t$99661))));
                }
                
                //#line 152 . "x10/array/Array_2.x10"
                boolean t$99662 = t$99660;
                
                //#line 152 . "x10/array/Array_2.x10"
                if (!(t$99660)) {
                    
                    //#line 152 . "x10/array/Array_2.x10"
                    t$99662 = ((i$99680) < (((long)(0L))));
                }
                
                //#line 152 . "x10/array/Array_2.x10"
                boolean t$99663 = t$99662;
                
                //#line 152 . "x10/array/Array_2.x10"
                if (!(t$99662)) {
                    
                    //#line 153 . "x10/array/Array_2.x10"
                    final long t$99664 = ((x10.array.Array_2<$T>)this$99657).numElems_2;
                    
                    //#line 152 . "x10/array/Array_2.x10"
                    t$99663 = ((i$99680) >= (((long)(t$99664))));
                }
                
                //#line 152 . "x10/array/Array_2.x10"
                if (t$99663) {
                    
                    //#line 154 . "x10/array/Array_2.x10"
                    x10.array.Array.raiseBoundsError((long)(i$99688), (long)(i$99680));
                }
                
                //#line 156 . "x10/array/Array_2.x10"
                final x10.core.Rail r$99666 = ((x10.core.Rail)(((x10.array.Array<$T>)this$99657).raw));
                
                //#line 140 .. "x10/array/Array_2.x10"
                final long t$99669 = ((x10.array.Array_2<$T>)this$99657).numElems_2;
                
                //#line 140 .. "x10/array/Array_2.x10"
                final long t$99670 = ((i$99688) * (((long)(t$99669))));
                
                //#line 156 . "x10/array/Array_2.x10"
                final long i$99671 = ((i$99680) + (((long)(t$99670))));
                
                //#line 38 .. "x10/lang/Unsafe.x10"
                final $T t$99672 = (($T)(((x10.core.Rail<$T>)r$99666).$apply$G((long)(i$99671))));
                
                //#line 116 "x10/array/Array_2.x10"
                sb.add(((java.lang.Object)(t$99672)));
                
                //#line 117 "x10/array/Array_2.x10"
                final long t$99674 = ((printed) + (((long)(1L))));
                
                //#line 117 "x10/array/Array_2.x10"
                final long t$99675 = printed = t$99674;
                
                //#line 117 "x10/array/Array_2.x10"
                final boolean t$99676 = ((t$99675) > (((long)(limit))));
                
                //#line 117 "x10/array/Array_2.x10"
                if (t$99676) {
                    
                    //#line 117 "x10/array/Array_2.x10"
                    break outer$99689;
                }
                
                //#line 114 "x10/array/Array_2.x10"
                final long t$99679 = ((i$99680) + (((long)(1L))));
                
                //#line 114 "x10/array/Array_2.x10"
                i$99680 = t$99679;
            }
            
            //#line 119 "x10/array/Array_2.x10"
            sb.add(((java.lang.String)("; ")));
            
            //#line 113 "x10/array/Array_2.x10"
            final long t$99687 = ((i$99688) + (((long)(1L))));
            
            //#line 113 "x10/array/Array_2.x10"
            i$99688 = t$99687;
        }
        
        //#line 121 "x10/array/Array_2.x10"
        final long t$99559 = this.size;
        
        //#line 121 "x10/array/Array_2.x10"
        final boolean t$99564 = ((limit) < (((long)(t$99559))));
        
        //#line 121 "x10/array/Array_2.x10"
        if (t$99564) {
            
            //#line 122 "x10/array/Array_2.x10"
            final long t$99560 = this.size;
            
            //#line 122 "x10/array/Array_2.x10"
            final long t$99561 = ((t$99560) - (((long)(limit))));
            
            //#line 122 "x10/array/Array_2.x10"
            final java.lang.String t$99562 = (("...(omitted ") + ((x10.core.Long.$box(t$99561))));
            
            //#line 122 "x10/array/Array_2.x10"
            final java.lang.String t$99563 = ((t$99562) + (" elements)"));
            
            //#line 122 "x10/array/Array_2.x10"
            sb.add(((java.lang.String)(t$99563)));
        }
        
        //#line 124 "x10/array/Array_2.x10"
        sb.add(((java.lang.String)("]")));
        
        //#line 125 "x10/array/Array_2.x10"
        final java.lang.String t$99565 = sb.toString();
        
        //#line 125 "x10/array/Array_2.x10"
        return t$99565;
    }
    
    
    //#line 131 "x10/array/Array_2.x10"
    /**
     * @return an IterationSpace containing all valid Points for indexing this Array.
     */
    public x10.array.DenseIterationSpace_2 indices() {
        
        //#line 132 "x10/array/Array_2.x10"
        final x10.array.DenseIterationSpace_2 alloc$99007 = ((x10.array.DenseIterationSpace_2)(new x10.array.DenseIterationSpace_2((java.lang.System[]) null)));
        
        //#line 132 "x10/array/Array_2.x10"
        final long t$99694 = this.numElems_1;
        
        //#line 132 "x10/array/Array_2.x10"
        final long t$99695 = ((t$99694) - (((long)(1L))));
        
        //#line 132 "x10/array/Array_2.x10"
        final long t$99696 = this.numElems_2;
        
        //#line 132 "x10/array/Array_2.x10"
        final long t$99697 = ((t$99696) - (((long)(1L))));
        
        //#line 132 "x10/array/Array_2.x10"
        alloc$99007.x10$array$DenseIterationSpace_2$$init$S(((long)(0L)), ((long)(0L)), t$99695, t$99697);
        
        //#line 132 "x10/array/Array_2.x10"
        return alloc$99007;
    }
    
    
    //#line 139 "x10/array/Array_2.x10"
    /**
     * Map a 2-D (i,j) index into a 1-D index into the backing Rail
     * returned by raw(). Uses row-major order.
     */
    public long offset$O(final long i, final long j) {
        
        //#line 140 "x10/array/Array_2.x10"
        final long t$99570 = this.numElems_2;
        
        //#line 140 "x10/array/Array_2.x10"
        final long t$99571 = ((i) * (((long)(t$99570))));
        
        //#line 140 "x10/array/Array_2.x10"
        final long t$99572 = ((j) + (((long)(t$99571))));
        
        //#line 140 "x10/array/Array_2.x10"
        return t$99572;
    }
    
    
    //#line 151 "x10/array/Array_2.x10"
    /**
     * Return the element of this array corresponding to the given pair of indices.
     * 
     * @param i the given index in the first dimension
     * @param j the given index in the second dimension
     * @return the element of this array corresponding to the given pair of indices.
     * @see #set(T, Long, Long)
     */
    public $T $apply$G(final long i, final long j) {
        
        //#line 152 "x10/array/Array_2.x10"
        boolean t$99574 = ((i) < (((long)(0L))));
        
        //#line 152 "x10/array/Array_2.x10"
        if (!(t$99574)) {
            
            //#line 152 "x10/array/Array_2.x10"
            final long t$99573 = this.numElems_1;
            
            //#line 152 "x10/array/Array_2.x10"
            t$99574 = ((i) >= (((long)(t$99573))));
        }
        
        //#line 152 "x10/array/Array_2.x10"
        boolean t$99575 = t$99574;
        
        //#line 152 "x10/array/Array_2.x10"
        if (!(t$99574)) {
            
            //#line 152 "x10/array/Array_2.x10"
            t$99575 = ((j) < (((long)(0L))));
        }
        
        //#line 152 "x10/array/Array_2.x10"
        boolean t$99577 = t$99575;
        
        //#line 152 "x10/array/Array_2.x10"
        if (!(t$99575)) {
            
            //#line 153 "x10/array/Array_2.x10"
            final long t$99576 = this.numElems_2;
            
            //#line 152 "x10/array/Array_2.x10"
            t$99577 = ((j) >= (((long)(t$99576))));
        }
        
        //#line 152 "x10/array/Array_2.x10"
        if (t$99577) {
            
            //#line 154 "x10/array/Array_2.x10"
            x10.array.Array.raiseBoundsError((long)(i), (long)(j));
        }
        
        //#line 156 "x10/array/Array_2.x10"
        final x10.core.Rail r$99460 = ((x10.core.Rail)(this.raw));
        
        //#line 156 "x10/array/Array_2.x10"
        final x10.array.Array_2 this$99458 = ((x10.array.Array_2)(this));
        
        //#line 140 . "x10/array/Array_2.x10"
        final long t$99579 = ((x10.array.Array_2<$T>)this$99458).numElems_2;
        
        //#line 140 . "x10/array/Array_2.x10"
        final long t$99580 = ((i) * (((long)(t$99579))));
        
        //#line 156 "x10/array/Array_2.x10"
        final long i$99461 = ((j) + (((long)(t$99580))));
        
        //#line 38 . "x10/lang/Unsafe.x10"
        final $T t$99581 = (($T)(((x10.core.Rail<$T>)r$99460).$apply$G((long)(i$99461))));
        
        //#line 156 "x10/array/Array_2.x10"
        return t$99581;
    }
    
    
    //#line 166 "x10/array/Array_2.x10"
    /**
     * Return the element of this array corresponding to the given Point.
     * 
     * @param p the given Point
     * @return the element of this array corresponding to the given Point.
     * @see #set(T, Point)
     */
    public $T $apply$G(final x10.lang.Point p) {
        
        //#line 166 "x10/array/Array_2.x10"
        final x10.array.Array_2 this$99465 = ((x10.array.Array_2)(this));
        
        //#line 166 "x10/array/Array_2.x10"
        final long i$99463 = p.$apply$O((long)(0L));
        
        //#line 166 "x10/array/Array_2.x10"
        final long j$99464 = p.$apply$O((long)(1L));
        
        //#line 152 . "x10/array/Array_2.x10"
        boolean t$99583 = ((i$99463) < (((long)(0L))));
        
        //#line 152 . "x10/array/Array_2.x10"
        if (!(t$99583)) {
            
            //#line 152 . "x10/array/Array_2.x10"
            final long t$99582 = ((x10.array.Array_2<$T>)this$99465).numElems_1;
            
            //#line 152 . "x10/array/Array_2.x10"
            t$99583 = ((i$99463) >= (((long)(t$99582))));
        }
        
        //#line 152 . "x10/array/Array_2.x10"
        boolean t$99584 = t$99583;
        
        //#line 152 . "x10/array/Array_2.x10"
        if (!(t$99583)) {
            
            //#line 152 . "x10/array/Array_2.x10"
            t$99584 = ((j$99464) < (((long)(0L))));
        }
        
        //#line 152 . "x10/array/Array_2.x10"
        boolean t$99586 = t$99584;
        
        //#line 152 . "x10/array/Array_2.x10"
        if (!(t$99584)) {
            
            //#line 153 . "x10/array/Array_2.x10"
            final long t$99585 = ((x10.array.Array_2<$T>)this$99465).numElems_2;
            
            //#line 152 . "x10/array/Array_2.x10"
            t$99586 = ((j$99464) >= (((long)(t$99585))));
        }
        
        //#line 152 . "x10/array/Array_2.x10"
        if (t$99586) {
            
            //#line 154 . "x10/array/Array_2.x10"
            x10.array.Array.raiseBoundsError((long)(i$99463), (long)(j$99464));
        }
        
        //#line 156 . "x10/array/Array_2.x10"
        final x10.core.Rail r$99470 = ((x10.core.Rail)(((x10.array.Array<$T>)this$99465).raw));
        
        //#line 140 .. "x10/array/Array_2.x10"
        final long t$99588 = ((x10.array.Array_2<$T>)this$99465).numElems_2;
        
        //#line 140 .. "x10/array/Array_2.x10"
        final long t$99589 = ((i$99463) * (((long)(t$99588))));
        
        //#line 156 . "x10/array/Array_2.x10"
        final long i$99471 = ((j$99464) + (((long)(t$99589))));
        
        //#line 38 .. "x10/lang/Unsafe.x10"
        final $T t$99590 = (($T)(((x10.core.Rail<$T>)r$99470).$apply$G((long)(i$99471))));
        
        //#line 166 "x10/array/Array_2.x10"
        return t$99590;
    }
    
    
    //#line 178 "x10/array/Array_2.x10"
    /**
     * Set the element of this array corresponding to the given pair of indices to the given value.
     * Return the new value of the element.
     * 
     * @param v the given value
     * @param i the given index in the first dimension
     * @param j the given index in the second dimension
     * @return the new value of the element of this array corresponding to the given pair of indices.
     * @see #operator(Long, Long)
     */
    public $T $set__2x10$array$Array_2$$T$G(final long i, final long j, final $T v) {
        
        //#line 179 "x10/array/Array_2.x10"
        boolean t$99592 = ((i) < (((long)(0L))));
        
        //#line 179 "x10/array/Array_2.x10"
        if (!(t$99592)) {
            
            //#line 179 "x10/array/Array_2.x10"
            final long t$99591 = this.numElems_1;
            
            //#line 179 "x10/array/Array_2.x10"
            t$99592 = ((i) >= (((long)(t$99591))));
        }
        
        //#line 179 "x10/array/Array_2.x10"
        boolean t$99593 = t$99592;
        
        //#line 179 "x10/array/Array_2.x10"
        if (!(t$99592)) {
            
            //#line 179 "x10/array/Array_2.x10"
            t$99593 = ((j) < (((long)(0L))));
        }
        
        //#line 179 "x10/array/Array_2.x10"
        boolean t$99595 = t$99593;
        
        //#line 179 "x10/array/Array_2.x10"
        if (!(t$99593)) {
            
            //#line 180 "x10/array/Array_2.x10"
            final long t$99594 = this.numElems_2;
            
            //#line 179 "x10/array/Array_2.x10"
            t$99595 = ((j) >= (((long)(t$99594))));
        }
        
        //#line 179 "x10/array/Array_2.x10"
        if (t$99595) {
            
            //#line 181 "x10/array/Array_2.x10"
            x10.array.Array.raiseBoundsError((long)(i), (long)(j));
        }
        
        //#line 183 "x10/array/Array_2.x10"
        final x10.core.Rail r$99477 = ((x10.core.Rail)(this.raw));
        
        //#line 183 "x10/array/Array_2.x10"
        final x10.array.Array_2 this$99475 = ((x10.array.Array_2)(this));
        
        //#line 140 . "x10/array/Array_2.x10"
        final long t$99597 = ((x10.array.Array_2<$T>)this$99475).numElems_2;
        
        //#line 140 . "x10/array/Array_2.x10"
        final long t$99598 = ((i) * (((long)(t$99597))));
        
        //#line 183 "x10/array/Array_2.x10"
        final long i$99478 = ((j) + (((long)(t$99598))));
        
        //#line 42 . "x10/lang/Unsafe.x10"
        ((x10.core.Rail<$T>)r$99477).$set__1x10$lang$Rail$$T$G((long)(i$99478), (($T)(v)));
        
        //#line 183 "x10/array/Array_2.x10"
        return (($T)
                 v);
    }
    
    
    //#line 195 "x10/array/Array_2.x10"
    /**
     * Set the element of this array corresponding to the given Point to the given value.
     * Return the new value of the element.
     * 
     * @param v the given value
     * @param p the given Point
     * @return the new value of the element of this array corresponding to the given Point.
     * @see #operator(Point)
     */
    public $T $set__1x10$array$Array_2$$T$G(final x10.lang.Point p, final $T v) {
        
        //#line 195 "x10/array/Array_2.x10"
        final x10.array.Array_2 this$99484 = ((x10.array.Array_2)(this));
        
        //#line 195 "x10/array/Array_2.x10"
        final long i$99481 = p.$apply$O((long)(0L));
        
        //#line 195 "x10/array/Array_2.x10"
        final long j$99482 = p.$apply$O((long)(1L));
        
        //#line 179 . "x10/array/Array_2.x10"
        boolean t$99600 = ((i$99481) < (((long)(0L))));
        
        //#line 179 . "x10/array/Array_2.x10"
        if (!(t$99600)) {
            
            //#line 179 . "x10/array/Array_2.x10"
            final long t$99599 = ((x10.array.Array_2<$T>)this$99484).numElems_1;
            
            //#line 179 . "x10/array/Array_2.x10"
            t$99600 = ((i$99481) >= (((long)(t$99599))));
        }
        
        //#line 179 . "x10/array/Array_2.x10"
        boolean t$99601 = t$99600;
        
        //#line 179 . "x10/array/Array_2.x10"
        if (!(t$99600)) {
            
            //#line 179 . "x10/array/Array_2.x10"
            t$99601 = ((j$99482) < (((long)(0L))));
        }
        
        //#line 179 . "x10/array/Array_2.x10"
        boolean t$99603 = t$99601;
        
        //#line 179 . "x10/array/Array_2.x10"
        if (!(t$99601)) {
            
            //#line 180 . "x10/array/Array_2.x10"
            final long t$99602 = ((x10.array.Array_2<$T>)this$99484).numElems_2;
            
            //#line 179 . "x10/array/Array_2.x10"
            t$99603 = ((j$99482) >= (((long)(t$99602))));
        }
        
        //#line 179 . "x10/array/Array_2.x10"
        if (t$99603) {
            
            //#line 181 . "x10/array/Array_2.x10"
            x10.array.Array.raiseBoundsError((long)(i$99481), (long)(j$99482));
        }
        
        //#line 183 . "x10/array/Array_2.x10"
        final x10.core.Rail r$99489 = ((x10.core.Rail)(((x10.array.Array<$T>)this$99484).raw));
        
        //#line 140 .. "x10/array/Array_2.x10"
        final long t$99605 = ((x10.array.Array_2<$T>)this$99484).numElems_2;
        
        //#line 140 .. "x10/array/Array_2.x10"
        final long t$99606 = ((i$99481) * (((long)(t$99605))));
        
        //#line 183 . "x10/array/Array_2.x10"
        final long i$99490 = ((j$99482) + (((long)(t$99606))));
        
        //#line 42 .. "x10/lang/Unsafe.x10"
        ((x10.core.Rail<$T>)r$99489).$set__1x10$lang$Rail$$T$G((long)(i$99490), (($T)(v)));
        
        //#line 195 "x10/array/Array_2.x10"
        return (($T)
                 v);
    }
    
    
    //#line 197 "x10/array/Array_2.x10"
    private static long validateSize$O(final long m, final long n) {
        
        //#line 198 "x10/array/Array_2.x10"
        boolean t$99607 = ((m) < (((long)(0L))));
        
        //#line 198 "x10/array/Array_2.x10"
        if (!(t$99607)) {
            
            //#line 198 "x10/array/Array_2.x10"
            t$99607 = ((n) < (((long)(0L))));
        }
        
        //#line 198 "x10/array/Array_2.x10"
        if (t$99607) {
            
            //#line 198 "x10/array/Array_2.x10"
            x10.array.Array.raiseNegativeArraySizeException();
        }
        
        //#line 199 "x10/array/Array_2.x10"
        final long t$99609 = ((m) * (((long)(n))));
        
        //#line 199 "x10/array/Array_2.x10"
        return t$99609;
    }
    
    public static long validateSize$P$O(final long m, final long n) {
        return x10.array.Array_2.validateSize$O((long)(m), (long)(n));
    }
    
    
    //#line 21 "x10/array/Array_2.x10"
    final public x10.array.Array_2 x10$array$Array_2$$this$x10$array$Array_2() {
        
        //#line 21 "x10/array/Array_2.x10"
        return x10.array.Array_2.this;
    }
    
    
    //#line 21 "x10/array/Array_2.x10"
    final public void __fieldInitializers_x10_array_Array_2() {
        
    }
}

