package x10.array;


/**
 * Represents the distribution of the Points of an IterationSpace(3) 
 * over the Places in its PlaceGroup by block-block distributing the
 * first two dimensions of the IterationSpace.
 */
@x10.runtime.impl.java.X10Generated
public class Dist_BlockBlock_3 extends x10.array.Dist implements x10.serialization.X10JavaSerializable
{
    public static final x10.rtt.RuntimeType<Dist_BlockBlock_3> $RTT = 
        x10.rtt.NamedType.<Dist_BlockBlock_3> make("x10.array.Dist_BlockBlock_3",
                                                   Dist_BlockBlock_3.class,
                                                   new x10.rtt.Type[] {
                                                       x10.array.Dist.$RTT
                                                   });
    
    public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
    
    public x10.rtt.Type<?> $getParam(int i) { return null; }
    
    private Object writeReplace() throws java.io.ObjectStreamException {
        return new x10.serialization.SerializationProxy(this);
    }
    
    public static x10.serialization.X10JavaSerializable $_deserialize_body(x10.array.Dist_BlockBlock_3 $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
        x10.array.Dist.$_deserialize_body($_obj, $deserializer);
        $_obj.globalIndices = $deserializer.readObject();
        
        /* fields with @TransientInitExpr annotations */
        $_obj.localIndices = $_obj.computeLocalIndices();
        
        return $_obj;
    }
    
    public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
        x10.array.Dist_BlockBlock_3 $_obj = new x10.array.Dist_BlockBlock_3((java.lang.System[]) null);
        $deserializer.record_reference($_obj);
        return $_deserialize_body($_obj, $deserializer);
    }
    
    public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
        super.$_serialize($serializer);
        $serializer.write(this.globalIndices);
        
    }
    
    // constructor just for allocation
    public Dist_BlockBlock_3(final java.lang.System[] $dummy) {
        super($dummy);
        
    }
    
    

    
    //#line 23 "x10/array/Dist_BlockBlock_3.x10"
    public x10.array.DenseIterationSpace_3 globalIndices;
    
    //#line 26 "x10/array/Dist_BlockBlock_3.x10"
    public transient x10.array.DenseIterationSpace_3 localIndices;
    
    
    //#line 27 "x10/array/Dist_BlockBlock_3.x10"
    final public x10.array.DenseIterationSpace_3 computeLocalIndices() {
        
        //#line 28 "x10/array/Dist_BlockBlock_3.x10"
        final x10.array.DenseIterationSpace_3 t$110289 = ((x10.array.DenseIterationSpace_3)(this.globalIndices));
        
        //#line 28 "x10/array/Dist_BlockBlock_3.x10"
        final long t$110295 = t$110289.min$O((long)(0L));
        
        //#line 28 "x10/array/Dist_BlockBlock_3.x10"
        final x10.array.DenseIterationSpace_3 t$110290 = ((x10.array.DenseIterationSpace_3)(this.globalIndices));
        
        //#line 28 "x10/array/Dist_BlockBlock_3.x10"
        final long t$110296 = t$110290.min$O((long)(1L));
        
        //#line 29 "x10/array/Dist_BlockBlock_3.x10"
        final x10.array.DenseIterationSpace_3 t$110291 = ((x10.array.DenseIterationSpace_3)(this.globalIndices));
        
        //#line 29 "x10/array/Dist_BlockBlock_3.x10"
        final long t$110297 = t$110291.max$O((long)(0L));
        
        //#line 29 "x10/array/Dist_BlockBlock_3.x10"
        final x10.array.DenseIterationSpace_3 t$110292 = ((x10.array.DenseIterationSpace_3)(this.globalIndices));
        
        //#line 29 "x10/array/Dist_BlockBlock_3.x10"
        final long t$110298 = t$110292.max$O((long)(1L));
        
        //#line 30 "x10/array/Dist_BlockBlock_3.x10"
        final x10.lang.PlaceGroup t$110293 = ((x10.lang.PlaceGroup)(this.pg));
        
        //#line 30 "x10/array/Dist_BlockBlock_3.x10"
        final long t$110299 = t$110293.numPlaces$O();
        
        //#line 30 "x10/array/Dist_BlockBlock_3.x10"
        final x10.lang.PlaceGroup t$110294 = ((x10.lang.PlaceGroup)(this.pg));
        
        //#line 30 "x10/array/Dist_BlockBlock_3.x10"
        final long t$110300 = t$110294.indexOf$O(((x10.lang.Place)(x10.x10rt.X10RT.here())));
        
        //#line 28 "x10/array/Dist_BlockBlock_3.x10"
        final x10.array.DenseIterationSpace_2 local_m = ((x10.array.DenseIterationSpace_2)(x10.array.BlockingUtils.partitionBlockBlock((long)(t$110295), (long)(t$110296), (long)(t$110297), (long)(t$110298), (long)(t$110299), (long)(t$110300))));
        
        //#line 31 "x10/array/Dist_BlockBlock_3.x10"
        final x10.array.DenseIterationSpace_3 alloc$107535 = ((x10.array.DenseIterationSpace_3)(new x10.array.DenseIterationSpace_3((java.lang.System[]) null)));
        
        //#line 31 "x10/array/Dist_BlockBlock_3.x10"
        final long t$110310 = local_m.min$O((long)(0L));
        
        //#line 31 "x10/array/Dist_BlockBlock_3.x10"
        final long t$110311 = local_m.min$O((long)(1L));
        
        //#line 31 "x10/array/Dist_BlockBlock_3.x10"
        final x10.array.DenseIterationSpace_3 t$110312 = ((x10.array.DenseIterationSpace_3)(this.globalIndices));
        
        //#line 31 "x10/array/Dist_BlockBlock_3.x10"
        final long t$110313 = t$110312.min$O((long)(2L));
        
        //#line 32 "x10/array/Dist_BlockBlock_3.x10"
        final long t$110314 = local_m.max$O((long)(0L));
        
        //#line 32 "x10/array/Dist_BlockBlock_3.x10"
        final long t$110315 = local_m.max$O((long)(1L));
        
        //#line 32 "x10/array/Dist_BlockBlock_3.x10"
        final x10.array.DenseIterationSpace_3 t$110316 = ((x10.array.DenseIterationSpace_3)(this.globalIndices));
        
        //#line 32 "x10/array/Dist_BlockBlock_3.x10"
        final long t$110317 = t$110316.max$O((long)(2L));
        
        //#line 31 "x10/array/Dist_BlockBlock_3.x10"
        alloc$107535.x10$array$DenseIterationSpace_3$$init$S(t$110310, t$110311, t$110313, t$110314, t$110315, t$110317);
        
        //#line 31 "x10/array/Dist_BlockBlock_3.x10"
        return alloc$107535;
    }
    
    
    //#line 35 "x10/array/Dist_BlockBlock_3.x10"
    // creation method for java code (1-phase java constructor)
    public Dist_BlockBlock_3(final x10.lang.PlaceGroup pg, final x10.array.DenseIterationSpace_3 is) {
        this((java.lang.System[]) null);
        x10$array$Dist_BlockBlock_3$$init$S(pg, is);
    }
    
    // constructor for non-virtual call
    final public x10.array.Dist_BlockBlock_3 x10$array$Dist_BlockBlock_3$$init$S(final x10.lang.PlaceGroup pg, final x10.array.DenseIterationSpace_3 is) {
         {
            
            //#line 36 "x10/array/Dist_BlockBlock_3.x10"
            final x10.array.Dist this$110284 = ((x10.array.Dist)(this));
            
            //#line 36 "x10/array/Dist_BlockBlock_3.x10"
            final x10.array.IterationSpace is$110283 = ((x10.array.IterationSpace)(((x10.array.IterationSpace)
                                                                                     is)));
            
            //#line 26 . "x10/array/Dist.x10"
            this$110284.pg = ((x10.lang.PlaceGroup)(pg));
            
            //#line 26 . "x10/array/Dist.x10"
            this$110284.is = ((x10.array.IterationSpace)(is$110283));
            
            //#line 35 "x10/array/Dist_BlockBlock_3.x10"
            
            
            //#line 37 "x10/array/Dist_BlockBlock_3.x10"
            this.globalIndices = ((x10.array.DenseIterationSpace_3)(is));
            
            //#line 38 "x10/array/Dist_BlockBlock_3.x10"
            final x10.array.DenseIterationSpace_3 t$110309 = ((x10.array.DenseIterationSpace_3)(this.computeLocalIndices()));
            
            //#line 38 "x10/array/Dist_BlockBlock_3.x10"
            this.localIndices = ((x10.array.DenseIterationSpace_3)(t$110309));
        }
        return this;
    }
    
    
    
    //#line 22 "x10/array/Dist_BlockBlock_3.x10"
    final public x10.array.Dist_BlockBlock_3 x10$array$Dist_BlockBlock_3$$this$x10$array$Dist_BlockBlock_3() {
        
        //#line 22 "x10/array/Dist_BlockBlock_3.x10"
        return x10.array.Dist_BlockBlock_3.this;
    }
    
    
    //#line 22 "x10/array/Dist_BlockBlock_3.x10"
    final public void __fieldInitializers_x10_array_Dist_BlockBlock_3() {
        
    }
}

