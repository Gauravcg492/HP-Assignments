package x10.array;


/**
 * <p> This class hierarchy provides high-performance implementations of
 * distributed multi-dimensional Arrays that map long indices to values. 
 * This array implementation only supports zero-based, dense indexing.
 * For example, a two dimensional array of N by M elements is indexed by 
 * (0..N-1,0..M-1).  Different subclasses of this class implement different
 * algorithms for distibuting the elements of the DistArray across the 
 * Places of the X10 computation.</p>
 * 
 * <p> Related classes in this package {@link Array} provide a similar
 * simple array abstraction whose data is contained in a sinple Place.</p>
 * 
 * <p>A more general, but lower performance, distributed array abstraction is
 *  provided by {@link x10.regionarray.DistArray} which supports more 
 * general indexing operations via user-extensible 
 * {@link x10.regionarray.Region}s and {@link x10.regionarray.Dist}s. 
 * See the package documentation of {@link x10.regionarray} for more details.</p>
 */
@x10.runtime.impl.java.X10Generated
abstract public class DistArray<$T> extends x10.core.Ref implements x10.lang.Iterable, x10.serialization.X10JavaSerializable
{
    public static final x10.rtt.RuntimeType<DistArray> $RTT = 
        x10.rtt.NamedType.<DistArray> make("x10.array.DistArray",
                                           DistArray.class,
                                           1,
                                           new x10.rtt.Type[] {
                                               x10.rtt.ParameterizedType.make(x10.lang.Iterable.$RTT, x10.lang.Point.$RTT)
                                           });
    
    public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
    
    public x10.rtt.Type<?> $getParam(int i) { if (i == 0) return $T; return null; }
    
    public static <$T> x10.serialization.X10JavaSerializable $_deserialize_body(x10.array.DistArray<$T> $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
        $_obj.$T = (x10.rtt.Type) $deserializer.readObject();
        $_obj.localHandle = $deserializer.readObject();
        $_obj.placeGroup = $deserializer.readObject();
        $_obj.size = $deserializer.readLong();
        
        /* fields with @TransientInitExpr annotations */
        $_obj.raw = $_obj.getRailFromLocalHandle();
        
        return $_obj;
    }
    
    public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
        return null;
    }
    
    public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
        $serializer.write(this.$T);
        $serializer.write(this.localHandle);
        $serializer.write(this.placeGroup);
        $serializer.write(this.size);
        
    }
    
    // constructor just for allocation
    public DistArray(final java.lang.System[] $dummy, final x10.rtt.Type $T) {
        x10.array.DistArray.$initParams(this, $T);
        
    }
    
    private x10.rtt.Type $T;
    
    // initializer of type parameters
    public static void $initParams(final DistArray $this, final x10.rtt.Type $T) {
        $this.$T = $T;
        
    }
    // synthetic type for parameter mangling
    public static final class __1$1x10$array$LocalState$1x10$array$DistArray$$T$2$2 {}
    
    // properties
    
    //#line 43 "x10/array/DistArray.x10"
    /**
         * The number of data values in the array.
         */
    public long size;
    

    
    
    //#line 49 "x10/array/DistArray.x10"
    /**
     * @return the rank (dimensionality) of the DistArray
     */
    abstract public long rank$O();
    
    
    //#line 54 "x10/array/DistArray.x10"
    /** 
     * The place-local state for the DistArray 
     */
    public x10.lang.PlaceLocalHandle<x10.array.LocalState<$T>> localHandle;
    
    //#line 60 "x10/array/DistArray.x10"
    /**
     * The place-local backing storage for elements of the DistArray.
     */
    public transient x10.core.Rail<$T> raw;
    
    
    //#line 61 "x10/array/DistArray.x10"
    final public x10.core.Rail getRailFromLocalHandle() {
        
        //#line 62 "x10/array/DistArray.x10"
        final x10.lang.PlaceLocalHandle t$105798 = ((x10.lang.PlaceLocalHandle)(this.localHandle));
        
        //#line 62 "x10/array/DistArray.x10"
        final x10.array.LocalState ls = ((x10.lang.PlaceLocalHandle<x10.array.LocalState<$T>>)t$105798).$apply$G();
        
        //#line 63 "x10/array/DistArray.x10"
        final boolean t$105799 = ((ls) != (null));
        
        //#line 63 "x10/array/DistArray.x10"
        x10.core.Rail t$105800 =  null;
        
        //#line 63 "x10/array/DistArray.x10"
        if (t$105799) {
            
            //#line 63 "x10/array/DistArray.x10"
            t$105800 = ((x10.core.Rail)(((x10.array.LocalState<$T>)ls).rail));
        } else {
            
            //#line 63 "x10/array/DistArray.x10"
            t$105800 = ((x10.core.Rail)(new x10.core.Rail<$T>($T)));
        }
        
        //#line 63 "x10/array/DistArray.x10"
        return t$105800;
    }
    
    
    //#line 69 "x10/array/DistArray.x10"
    /**
     * The PlaceGroup over which this DistArray is defined.
     */
    public x10.lang.PlaceGroup placeGroup;
    
    
    //#line 78 "x10/array/DistArray.x10"
    /**
     * Construct the DistArray using the argument PlaceGroup
     * and initialization closure to create the LocalState of
     * the DistArray in every Place in the PlaceGroup.
     * @param pg the PlaceGroup over which the DistArray is defined.
     * @param init the closure to pass to PlaceLocalHandle.make
     */
    
    // constructor for non-virtual call
    final public x10.array.DistArray<$T> x10$array$DistArray$$init$S(final x10.lang.PlaceGroup pg, final x10.core.fun.Fun_0_0<x10.array.LocalState<$T>> init, final long sz, __1$1x10$array$LocalState$1x10$array$DistArray$$T$2$2 $dummy) {
         {
            
            //#line 79 "x10/array/DistArray.x10"
            this.size = sz;
            
            
            //#line 80 "x10/array/DistArray.x10"
            final x10.lang.PlaceLocalHandle plh = x10.lang.PlaceLocalHandle.<x10.array.LocalState<$T>> makeFlat__1$1x10$lang$PlaceLocalHandle$$T$2(x10.rtt.ParameterizedType.make(x10.array.LocalState.$RTT, $T), ((x10.lang.PlaceGroup)(pg)), ((x10.core.fun.Fun_0_0)(init)));
            
            //#line 81 "x10/array/DistArray.x10"
            ((x10.lang.PlaceLocalHandle<x10.array.LocalState<$T>>)plh).$apply$G();
            
            //#line 82 "x10/array/DistArray.x10"
            ((x10.array.DistArray<$T>)this).localHandle = ((x10.lang.PlaceLocalHandle)(plh));
            
            //#line 83 "x10/array/DistArray.x10"
            ((x10.array.DistArray<$T>)this).placeGroup = ((x10.lang.PlaceGroup)(pg));
            
            //#line 84 "x10/array/DistArray.x10"
            final x10.core.Rail t$105802 = ((x10.core.Rail)(((x10.core.Rail<$T>)
                                                              this.getRailFromLocalHandle())));
            
            //#line 84 "x10/array/DistArray.x10"
            ((x10.array.DistArray<$T>)this).raw = ((x10.core.Rail)(t$105802));
        }
        return this;
    }
    
    
    
    //#line 99 "x10/array/DistArray.x10"
    /**
     * <p>Return the Rail[T] that is providing the backing storage for the array.
     * This method is primarily intended to be used to interface with native libraries 
     * (eg BLAS, ESSL) and to support bulk copy operations using the asyncCopy 
     * methods of Rail.</p>
     * 
     * This method should be used sparingly, since it may make client code dependent on the layout
     * algorithm used to map the local portion of the rank-dimensional array indicies to 
     * the 1-dimensional indicies in the backing Rail.
     * 
     * @return the Rail[T] that is the backing storage for the DistArray object in this Place.
     */
    final public x10.core.Rail raw() {
        
        //#line 99 "x10/array/DistArray.x10"
        final x10.core.Rail t$105803 = ((x10.core.Rail)(this.raw));
        
        //#line 99 "x10/array/DistArray.x10"
        return t$105803;
    }
    
    
    //#line 104 "x10/array/DistArray.x10"
    /**
     * The PlaceGroup over which the DistArray is defined
     */
    final public x10.lang.PlaceGroup placeGroup() {
        
        //#line 104 "x10/array/DistArray.x10"
        final x10.lang.PlaceGroup t$105804 = ((x10.lang.PlaceGroup)(this.placeGroup));
        
        //#line 104 "x10/array/DistArray.x10"
        return t$105804;
    }
    
    
    //#line 111 "x10/array/DistArray.x10"
    /**
     * Get an IterationSpace that represents all Points contained in
     * the global iteration space (valid indices) of the DistArray.
     * @return an IterationSpace for the DistArray
     */
    abstract public x10.array.IterationSpace globalIndices();
    
    
    //#line 117 "x10/array/DistArray.x10"
    /**
     * Define default iteration to be over globalIndices to support
     * idiomatic usage in <code>ateach</code>
     */
    public x10.lang.Iterator iterator() {
        
        //#line 117 "x10/array/DistArray.x10"
        final x10.array.IterationSpace t$105805 = ((x10.array.IterationSpace)(this.globalIndices()));
        
        //#line 117 "x10/array/DistArray.x10"
        final x10.lang.Iterator t$105806 = t$105805.iterator();
        
        //#line 117 "x10/array/DistArray.x10"
        return t$105806;
    }
    
    
    //#line 124 "x10/array/DistArray.x10"
    /**
     * Get an IterationSpace that represents all Points contained in
     * the local iteration space (valid indices) of the DistArray at the current Place.
     * @return an IterationSpace for the Array
     */
    abstract public x10.array.IterationSpace localIndices();
    
    
    //#line 135 "x10/array/DistArray.x10"
    /**
     * Return the Place which contains the data for the argument
     * Point or Place.INVALID_PLACE if the Point is not in the globalIndices
     * of this DistArray
     *
     * @param p the Point to lookup
     * @return the Place where p is a valid index in the DistArray; 
     *          will return Place.INVALID_PLACE if p is not contained in globalIndices
     */
    abstract public x10.lang.Place place(final x10.lang.Point p);
    
    
    //#line 147 "x10/array/DistArray.x10"
    /**
     * Return the element of this array corresponding to the given point.
     * The rank of the given point has to be the same as the rank of this array.
     * If the distribution does not map the given Point to the current place,
     * then a BadPlaceException will be raised.
     * 
     * @param p the given point
     * @return the element of this array corresponding to the given point.
     * @see #set(T, Point)
     */
    abstract public $T $apply$G(final x10.lang.Point p);
    
    
    //#line 161 "x10/array/DistArray.x10"
    /**
     * Set the element of this array corresponding to the given point to the given value.
     * Return the new value of the element.
     * The rank of the given point has to be the same as the rank of this array.
     * If the distribution does not map the given Point to the current place,
     * then a BadPlaceException will be raised.
     * 
     * @param v the given value
     * @param p the given point
     * @return the new value of the element of this array corresponding to the given point.
     * @see #operator(Point)
     */
    abstract public $T $set__1x10$array$DistArray$$T$G(final x10.lang.Point p, final $T v);
    
    
    //#line 170 "x10/array/DistArray.x10"
    /**
     * Returns the specified rectangular patch of this array as a Rail.
     * 
     * @param space the IterationSpace representing the portion of this array to copy
     * @throws ArrayIndexOutOfBoundsException if the specified region is not
     *        contained in this array
     */
    abstract public x10.core.Rail getPatch(final x10.array.IterationSpace space);
    
    
    //#line 183 "x10/array/DistArray.x10"
    /**
     * Reduce this array using the given function and the given initial value.
     * Each element of the array will be given as an argument to the reduction
     * function exactly once, but in an arbitrary order.  The reduction function
     * may be applied concurrently to implement a parallel reduction.
     * 
     * @param op the reduction function
     * @param unit the given initial value
     * @return the final result of the reduction.
     * @see #reduce((U,T)=>U,(U,U)=>U,U)
     */
    final public $T reduce__0$1x10$array$DistArray$$T$3x10$array$DistArray$$T$3x10$array$DistArray$$T$2__1x10$array$DistArray$$T$G(final x10.core.fun.Fun_0_2 op, final $T unit) {
        
        //#line 183 "x10/array/DistArray.x10"
        final $T t$105807 = (($T)(this.<$T> reduce__0$1x10$array$DistArray$$U$3x10$array$DistArray$$T$3x10$array$DistArray$$U$2__1$1x10$array$DistArray$$U$3x10$array$DistArray$$U$3x10$array$DistArray$$U$2__2x10$array$DistArray$$U$G($T, ((x10.core.fun.Fun_0_2)(op)), ((x10.core.fun.Fun_0_2)(op)), (($T)(unit)))));
        
        //#line 183 "x10/array/DistArray.x10"
        return t$105807;
    }
    
    
    //#line 196 "x10/array/DistArray.x10"
    /**
     * Reduce this array using the given function and the given initial value.
     * Each element of the array will be given as an argument to the reduction
     * function exactly once, but in an arbitrary order.  The reduction function
     * may be applied concurrently to implement a parallel reduction.
     * 
     * @param lop the local reduction function
     * @param gop the global reduction function
     * @param unit the given initial value
     * @return the final result of the reduction.
     */
    final public <$U>$U reduce__0$1x10$array$DistArray$$U$3x10$array$DistArray$$T$3x10$array$DistArray$$U$2__1$1x10$array$DistArray$$U$3x10$array$DistArray$$U$3x10$array$DistArray$$U$2__2x10$array$DistArray$$U$G(final x10.rtt.Type $U, final x10.core.fun.Fun_0_2 lop, final x10.core.fun.Fun_0_2 gop, final $U unit) {
        
        //#line 197 "x10/array/DistArray.x10"
        final x10.array.DistArray.Anonymous$7909 reducer = ((x10.array.DistArray.Anonymous$7909)(new x10.array.DistArray.Anonymous$7909<$U, $T>((java.lang.System[]) null, $U, $T)));
        
        //#line 197 "x10/array/DistArray.x10"
        final x10.array.DistArray out$105559 = ((x10.array.DistArray)(this));
        
        //#line 39 . "x10/array/DistArray.x10"
        ((x10.array.DistArray.Anonymous$7909<$U, $T>)reducer).out$ = out$105559;
        
        //#line 196 . "x10/array/DistArray.x10"
        ((x10.array.DistArray.Anonymous$7909<$U, $T>)reducer).unit = (($U)(unit));
        
        //#line 196 . "x10/array/DistArray.x10"
        ((x10.array.DistArray.Anonymous$7909<$U, $T>)reducer).gop = gop;
        
        //#line 202 "x10/array/DistArray.x10"
        final $U result;
        {
            
            //#line 202 "x10/array/DistArray.x10"
            final x10.xrx.FinishState fs$105939 = ((x10.xrx.FinishState)(x10.xrx.Runtime.<$U> startCollectingFinish__0$1x10$xrx$Runtime$$T$2($U, ((x10.lang.Reducible)(reducer)))));
            
            //#line 202 "x10/array/DistArray.x10"
            try {{
                {
                    
                    //#line 203 "x10/array/DistArray.x10"
                    final x10.lang.PlaceGroup t$105809 = ((x10.lang.PlaceGroup)(this.placeGroup));
                    
                    //#line 203 "x10/array/DistArray.x10"
                    final x10.lang.Iterator where$105544 = t$105809.iterator();
                    
                    //#line 203 "x10/array/DistArray.x10"
                    for (;
                         true;
                         ) {
                        
                        //#line 203 "x10/array/DistArray.x10"
                        final boolean t$105818 = ((x10.lang.Iterator<x10.lang.Place>)where$105544).hasNext$O();
                        
                        //#line 203 "x10/array/DistArray.x10"
                        if (!(t$105818)) {
                            
                            //#line 203 "x10/array/DistArray.x10"
                            break;
                        }
                        
                        //#line 203 "x10/array/DistArray.x10"
                        final x10.lang.Place where$105903 = ((x10.lang.Place)(((x10.lang.Iterator<x10.lang.Place>)where$105544).next$G()));
                        
                        //#line 204 "x10/array/DistArray.x10"
                        x10.xrx.Runtime.runAsync(((x10.lang.Place)(where$105903)), ((x10.core.fun.VoidFun_0_0)(new x10.array.DistArray.$Closure$2<$T, $U>($T, $U, ((x10.array.DistArray<$T>)(this)), unit, lop, (x10.array.DistArray.$Closure$2.__0$1x10$array$DistArray$$Closure$2$$T$2__1x10$array$DistArray$$Closure$2$$U__2$1x10$array$DistArray$$Closure$2$$U$3x10$array$DistArray$$Closure$2$$T$3x10$array$DistArray$$Closure$2$$U$2) null))), ((x10.xrx.Runtime.Profile)(null)));
                    }
                }
            }}catch (java.lang.Throwable __lowerer__var__0__) {
                
                //#line 202 "x10/array/DistArray.x10"
                x10.xrx.Runtime.pushException(((java.lang.Throwable)(__lowerer__var__0__)));
                
                //#line 202 "x10/array/DistArray.x10"
                throw new java.lang.RuntimeException();
            }finally {{
                 
                 //#line 202 "x10/array/DistArray.x10"
                 result = (($U)(x10.xrx.Runtime.<$U> stopCollectingFinish$G($U, ((x10.xrx.FinishState)(fs$105939)))));
             }}
            }
        
        //#line 211 "x10/array/DistArray.x10"
        return result;
        }
    
    
    //#line 231 "x10/array/DistArray.x10"
    /**
     * Map the given function onto the elements of this array
     * storing the results in the dst array. For maximum flexibility
     * of use, map does not require that the src and destination array
     * have the same dimesionality, rank or distribution, only that they have the same
     * number of elements as every Place.  
     * When applied to arrays that use the same IterationSpace,
     * the result will be that for all <code>pt</code> in the IterationSpace
     * </code> dst(pt) == op(src(pt)) </code>.  When applied to arrays that use
     * a different iteration space, the mapping from src to dst is defined in
     * terms of the index of the backing rails, that is <code>dst.raw()(i) = op(src.raw()(i))</code>
     * for i in <code>0..(src.size()-1)</code>.
     * 
     * @param dst the destination array for the results of the map operation
     * @param op the function to apply to each element of the array
     * @return dst after updating its contents to contain the result of the map operation.
     */
    final public <$U>x10.array.DistArray map__0$1x10$array$DistArray$$U$2__1$1x10$array$DistArray$$T$3x10$array$DistArray$$U$2(final x10.rtt.Type $U, final x10.array.DistArray dst, final x10.core.fun.Fun_0_1 op) {
        
        //#line 232 "x10/array/DistArray.x10"
        final x10.lang.PlaceGroup t$105826 = ((x10.lang.PlaceGroup)(this.placeGroup));
        
        //#line 232 "x10/array/DistArray.x10"
        final x10.core.fun.VoidFun_0_0 t$105827 = ((x10.core.fun.VoidFun_0_0)(new x10.array.DistArray.$Closure$3<$T, $U>($T, $U, ((x10.array.DistArray<$T>)(this)), dst, op, (x10.array.DistArray.$Closure$3.__0$1x10$array$DistArray$$Closure$3$$T$2__1$1x10$array$DistArray$$Closure$3$$U$2__2$1x10$array$DistArray$$Closure$3$$T$3x10$array$DistArray$$Closure$3$$U$2) null)));
        
        //#line 232 "x10/array/DistArray.x10"
        t$105826.broadcastFlat(((x10.core.fun.VoidFun_0_0)(t$105827)));
        
        //#line 237 "x10/array/DistArray.x10"
        return dst;
    }
    
    
    //#line 259 "x10/array/DistArray.x10"
    /**
     * Map the given function onto the elements of this array
     * and the argument src array storing the results in the dst array. 
     * For maximum flexibility of use, map does not require that the three arrays
     * have the same dimesionality, rank or distribution, only that they have the same
     * number of elements at every Place.  
     * When applied to arrays that use the same IterationSpace,
     * the result will be that for all <code>pt</code> in the IterationSpace
     * </code> dst(pt) == op(this(pt), src(pt)) </code>.  When applied to arrays that use
     * a different iteration space, the mapping from src to dst is defined in
     * terms of the index of the backing rails, that is 
     * <code>dst.raw()(i) = op(this.raw()(i), src.raw()(i))</code>
     * for i in <code>0..(src.size()-1)</code>.
     * 
     * @param src2 the second source array to use as input to the map function
     * @param dst the destination array for the results of the map operation
     * @param op the function to apply to each element of the arrays
     * @return dst after updating its contents to contain the result of the map operation.
     */
    final public <$S, $U>x10.array.DistArray map__0$1x10$array$DistArray$$S$2__1$1x10$array$DistArray$$U$2__2$1x10$array$DistArray$$T$3x10$array$DistArray$$S$3x10$array$DistArray$$U$2(final x10.rtt.Type $S, final x10.rtt.Type $U, final x10.array.DistArray src2, final x10.array.DistArray dst, final x10.core.fun.Fun_0_2 op) {
        
        //#line 260 "x10/array/DistArray.x10"
        final x10.lang.PlaceGroup t$105852 = ((x10.lang.PlaceGroup)(this.placeGroup));
        
        //#line 260 "x10/array/DistArray.x10"
        final x10.core.fun.VoidFun_0_0 t$105853 = ((x10.core.fun.VoidFun_0_0)(new x10.array.DistArray.$Closure$4<$T, $S, $U>($T, $S, $U, ((x10.array.DistArray<$T>)(this)), src2, dst, op, (x10.array.DistArray.$Closure$4.$_7c63cb90) null)));
        
        //#line 260 "x10/array/DistArray.x10"
        t$105852.broadcastFlat(((x10.core.fun.VoidFun_0_0)(t$105853)));
        
        //#line 269 "x10/array/DistArray.x10"
        return dst;
    }
    
    
    //#line 272 "x10/array/DistArray.x10"
    public static void raiseBoundsError(final long i) {
        
        //#line 273 "x10/array/DistArray.x10"
        final java.lang.String t$105854 = (("(") + ((x10.core.Long.$box(i))));
        
        //#line 273 "x10/array/DistArray.x10"
        final java.lang.String t$105855 = ((t$105854) + (") not contained in array"));
        
        //#line 273 "x10/array/DistArray.x10"
        final java.lang.ArrayIndexOutOfBoundsException t$105856 = ((java.lang.ArrayIndexOutOfBoundsException)(new java.lang.ArrayIndexOutOfBoundsException(t$105855)));
        
        //#line 273 "x10/array/DistArray.x10"
        throw t$105856;
    }
    
    
    //#line 275 "x10/array/DistArray.x10"
    public static void raiseBoundsError(final long i, final long j) {
        
        //#line 276 "x10/array/DistArray.x10"
        final java.lang.String t$105857 = (("(") + ((x10.core.Long.$box(i))));
        
        //#line 276 "x10/array/DistArray.x10"
        final java.lang.String t$105858 = ((t$105857) + (", "));
        
        //#line 276 "x10/array/DistArray.x10"
        final java.lang.String t$105859 = ((t$105858) + ((x10.core.Long.$box(j))));
        
        //#line 276 "x10/array/DistArray.x10"
        final java.lang.String t$105860 = ((t$105859) + (") not contained in array"));
        
        //#line 276 "x10/array/DistArray.x10"
        final java.lang.ArrayIndexOutOfBoundsException t$105861 = ((java.lang.ArrayIndexOutOfBoundsException)(new java.lang.ArrayIndexOutOfBoundsException(t$105860)));
        
        //#line 276 "x10/array/DistArray.x10"
        throw t$105861;
    }
    
    
    //#line 278 "x10/array/DistArray.x10"
    public static void raiseBoundsError(final long i, final long j, final long k) {
        
        //#line 279 "x10/array/DistArray.x10"
        final java.lang.String t$105862 = (("(") + ((x10.core.Long.$box(i))));
        
        //#line 279 "x10/array/DistArray.x10"
        final java.lang.String t$105863 = ((t$105862) + (", "));
        
        //#line 279 "x10/array/DistArray.x10"
        final java.lang.String t$105864 = ((t$105863) + ((x10.core.Long.$box(j))));
        
        //#line 279 "x10/array/DistArray.x10"
        final java.lang.String t$105865 = ((t$105864) + (", "));
        
        //#line 279 "x10/array/DistArray.x10"
        final java.lang.String t$105866 = ((t$105865) + ((x10.core.Long.$box(k))));
        
        //#line 279 "x10/array/DistArray.x10"
        final java.lang.String t$105867 = ((t$105866) + (") not contained in array"));
        
        //#line 279 "x10/array/DistArray.x10"
        final java.lang.ArrayIndexOutOfBoundsException t$105868 = ((java.lang.ArrayIndexOutOfBoundsException)(new java.lang.ArrayIndexOutOfBoundsException(t$105867)));
        
        //#line 279 "x10/array/DistArray.x10"
        throw t$105868;
    }
    
    
    //#line 282 "x10/array/DistArray.x10"
    public static void raisePlaceError(final long i) {
        
        //#line 283 "x10/array/DistArray.x10"
        final java.lang.String t$105869 = (("point (") + ((x10.core.Long.$box(i))));
        
        //#line 283 "x10/array/DistArray.x10"
        final java.lang.String t$105870 = ((t$105869) + (") not defined at "));
        
        //#line 283 "x10/array/DistArray.x10"
        final java.lang.String t$105871 = ((t$105870) + (x10.x10rt.X10RT.here()));
        
        //#line 283 "x10/array/DistArray.x10"
        final x10.lang.BadPlaceException t$105872 = ((x10.lang.BadPlaceException)(new x10.lang.BadPlaceException(t$105871)));
        
        //#line 283 "x10/array/DistArray.x10"
        throw t$105872;
    }
    
    
    //#line 285 "x10/array/DistArray.x10"
    public static void raisePlaceError(final long i, final long j) {
        
        //#line 286 "x10/array/DistArray.x10"
        final java.lang.String t$105873 = (("point (") + ((x10.core.Long.$box(i))));
        
        //#line 286 "x10/array/DistArray.x10"
        final java.lang.String t$105874 = ((t$105873) + (", "));
        
        //#line 286 "x10/array/DistArray.x10"
        final java.lang.String t$105875 = ((t$105874) + ((x10.core.Long.$box(j))));
        
        //#line 286 "x10/array/DistArray.x10"
        final java.lang.String t$105876 = ((t$105875) + (") not defined at "));
        
        //#line 286 "x10/array/DistArray.x10"
        final java.lang.String t$105877 = ((t$105876) + (x10.x10rt.X10RT.here()));
        
        //#line 286 "x10/array/DistArray.x10"
        final x10.lang.BadPlaceException t$105878 = ((x10.lang.BadPlaceException)(new x10.lang.BadPlaceException(t$105877)));
        
        //#line 286 "x10/array/DistArray.x10"
        throw t$105878;
    }
    
    
    //#line 288 "x10/array/DistArray.x10"
    public static void raisePlaceError(final long i, final long j, final long k) {
        
        //#line 289 "x10/array/DistArray.x10"
        final java.lang.String t$105879 = (("point (") + ((x10.core.Long.$box(i))));
        
        //#line 289 "x10/array/DistArray.x10"
        final java.lang.String t$105880 = ((t$105879) + (", "));
        
        //#line 289 "x10/array/DistArray.x10"
        final java.lang.String t$105881 = ((t$105880) + ((x10.core.Long.$box(j))));
        
        //#line 289 "x10/array/DistArray.x10"
        final java.lang.String t$105882 = ((t$105881) + (", "));
        
        //#line 289 "x10/array/DistArray.x10"
        final java.lang.String t$105883 = ((t$105882) + ((x10.core.Long.$box(k))));
        
        //#line 289 "x10/array/DistArray.x10"
        final java.lang.String t$105884 = ((t$105883) + (") not defined at "));
        
        //#line 289 "x10/array/DistArray.x10"
        final java.lang.String t$105885 = ((t$105884) + (x10.x10rt.X10RT.here()));
        
        //#line 289 "x10/array/DistArray.x10"
        final x10.lang.BadPlaceException t$105886 = ((x10.lang.BadPlaceException)(new x10.lang.BadPlaceException(t$105885)));
        
        //#line 289 "x10/array/DistArray.x10"
        throw t$105886;
    }
    
    
    //#line 292 "x10/array/DistArray.x10"
    public static void raiseNegativeArraySizeException() {
        
        //#line 293 "x10/array/DistArray.x10"
        final java.lang.NegativeArraySizeException t$105887 = ((java.lang.NegativeArraySizeException)(new java.lang.NegativeArraySizeException()));
        
        //#line 293 "x10/array/DistArray.x10"
        throw t$105887;
    }
    
    
    //#line 39 "x10/array/DistArray.x10"
    final public x10.array.DistArray x10$array$DistArray$$this$x10$array$DistArray() {
        
        //#line 39 "x10/array/DistArray.x10"
        return x10.array.DistArray.this;
    }
    
    
    //#line 39 "x10/array/DistArray.x10"
    final public void __fieldInitializers_x10_array_DistArray() {
        
    }
    
    
    //#line 197 "x10/array/DistArray.x10"
    @x10.runtime.impl.java.X10Generated
    final public static class Anonymous$7909<$U, $T> extends x10.core.Ref implements x10.lang.Reducible, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<Anonymous$7909> $RTT = 
            x10.rtt.NamedType.<Anonymous$7909> make("x10.array.DistArray.Anonymous$7909",
                                                    Anonymous$7909.class,
                                                    2,
                                                    new x10.rtt.Type[] {
                                                        x10.rtt.ParameterizedType.make(x10.lang.Reducible.$RTT, x10.rtt.UnresolvedType.PARAM(0))
                                                    });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { if (i == 0) return $U; if (i == 1) return $T; return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static <$U, $T> x10.serialization.X10JavaSerializable $_deserialize_body(x10.array.DistArray.Anonymous$7909<$U, $T> $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            $_obj.$U = (x10.rtt.Type) $deserializer.readObject();
            $_obj.$T = (x10.rtt.Type) $deserializer.readObject();
            $_obj.gop = $deserializer.readObject();
            $_obj.out$ = $deserializer.readObject();
            $_obj.unit = $deserializer.readObject();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.array.DistArray.Anonymous$7909 $_obj = new x10.array.DistArray.Anonymous$7909((java.lang.System[]) null, (x10.rtt.Type) null, (x10.rtt.Type) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            $serializer.write(this.$U);
            $serializer.write(this.$T);
            $serializer.write(this.gop);
            $serializer.write(this.out$);
            $serializer.write(this.unit);
            
        }
        
        // constructor just for allocation
        public Anonymous$7909(final java.lang.System[] $dummy, final x10.rtt.Type $U, final x10.rtt.Type $T) {
            x10.array.DistArray.Anonymous$7909.$initParams(this, $U, $T);
            
        }
        
        // dispatcher for method abstract public x10.lang.Reducible[T].operator()(a:T, b:T){}:T
        public java.lang.Object $apply(final java.lang.Object a1, final x10.rtt.Type t1, final java.lang.Object a2, final x10.rtt.Type t2) {
            return $apply__0x10$array$DistArray$Anonymous$7909$$U__1x10$array$DistArray$Anonymous$7909$$U$G(($U)a1, ($U)a2);
            
        }
        
        private x10.rtt.Type $U;
        private x10.rtt.Type $T;
        
        // initializer of type parameters
        public static void $initParams(final Anonymous$7909 $this, final x10.rtt.Type $U, final x10.rtt.Type $T) {
            $this.$U = $U;
            $this.$T = $T;
            
        }
        // synthetic type for parameter mangling
        public static final class __0$1x10$array$DistArray$Anonymous$7909$$T$2__1x10$array$DistArray$Anonymous$7909$$U__2$1x10$array$DistArray$Anonymous$7909$$U$3x10$array$DistArray$Anonymous$7909$$U$3x10$array$DistArray$Anonymous$7909$$U$2 {}
        
    
        
        //#line 39 "x10/array/DistArray.x10"
        public x10.array.DistArray<$T> out$;
        
        //#line 196 "x10/array/DistArray.x10"
        public $U unit;
        
        //#line 196 "x10/array/DistArray.x10"
        public x10.core.fun.Fun_0_2<$U,$U,$U> gop;
        
        
        //#line 198 "x10/array/DistArray.x10"
        public $U zero$G() {
            
            //#line 198 "x10/array/DistArray.x10"
            final $U t$105888 = (($U)(x10.array.DistArray.Anonymous$7909.this.unit));
            
            //#line 198 "x10/array/DistArray.x10"
            return t$105888;
        }
        
        
        //#line 199 "x10/array/DistArray.x10"
        public $U $apply__0x10$array$DistArray$Anonymous$7909$$U__1x10$array$DistArray$Anonymous$7909$$U$G(final $U a, final $U b) {
            
            //#line 199 "x10/array/DistArray.x10"
            final x10.core.fun.Fun_0_2 t$105889 = x10.array.DistArray.Anonymous$7909.this.gop;
            
            //#line 199 "x10/array/DistArray.x10"
            final $U t$105890 = (($U)((($U)
                                        ((x10.core.fun.Fun_0_2<$U,$U,$U>)t$105889).$apply(a, $U, b, $U))));
            
            //#line 199 "x10/array/DistArray.x10"
            return t$105890;
        }
        
        
        //#line 197 "x10/array/DistArray.x10"
        // creation method for java code (1-phase java constructor)
        public Anonymous$7909(final x10.rtt.Type $U, final x10.rtt.Type $T, final x10.array.DistArray<$T> out$, final $U unit, final x10.core.fun.Fun_0_2<$U,$U,$U> gop, __0$1x10$array$DistArray$Anonymous$7909$$T$2__1x10$array$DistArray$Anonymous$7909$$U__2$1x10$array$DistArray$Anonymous$7909$$U$3x10$array$DistArray$Anonymous$7909$$U$3x10$array$DistArray$Anonymous$7909$$U$2 $dummy) {
            this((java.lang.System[]) null, $U, $T);
            x10$array$DistArray$Anonymous$7909$$init$S(out$, unit, gop, (x10.array.DistArray.Anonymous$7909.__0$1x10$array$DistArray$Anonymous$7909$$T$2__1x10$array$DistArray$Anonymous$7909$$U__2$1x10$array$DistArray$Anonymous$7909$$U$3x10$array$DistArray$Anonymous$7909$$U$3x10$array$DistArray$Anonymous$7909$$U$2) null);
        }
        
        // constructor for non-virtual call
        final public x10.array.DistArray.Anonymous$7909<$U, $T> x10$array$DistArray$Anonymous$7909$$init$S(final x10.array.DistArray<$T> out$, final $U unit, final x10.core.fun.Fun_0_2<$U,$U,$U> gop, __0$1x10$array$DistArray$Anonymous$7909$$T$2__1x10$array$DistArray$Anonymous$7909$$U__2$1x10$array$DistArray$Anonymous$7909$$U$3x10$array$DistArray$Anonymous$7909$$U$3x10$array$DistArray$Anonymous$7909$$U$2 $dummy) {
             {
                
                //#line 39 "x10/array/DistArray.x10"
                ((x10.array.DistArray.Anonymous$7909<$U, $T>)this).out$ = out$;
                
                //#line 196 "x10/array/DistArray.x10"
                ((x10.array.DistArray.Anonymous$7909<$U, $T>)this).unit = (($U)(unit));
                
                //#line 196 "x10/array/DistArray.x10"
                ((x10.array.DistArray.Anonymous$7909<$U, $T>)this).gop = gop;
            }
            return this;
        }
        
    }
    
    @x10.runtime.impl.java.X10Generated
    final public static class $Closure$2<$T, $U> extends x10.core.Ref implements x10.core.fun.VoidFun_0_0, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<$Closure$2> $RTT = 
            x10.rtt.StaticVoidFunType.<$Closure$2> make($Closure$2.class,
                                                        2,
                                                        new x10.rtt.Type[] {
                                                            x10.core.fun.VoidFun_0_0.$RTT
                                                        });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { if (i == 0) return $T; if (i == 1) return $U; return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static <$T, $U> x10.serialization.X10JavaSerializable $_deserialize_body(x10.array.DistArray.$Closure$2<$T, $U> $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            $_obj.$T = (x10.rtt.Type) $deserializer.readObject();
            $_obj.$U = (x10.rtt.Type) $deserializer.readObject();
            $_obj.lop = $deserializer.readObject();
            $_obj.out$$ = $deserializer.readObject();
            $_obj.unit = $deserializer.readObject();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.array.DistArray.$Closure$2 $_obj = new x10.array.DistArray.$Closure$2((java.lang.System[]) null, (x10.rtt.Type) null, (x10.rtt.Type) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            $serializer.write(this.$T);
            $serializer.write(this.$U);
            $serializer.write(this.lop);
            $serializer.write(this.out$$);
            $serializer.write(this.unit);
            
        }
        
        // constructor just for allocation
        public $Closure$2(final java.lang.System[] $dummy, final x10.rtt.Type $T, final x10.rtt.Type $U) {
            x10.array.DistArray.$Closure$2.$initParams(this, $T, $U);
            
        }
        
        private x10.rtt.Type $T;
        private x10.rtt.Type $U;
        
        // initializer of type parameters
        public static void $initParams(final $Closure$2 $this, final x10.rtt.Type $T, final x10.rtt.Type $U) {
            $this.$T = $T;
            $this.$U = $U;
            
        }
        // synthetic type for parameter mangling
        public static final class __0$1x10$array$DistArray$$Closure$2$$T$2__1x10$array$DistArray$$Closure$2$$U__2$1x10$array$DistArray$$Closure$2$$U$3x10$array$DistArray$$Closure$2$$T$3x10$array$DistArray$$Closure$2$$U$2 {}
        
    
        
        public void $apply() {
            
            //#line 204 "x10/array/DistArray.x10"
            try {{
                
                //#line 205 "x10/array/DistArray.x10"
                final x10.array.DistArray this$105904 = ((x10.array.DistArray)(this.out$$));
                
                //#line 205 "x10/array/DistArray.x10"
                final x10.core.Rail src$105905 = ((x10.core.Rail)(((x10.array.DistArray<$T>)this$105904).raw));
                
                //#line 132 . "x10/util/RailUtils.x10"
                $U accum$105908 = (($U)(this.unit));
                
                //#line 133 . "x10/util/RailUtils.x10"
                final long i$97460max$105902 = ((x10.core.Rail<$T>)src$105905).size;
                
                //#line 133 . "x10/util/RailUtils.x10"
                long i$105898 = 0L;
                
                //#line 133 . "x10/util/RailUtils.x10"
                for (;
                     true;
                     ) {
                    
                    //#line 133 . "x10/util/RailUtils.x10"
                    final boolean t$105900 = ((i$105898) < (((long)(i$97460max$105902))));
                    
                    //#line 133 . "x10/util/RailUtils.x10"
                    if (!(t$105900)) {
                        
                        //#line 133 . "x10/util/RailUtils.x10"
                        break;
                    }
                    
                    //#line 134 . "x10/util/RailUtils.x10"
                    final $T t$105893 = (($T)(((x10.core.Rail<$T>)src$105905).$apply$G((long)(i$105898))));
                    
                    //#line 134 . "x10/util/RailUtils.x10"
                    final $U t$105894 = (($U)((($U)
                                                ((x10.core.fun.Fun_0_2<$U,$T,$U>)this.lop).$apply(accum$105908, $U, t$105893, $T))));
                    
                    //#line 134 . "x10/util/RailUtils.x10"
                    accum$105908 = (($U)(t$105894));
                    
                    //#line 133 . "x10/util/RailUtils.x10"
                    final long t$105897 = ((i$105898) + (((long)(1L))));
                    
                    //#line 133 . "x10/util/RailUtils.x10"
                    i$105898 = t$105897;
                }
                
                //#line 206 "x10/array/DistArray.x10"
                x10.xrx.Runtime.<$U> makeOffer__0x10$xrx$Runtime$$T($U, (($U)(accum$105908)));
            }}catch (java.lang.Error __lowerer__var__0__) {
                
                //#line 204 "x10/array/DistArray.x10"
                throw __lowerer__var__0__;
            }catch (java.lang.Throwable __lowerer__var__1__) {
                
                //#line 204 "x10/array/DistArray.x10"
                throw x10.rtt.Types.EXCEPTION.isInstance(__lowerer__var__1__) ? (java.lang.RuntimeException)(__lowerer__var__1__) : new x10.lang.WrappedThrowable(__lowerer__var__1__);
            }
        }
        
        public x10.array.DistArray<$T> out$$;
        public $U unit;
        public x10.core.fun.Fun_0_2<$U,$T,$U> lop;
        
        public $Closure$2(final x10.rtt.Type $T, final x10.rtt.Type $U, final x10.array.DistArray<$T> out$$, final $U unit, final x10.core.fun.Fun_0_2<$U,$T,$U> lop, __0$1x10$array$DistArray$$Closure$2$$T$2__1x10$array$DistArray$$Closure$2$$U__2$1x10$array$DistArray$$Closure$2$$U$3x10$array$DistArray$$Closure$2$$T$3x10$array$DistArray$$Closure$2$$U$2 $dummy) {
            x10.array.DistArray.$Closure$2.$initParams(this, $T, $U);
             {
                ((x10.array.DistArray.$Closure$2<$T, $U>)this).out$$ = out$$;
                ((x10.array.DistArray.$Closure$2<$T, $U>)this).unit = (($U)(unit));
                ((x10.array.DistArray.$Closure$2<$T, $U>)this).lop = lop;
            }
        }
        
    }
    
    @x10.runtime.impl.java.X10Generated
    final public static class $Closure$3<$T, $U> extends x10.core.Ref implements x10.core.fun.VoidFun_0_0, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<$Closure$3> $RTT = 
            x10.rtt.StaticVoidFunType.<$Closure$3> make($Closure$3.class,
                                                        2,
                                                        new x10.rtt.Type[] {
                                                            x10.core.fun.VoidFun_0_0.$RTT
                                                        });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { if (i == 0) return $T; if (i == 1) return $U; return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static <$T, $U> x10.serialization.X10JavaSerializable $_deserialize_body(x10.array.DistArray.$Closure$3<$T, $U> $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            $_obj.$T = (x10.rtt.Type) $deserializer.readObject();
            $_obj.$U = (x10.rtt.Type) $deserializer.readObject();
            $_obj.dst = $deserializer.readObject();
            $_obj.op = $deserializer.readObject();
            $_obj.out$$ = $deserializer.readObject();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.array.DistArray.$Closure$3 $_obj = new x10.array.DistArray.$Closure$3((java.lang.System[]) null, (x10.rtt.Type) null, (x10.rtt.Type) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            $serializer.write(this.$T);
            $serializer.write(this.$U);
            $serializer.write(this.dst);
            $serializer.write(this.op);
            $serializer.write(this.out$$);
            
        }
        
        // constructor just for allocation
        public $Closure$3(final java.lang.System[] $dummy, final x10.rtt.Type $T, final x10.rtt.Type $U) {
            x10.array.DistArray.$Closure$3.$initParams(this, $T, $U);
            
        }
        
        private x10.rtt.Type $T;
        private x10.rtt.Type $U;
        
        // initializer of type parameters
        public static void $initParams(final $Closure$3 $this, final x10.rtt.Type $T, final x10.rtt.Type $U) {
            $this.$T = $T;
            $this.$U = $U;
            
        }
        // synthetic type for parameter mangling
        public static final class __0$1x10$array$DistArray$$Closure$3$$T$2__1$1x10$array$DistArray$$Closure$3$$U$2__2$1x10$array$DistArray$$Closure$3$$T$3x10$array$DistArray$$Closure$3$$U$2 {}
        
    
        
        public void $apply() {
            
            //#line 233 "x10/array/DistArray.x10"
            final x10.array.DistArray this$105770 = ((x10.array.DistArray)(this.out$$));
            
            //#line 233 "x10/array/DistArray.x10"
            final x10.core.Rail s = ((x10.core.Rail)(((x10.array.DistArray<$T>)this$105770).raw));
            
            //#line 234 "x10/array/DistArray.x10"
            final x10.core.Rail d = ((x10.core.Rail)(((x10.array.DistArray<$U>)this.dst).raw));
            
            //#line 180 . "x10/util/RailUtils.x10"
            final long i$97498max$105919 = ((x10.core.Rail<$T>)s).size;
            
            //#line 180 . "x10/util/RailUtils.x10"
            long i$105915 = 0L;
            
            //#line 180 . "x10/util/RailUtils.x10"
            for (;
                 true;
                 ) {
                
                //#line 180 . "x10/util/RailUtils.x10"
                final boolean t$105917 = ((i$105915) < (((long)(i$97498max$105919))));
                
                //#line 180 . "x10/util/RailUtils.x10"
                if (!(t$105917)) {
                    
                    //#line 180 . "x10/util/RailUtils.x10"
                    break;
                }
                
                //#line 181 . "x10/util/RailUtils.x10"
                final $T t$105910 = (($T)(((x10.core.Rail<$T>)s).$apply$G((long)(i$105915))));
                
                //#line 181 . "x10/util/RailUtils.x10"
                final $U t$105911 = (($U)((($U)
                                            ((x10.core.fun.Fun_0_1<$T,$U>)this.op).$apply(t$105910, $T))));
                
                //#line 181 . "x10/util/RailUtils.x10"
                ((x10.core.Rail<$U>)d).$set__1x10$lang$Rail$$T$G((long)(i$105915), (($U)(t$105911)));
                
                //#line 180 . "x10/util/RailUtils.x10"
                final long t$105914 = ((i$105915) + (((long)(1L))));
                
                //#line 180 . "x10/util/RailUtils.x10"
                i$105915 = t$105914;
            }
        }
        
        public x10.array.DistArray<$T> out$$;
        public x10.array.DistArray<$U> dst;
        public x10.core.fun.Fun_0_1<$T,$U> op;
        
        public $Closure$3(final x10.rtt.Type $T, final x10.rtt.Type $U, final x10.array.DistArray<$T> out$$, final x10.array.DistArray<$U> dst, final x10.core.fun.Fun_0_1<$T,$U> op, __0$1x10$array$DistArray$$Closure$3$$T$2__1$1x10$array$DistArray$$Closure$3$$U$2__2$1x10$array$DistArray$$Closure$3$$T$3x10$array$DistArray$$Closure$3$$U$2 $dummy) {
            x10.array.DistArray.$Closure$3.$initParams(this, $T, $U);
             {
                ((x10.array.DistArray.$Closure$3<$T, $U>)this).out$$ = out$$;
                ((x10.array.DistArray.$Closure$3<$T, $U>)this).dst = dst;
                ((x10.array.DistArray.$Closure$3<$T, $U>)this).op = op;
            }
        }
        
    }
    
    @x10.runtime.impl.java.X10Generated
    final public static class $Closure$4<$T, $S, $U> extends x10.core.Ref implements x10.core.fun.VoidFun_0_0, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<$Closure$4> $RTT = 
            x10.rtt.StaticVoidFunType.<$Closure$4> make($Closure$4.class,
                                                        3,
                                                        new x10.rtt.Type[] {
                                                            x10.core.fun.VoidFun_0_0.$RTT
                                                        });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { if (i == 0) return $T; if (i == 1) return $S; if (i == 2) return $U; return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static <$T, $S, $U> x10.serialization.X10JavaSerializable $_deserialize_body(x10.array.DistArray.$Closure$4<$T, $S, $U> $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            $_obj.$T = (x10.rtt.Type) $deserializer.readObject();
            $_obj.$S = (x10.rtt.Type) $deserializer.readObject();
            $_obj.$U = (x10.rtt.Type) $deserializer.readObject();
            $_obj.dst = $deserializer.readObject();
            $_obj.op = $deserializer.readObject();
            $_obj.out$$ = $deserializer.readObject();
            $_obj.src2 = $deserializer.readObject();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.array.DistArray.$Closure$4 $_obj = new x10.array.DistArray.$Closure$4((java.lang.System[]) null, (x10.rtt.Type) null, (x10.rtt.Type) null, (x10.rtt.Type) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            $serializer.write(this.$T);
            $serializer.write(this.$S);
            $serializer.write(this.$U);
            $serializer.write(this.dst);
            $serializer.write(this.op);
            $serializer.write(this.out$$);
            $serializer.write(this.src2);
            
        }
        
        // constructor just for allocation
        public $Closure$4(final java.lang.System[] $dummy, final x10.rtt.Type $T, final x10.rtt.Type $S, final x10.rtt.Type $U) {
            x10.array.DistArray.$Closure$4.$initParams(this, $T, $S, $U);
            
        }
        
        private x10.rtt.Type $T;
        private x10.rtt.Type $S;
        private x10.rtt.Type $U;
        
        // initializer of type parameters
        public static void $initParams(final $Closure$4 $this, final x10.rtt.Type $T, final x10.rtt.Type $S, final x10.rtt.Type $U) {
            $this.$T = $T;
            $this.$S = $S;
            $this.$U = $U;
            
        }
        // synthetic type for parameter mangling for __0$1x10$array$DistArray$$Closure$4$$T$2__1$1x10$array$DistArray$$Closure$4$$S$2__2$1x10$array$DistArray$$Closure$4$$U$2__3$1x10$array$DistArray$$Closure$4$$T$3x10$array$DistArray$$Closure$4$$S$3x10$array$DistArray$$Closure$4$$U$2
        public static final class $_7c63cb90 {}
        
    
        
        public void $apply() {
            
            //#line 261 "x10/array/DistArray.x10"
            final x10.array.DistArray this$105782 = ((x10.array.DistArray)(this.out$$));
            
            //#line 261 "x10/array/DistArray.x10"
            final x10.core.Rail s1 = ((x10.core.Rail)(((x10.array.DistArray<$T>)this$105782).raw));
            
            //#line 262 "x10/array/DistArray.x10"
            final x10.core.Rail s2 = ((x10.core.Rail)(((x10.array.DistArray<$S>)this.src2).raw));
            
            //#line 263 "x10/array/DistArray.x10"
            final x10.core.Rail d = ((x10.core.Rail)(((x10.array.DistArray<$U>)this.dst).raw));
            
            //#line 264 "x10/array/DistArray.x10"
            final long t$105828 = ((x10.core.Rail<$T>)s1).size;
            
            //#line 264 "x10/array/DistArray.x10"
            final long t$105829 = ((x10.core.Rail<$S>)s2).size;
            
            //#line 264 "x10/array/DistArray.x10"
            final boolean t$105838 = ((long) t$105828) != ((long) t$105829);
            
            //#line 264 "x10/array/DistArray.x10"
            if (t$105838) {
                
                //#line 265 "x10/array/DistArray.x10"
                final long t$105830 = ((x10.core.Rail<$T>)s1).size;
                
                //#line 265 "x10/array/DistArray.x10"
                final java.lang.String t$105831 = (("Source arrays have different sizes (") + ((x10.core.Long.$box(t$105830))));
                
                //#line 265 "x10/array/DistArray.x10"
                final java.lang.String t$105832 = ((t$105831) + (", "));
                
                //#line 265 "x10/array/DistArray.x10"
                final long t$105833 = ((x10.core.Rail<$S>)s2).size;
                
                //#line 265 "x10/array/DistArray.x10"
                final java.lang.String t$105834 = ((t$105832) + ((x10.core.Long.$box(t$105833))));
                
                //#line 265 "x10/array/DistArray.x10"
                final java.lang.String t$105835 = ((t$105834) + (") at "));
                
                //#line 265 "x10/array/DistArray.x10"
                final java.lang.String t$105836 = ((t$105835) + (x10.x10rt.X10RT.here()));
                
                //#line 265 "x10/array/DistArray.x10"
                final java.lang.IllegalArgumentException t$105837 = ((java.lang.IllegalArgumentException)(new java.lang.IllegalArgumentException(t$105836)));
                
                //#line 265 "x10/array/DistArray.x10"
                throw t$105837;
            }
            
            //#line 267 "x10/array/DistArray.x10"
            final x10.core.Rail t$104967 = ((x10.core.Rail<$S>)
                                             s2);
            
            //#line 267 "x10/array/DistArray.x10"
            final long t$105839 = ((x10.core.Rail<$S>)t$104967).size;
            
            //#line 267 "x10/array/DistArray.x10"
            final long t$105840 = ((x10.core.Rail<$T>)s1).size;
            
            //#line 267 "x10/array/DistArray.x10"
            final boolean t$105841 = ((long) t$105839) == ((long) t$105840);
            
            //#line 267 "x10/array/DistArray.x10"
            final boolean t$105843 = !(t$105841);
            
            //#line 267 "x10/array/DistArray.x10"
            if (t$105843) {
                
                //#line 267 "x10/array/DistArray.x10"
                final x10.lang.FailedDynamicCheckException t$105842 = new x10.lang.FailedDynamicCheckException("x10.lang.Rail[S]{self.size==s1.size}");
                
                //#line 267 "x10/array/DistArray.x10"
                throw t$105842;
            }
            
            //#line 203 . "x10/util/RailUtils.x10"
            final long i$97517max$105930 = ((x10.core.Rail<$T>)s1).size;
            
            //#line 203 . "x10/util/RailUtils.x10"
            long i$105926 = 0L;
            
            //#line 203 . "x10/util/RailUtils.x10"
            for (;
                 true;
                 ) {
                
                //#line 203 . "x10/util/RailUtils.x10"
                final boolean t$105928 = ((i$105926) < (((long)(i$97517max$105930))));
                
                //#line 203 . "x10/util/RailUtils.x10"
                if (!(t$105928)) {
                    
                    //#line 203 . "x10/util/RailUtils.x10"
                    break;
                }
                
                //#line 204 . "x10/util/RailUtils.x10"
                final $T t$105920 = (($T)(((x10.core.Rail<$T>)s1).$apply$G((long)(i$105926))));
                
                //#line 204 . "x10/util/RailUtils.x10"
                final $S t$105921 = (($S)(((x10.core.Rail<$S>)t$104967).$apply$G((long)(i$105926))));
                
                //#line 204 . "x10/util/RailUtils.x10"
                final $U t$105922 = (($U)((($U)
                                            ((x10.core.fun.Fun_0_2<$T,$S,$U>)this.op).$apply(t$105920, $T, t$105921, $S))));
                
                //#line 204 . "x10/util/RailUtils.x10"
                ((x10.core.Rail<$U>)d).$set__1x10$lang$Rail$$T$G((long)(i$105926), (($U)(t$105922)));
                
                //#line 203 . "x10/util/RailUtils.x10"
                final long t$105925 = ((i$105926) + (((long)(1L))));
                
                //#line 203 . "x10/util/RailUtils.x10"
                i$105926 = t$105925;
            }
        }
        
        public x10.array.DistArray<$T> out$$;
        public x10.array.DistArray<$S> src2;
        public x10.array.DistArray<$U> dst;
        public x10.core.fun.Fun_0_2<$T,$S,$U> op;
        
        public $Closure$4(final x10.rtt.Type $T, final x10.rtt.Type $S, final x10.rtt.Type $U, final x10.array.DistArray<$T> out$$, final x10.array.DistArray<$S> src2, final x10.array.DistArray<$U> dst, final x10.core.fun.Fun_0_2<$T,$S,$U> op, $_7c63cb90 $dummy) {
            x10.array.DistArray.$Closure$4.$initParams(this, $T, $S, $U);
             {
                ((x10.array.DistArray.$Closure$4<$T, $S, $U>)this).out$$ = out$$;
                ((x10.array.DistArray.$Closure$4<$T, $S, $U>)this).src2 = src2;
                ((x10.array.DistArray.$Closure$4<$T, $S, $U>)this).dst = dst;
                ((x10.array.DistArray.$Closure$4<$T, $S, $U>)this).op = op;
            }
        }
        
    }
    
    }
    
    
    