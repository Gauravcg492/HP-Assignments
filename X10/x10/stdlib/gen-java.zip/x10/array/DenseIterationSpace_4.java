package x10.array;

/**
 * A DenseIterationSpace_4 represents the rank 4 
 * iteration space of points [min0,min1,min2]..[max0,max1,max2] inclusive.
 */
@x10.runtime.impl.java.X10Generated
final public class DenseIterationSpace_4 extends x10.array.IterationSpace implements x10.serialization.X10JavaSerializable
{
    public static final x10.rtt.RuntimeType<DenseIterationSpace_4> $RTT = 
        x10.rtt.NamedType.<DenseIterationSpace_4> make("x10.array.DenseIterationSpace_4",
                                                       DenseIterationSpace_4.class,
                                                       new x10.rtt.Type[] {
                                                           x10.array.IterationSpace.$RTT
                                                       });
    
    public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
    
    public x10.rtt.Type<?> $getParam(int i) { return null; }
    
    private Object writeReplace() throws java.io.ObjectStreamException {
        return new x10.serialization.SerializationProxy(this);
    }
    
    public static x10.serialization.X10JavaSerializable $_deserialize_body(x10.array.DenseIterationSpace_4 $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
        x10.array.IterationSpace.$_deserialize_body($_obj, $deserializer);
        $_obj.max0 = $deserializer.readLong();
        $_obj.max1 = $deserializer.readLong();
        $_obj.max2 = $deserializer.readLong();
        $_obj.max3 = $deserializer.readLong();
        $_obj.min0 = $deserializer.readLong();
        $_obj.min1 = $deserializer.readLong();
        $_obj.min2 = $deserializer.readLong();
        $_obj.min3 = $deserializer.readLong();
        return $_obj;
    }
    
    public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
        x10.array.DenseIterationSpace_4 $_obj = new x10.array.DenseIterationSpace_4((java.lang.System[]) null);
        $deserializer.record_reference($_obj);
        return $_deserialize_body($_obj, $deserializer);
    }
    
    public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
        super.$_serialize($serializer);
        $serializer.write(this.max0);
        $serializer.write(this.max1);
        $serializer.write(this.max2);
        $serializer.write(this.max3);
        $serializer.write(this.min0);
        $serializer.write(this.min1);
        $serializer.write(this.min2);
        $serializer.write(this.min3);
        
    }
    
    // constructor just for allocation
    public DenseIterationSpace_4(final java.lang.System[] $dummy) {
        super($dummy);
        
    }
    
    

    
    //#line 20 "x10/array/DenseIterationSpace_4.x10"
    public long min0;
    
    //#line 21 "x10/array/DenseIterationSpace_4.x10"
    public long min1;
    
    //#line 22 "x10/array/DenseIterationSpace_4.x10"
    public long min2;
    
    //#line 23 "x10/array/DenseIterationSpace_4.x10"
    public long min3;
    
    //#line 24 "x10/array/DenseIterationSpace_4.x10"
    public long max0;
    
    //#line 25 "x10/array/DenseIterationSpace_4.x10"
    public long max1;
    
    //#line 26 "x10/array/DenseIterationSpace_4.x10"
    public long max2;
    
    //#line 27 "x10/array/DenseIterationSpace_4.x10"
    public long max3;
    
    //#line 29 "x10/array/DenseIterationSpace_4.x10"
    private static x10.array.DenseIterationSpace_4 EMPTY;
    
    
    //#line 31 "x10/array/DenseIterationSpace_4.x10"
    // creation method for java code (1-phase java constructor)
    public DenseIterationSpace_4(final long min0, final long min1, final long min2, final long min3, final long max0, final long max1, final long max2, final long max3) {
        this((java.lang.System[]) null);
        x10$array$DenseIterationSpace_4$$init$S(min0, min1, min2, min3, max0, max1, max2, max3);
    }
    
    // constructor for non-virtual call
    final public x10.array.DenseIterationSpace_4 x10$array$DenseIterationSpace_4$$init$S(final long min0, final long min1, final long min2, final long min3, final long max0, final long max1, final long max2, final long max3) {
         {
            
            //#line 33 "x10/array/DenseIterationSpace_4.x10"
            final x10.array.IterationSpace this$104722 = ((x10.array.IterationSpace)(this));
            
            //#line 22 . "x10/array/IterationSpace.x10"
            this$104722.rank = 4L;
            
            //#line 22 . "x10/array/IterationSpace.x10"
            this$104722.rect = true;
            
            //#line 31 "x10/array/DenseIterationSpace_4.x10"
            
            
            //#line 34 "x10/array/DenseIterationSpace_4.x10"
            this.min0 = min0;
            
            //#line 35 "x10/array/DenseIterationSpace_4.x10"
            this.min1 = min1;
            
            //#line 36 "x10/array/DenseIterationSpace_4.x10"
            this.min2 = min2;
            
            //#line 37 "x10/array/DenseIterationSpace_4.x10"
            this.min3 = min3;
            
            //#line 38 "x10/array/DenseIterationSpace_4.x10"
            this.max0 = max0;
            
            //#line 39 "x10/array/DenseIterationSpace_4.x10"
            this.max1 = max1;
            
            //#line 40 "x10/array/DenseIterationSpace_4.x10"
            this.max2 = max2;
            
            //#line 41 "x10/array/DenseIterationSpace_4.x10"
            this.max3 = max3;
        }
        return this;
    }
    
    
    
    //#line 44 "x10/array/DenseIterationSpace_4.x10"
    public long min$O(final long i) {
        
        //#line 45 "x10/array/DenseIterationSpace_4.x10"
        final boolean t$104736 = ((long) i) == ((long) 0L);
        
        //#line 45 "x10/array/DenseIterationSpace_4.x10"
        if (t$104736) {
            
            //#line 45 "x10/array/DenseIterationSpace_4.x10"
            final long t$104735 = this.min0;
            
            //#line 45 "x10/array/DenseIterationSpace_4.x10"
            return t$104735;
        }
        
        //#line 46 "x10/array/DenseIterationSpace_4.x10"
        final boolean t$104738 = ((long) i) == ((long) 1L);
        
        //#line 46 "x10/array/DenseIterationSpace_4.x10"
        if (t$104738) {
            
            //#line 46 "x10/array/DenseIterationSpace_4.x10"
            final long t$104737 = this.min1;
            
            //#line 46 "x10/array/DenseIterationSpace_4.x10"
            return t$104737;
        }
        
        //#line 47 "x10/array/DenseIterationSpace_4.x10"
        final boolean t$104740 = ((long) i) == ((long) 2L);
        
        //#line 47 "x10/array/DenseIterationSpace_4.x10"
        if (t$104740) {
            
            //#line 47 "x10/array/DenseIterationSpace_4.x10"
            final long t$104739 = this.min2;
            
            //#line 47 "x10/array/DenseIterationSpace_4.x10"
            return t$104739;
        }
        
        //#line 48 "x10/array/DenseIterationSpace_4.x10"
        final boolean t$104742 = ((long) i) == ((long) 3L);
        
        //#line 48 "x10/array/DenseIterationSpace_4.x10"
        if (t$104742) {
            
            //#line 48 "x10/array/DenseIterationSpace_4.x10"
            final long t$104741 = this.min3;
            
            //#line 48 "x10/array/DenseIterationSpace_4.x10"
            return t$104741;
        }
        
        //#line 49 "x10/array/DenseIterationSpace_4.x10"
        final java.lang.String t$104743 = (((x10.core.Long.$box(i))) + (" is not a valid rank"));
        
        //#line 49 "x10/array/DenseIterationSpace_4.x10"
        final x10.lang.IllegalOperationException t$104744 = ((x10.lang.IllegalOperationException)(new x10.lang.IllegalOperationException(t$104743)));
        
        //#line 49 "x10/array/DenseIterationSpace_4.x10"
        throw t$104744;
    }
    
    
    //#line 52 "x10/array/DenseIterationSpace_4.x10"
    public long max$O(final long i) {
        
        //#line 53 "x10/array/DenseIterationSpace_4.x10"
        final boolean t$104746 = ((long) i) == ((long) 0L);
        
        //#line 53 "x10/array/DenseIterationSpace_4.x10"
        if (t$104746) {
            
            //#line 53 "x10/array/DenseIterationSpace_4.x10"
            final long t$104745 = this.max0;
            
            //#line 53 "x10/array/DenseIterationSpace_4.x10"
            return t$104745;
        }
        
        //#line 54 "x10/array/DenseIterationSpace_4.x10"
        final boolean t$104748 = ((long) i) == ((long) 1L);
        
        //#line 54 "x10/array/DenseIterationSpace_4.x10"
        if (t$104748) {
            
            //#line 54 "x10/array/DenseIterationSpace_4.x10"
            final long t$104747 = this.max1;
            
            //#line 54 "x10/array/DenseIterationSpace_4.x10"
            return t$104747;
        }
        
        //#line 55 "x10/array/DenseIterationSpace_4.x10"
        final boolean t$104750 = ((long) i) == ((long) 2L);
        
        //#line 55 "x10/array/DenseIterationSpace_4.x10"
        if (t$104750) {
            
            //#line 55 "x10/array/DenseIterationSpace_4.x10"
            final long t$104749 = this.max2;
            
            //#line 55 "x10/array/DenseIterationSpace_4.x10"
            return t$104749;
        }
        
        //#line 56 "x10/array/DenseIterationSpace_4.x10"
        final boolean t$104752 = ((long) i) == ((long) 3L);
        
        //#line 56 "x10/array/DenseIterationSpace_4.x10"
        if (t$104752) {
            
            //#line 56 "x10/array/DenseIterationSpace_4.x10"
            final long t$104751 = this.max3;
            
            //#line 56 "x10/array/DenseIterationSpace_4.x10"
            return t$104751;
        }
        
        //#line 57 "x10/array/DenseIterationSpace_4.x10"
        final java.lang.String t$104753 = (((x10.core.Long.$box(i))) + (" is not a valid rank"));
        
        //#line 57 "x10/array/DenseIterationSpace_4.x10"
        final x10.lang.IllegalOperationException t$104754 = ((x10.lang.IllegalOperationException)(new x10.lang.IllegalOperationException(t$104753)));
        
        //#line 57 "x10/array/DenseIterationSpace_4.x10"
        throw t$104754;
    }
    
    
    //#line 60 "x10/array/DenseIterationSpace_4.x10"
    public boolean isEmpty$O() {
        
        //#line 60 "x10/array/DenseIterationSpace_4.x10"
        final long t$104755 = this.max0;
        
        //#line 60 "x10/array/DenseIterationSpace_4.x10"
        final long t$104756 = this.min0;
        
        //#line 60 "x10/array/DenseIterationSpace_4.x10"
        boolean t$104759 = ((t$104755) < (((long)(t$104756))));
        
        //#line 60 "x10/array/DenseIterationSpace_4.x10"
        if (!(t$104759)) {
            
            //#line 60 "x10/array/DenseIterationSpace_4.x10"
            final long t$104757 = this.max1;
            
            //#line 60 "x10/array/DenseIterationSpace_4.x10"
            final long t$104758 = this.min1;
            
            //#line 60 "x10/array/DenseIterationSpace_4.x10"
            t$104759 = ((t$104757) < (((long)(t$104758))));
        }
        
        //#line 60 "x10/array/DenseIterationSpace_4.x10"
        boolean t$104762 = t$104759;
        
        //#line 60 "x10/array/DenseIterationSpace_4.x10"
        if (!(t$104759)) {
            
            //#line 60 "x10/array/DenseIterationSpace_4.x10"
            final long t$104760 = this.max2;
            
            //#line 60 "x10/array/DenseIterationSpace_4.x10"
            final long t$104761 = this.min2;
            
            //#line 60 "x10/array/DenseIterationSpace_4.x10"
            t$104762 = ((t$104760) < (((long)(t$104761))));
        }
        
        //#line 60 "x10/array/DenseIterationSpace_4.x10"
        boolean t$104765 = t$104762;
        
        //#line 60 "x10/array/DenseIterationSpace_4.x10"
        if (!(t$104762)) {
            
            //#line 60 "x10/array/DenseIterationSpace_4.x10"
            final long t$104763 = this.max3;
            
            //#line 60 "x10/array/DenseIterationSpace_4.x10"
            final long t$104764 = this.min3;
            
            //#line 60 "x10/array/DenseIterationSpace_4.x10"
            t$104765 = ((t$104763) < (((long)(t$104764))));
        }
        
        //#line 60 "x10/array/DenseIterationSpace_4.x10"
        return t$104765;
    }
    
    
    //#line 62 "x10/array/DenseIterationSpace_4.x10"
    public long size$O() {
        
        //#line 62 "x10/array/DenseIterationSpace_4.x10"
        final long t$104767 = this.max0;
        
        //#line 62 "x10/array/DenseIterationSpace_4.x10"
        final long t$104768 = this.min0;
        
        //#line 62 "x10/array/DenseIterationSpace_4.x10"
        final long t$104769 = ((t$104767) - (((long)(t$104768))));
        
        //#line 62 "x10/array/DenseIterationSpace_4.x10"
        final long t$104773 = ((t$104769) + (((long)(1L))));
        
        //#line 62 "x10/array/DenseIterationSpace_4.x10"
        final long t$104770 = this.max1;
        
        //#line 62 "x10/array/DenseIterationSpace_4.x10"
        final long t$104771 = this.min1;
        
        //#line 62 "x10/array/DenseIterationSpace_4.x10"
        final long t$104772 = ((t$104770) - (((long)(t$104771))));
        
        //#line 62 "x10/array/DenseIterationSpace_4.x10"
        final long t$104774 = ((t$104772) + (((long)(1L))));
        
        //#line 62 "x10/array/DenseIterationSpace_4.x10"
        final long t$104778 = ((t$104773) * (((long)(t$104774))));
        
        //#line 62 "x10/array/DenseIterationSpace_4.x10"
        final long t$104775 = this.max2;
        
        //#line 62 "x10/array/DenseIterationSpace_4.x10"
        final long t$104776 = this.min2;
        
        //#line 62 "x10/array/DenseIterationSpace_4.x10"
        final long t$104777 = ((t$104775) - (((long)(t$104776))));
        
        //#line 62 "x10/array/DenseIterationSpace_4.x10"
        final long t$104779 = ((t$104777) + (((long)(1L))));
        
        //#line 62 "x10/array/DenseIterationSpace_4.x10"
        final long t$104783 = ((t$104778) * (((long)(t$104779))));
        
        //#line 62 "x10/array/DenseIterationSpace_4.x10"
        final long t$104780 = this.max3;
        
        //#line 62 "x10/array/DenseIterationSpace_4.x10"
        final long t$104781 = this.min3;
        
        //#line 62 "x10/array/DenseIterationSpace_4.x10"
        final long t$104782 = ((t$104780) - (((long)(t$104781))));
        
        //#line 62 "x10/array/DenseIterationSpace_4.x10"
        final long t$104784 = ((t$104782) + (((long)(1L))));
        
        //#line 62 "x10/array/DenseIterationSpace_4.x10"
        final long t$104785 = ((t$104783) * (((long)(t$104784))));
        
        //#line 62 "x10/array/DenseIterationSpace_4.x10"
        return t$104785;
    }
    
    
    //#line 64 "x10/array/DenseIterationSpace_4.x10"
    public x10.lang.Iterator iterator() {
        
        //#line 64 "x10/array/DenseIterationSpace_4.x10"
        final x10.array.DenseIterationSpace_4.DIS4_It alloc$102464 = ((x10.array.DenseIterationSpace_4.DIS4_It)(new x10.array.DenseIterationSpace_4.DIS4_It((java.lang.System[]) null)));
        
        //#line 64 "x10/array/DenseIterationSpace_4.x10"
        alloc$102464.x10$array$DenseIterationSpace_4$DIS4_It$$init$S(this);
        
        //#line 64 "x10/array/DenseIterationSpace_4.x10"
        return alloc$102464;
    }
    
    
    //#line 66 "x10/array/DenseIterationSpace_4.x10"
    @x10.runtime.impl.java.X10Generated
    public static class DIS4_It extends x10.core.Ref implements x10.lang.Iterator, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<DIS4_It> $RTT = 
            x10.rtt.NamedType.<DIS4_It> make("x10.array.DenseIterationSpace_4.DIS4_It",
                                             DIS4_It.class,
                                             new x10.rtt.Type[] {
                                                 x10.rtt.ParameterizedType.make(x10.lang.Iterator.$RTT, x10.lang.Point.$RTT)
                                             });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static x10.serialization.X10JavaSerializable $_deserialize_body(x10.array.DenseIterationSpace_4.DIS4_It $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            $_obj.cur0 = $deserializer.readLong();
            $_obj.cur1 = $deserializer.readLong();
            $_obj.cur2 = $deserializer.readLong();
            $_obj.cur3 = $deserializer.readLong();
            $_obj.out$ = $deserializer.readObject();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.array.DenseIterationSpace_4.DIS4_It $_obj = new x10.array.DenseIterationSpace_4.DIS4_It((java.lang.System[]) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            $serializer.write(this.cur0);
            $serializer.write(this.cur1);
            $serializer.write(this.cur2);
            $serializer.write(this.cur3);
            $serializer.write(this.out$);
            
        }
        
        // constructor just for allocation
        public DIS4_It(final java.lang.System[] $dummy) {
            
        }
        
        // bridge for method abstract public x10.lang.Iterator[T].next(){}:T
        public x10.lang.Point next$G() {
            return next();
        }
        
        
    
        
        //#line 18 "x10/array/DenseIterationSpace_4.x10"
        public x10.array.DenseIterationSpace_4 out$;
        
        //#line 67 "x10/array/DenseIterationSpace_4.x10"
        public long cur0;
        
        //#line 68 "x10/array/DenseIterationSpace_4.x10"
        public long cur1;
        
        //#line 69 "x10/array/DenseIterationSpace_4.x10"
        public long cur2;
        
        //#line 70 "x10/array/DenseIterationSpace_4.x10"
        public long cur3;
        
        
        //#line 72 "x10/array/DenseIterationSpace_4.x10"
        // creation method for java code (1-phase java constructor)
        public DIS4_It(final x10.array.DenseIterationSpace_4 out$) {
            this((java.lang.System[]) null);
            x10$array$DenseIterationSpace_4$DIS4_It$$init$S(out$);
        }
        
        // constructor for non-virtual call
        final public x10.array.DenseIterationSpace_4.DIS4_It x10$array$DenseIterationSpace_4$DIS4_It$$init$S(final x10.array.DenseIterationSpace_4 out$) {
             {
                
                //#line 18 "x10/array/DenseIterationSpace_4.x10"
                this.out$ = out$;
                
                //#line 72 "x10/array/DenseIterationSpace_4.x10"
                
                
                //#line 66 "x10/array/DenseIterationSpace_4.x10"
                final x10.array.DenseIterationSpace_4.DIS4_It this$104862 = this;
                
                //#line 66 "x10/array/DenseIterationSpace_4.x10"
                this$104862.cur0 = 0L;
                
                //#line 66 "x10/array/DenseIterationSpace_4.x10"
                this$104862.cur1 = 0L;
                
                //#line 66 "x10/array/DenseIterationSpace_4.x10"
                this$104862.cur2 = 0L;
                
                //#line 66 "x10/array/DenseIterationSpace_4.x10"
                this$104862.cur3 = 0L;
                
                //#line 73 "x10/array/DenseIterationSpace_4.x10"
                final x10.array.DenseIterationSpace_4 t$104786 = this.out$;
                
                //#line 73 "x10/array/DenseIterationSpace_4.x10"
                final long t$104787 = t$104786.min0;
                
                //#line 73 "x10/array/DenseIterationSpace_4.x10"
                this.cur0 = t$104787;
                
                //#line 74 "x10/array/DenseIterationSpace_4.x10"
                final x10.array.DenseIterationSpace_4 t$104788 = this.out$;
                
                //#line 74 "x10/array/DenseIterationSpace_4.x10"
                final long t$104789 = t$104788.min1;
                
                //#line 74 "x10/array/DenseIterationSpace_4.x10"
                this.cur1 = t$104789;
                
                //#line 75 "x10/array/DenseIterationSpace_4.x10"
                final x10.array.DenseIterationSpace_4 t$104790 = this.out$;
                
                //#line 75 "x10/array/DenseIterationSpace_4.x10"
                final long t$104791 = t$104790.min2;
                
                //#line 75 "x10/array/DenseIterationSpace_4.x10"
                this.cur2 = t$104791;
                
                //#line 76 "x10/array/DenseIterationSpace_4.x10"
                final x10.array.DenseIterationSpace_4 t$104792 = this.out$;
                
                //#line 76 "x10/array/DenseIterationSpace_4.x10"
                final long t$104793 = t$104792.min3;
                
                //#line 76 "x10/array/DenseIterationSpace_4.x10"
                this.cur3 = t$104793;
            }
            return this;
        }
        
        
        
        //#line 79 "x10/array/DenseIterationSpace_4.x10"
        public boolean hasNext$O() {
            
            //#line 79 "x10/array/DenseIterationSpace_4.x10"
            final long t$104795 = this.cur0;
            
            //#line 79 "x10/array/DenseIterationSpace_4.x10"
            final x10.array.DenseIterationSpace_4 t$104794 = this.out$;
            
            //#line 79 "x10/array/DenseIterationSpace_4.x10"
            final long t$104796 = t$104794.max0;
            
            //#line 79 "x10/array/DenseIterationSpace_4.x10"
            boolean t$104800 = ((t$104795) <= (((long)(t$104796))));
            
            //#line 79 "x10/array/DenseIterationSpace_4.x10"
            if (t$104800) {
                
                //#line 79 "x10/array/DenseIterationSpace_4.x10"
                final long t$104798 = this.cur1;
                
                //#line 79 "x10/array/DenseIterationSpace_4.x10"
                final x10.array.DenseIterationSpace_4 t$104797 = this.out$;
                
                //#line 79 "x10/array/DenseIterationSpace_4.x10"
                final long t$104799 = t$104797.max1;
                
                //#line 79 "x10/array/DenseIterationSpace_4.x10"
                t$104800 = ((t$104798) <= (((long)(t$104799))));
            }
            
            //#line 79 "x10/array/DenseIterationSpace_4.x10"
            boolean t$104804 = t$104800;
            
            //#line 79 "x10/array/DenseIterationSpace_4.x10"
            if (t$104800) {
                
                //#line 79 "x10/array/DenseIterationSpace_4.x10"
                final long t$104802 = this.cur2;
                
                //#line 79 "x10/array/DenseIterationSpace_4.x10"
                final x10.array.DenseIterationSpace_4 t$104801 = this.out$;
                
                //#line 79 "x10/array/DenseIterationSpace_4.x10"
                final long t$104803 = t$104801.max2;
                
                //#line 79 "x10/array/DenseIterationSpace_4.x10"
                t$104804 = ((t$104802) <= (((long)(t$104803))));
            }
            
            //#line 79 "x10/array/DenseIterationSpace_4.x10"
            boolean t$104808 = t$104804;
            
            //#line 79 "x10/array/DenseIterationSpace_4.x10"
            if (t$104804) {
                
                //#line 79 "x10/array/DenseIterationSpace_4.x10"
                final long t$104806 = this.cur3;
                
                //#line 79 "x10/array/DenseIterationSpace_4.x10"
                final x10.array.DenseIterationSpace_4 t$104805 = this.out$;
                
                //#line 79 "x10/array/DenseIterationSpace_4.x10"
                final long t$104807 = t$104805.max3;
                
                //#line 79 "x10/array/DenseIterationSpace_4.x10"
                t$104808 = ((t$104806) <= (((long)(t$104807))));
            }
            
            //#line 79 "x10/array/DenseIterationSpace_4.x10"
            return t$104808;
        }
        
        
        //#line 81 "x10/array/DenseIterationSpace_4.x10"
        public x10.lang.Point next() {
            
            //#line 82 "x10/array/DenseIterationSpace_4.x10"
            final long i$104729 = this.cur0;
            
            //#line 82 "x10/array/DenseIterationSpace_4.x10"
            final long i$104730 = this.cur1;
            
            //#line 82 "x10/array/DenseIterationSpace_4.x10"
            final long i$104731 = this.cur2;
            
            //#line 82 "x10/array/DenseIterationSpace_4.x10"
            final long i$104732 = this.cur3;
            
            //#line 154 . "x10/lang/Point.x10"
            final x10.lang.Point alloc$104733 = ((x10.lang.Point)(new x10.lang.Point((java.lang.System[]) null)));
            
            //#line 154 . "x10/lang/Point.x10"
            alloc$104733.x10$lang$Point$$init$S(((long)(i$104729)), ((long)(i$104730)), ((long)(i$104731)), ((long)(i$104732)));
            
            //#line 83 "x10/array/DenseIterationSpace_4.x10"
            final long t$104810 = this.cur3;
            
            //#line 83 "x10/array/DenseIterationSpace_4.x10"
            final long t$104811 = ((t$104810) + (((long)(1L))));
            
            //#line 83 "x10/array/DenseIterationSpace_4.x10"
            this.cur3 = t$104811;
            
            //#line 84 "x10/array/DenseIterationSpace_4.x10"
            final long t$104813 = this.cur3;
            
            //#line 84 "x10/array/DenseIterationSpace_4.x10"
            final x10.array.DenseIterationSpace_4 t$104812 = this.out$;
            
            //#line 84 "x10/array/DenseIterationSpace_4.x10"
            final long t$104814 = t$104812.max3;
            
            //#line 84 "x10/array/DenseIterationSpace_4.x10"
            final boolean t$104835 = ((t$104813) > (((long)(t$104814))));
            
            //#line 84 "x10/array/DenseIterationSpace_4.x10"
            if (t$104835) {
                
                //#line 85 "x10/array/DenseIterationSpace_4.x10"
                final x10.array.DenseIterationSpace_4 t$104815 = this.out$;
                
                //#line 85 "x10/array/DenseIterationSpace_4.x10"
                final long t$104816 = t$104815.min3;
                
                //#line 85 "x10/array/DenseIterationSpace_4.x10"
                this.cur3 = t$104816;
                
                //#line 86 "x10/array/DenseIterationSpace_4.x10"
                final long t$104817 = this.cur2;
                
                //#line 86 "x10/array/DenseIterationSpace_4.x10"
                final long t$104818 = ((t$104817) + (((long)(1L))));
                
                //#line 86 "x10/array/DenseIterationSpace_4.x10"
                this.cur2 = t$104818;
                
                //#line 87 "x10/array/DenseIterationSpace_4.x10"
                final long t$104820 = this.cur2;
                
                //#line 87 "x10/array/DenseIterationSpace_4.x10"
                final x10.array.DenseIterationSpace_4 t$104819 = this.out$;
                
                //#line 87 "x10/array/DenseIterationSpace_4.x10"
                final long t$104821 = t$104819.max2;
                
                //#line 87 "x10/array/DenseIterationSpace_4.x10"
                final boolean t$104834 = ((t$104820) > (((long)(t$104821))));
                
                //#line 87 "x10/array/DenseIterationSpace_4.x10"
                if (t$104834) {
                    
                    //#line 88 "x10/array/DenseIterationSpace_4.x10"
                    final x10.array.DenseIterationSpace_4 t$104822 = this.out$;
                    
                    //#line 88 "x10/array/DenseIterationSpace_4.x10"
                    final long t$104823 = t$104822.min2;
                    
                    //#line 88 "x10/array/DenseIterationSpace_4.x10"
                    this.cur2 = t$104823;
                    
                    //#line 89 "x10/array/DenseIterationSpace_4.x10"
                    final long t$104824 = this.cur1;
                    
                    //#line 89 "x10/array/DenseIterationSpace_4.x10"
                    final long t$104825 = ((t$104824) + (((long)(1L))));
                    
                    //#line 89 "x10/array/DenseIterationSpace_4.x10"
                    this.cur1 = t$104825;
                    
                    //#line 90 "x10/array/DenseIterationSpace_4.x10"
                    final long t$104827 = this.cur1;
                    
                    //#line 90 "x10/array/DenseIterationSpace_4.x10"
                    final x10.array.DenseIterationSpace_4 t$104826 = this.out$;
                    
                    //#line 90 "x10/array/DenseIterationSpace_4.x10"
                    final long t$104828 = t$104826.max1;
                    
                    //#line 90 "x10/array/DenseIterationSpace_4.x10"
                    final boolean t$104833 = ((t$104827) > (((long)(t$104828))));
                    
                    //#line 90 "x10/array/DenseIterationSpace_4.x10"
                    if (t$104833) {
                        
                        //#line 91 "x10/array/DenseIterationSpace_4.x10"
                        final x10.array.DenseIterationSpace_4 t$104829 = this.out$;
                        
                        //#line 91 "x10/array/DenseIterationSpace_4.x10"
                        final long t$104830 = t$104829.min1;
                        
                        //#line 91 "x10/array/DenseIterationSpace_4.x10"
                        this.cur1 = t$104830;
                        
                        //#line 92 "x10/array/DenseIterationSpace_4.x10"
                        final long t$104831 = this.cur0;
                        
                        //#line 92 "x10/array/DenseIterationSpace_4.x10"
                        final long t$104832 = ((t$104831) + (((long)(1L))));
                        
                        //#line 92 "x10/array/DenseIterationSpace_4.x10"
                        this.cur0 = t$104832;
                    }
                }
            }
            
            //#line 96 "x10/array/DenseIterationSpace_4.x10"
            return alloc$104733;
        }
        
        
        //#line 66 "x10/array/DenseIterationSpace_4.x10"
        final public x10.array.DenseIterationSpace_4.DIS4_It x10$array$DenseIterationSpace_4$DIS4_It$$this$x10$array$DenseIterationSpace_4$DIS4_It() {
            
            //#line 66 "x10/array/DenseIterationSpace_4.x10"
            return x10.array.DenseIterationSpace_4.DIS4_It.this;
        }
        
        
        //#line 66 "x10/array/DenseIterationSpace_4.x10"
        final public x10.array.DenseIterationSpace_4 x10$array$DenseIterationSpace_4$DIS4_It$$this$x10$array$DenseIterationSpace_4() {
            
            //#line 66 "x10/array/DenseIterationSpace_4.x10"
            final x10.array.DenseIterationSpace_4 t$104836 = this.out$;
            
            //#line 66 "x10/array/DenseIterationSpace_4.x10"
            return t$104836;
        }
        
        
        //#line 66 "x10/array/DenseIterationSpace_4.x10"
        final public void __fieldInitializers_x10_array_DenseIterationSpace_4_DIS4_It() {
            
            //#line 66 "x10/array/DenseIterationSpace_4.x10"
            this.cur0 = 0L;
            
            //#line 66 "x10/array/DenseIterationSpace_4.x10"
            this.cur1 = 0L;
            
            //#line 66 "x10/array/DenseIterationSpace_4.x10"
            this.cur2 = 0L;
            
            //#line 66 "x10/array/DenseIterationSpace_4.x10"
            this.cur3 = 0L;
        }
    }
    
    
    
    //#line 100 "x10/array/DenseIterationSpace_4.x10"
    public java.lang.String toString() {
        
        //#line 102 "x10/array/DenseIterationSpace_4.x10"
        final long t$104837 = this.min0;
        
        //#line 101 "x10/array/DenseIterationSpace_4.x10"
        final java.lang.String t$104838 = (("[") + ((x10.core.Long.$box(t$104837))));
        
        //#line 101 "x10/array/DenseIterationSpace_4.x10"
        final java.lang.String t$104839 = ((t$104838) + (".."));
        
        //#line 102 "x10/array/DenseIterationSpace_4.x10"
        final long t$104840 = this.max0;
        
        //#line 101 "x10/array/DenseIterationSpace_4.x10"
        final java.lang.String t$104841 = ((t$104839) + ((x10.core.Long.$box(t$104840))));
        
        //#line 101 "x10/array/DenseIterationSpace_4.x10"
        final java.lang.String t$104842 = ((t$104841) + (","));
        
        //#line 103 "x10/array/DenseIterationSpace_4.x10"
        final long t$104843 = this.min1;
        
        //#line 101 "x10/array/DenseIterationSpace_4.x10"
        final java.lang.String t$104844 = ((t$104842) + ((x10.core.Long.$box(t$104843))));
        
        //#line 101 "x10/array/DenseIterationSpace_4.x10"
        final java.lang.String t$104845 = ((t$104844) + (".."));
        
        //#line 103 "x10/array/DenseIterationSpace_4.x10"
        final long t$104846 = this.max1;
        
        //#line 101 "x10/array/DenseIterationSpace_4.x10"
        final java.lang.String t$104847 = ((t$104845) + ((x10.core.Long.$box(t$104846))));
        
        //#line 101 "x10/array/DenseIterationSpace_4.x10"
        final java.lang.String t$104848 = ((t$104847) + (","));
        
        //#line 104 "x10/array/DenseIterationSpace_4.x10"
        final long t$104849 = this.min2;
        
        //#line 101 "x10/array/DenseIterationSpace_4.x10"
        final java.lang.String t$104850 = ((t$104848) + ((x10.core.Long.$box(t$104849))));
        
        //#line 101 "x10/array/DenseIterationSpace_4.x10"
        final java.lang.String t$104851 = ((t$104850) + (".."));
        
        //#line 104 "x10/array/DenseIterationSpace_4.x10"
        final long t$104852 = this.max2;
        
        //#line 101 "x10/array/DenseIterationSpace_4.x10"
        final java.lang.String t$104853 = ((t$104851) + ((x10.core.Long.$box(t$104852))));
        
        //#line 101 "x10/array/DenseIterationSpace_4.x10"
        final java.lang.String t$104854 = ((t$104853) + (","));
        
        //#line 105 "x10/array/DenseIterationSpace_4.x10"
        final long t$104855 = this.min3;
        
        //#line 101 "x10/array/DenseIterationSpace_4.x10"
        final java.lang.String t$104856 = ((t$104854) + ((x10.core.Long.$box(t$104855))));
        
        //#line 101 "x10/array/DenseIterationSpace_4.x10"
        final java.lang.String t$104857 = ((t$104856) + (".."));
        
        //#line 105 "x10/array/DenseIterationSpace_4.x10"
        final long t$104858 = this.max3;
        
        //#line 101 "x10/array/DenseIterationSpace_4.x10"
        final java.lang.String t$104859 = ((t$104857) + ((x10.core.Long.$box(t$104858))));
        
        //#line 101 "x10/array/DenseIterationSpace_4.x10"
        final java.lang.String t$104860 = ((t$104859) + ("]"));
        
        //#line 101 "x10/array/DenseIterationSpace_4.x10"
        return t$104860;
    }
    
    
    //#line 18 "x10/array/DenseIterationSpace_4.x10"
    final public x10.array.DenseIterationSpace_4 x10$array$DenseIterationSpace_4$$this$x10$array$DenseIterationSpace_4() {
        
        //#line 18 "x10/array/DenseIterationSpace_4.x10"
        return x10.array.DenseIterationSpace_4.this;
    }
    
    
    //#line 18 "x10/array/DenseIterationSpace_4.x10"
    final public void __fieldInitializers_x10_array_DenseIterationSpace_4() {
        
    }
    
    final private static x10.core.concurrent.AtomicInteger initStatus$EMPTY = new x10.core.concurrent.AtomicInteger(x10.runtime.impl.java.InitDispatcher.UNINITIALIZED);
    private static x10.lang.ExceptionInInitializer exception$EMPTY;
    
    public static x10.array.DenseIterationSpace_4 get$EMPTY() {
        if (((int) x10.array.DenseIterationSpace_4.initStatus$EMPTY.get()) == ((int) x10.runtime.impl.java.InitDispatcher.INITIALIZED)) {
            return x10.array.DenseIterationSpace_4.EMPTY;
        }
        if (((int) x10.array.DenseIterationSpace_4.initStatus$EMPTY.get()) == ((int) x10.runtime.impl.java.InitDispatcher.EXCEPTION_RAISED)) {
            throw x10.array.DenseIterationSpace_4.exception$EMPTY;
        }
        if (x10.array.DenseIterationSpace_4.initStatus$EMPTY.compareAndSet((int)(x10.runtime.impl.java.InitDispatcher.UNINITIALIZED), (int)(x10.runtime.impl.java.InitDispatcher.INITIALIZING))) {
            try {{
                x10.array.DenseIterationSpace_4.EMPTY = ((x10.array.DenseIterationSpace_4)(new x10.array.DenseIterationSpace_4((java.lang.System[]) null).x10$array$DenseIterationSpace_4$$init$S(((long)(0L)), ((long)(0L)), ((long)(0L)), ((long)(0L)), ((long)(-1L)), ((long)(-1L)), ((long)(-1L)), ((long)(-1L)))));
            }}catch (java.lang.Throwable exc$104863) {
                x10.array.DenseIterationSpace_4.exception$EMPTY = new x10.lang.ExceptionInInitializer(exc$104863);
                x10.array.DenseIterationSpace_4.initStatus$EMPTY.set((int)(x10.runtime.impl.java.InitDispatcher.EXCEPTION_RAISED));
                x10.runtime.impl.java.InitDispatcher.lockInitialized();
                x10.runtime.impl.java.InitDispatcher.notifyInitialized();
                throw x10.array.DenseIterationSpace_4.exception$EMPTY;
            }
            x10.array.DenseIterationSpace_4.initStatus$EMPTY.set((int)(x10.runtime.impl.java.InitDispatcher.INITIALIZED));
            x10.runtime.impl.java.InitDispatcher.lockInitialized();
            x10.runtime.impl.java.InitDispatcher.notifyInitialized();
        } else {
            if (x10.array.DenseIterationSpace_4.initStatus$EMPTY.get() < x10.runtime.impl.java.InitDispatcher.INITIALIZED) {
                x10.runtime.impl.java.InitDispatcher.lockInitialized();
                while (x10.array.DenseIterationSpace_4.initStatus$EMPTY.get() < x10.runtime.impl.java.InitDispatcher.INITIALIZED) {
                    x10.runtime.impl.java.InitDispatcher.awaitInitialized();
                }
                x10.runtime.impl.java.InitDispatcher.unlockInitialized();
                if (((int) x10.array.DenseIterationSpace_4.initStatus$EMPTY.get()) == ((int) x10.runtime.impl.java.InitDispatcher.EXCEPTION_RAISED)) {
                    throw x10.array.DenseIterationSpace_4.exception$EMPTY;
                }
            }
        }
        return x10.array.DenseIterationSpace_4.EMPTY;
    }
}

