package x10.array;

/**
 * A DenseIterationSpace_2 represents the rank 2 
 * iteration space of points [min0,min1]..[max0,max1] inclusive.
 */
@x10.runtime.impl.java.X10Generated
final public class DenseIterationSpace_2 extends x10.array.IterationSpace implements x10.serialization.X10JavaSerializable
{
    public static final x10.rtt.RuntimeType<DenseIterationSpace_2> $RTT = 
        x10.rtt.NamedType.<DenseIterationSpace_2> make("x10.array.DenseIterationSpace_2",
                                                       DenseIterationSpace_2.class,
                                                       new x10.rtt.Type[] {
                                                           x10.array.IterationSpace.$RTT
                                                       });
    
    public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
    
    public x10.rtt.Type<?> $getParam(int i) { return null; }
    
    private Object writeReplace() throws java.io.ObjectStreamException {
        return new x10.serialization.SerializationProxy(this);
    }
    
    public static x10.serialization.X10JavaSerializable $_deserialize_body(x10.array.DenseIterationSpace_2 $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
        x10.array.IterationSpace.$_deserialize_body($_obj, $deserializer);
        $_obj.max0 = $deserializer.readLong();
        $_obj.max1 = $deserializer.readLong();
        $_obj.min0 = $deserializer.readLong();
        $_obj.min1 = $deserializer.readLong();
        return $_obj;
    }
    
    public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
        x10.array.DenseIterationSpace_2 $_obj = new x10.array.DenseIterationSpace_2((java.lang.System[]) null);
        $deserializer.record_reference($_obj);
        return $_deserialize_body($_obj, $deserializer);
    }
    
    public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
        super.$_serialize($serializer);
        $serializer.write(this.max0);
        $serializer.write(this.max1);
        $serializer.write(this.min0);
        $serializer.write(this.min1);
        
    }
    
    // constructor just for allocation
    public DenseIterationSpace_2(final java.lang.System[] $dummy) {
        super($dummy);
        
    }
    
    

    
    //#line 20 "x10/array/DenseIterationSpace_2.x10"
    public long min0;
    
    //#line 21 "x10/array/DenseIterationSpace_2.x10"
    public long min1;
    
    //#line 22 "x10/array/DenseIterationSpace_2.x10"
    public long max0;
    
    //#line 23 "x10/array/DenseIterationSpace_2.x10"
    public long max1;
    
    //#line 25 "x10/array/DenseIterationSpace_2.x10"
    private static x10.array.DenseIterationSpace_2 EMPTY;
    
    
    //#line 27 "x10/array/DenseIterationSpace_2.x10"
    // creation method for java code (1-phase java constructor)
    public DenseIterationSpace_2(final long min0, final long min1, final long max0, final long max1) {
        this((java.lang.System[]) null);
        x10$array$DenseIterationSpace_2$$init$S(min0, min1, max0, max1);
    }
    
    // constructor for non-virtual call
    final public x10.array.DenseIterationSpace_2 x10$array$DenseIterationSpace_2$$init$S(final long min0, final long min1, final long max0, final long max1) {
         {
            
            //#line 28 "x10/array/DenseIterationSpace_2.x10"
            final x10.array.IterationSpace this$104505 = ((x10.array.IterationSpace)(this));
            
            //#line 22 . "x10/array/IterationSpace.x10"
            this$104505.rank = 2L;
            
            //#line 22 . "x10/array/IterationSpace.x10"
            this$104505.rect = true;
            
            //#line 27 "x10/array/DenseIterationSpace_2.x10"
            
            
            //#line 29 "x10/array/DenseIterationSpace_2.x10"
            this.min0 = min0;
            
            //#line 30 "x10/array/DenseIterationSpace_2.x10"
            this.min1 = min1;
            
            //#line 31 "x10/array/DenseIterationSpace_2.x10"
            this.max0 = max0;
            
            //#line 32 "x10/array/DenseIterationSpace_2.x10"
            this.max1 = max1;
        }
        return this;
    }
    
    
    
    //#line 35 "x10/array/DenseIterationSpace_2.x10"
    public x10.array.DenseIterationSpace_3 $times(final x10.lang.LongRange that) {
        
        //#line 36 "x10/array/DenseIterationSpace_2.x10"
        final x10.array.DenseIterationSpace_3 alloc$99454 = ((x10.array.DenseIterationSpace_3)(new x10.array.DenseIterationSpace_3((java.lang.System[]) null)));
        
        //#line 36 "x10/array/DenseIterationSpace_2.x10"
        final long t$104585 = this.min0;
        
        //#line 36 "x10/array/DenseIterationSpace_2.x10"
        final long t$104586 = this.min1;
        
        //#line 36 "x10/array/DenseIterationSpace_2.x10"
        final long t$104587 = that.min;
        
        //#line 36 "x10/array/DenseIterationSpace_2.x10"
        final long t$104588 = this.max0;
        
        //#line 36 "x10/array/DenseIterationSpace_2.x10"
        final long t$104589 = this.max1;
        
        //#line 36 "x10/array/DenseIterationSpace_2.x10"
        final long t$104590 = that.max;
        
        //#line 36 "x10/array/DenseIterationSpace_2.x10"
        alloc$99454.x10$array$DenseIterationSpace_3$$init$S(((long)(t$104585)), ((long)(t$104586)), ((long)(t$104587)), ((long)(t$104588)), ((long)(t$104589)), ((long)(t$104590)));
        
        //#line 36 "x10/array/DenseIterationSpace_2.x10"
        return alloc$99454;
    }
    
    
    //#line 39 "x10/array/DenseIterationSpace_2.x10"
    public long min$O(final long i) {
        
        //#line 40 "x10/array/DenseIterationSpace_2.x10"
        final boolean t$104523 = ((long) i) == ((long) 0L);
        
        //#line 40 "x10/array/DenseIterationSpace_2.x10"
        if (t$104523) {
            
            //#line 40 "x10/array/DenseIterationSpace_2.x10"
            final long t$104522 = this.min0;
            
            //#line 40 "x10/array/DenseIterationSpace_2.x10"
            return t$104522;
        }
        
        //#line 41 "x10/array/DenseIterationSpace_2.x10"
        final boolean t$104525 = ((long) i) == ((long) 1L);
        
        //#line 41 "x10/array/DenseIterationSpace_2.x10"
        if (t$104525) {
            
            //#line 41 "x10/array/DenseIterationSpace_2.x10"
            final long t$104524 = this.min1;
            
            //#line 41 "x10/array/DenseIterationSpace_2.x10"
            return t$104524;
        }
        
        //#line 42 "x10/array/DenseIterationSpace_2.x10"
        final java.lang.String t$104526 = (((x10.core.Long.$box(i))) + (" is not a valid rank"));
        
        //#line 42 "x10/array/DenseIterationSpace_2.x10"
        final x10.lang.IllegalOperationException t$104527 = ((x10.lang.IllegalOperationException)(new x10.lang.IllegalOperationException(t$104526)));
        
        //#line 42 "x10/array/DenseIterationSpace_2.x10"
        throw t$104527;
    }
    
    
    //#line 45 "x10/array/DenseIterationSpace_2.x10"
    public long max$O(final long i) {
        
        //#line 46 "x10/array/DenseIterationSpace_2.x10"
        final boolean t$104529 = ((long) i) == ((long) 0L);
        
        //#line 46 "x10/array/DenseIterationSpace_2.x10"
        if (t$104529) {
            
            //#line 46 "x10/array/DenseIterationSpace_2.x10"
            final long t$104528 = this.max0;
            
            //#line 46 "x10/array/DenseIterationSpace_2.x10"
            return t$104528;
        }
        
        //#line 47 "x10/array/DenseIterationSpace_2.x10"
        final boolean t$104531 = ((long) i) == ((long) 1L);
        
        //#line 47 "x10/array/DenseIterationSpace_2.x10"
        if (t$104531) {
            
            //#line 47 "x10/array/DenseIterationSpace_2.x10"
            final long t$104530 = this.max1;
            
            //#line 47 "x10/array/DenseIterationSpace_2.x10"
            return t$104530;
        }
        
        //#line 48 "x10/array/DenseIterationSpace_2.x10"
        final java.lang.String t$104532 = (((x10.core.Long.$box(i))) + (" is not a valid rank"));
        
        //#line 48 "x10/array/DenseIterationSpace_2.x10"
        final x10.lang.IllegalOperationException t$104533 = ((x10.lang.IllegalOperationException)(new x10.lang.IllegalOperationException(t$104532)));
        
        //#line 48 "x10/array/DenseIterationSpace_2.x10"
        throw t$104533;
    }
    
    
    //#line 51 "x10/array/DenseIterationSpace_2.x10"
    public boolean isEmpty$O() {
        
        //#line 51 "x10/array/DenseIterationSpace_2.x10"
        final long t$104534 = this.max0;
        
        //#line 51 "x10/array/DenseIterationSpace_2.x10"
        final long t$104535 = this.min0;
        
        //#line 51 "x10/array/DenseIterationSpace_2.x10"
        boolean t$104538 = ((t$104534) < (((long)(t$104535))));
        
        //#line 51 "x10/array/DenseIterationSpace_2.x10"
        if (!(t$104538)) {
            
            //#line 51 "x10/array/DenseIterationSpace_2.x10"
            final long t$104536 = this.max1;
            
            //#line 51 "x10/array/DenseIterationSpace_2.x10"
            final long t$104537 = this.min1;
            
            //#line 51 "x10/array/DenseIterationSpace_2.x10"
            t$104538 = ((t$104536) < (((long)(t$104537))));
        }
        
        //#line 51 "x10/array/DenseIterationSpace_2.x10"
        return t$104538;
    }
    
    
    //#line 53 "x10/array/DenseIterationSpace_2.x10"
    public long size$O() {
        
        //#line 53 "x10/array/DenseIterationSpace_2.x10"
        final long t$104540 = this.max0;
        
        //#line 53 "x10/array/DenseIterationSpace_2.x10"
        final long t$104541 = this.min0;
        
        //#line 53 "x10/array/DenseIterationSpace_2.x10"
        final long t$104542 = ((t$104540) - (((long)(t$104541))));
        
        //#line 53 "x10/array/DenseIterationSpace_2.x10"
        final long t$104546 = ((t$104542) + (((long)(1L))));
        
        //#line 53 "x10/array/DenseIterationSpace_2.x10"
        final long t$104543 = this.max1;
        
        //#line 53 "x10/array/DenseIterationSpace_2.x10"
        final long t$104544 = this.min1;
        
        //#line 53 "x10/array/DenseIterationSpace_2.x10"
        final long t$104545 = ((t$104543) - (((long)(t$104544))));
        
        //#line 53 "x10/array/DenseIterationSpace_2.x10"
        final long t$104547 = ((t$104545) + (((long)(1L))));
        
        //#line 53 "x10/array/DenseIterationSpace_2.x10"
        final long t$104548 = ((t$104546) * (((long)(t$104547))));
        
        //#line 53 "x10/array/DenseIterationSpace_2.x10"
        return t$104548;
    }
    
    
    //#line 55 "x10/array/DenseIterationSpace_2.x10"
    public x10.lang.Iterator iterator() {
        
        //#line 55 "x10/array/DenseIterationSpace_2.x10"
        final x10.array.DenseIterationSpace_2.DIS2_It alloc$99455 = ((x10.array.DenseIterationSpace_2.DIS2_It)(new x10.array.DenseIterationSpace_2.DIS2_It((java.lang.System[]) null)));
        
        //#line 55 "x10/array/DenseIterationSpace_2.x10"
        alloc$99455.x10$array$DenseIterationSpace_2$DIS2_It$$init$S(this);
        
        //#line 55 "x10/array/DenseIterationSpace_2.x10"
        return alloc$99455;
    }
    
    
    //#line 57 "x10/array/DenseIterationSpace_2.x10"
    @x10.runtime.impl.java.X10Generated
    public static class DIS2_It extends x10.core.Ref implements x10.lang.Iterator, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<DIS2_It> $RTT = 
            x10.rtt.NamedType.<DIS2_It> make("x10.array.DenseIterationSpace_2.DIS2_It",
                                             DIS2_It.class,
                                             new x10.rtt.Type[] {
                                                 x10.rtt.ParameterizedType.make(x10.lang.Iterator.$RTT, x10.lang.Point.$RTT)
                                             });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static x10.serialization.X10JavaSerializable $_deserialize_body(x10.array.DenseIterationSpace_2.DIS2_It $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            $_obj.cur0 = $deserializer.readLong();
            $_obj.cur1 = $deserializer.readLong();
            $_obj.out$ = $deserializer.readObject();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.array.DenseIterationSpace_2.DIS2_It $_obj = new x10.array.DenseIterationSpace_2.DIS2_It((java.lang.System[]) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            $serializer.write(this.cur0);
            $serializer.write(this.cur1);
            $serializer.write(this.out$);
            
        }
        
        // constructor just for allocation
        public DIS2_It(final java.lang.System[] $dummy) {
            
        }
        
        // bridge for method abstract public x10.lang.Iterator[T].next(){}:T
        public x10.lang.Point next$G() {
            return next();
        }
        
        
    
        
        //#line 18 "x10/array/DenseIterationSpace_2.x10"
        public x10.array.DenseIterationSpace_2 out$;
        
        //#line 58 "x10/array/DenseIterationSpace_2.x10"
        public long cur0;
        
        //#line 59 "x10/array/DenseIterationSpace_2.x10"
        public long cur1;
        
        
        //#line 61 "x10/array/DenseIterationSpace_2.x10"
        // creation method for java code (1-phase java constructor)
        public DIS2_It(final x10.array.DenseIterationSpace_2 out$) {
            this((java.lang.System[]) null);
            x10$array$DenseIterationSpace_2$DIS2_It$$init$S(out$);
        }
        
        // constructor for non-virtual call
        final public x10.array.DenseIterationSpace_2.DIS2_It x10$array$DenseIterationSpace_2$DIS2_It$$init$S(final x10.array.DenseIterationSpace_2 out$) {
             {
                
                //#line 18 "x10/array/DenseIterationSpace_2.x10"
                this.out$ = out$;
                
                //#line 61 "x10/array/DenseIterationSpace_2.x10"
                
                
                //#line 57 "x10/array/DenseIterationSpace_2.x10"
                final x10.array.DenseIterationSpace_2.DIS2_It this$104591 = this;
                
                //#line 57 "x10/array/DenseIterationSpace_2.x10"
                this$104591.cur0 = 0L;
                
                //#line 57 "x10/array/DenseIterationSpace_2.x10"
                this$104591.cur1 = 0L;
                
                //#line 62 "x10/array/DenseIterationSpace_2.x10"
                final x10.array.DenseIterationSpace_2 t$104549 = this.out$;
                
                //#line 62 "x10/array/DenseIterationSpace_2.x10"
                final long t$104550 = t$104549.min0;
                
                //#line 62 "x10/array/DenseIterationSpace_2.x10"
                this.cur0 = t$104550;
                
                //#line 63 "x10/array/DenseIterationSpace_2.x10"
                final x10.array.DenseIterationSpace_2 t$104551 = this.out$;
                
                //#line 63 "x10/array/DenseIterationSpace_2.x10"
                final long t$104552 = t$104551.min1;
                
                //#line 63 "x10/array/DenseIterationSpace_2.x10"
                this.cur1 = t$104552;
            }
            return this;
        }
        
        
        
        //#line 66 "x10/array/DenseIterationSpace_2.x10"
        public boolean hasNext$O() {
            
            //#line 66 "x10/array/DenseIterationSpace_2.x10"
            final long t$104554 = this.cur0;
            
            //#line 66 "x10/array/DenseIterationSpace_2.x10"
            final x10.array.DenseIterationSpace_2 t$104553 = this.out$;
            
            //#line 66 "x10/array/DenseIterationSpace_2.x10"
            final long t$104555 = t$104553.max0;
            
            //#line 66 "x10/array/DenseIterationSpace_2.x10"
            boolean t$104559 = ((t$104554) <= (((long)(t$104555))));
            
            //#line 66 "x10/array/DenseIterationSpace_2.x10"
            if (t$104559) {
                
                //#line 66 "x10/array/DenseIterationSpace_2.x10"
                final long t$104557 = this.cur1;
                
                //#line 66 "x10/array/DenseIterationSpace_2.x10"
                final x10.array.DenseIterationSpace_2 t$104556 = this.out$;
                
                //#line 66 "x10/array/DenseIterationSpace_2.x10"
                final long t$104558 = t$104556.max1;
                
                //#line 66 "x10/array/DenseIterationSpace_2.x10"
                t$104559 = ((t$104557) <= (((long)(t$104558))));
            }
            
            //#line 66 "x10/array/DenseIterationSpace_2.x10"
            return t$104559;
        }
        
        
        //#line 68 "x10/array/DenseIterationSpace_2.x10"
        public x10.lang.Point next() {
            
            //#line 69 "x10/array/DenseIterationSpace_2.x10"
            final long i$104512 = this.cur0;
            
            //#line 69 "x10/array/DenseIterationSpace_2.x10"
            final long i$104513 = this.cur1;
            
            //#line 152 . "x10/lang/Point.x10"
            final x10.lang.Point alloc$104514 = ((x10.lang.Point)(new x10.lang.Point((java.lang.System[]) null)));
            
            //#line 152 . "x10/lang/Point.x10"
            alloc$104514.x10$lang$Point$$init$S(((long)(i$104512)), ((long)(i$104513)));
            
            //#line 70 "x10/array/DenseIterationSpace_2.x10"
            final long t$104561 = this.cur1;
            
            //#line 70 "x10/array/DenseIterationSpace_2.x10"
            final long t$104562 = ((t$104561) + (((long)(1L))));
            
            //#line 70 "x10/array/DenseIterationSpace_2.x10"
            this.cur1 = t$104562;
            
            //#line 71 "x10/array/DenseIterationSpace_2.x10"
            final long t$104564 = this.cur1;
            
            //#line 71 "x10/array/DenseIterationSpace_2.x10"
            final x10.array.DenseIterationSpace_2 t$104563 = this.out$;
            
            //#line 71 "x10/array/DenseIterationSpace_2.x10"
            final long t$104565 = t$104563.max1;
            
            //#line 71 "x10/array/DenseIterationSpace_2.x10"
            final boolean t$104570 = ((t$104564) > (((long)(t$104565))));
            
            //#line 71 "x10/array/DenseIterationSpace_2.x10"
            if (t$104570) {
                
                //#line 72 "x10/array/DenseIterationSpace_2.x10"
                final x10.array.DenseIterationSpace_2 t$104566 = this.out$;
                
                //#line 72 "x10/array/DenseIterationSpace_2.x10"
                final long t$104567 = t$104566.min1;
                
                //#line 72 "x10/array/DenseIterationSpace_2.x10"
                this.cur1 = t$104567;
                
                //#line 73 "x10/array/DenseIterationSpace_2.x10"
                final long t$104568 = this.cur0;
                
                //#line 73 "x10/array/DenseIterationSpace_2.x10"
                final long t$104569 = ((t$104568) + (((long)(1L))));
                
                //#line 73 "x10/array/DenseIterationSpace_2.x10"
                this.cur0 = t$104569;
            }
            
            //#line 75 "x10/array/DenseIterationSpace_2.x10"
            return alloc$104514;
        }
        
        
        //#line 57 "x10/array/DenseIterationSpace_2.x10"
        final public x10.array.DenseIterationSpace_2.DIS2_It x10$array$DenseIterationSpace_2$DIS2_It$$this$x10$array$DenseIterationSpace_2$DIS2_It() {
            
            //#line 57 "x10/array/DenseIterationSpace_2.x10"
            return x10.array.DenseIterationSpace_2.DIS2_It.this;
        }
        
        
        //#line 57 "x10/array/DenseIterationSpace_2.x10"
        final public x10.array.DenseIterationSpace_2 x10$array$DenseIterationSpace_2$DIS2_It$$this$x10$array$DenseIterationSpace_2() {
            
            //#line 57 "x10/array/DenseIterationSpace_2.x10"
            final x10.array.DenseIterationSpace_2 t$104571 = this.out$;
            
            //#line 57 "x10/array/DenseIterationSpace_2.x10"
            return t$104571;
        }
        
        
        //#line 57 "x10/array/DenseIterationSpace_2.x10"
        final public void __fieldInitializers_x10_array_DenseIterationSpace_2_DIS2_It() {
            
            //#line 57 "x10/array/DenseIterationSpace_2.x10"
            this.cur0 = 0L;
            
            //#line 57 "x10/array/DenseIterationSpace_2.x10"
            this.cur1 = 0L;
        }
    }
    
    
    
    //#line 79 "x10/array/DenseIterationSpace_2.x10"
    public java.lang.String toString() {
        
        //#line 81 "x10/array/DenseIterationSpace_2.x10"
        final long t$104572 = this.min0;
        
        //#line 80 "x10/array/DenseIterationSpace_2.x10"
        final java.lang.String t$104573 = (("[") + ((x10.core.Long.$box(t$104572))));
        
        //#line 80 "x10/array/DenseIterationSpace_2.x10"
        final java.lang.String t$104574 = ((t$104573) + (".."));
        
        //#line 81 "x10/array/DenseIterationSpace_2.x10"
        final long t$104575 = this.max0;
        
        //#line 80 "x10/array/DenseIterationSpace_2.x10"
        final java.lang.String t$104576 = ((t$104574) + ((x10.core.Long.$box(t$104575))));
        
        //#line 80 "x10/array/DenseIterationSpace_2.x10"
        final java.lang.String t$104577 = ((t$104576) + (","));
        
        //#line 82 "x10/array/DenseIterationSpace_2.x10"
        final long t$104578 = this.min1;
        
        //#line 80 "x10/array/DenseIterationSpace_2.x10"
        final java.lang.String t$104579 = ((t$104577) + ((x10.core.Long.$box(t$104578))));
        
        //#line 80 "x10/array/DenseIterationSpace_2.x10"
        final java.lang.String t$104580 = ((t$104579) + (".."));
        
        //#line 82 "x10/array/DenseIterationSpace_2.x10"
        final long t$104581 = this.max1;
        
        //#line 80 "x10/array/DenseIterationSpace_2.x10"
        final java.lang.String t$104582 = ((t$104580) + ((x10.core.Long.$box(t$104581))));
        
        //#line 80 "x10/array/DenseIterationSpace_2.x10"
        final java.lang.String t$104583 = ((t$104582) + ("]"));
        
        //#line 80 "x10/array/DenseIterationSpace_2.x10"
        return t$104583;
    }
    
    
    //#line 18 "x10/array/DenseIterationSpace_2.x10"
    final public x10.array.DenseIterationSpace_2 x10$array$DenseIterationSpace_2$$this$x10$array$DenseIterationSpace_2() {
        
        //#line 18 "x10/array/DenseIterationSpace_2.x10"
        return x10.array.DenseIterationSpace_2.this;
    }
    
    
    //#line 18 "x10/array/DenseIterationSpace_2.x10"
    final public void __fieldInitializers_x10_array_DenseIterationSpace_2() {
        
    }
    
    final private static x10.core.concurrent.AtomicInteger initStatus$EMPTY = new x10.core.concurrent.AtomicInteger(x10.runtime.impl.java.InitDispatcher.UNINITIALIZED);
    private static x10.lang.ExceptionInInitializer exception$EMPTY;
    
    public static x10.array.DenseIterationSpace_2 get$EMPTY() {
        if (((int) x10.array.DenseIterationSpace_2.initStatus$EMPTY.get()) == ((int) x10.runtime.impl.java.InitDispatcher.INITIALIZED)) {
            return x10.array.DenseIterationSpace_2.EMPTY;
        }
        if (((int) x10.array.DenseIterationSpace_2.initStatus$EMPTY.get()) == ((int) x10.runtime.impl.java.InitDispatcher.EXCEPTION_RAISED)) {
            throw x10.array.DenseIterationSpace_2.exception$EMPTY;
        }
        if (x10.array.DenseIterationSpace_2.initStatus$EMPTY.compareAndSet((int)(x10.runtime.impl.java.InitDispatcher.UNINITIALIZED), (int)(x10.runtime.impl.java.InitDispatcher.INITIALIZING))) {
            try {{
                x10.array.DenseIterationSpace_2.EMPTY = ((x10.array.DenseIterationSpace_2)(new x10.array.DenseIterationSpace_2((java.lang.System[]) null).x10$array$DenseIterationSpace_2$$init$S(((long)(0L)), ((long)(0L)), ((long)(-1L)), ((long)(-1L)))));
            }}catch (java.lang.Throwable exc$104592) {
                x10.array.DenseIterationSpace_2.exception$EMPTY = new x10.lang.ExceptionInInitializer(exc$104592);
                x10.array.DenseIterationSpace_2.initStatus$EMPTY.set((int)(x10.runtime.impl.java.InitDispatcher.EXCEPTION_RAISED));
                x10.runtime.impl.java.InitDispatcher.lockInitialized();
                x10.runtime.impl.java.InitDispatcher.notifyInitialized();
                throw x10.array.DenseIterationSpace_2.exception$EMPTY;
            }
            x10.array.DenseIterationSpace_2.initStatus$EMPTY.set((int)(x10.runtime.impl.java.InitDispatcher.INITIALIZED));
            x10.runtime.impl.java.InitDispatcher.lockInitialized();
            x10.runtime.impl.java.InitDispatcher.notifyInitialized();
        } else {
            if (x10.array.DenseIterationSpace_2.initStatus$EMPTY.get() < x10.runtime.impl.java.InitDispatcher.INITIALIZED) {
                x10.runtime.impl.java.InitDispatcher.lockInitialized();
                while (x10.array.DenseIterationSpace_2.initStatus$EMPTY.get() < x10.runtime.impl.java.InitDispatcher.INITIALIZED) {
                    x10.runtime.impl.java.InitDispatcher.awaitInitialized();
                }
                x10.runtime.impl.java.InitDispatcher.unlockInitialized();
                if (((int) x10.array.DenseIterationSpace_2.initStatus$EMPTY.get()) == ((int) x10.runtime.impl.java.InitDispatcher.EXCEPTION_RAISED)) {
                    throw x10.array.DenseIterationSpace_2.exception$EMPTY;
                }
            }
        }
        return x10.array.DenseIterationSpace_2.EMPTY;
    }
}

