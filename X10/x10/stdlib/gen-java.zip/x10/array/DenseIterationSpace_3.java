package x10.array;

/**
 * A DenseIterationSpace_3 represents the rank 3 
 * iteration space of points [min0,min1,min2]..[max0,max1,max2] inclusive.
 */
@x10.runtime.impl.java.X10Generated
final public class DenseIterationSpace_3 extends x10.array.IterationSpace implements x10.serialization.X10JavaSerializable
{
    public static final x10.rtt.RuntimeType<DenseIterationSpace_3> $RTT = 
        x10.rtt.NamedType.<DenseIterationSpace_3> make("x10.array.DenseIterationSpace_3",
                                                       DenseIterationSpace_3.class,
                                                       new x10.rtt.Type[] {
                                                           x10.array.IterationSpace.$RTT
                                                       });
    
    public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
    
    public x10.rtt.Type<?> $getParam(int i) { return null; }
    
    private Object writeReplace() throws java.io.ObjectStreamException {
        return new x10.serialization.SerializationProxy(this);
    }
    
    public static x10.serialization.X10JavaSerializable $_deserialize_body(x10.array.DenseIterationSpace_3 $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
        x10.array.IterationSpace.$_deserialize_body($_obj, $deserializer);
        $_obj.max0 = $deserializer.readLong();
        $_obj.max1 = $deserializer.readLong();
        $_obj.max2 = $deserializer.readLong();
        $_obj.min0 = $deserializer.readLong();
        $_obj.min1 = $deserializer.readLong();
        $_obj.min2 = $deserializer.readLong();
        return $_obj;
    }
    
    public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
        x10.array.DenseIterationSpace_3 $_obj = new x10.array.DenseIterationSpace_3((java.lang.System[]) null);
        $deserializer.record_reference($_obj);
        return $_deserialize_body($_obj, $deserializer);
    }
    
    public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
        super.$_serialize($serializer);
        $serializer.write(this.max0);
        $serializer.write(this.max1);
        $serializer.write(this.max2);
        $serializer.write(this.min0);
        $serializer.write(this.min1);
        $serializer.write(this.min2);
        
    }
    
    // constructor just for allocation
    public DenseIterationSpace_3(final java.lang.System[] $dummy) {
        super($dummy);
        
    }
    
    

    
    //#line 20 "x10/array/DenseIterationSpace_3.x10"
    public long min0;
    
    //#line 21 "x10/array/DenseIterationSpace_3.x10"
    public long min1;
    
    //#line 22 "x10/array/DenseIterationSpace_3.x10"
    public long min2;
    
    //#line 23 "x10/array/DenseIterationSpace_3.x10"
    public long max0;
    
    //#line 24 "x10/array/DenseIterationSpace_3.x10"
    public long max1;
    
    //#line 25 "x10/array/DenseIterationSpace_3.x10"
    public long max2;
    
    //#line 27 "x10/array/DenseIterationSpace_3.x10"
    private static x10.array.DenseIterationSpace_3 EMPTY;
    
    
    //#line 29 "x10/array/DenseIterationSpace_3.x10"
    // creation method for java code (1-phase java constructor)
    public DenseIterationSpace_3(final long min0, final long min1, final long min2, final long max0, final long max1, final long max2) {
        this((java.lang.System[]) null);
        x10$array$DenseIterationSpace_3$$init$S(min0, min1, min2, max0, max1, max2);
    }
    
    // constructor for non-virtual call
    final public x10.array.DenseIterationSpace_3 x10$array$DenseIterationSpace_3$$init$S(final long min0, final long min1, final long min2, final long max0, final long max1, final long max2) {
         {
            
            //#line 30 "x10/array/DenseIterationSpace_3.x10"
            final x10.array.IterationSpace this$104595 = ((x10.array.IterationSpace)(this));
            
            //#line 22 . "x10/array/IterationSpace.x10"
            this$104595.rank = 3L;
            
            //#line 22 . "x10/array/IterationSpace.x10"
            this$104595.rect = true;
            
            //#line 29 "x10/array/DenseIterationSpace_3.x10"
            
            
            //#line 31 "x10/array/DenseIterationSpace_3.x10"
            this.min0 = min0;
            
            //#line 32 "x10/array/DenseIterationSpace_3.x10"
            this.min1 = min1;
            
            //#line 33 "x10/array/DenseIterationSpace_3.x10"
            this.min2 = min2;
            
            //#line 34 "x10/array/DenseIterationSpace_3.x10"
            this.max0 = max0;
            
            //#line 35 "x10/array/DenseIterationSpace_3.x10"
            this.max1 = max1;
            
            //#line 36 "x10/array/DenseIterationSpace_3.x10"
            this.max2 = max2;
        }
        return this;
    }
    
    
    
    //#line 39 "x10/array/DenseIterationSpace_3.x10"
    public x10.array.DenseIterationSpace_4 $times(final x10.lang.LongRange that) {
        
        //#line 40 "x10/array/DenseIterationSpace_3.x10"
        final x10.array.DenseIterationSpace_4 alloc$100739 = ((x10.array.DenseIterationSpace_4)(new x10.array.DenseIterationSpace_4((java.lang.System[]) null)));
        
        //#line 40 "x10/array/DenseIterationSpace_3.x10"
        final long t$104710 = this.min0;
        
        //#line 40 "x10/array/DenseIterationSpace_3.x10"
        final long t$104711 = this.min1;
        
        //#line 40 "x10/array/DenseIterationSpace_3.x10"
        final long t$104712 = this.min2;
        
        //#line 40 "x10/array/DenseIterationSpace_3.x10"
        final long t$104713 = that.min;
        
        //#line 40 "x10/array/DenseIterationSpace_3.x10"
        final long t$104714 = this.max0;
        
        //#line 40 "x10/array/DenseIterationSpace_3.x10"
        final long t$104715 = this.max1;
        
        //#line 40 "x10/array/DenseIterationSpace_3.x10"
        final long t$104716 = this.max2;
        
        //#line 40 "x10/array/DenseIterationSpace_3.x10"
        final long t$104717 = that.max;
        
        //#line 40 "x10/array/DenseIterationSpace_3.x10"
        alloc$100739.x10$array$DenseIterationSpace_4$$init$S(((long)(t$104710)), ((long)(t$104711)), ((long)(t$104712)), ((long)(t$104713)), ((long)(t$104714)), ((long)(t$104715)), ((long)(t$104716)), ((long)(t$104717)));
        
        //#line 40 "x10/array/DenseIterationSpace_3.x10"
        return alloc$100739;
    }
    
    
    //#line 43 "x10/array/DenseIterationSpace_3.x10"
    public long min$O(final long i) {
        
        //#line 44 "x10/array/DenseIterationSpace_3.x10"
        final boolean t$104616 = ((long) i) == ((long) 0L);
        
        //#line 44 "x10/array/DenseIterationSpace_3.x10"
        if (t$104616) {
            
            //#line 44 "x10/array/DenseIterationSpace_3.x10"
            final long t$104615 = this.min0;
            
            //#line 44 "x10/array/DenseIterationSpace_3.x10"
            return t$104615;
        }
        
        //#line 45 "x10/array/DenseIterationSpace_3.x10"
        final boolean t$104618 = ((long) i) == ((long) 1L);
        
        //#line 45 "x10/array/DenseIterationSpace_3.x10"
        if (t$104618) {
            
            //#line 45 "x10/array/DenseIterationSpace_3.x10"
            final long t$104617 = this.min1;
            
            //#line 45 "x10/array/DenseIterationSpace_3.x10"
            return t$104617;
        }
        
        //#line 46 "x10/array/DenseIterationSpace_3.x10"
        final boolean t$104620 = ((long) i) == ((long) 2L);
        
        //#line 46 "x10/array/DenseIterationSpace_3.x10"
        if (t$104620) {
            
            //#line 46 "x10/array/DenseIterationSpace_3.x10"
            final long t$104619 = this.min2;
            
            //#line 46 "x10/array/DenseIterationSpace_3.x10"
            return t$104619;
        }
        
        //#line 47 "x10/array/DenseIterationSpace_3.x10"
        final java.lang.String t$104621 = (((x10.core.Long.$box(i))) + (" is not a valid rank"));
        
        //#line 47 "x10/array/DenseIterationSpace_3.x10"
        final x10.lang.IllegalOperationException t$104622 = ((x10.lang.IllegalOperationException)(new x10.lang.IllegalOperationException(t$104621)));
        
        //#line 47 "x10/array/DenseIterationSpace_3.x10"
        throw t$104622;
    }
    
    
    //#line 50 "x10/array/DenseIterationSpace_3.x10"
    public long max$O(final long i) {
        
        //#line 51 "x10/array/DenseIterationSpace_3.x10"
        final boolean t$104624 = ((long) i) == ((long) 0L);
        
        //#line 51 "x10/array/DenseIterationSpace_3.x10"
        if (t$104624) {
            
            //#line 51 "x10/array/DenseIterationSpace_3.x10"
            final long t$104623 = this.max0;
            
            //#line 51 "x10/array/DenseIterationSpace_3.x10"
            return t$104623;
        }
        
        //#line 52 "x10/array/DenseIterationSpace_3.x10"
        final boolean t$104626 = ((long) i) == ((long) 1L);
        
        //#line 52 "x10/array/DenseIterationSpace_3.x10"
        if (t$104626) {
            
            //#line 52 "x10/array/DenseIterationSpace_3.x10"
            final long t$104625 = this.max1;
            
            //#line 52 "x10/array/DenseIterationSpace_3.x10"
            return t$104625;
        }
        
        //#line 53 "x10/array/DenseIterationSpace_3.x10"
        final boolean t$104628 = ((long) i) == ((long) 2L);
        
        //#line 53 "x10/array/DenseIterationSpace_3.x10"
        if (t$104628) {
            
            //#line 53 "x10/array/DenseIterationSpace_3.x10"
            final long t$104627 = this.max2;
            
            //#line 53 "x10/array/DenseIterationSpace_3.x10"
            return t$104627;
        }
        
        //#line 54 "x10/array/DenseIterationSpace_3.x10"
        final java.lang.String t$104629 = (((x10.core.Long.$box(i))) + (" is not a valid rank"));
        
        //#line 54 "x10/array/DenseIterationSpace_3.x10"
        final x10.lang.IllegalOperationException t$104630 = ((x10.lang.IllegalOperationException)(new x10.lang.IllegalOperationException(t$104629)));
        
        //#line 54 "x10/array/DenseIterationSpace_3.x10"
        throw t$104630;
    }
    
    
    //#line 57 "x10/array/DenseIterationSpace_3.x10"
    public boolean isEmpty$O() {
        
        //#line 57 "x10/array/DenseIterationSpace_3.x10"
        final long t$104631 = this.max0;
        
        //#line 57 "x10/array/DenseIterationSpace_3.x10"
        final long t$104632 = this.min0;
        
        //#line 57 "x10/array/DenseIterationSpace_3.x10"
        boolean t$104635 = ((t$104631) < (((long)(t$104632))));
        
        //#line 57 "x10/array/DenseIterationSpace_3.x10"
        if (!(t$104635)) {
            
            //#line 57 "x10/array/DenseIterationSpace_3.x10"
            final long t$104633 = this.max1;
            
            //#line 57 "x10/array/DenseIterationSpace_3.x10"
            final long t$104634 = this.min1;
            
            //#line 57 "x10/array/DenseIterationSpace_3.x10"
            t$104635 = ((t$104633) < (((long)(t$104634))));
        }
        
        //#line 57 "x10/array/DenseIterationSpace_3.x10"
        boolean t$104638 = t$104635;
        
        //#line 57 "x10/array/DenseIterationSpace_3.x10"
        if (!(t$104635)) {
            
            //#line 57 "x10/array/DenseIterationSpace_3.x10"
            final long t$104636 = this.max2;
            
            //#line 57 "x10/array/DenseIterationSpace_3.x10"
            final long t$104637 = this.min2;
            
            //#line 57 "x10/array/DenseIterationSpace_3.x10"
            t$104638 = ((t$104636) < (((long)(t$104637))));
        }
        
        //#line 57 "x10/array/DenseIterationSpace_3.x10"
        return t$104638;
    }
    
    
    //#line 59 "x10/array/DenseIterationSpace_3.x10"
    public long size$O() {
        
        //#line 59 "x10/array/DenseIterationSpace_3.x10"
        final long t$104640 = this.max0;
        
        //#line 59 "x10/array/DenseIterationSpace_3.x10"
        final long t$104641 = this.min0;
        
        //#line 59 "x10/array/DenseIterationSpace_3.x10"
        final long t$104642 = ((t$104640) - (((long)(t$104641))));
        
        //#line 59 "x10/array/DenseIterationSpace_3.x10"
        final long t$104646 = ((t$104642) + (((long)(1L))));
        
        //#line 59 "x10/array/DenseIterationSpace_3.x10"
        final long t$104643 = this.max1;
        
        //#line 59 "x10/array/DenseIterationSpace_3.x10"
        final long t$104644 = this.min1;
        
        //#line 59 "x10/array/DenseIterationSpace_3.x10"
        final long t$104645 = ((t$104643) - (((long)(t$104644))));
        
        //#line 59 "x10/array/DenseIterationSpace_3.x10"
        final long t$104647 = ((t$104645) + (((long)(1L))));
        
        //#line 59 "x10/array/DenseIterationSpace_3.x10"
        final long t$104651 = ((t$104646) * (((long)(t$104647))));
        
        //#line 59 "x10/array/DenseIterationSpace_3.x10"
        final long t$104648 = this.max2;
        
        //#line 59 "x10/array/DenseIterationSpace_3.x10"
        final long t$104649 = this.min2;
        
        //#line 59 "x10/array/DenseIterationSpace_3.x10"
        final long t$104650 = ((t$104648) - (((long)(t$104649))));
        
        //#line 59 "x10/array/DenseIterationSpace_3.x10"
        final long t$104652 = ((t$104650) + (((long)(1L))));
        
        //#line 59 "x10/array/DenseIterationSpace_3.x10"
        final long t$104653 = ((t$104651) * (((long)(t$104652))));
        
        //#line 59 "x10/array/DenseIterationSpace_3.x10"
        return t$104653;
    }
    
    
    //#line 61 "x10/array/DenseIterationSpace_3.x10"
    public x10.lang.Iterator iterator() {
        
        //#line 61 "x10/array/DenseIterationSpace_3.x10"
        final x10.array.DenseIterationSpace_3.DIS3_It alloc$100740 = ((x10.array.DenseIterationSpace_3.DIS3_It)(new x10.array.DenseIterationSpace_3.DIS3_It((java.lang.System[]) null)));
        
        //#line 61 "x10/array/DenseIterationSpace_3.x10"
        alloc$100740.x10$array$DenseIterationSpace_3$DIS3_It$$init$S(this);
        
        //#line 61 "x10/array/DenseIterationSpace_3.x10"
        return alloc$100740;
    }
    
    
    //#line 63 "x10/array/DenseIterationSpace_3.x10"
    @x10.runtime.impl.java.X10Generated
    public static class DIS3_It extends x10.core.Ref implements x10.lang.Iterator, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<DIS3_It> $RTT = 
            x10.rtt.NamedType.<DIS3_It> make("x10.array.DenseIterationSpace_3.DIS3_It",
                                             DIS3_It.class,
                                             new x10.rtt.Type[] {
                                                 x10.rtt.ParameterizedType.make(x10.lang.Iterator.$RTT, x10.lang.Point.$RTT)
                                             });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static x10.serialization.X10JavaSerializable $_deserialize_body(x10.array.DenseIterationSpace_3.DIS3_It $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            $_obj.cur0 = $deserializer.readLong();
            $_obj.cur1 = $deserializer.readLong();
            $_obj.cur2 = $deserializer.readLong();
            $_obj.out$ = $deserializer.readObject();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.array.DenseIterationSpace_3.DIS3_It $_obj = new x10.array.DenseIterationSpace_3.DIS3_It((java.lang.System[]) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            $serializer.write(this.cur0);
            $serializer.write(this.cur1);
            $serializer.write(this.cur2);
            $serializer.write(this.out$);
            
        }
        
        // constructor just for allocation
        public DIS3_It(final java.lang.System[] $dummy) {
            
        }
        
        // bridge for method abstract public x10.lang.Iterator[T].next(){}:T
        public x10.lang.Point next$G() {
            return next();
        }
        
        
    
        
        //#line 18 "x10/array/DenseIterationSpace_3.x10"
        public x10.array.DenseIterationSpace_3 out$;
        
        //#line 64 "x10/array/DenseIterationSpace_3.x10"
        public long cur0;
        
        //#line 65 "x10/array/DenseIterationSpace_3.x10"
        public long cur1;
        
        //#line 66 "x10/array/DenseIterationSpace_3.x10"
        public long cur2;
        
        
        //#line 68 "x10/array/DenseIterationSpace_3.x10"
        // creation method for java code (1-phase java constructor)
        public DIS3_It(final x10.array.DenseIterationSpace_3 out$) {
            this((java.lang.System[]) null);
            x10$array$DenseIterationSpace_3$DIS3_It$$init$S(out$);
        }
        
        // constructor for non-virtual call
        final public x10.array.DenseIterationSpace_3.DIS3_It x10$array$DenseIterationSpace_3$DIS3_It$$init$S(final x10.array.DenseIterationSpace_3 out$) {
             {
                
                //#line 18 "x10/array/DenseIterationSpace_3.x10"
                this.out$ = out$;
                
                //#line 68 "x10/array/DenseIterationSpace_3.x10"
                
                
                //#line 63 "x10/array/DenseIterationSpace_3.x10"
                final x10.array.DenseIterationSpace_3.DIS3_It this$104718 = this;
                
                //#line 63 "x10/array/DenseIterationSpace_3.x10"
                this$104718.cur0 = 0L;
                
                //#line 63 "x10/array/DenseIterationSpace_3.x10"
                this$104718.cur1 = 0L;
                
                //#line 63 "x10/array/DenseIterationSpace_3.x10"
                this$104718.cur2 = 0L;
                
                //#line 69 "x10/array/DenseIterationSpace_3.x10"
                final x10.array.DenseIterationSpace_3 t$104654 = this.out$;
                
                //#line 69 "x10/array/DenseIterationSpace_3.x10"
                final long t$104655 = t$104654.min0;
                
                //#line 69 "x10/array/DenseIterationSpace_3.x10"
                this.cur0 = t$104655;
                
                //#line 70 "x10/array/DenseIterationSpace_3.x10"
                final x10.array.DenseIterationSpace_3 t$104656 = this.out$;
                
                //#line 70 "x10/array/DenseIterationSpace_3.x10"
                final long t$104657 = t$104656.min1;
                
                //#line 70 "x10/array/DenseIterationSpace_3.x10"
                this.cur1 = t$104657;
                
                //#line 71 "x10/array/DenseIterationSpace_3.x10"
                final x10.array.DenseIterationSpace_3 t$104658 = this.out$;
                
                //#line 71 "x10/array/DenseIterationSpace_3.x10"
                final long t$104659 = t$104658.min2;
                
                //#line 71 "x10/array/DenseIterationSpace_3.x10"
                this.cur2 = t$104659;
            }
            return this;
        }
        
        
        
        //#line 74 "x10/array/DenseIterationSpace_3.x10"
        public boolean hasNext$O() {
            
            //#line 74 "x10/array/DenseIterationSpace_3.x10"
            final long t$104661 = this.cur0;
            
            //#line 74 "x10/array/DenseIterationSpace_3.x10"
            final x10.array.DenseIterationSpace_3 t$104660 = this.out$;
            
            //#line 74 "x10/array/DenseIterationSpace_3.x10"
            final long t$104662 = t$104660.max0;
            
            //#line 74 "x10/array/DenseIterationSpace_3.x10"
            boolean t$104666 = ((t$104661) <= (((long)(t$104662))));
            
            //#line 74 "x10/array/DenseIterationSpace_3.x10"
            if (t$104666) {
                
                //#line 74 "x10/array/DenseIterationSpace_3.x10"
                final long t$104664 = this.cur1;
                
                //#line 74 "x10/array/DenseIterationSpace_3.x10"
                final x10.array.DenseIterationSpace_3 t$104663 = this.out$;
                
                //#line 74 "x10/array/DenseIterationSpace_3.x10"
                final long t$104665 = t$104663.max1;
                
                //#line 74 "x10/array/DenseIterationSpace_3.x10"
                t$104666 = ((t$104664) <= (((long)(t$104665))));
            }
            
            //#line 74 "x10/array/DenseIterationSpace_3.x10"
            boolean t$104670 = t$104666;
            
            //#line 74 "x10/array/DenseIterationSpace_3.x10"
            if (t$104666) {
                
                //#line 74 "x10/array/DenseIterationSpace_3.x10"
                final long t$104668 = this.cur2;
                
                //#line 74 "x10/array/DenseIterationSpace_3.x10"
                final x10.array.DenseIterationSpace_3 t$104667 = this.out$;
                
                //#line 74 "x10/array/DenseIterationSpace_3.x10"
                final long t$104669 = t$104667.max2;
                
                //#line 74 "x10/array/DenseIterationSpace_3.x10"
                t$104670 = ((t$104668) <= (((long)(t$104669))));
            }
            
            //#line 74 "x10/array/DenseIterationSpace_3.x10"
            return t$104670;
        }
        
        
        //#line 76 "x10/array/DenseIterationSpace_3.x10"
        public x10.lang.Point next() {
            
            //#line 77 "x10/array/DenseIterationSpace_3.x10"
            final long i$104602 = this.cur0;
            
            //#line 77 "x10/array/DenseIterationSpace_3.x10"
            final long i$104603 = this.cur1;
            
            //#line 77 "x10/array/DenseIterationSpace_3.x10"
            final long i$104604 = this.cur2;
            
            //#line 153 . "x10/lang/Point.x10"
            final x10.lang.Point alloc$104605 = ((x10.lang.Point)(new x10.lang.Point((java.lang.System[]) null)));
            
            //#line 153 . "x10/lang/Point.x10"
            alloc$104605.x10$lang$Point$$init$S(((long)(i$104602)), ((long)(i$104603)), ((long)(i$104604)));
            
            //#line 78 "x10/array/DenseIterationSpace_3.x10"
            final long t$104672 = this.cur2;
            
            //#line 78 "x10/array/DenseIterationSpace_3.x10"
            final long t$104673 = ((t$104672) + (((long)(1L))));
            
            //#line 78 "x10/array/DenseIterationSpace_3.x10"
            this.cur2 = t$104673;
            
            //#line 79 "x10/array/DenseIterationSpace_3.x10"
            final long t$104675 = this.cur2;
            
            //#line 79 "x10/array/DenseIterationSpace_3.x10"
            final x10.array.DenseIterationSpace_3 t$104674 = this.out$;
            
            //#line 79 "x10/array/DenseIterationSpace_3.x10"
            final long t$104676 = t$104674.max2;
            
            //#line 79 "x10/array/DenseIterationSpace_3.x10"
            final boolean t$104689 = ((t$104675) > (((long)(t$104676))));
            
            //#line 79 "x10/array/DenseIterationSpace_3.x10"
            if (t$104689) {
                
                //#line 80 "x10/array/DenseIterationSpace_3.x10"
                final x10.array.DenseIterationSpace_3 t$104677 = this.out$;
                
                //#line 80 "x10/array/DenseIterationSpace_3.x10"
                final long t$104678 = t$104677.min2;
                
                //#line 80 "x10/array/DenseIterationSpace_3.x10"
                this.cur2 = t$104678;
                
                //#line 81 "x10/array/DenseIterationSpace_3.x10"
                final long t$104679 = this.cur1;
                
                //#line 81 "x10/array/DenseIterationSpace_3.x10"
                final long t$104680 = ((t$104679) + (((long)(1L))));
                
                //#line 81 "x10/array/DenseIterationSpace_3.x10"
                this.cur1 = t$104680;
                
                //#line 82 "x10/array/DenseIterationSpace_3.x10"
                final long t$104682 = this.cur1;
                
                //#line 82 "x10/array/DenseIterationSpace_3.x10"
                final x10.array.DenseIterationSpace_3 t$104681 = this.out$;
                
                //#line 82 "x10/array/DenseIterationSpace_3.x10"
                final long t$104683 = t$104681.max1;
                
                //#line 82 "x10/array/DenseIterationSpace_3.x10"
                final boolean t$104688 = ((t$104682) > (((long)(t$104683))));
                
                //#line 82 "x10/array/DenseIterationSpace_3.x10"
                if (t$104688) {
                    
                    //#line 83 "x10/array/DenseIterationSpace_3.x10"
                    final x10.array.DenseIterationSpace_3 t$104684 = this.out$;
                    
                    //#line 83 "x10/array/DenseIterationSpace_3.x10"
                    final long t$104685 = t$104684.min1;
                    
                    //#line 83 "x10/array/DenseIterationSpace_3.x10"
                    this.cur1 = t$104685;
                    
                    //#line 84 "x10/array/DenseIterationSpace_3.x10"
                    final long t$104686 = this.cur0;
                    
                    //#line 84 "x10/array/DenseIterationSpace_3.x10"
                    final long t$104687 = ((t$104686) + (((long)(1L))));
                    
                    //#line 84 "x10/array/DenseIterationSpace_3.x10"
                    this.cur0 = t$104687;
                }
            }
            
            //#line 87 "x10/array/DenseIterationSpace_3.x10"
            return alloc$104605;
        }
        
        
        //#line 63 "x10/array/DenseIterationSpace_3.x10"
        final public x10.array.DenseIterationSpace_3.DIS3_It x10$array$DenseIterationSpace_3$DIS3_It$$this$x10$array$DenseIterationSpace_3$DIS3_It() {
            
            //#line 63 "x10/array/DenseIterationSpace_3.x10"
            return x10.array.DenseIterationSpace_3.DIS3_It.this;
        }
        
        
        //#line 63 "x10/array/DenseIterationSpace_3.x10"
        final public x10.array.DenseIterationSpace_3 x10$array$DenseIterationSpace_3$DIS3_It$$this$x10$array$DenseIterationSpace_3() {
            
            //#line 63 "x10/array/DenseIterationSpace_3.x10"
            final x10.array.DenseIterationSpace_3 t$104690 = this.out$;
            
            //#line 63 "x10/array/DenseIterationSpace_3.x10"
            return t$104690;
        }
        
        
        //#line 63 "x10/array/DenseIterationSpace_3.x10"
        final public void __fieldInitializers_x10_array_DenseIterationSpace_3_DIS3_It() {
            
            //#line 63 "x10/array/DenseIterationSpace_3.x10"
            this.cur0 = 0L;
            
            //#line 63 "x10/array/DenseIterationSpace_3.x10"
            this.cur1 = 0L;
            
            //#line 63 "x10/array/DenseIterationSpace_3.x10"
            this.cur2 = 0L;
        }
    }
    
    
    
    //#line 91 "x10/array/DenseIterationSpace_3.x10"
    public java.lang.String toString() {
        
        //#line 93 "x10/array/DenseIterationSpace_3.x10"
        final long t$104691 = this.min0;
        
        //#line 92 "x10/array/DenseIterationSpace_3.x10"
        final java.lang.String t$104692 = (("[") + ((x10.core.Long.$box(t$104691))));
        
        //#line 92 "x10/array/DenseIterationSpace_3.x10"
        final java.lang.String t$104693 = ((t$104692) + (".."));
        
        //#line 93 "x10/array/DenseIterationSpace_3.x10"
        final long t$104694 = this.max0;
        
        //#line 92 "x10/array/DenseIterationSpace_3.x10"
        final java.lang.String t$104695 = ((t$104693) + ((x10.core.Long.$box(t$104694))));
        
        //#line 92 "x10/array/DenseIterationSpace_3.x10"
        final java.lang.String t$104696 = ((t$104695) + (","));
        
        //#line 94 "x10/array/DenseIterationSpace_3.x10"
        final long t$104697 = this.min1;
        
        //#line 92 "x10/array/DenseIterationSpace_3.x10"
        final java.lang.String t$104698 = ((t$104696) + ((x10.core.Long.$box(t$104697))));
        
        //#line 92 "x10/array/DenseIterationSpace_3.x10"
        final java.lang.String t$104699 = ((t$104698) + (".."));
        
        //#line 94 "x10/array/DenseIterationSpace_3.x10"
        final long t$104700 = this.max1;
        
        //#line 92 "x10/array/DenseIterationSpace_3.x10"
        final java.lang.String t$104701 = ((t$104699) + ((x10.core.Long.$box(t$104700))));
        
        //#line 92 "x10/array/DenseIterationSpace_3.x10"
        final java.lang.String t$104702 = ((t$104701) + (","));
        
        //#line 95 "x10/array/DenseIterationSpace_3.x10"
        final long t$104703 = this.min2;
        
        //#line 92 "x10/array/DenseIterationSpace_3.x10"
        final java.lang.String t$104704 = ((t$104702) + ((x10.core.Long.$box(t$104703))));
        
        //#line 92 "x10/array/DenseIterationSpace_3.x10"
        final java.lang.String t$104705 = ((t$104704) + (".."));
        
        //#line 95 "x10/array/DenseIterationSpace_3.x10"
        final long t$104706 = this.max2;
        
        //#line 92 "x10/array/DenseIterationSpace_3.x10"
        final java.lang.String t$104707 = ((t$104705) + ((x10.core.Long.$box(t$104706))));
        
        //#line 92 "x10/array/DenseIterationSpace_3.x10"
        final java.lang.String t$104708 = ((t$104707) + ("]"));
        
        //#line 92 "x10/array/DenseIterationSpace_3.x10"
        return t$104708;
    }
    
    
    //#line 18 "x10/array/DenseIterationSpace_3.x10"
    final public x10.array.DenseIterationSpace_3 x10$array$DenseIterationSpace_3$$this$x10$array$DenseIterationSpace_3() {
        
        //#line 18 "x10/array/DenseIterationSpace_3.x10"
        return x10.array.DenseIterationSpace_3.this;
    }
    
    
    //#line 18 "x10/array/DenseIterationSpace_3.x10"
    final public void __fieldInitializers_x10_array_DenseIterationSpace_3() {
        
    }
    
    final private static x10.core.concurrent.AtomicInteger initStatus$EMPTY = new x10.core.concurrent.AtomicInteger(x10.runtime.impl.java.InitDispatcher.UNINITIALIZED);
    private static x10.lang.ExceptionInInitializer exception$EMPTY;
    
    public static x10.array.DenseIterationSpace_3 get$EMPTY() {
        if (((int) x10.array.DenseIterationSpace_3.initStatus$EMPTY.get()) == ((int) x10.runtime.impl.java.InitDispatcher.INITIALIZED)) {
            return x10.array.DenseIterationSpace_3.EMPTY;
        }
        if (((int) x10.array.DenseIterationSpace_3.initStatus$EMPTY.get()) == ((int) x10.runtime.impl.java.InitDispatcher.EXCEPTION_RAISED)) {
            throw x10.array.DenseIterationSpace_3.exception$EMPTY;
        }
        if (x10.array.DenseIterationSpace_3.initStatus$EMPTY.compareAndSet((int)(x10.runtime.impl.java.InitDispatcher.UNINITIALIZED), (int)(x10.runtime.impl.java.InitDispatcher.INITIALIZING))) {
            try {{
                x10.array.DenseIterationSpace_3.EMPTY = ((x10.array.DenseIterationSpace_3)(new x10.array.DenseIterationSpace_3((java.lang.System[]) null).x10$array$DenseIterationSpace_3$$init$S(((long)(0L)), ((long)(0L)), ((long)(0L)), ((long)(-1L)), ((long)(-1L)), ((long)(-1L)))));
            }}catch (java.lang.Throwable exc$104719) {
                x10.array.DenseIterationSpace_3.exception$EMPTY = new x10.lang.ExceptionInInitializer(exc$104719);
                x10.array.DenseIterationSpace_3.initStatus$EMPTY.set((int)(x10.runtime.impl.java.InitDispatcher.EXCEPTION_RAISED));
                x10.runtime.impl.java.InitDispatcher.lockInitialized();
                x10.runtime.impl.java.InitDispatcher.notifyInitialized();
                throw x10.array.DenseIterationSpace_3.exception$EMPTY;
            }
            x10.array.DenseIterationSpace_3.initStatus$EMPTY.set((int)(x10.runtime.impl.java.InitDispatcher.INITIALIZED));
            x10.runtime.impl.java.InitDispatcher.lockInitialized();
            x10.runtime.impl.java.InitDispatcher.notifyInitialized();
        } else {
            if (x10.array.DenseIterationSpace_3.initStatus$EMPTY.get() < x10.runtime.impl.java.InitDispatcher.INITIALIZED) {
                x10.runtime.impl.java.InitDispatcher.lockInitialized();
                while (x10.array.DenseIterationSpace_3.initStatus$EMPTY.get() < x10.runtime.impl.java.InitDispatcher.INITIALIZED) {
                    x10.runtime.impl.java.InitDispatcher.awaitInitialized();
                }
                x10.runtime.impl.java.InitDispatcher.unlockInitialized();
                if (((int) x10.array.DenseIterationSpace_3.initStatus$EMPTY.get()) == ((int) x10.runtime.impl.java.InitDispatcher.EXCEPTION_RAISED)) {
                    throw x10.array.DenseIterationSpace_3.exception$EMPTY;
                }
            }
        }
        return x10.array.DenseIterationSpace_3.EMPTY;
    }
}

