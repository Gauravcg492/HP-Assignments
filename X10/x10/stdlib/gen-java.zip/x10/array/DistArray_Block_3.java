package x10.array;


/**
 * Implementation of a 3-D DistArray that distributes its data elements
 * over the places in its PlaceGroup by distributing the first dimension 
 * in a 1-D blocked fashion.
 */
@x10.runtime.impl.java.X10Generated
public class DistArray_Block_3<$T> extends x10.array.DistArray<$T> implements x10.core.fun.Fun_0_3, x10.serialization.X10JavaSerializable
{
    public static final x10.rtt.RuntimeType<DistArray_Block_3> $RTT = 
        x10.rtt.NamedType.<DistArray_Block_3> make("x10.array.DistArray_Block_3",
                                                   DistArray_Block_3.class,
                                                   1,
                                                   new x10.rtt.Type[] {
                                                       x10.rtt.ParameterizedType.make(x10.core.fun.Fun_0_3.$RTT, x10.rtt.Types.LONG, x10.rtt.Types.LONG, x10.rtt.Types.LONG, x10.rtt.UnresolvedType.PARAM(0)),
                                                       x10.rtt.ParameterizedType.make(x10.array.DistArray.$RTT, x10.rtt.UnresolvedType.PARAM(0))
                                                   });
    
    public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
    
    public x10.rtt.Type<?> $getParam(int i) { if (i == 0) return $T; return null; }
    
    private Object writeReplace() throws java.io.ObjectStreamException {
        return new x10.serialization.SerializationProxy(this);
    }
    
    public static <$T> x10.serialization.X10JavaSerializable $_deserialize_body(x10.array.DistArray_Block_3<$T> $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
        x10.array.DistArray.$_deserialize_body($_obj, $deserializer);
        $_obj.$T = (x10.rtt.Type) $deserializer.readObject();
        $_obj.globalIndices = $deserializer.readObject();
        $_obj.numElems_1 = $deserializer.readLong();
        $_obj.numElems_2 = $deserializer.readLong();
        $_obj.numElems_3 = $deserializer.readLong();
        
        /* fields with @TransientInitExpr annotations */
        $_obj.localIndices = $_obj.reloadLocalIndices();
        $_obj.minIndex_1 = $_obj.reloadMinIndex_1$O();
        $_obj.numElemsLocal_1 = $_obj.reloadNumElemsLocal_1$O();
        
        return $_obj;
    }
    
    public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
        x10.array.DistArray_Block_3 $_obj = new x10.array.DistArray_Block_3((java.lang.System[]) null, (x10.rtt.Type) null);
        $deserializer.record_reference($_obj);
        return $_deserialize_body($_obj, $deserializer);
    }
    
    public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
        super.$_serialize($serializer);
        $serializer.write(this.$T);
        $serializer.write(this.globalIndices);
        $serializer.write(this.numElems_1);
        $serializer.write(this.numElems_2);
        $serializer.write(this.numElems_3);
        
    }
    
    // constructor just for allocation
    public DistArray_Block_3(final java.lang.System[] $dummy, final x10.rtt.Type $T) {
        super($dummy, $T);
        x10.array.DistArray_Block_3.$initParams(this, $T);
        
    }
    
    // dispatcher for method abstract public (Z1,Z2,Z3)=>U.operator()(a1:Z1, a2:Z2, a3:Z3){}:U
    public java.lang.Object $apply(final java.lang.Object a1, final x10.rtt.Type t1, final java.lang.Object a2, final x10.rtt.Type t2, final java.lang.Object a3, final x10.rtt.Type t3) {
        return $apply$G(x10.core.Long.$unbox(a1), x10.core.Long.$unbox(a2), x10.core.Long.$unbox(a3));
        
    }
    
    // bridge for method abstract public x10.array.DistArray[T].operator()=(p:x10.lang.Point{self.rank==this(:x10.array.DistArray).rank()}, v:T){}:T{self==v}
    final public $T $set__1x10$array$DistArray$$T$G(x10.lang.Point a1, $T a2) {
        return $set__1x10$array$DistArray_Block_3$$T$G(a1, a2);
    }
    
    private x10.rtt.Type $T;
    
    // initializer of type parameters
    public static void $initParams(final DistArray_Block_3 $this, final x10.rtt.Type $T) {
        $this.$T = $T;
        
    }
    // synthetic type for parameter mangling
    public static final class __4$1x10$lang$Long$3x10$lang$Long$3x10$lang$Long$3x10$array$DistArray_Block_3$$T$2 {}
    // synthetic type for parameter mangling
    public static final class __3$1x10$lang$Long$3x10$lang$Long$3x10$lang$Long$3x10$array$DistArray_Block_3$$T$2 {}
    

    
    
    //#line 26 "x10/array/DistArray_Block_3.x10"
    final public long rank$O() {
        
        //#line 26 "x10/array/DistArray_Block_3.x10"
        return 3L;
    }
    
    
    //#line 28 "x10/array/DistArray_Block_3.x10"
    public x10.array.DenseIterationSpace_3 globalIndices;
    
    //#line 30 "x10/array/DistArray_Block_3.x10"
    public long numElems_1;
    
    //#line 32 "x10/array/DistArray_Block_3.x10"
    public long numElems_2;
    
    //#line 34 "x10/array/DistArray_Block_3.x10"
    public long numElems_3;
    
    //#line 37 "x10/array/DistArray_Block_3.x10"
    public transient x10.array.DenseIterationSpace_3 localIndices;
    
    
    //#line 38 "x10/array/DistArray_Block_3.x10"
    final public x10.array.DenseIterationSpace_3 reloadLocalIndices() {
        
        //#line 40 "x10/array/DistArray_Block_3.x10"
        final x10.lang.PlaceLocalHandle t$109768 = ((x10.lang.PlaceLocalHandle)(this.localHandle));
        
        //#line 40 "x10/array/DistArray_Block_3.x10"
        final x10.array.LocalState t$109769 = ((x10.lang.PlaceLocalHandle<x10.array.LocalState<$T>>)t$109768).$apply$G();
        
        //#line 40 "x10/array/DistArray_Block_3.x10"
        final x10.array.LocalState_B3 ls = x10.rtt.Types.<x10.array.LocalState_B3<$T>> cast(t$109769,x10.rtt.ParameterizedType.make(x10.array.LocalState_B3.$RTT, $T));
        
        //#line 41 "x10/array/DistArray_Block_3.x10"
        final boolean t$109771 = ((ls) != (null));
        
        //#line 41 "x10/array/DistArray_Block_3.x10"
        x10.array.DenseIterationSpace_3 t$109772 =  null;
        
        //#line 41 "x10/array/DistArray_Block_3.x10"
        if (t$109771) {
            
            //#line 41 "x10/array/DistArray_Block_3.x10"
            final x10.array.Dist_Block_3 t$109770 = ((x10.array.Dist_Block_3)(((x10.array.LocalState_B3<$T>)ls).dist));
            
            //#line 41 "x10/array/DistArray_Block_3.x10"
            t$109772 = ((x10.array.DenseIterationSpace_3)(t$109770.localIndices));
        } else {
            
            //#line 41 "x10/array/DistArray_Block_3.x10"
            final x10.array.DenseIterationSpace_3 alloc$109549 = ((x10.array.DenseIterationSpace_3)(new x10.array.DenseIterationSpace_3((java.lang.System[]) null)));
            
            //#line 41 "x10/array/DistArray_Block_3.x10"
            alloc$109549.x10$array$DenseIterationSpace_3$$init$S(((long)(0L)), ((long)(0L)), ((long)(0L)), ((long)(-1L)), ((long)(-1L)), ((long)(-1L)));
            
            //#line 41 "x10/array/DistArray_Block_3.x10"
            t$109772 = ((x10.array.DenseIterationSpace_3)(alloc$109549));
        }
        
        //#line 41 "x10/array/DistArray_Block_3.x10"
        return t$109772;
    }
    
    
    //#line 45 "x10/array/DistArray_Block_3.x10"
    public transient long minIndex_1;
    
    
    //#line 46 "x10/array/DistArray_Block_3.x10"
    final public long reloadMinIndex_1$O() {
        
        //#line 46 "x10/array/DistArray_Block_3.x10"
        final x10.array.DenseIterationSpace_3 t$109774 = ((x10.array.DenseIterationSpace_3)(this.localIndices));
        
        //#line 46 "x10/array/DistArray_Block_3.x10"
        final long t$109775 = t$109774.min$O((long)(0L));
        
        //#line 46 "x10/array/DistArray_Block_3.x10"
        return t$109775;
    }
    
    
    //#line 49 "x10/array/DistArray_Block_3.x10"
    public transient long numElemsLocal_1;
    
    
    //#line 50 "x10/array/DistArray_Block_3.x10"
    final public long reloadNumElemsLocal_1$O() {
        
        //#line 50 "x10/array/DistArray_Block_3.x10"
        final x10.array.DenseIterationSpace_3 t$109776 = ((x10.array.DenseIterationSpace_3)(this.localIndices));
        
        //#line 50 "x10/array/DistArray_Block_3.x10"
        final long t$109777 = t$109776.max$O((long)(0L));
        
        //#line 50 "x10/array/DistArray_Block_3.x10"
        final long t$109778 = this.minIndex_1;
        
        //#line 50 "x10/array/DistArray_Block_3.x10"
        final long t$109779 = ((t$109777) - (((long)(t$109778))));
        
        //#line 50 "x10/array/DistArray_Block_3.x10"
        final long t$109780 = ((t$109779) + (((long)(1L))));
        
        //#line 50 "x10/array/DistArray_Block_3.x10"
        return t$109780;
    }
    
    
    //#line 63 "x10/array/DistArray_Block_3.x10"
    /**
     * Construct a m by n by p block distributed DistArray
     * whose data is distributed over pg and initialized using
     * the init function.
     *
     * @param m number of elements in the first dimension
     * @param n number of elements in the second dimension
     * @param p number of elements in the third dimension
     * @param pg the PlaceGroup to use to distibute the elements.
     * @param init the element initialization function
     */
    // creation method for java code (1-phase java constructor)
    public DistArray_Block_3(final x10.rtt.Type $T, final long m, final long n, final long p, final x10.lang.PlaceGroup pg, final x10.core.fun.Fun_0_3<x10.core.Long,x10.core.Long,x10.core.Long,$T> init, __4$1x10$lang$Long$3x10$lang$Long$3x10$lang$Long$3x10$array$DistArray_Block_3$$T$2 $dummy) {
        this((java.lang.System[]) null, $T);
        x10$array$DistArray_Block_3$$init$S(m, n, p, pg, init, (x10.array.DistArray_Block_3.__4$1x10$lang$Long$3x10$lang$Long$3x10$lang$Long$3x10$array$DistArray_Block_3$$T$2) null);
    }
    
    // constructor for non-virtual call
    final public x10.array.DistArray_Block_3<$T> x10$array$DistArray_Block_3$$init$S(final long m, final long n, final long p, final x10.lang.PlaceGroup pg, final x10.core.fun.Fun_0_3<x10.core.Long,x10.core.Long,x10.core.Long,$T> init, __4$1x10$lang$Long$3x10$lang$Long$3x10$lang$Long$3x10$array$DistArray_Block_3$$T$2 $dummy) {
         {
            
            //#line 64 "x10/array/DistArray_Block_3.x10"
            final x10.core.fun.Fun_0_0 t$109978 = ((x10.core.fun.Fun_0_0)(new x10.array.DistArray_Block_3.$Closure$17<$T>($T, pg, m, n, p, init, (x10.array.DistArray_Block_3.$Closure$17.__4$1x10$lang$Long$3x10$lang$Long$3x10$lang$Long$3x10$array$DistArray_Block_3$$Closure$17$$T$2) null)));
            
            //#line 268 . "x10/array/DistArray_Block_3.x10"
            boolean t$109983 = ((m) < (((long)(0L))));
            
            //#line 268 . "x10/array/DistArray_Block_3.x10"
            if (!(t$109983)) {
                
                //#line 268 . "x10/array/DistArray_Block_3.x10"
                t$109983 = ((n) < (((long)(0L))));
            }
            
            //#line 268 . "x10/array/DistArray_Block_3.x10"
            boolean t$109984 = t$109983;
            
            //#line 268 . "x10/array/DistArray_Block_3.x10"
            if (!(t$109983)) {
                
                //#line 268 . "x10/array/DistArray_Block_3.x10"
                t$109984 = ((p) < (((long)(0L))));
            }
            
            //#line 268 . "x10/array/DistArray_Block_3.x10"
            if (t$109984) {
                
                //#line 268 . "x10/array/DistArray_Block_3.x10"
                x10.array.DistArray.raiseNegativeArraySizeException();
            }
            
            //#line 269 . "x10/array/DistArray_Block_3.x10"
            final long t$109986 = ((m) * (((long)(n))));
            
            //#line 269 . "x10/array/DistArray_Block_3.x10"
            final long t$109987 = ((t$109986) * (((long)(p))));
            
            //#line 64 "x10/array/DistArray_Block_3.x10"
            /*super.*/x10$array$DistArray$$init$S(((x10.lang.PlaceGroup)(pg)), ((x10.core.fun.Fun_0_0)(t$109978)), t$109987, (x10.array.DistArray.__1$1x10$array$LocalState$1x10$array$DistArray$$T$2$2) null);
            
            //#line 63 "x10/array/DistArray_Block_3.x10"
            
            
            //#line 65 "x10/array/DistArray_Block_3.x10"
            final x10.array.DenseIterationSpace_3 alloc$109550 = ((x10.array.DenseIterationSpace_3)(new x10.array.DenseIterationSpace_3((java.lang.System[]) null)));
            
            //#line 65 "x10/array/DistArray_Block_3.x10"
            final long t$109989 = ((m) - (((long)(1L))));
            
            //#line 65 "x10/array/DistArray_Block_3.x10"
            final long t$109990 = ((n) - (((long)(1L))));
            
            //#line 65 "x10/array/DistArray_Block_3.x10"
            final long t$109991 = ((p) - (((long)(1L))));
            
            //#line 65 "x10/array/DistArray_Block_3.x10"
            alloc$109550.x10$array$DenseIterationSpace_3$$init$S(((long)(0L)), ((long)(0L)), ((long)(0L)), t$109989, t$109990, t$109991);
            
            //#line 65 "x10/array/DistArray_Block_3.x10"
            ((x10.array.DistArray_Block_3<$T>)this).globalIndices = ((x10.array.DenseIterationSpace_3)(alloc$109550));
            
            //#line 66 "x10/array/DistArray_Block_3.x10"
            ((x10.array.DistArray_Block_3<$T>)this).numElems_1 = m;
            
            //#line 67 "x10/array/DistArray_Block_3.x10"
            ((x10.array.DistArray_Block_3<$T>)this).numElems_2 = n;
            
            //#line 68 "x10/array/DistArray_Block_3.x10"
            ((x10.array.DistArray_Block_3<$T>)this).numElems_3 = p;
            
            //#line 69 "x10/array/DistArray_Block_3.x10"
            final x10.array.DenseIterationSpace_3 t$109791 = ((x10.array.DenseIterationSpace_3)(this.reloadLocalIndices()));
            
            //#line 69 "x10/array/DistArray_Block_3.x10"
            ((x10.array.DistArray_Block_3<$T>)this).localIndices = ((x10.array.DenseIterationSpace_3)(t$109791));
            
            //#line 70 "x10/array/DistArray_Block_3.x10"
            final x10.array.DistArray_Block_3 this$109707 = ((x10.array.DistArray_Block_3)(this));
            
            //#line 46 . "x10/array/DistArray_Block_3.x10"
            final x10.array.DenseIterationSpace_3 t$109792 = ((x10.array.DenseIterationSpace_3)(((x10.array.DistArray_Block_3<$T>)this$109707).localIndices));
            
            //#line 46 . "x10/array/DistArray_Block_3.x10"
            final long t$109793 = t$109792.min$O((long)(0L));
            
            //#line 70 "x10/array/DistArray_Block_3.x10"
            ((x10.array.DistArray_Block_3<$T>)this).minIndex_1 = t$109793;
            
            //#line 71 "x10/array/DistArray_Block_3.x10"
            final long t$109794 = this.reloadNumElemsLocal_1$O();
            
            //#line 71 "x10/array/DistArray_Block_3.x10"
            ((x10.array.DistArray_Block_3<$T>)this).numElemsLocal_1 = t$109794;
        }
        return this;
    }
    
    
    
    //#line 85 "x10/array/DistArray_Block_3.x10"
    /**
     * Construct a m by n by p block distributed DistArray
     * whose data is distributed over Place.places() and 
     * initialized using the provided init closure.
     *
     * @param m number of elements in the first dimension
     * @param n number of elements in the second dimension
     * @param p number of elements in the third dimension
     * @param init the element initialization function
     */
    // creation method for java code (1-phase java constructor)
    public DistArray_Block_3(final x10.rtt.Type $T, final long m, final long n, final long p, final x10.core.fun.Fun_0_3<x10.core.Long,x10.core.Long,x10.core.Long,$T> init, __3$1x10$lang$Long$3x10$lang$Long$3x10$lang$Long$3x10$array$DistArray_Block_3$$T$2 $dummy) {
        this((java.lang.System[]) null, $T);
        x10$array$DistArray_Block_3$$init$S(m, n, p, init, (x10.array.DistArray_Block_3.__3$1x10$lang$Long$3x10$lang$Long$3x10$lang$Long$3x10$array$DistArray_Block_3$$T$2) null);
    }
    
    // constructor for non-virtual call
    final public x10.array.DistArray_Block_3<$T> x10$array$DistArray_Block_3$$init$S(final long m, final long n, final long p, final x10.core.fun.Fun_0_3<x10.core.Long,x10.core.Long,x10.core.Long,$T> init, __3$1x10$lang$Long$3x10$lang$Long$3x10$lang$Long$3x10$array$DistArray_Block_3$$T$2 $dummy) {
         {
            
            //#line 86 "x10/array/DistArray_Block_3.x10"
            final x10.lang.PlaceGroup t$109795 = ((x10.lang.PlaceGroup)(x10.lang.Place.places()));
            
            //#line 86 "x10/array/DistArray_Block_3.x10"
            /*this.*/x10$array$DistArray_Block_3$$init$S(((long)(m)), ((long)(n)), ((long)(p)), t$109795, ((x10.core.fun.Fun_0_3)(init)), (x10.array.DistArray_Block_3.__4$1x10$lang$Long$3x10$lang$Long$3x10$lang$Long$3x10$array$DistArray_Block_3$$T$2) null);
        }
        return this;
    }
    
    
    
    //#line 99 "x10/array/DistArray_Block_3.x10"
    /**
     * Construct a m by n by p block distributed DistArray
     * whose data is distributed over pg and zero-initialized.
     *
     * @param m number of elements in the first dimension
     * @param n number of elements in the second dimension
     * @param p number of elements in the third dimension
     * @param pg the PlaceGroup to use to distibute the elements.
     */
    // creation method for java code (1-phase java constructor)
    public DistArray_Block_3(final x10.rtt.Type $T, final long m, final long n, final long p, final x10.lang.PlaceGroup pg) {
        this((java.lang.System[]) null, $T);
        x10$array$DistArray_Block_3$$init$S(m, n, p, pg);
    }
    
    // constructor for non-virtual call
    final public x10.array.DistArray_Block_3<$T> x10$array$DistArray_Block_3$$init$S(final long m, final long n, final long p, final x10.lang.PlaceGroup pg) {
         {
            
            //#line 100 "x10/array/DistArray_Block_3.x10"
            final x10.core.fun.Fun_0_3 t$109797 = ((x10.core.fun.Fun_0_3)(new x10.array.DistArray_Block_3.$Closure$18<$T>($T)));
            
            //#line 100 "x10/array/DistArray_Block_3.x10"
            /*this.*/x10$array$DistArray_Block_3$$init$S(((long)(m)), ((long)(n)), ((long)(p)), ((x10.lang.PlaceGroup)(pg)), ((x10.core.fun.Fun_0_3)(t$109797)), (x10.array.DistArray_Block_3.__4$1x10$lang$Long$3x10$lang$Long$3x10$lang$Long$3x10$array$DistArray_Block_3$$T$2) null);
        }
        return this;
    }
    
    
    
    //#line 113 "x10/array/DistArray_Block_3.x10"
    /**
     * Construct a m by n by p block distributed DistArray
     * whose data is distributed over Place.places() and 
     * zero-initialized.
     *
     * @param m number of elements in the first dimension
     * @param n number of elements in the second dimension
     * @param p number of elements in the second dimension
     */
    // creation method for java code (1-phase java constructor)
    public DistArray_Block_3(final x10.rtt.Type $T, final long m, final long n, final long p) {
        this((java.lang.System[]) null, $T);
        x10$array$DistArray_Block_3$$init$S(m, n, p);
    }
    
    // constructor for non-virtual call
    final public x10.array.DistArray_Block_3<$T> x10$array$DistArray_Block_3$$init$S(final long m, final long n, final long p) {
         {
            
            //#line 114 "x10/array/DistArray_Block_3.x10"
            final x10.lang.PlaceGroup t$109799 = ((x10.lang.PlaceGroup)(x10.lang.Place.places()));
            
            //#line 114 "x10/array/DistArray_Block_3.x10"
            final x10.core.fun.Fun_0_3 t$109800 = ((x10.core.fun.Fun_0_3)(new x10.array.DistArray_Block_3.$Closure$19<$T>($T)));
            
            //#line 114 "x10/array/DistArray_Block_3.x10"
            /*this.*/x10$array$DistArray_Block_3$$init$S(((long)(m)), ((long)(n)), ((long)(p)), t$109799, ((x10.core.fun.Fun_0_3)(t$109800)), (x10.array.DistArray_Block_3.__4$1x10$lang$Long$3x10$lang$Long$3x10$lang$Long$3x10$array$DistArray_Block_3$$T$2) null);
        }
        return this;
    }
    
    
    
    //#line 123 "x10/array/DistArray_Block_3.x10"
    /**
     * Get an IterationSpace that represents all Points contained in
     * the global iteration space (valid indices) of the DistArray.
     * @return an IterationSpace for the DistArray
     */
    final public x10.array.DenseIterationSpace_3 globalIndices() {
        
        //#line 123 "x10/array/DistArray_Block_3.x10"
        final x10.array.DenseIterationSpace_3 t$109801 = ((x10.array.DenseIterationSpace_3)(this.globalIndices));
        
        //#line 123 "x10/array/DistArray_Block_3.x10"
        return t$109801;
    }
    
    
    //#line 131 "x10/array/DistArray_Block_3.x10"
    /**
     * Get an IterationSpace that represents all Points contained in
     * the local iteration space (valid indices) of the DistArray at the current Place.
     * @return an IterationSpace for the local portion of the DistArray
     */
    final public x10.array.DenseIterationSpace_3 localIndices() {
        
        //#line 131 "x10/array/DistArray_Block_3.x10"
        final x10.array.DenseIterationSpace_3 t$109802 = ((x10.array.DenseIterationSpace_3)(this.localIndices));
        
        //#line 131 "x10/array/DistArray_Block_3.x10"
        return t$109802;
    }
    
    
    //#line 145 "x10/array/DistArray_Block_3.x10"
    /**
     * Return the Place which contains the data for the argument
     * index or Place.INVALID_PLACE if the Point is not in the globalIndices
     * of this DistArray
     *
     * @param i the index in the first dimension
     * @param j the index in the second dimension
     * @param k the index in the third dimension
     * @return the Place where (i,j,k) is a valid index in the DistArray; 
     *          will return Place.INVALID_PLACE if (i,j,k) is not contained in globalIndices
     */
    final public x10.lang.Place place(final long i, final long j, final long k) {
        
        //#line 146 "x10/array/DistArray_Block_3.x10"
        boolean t$109804 = ((j) < (((long)(0L))));
        
        //#line 146 "x10/array/DistArray_Block_3.x10"
        if (!(t$109804)) {
            
            //#line 146 "x10/array/DistArray_Block_3.x10"
            final long t$109803 = this.numElems_2;
            
            //#line 146 "x10/array/DistArray_Block_3.x10"
            t$109804 = ((j) >= (((long)(t$109803))));
        }
        
        //#line 146 "x10/array/DistArray_Block_3.x10"
        boolean t$109805 = t$109804;
        
        //#line 146 "x10/array/DistArray_Block_3.x10"
        if (!(t$109804)) {
            
            //#line 146 "x10/array/DistArray_Block_3.x10"
            t$109805 = ((k) < (((long)(0L))));
        }
        
        //#line 146 "x10/array/DistArray_Block_3.x10"
        boolean t$109807 = t$109805;
        
        //#line 146 "x10/array/DistArray_Block_3.x10"
        if (!(t$109805)) {
            
            //#line 146 "x10/array/DistArray_Block_3.x10"
            final long t$109806 = this.numElems_3;
            
            //#line 146 "x10/array/DistArray_Block_3.x10"
            t$109807 = ((k) >= (((long)(t$109806))));
        }
        
        //#line 146 "x10/array/DistArray_Block_3.x10"
        if (t$109807) {
            
            //#line 146 "x10/array/DistArray_Block_3.x10"
            final x10.lang.Place t$109808 = ((x10.lang.Place)(x10.lang.Place.get$INVALID_PLACE()));
            
            //#line 146 "x10/array/DistArray_Block_3.x10"
            return t$109808;
        }
        
        //#line 147 "x10/array/DistArray_Block_3.x10"
        final long t$109810 = this.numElems_1;
        
        //#line 147 "x10/array/DistArray_Block_3.x10"
        final long t$109811 = ((t$109810) - (((long)(1L))));
        
        //#line 147 "x10/array/DistArray_Block_3.x10"
        final x10.lang.PlaceGroup this$109709 = ((x10.lang.PlaceGroup)(this.placeGroup));
        
        //#line 35 . "x10/lang/PlaceGroup.x10"
        final long t$109812 = this$109709.numPlaces$O();
        
        //#line 147 "x10/array/DistArray_Block_3.x10"
        final long tmp = x10.array.BlockingUtils.mapIndexToBlockPartition$O((long)(0L), (long)(t$109811), (long)(t$109812), (long)(i));
        
        //#line 148 "x10/array/DistArray_Block_3.x10"
        final boolean t$109814 = ((long) tmp) == ((long) -1L);
        
        //#line 148 "x10/array/DistArray_Block_3.x10"
        x10.lang.Place t$109815 =  null;
        
        //#line 148 "x10/array/DistArray_Block_3.x10"
        if (t$109814) {
            
            //#line 148 "x10/array/DistArray_Block_3.x10"
            t$109815 = x10.lang.Place.get$INVALID_PLACE();
        } else {
            
            //#line 148 "x10/array/DistArray_Block_3.x10"
            final x10.lang.PlaceGroup t$109813 = ((x10.lang.PlaceGroup)(this.placeGroup));
            
            //#line 148 "x10/array/DistArray_Block_3.x10"
            t$109815 = t$109813.$apply((long)(tmp));
        }
        
        //#line 148 "x10/array/DistArray_Block_3.x10"
        return t$109815;
    }
    
    
    //#line 161 "x10/array/DistArray_Block_3.x10"
    /**
     * Return the Place which contains the data for the argument
     * Point or Place.INVALID_PLACE if the Point is not in the globalIndices
     * of this DistArray
     *
     * @param p the Point to lookup
     * @return the Place where p is a valid index in the DistArray; 
     *          will return Place.INVALID_PLACE if p is not contained in globalIndices
     */
    final public x10.lang.Place place(final x10.lang.Point p) {
        
        //#line 161 "x10/array/DistArray_Block_3.x10"
        final long t$109817 = p.$apply$O((long)(0L));
        
        //#line 161 "x10/array/DistArray_Block_3.x10"
        final long t$109818 = p.$apply$O((long)(1L));
        
        //#line 161 "x10/array/DistArray_Block_3.x10"
        final long t$109819 = p.$apply$O((long)(2L));
        
        //#line 161 "x10/array/DistArray_Block_3.x10"
        final x10.lang.Place t$109820 = this.place((long)(t$109817), (long)(t$109818), (long)(t$109819));
        
        //#line 161 "x10/array/DistArray_Block_3.x10"
        return t$109820;
    }
    
    
    //#line 173 "x10/array/DistArray_Block_3.x10"
    /**
     * Return the element of this array corresponding to the given index.
     * 
     * @param i the given index in the first dimension
     * @param j the given index in the second dimension
     * @param k the given index in the third dimension
     * @return the element of this array corresponding to the given index.
     * @see #set(T, Long, Long, Long)
     */
    final public $T $apply$G(final long i, final long j, final long k) {
        
        //#line 174 "x10/array/DistArray_Block_3.x10"
        this.validateIndex((long)(i), (long)(j), (long)(k));
        
        //#line 175 "x10/array/DistArray_Block_3.x10"
        final x10.core.Rail r$109716 = ((x10.core.Rail)(this.raw));
        
        //#line 175 "x10/array/DistArray_Block_3.x10"
        final x10.array.DistArray_Block_3 this$109714 = ((x10.array.DistArray_Block_3)(this));
        
        //#line 238 . "x10/array/DistArray_Block_3.x10"
        final long t$109825 = ((x10.array.DistArray_Block_3<$T>)this$109714).numElems_3;
        
        //#line 238 . "x10/array/DistArray_Block_3.x10"
        final long t$109821 = ((x10.array.DistArray_Block_3<$T>)this$109714).minIndex_1;
        
        //#line 238 . "x10/array/DistArray_Block_3.x10"
        final long t$109822 = ((i) - (((long)(t$109821))));
        
        //#line 238 . "x10/array/DistArray_Block_3.x10"
        final long t$109823 = ((x10.array.DistArray_Block_3<$T>)this$109714).numElems_2;
        
        //#line 238 . "x10/array/DistArray_Block_3.x10"
        final long t$109824 = ((t$109822) * (((long)(t$109823))));
        
        //#line 238 . "x10/array/DistArray_Block_3.x10"
        final long t$109826 = ((j) + (((long)(t$109824))));
        
        //#line 238 . "x10/array/DistArray_Block_3.x10"
        final long t$109827 = ((t$109825) * (((long)(t$109826))));
        
        //#line 175 "x10/array/DistArray_Block_3.x10"
        final long i$109717 = ((k) + (((long)(t$109827))));
        
        //#line 38 . "x10/lang/Unsafe.x10"
        final $T t$109828 = (($T)(((x10.core.Rail<$T>)r$109716).$apply$G((long)(i$109717))));
        
        //#line 175 "x10/array/DistArray_Block_3.x10"
        return t$109828;
    }
    
    
    //#line 186 "x10/array/DistArray_Block_3.x10"
    /**
     * Return the element of this array corresponding to the given Point.
     * 
     * @param p the given Point
     * @return the element of this array corresponding to the given Point.
     * @see #set(T, Point)
     */
    final public $T $apply$G(final x10.lang.Point p) {
        
        //#line 186 "x10/array/DistArray_Block_3.x10"
        final x10.array.DistArray_Block_3 this$109722 = ((x10.array.DistArray_Block_3)(this));
        
        //#line 186 "x10/array/DistArray_Block_3.x10"
        final long i$109719 = p.$apply$O((long)(0L));
        
        //#line 186 "x10/array/DistArray_Block_3.x10"
        final long j$109720 = p.$apply$O((long)(1L));
        
        //#line 186 "x10/array/DistArray_Block_3.x10"
        final long k$109721 = p.$apply$O((long)(2L));
        
        //#line 174 . "x10/array/DistArray_Block_3.x10"
        ((x10.array.DistArray_Block_3<$T>)this$109722).validateIndex((long)(i$109719), (long)(j$109720), (long)(k$109721));
        
        //#line 175 . "x10/array/DistArray_Block_3.x10"
        final x10.core.Rail r$109728 = ((x10.core.Rail)(((x10.array.DistArray<$T>)this$109722).raw));
        
        //#line 238 .. "x10/array/DistArray_Block_3.x10"
        final long t$109833 = ((x10.array.DistArray_Block_3<$T>)this$109722).numElems_3;
        
        //#line 238 .. "x10/array/DistArray_Block_3.x10"
        final long t$109829 = ((x10.array.DistArray_Block_3<$T>)this$109722).minIndex_1;
        
        //#line 238 .. "x10/array/DistArray_Block_3.x10"
        final long t$109830 = ((i$109719) - (((long)(t$109829))));
        
        //#line 238 .. "x10/array/DistArray_Block_3.x10"
        final long t$109831 = ((x10.array.DistArray_Block_3<$T>)this$109722).numElems_2;
        
        //#line 238 .. "x10/array/DistArray_Block_3.x10"
        final long t$109832 = ((t$109830) * (((long)(t$109831))));
        
        //#line 238 .. "x10/array/DistArray_Block_3.x10"
        final long t$109834 = ((j$109720) + (((long)(t$109832))));
        
        //#line 238 .. "x10/array/DistArray_Block_3.x10"
        final long t$109835 = ((t$109833) * (((long)(t$109834))));
        
        //#line 175 . "x10/array/DistArray_Block_3.x10"
        final long i$109729 = ((k$109721) + (((long)(t$109835))));
        
        //#line 38 .. "x10/lang/Unsafe.x10"
        final $T t$109836 = (($T)(((x10.core.Rail<$T>)r$109728).$apply$G((long)(i$109729))));
        
        //#line 186 "x10/array/DistArray_Block_3.x10"
        return t$109836;
    }
    
    
    //#line 200 "x10/array/DistArray_Block_3.x10"
    /**
     * Set the element of this array corresponding to the given index to the given value.
     * Return the new value of the element.
     * 
     * @param v the given value
     * @param i the given index in the first dimension
     * @param j the given index in the second dimension
     * @param k the given index in the third dimension
     * @return the new value of the element of this array corresponding to the given index.
     * @see #operator(Long, Long, Long)
     */
    final public $T $set__3x10$array$DistArray_Block_3$$T$G(final long i, final long j, final long k, final $T v) {
        
        //#line 201 "x10/array/DistArray_Block_3.x10"
        this.validateIndex((long)(i), (long)(j), (long)(k));
        
        //#line 202 "x10/array/DistArray_Block_3.x10"
        final x10.core.Rail r$109736 = ((x10.core.Rail)(this.raw));
        
        //#line 202 "x10/array/DistArray_Block_3.x10"
        final x10.array.DistArray_Block_3 this$109734 = ((x10.array.DistArray_Block_3)(this));
        
        //#line 238 . "x10/array/DistArray_Block_3.x10"
        final long t$109841 = ((x10.array.DistArray_Block_3<$T>)this$109734).numElems_3;
        
        //#line 238 . "x10/array/DistArray_Block_3.x10"
        final long t$109837 = ((x10.array.DistArray_Block_3<$T>)this$109734).minIndex_1;
        
        //#line 238 . "x10/array/DistArray_Block_3.x10"
        final long t$109838 = ((i) - (((long)(t$109837))));
        
        //#line 238 . "x10/array/DistArray_Block_3.x10"
        final long t$109839 = ((x10.array.DistArray_Block_3<$T>)this$109734).numElems_2;
        
        //#line 238 . "x10/array/DistArray_Block_3.x10"
        final long t$109840 = ((t$109838) * (((long)(t$109839))));
        
        //#line 238 . "x10/array/DistArray_Block_3.x10"
        final long t$109842 = ((j) + (((long)(t$109840))));
        
        //#line 238 . "x10/array/DistArray_Block_3.x10"
        final long t$109843 = ((t$109841) * (((long)(t$109842))));
        
        //#line 202 "x10/array/DistArray_Block_3.x10"
        final long i$109737 = ((k) + (((long)(t$109843))));
        
        //#line 42 . "x10/lang/Unsafe.x10"
        ((x10.core.Rail<$T>)r$109736).$set__1x10$lang$Rail$$T$G((long)(i$109737), (($T)(v)));
        
        //#line 202 "x10/array/DistArray_Block_3.x10"
        return (($T)
                 v);
    }
    
    
    //#line 215 "x10/array/DistArray_Block_3.x10"
    /**
     * Set the element of this array corresponding to the given Point to the given value.
     * Return the new value of the element.
     * 
     * @param v the given value
     * @param p the given Point
     * @return the new value of the element of this array corresponding to the given Point.
     * @see #operator(Point)
     */
    final public $T $set__1x10$array$DistArray_Block_3$$T$G(final x10.lang.Point p, final $T v) {
        
        //#line 215 "x10/array/DistArray_Block_3.x10"
        final x10.array.DistArray_Block_3 this$109744 = ((x10.array.DistArray_Block_3)(this));
        
        //#line 215 "x10/array/DistArray_Block_3.x10"
        final long i$109740 = p.$apply$O((long)(0L));
        
        //#line 215 "x10/array/DistArray_Block_3.x10"
        final long j$109741 = p.$apply$O((long)(1L));
        
        //#line 215 "x10/array/DistArray_Block_3.x10"
        final long k$109742 = p.$apply$O((long)(2L));
        
        //#line 201 . "x10/array/DistArray_Block_3.x10"
        ((x10.array.DistArray_Block_3<$T>)this$109744).validateIndex((long)(i$109740), (long)(j$109741), (long)(k$109742));
        
        //#line 202 . "x10/array/DistArray_Block_3.x10"
        final x10.core.Rail r$109750 = ((x10.core.Rail)(((x10.array.DistArray<$T>)this$109744).raw));
        
        //#line 238 .. "x10/array/DistArray_Block_3.x10"
        final long t$109848 = ((x10.array.DistArray_Block_3<$T>)this$109744).numElems_3;
        
        //#line 238 .. "x10/array/DistArray_Block_3.x10"
        final long t$109844 = ((x10.array.DistArray_Block_3<$T>)this$109744).minIndex_1;
        
        //#line 238 .. "x10/array/DistArray_Block_3.x10"
        final long t$109845 = ((i$109740) - (((long)(t$109844))));
        
        //#line 238 .. "x10/array/DistArray_Block_3.x10"
        final long t$109846 = ((x10.array.DistArray_Block_3<$T>)this$109744).numElems_2;
        
        //#line 238 .. "x10/array/DistArray_Block_3.x10"
        final long t$109847 = ((t$109845) * (((long)(t$109846))));
        
        //#line 238 .. "x10/array/DistArray_Block_3.x10"
        final long t$109849 = ((j$109741) + (((long)(t$109847))));
        
        //#line 238 .. "x10/array/DistArray_Block_3.x10"
        final long t$109850 = ((t$109848) * (((long)(t$109849))));
        
        //#line 202 . "x10/array/DistArray_Block_3.x10"
        final long i$109751 = ((k$109742) + (((long)(t$109850))));
        
        //#line 42 .. "x10/lang/Unsafe.x10"
        ((x10.core.Rail<$T>)r$109750).$set__1x10$lang$Rail$$T$G((long)(i$109751), (($T)(v)));
        
        //#line 215 "x10/array/DistArray_Block_3.x10"
        return (($T)
                 v);
    }
    
    
    //#line 223 "x10/array/DistArray_Block_3.x10"
    final public void validateIndex(final long i, final long j, final long k) {
        
        //#line 225 "x10/array/DistArray_Block_3.x10"
        boolean t$109852 = ((j) < (((long)(0L))));
        
        //#line 225 "x10/array/DistArray_Block_3.x10"
        if (!(t$109852)) {
            
            //#line 225 "x10/array/DistArray_Block_3.x10"
            final long t$109851 = this.numElems_2;
            
            //#line 225 "x10/array/DistArray_Block_3.x10"
            t$109852 = ((j) >= (((long)(t$109851))));
        }
        
        //#line 225 "x10/array/DistArray_Block_3.x10"
        boolean t$109853 = t$109852;
        
        //#line 225 "x10/array/DistArray_Block_3.x10"
        if (!(t$109852)) {
            
            //#line 225 "x10/array/DistArray_Block_3.x10"
            t$109853 = ((k) < (((long)(0L))));
        }
        
        //#line 225 "x10/array/DistArray_Block_3.x10"
        boolean t$109855 = t$109853;
        
        //#line 225 "x10/array/DistArray_Block_3.x10"
        if (!(t$109853)) {
            
            //#line 225 "x10/array/DistArray_Block_3.x10"
            final long t$109854 = this.numElems_3;
            
            //#line 225 "x10/array/DistArray_Block_3.x10"
            t$109855 = ((k) >= (((long)(t$109854))));
        }
        
        //#line 225 "x10/array/DistArray_Block_3.x10"
        if (t$109855) {
            
            //#line 226 "x10/array/DistArray_Block_3.x10"
            x10.array.DistArray.raiseBoundsError((long)(i), (long)(j), (long)(k));
        }
        
        //#line 228 "x10/array/DistArray_Block_3.x10"
        final long t$109857 = this.minIndex_1;
        
        //#line 228 "x10/array/DistArray_Block_3.x10"
        boolean t$109861 = ((i) < (((long)(t$109857))));
        
        //#line 228 "x10/array/DistArray_Block_3.x10"
        if (!(t$109861)) {
            
            //#line 228 "x10/array/DistArray_Block_3.x10"
            final long t$109858 = this.minIndex_1;
            
            //#line 228 "x10/array/DistArray_Block_3.x10"
            final long t$109859 = this.numElemsLocal_1;
            
            //#line 228 "x10/array/DistArray_Block_3.x10"
            final long t$109860 = ((t$109858) + (((long)(t$109859))));
            
            //#line 228 "x10/array/DistArray_Block_3.x10"
            t$109861 = ((i) >= (((long)(t$109860))));
        }
        
        //#line 228 "x10/array/DistArray_Block_3.x10"
        if (t$109861) {
            
            //#line 229 "x10/array/DistArray_Block_3.x10"
            boolean t$109863 = ((i) < (((long)(0L))));
            
            //#line 229 "x10/array/DistArray_Block_3.x10"
            if (!(t$109863)) {
                
                //#line 229 "x10/array/DistArray_Block_3.x10"
                final long t$109862 = this.numElems_1;
                
                //#line 229 "x10/array/DistArray_Block_3.x10"
                t$109863 = ((i) >= (((long)(t$109862))));
            }
            
            //#line 229 "x10/array/DistArray_Block_3.x10"
            if (t$109863) {
                
                //#line 230 "x10/array/DistArray_Block_3.x10"
                x10.array.DistArray.raiseBoundsError((long)(i), (long)(j), (long)(k));
            }
            
            //#line 232 "x10/array/DistArray_Block_3.x10"
            x10.array.DistArray.raisePlaceError((long)(i), (long)(j), (long)(k));
        }
    }
    
    
    //#line 237 "x10/array/DistArray_Block_3.x10"
    final public long offset$O(final long i, final long j, final long k) {
        
        //#line 238 "x10/array/DistArray_Block_3.x10"
        final long t$109870 = this.numElems_3;
        
        //#line 238 "x10/array/DistArray_Block_3.x10"
        final long t$109866 = this.minIndex_1;
        
        //#line 238 "x10/array/DistArray_Block_3.x10"
        final long t$109867 = ((i) - (((long)(t$109866))));
        
        //#line 238 "x10/array/DistArray_Block_3.x10"
        final long t$109868 = this.numElems_2;
        
        //#line 238 "x10/array/DistArray_Block_3.x10"
        final long t$109869 = ((t$109867) * (((long)(t$109868))));
        
        //#line 238 "x10/array/DistArray_Block_3.x10"
        final long t$109871 = ((j) + (((long)(t$109869))));
        
        //#line 238 "x10/array/DistArray_Block_3.x10"
        final long t$109872 = ((t$109870) * (((long)(t$109871))));
        
        //#line 238 "x10/array/DistArray_Block_3.x10"
        final long t$109873 = ((k) + (((long)(t$109872))));
        
        //#line 238 "x10/array/DistArray_Block_3.x10"
        return t$109873;
    }
    
    
    //#line 249 "x10/array/DistArray_Block_3.x10"
    /**
     * Returns the specified rectangular patch of this array as a Rail.
     * 
     * @param space the IterationSpace representing the portion of this array to copy
     * @see offset
     * @throws ArrayIndexOutOfBoundsException if the specified region is not
     *        contained in this array
     */
    public x10.core.Rail getPatch(final x10.array.IterationSpace space) {
        
        //#line 250 "x10/array/DistArray_Block_3.x10"
        final x10.array.DenseIterationSpace_3 r = ((x10.array.DenseIterationSpace_3)(x10.rtt.Types.<x10.array.DenseIterationSpace_3> cast(space,x10.array.DenseIterationSpace_3.$RTT)));
        
        //#line 253 "x10/array/DistArray_Block_3.x10"
        final x10.array.DenseIterationSpace_3 t$109874 = ((x10.array.DenseIterationSpace_3)(this.localIndices));
        
        //#line 253 "x10/array/DistArray_Block_3.x10"
        final long t$109875 = t$109874.min0;
        
        //#line 253 "x10/array/DistArray_Block_3.x10"
        final long t$109876 = r.min0;
        
        //#line 253 "x10/array/DistArray_Block_3.x10"
        boolean t$109880 = ((t$109875) <= (((long)(t$109876))));
        
        //#line 253 "x10/array/DistArray_Block_3.x10"
        if (t$109880) {
            
            //#line 253 "x10/array/DistArray_Block_3.x10"
            final long t$109878 = r.max0;
            
            //#line 253 "x10/array/DistArray_Block_3.x10"
            final x10.array.DenseIterationSpace_3 t$109877 = ((x10.array.DenseIterationSpace_3)(this.localIndices));
            
            //#line 253 "x10/array/DistArray_Block_3.x10"
            final long t$109879 = t$109877.max0;
            
            //#line 253 "x10/array/DistArray_Block_3.x10"
            t$109880 = ((t$109878) <= (((long)(t$109879))));
        }
        
        //#line 253 "x10/array/DistArray_Block_3.x10"
        boolean t$109884 = t$109880;
        
        //#line 253 "x10/array/DistArray_Block_3.x10"
        if (t$109880) {
            
            //#line 254 "x10/array/DistArray_Block_3.x10"
            final x10.array.DenseIterationSpace_3 t$109881 = ((x10.array.DenseIterationSpace_3)(this.localIndices));
            
            //#line 254 "x10/array/DistArray_Block_3.x10"
            final long t$109882 = t$109881.min1;
            
            //#line 254 "x10/array/DistArray_Block_3.x10"
            final long t$109883 = r.min1;
            
            //#line 253 "x10/array/DistArray_Block_3.x10"
            t$109884 = ((t$109882) <= (((long)(t$109883))));
        }
        
        //#line 253 "x10/array/DistArray_Block_3.x10"
        boolean t$109888 = t$109884;
        
        //#line 253 "x10/array/DistArray_Block_3.x10"
        if (t$109884) {
            
            //#line 254 "x10/array/DistArray_Block_3.x10"
            final long t$109886 = r.max1;
            
            //#line 254 "x10/array/DistArray_Block_3.x10"
            final x10.array.DenseIterationSpace_3 t$109885 = ((x10.array.DenseIterationSpace_3)(this.localIndices));
            
            //#line 254 "x10/array/DistArray_Block_3.x10"
            final long t$109887 = t$109885.max1;
            
            //#line 253 "x10/array/DistArray_Block_3.x10"
            t$109888 = ((t$109886) <= (((long)(t$109887))));
        }
        
        //#line 253 "x10/array/DistArray_Block_3.x10"
        boolean t$109892 = t$109888;
        
        //#line 253 "x10/array/DistArray_Block_3.x10"
        if (t$109888) {
            
            //#line 255 "x10/array/DistArray_Block_3.x10"
            final x10.array.DenseIterationSpace_3 t$109889 = ((x10.array.DenseIterationSpace_3)(this.localIndices));
            
            //#line 255 "x10/array/DistArray_Block_3.x10"
            final long t$109890 = t$109889.min2;
            
            //#line 255 "x10/array/DistArray_Block_3.x10"
            final long t$109891 = r.min2;
            
            //#line 253 "x10/array/DistArray_Block_3.x10"
            t$109892 = ((t$109890) <= (((long)(t$109891))));
        }
        
        //#line 253 "x10/array/DistArray_Block_3.x10"
        boolean t$109896 = t$109892;
        
        //#line 253 "x10/array/DistArray_Block_3.x10"
        if (t$109892) {
            
            //#line 255 "x10/array/DistArray_Block_3.x10"
            final long t$109894 = r.max2;
            
            //#line 255 "x10/array/DistArray_Block_3.x10"
            final x10.array.DenseIterationSpace_3 t$109893 = ((x10.array.DenseIterationSpace_3)(this.localIndices));
            
            //#line 255 "x10/array/DistArray_Block_3.x10"
            final long t$109895 = t$109893.max2;
            
            //#line 253 "x10/array/DistArray_Block_3.x10"
            t$109896 = ((t$109894) <= (((long)(t$109895))));
        }
        
        //#line 253 "x10/array/DistArray_Block_3.x10"
        final boolean t$109903 = !(t$109896);
        
        //#line 252 "x10/array/DistArray_Block_3.x10"
        if (t$109903) {
            
            //#line 256 "x10/array/DistArray_Block_3.x10"
            final java.lang.String t$109898 = (("patch to copy: ") + (r));
            
            //#line 256 "x10/array/DistArray_Block_3.x10"
            final java.lang.String t$109899 = ((t$109898) + (" not contained in local indices: "));
            
            //#line 256 "x10/array/DistArray_Block_3.x10"
            final x10.array.DenseIterationSpace_3 t$109900 = ((x10.array.DenseIterationSpace_3)(this.localIndices));
            
            //#line 256 "x10/array/DistArray_Block_3.x10"
            final java.lang.String t$109901 = ((t$109899) + (t$109900));
            
            //#line 256 "x10/array/DistArray_Block_3.x10"
            final java.lang.ArrayIndexOutOfBoundsException t$109902 = ((java.lang.ArrayIndexOutOfBoundsException)(new java.lang.ArrayIndexOutOfBoundsException(t$109901)));
            
            //#line 256 "x10/array/DistArray_Block_3.x10"
            throw t$109902;
        }
        
        //#line 259 "x10/array/DistArray_Block_3.x10"
        final long t$109904 = r.size$O();
        
        //#line 259 "x10/array/DistArray_Block_3.x10"
        final x10.core.Rail patch = ((x10.core.Rail)(x10.core.Rail.<$T>makeUnsafe($T, ((long)(t$109904)), false)));
        
        //#line 260 "x10/array/DistArray_Block_3.x10"
        long patchIndex = 0L;
        
        //#line 261 "x10/array/DistArray_Block_3.x10"
        final long i2$109554min$110028 = r.min$O((long)(2L));
        
        //#line 261 "x10/array/DistArray_Block_3.x10"
        final long i2$109554max$110029 = r.max$O((long)(2L));
        
        //#line 261 "x10/array/DistArray_Block_3.x10"
        final long i1$109585min$110030 = r.min$O((long)(1L));
        
        //#line 261 "x10/array/DistArray_Block_3.x10"
        final long i1$109585max$110031 = r.max$O((long)(1L));
        
        //#line 261 "x10/array/DistArray_Block_3.x10"
        final long i0$109616min$110032 = r.min$O((long)(0L));
        
        //#line 261 "x10/array/DistArray_Block_3.x10"
        final long i0$109616max$110033 = r.max$O((long)(0L));
        
        //#line 261 "x10/array/DistArray_Block_3.x10"
        long i$110024 = i0$109616min$110032;
        
        //#line 261 "x10/array/DistArray_Block_3.x10"
        for (;
             true;
             ) {
            
            //#line 261 "x10/array/DistArray_Block_3.x10"
            final boolean t$110026 = ((i$110024) <= (((long)(i0$109616max$110033))));
            
            //#line 261 "x10/array/DistArray_Block_3.x10"
            if (!(t$110026)) {
                
                //#line 261 "x10/array/DistArray_Block_3.x10"
                break;
            }
            
            //#line 261 "x10/array/DistArray_Block_3.x10"
            long i$110018 = i1$109585min$110030;
            
            //#line 261 "x10/array/DistArray_Block_3.x10"
            for (;
                 true;
                 ) {
                
                //#line 261 "x10/array/DistArray_Block_3.x10"
                final boolean t$110020 = ((i$110018) <= (((long)(i1$109585max$110031))));
                
                //#line 261 "x10/array/DistArray_Block_3.x10"
                if (!(t$110020)) {
                    
                    //#line 261 "x10/array/DistArray_Block_3.x10"
                    break;
                }
                
                //#line 261 "x10/array/DistArray_Block_3.x10"
                long i$110012 = i2$109554min$110028;
                
                //#line 261 "x10/array/DistArray_Block_3.x10"
                for (;
                     true;
                     ) {
                    
                    //#line 261 "x10/array/DistArray_Block_3.x10"
                    final boolean t$110014 = ((i$110012) <= (((long)(i2$109554max$110029))));
                    
                    //#line 261 "x10/array/DistArray_Block_3.x10"
                    if (!(t$110014)) {
                        
                        //#line 261 "x10/array/DistArray_Block_3.x10"
                        break;
                    }
                    
                    //#line 262 "x10/array/DistArray_Block_3.x10"
                    final long pre$109992 = patchIndex;
                    
                    //#line 262 "x10/array/DistArray_Block_3.x10"
                    final long t$109994 = ((patchIndex) + (((long)(1L))));
                    
                    //#line 262 "x10/array/DistArray_Block_3.x10"
                    patchIndex = t$109994;
                    
                    //#line 262 "x10/array/DistArray_Block_3.x10"
                    final x10.core.Rail t$109995 = ((x10.core.Rail)(this.raw));
                    
                    //#line 262 "x10/array/DistArray_Block_3.x10"
                    final x10.array.DistArray_Block_3 this$109996 = ((x10.array.DistArray_Block_3)(this));
                    
                    //#line 238 . "x10/array/DistArray_Block_3.x10"
                    final long t$110000 = ((x10.array.DistArray_Block_3<$T>)this$109996).numElems_3;
                    
                    //#line 238 . "x10/array/DistArray_Block_3.x10"
                    final long t$110001 = ((x10.array.DistArray_Block_3<$T>)this$109996).minIndex_1;
                    
                    //#line 238 . "x10/array/DistArray_Block_3.x10"
                    final long t$110002 = ((i$110024) - (((long)(t$110001))));
                    
                    //#line 238 . "x10/array/DistArray_Block_3.x10"
                    final long t$110003 = ((x10.array.DistArray_Block_3<$T>)this$109996).numElems_2;
                    
                    //#line 238 . "x10/array/DistArray_Block_3.x10"
                    final long t$110004 = ((t$110002) * (((long)(t$110003))));
                    
                    //#line 238 . "x10/array/DistArray_Block_3.x10"
                    final long t$110005 = ((i$110018) + (((long)(t$110004))));
                    
                    //#line 238 . "x10/array/DistArray_Block_3.x10"
                    final long t$110006 = ((t$110000) * (((long)(t$110005))));
                    
                    //#line 238 . "x10/array/DistArray_Block_3.x10"
                    final long t$110007 = ((i$110012) + (((long)(t$110006))));
                    
                    //#line 262 "x10/array/DistArray_Block_3.x10"
                    final $T t$110008 = (($T)(((x10.core.Rail<$T>)t$109995).$apply$G((long)(t$110007))));
                    
                    //#line 262 "x10/array/DistArray_Block_3.x10"
                    ((x10.core.Rail<$T>)patch).$set__1x10$lang$Rail$$T$G((long)(pre$109992), (($T)(t$110008)));
                    
                    //#line 261 "x10/array/DistArray_Block_3.x10"
                    final long t$110011 = ((i$110012) + (((long)(1L))));
                    
                    //#line 261 "x10/array/DistArray_Block_3.x10"
                    i$110012 = t$110011;
                }
                
                //#line 261 "x10/array/DistArray_Block_3.x10"
                final long t$110017 = ((i$110018) + (((long)(1L))));
                
                //#line 261 "x10/array/DistArray_Block_3.x10"
                i$110018 = t$110017;
            }
            
            //#line 261 "x10/array/DistArray_Block_3.x10"
            final long t$110023 = ((i$110024) + (((long)(1L))));
            
            //#line 261 "x10/array/DistArray_Block_3.x10"
            i$110024 = t$110023;
        }
        
        //#line 264 "x10/array/DistArray_Block_3.x10"
        return patch;
    }
    
    
    //#line 267 "x10/array/DistArray_Block_3.x10"
    private static long validateSize$O(final long m, final long n, final long p) {
        
        //#line 268 "x10/array/DistArray_Block_3.x10"
        boolean t$109932 = ((m) < (((long)(0L))));
        
        //#line 268 "x10/array/DistArray_Block_3.x10"
        if (!(t$109932)) {
            
            //#line 268 "x10/array/DistArray_Block_3.x10"
            t$109932 = ((n) < (((long)(0L))));
        }
        
        //#line 268 "x10/array/DistArray_Block_3.x10"
        boolean t$109933 = t$109932;
        
        //#line 268 "x10/array/DistArray_Block_3.x10"
        if (!(t$109932)) {
            
            //#line 268 "x10/array/DistArray_Block_3.x10"
            t$109933 = ((p) < (((long)(0L))));
        }
        
        //#line 268 "x10/array/DistArray_Block_3.x10"
        if (t$109933) {
            
            //#line 268 "x10/array/DistArray_Block_3.x10"
            x10.array.DistArray.raiseNegativeArraySizeException();
        }
        
        //#line 269 "x10/array/DistArray_Block_3.x10"
        final long t$109935 = ((m) * (((long)(n))));
        
        //#line 269 "x10/array/DistArray_Block_3.x10"
        final long t$109936 = ((t$109935) * (((long)(p))));
        
        //#line 269 "x10/array/DistArray_Block_3.x10"
        return t$109936;
    }
    
    public static long validateSize$P$O(final long m, final long n, final long p) {
        return x10.array.DistArray_Block_3.validateSize$O((long)(m), (long)(n), (long)(p));
    }
    
    
    //#line 24 "x10/array/DistArray_Block_3.x10"
    final public x10.array.DistArray_Block_3 x10$array$DistArray_Block_3$$this$x10$array$DistArray_Block_3() {
        
        //#line 24 "x10/array/DistArray_Block_3.x10"
        return x10.array.DistArray_Block_3.this;
    }
    
    
    //#line 24 "x10/array/DistArray_Block_3.x10"
    final public void __fieldInitializers_x10_array_DistArray_Block_3() {
        
    }
    
    @x10.runtime.impl.java.X10Generated
    final public static class $Closure$17<$T> extends x10.core.Ref implements x10.core.fun.Fun_0_0, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<$Closure$17> $RTT = 
            x10.rtt.StaticFunType.<$Closure$17> make($Closure$17.class,
                                                     1,
                                                     new x10.rtt.Type[] {
                                                         x10.rtt.ParameterizedType.make(x10.core.fun.Fun_0_0.$RTT, x10.rtt.ParameterizedType.make(x10.array.LocalState_B3.$RTT, x10.rtt.UnresolvedType.PARAM(0)))
                                                     });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { if (i == 0) return $T; return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static <$T> x10.serialization.X10JavaSerializable $_deserialize_body(x10.array.DistArray_Block_3.$Closure$17<$T> $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            $_obj.$T = (x10.rtt.Type) $deserializer.readObject();
            $_obj.init = $deserializer.readObject();
            $_obj.m = $deserializer.readLong();
            $_obj.n = $deserializer.readLong();
            $_obj.p = $deserializer.readLong();
            $_obj.pg = $deserializer.readObject();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.array.DistArray_Block_3.$Closure$17 $_obj = new x10.array.DistArray_Block_3.$Closure$17((java.lang.System[]) null, (x10.rtt.Type) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            $serializer.write(this.$T);
            $serializer.write(this.init);
            $serializer.write(this.m);
            $serializer.write(this.n);
            $serializer.write(this.p);
            $serializer.write(this.pg);
            
        }
        
        // constructor just for allocation
        public $Closure$17(final java.lang.System[] $dummy, final x10.rtt.Type $T) {
            x10.array.DistArray_Block_3.$Closure$17.$initParams(this, $T);
            
        }
        
        // bridge for method abstract public ()=>U.operator()():U
        public x10.array.LocalState_B3 $apply$G() {
            return $apply();
        }
        
        private x10.rtt.Type $T;
        
        // initializer of type parameters
        public static void $initParams(final $Closure$17 $this, final x10.rtt.Type $T) {
            $this.$T = $T;
            
        }
        // synthetic type for parameter mangling
        public static final class __4$1x10$lang$Long$3x10$lang$Long$3x10$lang$Long$3x10$array$DistArray_Block_3$$Closure$17$$T$2 {}
        
    
        
        public x10.array.LocalState_B3 $apply() {
            
            //#line 64 "x10/array/DistArray_Block_3.x10"
            final x10.array.LocalState_B3 t$109979 = x10.array.LocalState_B3.<$T> make__4$1x10$lang$Long$3x10$lang$Long$3x10$lang$Long$3x10$array$LocalState_B3$$S$2($T, ((x10.lang.PlaceGroup)(this.pg)), (long)(this.m), (long)(this.n), (long)(this.p), ((x10.core.fun.Fun_0_3)(this.init)));
            
            //#line 64 "x10/array/DistArray_Block_3.x10"
            return t$109979;
        }
        
        public x10.lang.PlaceGroup pg;
        public long m;
        public long n;
        public long p;
        public x10.core.fun.Fun_0_3<x10.core.Long,x10.core.Long,x10.core.Long,$T> init;
        
        public $Closure$17(final x10.rtt.Type $T, final x10.lang.PlaceGroup pg, final long m, final long n, final long p, final x10.core.fun.Fun_0_3<x10.core.Long,x10.core.Long,x10.core.Long,$T> init, __4$1x10$lang$Long$3x10$lang$Long$3x10$lang$Long$3x10$array$DistArray_Block_3$$Closure$17$$T$2 $dummy) {
            x10.array.DistArray_Block_3.$Closure$17.$initParams(this, $T);
             {
                ((x10.array.DistArray_Block_3.$Closure$17<$T>)this).pg = ((x10.lang.PlaceGroup)(pg));
                ((x10.array.DistArray_Block_3.$Closure$17<$T>)this).m = m;
                ((x10.array.DistArray_Block_3.$Closure$17<$T>)this).n = n;
                ((x10.array.DistArray_Block_3.$Closure$17<$T>)this).p = p;
                ((x10.array.DistArray_Block_3.$Closure$17<$T>)this).init = ((x10.core.fun.Fun_0_3)(init));
            }
        }
        
    }
    
    @x10.runtime.impl.java.X10Generated
    final public static class $Closure$18<$T> extends x10.core.Ref implements x10.core.fun.Fun_0_3, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<$Closure$18> $RTT = 
            x10.rtt.StaticFunType.<$Closure$18> make($Closure$18.class,
                                                     1,
                                                     new x10.rtt.Type[] {
                                                         x10.rtt.ParameterizedType.make(x10.core.fun.Fun_0_3.$RTT, x10.rtt.Types.LONG, x10.rtt.Types.LONG, x10.rtt.Types.LONG, x10.rtt.UnresolvedType.PARAM(0))
                                                     });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { if (i == 0) return $T; return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static <$T> x10.serialization.X10JavaSerializable $_deserialize_body(x10.array.DistArray_Block_3.$Closure$18<$T> $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            $_obj.$T = (x10.rtt.Type) $deserializer.readObject();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.array.DistArray_Block_3.$Closure$18 $_obj = new x10.array.DistArray_Block_3.$Closure$18((java.lang.System[]) null, (x10.rtt.Type) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            $serializer.write(this.$T);
            
        }
        
        // constructor just for allocation
        public $Closure$18(final java.lang.System[] $dummy, final x10.rtt.Type $T) {
            x10.array.DistArray_Block_3.$Closure$18.$initParams(this, $T);
            
        }
        
        // dispatcher for method abstract public (Z1,Z2,Z3)=>U.operator()(a1:Z1, a2:Z2, a3:Z3):U
        public java.lang.Object $apply(final java.lang.Object a1, final x10.rtt.Type t1, final java.lang.Object a2, final x10.rtt.Type t2, final java.lang.Object a3, final x10.rtt.Type t3) {
            return $apply$G(x10.core.Long.$unbox(a1), x10.core.Long.$unbox(a2), x10.core.Long.$unbox(a3));
            
        }
        
        private x10.rtt.Type $T;
        
        // initializer of type parameters
        public static void $initParams(final $Closure$18 $this, final x10.rtt.Type $T) {
            $this.$T = $T;
            
        }
        
    
        
        public $T $apply$G(final long id$99, final long id$100, final long id$101) {
            
            //#line 100 "x10/array/DistArray_Block_3.x10"
            final $T t$109796 = (($T)(($T) x10.rtt.Types.zeroValue($T)));
            
            //#line 100 "x10/array/DistArray_Block_3.x10"
            return t$109796;
        }
        
        public $Closure$18(final x10.rtt.Type $T) {
            x10.array.DistArray_Block_3.$Closure$18.$initParams(this, $T);
             {
                
            }
        }
        
    }
    
    @x10.runtime.impl.java.X10Generated
    final public static class $Closure$19<$T> extends x10.core.Ref implements x10.core.fun.Fun_0_3, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<$Closure$19> $RTT = 
            x10.rtt.StaticFunType.<$Closure$19> make($Closure$19.class,
                                                     1,
                                                     new x10.rtt.Type[] {
                                                         x10.rtt.ParameterizedType.make(x10.core.fun.Fun_0_3.$RTT, x10.rtt.Types.LONG, x10.rtt.Types.LONG, x10.rtt.Types.LONG, x10.rtt.UnresolvedType.PARAM(0))
                                                     });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { if (i == 0) return $T; return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static <$T> x10.serialization.X10JavaSerializable $_deserialize_body(x10.array.DistArray_Block_3.$Closure$19<$T> $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            $_obj.$T = (x10.rtt.Type) $deserializer.readObject();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.array.DistArray_Block_3.$Closure$19 $_obj = new x10.array.DistArray_Block_3.$Closure$19((java.lang.System[]) null, (x10.rtt.Type) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            $serializer.write(this.$T);
            
        }
        
        // constructor just for allocation
        public $Closure$19(final java.lang.System[] $dummy, final x10.rtt.Type $T) {
            x10.array.DistArray_Block_3.$Closure$19.$initParams(this, $T);
            
        }
        
        // dispatcher for method abstract public (Z1,Z2,Z3)=>U.operator()(a1:Z1, a2:Z2, a3:Z3):U
        public java.lang.Object $apply(final java.lang.Object a1, final x10.rtt.Type t1, final java.lang.Object a2, final x10.rtt.Type t2, final java.lang.Object a3, final x10.rtt.Type t3) {
            return $apply$G(x10.core.Long.$unbox(a1), x10.core.Long.$unbox(a2), x10.core.Long.$unbox(a3));
            
        }
        
        private x10.rtt.Type $T;
        
        // initializer of type parameters
        public static void $initParams(final $Closure$19 $this, final x10.rtt.Type $T) {
            $this.$T = $T;
            
        }
        
    
        
        public $T $apply$G(final long id$102, final long id$103, final long id$104) {
            
            //#line 114 "x10/array/DistArray_Block_3.x10"
            final $T t$109798 = (($T)(($T) x10.rtt.Types.zeroValue($T)));
            
            //#line 114 "x10/array/DistArray_Block_3.x10"
            return t$109798;
        }
        
        public $Closure$19(final x10.rtt.Type $T) {
            x10.array.DistArray_Block_3.$Closure$19.$initParams(this, $T);
             {
                
            }
        }
        
    }
    
}


