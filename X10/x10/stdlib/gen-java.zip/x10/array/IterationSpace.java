package x10.array;

/**
 * An IterationSpace represents an iteration space,
 * ie. a lexograpically ordered finite collection of 
 * equal rank Points.
 */
@x10.runtime.impl.java.X10Generated
abstract public class IterationSpace extends x10.core.Ref implements x10.lang.Iterable, x10.serialization.X10JavaSerializable
{
    public static final x10.rtt.RuntimeType<IterationSpace> $RTT = 
        x10.rtt.NamedType.<IterationSpace> make("x10.array.IterationSpace",
                                                IterationSpace.class,
                                                new x10.rtt.Type[] {
                                                    x10.rtt.ParameterizedType.make(x10.lang.Iterable.$RTT, x10.lang.Point.$RTT)
                                                });
    
    public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
    
    public x10.rtt.Type<?> $getParam(int i) { return null; }
    
    public static x10.serialization.X10JavaSerializable $_deserialize_body(x10.array.IterationSpace $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
        $_obj.rank = $deserializer.readLong();
        $_obj.rect = $deserializer.readBoolean();
        return $_obj;
    }
    
    public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
        return null;
    }
    
    public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
        $serializer.write(this.rank);
        $serializer.write(this.rect);
        
    }
    
    // constructor just for allocation
    public IterationSpace(final java.lang.System[] $dummy) {
        
    }
    
    
    // properties
    
    //#line 19 "x10/array/IterationSpace.x10"
    public long rank;
    
    //#line 19 "x10/array/IterationSpace.x10"
    public boolean rect;
    

    
    
    //#line 21 "x10/array/IterationSpace.x10"
    
    // constructor for non-virtual call
    final public x10.array.IterationSpace x10$array$IterationSpace$$init$S(final long rank, final boolean rect) {
         {
            
            //#line 22 "x10/array/IterationSpace.x10"
            this.rank = rank;
            this.rect = rect;
            
        }
        return this;
    }
    
    
    
    //#line 25 "x10/array/IterationSpace.x10"
    public static x10.array.IterationSpace $implicit_convert(final x10.lang.IntRange r) {
        
        //#line 25 "x10/array/IterationSpace.x10"
        final x10.array.DenseIterationSpace_1 alloc$103648 = ((x10.array.DenseIterationSpace_1)(new x10.array.DenseIterationSpace_1((java.lang.System[]) null)));
        
        //#line 25 "x10/array/IterationSpace.x10"
        final int t$110418 = r.min;
        
        //#line 25 "x10/array/IterationSpace.x10"
        final long t$110419 = ((long)(((int)(t$110418))));
        
        //#line 25 "x10/array/IterationSpace.x10"
        final int t$110420 = r.max;
        
        //#line 25 "x10/array/IterationSpace.x10"
        final long t$110421 = ((long)(((int)(t$110420))));
        
        //#line 25 "x10/array/IterationSpace.x10"
        alloc$103648.x10$array$DenseIterationSpace_1$$init$S(t$110419, t$110421);
        
        //#line 25 "x10/array/IterationSpace.x10"
        return alloc$103648;
    }
    
    
    //#line 27 "x10/array/IterationSpace.x10"
    public static x10.array.IterationSpace $implicit_convert(final x10.lang.LongRange r) {
        
        //#line 27 "x10/array/IterationSpace.x10"
        final x10.array.DenseIterationSpace_1 alloc$103649 = ((x10.array.DenseIterationSpace_1)(new x10.array.DenseIterationSpace_1((java.lang.System[]) null)));
        
        //#line 27 "x10/array/IterationSpace.x10"
        final long t$110422 = r.min;
        
        //#line 27 "x10/array/IterationSpace.x10"
        final long t$110423 = r.max;
        
        //#line 27 "x10/array/IterationSpace.x10"
        alloc$103649.x10$array$DenseIterationSpace_1$$init$S(((long)(t$110422)), ((long)(t$110423)));
        
        //#line 27 "x10/array/IterationSpace.x10"
        return alloc$103649;
    }
    
    
    //#line 29 "x10/array/IterationSpace.x10"
    abstract public x10.lang.Iterator iterator();
    
    
    //#line 31 "x10/array/IterationSpace.x10"
    abstract public long min$O(final long i);
    
    
    //#line 33 "x10/array/IterationSpace.x10"
    abstract public long max$O(final long i);
    
    
    //#line 35 "x10/array/IterationSpace.x10"
    abstract public boolean isEmpty$O();
    
    
    //#line 37 "x10/array/IterationSpace.x10"
    abstract public long size$O();
    
    
    //#line 39 "x10/array/IterationSpace.x10"
    public java.lang.String toString() {
        
        //#line 40 "x10/array/IterationSpace.x10"
        final x10.util.StringBuilder sb = ((x10.util.StringBuilder)(new x10.util.StringBuilder((java.lang.System[]) null)));
        
        //#line 40 "x10/array/IterationSpace.x10"
        sb.x10$util$StringBuilder$$init$S();
        
        //#line 41 "x10/array/IterationSpace.x10"
        final x10.lang.Iterator it = this.iterator();
        
        //#line 43 "x10/array/IterationSpace.x10"
        sb.add(((java.lang.String)("{")));
        
        //#line 44 "x10/array/IterationSpace.x10"
        int c$110428 = 0;
        
        //#line 44 "x10/array/IterationSpace.x10"
        for (;
             true;
             ) {
            
            //#line 44 "x10/array/IterationSpace.x10"
            boolean t$110430 = ((c$110428) < (((int)(10))));
            
            //#line 44 "x10/array/IterationSpace.x10"
            if (t$110430) {
                
                //#line 44 "x10/array/IterationSpace.x10"
                t$110430 = ((x10.lang.Iterator<x10.lang.Point>)it).hasNext$O();
            }
            
            //#line 44 "x10/array/IterationSpace.x10"
            if (!(t$110430)) {
                
                //#line 44 "x10/array/IterationSpace.x10"
                break;
            }
            
            //#line 45 "x10/array/IterationSpace.x10"
            final x10.lang.Point t$110424 = ((x10.lang.Point)(((x10.lang.Iterator<x10.lang.Point>)it).next$G()));
            
            //#line 45 "x10/array/IterationSpace.x10"
            sb.add(((java.lang.Object)(t$110424)));
            
            //#line 46 "x10/array/IterationSpace.x10"
            final boolean t$110425 = ((x10.lang.Iterator<x10.lang.Point>)it).hasNext$O();
            
            //#line 46 "x10/array/IterationSpace.x10"
            if (t$110425) {
                
                //#line 46 "x10/array/IterationSpace.x10"
                sb.add(((java.lang.String)(", ")));
            }
            
            //#line 44 "x10/array/IterationSpace.x10"
            final int t$110427 = ((c$110428) + (((int)(1))));
            
            //#line 44 "x10/array/IterationSpace.x10"
            c$110428 = t$110427;
        }
        
        //#line 48 "x10/array/IterationSpace.x10"
        final boolean t$110416 = ((x10.lang.Iterator<x10.lang.Point>)it).hasNext$O();
        
        //#line 48 "x10/array/IterationSpace.x10"
        if (t$110416) {
            
            //#line 48 "x10/array/IterationSpace.x10"
            sb.add(((java.lang.String)("...")));
        }
        
        //#line 49 "x10/array/IterationSpace.x10"
        sb.add(((java.lang.String)("}")));
        
        //#line 51 "x10/array/IterationSpace.x10"
        final java.lang.String t$110417 = sb.toString();
        
        //#line 51 "x10/array/IterationSpace.x10"
        return t$110417;
    }
    
    
    //#line 19 "x10/array/IterationSpace.x10"
    final public x10.array.IterationSpace x10$array$IterationSpace$$this$x10$array$IterationSpace() {
        
        //#line 19 "x10/array/IterationSpace.x10"
        return x10.array.IterationSpace.this;
    }
    
    
    //#line 19 "x10/array/IterationSpace.x10"
    final public void __fieldInitializers_x10_array_IterationSpace() {
        
    }
}


