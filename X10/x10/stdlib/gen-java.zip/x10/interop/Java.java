package x10.interop;


@x10.runtime.impl.java.X10Generated
public class Java extends x10.core.Ref implements x10.serialization.X10JavaSerializable
{
    public static final x10.rtt.RuntimeType<Java> $RTT = 
        x10.rtt.NamedType.<Java> make("x10.interop.Java",
                                      Java.class);
    
    public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
    
    public x10.rtt.Type<?> $getParam(int i) { return null; }
    
    private Object writeReplace() throws java.io.ObjectStreamException {
        return new x10.serialization.SerializationProxy(this);
    }
    
    public static x10.serialization.X10JavaSerializable $_deserialize_body(x10.interop.Java $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
        return $_obj;
    }
    
    public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
        x10.interop.Java $_obj = new x10.interop.Java((java.lang.System[]) null);
        $deserializer.record_reference($_obj);
        return $_deserialize_body($_obj, $deserializer);
    }
    
    public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
        
    }
    
    // constructor just for allocation
    public Java(final java.lang.System[] $dummy) {
        
    }
    
    

    
    
    //#line 20 "x10/interop/Java.x10"
    public Java() {
         {
            
            //#line 20 "x10/interop/Java.x10"
            
            
            //#line 18 "x10/interop/Java.x10"
            this.__fieldInitializers_x10_interop_Java();
        }
    }
    
    
    
    //#line 24 "x10/interop/Java.x10"
    ;
    
    
    
    //#line 36 "x10/interop/Java.x10"
    public static java.lang.Object newObject() {
        try {
            return new java.lang.Object();
        }
        catch (java.lang.Throwable exc$206305) {
            throw x10.runtime.impl.java.ThrowableUtils.ensureX10Exception(exc$206305);
        }
        
    }
    
    
    
    //#line 38 "x10/interop/Java.x10"
    public static <$T>$T[] newArray(final x10.rtt.Type $T, final int d0) {
        try {
            return ($T[])$T.makeArray(d0);
        }
        catch (java.lang.Throwable exc$206306) {
            throw x10.runtime.impl.java.ThrowableUtils.ensureX10Exception(exc$206306);
        }
        
    }
    
    
    
    //#line 40 "x10/interop/Java.x10"
    public static <$T>$T[][] newArray(final x10.rtt.Type $T, final int d0, final int d1) {
        try {
            return ($T[][])$T.makeArray(d0,d1);
        }
        catch (java.lang.Throwable exc$206307) {
            throw x10.runtime.impl.java.ThrowableUtils.ensureX10Exception(exc$206307);
        }
        
    }
    
    
    
    //#line 42 "x10/interop/Java.x10"
    public static <$T>$T[][][] newArray(final x10.rtt.Type $T, final int d0, final int d1, final int d2) {
        try {
            return ($T[][][])$T.makeArray(d0,d1,d2);
        }
        catch (java.lang.Throwable exc$206308) {
            throw x10.runtime.impl.java.ThrowableUtils.ensureX10Exception(exc$206308);
        }
        
    }
    
    
    
    //#line 44 "x10/interop/Java.x10"
    public static <$T>$T[][][][] newArray(final x10.rtt.Type $T, final int d0, final int d1, final int d2, final int d3) {
        try {
            return ($T[][][][])$T.makeArray(d0,d1,d2,d3);
        }
        catch (java.lang.Throwable exc$206309) {
            throw x10.runtime.impl.java.ThrowableUtils.ensureX10Exception(exc$206309);
        }
        
    }
    
    
    
    //#line 48 "x10/interop/Java.x10"
    public static <$T>java.lang.Class javaClass(final x10.rtt.Type $T) {
        try {
            return $T.getJavaClass();
        }
        catch (java.lang.Throwable exc$206310) {
            throw x10.runtime.impl.java.ThrowableUtils.ensureX10Exception(exc$206310);
        }
        
    }
    
    
    
    //#line 50 "x10/interop/Java.x10"
    public static <$T>void setStaticField(final x10.rtt.Type $T, final java.lang.String name, final java.lang.Object value) {
        try {
            do { try { $T.getJavaClass().getDeclaredField(name).set(null,value); } catch (java.lang.Exception e) { java.lang.RuntimeException re = (e instanceof java.lang.RuntimeException) ? ((java.lang.RuntimeException) e) : new x10.lang.WrappedThrowable(e); throw re; } } while (false);
        }
        catch (java.lang.Throwable exc$206311) {
            throw x10.runtime.impl.java.ThrowableUtils.ensureX10Exception(exc$206311);
        }
        
    }
    
    
    
    //#line 52 "x10/interop/Java.x10"
    public static <$T>void setStaticField(final x10.rtt.Type $T, final java.lang.String name, final byte value) {
        try {
            do { try { $T.getJavaClass().getDeclaredField(name).setByte(null,value); } catch (java.lang.Exception e) { java.lang.RuntimeException re = (e instanceof java.lang.RuntimeException) ? ((java.lang.RuntimeException) e) : new x10.lang.WrappedThrowable(e); throw re; } } while (false);
        }
        catch (java.lang.Throwable exc$206312) {
            throw x10.runtime.impl.java.ThrowableUtils.ensureX10Exception(exc$206312);
        }
        
    }
    
    
    
    //#line 54 "x10/interop/Java.x10"
    public static <$T>void setStaticField(final x10.rtt.Type $T, final java.lang.String name, final short value) {
        try {
            do { try { $T.getJavaClass().getDeclaredField(name).setShort(null,value); } catch (java.lang.Exception e) { java.lang.RuntimeException re = (e instanceof java.lang.RuntimeException) ? ((java.lang.RuntimeException) e) : new x10.lang.WrappedThrowable(e); throw re; } } while (false);
        }
        catch (java.lang.Throwable exc$206313) {
            throw x10.runtime.impl.java.ThrowableUtils.ensureX10Exception(exc$206313);
        }
        
    }
    
    
    
    //#line 56 "x10/interop/Java.x10"
    public static <$T>void setStaticField(final x10.rtt.Type $T, final java.lang.String name, final int value) {
        try {
            do { try { $T.getJavaClass().getDeclaredField(name).setInt(null,value); } catch (java.lang.Exception e) { java.lang.RuntimeException re = (e instanceof java.lang.RuntimeException) ? ((java.lang.RuntimeException) e) : new x10.lang.WrappedThrowable(e); throw re; } } while (false);
        }
        catch (java.lang.Throwable exc$206314) {
            throw x10.runtime.impl.java.ThrowableUtils.ensureX10Exception(exc$206314);
        }
        
    }
    
    
    
    //#line 58 "x10/interop/Java.x10"
    public static <$T>void setStaticField(final x10.rtt.Type $T, final java.lang.String name, final long value) {
        try {
            do { try { $T.getJavaClass().getDeclaredField(name).setLong(null,value); } catch (java.lang.Exception e) { java.lang.RuntimeException re = (e instanceof java.lang.RuntimeException) ? ((java.lang.RuntimeException) e) : new x10.lang.WrappedThrowable(e); throw re; } } while (false);
        }
        catch (java.lang.Throwable exc$206315) {
            throw x10.runtime.impl.java.ThrowableUtils.ensureX10Exception(exc$206315);
        }
        
    }
    
    
    
    //#line 60 "x10/interop/Java.x10"
    public static <$T>void setStaticField(final x10.rtt.Type $T, final java.lang.String name, final float value) {
        try {
            do { try { $T.getJavaClass().getDeclaredField(name).setFloat(null,value); } catch (java.lang.Exception e) { java.lang.RuntimeException re = (e instanceof java.lang.RuntimeException) ? ((java.lang.RuntimeException) e) : new x10.lang.WrappedThrowable(e); throw re; } } while (false);
        }
        catch (java.lang.Throwable exc$206316) {
            throw x10.runtime.impl.java.ThrowableUtils.ensureX10Exception(exc$206316);
        }
        
    }
    
    
    
    //#line 62 "x10/interop/Java.x10"
    public static <$T>void setStaticField(final x10.rtt.Type $T, final java.lang.String name, final double value) {
        try {
            do { try { $T.getJavaClass().getDeclaredField(name).setDouble(null,value); } catch (java.lang.Exception e) { java.lang.RuntimeException re = (e instanceof java.lang.RuntimeException) ? ((java.lang.RuntimeException) e) : new x10.lang.WrappedThrowable(e); throw re; } } while (false);
        }
        catch (java.lang.Throwable exc$206317) {
            throw x10.runtime.impl.java.ThrowableUtils.ensureX10Exception(exc$206317);
        }
        
    }
    
    
    
    //#line 64 "x10/interop/Java.x10"
    public static <$T>void setStaticField(final x10.rtt.Type $T, final java.lang.String name, final char value) {
        try {
            do { try { $T.getJavaClass().getDeclaredField(name).setChar(null,value); } catch (java.lang.Exception e) { java.lang.RuntimeException re = (e instanceof java.lang.RuntimeException) ? ((java.lang.RuntimeException) e) : new x10.lang.WrappedThrowable(e); throw re; } } while (false);
        }
        catch (java.lang.Throwable exc$206318) {
            throw x10.runtime.impl.java.ThrowableUtils.ensureX10Exception(exc$206318);
        }
        
    }
    
    
    
    //#line 66 "x10/interop/Java.x10"
    public static <$T>void setStaticField(final x10.rtt.Type $T, final java.lang.String name, final boolean value) {
        try {
            do { try { $T.getJavaClass().getDeclaredField(name).setBoolean(null,value); } catch (java.lang.Exception e) { java.lang.RuntimeException re = (e instanceof java.lang.RuntimeException) ? ((java.lang.RuntimeException) e) : new x10.lang.WrappedThrowable(e); throw re; } } while (false);
        }
        catch (java.lang.Throwable exc$206319) {
            throw x10.runtime.impl.java.ThrowableUtils.ensureX10Exception(exc$206319);
        }
        
    }
    
    
    
    //#line 68 "x10/interop/Java.x10"
    public static java.lang.Class getClass(final java.lang.Object o) {
        try {
            return o.getClass();
        }
        catch (java.lang.Throwable exc$206320) {
            throw x10.runtime.impl.java.ThrowableUtils.ensureX10Exception(exc$206320);
        }
        
    }
    
    
    
    //#line 72 "x10/interop/Java.x10"
    public static void throwException(final java.lang.Throwable e) {
        try {
            do { throw e; } while (false);
        }
        catch (java.lang.Throwable exc$206321) {
            throw x10.runtime.impl.java.ThrowableUtils.ensureX10Exception(exc$206321);
        }
        
    }
    
    
    
    //#line 77 "x10/interop/Java.x10"
    /** @deprecated use {@link #toJava(x10.lang.Boolean)} instead */
    public static java.lang.Boolean convert(final boolean b) {
        try {
            return java.lang.Boolean.valueOf(b);
        }
        catch (java.lang.Throwable exc$206322) {
            throw x10.runtime.impl.java.ThrowableUtils.ensureX10Exception(exc$206322);
        }
        
    }
    
    
    
    //#line 80 "x10/interop/Java.x10"
    /** @deprecated use {@link #toX10(java.lang.Boolean)} instead */
    public static boolean convert$O(final java.lang.Boolean b) {
        try {
            return b.booleanValue();
        }
        catch (java.lang.Throwable exc$206323) {
            throw x10.runtime.impl.java.ThrowableUtils.ensureX10Exception(exc$206323);
        }
        
    }
    
    
    
    //#line 83 "x10/interop/Java.x10"
    /** @deprecated use {@link #toJava(x10.lang.Byte)} instead */
    public static java.lang.Byte convert(final byte y) {
        try {
            return java.lang.Byte.valueOf(y);
        }
        catch (java.lang.Throwable exc$206324) {
            throw x10.runtime.impl.java.ThrowableUtils.ensureX10Exception(exc$206324);
        }
        
    }
    
    
    
    //#line 86 "x10/interop/Java.x10"
    /** @deprecated use {@link #toX10(java.lang.Byte)} instead */
    public static byte convert$O(final java.lang.Byte y) {
        try {
            return y.byteValue();
        }
        catch (java.lang.Throwable exc$206325) {
            throw x10.runtime.impl.java.ThrowableUtils.ensureX10Exception(exc$206325);
        }
        
    }
    
    
    
    //#line 89 "x10/interop/Java.x10"
    /** @deprecated use {@link #toJava(x10.lang.Short)} instead */
    public static java.lang.Short convert(final short s) {
        try {
            return java.lang.Short.valueOf(s);
        }
        catch (java.lang.Throwable exc$206326) {
            throw x10.runtime.impl.java.ThrowableUtils.ensureX10Exception(exc$206326);
        }
        
    }
    
    
    
    //#line 92 "x10/interop/Java.x10"
    /** @deprecated use {@link #toX10(java.lang.Short)} instead */
    public static short convert$O(final java.lang.Short s) {
        try {
            return s.shortValue();
        }
        catch (java.lang.Throwable exc$206327) {
            throw x10.runtime.impl.java.ThrowableUtils.ensureX10Exception(exc$206327);
        }
        
    }
    
    
    
    //#line 95 "x10/interop/Java.x10"
    /** @deprecated use {@link #toJava(x10.lang.Int)} instead */
    public static java.lang.Integer convert(final int i) {
        try {
            return java.lang.Integer.valueOf(i);
        }
        catch (java.lang.Throwable exc$206328) {
            throw x10.runtime.impl.java.ThrowableUtils.ensureX10Exception(exc$206328);
        }
        
    }
    
    
    
    //#line 98 "x10/interop/Java.x10"
    /** @deprecated use {@link #toX10(java.lang.Integer)} instead */
    public static int convert$O(final java.lang.Integer i) {
        try {
            return i.intValue();
        }
        catch (java.lang.Throwable exc$206329) {
            throw x10.runtime.impl.java.ThrowableUtils.ensureX10Exception(exc$206329);
        }
        
    }
    
    
    
    //#line 101 "x10/interop/Java.x10"
    /** @deprecated use {@link #toJava(x10.lang.Long)} instead */
    public static java.lang.Long convert(final long l) {
        try {
            return java.lang.Long.valueOf(l);
        }
        catch (java.lang.Throwable exc$206330) {
            throw x10.runtime.impl.java.ThrowableUtils.ensureX10Exception(exc$206330);
        }
        
    }
    
    
    
    //#line 104 "x10/interop/Java.x10"
    /** @deprecated use {@link #toX10(java.lang.Long)} instead */
    public static long convert$O(final java.lang.Long l) {
        try {
            return l.longValue();
        }
        catch (java.lang.Throwable exc$206331) {
            throw x10.runtime.impl.java.ThrowableUtils.ensureX10Exception(exc$206331);
        }
        
    }
    
    
    
    //#line 107 "x10/interop/Java.x10"
    /** @deprecated use {@link #toJava(x10.lang.Float)} instead */
    public static java.lang.Float convert(final float f) {
        try {
            return java.lang.Float.valueOf(f);
        }
        catch (java.lang.Throwable exc$206332) {
            throw x10.runtime.impl.java.ThrowableUtils.ensureX10Exception(exc$206332);
        }
        
    }
    
    
    
    //#line 110 "x10/interop/Java.x10"
    /** @deprecated use {@link #toX10(java.lang.Float)} instead */
    public static float convert$O(final java.lang.Float f) {
        try {
            return f.floatValue();
        }
        catch (java.lang.Throwable exc$206333) {
            throw x10.runtime.impl.java.ThrowableUtils.ensureX10Exception(exc$206333);
        }
        
    }
    
    
    
    //#line 113 "x10/interop/Java.x10"
    /** @deprecated use {@link #toJava(x10.lang.Double)} instead */
    public static java.lang.Double convert(final double d) {
        try {
            return java.lang.Double.valueOf(d);
        }
        catch (java.lang.Throwable exc$206334) {
            throw x10.runtime.impl.java.ThrowableUtils.ensureX10Exception(exc$206334);
        }
        
    }
    
    
    
    //#line 116 "x10/interop/Java.x10"
    /** @deprecated use {@link #toX10(java.lang.Double)} instead */
    public static double convert$O(final java.lang.Double d) {
        try {
            return d.doubleValue();
        }
        catch (java.lang.Throwable exc$206335) {
            throw x10.runtime.impl.java.ThrowableUtils.ensureX10Exception(exc$206335);
        }
        
    }
    
    
    
    //#line 119 "x10/interop/Java.x10"
    /** @deprecated use {@link #toJava(x10.lang.Char)} instead */
    public static java.lang.Character convert(final char c) {
        try {
            return java.lang.Character.valueOf(c);
        }
        catch (java.lang.Throwable exc$206336) {
            throw x10.runtime.impl.java.ThrowableUtils.ensureX10Exception(exc$206336);
        }
        
    }
    
    
    
    //#line 122 "x10/interop/Java.x10"
    /** @deprecated use {@link #toX10(java.lang.Character)} instead */
    public static char convert$O(final java.lang.Character c) {
        try {
            return c.charValue();
        }
        catch (java.lang.Throwable exc$206337) {
            throw x10.runtime.impl.java.ThrowableUtils.ensureX10Exception(exc$206337);
        }
        
    }
    
    
    
    //#line 125 "x10/interop/Java.x10"
    public static java.lang.Boolean toJava(final boolean b) {
        try {
            return java.lang.Boolean.valueOf(b);
        }
        catch (java.lang.Throwable exc$206338) {
            throw x10.runtime.impl.java.ThrowableUtils.ensureX10Exception(exc$206338);
        }
        
    }
    
    
    
    //#line 127 "x10/interop/Java.x10"
    public static boolean toX10$O(final java.lang.Boolean b) {
        try {
            return b.booleanValue();
        }
        catch (java.lang.Throwable exc$206339) {
            throw x10.runtime.impl.java.ThrowableUtils.ensureX10Exception(exc$206339);
        }
        
    }
    
    
    
    //#line 129 "x10/interop/Java.x10"
    public static java.lang.Byte toJava(final byte y) {
        try {
            return java.lang.Byte.valueOf(y);
        }
        catch (java.lang.Throwable exc$206340) {
            throw x10.runtime.impl.java.ThrowableUtils.ensureX10Exception(exc$206340);
        }
        
    }
    
    
    
    //#line 131 "x10/interop/Java.x10"
    public static byte toX10$O(final java.lang.Byte y) {
        try {
            return y.byteValue();
        }
        catch (java.lang.Throwable exc$206341) {
            throw x10.runtime.impl.java.ThrowableUtils.ensureX10Exception(exc$206341);
        }
        
    }
    
    
    
    //#line 133 "x10/interop/Java.x10"
    public static java.lang.Short toJava(final short s) {
        try {
            return java.lang.Short.valueOf(s);
        }
        catch (java.lang.Throwable exc$206342) {
            throw x10.runtime.impl.java.ThrowableUtils.ensureX10Exception(exc$206342);
        }
        
    }
    
    
    
    //#line 135 "x10/interop/Java.x10"
    public static short toX10$O(final java.lang.Short s) {
        try {
            return s.shortValue();
        }
        catch (java.lang.Throwable exc$206343) {
            throw x10.runtime.impl.java.ThrowableUtils.ensureX10Exception(exc$206343);
        }
        
    }
    
    
    
    //#line 137 "x10/interop/Java.x10"
    public static java.lang.Integer toJava(final int i) {
        try {
            return java.lang.Integer.valueOf(i);
        }
        catch (java.lang.Throwable exc$206344) {
            throw x10.runtime.impl.java.ThrowableUtils.ensureX10Exception(exc$206344);
        }
        
    }
    
    
    
    //#line 139 "x10/interop/Java.x10"
    public static int toX10$O(final java.lang.Integer i) {
        try {
            return i.intValue();
        }
        catch (java.lang.Throwable exc$206345) {
            throw x10.runtime.impl.java.ThrowableUtils.ensureX10Exception(exc$206345);
        }
        
    }
    
    
    
    //#line 141 "x10/interop/Java.x10"
    public static java.lang.Long toJava(final long l) {
        try {
            return java.lang.Long.valueOf(l);
        }
        catch (java.lang.Throwable exc$206346) {
            throw x10.runtime.impl.java.ThrowableUtils.ensureX10Exception(exc$206346);
        }
        
    }
    
    
    
    //#line 143 "x10/interop/Java.x10"
    public static long toX10$O(final java.lang.Long l) {
        try {
            return l.longValue();
        }
        catch (java.lang.Throwable exc$206347) {
            throw x10.runtime.impl.java.ThrowableUtils.ensureX10Exception(exc$206347);
        }
        
    }
    
    
    
    //#line 145 "x10/interop/Java.x10"
    public static java.lang.Float toJava(final float f) {
        try {
            return java.lang.Float.valueOf(f);
        }
        catch (java.lang.Throwable exc$206348) {
            throw x10.runtime.impl.java.ThrowableUtils.ensureX10Exception(exc$206348);
        }
        
    }
    
    
    
    //#line 147 "x10/interop/Java.x10"
    public static float toX10$O(final java.lang.Float f) {
        try {
            return f.floatValue();
        }
        catch (java.lang.Throwable exc$206349) {
            throw x10.runtime.impl.java.ThrowableUtils.ensureX10Exception(exc$206349);
        }
        
    }
    
    
    
    //#line 149 "x10/interop/Java.x10"
    public static java.lang.Double toJava(final double d) {
        try {
            return java.lang.Double.valueOf(d);
        }
        catch (java.lang.Throwable exc$206350) {
            throw x10.runtime.impl.java.ThrowableUtils.ensureX10Exception(exc$206350);
        }
        
    }
    
    
    
    //#line 151 "x10/interop/Java.x10"
    public static double toX10$O(final java.lang.Double d) {
        try {
            return d.doubleValue();
        }
        catch (java.lang.Throwable exc$206351) {
            throw x10.runtime.impl.java.ThrowableUtils.ensureX10Exception(exc$206351);
        }
        
    }
    
    
    
    //#line 153 "x10/interop/Java.x10"
    public static java.lang.Character toJava(final char c) {
        try {
            return java.lang.Character.valueOf(c);
        }
        catch (java.lang.Throwable exc$206352) {
            throw x10.runtime.impl.java.ThrowableUtils.ensureX10Exception(exc$206352);
        }
        
    }
    
    
    
    //#line 155 "x10/interop/Java.x10"
    public static char toX10$O(final java.lang.Character c) {
        try {
            return c.charValue();
        }
        catch (java.lang.Throwable exc$206353) {
            throw x10.runtime.impl.java.ThrowableUtils.ensureX10Exception(exc$206353);
        }
        
    }
    
    
    
    //#line 160 "x10/interop/Java.x10"
    /** @deprecated use {@link #toJava(x10.lang.Rail[T])} instead */
    public static <$T>$T[] convert__0$1x10$interop$Java$$T$2(final x10.rtt.Type $T, final x10.core.Rail<$T> a) {
        try {
            return ($T[])a.getBackingArray();
        }
        catch (java.lang.Throwable exc$206354) {
            throw x10.runtime.impl.java.ThrowableUtils.ensureX10Exception(exc$206354);
        }
        
    }
    
    
    
    //#line 163 "x10/interop/Java.x10"
    /** @deprecated use {@link #toX10(array[T])} instead */
    public static <$T>x10.core.Rail convert__0$1x10$interop$Java$$T$2(final x10.rtt.Type $T, final $T[] a) {
        try {
            return new x10.core.Rail($T, a.length, a);
        }
        catch (java.lang.Throwable exc$206355) {
            throw x10.runtime.impl.java.ThrowableUtils.ensureX10Exception(exc$206355);
        }
        
    }
    
    
    
    //#line 166 "x10/interop/Java.x10"
    public static <$T>$T[] toJava__0$1x10$interop$Java$$T$2(final x10.rtt.Type $T, final x10.core.Rail<$T> a) {
        try {
            return ($T[])a.getBackingArray();
        }
        catch (java.lang.Throwable exc$206356) {
            throw x10.runtime.impl.java.ThrowableUtils.ensureX10Exception(exc$206356);
        }
        
    }
    
    
    
    //#line 168 "x10/interop/Java.x10"
    public static <$T>x10.core.Rail toX10__0$1x10$interop$Java$$T$2(final x10.rtt.Type $T, final $T[] a) {
        try {
            return new x10.core.Rail($T, a.length, a);
        }
        catch (java.lang.Throwable exc$206357) {
            throw x10.runtime.impl.java.ThrowableUtils.ensureX10Exception(exc$206357);
        }
        
    }
    
    
    
    //#line 172 "x10/interop/Java.x10"
    public static byte[] serialize(final java.lang.Object a) {
        
        //#line 173 "x10/interop/Java.x10"
        final x10.io.Serializer s = ((x10.io.Serializer)(new x10.io.Serializer()));
        
        //#line 174 "x10/interop/Java.x10"
        s.writeAny(((java.lang.Object)(a)));
        
        //#line 175 "x10/interop/Java.x10"
        final x10.core.Rail t$129595 = s.toRail();
        
        //#line 175 "x10/interop/Java.x10"
        final byte[] t$129596 = (byte[])t$129595.getBackingArray();
        
        //#line 175 "x10/interop/Java.x10"
        return t$129596;
    }
    
    
    //#line 177 "x10/interop/Java.x10"
    public static java.lang.Object deserialize__0$1x10$lang$Byte$2(final byte[] a) {
        
        //#line 177 "x10/interop/Java.x10"
        final x10.core.Rail t$129597 = new x10.core.Rail(x10.rtt.Types.BYTE, a.length, a);
        
        //#line 177 "x10/interop/Java.x10"
        final x10.io.Deserializer t$129598 = ((x10.io.Deserializer)(new x10.io.Deserializer(t$129597, (x10.io.Deserializer.__0$1x10$lang$Byte$2) null)));
        
        //#line 177 "x10/interop/Java.x10"
        final java.lang.Object t$129599 = t$129598.readAny();
        
        //#line 177 "x10/interop/Java.x10"
        return t$129599;
    }
    
    
    //#line 18 "x10/interop/Java.x10"
    final public x10.interop.Java x10$interop$Java$$this$x10$interop$Java() {
        
        //#line 18 "x10/interop/Java.x10"
        return x10.interop.Java.this;
    }
    
    
    //#line 18 "x10/interop/Java.x10"
    final public void __fieldInitializers_x10_interop_Java() {
        
    }
}

