package x10.interop;


@x10.runtime.impl.java.X10Generated
public class Java8 extends x10.core.Ref implements x10.serialization.X10JavaSerializable
{
    public static final x10.rtt.RuntimeType<Java8> $RTT = 
        x10.rtt.NamedType.<Java8> make("x10.interop.Java8",
                                       Java8.class);
    
    public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
    
    public x10.rtt.Type<?> $getParam(int i) { return null; }
    
    private Object writeReplace() throws java.io.ObjectStreamException {
        return new x10.serialization.SerializationProxy(this);
    }
    
    public static x10.serialization.X10JavaSerializable $_deserialize_body(x10.interop.Java8 $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
        return $_obj;
    }
    
    public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
        x10.interop.Java8 $_obj = new x10.interop.Java8((java.lang.System[]) null);
        $deserializer.record_reference($_obj);
        return $_deserialize_body($_obj, $deserializer);
    }
    
    public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
        
    }
    
    // constructor just for allocation
    public Java8(final java.lang.System[] $dummy) {
        
    }
    
    

    
    
    //#line 19 "x10/interop/Java8.x10"
    public Java8() {
         {
            
            //#line 19 "x10/interop/Java8.x10"
            
            
            //#line 17 "x10/interop/Java8.x10"
            this.__fieldInitializers_x10_interop_Java8();
        }
    }
    
    
    
    //#line 26 "x10/interop/Java8.x10"
    public static x10.core.fun.Fun_0_2 toX10(final java.util.function.IntBinaryOperator op) {
        
        //#line 27 "x10/interop/Java8.x10"
        final x10.core.fun.Fun_0_2 t$129645 = ((x10.core.fun.Fun_0_2)(new x10.interop.Java8.$Closure$100(op)));
        
        //#line 27 "x10/interop/Java8.x10"
        return t$129645;
    }
    
    
    //#line 29 "x10/interop/Java8.x10"
    public static x10.core.fun.Fun_0_2 toX10(final java.util.function.LongBinaryOperator op) {
        
        //#line 30 "x10/interop/Java8.x10"
        final x10.core.fun.Fun_0_2 t$129647 = ((x10.core.fun.Fun_0_2)(new x10.interop.Java8.$Closure$101(op)));
        
        //#line 30 "x10/interop/Java8.x10"
        return t$129647;
    }
    
    
    //#line 32 "x10/interop/Java8.x10"
    public static x10.core.fun.Fun_0_2 toX10(final java.util.function.DoubleBinaryOperator op) {
        
        //#line 33 "x10/interop/Java8.x10"
        final x10.core.fun.Fun_0_2 t$129649 = ((x10.core.fun.Fun_0_2)(new x10.interop.Java8.$Closure$102(op)));
        
        //#line 33 "x10/interop/Java8.x10"
        return t$129649;
    }
    
    
    //#line 35 "x10/interop/Java8.x10"
    public static <$T>x10.core.fun.Fun_0_2 toX10(final x10.rtt.Type $T, final java.util.function.BinaryOperator op) {
        
        //#line 36 "x10/interop/Java8.x10"
        final x10.core.fun.Fun_0_2 t$129652 = ((x10.core.fun.Fun_0_2)(new x10.interop.Java8.$Closure$103<$T>($T, op)));
        
        //#line 36 "x10/interop/Java8.x10"
        return t$129652;
    }
    
    
    //#line 39 "x10/interop/Java8.x10"
    public static java.util.function.IntBinaryOperator toJava__0$1x10$lang$Int$3x10$lang$Int$3x10$lang$Int$2(final x10.core.fun.Fun_0_2<x10.core.Int,x10.core.Int,x10.core.Int> xop) {
        
        //#line 40 "x10/interop/Java8.x10"
        final x10.interop.Java8.Anonymous$1414 alloc$129600 = ((x10.interop.Java8.Anonymous$1414)(new x10.interop.Java8.Anonymous$1414((java.lang.System[]) null)));
        
        //#line 40 "x10/interop/Java8.x10"
        alloc$129600.x10$interop$Java8$Anonymous$1414$$init$S(xop, (x10.interop.Java8.Anonymous$1414.__0$1x10$lang$Int$3x10$lang$Int$3x10$lang$Int$2) null);
        
        //#line 40 "x10/interop/Java8.x10"
        return alloc$129600;
    }
    
    
    //#line 44 "x10/interop/Java8.x10"
    public static java.util.function.LongBinaryOperator toJava__0$1x10$lang$Long$3x10$lang$Long$3x10$lang$Long$2(final x10.core.fun.Fun_0_2<x10.core.Long,x10.core.Long,x10.core.Long> xop) {
        
        //#line 45 "x10/interop/Java8.x10"
        final x10.interop.Java8.Anonymous$1669 alloc$129601 = ((x10.interop.Java8.Anonymous$1669)(new x10.interop.Java8.Anonymous$1669((java.lang.System[]) null)));
        
        //#line 45 "x10/interop/Java8.x10"
        alloc$129601.x10$interop$Java8$Anonymous$1669$$init$S(xop, (x10.interop.Java8.Anonymous$1669.__0$1x10$lang$Long$3x10$lang$Long$3x10$lang$Long$2) null);
        
        //#line 45 "x10/interop/Java8.x10"
        return alloc$129601;
    }
    
    
    //#line 49 "x10/interop/Java8.x10"
    public static java.util.function.DoubleBinaryOperator toJava__0$1x10$lang$Double$3x10$lang$Double$3x10$lang$Double$2(final x10.core.fun.Fun_0_2<x10.core.Double,x10.core.Double,x10.core.Double> xop) {
        
        //#line 50 "x10/interop/Java8.x10"
        final x10.interop.Java8.Anonymous$1937 alloc$129602 = ((x10.interop.Java8.Anonymous$1937)(new x10.interop.Java8.Anonymous$1937((java.lang.System[]) null)));
        
        //#line 50 "x10/interop/Java8.x10"
        alloc$129602.x10$interop$Java8$Anonymous$1937$$init$S(xop, (x10.interop.Java8.Anonymous$1937.__0$1x10$lang$Double$3x10$lang$Double$3x10$lang$Double$2) null);
        
        //#line 50 "x10/interop/Java8.x10"
        return alloc$129602;
    }
    
    
    //#line 54 "x10/interop/Java8.x10"
    public static <$T>java.util.function.BinaryOperator toJava__0$1x10$interop$Java8$$T$3x10$interop$Java8$$T$3x10$interop$Java8$$T$2(final x10.rtt.Type $T, final x10.core.fun.Fun_0_2<$T,$T,$T> xop) {
        
        //#line 55 "x10/interop/Java8.x10"
        final x10.interop.Java8.Anonymous$2204 alloc$129603 = ((x10.interop.Java8.Anonymous$2204)(new x10.interop.Java8.Anonymous$2204<$T>((java.lang.System[]) null, $T)));
        
        //#line 55 "x10/interop/Java8.x10"
        alloc$129603.x10$interop$Java8$Anonymous$2204$$init$S(xop, (x10.interop.Java8.Anonymous$2204.__0$1x10$interop$Java8$Anonymous$2204$$T$3x10$interop$Java8$Anonymous$2204$$T$3x10$interop$Java8$Anonymous$2204$$T$2) null);
        
        //#line 55 "x10/interop/Java8.x10"
        return alloc$129603;
    }
    
    
    //#line 62 "x10/interop/Java8.x10"
    public static x10.core.fun.Fun_0_1 toX10(final java.util.function.IntUnaryOperator op) {
        
        //#line 63 "x10/interop/Java8.x10"
        final x10.core.fun.Fun_0_1 t$129654 = ((x10.core.fun.Fun_0_1)(new x10.interop.Java8.$Closure$104(op)));
        
        //#line 63 "x10/interop/Java8.x10"
        return t$129654;
    }
    
    
    //#line 65 "x10/interop/Java8.x10"
    public static x10.core.fun.Fun_0_1 toX10(final java.util.function.LongUnaryOperator op) {
        
        //#line 66 "x10/interop/Java8.x10"
        final x10.core.fun.Fun_0_1 t$129656 = ((x10.core.fun.Fun_0_1)(new x10.interop.Java8.$Closure$105(op)));
        
        //#line 66 "x10/interop/Java8.x10"
        return t$129656;
    }
    
    
    //#line 68 "x10/interop/Java8.x10"
    public static x10.core.fun.Fun_0_1 toX10(final java.util.function.DoubleUnaryOperator op) {
        
        //#line 69 "x10/interop/Java8.x10"
        final x10.core.fun.Fun_0_1 t$129658 = ((x10.core.fun.Fun_0_1)(new x10.interop.Java8.$Closure$106(op)));
        
        //#line 69 "x10/interop/Java8.x10"
        return t$129658;
    }
    
    
    //#line 71 "x10/interop/Java8.x10"
    public static <$T>x10.core.fun.Fun_0_1 toX10(final x10.rtt.Type $T, final java.util.function.UnaryOperator op) {
        
        //#line 72 "x10/interop/Java8.x10"
        final x10.core.fun.Fun_0_1 t$129661 = ((x10.core.fun.Fun_0_1)(new x10.interop.Java8.$Closure$107<$T>($T, op)));
        
        //#line 72 "x10/interop/Java8.x10"
        return t$129661;
    }
    
    
    //#line 75 "x10/interop/Java8.x10"
    public static java.util.function.IntUnaryOperator toJava__0$1x10$lang$Int$3x10$lang$Int$2(final x10.core.fun.Fun_0_1<x10.core.Int,x10.core.Int> xop) {
        
        //#line 76 "x10/interop/Java8.x10"
        final x10.interop.Java8.Anonymous$3083 alloc$129604 = ((x10.interop.Java8.Anonymous$3083)(new x10.interop.Java8.Anonymous$3083((java.lang.System[]) null)));
        
        //#line 76 "x10/interop/Java8.x10"
        alloc$129604.x10$interop$Java8$Anonymous$3083$$init$S(xop, (x10.interop.Java8.Anonymous$3083.__0$1x10$lang$Int$3x10$lang$Int$2) null);
        
        //#line 76 "x10/interop/Java8.x10"
        return alloc$129604;
    }
    
    
    //#line 80 "x10/interop/Java8.x10"
    public static java.util.function.LongUnaryOperator toJava__0$1x10$lang$Long$3x10$lang$Long$2(final x10.core.fun.Fun_0_1<x10.core.Long,x10.core.Long> xop) {
        
        //#line 81 "x10/interop/Java8.x10"
        final x10.interop.Java8.Anonymous$3321 alloc$129605 = ((x10.interop.Java8.Anonymous$3321)(new x10.interop.Java8.Anonymous$3321((java.lang.System[]) null)));
        
        //#line 81 "x10/interop/Java8.x10"
        alloc$129605.x10$interop$Java8$Anonymous$3321$$init$S(xop, (x10.interop.Java8.Anonymous$3321.__0$1x10$lang$Long$3x10$lang$Long$2) null);
        
        //#line 81 "x10/interop/Java8.x10"
        return alloc$129605;
    }
    
    
    //#line 85 "x10/interop/Java8.x10"
    public static java.util.function.DoubleUnaryOperator toJava__0$1x10$lang$Double$3x10$lang$Double$2(final x10.core.fun.Fun_0_1<x10.core.Double,x10.core.Double> xop) {
        
        //#line 86 "x10/interop/Java8.x10"
        final x10.interop.Java8.Anonymous$3569 alloc$129606 = ((x10.interop.Java8.Anonymous$3569)(new x10.interop.Java8.Anonymous$3569((java.lang.System[]) null)));
        
        //#line 86 "x10/interop/Java8.x10"
        alloc$129606.x10$interop$Java8$Anonymous$3569$$init$S(xop, (x10.interop.Java8.Anonymous$3569.__0$1x10$lang$Double$3x10$lang$Double$2) null);
        
        //#line 86 "x10/interop/Java8.x10"
        return alloc$129606;
    }
    
    
    //#line 90 "x10/interop/Java8.x10"
    public static <$T>java.util.function.UnaryOperator toJava__0$1x10$interop$Java8$$T$3x10$interop$Java8$$T$2(final x10.rtt.Type $T, final x10.core.fun.Fun_0_1<$T,$T> xop) {
        
        //#line 91 "x10/interop/Java8.x10"
        final x10.interop.Java8.Anonymous$3819 alloc$129607 = ((x10.interop.Java8.Anonymous$3819)(new x10.interop.Java8.Anonymous$3819<$T>((java.lang.System[]) null, $T)));
        
        //#line 91 "x10/interop/Java8.x10"
        alloc$129607.x10$interop$Java8$Anonymous$3819$$init$S(xop, (x10.interop.Java8.Anonymous$3819.__0$1x10$interop$Java8$Anonymous$3819$$T$3x10$interop$Java8$Anonymous$3819$$T$2) null);
        
        //#line 91 "x10/interop/Java8.x10"
        return alloc$129607;
    }
    
    
    //#line 98 "x10/interop/Java8.x10"
    public static x10.core.fun.Fun_0_1 toX10(final java.util.function.IntPredicate op) {
        
        //#line 99 "x10/interop/Java8.x10"
        final x10.core.fun.Fun_0_1 t$129663 = ((x10.core.fun.Fun_0_1)(new x10.interop.Java8.$Closure$108(op)));
        
        //#line 99 "x10/interop/Java8.x10"
        return t$129663;
    }
    
    
    //#line 101 "x10/interop/Java8.x10"
    public static x10.core.fun.Fun_0_1 toX10(final java.util.function.LongPredicate op) {
        
        //#line 102 "x10/interop/Java8.x10"
        final x10.core.fun.Fun_0_1 t$129665 = ((x10.core.fun.Fun_0_1)(new x10.interop.Java8.$Closure$109(op)));
        
        //#line 102 "x10/interop/Java8.x10"
        return t$129665;
    }
    
    
    //#line 104 "x10/interop/Java8.x10"
    public static x10.core.fun.Fun_0_1 toX10(final java.util.function.DoublePredicate op) {
        
        //#line 105 "x10/interop/Java8.x10"
        final x10.core.fun.Fun_0_1 t$129667 = ((x10.core.fun.Fun_0_1)(new x10.interop.Java8.$Closure$110(op)));
        
        //#line 105 "x10/interop/Java8.x10"
        return t$129667;
    }
    
    
    //#line 107 "x10/interop/Java8.x10"
    public static <$T>x10.core.fun.Fun_0_1 toX10(final x10.rtt.Type $T, final java.util.function.Predicate op) {
        
        //#line 108 "x10/interop/Java8.x10"
        final x10.core.fun.Fun_0_1 t$129669 = ((x10.core.fun.Fun_0_1)(new x10.interop.Java8.$Closure$111<$T>($T, op)));
        
        //#line 108 "x10/interop/Java8.x10"
        return t$129669;
    }
    
    
    //#line 111 "x10/interop/Java8.x10"
    public static java.util.function.IntPredicate toJava__0$1x10$lang$Int$3x10$lang$Boolean$2(final x10.core.fun.Fun_0_1<x10.core.Int,x10.core.Boolean> xop) {
        
        //#line 112 "x10/interop/Java8.x10"
        final x10.interop.Java8.Anonymous$4627 alloc$129608 = ((x10.interop.Java8.Anonymous$4627)(new x10.interop.Java8.Anonymous$4627((java.lang.System[]) null)));
        
        //#line 112 "x10/interop/Java8.x10"
        alloc$129608.x10$interop$Java8$Anonymous$4627$$init$S(xop, (x10.interop.Java8.Anonymous$4627.__0$1x10$lang$Int$3x10$lang$Boolean$2) null);
        
        //#line 112 "x10/interop/Java8.x10"
        return alloc$129608;
    }
    
    
    //#line 116 "x10/interop/Java8.x10"
    public static java.util.function.LongPredicate toJava__0$1x10$lang$Long$3x10$lang$Boolean$2(final x10.core.fun.Fun_0_1<x10.core.Long,x10.core.Boolean> xop) {
        
        //#line 117 "x10/interop/Java8.x10"
        final x10.interop.Java8.Anonymous$4854 alloc$129609 = ((x10.interop.Java8.Anonymous$4854)(new x10.interop.Java8.Anonymous$4854((java.lang.System[]) null)));
        
        //#line 117 "x10/interop/Java8.x10"
        alloc$129609.x10$interop$Java8$Anonymous$4854$$init$S(xop, (x10.interop.Java8.Anonymous$4854.__0$1x10$lang$Long$3x10$lang$Boolean$2) null);
        
        //#line 117 "x10/interop/Java8.x10"
        return alloc$129609;
    }
    
    
    //#line 121 "x10/interop/Java8.x10"
    public static java.util.function.DoublePredicate toJava__0$1x10$lang$Double$3x10$lang$Boolean$2(final x10.core.fun.Fun_0_1<x10.core.Double,x10.core.Boolean> xop) {
        
        //#line 122 "x10/interop/Java8.x10"
        final x10.interop.Java8.Anonymous$5087 alloc$129610 = ((x10.interop.Java8.Anonymous$5087)(new x10.interop.Java8.Anonymous$5087((java.lang.System[]) null)));
        
        //#line 122 "x10/interop/Java8.x10"
        alloc$129610.x10$interop$Java8$Anonymous$5087$$init$S(xop, (x10.interop.Java8.Anonymous$5087.__0$1x10$lang$Double$3x10$lang$Boolean$2) null);
        
        //#line 122 "x10/interop/Java8.x10"
        return alloc$129610;
    }
    
    
    //#line 126 "x10/interop/Java8.x10"
    public static <$T>java.util.function.Predicate toJava__0$1x10$interop$Java8$$T$3x10$lang$Boolean$2(final x10.rtt.Type $T, final x10.core.fun.Fun_0_1<$T,x10.core.Boolean> xop) {
        
        //#line 127 "x10/interop/Java8.x10"
        final x10.interop.Java8.Anonymous$5323 alloc$129611 = ((x10.interop.Java8.Anonymous$5323)(new x10.interop.Java8.Anonymous$5323<$T>((java.lang.System[]) null, $T)));
        
        //#line 127 "x10/interop/Java8.x10"
        alloc$129611.x10$interop$Java8$Anonymous$5323$$init$S(xop, (x10.interop.Java8.Anonymous$5323.__0$1x10$interop$Java8$Anonymous$5323$$T$3x10$lang$Boolean$2) null);
        
        //#line 127 "x10/interop/Java8.x10"
        return alloc$129611;
    }
    
    
    //#line 134 "x10/interop/Java8.x10"
    public static <$T, $U>x10.core.fun.Fun_0_2 toX10(final x10.rtt.Type $T, final x10.rtt.Type $U, final java.util.function.BiPredicate op) {
        
        //#line 135 "x10/interop/Java8.x10"
        final x10.core.fun.Fun_0_2 t$129671 = ((x10.core.fun.Fun_0_2)(new x10.interop.Java8.$Closure$112<$T, $U>($T, $U, op)));
        
        //#line 135 "x10/interop/Java8.x10"
        return t$129671;
    }
    
    
    //#line 138 "x10/interop/Java8.x10"
    public static <$T, $U>java.util.function.BiPredicate toJava__0$1x10$interop$Java8$$T$3x10$interop$Java8$$U$3x10$lang$Boolean$2(final x10.rtt.Type $T, final x10.rtt.Type $U, final x10.core.fun.Fun_0_2<$T,$U,x10.core.Boolean> xop) {
        
        //#line 139 "x10/interop/Java8.x10"
        final x10.interop.Java8.Anonymous$5737 alloc$129612 = ((x10.interop.Java8.Anonymous$5737)(new x10.interop.Java8.Anonymous$5737<$T, $U>((java.lang.System[]) null, $T, $U)));
        
        //#line 139 "x10/interop/Java8.x10"
        alloc$129612.x10$interop$Java8$Anonymous$5737$$init$S(xop, (x10.interop.Java8.Anonymous$5737.__0$1x10$interop$Java8$Anonymous$5737$$T$3x10$interop$Java8$Anonymous$5737$$U$3x10$lang$Boolean$2) null);
        
        //#line 139 "x10/interop/Java8.x10"
        return alloc$129612;
    }
    
    
    //#line 146 "x10/interop/Java8.x10"
    public static x10.core.fun.VoidFun_0_1 toX10(final java.util.function.IntConsumer op) {
        
        //#line 147 "x10/interop/Java8.x10"
        final x10.core.fun.VoidFun_0_1 t$129672 = ((x10.core.fun.VoidFun_0_1)(new x10.interop.Java8.$Closure$113(op)));
        
        //#line 147 "x10/interop/Java8.x10"
        return t$129672;
    }
    
    
    //#line 149 "x10/interop/Java8.x10"
    public static x10.core.fun.VoidFun_0_1 toX10(final java.util.function.LongConsumer op) {
        
        //#line 150 "x10/interop/Java8.x10"
        final x10.core.fun.VoidFun_0_1 t$129673 = ((x10.core.fun.VoidFun_0_1)(new x10.interop.Java8.$Closure$114(op)));
        
        //#line 150 "x10/interop/Java8.x10"
        return t$129673;
    }
    
    
    //#line 152 "x10/interop/Java8.x10"
    public static x10.core.fun.VoidFun_0_1 toX10(final java.util.function.DoubleConsumer op) {
        
        //#line 153 "x10/interop/Java8.x10"
        final x10.core.fun.VoidFun_0_1 t$129674 = ((x10.core.fun.VoidFun_0_1)(new x10.interop.Java8.$Closure$115(op)));
        
        //#line 153 "x10/interop/Java8.x10"
        return t$129674;
    }
    
    
    //#line 155 "x10/interop/Java8.x10"
    public static <$T>x10.core.fun.VoidFun_0_1 toX10(final x10.rtt.Type $T, final java.util.function.Consumer op) {
        
        //#line 156 "x10/interop/Java8.x10"
        final x10.core.fun.VoidFun_0_1 t$129675 = ((x10.core.fun.VoidFun_0_1)(new x10.interop.Java8.$Closure$116<$T>($T, op)));
        
        //#line 156 "x10/interop/Java8.x10"
        return t$129675;
    }
    
    
    //#line 159 "x10/interop/Java8.x10"
    public static java.util.function.IntConsumer toJava__0$1x10$lang$Int$2(final x10.core.fun.VoidFun_0_1<x10.core.Int> xop) {
        
        //#line 160 "x10/interop/Java8.x10"
        final x10.interop.Java8.Anonymous$6556 alloc$129613 = ((x10.interop.Java8.Anonymous$6556)(new x10.interop.Java8.Anonymous$6556((java.lang.System[]) null)));
        
        //#line 160 "x10/interop/Java8.x10"
        alloc$129613.x10$interop$Java8$Anonymous$6556$$init$S(xop, (x10.interop.Java8.Anonymous$6556.__0$1x10$lang$Int$2) null);
        
        //#line 160 "x10/interop/Java8.x10"
        return alloc$129613;
    }
    
    
    //#line 164 "x10/interop/Java8.x10"
    public static java.util.function.LongConsumer toJava__0$1x10$lang$Long$2(final x10.core.fun.VoidFun_0_1<x10.core.Long> xop) {
        
        //#line 165 "x10/interop/Java8.x10"
        final x10.interop.Java8.Anonymous$6770 alloc$129614 = ((x10.interop.Java8.Anonymous$6770)(new x10.interop.Java8.Anonymous$6770((java.lang.System[]) null)));
        
        //#line 165 "x10/interop/Java8.x10"
        alloc$129614.x10$interop$Java8$Anonymous$6770$$init$S(xop, (x10.interop.Java8.Anonymous$6770.__0$1x10$lang$Long$2) null);
        
        //#line 165 "x10/interop/Java8.x10"
        return alloc$129614;
    }
    
    
    //#line 169 "x10/interop/Java8.x10"
    public static java.util.function.DoubleConsumer toJava__0$1x10$lang$Double$2(final x10.core.fun.VoidFun_0_1<x10.core.Double> xop) {
        
        //#line 170 "x10/interop/Java8.x10"
        final x10.interop.Java8.Anonymous$6990 alloc$129615 = ((x10.interop.Java8.Anonymous$6990)(new x10.interop.Java8.Anonymous$6990((java.lang.System[]) null)));
        
        //#line 170 "x10/interop/Java8.x10"
        alloc$129615.x10$interop$Java8$Anonymous$6990$$init$S(xop, (x10.interop.Java8.Anonymous$6990.__0$1x10$lang$Double$2) null);
        
        //#line 170 "x10/interop/Java8.x10"
        return alloc$129615;
    }
    
    
    //#line 174 "x10/interop/Java8.x10"
    public static <$T>java.util.function.Consumer toJava__0$1x10$interop$Java8$$T$2(final x10.rtt.Type $T, final x10.core.fun.VoidFun_0_1<$T> xop) {
        
        //#line 175 "x10/interop/Java8.x10"
        final x10.interop.Java8.Anonymous$7213 alloc$129616 = ((x10.interop.Java8.Anonymous$7213)(new x10.interop.Java8.Anonymous$7213<$T>((java.lang.System[]) null, $T)));
        
        //#line 175 "x10/interop/Java8.x10"
        alloc$129616.x10$interop$Java8$Anonymous$7213$$init$S(xop, (x10.interop.Java8.Anonymous$7213.__0$1x10$interop$Java8$Anonymous$7213$$T$2) null);
        
        //#line 175 "x10/interop/Java8.x10"
        return alloc$129616;
    }
    
    
    //#line 182 "x10/interop/Java8.x10"
    public static <$T>x10.core.fun.VoidFun_0_2 toX10(final x10.rtt.Type $T, final java.util.function.ObjIntConsumer op) {
        
        //#line 183 "x10/interop/Java8.x10"
        final x10.core.fun.VoidFun_0_2 t$129676 = ((x10.core.fun.VoidFun_0_2)(new x10.interop.Java8.$Closure$117<$T>($T, op)));
        
        //#line 183 "x10/interop/Java8.x10"
        return t$129676;
    }
    
    
    //#line 185 "x10/interop/Java8.x10"
    public static <$T>x10.core.fun.VoidFun_0_2 toX10(final x10.rtt.Type $T, final java.util.function.ObjLongConsumer op) {
        
        //#line 186 "x10/interop/Java8.x10"
        final x10.core.fun.VoidFun_0_2 t$129677 = ((x10.core.fun.VoidFun_0_2)(new x10.interop.Java8.$Closure$118<$T>($T, op)));
        
        //#line 186 "x10/interop/Java8.x10"
        return t$129677;
    }
    
    
    //#line 188 "x10/interop/Java8.x10"
    public static <$T>x10.core.fun.VoidFun_0_2 toX10(final x10.rtt.Type $T, final java.util.function.ObjDoubleConsumer op) {
        
        //#line 189 "x10/interop/Java8.x10"
        final x10.core.fun.VoidFun_0_2 t$129678 = ((x10.core.fun.VoidFun_0_2)(new x10.interop.Java8.$Closure$119<$T>($T, op)));
        
        //#line 189 "x10/interop/Java8.x10"
        return t$129678;
    }
    
    
    //#line 191 "x10/interop/Java8.x10"
    public static <$T, $U>x10.core.fun.VoidFun_0_2 toX10(final x10.rtt.Type $T, final x10.rtt.Type $U, final java.util.function.BiConsumer op) {
        
        //#line 192 "x10/interop/Java8.x10"
        final x10.core.fun.VoidFun_0_2 t$129679 = ((x10.core.fun.VoidFun_0_2)(new x10.interop.Java8.$Closure$120<$T, $U>($T, $U, op)));
        
        //#line 192 "x10/interop/Java8.x10"
        return t$129679;
    }
    
    
    //#line 195 "x10/interop/Java8.x10"
    public static <$T>java.util.function.ObjIntConsumer toJava__0$1x10$interop$Java8$$T$3x10$lang$Int$2(final x10.rtt.Type $T, final x10.core.fun.VoidFun_0_2<$T,x10.core.Int> xop) {
        
        //#line 196 "x10/interop/Java8.x10"
        final x10.interop.Java8.Anonymous$8071 alloc$129617 = ((x10.interop.Java8.Anonymous$8071)(new x10.interop.Java8.Anonymous$8071<$T>((java.lang.System[]) null, $T)));
        
        //#line 196 "x10/interop/Java8.x10"
        alloc$129617.x10$interop$Java8$Anonymous$8071$$init$S(xop, (x10.interop.Java8.Anonymous$8071.__0$1x10$interop$Java8$Anonymous$8071$$T$3x10$lang$Int$2) null);
        
        //#line 196 "x10/interop/Java8.x10"
        return alloc$129617;
    }
    
    
    //#line 200 "x10/interop/Java8.x10"
    public static <$T>java.util.function.ObjLongConsumer toJava__0$1x10$interop$Java8$$T$3x10$lang$Long$2(final x10.rtt.Type $T, final x10.core.fun.VoidFun_0_2<$T,x10.core.Long> xop) {
        
        //#line 201 "x10/interop/Java8.x10"
        final x10.interop.Java8.Anonymous$8321 alloc$129618 = ((x10.interop.Java8.Anonymous$8321)(new x10.interop.Java8.Anonymous$8321<$T>((java.lang.System[]) null, $T)));
        
        //#line 201 "x10/interop/Java8.x10"
        alloc$129618.x10$interop$Java8$Anonymous$8321$$init$S(xop, (x10.interop.Java8.Anonymous$8321.__0$1x10$interop$Java8$Anonymous$8321$$T$3x10$lang$Long$2) null);
        
        //#line 201 "x10/interop/Java8.x10"
        return alloc$129618;
    }
    
    
    //#line 205 "x10/interop/Java8.x10"
    public static <$T>java.util.function.ObjDoubleConsumer toJava__0$1x10$interop$Java8$$T$3x10$lang$Double$2(final x10.rtt.Type $T, final x10.core.fun.VoidFun_0_2<$T,x10.core.Double> xop) {
        
        //#line 206 "x10/interop/Java8.x10"
        final x10.interop.Java8.Anonymous$8577 alloc$129619 = ((x10.interop.Java8.Anonymous$8577)(new x10.interop.Java8.Anonymous$8577<$T>((java.lang.System[]) null, $T)));
        
        //#line 206 "x10/interop/Java8.x10"
        alloc$129619.x10$interop$Java8$Anonymous$8577$$init$S(xop, (x10.interop.Java8.Anonymous$8577.__0$1x10$interop$Java8$Anonymous$8577$$T$3x10$lang$Double$2) null);
        
        //#line 206 "x10/interop/Java8.x10"
        return alloc$129619;
    }
    
    
    //#line 210 "x10/interop/Java8.x10"
    public static <$T, $U>java.util.function.BiConsumer toJava__0$1x10$interop$Java8$$T$3x10$interop$Java8$$U$2(final x10.rtt.Type $T, final x10.rtt.Type $U, final x10.core.fun.VoidFun_0_2<$T,$U> xop) {
        
        //#line 211 "x10/interop/Java8.x10"
        final x10.interop.Java8.Anonymous$8829 alloc$129620 = ((x10.interop.Java8.Anonymous$8829)(new x10.interop.Java8.Anonymous$8829<$T, $U>((java.lang.System[]) null, $T, $U)));
        
        //#line 211 "x10/interop/Java8.x10"
        alloc$129620.x10$interop$Java8$Anonymous$8829$$init$S(xop, (x10.interop.Java8.Anonymous$8829.__0$1x10$interop$Java8$Anonymous$8829$$T$3x10$interop$Java8$Anonymous$8829$$U$2) null);
        
        //#line 211 "x10/interop/Java8.x10"
        return alloc$129620;
    }
    
    
    //#line 218 "x10/interop/Java8.x10"
    public static x10.core.fun.Fun_0_0 toX10(final java.util.function.IntSupplier op) {
        
        //#line 219 "x10/interop/Java8.x10"
        final x10.core.fun.Fun_0_0 t$129681 = ((x10.core.fun.Fun_0_0)(new x10.interop.Java8.$Closure$121(op)));
        
        //#line 219 "x10/interop/Java8.x10"
        return t$129681;
    }
    
    
    //#line 221 "x10/interop/Java8.x10"
    public static x10.core.fun.Fun_0_0 toX10(final java.util.function.LongSupplier op) {
        
        //#line 222 "x10/interop/Java8.x10"
        final x10.core.fun.Fun_0_0 t$129683 = ((x10.core.fun.Fun_0_0)(new x10.interop.Java8.$Closure$122(op)));
        
        //#line 222 "x10/interop/Java8.x10"
        return t$129683;
    }
    
    
    //#line 224 "x10/interop/Java8.x10"
    public static x10.core.fun.Fun_0_0 toX10(final java.util.function.DoubleSupplier op) {
        
        //#line 225 "x10/interop/Java8.x10"
        final x10.core.fun.Fun_0_0 t$129685 = ((x10.core.fun.Fun_0_0)(new x10.interop.Java8.$Closure$123(op)));
        
        //#line 225 "x10/interop/Java8.x10"
        return t$129685;
    }
    
    
    //#line 227 "x10/interop/Java8.x10"
    public static x10.core.fun.Fun_0_0 toX10(final java.util.function.BooleanSupplier op) {
        
        //#line 228 "x10/interop/Java8.x10"
        final x10.core.fun.Fun_0_0 t$129687 = ((x10.core.fun.Fun_0_0)(new x10.interop.Java8.$Closure$124(op)));
        
        //#line 228 "x10/interop/Java8.x10"
        return t$129687;
    }
    
    
    //#line 230 "x10/interop/Java8.x10"
    public static <$T>x10.core.fun.Fun_0_0 toX10(final x10.rtt.Type $T, final java.util.function.Supplier op) {
        
        //#line 231 "x10/interop/Java8.x10"
        final x10.core.fun.Fun_0_0 t$129690 = ((x10.core.fun.Fun_0_0)(new x10.interop.Java8.$Closure$125<$T>($T, op)));
        
        //#line 231 "x10/interop/Java8.x10"
        return t$129690;
    }
    
    
    //#line 234 "x10/interop/Java8.x10"
    public static java.util.function.IntSupplier toJava__0$1x10$lang$Int$2(final x10.core.fun.Fun_0_0<x10.core.Int> xop) {
        
        //#line 235 "x10/interop/Java8.x10"
        final x10.interop.Java8.Anonymous$9679 alloc$129621 = ((x10.interop.Java8.Anonymous$9679)(new x10.interop.Java8.Anonymous$9679((java.lang.System[]) null)));
        
        //#line 235 "x10/interop/Java8.x10"
        alloc$129621.x10$interop$Java8$Anonymous$9679$$init$S(xop, (x10.interop.Java8.Anonymous$9679.__0$1x10$lang$Int$2) null);
        
        //#line 235 "x10/interop/Java8.x10"
        return alloc$129621;
    }
    
    
    //#line 239 "x10/interop/Java8.x10"
    public static java.util.function.LongSupplier toJava__0$1x10$lang$Long$2(final x10.core.fun.Fun_0_0<x10.core.Long> xop) {
        
        //#line 240 "x10/interop/Java8.x10"
        final x10.interop.Java8.Anonymous$9883 alloc$129622 = ((x10.interop.Java8.Anonymous$9883)(new x10.interop.Java8.Anonymous$9883((java.lang.System[]) null)));
        
        //#line 240 "x10/interop/Java8.x10"
        alloc$129622.x10$interop$Java8$Anonymous$9883$$init$S(xop, (x10.interop.Java8.Anonymous$9883.__0$1x10$lang$Long$2) null);
        
        //#line 240 "x10/interop/Java8.x10"
        return alloc$129622;
    }
    
    
    //#line 244 "x10/interop/Java8.x10"
    public static java.util.function.DoubleSupplier toJava__0$1x10$lang$Double$2(final x10.core.fun.Fun_0_0<x10.core.Double> xop) {
        
        //#line 245 "x10/interop/Java8.x10"
        final x10.interop.Java8.Anonymous$10094 alloc$129623 = ((x10.interop.Java8.Anonymous$10094)(new x10.interop.Java8.Anonymous$10094((java.lang.System[]) null)));
        
        //#line 245 "x10/interop/Java8.x10"
        alloc$129623.x10$interop$Java8$Anonymous$10094$$init$S(xop, (x10.interop.Java8.Anonymous$10094.__0$1x10$lang$Double$2) null);
        
        //#line 245 "x10/interop/Java8.x10"
        return alloc$129623;
    }
    
    
    //#line 249 "x10/interop/Java8.x10"
    public static java.util.function.BooleanSupplier toJava__0$1x10$lang$Boolean$2(final x10.core.fun.Fun_0_0<x10.core.Boolean> xop) {
        
        //#line 250 "x10/interop/Java8.x10"
        final x10.interop.Java8.Anonymous$10313 alloc$129624 = ((x10.interop.Java8.Anonymous$10313)(new x10.interop.Java8.Anonymous$10313((java.lang.System[]) null)));
        
        //#line 250 "x10/interop/Java8.x10"
        alloc$129624.x10$interop$Java8$Anonymous$10313$$init$S(xop, (x10.interop.Java8.Anonymous$10313.__0$1x10$lang$Boolean$2) null);
        
        //#line 250 "x10/interop/Java8.x10"
        return alloc$129624;
    }
    
    
    //#line 254 "x10/interop/Java8.x10"
    public static <$T>java.util.function.Supplier toJava__0$1x10$interop$Java8$$T$2(final x10.rtt.Type $T, final x10.core.fun.Fun_0_0<$T> xop) {
        
        //#line 255 "x10/interop/Java8.x10"
        final x10.interop.Java8.Anonymous$10532 alloc$129625 = ((x10.interop.Java8.Anonymous$10532)(new x10.interop.Java8.Anonymous$10532<$T>((java.lang.System[]) null, $T)));
        
        //#line 255 "x10/interop/Java8.x10"
        alloc$129625.x10$interop$Java8$Anonymous$10532$$init$S(xop, (x10.interop.Java8.Anonymous$10532.__0$1x10$interop$Java8$Anonymous$10532$$T$2) null);
        
        //#line 255 "x10/interop/Java8.x10"
        return alloc$129625;
    }
    
    
    //#line 262 "x10/interop/Java8.x10"
    public static x10.core.fun.Fun_0_1 toX10(final java.util.function.LongToIntFunction op) {
        
        //#line 263 "x10/interop/Java8.x10"
        final x10.core.fun.Fun_0_1 t$129692 = ((x10.core.fun.Fun_0_1)(new x10.interop.Java8.$Closure$126(op)));
        
        //#line 263 "x10/interop/Java8.x10"
        return t$129692;
    }
    
    
    //#line 265 "x10/interop/Java8.x10"
    public static x10.core.fun.Fun_0_1 toX10(final java.util.function.DoubleToIntFunction op) {
        
        //#line 266 "x10/interop/Java8.x10"
        final x10.core.fun.Fun_0_1 t$129694 = ((x10.core.fun.Fun_0_1)(new x10.interop.Java8.$Closure$127(op)));
        
        //#line 266 "x10/interop/Java8.x10"
        return t$129694;
    }
    
    
    //#line 268 "x10/interop/Java8.x10"
    public static <$T>x10.core.fun.Fun_0_1 toX10(final x10.rtt.Type $T, final java.util.function.ToIntFunction op) {
        
        //#line 269 "x10/interop/Java8.x10"
        final x10.core.fun.Fun_0_1 t$129696 = ((x10.core.fun.Fun_0_1)(new x10.interop.Java8.$Closure$128<$T>($T, op)));
        
        //#line 269 "x10/interop/Java8.x10"
        return t$129696;
    }
    
    
    //#line 272 "x10/interop/Java8.x10"
    public static java.util.function.LongToIntFunction toJava__0$1x10$lang$Long$3x10$lang$Int$2(final x10.core.fun.Fun_0_1<x10.core.Long,x10.core.Int> xop) {
        
        //#line 273 "x10/interop/Java8.x10"
        final x10.interop.Java8.Anonymous$11198 alloc$129626 = ((x10.interop.Java8.Anonymous$11198)(new x10.interop.Java8.Anonymous$11198((java.lang.System[]) null)));
        
        //#line 273 "x10/interop/Java8.x10"
        alloc$129626.x10$interop$Java8$Anonymous$11198$$init$S(xop, (x10.interop.Java8.Anonymous$11198.__0$1x10$lang$Long$3x10$lang$Int$2) null);
        
        //#line 273 "x10/interop/Java8.x10"
        return alloc$129626;
    }
    
    
    //#line 277 "x10/interop/Java8.x10"
    public static java.util.function.DoubleToIntFunction toJava__0$1x10$lang$Double$3x10$lang$Int$2(final x10.core.fun.Fun_0_1<x10.core.Double,x10.core.Int> xop) {
        
        //#line 278 "x10/interop/Java8.x10"
        final x10.interop.Java8.Anonymous$11437 alloc$129627 = ((x10.interop.Java8.Anonymous$11437)(new x10.interop.Java8.Anonymous$11437((java.lang.System[]) null)));
        
        //#line 278 "x10/interop/Java8.x10"
        alloc$129627.x10$interop$Java8$Anonymous$11437$$init$S(xop, (x10.interop.Java8.Anonymous$11437.__0$1x10$lang$Double$3x10$lang$Int$2) null);
        
        //#line 278 "x10/interop/Java8.x10"
        return alloc$129627;
    }
    
    
    //#line 282 "x10/interop/Java8.x10"
    public static <$T>java.util.function.ToIntFunction toJava__0$1x10$interop$Java8$$T$3x10$lang$Int$2(final x10.rtt.Type $T, final x10.core.fun.Fun_0_1<$T,x10.core.Int> xop) {
        
        //#line 283 "x10/interop/Java8.x10"
        final x10.interop.Java8.Anonymous$11679 alloc$129628 = ((x10.interop.Java8.Anonymous$11679)(new x10.interop.Java8.Anonymous$11679<$T>((java.lang.System[]) null, $T)));
        
        //#line 283 "x10/interop/Java8.x10"
        alloc$129628.x10$interop$Java8$Anonymous$11679$$init$S(xop, (x10.interop.Java8.Anonymous$11679.__0$1x10$interop$Java8$Anonymous$11679$$T$3x10$lang$Int$2) null);
        
        //#line 283 "x10/interop/Java8.x10"
        return alloc$129628;
    }
    
    
    //#line 290 "x10/interop/Java8.x10"
    public static x10.core.fun.Fun_0_1 toX10(final java.util.function.IntToLongFunction op) {
        
        //#line 291 "x10/interop/Java8.x10"
        final x10.core.fun.Fun_0_1 t$129698 = ((x10.core.fun.Fun_0_1)(new x10.interop.Java8.$Closure$129(op)));
        
        //#line 291 "x10/interop/Java8.x10"
        return t$129698;
    }
    
    
    //#line 293 "x10/interop/Java8.x10"
    public static x10.core.fun.Fun_0_1 toX10(final java.util.function.DoubleToLongFunction op) {
        
        //#line 294 "x10/interop/Java8.x10"
        final x10.core.fun.Fun_0_1 t$129700 = ((x10.core.fun.Fun_0_1)(new x10.interop.Java8.$Closure$130(op)));
        
        //#line 294 "x10/interop/Java8.x10"
        return t$129700;
    }
    
    
    //#line 296 "x10/interop/Java8.x10"
    public static <$T>x10.core.fun.Fun_0_1 toX10(final x10.rtt.Type $T, final java.util.function.ToLongFunction op) {
        
        //#line 297 "x10/interop/Java8.x10"
        final x10.core.fun.Fun_0_1 t$129702 = ((x10.core.fun.Fun_0_1)(new x10.interop.Java8.$Closure$131<$T>($T, op)));
        
        //#line 297 "x10/interop/Java8.x10"
        return t$129702;
    }
    
    
    //#line 300 "x10/interop/Java8.x10"
    public static java.util.function.IntToLongFunction toJava__0$1x10$lang$Int$3x10$lang$Long$2(final x10.core.fun.Fun_0_1<x10.core.Int,x10.core.Long> xop) {
        
        //#line 301 "x10/interop/Java8.x10"
        final x10.interop.Java8.Anonymous$12383 alloc$129629 = ((x10.interop.Java8.Anonymous$12383)(new x10.interop.Java8.Anonymous$12383((java.lang.System[]) null)));
        
        //#line 301 "x10/interop/Java8.x10"
        alloc$129629.x10$interop$Java8$Anonymous$12383$$init$S(xop, (x10.interop.Java8.Anonymous$12383.__0$1x10$lang$Int$3x10$lang$Long$2) null);
        
        //#line 301 "x10/interop/Java8.x10"
        return alloc$129629;
    }
    
    
    //#line 305 "x10/interop/Java8.x10"
    public static java.util.function.DoubleToLongFunction toJava__0$1x10$lang$Double$3x10$lang$Long$2(final x10.core.fun.Fun_0_1<x10.core.Double,x10.core.Long> xop) {
        
        //#line 306 "x10/interop/Java8.x10"
        final x10.interop.Java8.Anonymous$12625 alloc$129630 = ((x10.interop.Java8.Anonymous$12625)(new x10.interop.Java8.Anonymous$12625((java.lang.System[]) null)));
        
        //#line 306 "x10/interop/Java8.x10"
        alloc$129630.x10$interop$Java8$Anonymous$12625$$init$S(xop, (x10.interop.Java8.Anonymous$12625.__0$1x10$lang$Double$3x10$lang$Long$2) null);
        
        //#line 306 "x10/interop/Java8.x10"
        return alloc$129630;
    }
    
    
    //#line 310 "x10/interop/Java8.x10"
    public static <$T>java.util.function.ToLongFunction toJava__0$1x10$interop$Java8$$T$3x10$lang$Long$2(final x10.rtt.Type $T, final x10.core.fun.Fun_0_1<$T,x10.core.Long> xop) {
        
        //#line 311 "x10/interop/Java8.x10"
        final x10.interop.Java8.Anonymous$12872 alloc$129631 = ((x10.interop.Java8.Anonymous$12872)(new x10.interop.Java8.Anonymous$12872<$T>((java.lang.System[]) null, $T)));
        
        //#line 311 "x10/interop/Java8.x10"
        alloc$129631.x10$interop$Java8$Anonymous$12872$$init$S(xop, (x10.interop.Java8.Anonymous$12872.__0$1x10$interop$Java8$Anonymous$12872$$T$3x10$lang$Long$2) null);
        
        //#line 311 "x10/interop/Java8.x10"
        return alloc$129631;
    }
    
    
    //#line 318 "x10/interop/Java8.x10"
    public static x10.core.fun.Fun_0_1 toX10(final java.util.function.IntToDoubleFunction op) {
        
        //#line 319 "x10/interop/Java8.x10"
        final x10.core.fun.Fun_0_1 t$129704 = ((x10.core.fun.Fun_0_1)(new x10.interop.Java8.$Closure$132(op)));
        
        //#line 319 "x10/interop/Java8.x10"
        return t$129704;
    }
    
    
    //#line 321 "x10/interop/Java8.x10"
    public static x10.core.fun.Fun_0_1 toX10(final java.util.function.LongToDoubleFunction op) {
        
        //#line 322 "x10/interop/Java8.x10"
        final x10.core.fun.Fun_0_1 t$129706 = ((x10.core.fun.Fun_0_1)(new x10.interop.Java8.$Closure$133(op)));
        
        //#line 322 "x10/interop/Java8.x10"
        return t$129706;
    }
    
    
    //#line 324 "x10/interop/Java8.x10"
    public static <$T>x10.core.fun.Fun_0_1 toX10(final x10.rtt.Type $T, final java.util.function.ToDoubleFunction op) {
        
        //#line 325 "x10/interop/Java8.x10"
        final x10.core.fun.Fun_0_1 t$129708 = ((x10.core.fun.Fun_0_1)(new x10.interop.Java8.$Closure$134<$T>($T, op)));
        
        //#line 325 "x10/interop/Java8.x10"
        return t$129708;
    }
    
    
    //#line 328 "x10/interop/Java8.x10"
    public static java.util.function.IntToDoubleFunction toJava__0$1x10$lang$Int$3x10$lang$Double$2(final x10.core.fun.Fun_0_1<x10.core.Int,x10.core.Double> xop) {
        
        //#line 329 "x10/interop/Java8.x10"
        final x10.interop.Java8.Anonymous$13597 alloc$129632 = ((x10.interop.Java8.Anonymous$13597)(new x10.interop.Java8.Anonymous$13597((java.lang.System[]) null)));
        
        //#line 329 "x10/interop/Java8.x10"
        alloc$129632.x10$interop$Java8$Anonymous$13597$$init$S(xop, (x10.interop.Java8.Anonymous$13597.__0$1x10$lang$Int$3x10$lang$Double$2) null);
        
        //#line 329 "x10/interop/Java8.x10"
        return alloc$129632;
    }
    
    
    //#line 333 "x10/interop/Java8.x10"
    public static java.util.function.LongToDoubleFunction toJava__0$1x10$lang$Long$3x10$lang$Double$2(final x10.core.fun.Fun_0_1<x10.core.Long,x10.core.Double> xop) {
        
        //#line 334 "x10/interop/Java8.x10"
        final x10.interop.Java8.Anonymous$13845 alloc$129633 = ((x10.interop.Java8.Anonymous$13845)(new x10.interop.Java8.Anonymous$13845((java.lang.System[]) null)));
        
        //#line 334 "x10/interop/Java8.x10"
        alloc$129633.x10$interop$Java8$Anonymous$13845$$init$S(xop, (x10.interop.Java8.Anonymous$13845.__0$1x10$lang$Long$3x10$lang$Double$2) null);
        
        //#line 334 "x10/interop/Java8.x10"
        return alloc$129633;
    }
    
    
    //#line 338 "x10/interop/Java8.x10"
    public static <$T>java.util.function.ToDoubleFunction toJava__0$1x10$interop$Java8$$T$3x10$lang$Double$2(final x10.rtt.Type $T, final x10.core.fun.Fun_0_1<$T,x10.core.Double> xop) {
        
        //#line 339 "x10/interop/Java8.x10"
        final x10.interop.Java8.Anonymous$14098 alloc$129634 = ((x10.interop.Java8.Anonymous$14098)(new x10.interop.Java8.Anonymous$14098<$T>((java.lang.System[]) null, $T)));
        
        //#line 339 "x10/interop/Java8.x10"
        alloc$129634.x10$interop$Java8$Anonymous$14098$$init$S(xop, (x10.interop.Java8.Anonymous$14098.__0$1x10$interop$Java8$Anonymous$14098$$T$3x10$lang$Double$2) null);
        
        //#line 339 "x10/interop/Java8.x10"
        return alloc$129634;
    }
    
    
    //#line 346 "x10/interop/Java8.x10"
    public static <$R>x10.core.fun.Fun_0_1 toX10(final x10.rtt.Type $R, final java.util.function.IntFunction op) {
        
        //#line 347 "x10/interop/Java8.x10"
        final x10.core.fun.Fun_0_1 t$129711 = ((x10.core.fun.Fun_0_1)(new x10.interop.Java8.$Closure$135<$R>($R, op)));
        
        //#line 347 "x10/interop/Java8.x10"
        return t$129711;
    }
    
    
    //#line 349 "x10/interop/Java8.x10"
    public static <$R>x10.core.fun.Fun_0_1 toX10(final x10.rtt.Type $R, final java.util.function.LongFunction op) {
        
        //#line 350 "x10/interop/Java8.x10"
        final x10.core.fun.Fun_0_1 t$129714 = ((x10.core.fun.Fun_0_1)(new x10.interop.Java8.$Closure$136<$R>($R, op)));
        
        //#line 350 "x10/interop/Java8.x10"
        return t$129714;
    }
    
    
    //#line 352 "x10/interop/Java8.x10"
    public static <$R>x10.core.fun.Fun_0_1 toX10(final x10.rtt.Type $R, final java.util.function.DoubleFunction op) {
        
        //#line 353 "x10/interop/Java8.x10"
        final x10.core.fun.Fun_0_1 t$129717 = ((x10.core.fun.Fun_0_1)(new x10.interop.Java8.$Closure$137<$R>($R, op)));
        
        //#line 353 "x10/interop/Java8.x10"
        return t$129717;
    }
    
    
    //#line 355 "x10/interop/Java8.x10"
    public static <$T, $R>x10.core.fun.Fun_0_1 toX10(final x10.rtt.Type $T, final x10.rtt.Type $R, final java.util.function.Function op) {
        
        //#line 356 "x10/interop/Java8.x10"
        final x10.core.fun.Fun_0_1 t$129720 = ((x10.core.fun.Fun_0_1)(new x10.interop.Java8.$Closure$138<$T, $R>($T, $R, op)));
        
        //#line 356 "x10/interop/Java8.x10"
        return t$129720;
    }
    
    
    //#line 359 "x10/interop/Java8.x10"
    public static <$R>java.util.function.IntFunction toJava__0$1x10$lang$Int$3x10$interop$Java8$$R$2(final x10.rtt.Type $R, final x10.core.fun.Fun_0_1<x10.core.Int,$R> xop) {
        
        //#line 360 "x10/interop/Java8.x10"
        final x10.interop.Java8.Anonymous$14943 alloc$129635 = ((x10.interop.Java8.Anonymous$14943)(new x10.interop.Java8.Anonymous$14943<$R>((java.lang.System[]) null, $R)));
        
        //#line 360 "x10/interop/Java8.x10"
        alloc$129635.x10$interop$Java8$Anonymous$14943$$init$S(xop, (x10.interop.Java8.Anonymous$14943.__0$1x10$lang$Int$3x10$interop$Java8$Anonymous$14943$$R$2) null);
        
        //#line 360 "x10/interop/Java8.x10"
        return alloc$129635;
    }
    
    
    //#line 364 "x10/interop/Java8.x10"
    public static <$R>java.util.function.LongFunction toJava__0$1x10$lang$Long$3x10$interop$Java8$$R$2(final x10.rtt.Type $R, final x10.core.fun.Fun_0_1<x10.core.Long,$R> xop) {
        
        //#line 365 "x10/interop/Java8.x10"
        final x10.interop.Java8.Anonymous$15174 alloc$129636 = ((x10.interop.Java8.Anonymous$15174)(new x10.interop.Java8.Anonymous$15174<$R>((java.lang.System[]) null, $R)));
        
        //#line 365 "x10/interop/Java8.x10"
        alloc$129636.x10$interop$Java8$Anonymous$15174$$init$S(xop, (x10.interop.Java8.Anonymous$15174.__0$1x10$lang$Long$3x10$interop$Java8$Anonymous$15174$$R$2) null);
        
        //#line 365 "x10/interop/Java8.x10"
        return alloc$129636;
    }
    
    
    //#line 369 "x10/interop/Java8.x10"
    public static <$R>java.util.function.DoubleFunction toJava__0$1x10$lang$Double$3x10$interop$Java8$$R$2(final x10.rtt.Type $R, final x10.core.fun.Fun_0_1<x10.core.Double,$R> xop) {
        
        //#line 370 "x10/interop/Java8.x10"
        final x10.interop.Java8.Anonymous$15411 alloc$129637 = ((x10.interop.Java8.Anonymous$15411)(new x10.interop.Java8.Anonymous$15411<$R>((java.lang.System[]) null, $R)));
        
        //#line 370 "x10/interop/Java8.x10"
        alloc$129637.x10$interop$Java8$Anonymous$15411$$init$S(xop, (x10.interop.Java8.Anonymous$15411.__0$1x10$lang$Double$3x10$interop$Java8$Anonymous$15411$$R$2) null);
        
        //#line 370 "x10/interop/Java8.x10"
        return alloc$129637;
    }
    
    
    //#line 374 "x10/interop/Java8.x10"
    public static <$T, $R>java.util.function.Function toJava__0$1x10$interop$Java8$$T$3x10$interop$Java8$$R$2(final x10.rtt.Type $T, final x10.rtt.Type $R, final x10.core.fun.Fun_0_1<$T,$R> xop) {
        
        //#line 375 "x10/interop/Java8.x10"
        final x10.interop.Java8.Anonymous$15645 alloc$129638 = ((x10.interop.Java8.Anonymous$15645)(new x10.interop.Java8.Anonymous$15645<$T, $R>((java.lang.System[]) null, $T, $R)));
        
        //#line 375 "x10/interop/Java8.x10"
        alloc$129638.x10$interop$Java8$Anonymous$15645$$init$S(xop, (x10.interop.Java8.Anonymous$15645.__0$1x10$interop$Java8$Anonymous$15645$$T$3x10$interop$Java8$Anonymous$15645$$R$2) null);
        
        //#line 375 "x10/interop/Java8.x10"
        return alloc$129638;
    }
    
    
    //#line 382 "x10/interop/Java8.x10"
    public static <$T, $U>x10.core.fun.Fun_0_2 toX10(final x10.rtt.Type $T, final x10.rtt.Type $U, final java.util.function.ToIntBiFunction op) {
        
        //#line 383 "x10/interop/Java8.x10"
        final x10.core.fun.Fun_0_2 t$129722 = ((x10.core.fun.Fun_0_2)(new x10.interop.Java8.$Closure$139<$T, $U>($T, $U, op)));
        
        //#line 383 "x10/interop/Java8.x10"
        return t$129722;
    }
    
    
    //#line 385 "x10/interop/Java8.x10"
    public static <$T, $U>x10.core.fun.Fun_0_2 toX10(final x10.rtt.Type $T, final x10.rtt.Type $U, final java.util.function.ToLongBiFunction op) {
        
        //#line 386 "x10/interop/Java8.x10"
        final x10.core.fun.Fun_0_2 t$129724 = ((x10.core.fun.Fun_0_2)(new x10.interop.Java8.$Closure$140<$T, $U>($T, $U, op)));
        
        //#line 386 "x10/interop/Java8.x10"
        return t$129724;
    }
    
    
    //#line 388 "x10/interop/Java8.x10"
    public static <$T, $U>x10.core.fun.Fun_0_2 toX10(final x10.rtt.Type $T, final x10.rtt.Type $U, final java.util.function.ToDoubleBiFunction op) {
        
        //#line 389 "x10/interop/Java8.x10"
        final x10.core.fun.Fun_0_2 t$129726 = ((x10.core.fun.Fun_0_2)(new x10.interop.Java8.$Closure$141<$T, $U>($T, $U, op)));
        
        //#line 389 "x10/interop/Java8.x10"
        return t$129726;
    }
    
    
    //#line 391 "x10/interop/Java8.x10"
    public static <$T, $U, $R>x10.core.fun.Fun_0_2 toX10(final x10.rtt.Type $T, final x10.rtt.Type $U, final x10.rtt.Type $R, final java.util.function.BiFunction op) {
        
        //#line 392 "x10/interop/Java8.x10"
        final x10.core.fun.Fun_0_2 t$129729 = ((x10.core.fun.Fun_0_2)(new x10.interop.Java8.$Closure$142<$T, $U, $R>($T, $U, $R, op)));
        
        //#line 392 "x10/interop/Java8.x10"
        return t$129729;
    }
    
    
    //#line 395 "x10/interop/Java8.x10"
    public static <$T, $U>java.util.function.ToIntBiFunction toJava__0$1x10$interop$Java8$$T$3x10$interop$Java8$$U$3x10$lang$Int$2(final x10.rtt.Type $T, final x10.rtt.Type $U, final x10.core.fun.Fun_0_2<$T,$U,x10.core.Int> xop) {
        
        //#line 396 "x10/interop/Java8.x10"
        final x10.interop.Java8.Anonymous$16507 alloc$129639 = ((x10.interop.Java8.Anonymous$16507)(new x10.interop.Java8.Anonymous$16507<$T, $U>((java.lang.System[]) null, $T, $U)));
        
        //#line 396 "x10/interop/Java8.x10"
        alloc$129639.x10$interop$Java8$Anonymous$16507$$init$S(xop, (x10.interop.Java8.Anonymous$16507.__0$1x10$interop$Java8$Anonymous$16507$$T$3x10$interop$Java8$Anonymous$16507$$U$3x10$lang$Int$2) null);
        
        //#line 396 "x10/interop/Java8.x10"
        return alloc$129639;
    }
    
    
    //#line 400 "x10/interop/Java8.x10"
    public static <$T, $U>java.util.function.ToLongBiFunction toJava__0$1x10$interop$Java8$$T$3x10$interop$Java8$$U$3x10$lang$Long$2(final x10.rtt.Type $T, final x10.rtt.Type $U, final x10.core.fun.Fun_0_2<$T,$U,x10.core.Long> xop) {
        
        //#line 401 "x10/interop/Java8.x10"
        final x10.interop.Java8.Anonymous$16781 alloc$129640 = ((x10.interop.Java8.Anonymous$16781)(new x10.interop.Java8.Anonymous$16781<$T, $U>((java.lang.System[]) null, $T, $U)));
        
        //#line 401 "x10/interop/Java8.x10"
        alloc$129640.x10$interop$Java8$Anonymous$16781$$init$S(xop, (x10.interop.Java8.Anonymous$16781.__0$1x10$interop$Java8$Anonymous$16781$$T$3x10$interop$Java8$Anonymous$16781$$U$3x10$lang$Long$2) null);
        
        //#line 401 "x10/interop/Java8.x10"
        return alloc$129640;
    }
    
    
    //#line 405 "x10/interop/Java8.x10"
    public static <$T, $U>java.util.function.ToDoubleBiFunction toJava__0$1x10$interop$Java8$$T$3x10$interop$Java8$$U$3x10$lang$Double$2(final x10.rtt.Type $T, final x10.rtt.Type $U, final x10.core.fun.Fun_0_2<$T,$U,x10.core.Double> xop) {
        
        //#line 406 "x10/interop/Java8.x10"
        final x10.interop.Java8.Anonymous$17062 alloc$129641 = ((x10.interop.Java8.Anonymous$17062)(new x10.interop.Java8.Anonymous$17062<$T, $U>((java.lang.System[]) null, $T, $U)));
        
        //#line 406 "x10/interop/Java8.x10"
        alloc$129641.x10$interop$Java8$Anonymous$17062$$init$S(xop, (x10.interop.Java8.Anonymous$17062.__0$1x10$interop$Java8$Anonymous$17062$$T$3x10$interop$Java8$Anonymous$17062$$U$3x10$lang$Double$2) null);
        
        //#line 406 "x10/interop/Java8.x10"
        return alloc$129641;
    }
    
    
    //#line 410 "x10/interop/Java8.x10"
    public static <$T, $U, $R>java.util.function.BiFunction toJava__0$1x10$interop$Java8$$T$3x10$interop$Java8$$U$3x10$interop$Java8$$R$2(final x10.rtt.Type $T, final x10.rtt.Type $U, final x10.rtt.Type $R, final x10.core.fun.Fun_0_2<$T,$U,$R> xop) {
        
        //#line 411 "x10/interop/Java8.x10"
        final x10.interop.Java8.Anonymous$17340 alloc$129642 = ((x10.interop.Java8.Anonymous$17340)(new x10.interop.Java8.Anonymous$17340<$T, $U, $R>((java.lang.System[]) null, $T, $U, $R)));
        
        //#line 411 "x10/interop/Java8.x10"
        alloc$129642.x10$interop$Java8$Anonymous$17340$$init$S(xop, (x10.interop.Java8.Anonymous$17340.__0$1x10$interop$Java8$Anonymous$17340$$T$3x10$interop$Java8$Anonymous$17340$$U$3x10$interop$Java8$Anonymous$17340$$R$2) null);
        
        //#line 411 "x10/interop/Java8.x10"
        return alloc$129642;
    }
    
    
    //#line 418 "x10/interop/Java8.x10"
    public static x10.core.fun.VoidFun_0_0 toX10(final java.lang.Runnable op) {
        
        //#line 419 "x10/interop/Java8.x10"
        final x10.core.fun.VoidFun_0_0 t$129730 = ((x10.core.fun.VoidFun_0_0)(new x10.interop.Java8.$Closure$143(op)));
        
        //#line 419 "x10/interop/Java8.x10"
        return t$129730;
    }
    
    
    //#line 422 "x10/interop/Java8.x10"
    public static java.lang.Runnable toJava(final x10.core.fun.VoidFun_0_0 xop) {
        
        //#line 423 "x10/interop/Java8.x10"
        final x10.interop.Java8.Anonymous$17695 alloc$129643 = ((x10.interop.Java8.Anonymous$17695)(new x10.interop.Java8.Anonymous$17695((java.lang.System[]) null)));
        
        //#line 423 "x10/interop/Java8.x10"
        alloc$129643.x10$interop$Java8$Anonymous$17695$$init$S(xop);
        
        //#line 423 "x10/interop/Java8.x10"
        return alloc$129643;
    }
    
    
    //#line 17 "x10/interop/Java8.x10"
    final public x10.interop.Java8 x10$interop$Java8$$this$x10$interop$Java8() {
        
        //#line 17 "x10/interop/Java8.x10"
        return x10.interop.Java8.this;
    }
    
    
    //#line 17 "x10/interop/Java8.x10"
    final public void __fieldInitializers_x10_interop_Java8() {
        
    }
    
    
    //#line 40 "x10/interop/Java8.x10"
    @x10.runtime.impl.java.X10Generated
    final public static class Anonymous$1414 extends x10.core.Ref implements java.util.function.IntBinaryOperator, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<Anonymous$1414> $RTT = 
            x10.rtt.NamedType.<Anonymous$1414> make("x10.interop.Java8.Anonymous$1414",
                                                    Anonymous$1414.class,
                                                    new x10.rtt.Type[] {
                                                        x10.rtt.Types.getRTT(java.util.function.IntBinaryOperator.class)
                                                    });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static x10.serialization.X10JavaSerializable $_deserialize_body(x10.interop.Java8.Anonymous$1414 $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            $_obj.xop = $deserializer.readObject();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.interop.Java8.Anonymous$1414 $_obj = new x10.interop.Java8.Anonymous$1414((java.lang.System[]) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            $serializer.write(this.xop);
            
        }
        
        // constructor just for allocation
        public Anonymous$1414(final java.lang.System[] $dummy) {
            
        }
        
        // synthetic type for parameter mangling
        public static final class __0$1x10$lang$Int$3x10$lang$Int$3x10$lang$Int$2 {}
        
    
        
        //#line 39 "x10/interop/Java8.x10"
        public x10.core.fun.Fun_0_2<x10.core.Int,x10.core.Int,x10.core.Int> xop;
        
        
        //#line 41 "x10/interop/Java8.x10"
        public int applyAsInt(final int left, final int right) {
            
            //#line 41 "x10/interop/Java8.x10"
            final x10.core.fun.Fun_0_2 t$129731 = x10.interop.Java8.Anonymous$1414.this.xop;
            
            //#line 41 "x10/interop/Java8.x10"
            final int t$129732 = x10.core.Int.$unbox(((x10.core.fun.Fun_0_2<x10.core.Int,x10.core.Int,x10.core.Int>)t$129731).$apply(x10.core.Int.$box(left), x10.rtt.Types.INT, x10.core.Int.$box(right), x10.rtt.Types.INT));
            
            //#line 41 "x10/interop/Java8.x10"
            return t$129732;
        }
        
        
        //#line 40 "x10/interop/Java8.x10"
        // creation method for java code (1-phase java constructor)
        public Anonymous$1414(final x10.core.fun.Fun_0_2<x10.core.Int,x10.core.Int,x10.core.Int> xop, __0$1x10$lang$Int$3x10$lang$Int$3x10$lang$Int$2 $dummy) {
            this((java.lang.System[]) null);
            x10$interop$Java8$Anonymous$1414$$init$S(xop, (x10.interop.Java8.Anonymous$1414.__0$1x10$lang$Int$3x10$lang$Int$3x10$lang$Int$2) null);
        }
        
        // constructor for non-virtual call
        final public x10.interop.Java8.Anonymous$1414 x10$interop$Java8$Anonymous$1414$$init$S(final x10.core.fun.Fun_0_2<x10.core.Int,x10.core.Int,x10.core.Int> xop, __0$1x10$lang$Int$3x10$lang$Int$3x10$lang$Int$2 $dummy) {
             {
                
                //#line 39 "x10/interop/Java8.x10"
                this.xop = xop;
            }
            return this;
        }
        
    }
    
    
    //#line 45 "x10/interop/Java8.x10"
    @x10.runtime.impl.java.X10Generated
    final public static class Anonymous$1669 extends x10.core.Ref implements java.util.function.LongBinaryOperator, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<Anonymous$1669> $RTT = 
            x10.rtt.NamedType.<Anonymous$1669> make("x10.interop.Java8.Anonymous$1669",
                                                    Anonymous$1669.class,
                                                    new x10.rtt.Type[] {
                                                        x10.rtt.Types.getRTT(java.util.function.LongBinaryOperator.class)
                                                    });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static x10.serialization.X10JavaSerializable $_deserialize_body(x10.interop.Java8.Anonymous$1669 $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            $_obj.xop = $deserializer.readObject();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.interop.Java8.Anonymous$1669 $_obj = new x10.interop.Java8.Anonymous$1669((java.lang.System[]) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            $serializer.write(this.xop);
            
        }
        
        // constructor just for allocation
        public Anonymous$1669(final java.lang.System[] $dummy) {
            
        }
        
        // synthetic type for parameter mangling
        public static final class __0$1x10$lang$Long$3x10$lang$Long$3x10$lang$Long$2 {}
        
    
        
        //#line 44 "x10/interop/Java8.x10"
        public x10.core.fun.Fun_0_2<x10.core.Long,x10.core.Long,x10.core.Long> xop;
        
        
        //#line 46 "x10/interop/Java8.x10"
        public long applyAsLong(final long left, final long right) {
            
            //#line 46 "x10/interop/Java8.x10"
            final x10.core.fun.Fun_0_2 t$129733 = x10.interop.Java8.Anonymous$1669.this.xop;
            
            //#line 46 "x10/interop/Java8.x10"
            final long t$129734 = x10.core.Long.$unbox(((x10.core.fun.Fun_0_2<x10.core.Long,x10.core.Long,x10.core.Long>)t$129733).$apply(x10.core.Long.$box(left), x10.rtt.Types.LONG, x10.core.Long.$box(right), x10.rtt.Types.LONG));
            
            //#line 46 "x10/interop/Java8.x10"
            return t$129734;
        }
        
        
        //#line 45 "x10/interop/Java8.x10"
        // creation method for java code (1-phase java constructor)
        public Anonymous$1669(final x10.core.fun.Fun_0_2<x10.core.Long,x10.core.Long,x10.core.Long> xop, __0$1x10$lang$Long$3x10$lang$Long$3x10$lang$Long$2 $dummy) {
            this((java.lang.System[]) null);
            x10$interop$Java8$Anonymous$1669$$init$S(xop, (x10.interop.Java8.Anonymous$1669.__0$1x10$lang$Long$3x10$lang$Long$3x10$lang$Long$2) null);
        }
        
        // constructor for non-virtual call
        final public x10.interop.Java8.Anonymous$1669 x10$interop$Java8$Anonymous$1669$$init$S(final x10.core.fun.Fun_0_2<x10.core.Long,x10.core.Long,x10.core.Long> xop, __0$1x10$lang$Long$3x10$lang$Long$3x10$lang$Long$2 $dummy) {
             {
                
                //#line 44 "x10/interop/Java8.x10"
                this.xop = xop;
            }
            return this;
        }
        
    }
    
    
    //#line 50 "x10/interop/Java8.x10"
    @x10.runtime.impl.java.X10Generated
    final public static class Anonymous$1937 extends x10.core.Ref implements java.util.function.DoubleBinaryOperator, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<Anonymous$1937> $RTT = 
            x10.rtt.NamedType.<Anonymous$1937> make("x10.interop.Java8.Anonymous$1937",
                                                    Anonymous$1937.class,
                                                    new x10.rtt.Type[] {
                                                        x10.rtt.Types.getRTT(java.util.function.DoubleBinaryOperator.class)
                                                    });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static x10.serialization.X10JavaSerializable $_deserialize_body(x10.interop.Java8.Anonymous$1937 $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            $_obj.xop = $deserializer.readObject();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.interop.Java8.Anonymous$1937 $_obj = new x10.interop.Java8.Anonymous$1937((java.lang.System[]) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            $serializer.write(this.xop);
            
        }
        
        // constructor just for allocation
        public Anonymous$1937(final java.lang.System[] $dummy) {
            
        }
        
        // synthetic type for parameter mangling
        public static final class __0$1x10$lang$Double$3x10$lang$Double$3x10$lang$Double$2 {}
        
    
        
        //#line 49 "x10/interop/Java8.x10"
        public x10.core.fun.Fun_0_2<x10.core.Double,x10.core.Double,x10.core.Double> xop;
        
        
        //#line 51 "x10/interop/Java8.x10"
        public double applyAsDouble(final double left, final double right) {
            
            //#line 51 "x10/interop/Java8.x10"
            final x10.core.fun.Fun_0_2 t$129735 = x10.interop.Java8.Anonymous$1937.this.xop;
            
            //#line 51 "x10/interop/Java8.x10"
            final double t$129736 = x10.core.Double.$unbox(((x10.core.fun.Fun_0_2<x10.core.Double,x10.core.Double,x10.core.Double>)t$129735).$apply(x10.core.Double.$box(left), x10.rtt.Types.DOUBLE, x10.core.Double.$box(right), x10.rtt.Types.DOUBLE));
            
            //#line 51 "x10/interop/Java8.x10"
            return t$129736;
        }
        
        
        //#line 50 "x10/interop/Java8.x10"
        // creation method for java code (1-phase java constructor)
        public Anonymous$1937(final x10.core.fun.Fun_0_2<x10.core.Double,x10.core.Double,x10.core.Double> xop, __0$1x10$lang$Double$3x10$lang$Double$3x10$lang$Double$2 $dummy) {
            this((java.lang.System[]) null);
            x10$interop$Java8$Anonymous$1937$$init$S(xop, (x10.interop.Java8.Anonymous$1937.__0$1x10$lang$Double$3x10$lang$Double$3x10$lang$Double$2) null);
        }
        
        // constructor for non-virtual call
        final public x10.interop.Java8.Anonymous$1937 x10$interop$Java8$Anonymous$1937$$init$S(final x10.core.fun.Fun_0_2<x10.core.Double,x10.core.Double,x10.core.Double> xop, __0$1x10$lang$Double$3x10$lang$Double$3x10$lang$Double$2 $dummy) {
             {
                
                //#line 49 "x10/interop/Java8.x10"
                this.xop = xop;
            }
            return this;
        }
        
    }
    
    
    //#line 55 "x10/interop/Java8.x10"
    @x10.runtime.impl.java.X10Generated
    final public static class Anonymous$2204<$T> extends x10.core.Ref implements java.util.function.BinaryOperator, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<Anonymous$2204> $RTT = 
            x10.rtt.NamedType.<Anonymous$2204> make("x10.interop.Java8.Anonymous$2204",
                                                    Anonymous$2204.class,
                                                    1,
                                                    new x10.rtt.Type[] {
                                                        x10.rtt.Types.getRTT(java.util.function.BinaryOperator.class)
                                                    });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { if (i == 0) return $T; return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static <$T> x10.serialization.X10JavaSerializable $_deserialize_body(x10.interop.Java8.Anonymous$2204<$T> $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            $_obj.$T = (x10.rtt.Type) $deserializer.readObject();
            $_obj.xop = $deserializer.readObject();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.interop.Java8.Anonymous$2204 $_obj = new x10.interop.Java8.Anonymous$2204((java.lang.System[]) null, (x10.rtt.Type) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            $serializer.write(this.$T);
            $serializer.write(this.xop);
            
        }
        
        // constructor just for allocation
        public Anonymous$2204(final java.lang.System[] $dummy, final x10.rtt.Type $T) {
            x10.interop.Java8.Anonymous$2204.$initParams(this, $T);
            
        }
        
        private x10.rtt.Type $T;
        
        // initializer of type parameters
        public static void $initParams(final Anonymous$2204 $this, final x10.rtt.Type $T) {
            $this.$T = $T;
            
        }
        // synthetic type for parameter mangling
        public static final class __0$1x10$interop$Java8$Anonymous$2204$$T$3x10$interop$Java8$Anonymous$2204$$T$3x10$interop$Java8$Anonymous$2204$$T$2 {}
        
    
        
        //#line 54 "x10/interop/Java8.x10"
        public x10.core.fun.Fun_0_2<$T,$T,$T> xop;
        
        
        //#line 56 "x10/interop/Java8.x10"
        public java.lang.Object apply(final java.lang.Object left, final java.lang.Object right) {
            
            //#line 56 "x10/interop/Java8.x10"
            final x10.core.fun.Fun_0_2 t$129737 = x10.interop.Java8.Anonymous$2204.this.xop;
            
            //#line 56 "x10/interop/Java8.x10"
            final $T t$129738 = (($T)(x10.rtt.Types.<$T> cast(left,$T)));
            
            //#line 56 "x10/interop/Java8.x10"
            final $T t$129739 = (($T)(x10.rtt.Types.<$T> cast(right,$T)));
            
            //#line 56 "x10/interop/Java8.x10"
            final $T t$129740 = (($T)((($T)
                                        ((x10.core.fun.Fun_0_2<$T,$T,$T>)t$129737).$apply(t$129738, $T, t$129739, $T))));
            
            //#line 56 "x10/interop/Java8.x10"
            return ((java.lang.Object)
                     t$129740);
        }
        
        
        //#line 55 "x10/interop/Java8.x10"
        // creation method for java code (1-phase java constructor)
        public Anonymous$2204(final x10.rtt.Type $T, final x10.core.fun.Fun_0_2<$T,$T,$T> xop, __0$1x10$interop$Java8$Anonymous$2204$$T$3x10$interop$Java8$Anonymous$2204$$T$3x10$interop$Java8$Anonymous$2204$$T$2 $dummy) {
            this((java.lang.System[]) null, $T);
            x10$interop$Java8$Anonymous$2204$$init$S(xop, (x10.interop.Java8.Anonymous$2204.__0$1x10$interop$Java8$Anonymous$2204$$T$3x10$interop$Java8$Anonymous$2204$$T$3x10$interop$Java8$Anonymous$2204$$T$2) null);
        }
        
        // constructor for non-virtual call
        final public x10.interop.Java8.Anonymous$2204<$T> x10$interop$Java8$Anonymous$2204$$init$S(final x10.core.fun.Fun_0_2<$T,$T,$T> xop, __0$1x10$interop$Java8$Anonymous$2204$$T$3x10$interop$Java8$Anonymous$2204$$T$3x10$interop$Java8$Anonymous$2204$$T$2 $dummy) {
             {
                
                //#line 54 "x10/interop/Java8.x10"
                ((x10.interop.Java8.Anonymous$2204)this).xop = xop;
            }
            return this;
        }
        
    }
    
    
    //#line 76 "x10/interop/Java8.x10"
    @x10.runtime.impl.java.X10Generated
    final public static class Anonymous$3083 extends x10.core.Ref implements java.util.function.IntUnaryOperator, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<Anonymous$3083> $RTT = 
            x10.rtt.NamedType.<Anonymous$3083> make("x10.interop.Java8.Anonymous$3083",
                                                    Anonymous$3083.class,
                                                    new x10.rtt.Type[] {
                                                        x10.rtt.Types.getRTT(java.util.function.IntUnaryOperator.class)
                                                    });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static x10.serialization.X10JavaSerializable $_deserialize_body(x10.interop.Java8.Anonymous$3083 $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            $_obj.xop = $deserializer.readObject();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.interop.Java8.Anonymous$3083 $_obj = new x10.interop.Java8.Anonymous$3083((java.lang.System[]) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            $serializer.write(this.xop);
            
        }
        
        // constructor just for allocation
        public Anonymous$3083(final java.lang.System[] $dummy) {
            
        }
        
        // synthetic type for parameter mangling
        public static final class __0$1x10$lang$Int$3x10$lang$Int$2 {}
        
    
        
        //#line 75 "x10/interop/Java8.x10"
        public x10.core.fun.Fun_0_1<x10.core.Int,x10.core.Int> xop;
        
        
        //#line 77 "x10/interop/Java8.x10"
        public int applyAsInt(final int operand) {
            
            //#line 77 "x10/interop/Java8.x10"
            final x10.core.fun.Fun_0_1 t$129741 = x10.interop.Java8.Anonymous$3083.this.xop;
            
            //#line 77 "x10/interop/Java8.x10"
            final int t$129742 = x10.core.Int.$unbox(((x10.core.fun.Fun_0_1<x10.core.Int,x10.core.Int>)t$129741).$apply(x10.core.Int.$box(operand), x10.rtt.Types.INT));
            
            //#line 77 "x10/interop/Java8.x10"
            return t$129742;
        }
        
        
        //#line 76 "x10/interop/Java8.x10"
        // creation method for java code (1-phase java constructor)
        public Anonymous$3083(final x10.core.fun.Fun_0_1<x10.core.Int,x10.core.Int> xop, __0$1x10$lang$Int$3x10$lang$Int$2 $dummy) {
            this((java.lang.System[]) null);
            x10$interop$Java8$Anonymous$3083$$init$S(xop, (x10.interop.Java8.Anonymous$3083.__0$1x10$lang$Int$3x10$lang$Int$2) null);
        }
        
        // constructor for non-virtual call
        final public x10.interop.Java8.Anonymous$3083 x10$interop$Java8$Anonymous$3083$$init$S(final x10.core.fun.Fun_0_1<x10.core.Int,x10.core.Int> xop, __0$1x10$lang$Int$3x10$lang$Int$2 $dummy) {
             {
                
                //#line 75 "x10/interop/Java8.x10"
                this.xop = xop;
            }
            return this;
        }
        
    }
    
    
    //#line 81 "x10/interop/Java8.x10"
    @x10.runtime.impl.java.X10Generated
    final public static class Anonymous$3321 extends x10.core.Ref implements java.util.function.LongUnaryOperator, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<Anonymous$3321> $RTT = 
            x10.rtt.NamedType.<Anonymous$3321> make("x10.interop.Java8.Anonymous$3321",
                                                    Anonymous$3321.class,
                                                    new x10.rtt.Type[] {
                                                        x10.rtt.Types.getRTT(java.util.function.LongUnaryOperator.class)
                                                    });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static x10.serialization.X10JavaSerializable $_deserialize_body(x10.interop.Java8.Anonymous$3321 $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            $_obj.xop = $deserializer.readObject();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.interop.Java8.Anonymous$3321 $_obj = new x10.interop.Java8.Anonymous$3321((java.lang.System[]) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            $serializer.write(this.xop);
            
        }
        
        // constructor just for allocation
        public Anonymous$3321(final java.lang.System[] $dummy) {
            
        }
        
        // synthetic type for parameter mangling
        public static final class __0$1x10$lang$Long$3x10$lang$Long$2 {}
        
    
        
        //#line 80 "x10/interop/Java8.x10"
        public x10.core.fun.Fun_0_1<x10.core.Long,x10.core.Long> xop;
        
        
        //#line 82 "x10/interop/Java8.x10"
        public long applyAsLong(final long operand) {
            
            //#line 82 "x10/interop/Java8.x10"
            final x10.core.fun.Fun_0_1 t$129743 = x10.interop.Java8.Anonymous$3321.this.xop;
            
            //#line 82 "x10/interop/Java8.x10"
            final long t$129744 = x10.core.Long.$unbox(((x10.core.fun.Fun_0_1<x10.core.Long,x10.core.Long>)t$129743).$apply(x10.core.Long.$box(operand), x10.rtt.Types.LONG));
            
            //#line 82 "x10/interop/Java8.x10"
            return t$129744;
        }
        
        
        //#line 81 "x10/interop/Java8.x10"
        // creation method for java code (1-phase java constructor)
        public Anonymous$3321(final x10.core.fun.Fun_0_1<x10.core.Long,x10.core.Long> xop, __0$1x10$lang$Long$3x10$lang$Long$2 $dummy) {
            this((java.lang.System[]) null);
            x10$interop$Java8$Anonymous$3321$$init$S(xop, (x10.interop.Java8.Anonymous$3321.__0$1x10$lang$Long$3x10$lang$Long$2) null);
        }
        
        // constructor for non-virtual call
        final public x10.interop.Java8.Anonymous$3321 x10$interop$Java8$Anonymous$3321$$init$S(final x10.core.fun.Fun_0_1<x10.core.Long,x10.core.Long> xop, __0$1x10$lang$Long$3x10$lang$Long$2 $dummy) {
             {
                
                //#line 80 "x10/interop/Java8.x10"
                this.xop = xop;
            }
            return this;
        }
        
    }
    
    
    //#line 86 "x10/interop/Java8.x10"
    @x10.runtime.impl.java.X10Generated
    final public static class Anonymous$3569 extends x10.core.Ref implements java.util.function.DoubleUnaryOperator, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<Anonymous$3569> $RTT = 
            x10.rtt.NamedType.<Anonymous$3569> make("x10.interop.Java8.Anonymous$3569",
                                                    Anonymous$3569.class,
                                                    new x10.rtt.Type[] {
                                                        x10.rtt.Types.getRTT(java.util.function.DoubleUnaryOperator.class)
                                                    });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static x10.serialization.X10JavaSerializable $_deserialize_body(x10.interop.Java8.Anonymous$3569 $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            $_obj.xop = $deserializer.readObject();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.interop.Java8.Anonymous$3569 $_obj = new x10.interop.Java8.Anonymous$3569((java.lang.System[]) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            $serializer.write(this.xop);
            
        }
        
        // constructor just for allocation
        public Anonymous$3569(final java.lang.System[] $dummy) {
            
        }
        
        // synthetic type for parameter mangling
        public static final class __0$1x10$lang$Double$3x10$lang$Double$2 {}
        
    
        
        //#line 85 "x10/interop/Java8.x10"
        public x10.core.fun.Fun_0_1<x10.core.Double,x10.core.Double> xop;
        
        
        //#line 87 "x10/interop/Java8.x10"
        public double applyAsDouble(final double operand) {
            
            //#line 87 "x10/interop/Java8.x10"
            final x10.core.fun.Fun_0_1 t$129745 = x10.interop.Java8.Anonymous$3569.this.xop;
            
            //#line 87 "x10/interop/Java8.x10"
            final double t$129746 = x10.core.Double.$unbox(((x10.core.fun.Fun_0_1<x10.core.Double,x10.core.Double>)t$129745).$apply(x10.core.Double.$box(operand), x10.rtt.Types.DOUBLE));
            
            //#line 87 "x10/interop/Java8.x10"
            return t$129746;
        }
        
        
        //#line 86 "x10/interop/Java8.x10"
        // creation method for java code (1-phase java constructor)
        public Anonymous$3569(final x10.core.fun.Fun_0_1<x10.core.Double,x10.core.Double> xop, __0$1x10$lang$Double$3x10$lang$Double$2 $dummy) {
            this((java.lang.System[]) null);
            x10$interop$Java8$Anonymous$3569$$init$S(xop, (x10.interop.Java8.Anonymous$3569.__0$1x10$lang$Double$3x10$lang$Double$2) null);
        }
        
        // constructor for non-virtual call
        final public x10.interop.Java8.Anonymous$3569 x10$interop$Java8$Anonymous$3569$$init$S(final x10.core.fun.Fun_0_1<x10.core.Double,x10.core.Double> xop, __0$1x10$lang$Double$3x10$lang$Double$2 $dummy) {
             {
                
                //#line 85 "x10/interop/Java8.x10"
                this.xop = xop;
            }
            return this;
        }
        
    }
    
    
    //#line 91 "x10/interop/Java8.x10"
    @x10.runtime.impl.java.X10Generated
    final public static class Anonymous$3819<$T> extends x10.core.Ref implements java.util.function.UnaryOperator, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<Anonymous$3819> $RTT = 
            x10.rtt.NamedType.<Anonymous$3819> make("x10.interop.Java8.Anonymous$3819",
                                                    Anonymous$3819.class,
                                                    1,
                                                    new x10.rtt.Type[] {
                                                        x10.rtt.Types.getRTT(java.util.function.UnaryOperator.class)
                                                    });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { if (i == 0) return $T; return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static <$T> x10.serialization.X10JavaSerializable $_deserialize_body(x10.interop.Java8.Anonymous$3819<$T> $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            $_obj.$T = (x10.rtt.Type) $deserializer.readObject();
            $_obj.xop = $deserializer.readObject();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.interop.Java8.Anonymous$3819 $_obj = new x10.interop.Java8.Anonymous$3819((java.lang.System[]) null, (x10.rtt.Type) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            $serializer.write(this.$T);
            $serializer.write(this.xop);
            
        }
        
        // constructor just for allocation
        public Anonymous$3819(final java.lang.System[] $dummy, final x10.rtt.Type $T) {
            x10.interop.Java8.Anonymous$3819.$initParams(this, $T);
            
        }
        
        private x10.rtt.Type $T;
        
        // initializer of type parameters
        public static void $initParams(final Anonymous$3819 $this, final x10.rtt.Type $T) {
            $this.$T = $T;
            
        }
        // synthetic type for parameter mangling
        public static final class __0$1x10$interop$Java8$Anonymous$3819$$T$3x10$interop$Java8$Anonymous$3819$$T$2 {}
        
    
        
        //#line 90 "x10/interop/Java8.x10"
        public x10.core.fun.Fun_0_1<$T,$T> xop;
        
        
        //#line 92 "x10/interop/Java8.x10"
        public java.lang.Object apply(final java.lang.Object operand) {
            
            //#line 92 "x10/interop/Java8.x10"
            final x10.core.fun.Fun_0_1 t$129747 = x10.interop.Java8.Anonymous$3819.this.xop;
            
            //#line 92 "x10/interop/Java8.x10"
            final $T t$129748 = (($T)(x10.rtt.Types.<$T> cast(operand,$T)));
            
            //#line 92 "x10/interop/Java8.x10"
            final $T t$129749 = (($T)((($T)
                                        ((x10.core.fun.Fun_0_1<$T,$T>)t$129747).$apply(t$129748, $T))));
            
            //#line 92 "x10/interop/Java8.x10"
            return ((java.lang.Object)
                     t$129749);
        }
        
        
        //#line 91 "x10/interop/Java8.x10"
        // creation method for java code (1-phase java constructor)
        public Anonymous$3819(final x10.rtt.Type $T, final x10.core.fun.Fun_0_1<$T,$T> xop, __0$1x10$interop$Java8$Anonymous$3819$$T$3x10$interop$Java8$Anonymous$3819$$T$2 $dummy) {
            this((java.lang.System[]) null, $T);
            x10$interop$Java8$Anonymous$3819$$init$S(xop, (x10.interop.Java8.Anonymous$3819.__0$1x10$interop$Java8$Anonymous$3819$$T$3x10$interop$Java8$Anonymous$3819$$T$2) null);
        }
        
        // constructor for non-virtual call
        final public x10.interop.Java8.Anonymous$3819<$T> x10$interop$Java8$Anonymous$3819$$init$S(final x10.core.fun.Fun_0_1<$T,$T> xop, __0$1x10$interop$Java8$Anonymous$3819$$T$3x10$interop$Java8$Anonymous$3819$$T$2 $dummy) {
             {
                
                //#line 90 "x10/interop/Java8.x10"
                ((x10.interop.Java8.Anonymous$3819)this).xop = xop;
            }
            return this;
        }
        
    }
    
    
    //#line 112 "x10/interop/Java8.x10"
    @x10.runtime.impl.java.X10Generated
    final public static class Anonymous$4627 extends x10.core.Ref implements java.util.function.IntPredicate, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<Anonymous$4627> $RTT = 
            x10.rtt.NamedType.<Anonymous$4627> make("x10.interop.Java8.Anonymous$4627",
                                                    Anonymous$4627.class,
                                                    new x10.rtt.Type[] {
                                                        x10.rtt.Types.getRTT(java.util.function.IntPredicate.class)
                                                    });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static x10.serialization.X10JavaSerializable $_deserialize_body(x10.interop.Java8.Anonymous$4627 $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            $_obj.xop = $deserializer.readObject();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.interop.Java8.Anonymous$4627 $_obj = new x10.interop.Java8.Anonymous$4627((java.lang.System[]) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            $serializer.write(this.xop);
            
        }
        
        // constructor just for allocation
        public Anonymous$4627(final java.lang.System[] $dummy) {
            
        }
        
        // synthetic type for parameter mangling
        public static final class __0$1x10$lang$Int$3x10$lang$Boolean$2 {}
        
    
        
        //#line 111 "x10/interop/Java8.x10"
        public x10.core.fun.Fun_0_1<x10.core.Int,x10.core.Boolean> xop;
        
        
        //#line 113 "x10/interop/Java8.x10"
        public boolean test(final int value) {
            
            //#line 113 "x10/interop/Java8.x10"
            final x10.core.fun.Fun_0_1 t$129750 = x10.interop.Java8.Anonymous$4627.this.xop;
            
            //#line 113 "x10/interop/Java8.x10"
            final boolean t$129751 = x10.core.Boolean.$unbox(((x10.core.fun.Fun_0_1<x10.core.Int,x10.core.Boolean>)t$129750).$apply(x10.core.Int.$box(value), x10.rtt.Types.INT));
            
            //#line 113 "x10/interop/Java8.x10"
            return t$129751;
        }
        
        
        //#line 112 "x10/interop/Java8.x10"
        // creation method for java code (1-phase java constructor)
        public Anonymous$4627(final x10.core.fun.Fun_0_1<x10.core.Int,x10.core.Boolean> xop, __0$1x10$lang$Int$3x10$lang$Boolean$2 $dummy) {
            this((java.lang.System[]) null);
            x10$interop$Java8$Anonymous$4627$$init$S(xop, (x10.interop.Java8.Anonymous$4627.__0$1x10$lang$Int$3x10$lang$Boolean$2) null);
        }
        
        // constructor for non-virtual call
        final public x10.interop.Java8.Anonymous$4627 x10$interop$Java8$Anonymous$4627$$init$S(final x10.core.fun.Fun_0_1<x10.core.Int,x10.core.Boolean> xop, __0$1x10$lang$Int$3x10$lang$Boolean$2 $dummy) {
             {
                
                //#line 111 "x10/interop/Java8.x10"
                this.xop = xop;
            }
            return this;
        }
        
    }
    
    
    //#line 117 "x10/interop/Java8.x10"
    @x10.runtime.impl.java.X10Generated
    final public static class Anonymous$4854 extends x10.core.Ref implements java.util.function.LongPredicate, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<Anonymous$4854> $RTT = 
            x10.rtt.NamedType.<Anonymous$4854> make("x10.interop.Java8.Anonymous$4854",
                                                    Anonymous$4854.class,
                                                    new x10.rtt.Type[] {
                                                        x10.rtt.Types.getRTT(java.util.function.LongPredicate.class)
                                                    });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static x10.serialization.X10JavaSerializable $_deserialize_body(x10.interop.Java8.Anonymous$4854 $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            $_obj.xop = $deserializer.readObject();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.interop.Java8.Anonymous$4854 $_obj = new x10.interop.Java8.Anonymous$4854((java.lang.System[]) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            $serializer.write(this.xop);
            
        }
        
        // constructor just for allocation
        public Anonymous$4854(final java.lang.System[] $dummy) {
            
        }
        
        // synthetic type for parameter mangling
        public static final class __0$1x10$lang$Long$3x10$lang$Boolean$2 {}
        
    
        
        //#line 116 "x10/interop/Java8.x10"
        public x10.core.fun.Fun_0_1<x10.core.Long,x10.core.Boolean> xop;
        
        
        //#line 118 "x10/interop/Java8.x10"
        public boolean test(final long value) {
            
            //#line 118 "x10/interop/Java8.x10"
            final x10.core.fun.Fun_0_1 t$129752 = x10.interop.Java8.Anonymous$4854.this.xop;
            
            //#line 118 "x10/interop/Java8.x10"
            final boolean t$129753 = x10.core.Boolean.$unbox(((x10.core.fun.Fun_0_1<x10.core.Long,x10.core.Boolean>)t$129752).$apply(x10.core.Long.$box(value), x10.rtt.Types.LONG));
            
            //#line 118 "x10/interop/Java8.x10"
            return t$129753;
        }
        
        
        //#line 117 "x10/interop/Java8.x10"
        // creation method for java code (1-phase java constructor)
        public Anonymous$4854(final x10.core.fun.Fun_0_1<x10.core.Long,x10.core.Boolean> xop, __0$1x10$lang$Long$3x10$lang$Boolean$2 $dummy) {
            this((java.lang.System[]) null);
            x10$interop$Java8$Anonymous$4854$$init$S(xop, (x10.interop.Java8.Anonymous$4854.__0$1x10$lang$Long$3x10$lang$Boolean$2) null);
        }
        
        // constructor for non-virtual call
        final public x10.interop.Java8.Anonymous$4854 x10$interop$Java8$Anonymous$4854$$init$S(final x10.core.fun.Fun_0_1<x10.core.Long,x10.core.Boolean> xop, __0$1x10$lang$Long$3x10$lang$Boolean$2 $dummy) {
             {
                
                //#line 116 "x10/interop/Java8.x10"
                this.xop = xop;
            }
            return this;
        }
        
    }
    
    
    //#line 122 "x10/interop/Java8.x10"
    @x10.runtime.impl.java.X10Generated
    final public static class Anonymous$5087 extends x10.core.Ref implements java.util.function.DoublePredicate, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<Anonymous$5087> $RTT = 
            x10.rtt.NamedType.<Anonymous$5087> make("x10.interop.Java8.Anonymous$5087",
                                                    Anonymous$5087.class,
                                                    new x10.rtt.Type[] {
                                                        x10.rtt.Types.getRTT(java.util.function.DoublePredicate.class)
                                                    });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static x10.serialization.X10JavaSerializable $_deserialize_body(x10.interop.Java8.Anonymous$5087 $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            $_obj.xop = $deserializer.readObject();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.interop.Java8.Anonymous$5087 $_obj = new x10.interop.Java8.Anonymous$5087((java.lang.System[]) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            $serializer.write(this.xop);
            
        }
        
        // constructor just for allocation
        public Anonymous$5087(final java.lang.System[] $dummy) {
            
        }
        
        // synthetic type for parameter mangling
        public static final class __0$1x10$lang$Double$3x10$lang$Boolean$2 {}
        
    
        
        //#line 121 "x10/interop/Java8.x10"
        public x10.core.fun.Fun_0_1<x10.core.Double,x10.core.Boolean> xop;
        
        
        //#line 123 "x10/interop/Java8.x10"
        public boolean test(final double value) {
            
            //#line 123 "x10/interop/Java8.x10"
            final x10.core.fun.Fun_0_1 t$129754 = x10.interop.Java8.Anonymous$5087.this.xop;
            
            //#line 123 "x10/interop/Java8.x10"
            final boolean t$129755 = x10.core.Boolean.$unbox(((x10.core.fun.Fun_0_1<x10.core.Double,x10.core.Boolean>)t$129754).$apply(x10.core.Double.$box(value), x10.rtt.Types.DOUBLE));
            
            //#line 123 "x10/interop/Java8.x10"
            return t$129755;
        }
        
        
        //#line 122 "x10/interop/Java8.x10"
        // creation method for java code (1-phase java constructor)
        public Anonymous$5087(final x10.core.fun.Fun_0_1<x10.core.Double,x10.core.Boolean> xop, __0$1x10$lang$Double$3x10$lang$Boolean$2 $dummy) {
            this((java.lang.System[]) null);
            x10$interop$Java8$Anonymous$5087$$init$S(xop, (x10.interop.Java8.Anonymous$5087.__0$1x10$lang$Double$3x10$lang$Boolean$2) null);
        }
        
        // constructor for non-virtual call
        final public x10.interop.Java8.Anonymous$5087 x10$interop$Java8$Anonymous$5087$$init$S(final x10.core.fun.Fun_0_1<x10.core.Double,x10.core.Boolean> xop, __0$1x10$lang$Double$3x10$lang$Boolean$2 $dummy) {
             {
                
                //#line 121 "x10/interop/Java8.x10"
                this.xop = xop;
            }
            return this;
        }
        
    }
    
    
    //#line 127 "x10/interop/Java8.x10"
    @x10.runtime.impl.java.X10Generated
    final public static class Anonymous$5323<$T> extends x10.core.Ref implements java.util.function.Predicate, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<Anonymous$5323> $RTT = 
            x10.rtt.NamedType.<Anonymous$5323> make("x10.interop.Java8.Anonymous$5323",
                                                    Anonymous$5323.class,
                                                    1,
                                                    new x10.rtt.Type[] {
                                                        x10.rtt.Types.getRTT(java.util.function.Predicate.class)
                                                    });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { if (i == 0) return $T; return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static <$T> x10.serialization.X10JavaSerializable $_deserialize_body(x10.interop.Java8.Anonymous$5323<$T> $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            $_obj.$T = (x10.rtt.Type) $deserializer.readObject();
            $_obj.xop = $deserializer.readObject();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.interop.Java8.Anonymous$5323 $_obj = new x10.interop.Java8.Anonymous$5323((java.lang.System[]) null, (x10.rtt.Type) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            $serializer.write(this.$T);
            $serializer.write(this.xop);
            
        }
        
        // constructor just for allocation
        public Anonymous$5323(final java.lang.System[] $dummy, final x10.rtt.Type $T) {
            x10.interop.Java8.Anonymous$5323.$initParams(this, $T);
            
        }
        
        private x10.rtt.Type $T;
        
        // initializer of type parameters
        public static void $initParams(final Anonymous$5323 $this, final x10.rtt.Type $T) {
            $this.$T = $T;
            
        }
        // synthetic type for parameter mangling
        public static final class __0$1x10$interop$Java8$Anonymous$5323$$T$3x10$lang$Boolean$2 {}
        
    
        
        //#line 126 "x10/interop/Java8.x10"
        public x10.core.fun.Fun_0_1<$T,x10.core.Boolean> xop;
        
        
        //#line 128 "x10/interop/Java8.x10"
        public boolean test(final java.lang.Object value) {
            
            //#line 128 "x10/interop/Java8.x10"
            final x10.core.fun.Fun_0_1 t$129756 = x10.interop.Java8.Anonymous$5323.this.xop;
            
            //#line 128 "x10/interop/Java8.x10"
            final $T t$129757 = (($T)(x10.rtt.Types.<$T> cast(value,$T)));
            
            //#line 128 "x10/interop/Java8.x10"
            final boolean t$129758 = x10.core.Boolean.$unbox(((x10.core.fun.Fun_0_1<$T,x10.core.Boolean>)t$129756).$apply(t$129757, $T));
            
            //#line 128 "x10/interop/Java8.x10"
            return t$129758;
        }
        
        
        //#line 127 "x10/interop/Java8.x10"
        // creation method for java code (1-phase java constructor)
        public Anonymous$5323(final x10.rtt.Type $T, final x10.core.fun.Fun_0_1<$T,x10.core.Boolean> xop, __0$1x10$interop$Java8$Anonymous$5323$$T$3x10$lang$Boolean$2 $dummy) {
            this((java.lang.System[]) null, $T);
            x10$interop$Java8$Anonymous$5323$$init$S(xop, (x10.interop.Java8.Anonymous$5323.__0$1x10$interop$Java8$Anonymous$5323$$T$3x10$lang$Boolean$2) null);
        }
        
        // constructor for non-virtual call
        final public x10.interop.Java8.Anonymous$5323<$T> x10$interop$Java8$Anonymous$5323$$init$S(final x10.core.fun.Fun_0_1<$T,x10.core.Boolean> xop, __0$1x10$interop$Java8$Anonymous$5323$$T$3x10$lang$Boolean$2 $dummy) {
             {
                
                //#line 126 "x10/interop/Java8.x10"
                ((x10.interop.Java8.Anonymous$5323)this).xop = xop;
            }
            return this;
        }
        
    }
    
    
    //#line 139 "x10/interop/Java8.x10"
    @x10.runtime.impl.java.X10Generated
    final public static class Anonymous$5737<$T, $U> extends x10.core.Ref implements java.util.function.BiPredicate, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<Anonymous$5737> $RTT = 
            x10.rtt.NamedType.<Anonymous$5737> make("x10.interop.Java8.Anonymous$5737",
                                                    Anonymous$5737.class,
                                                    2,
                                                    new x10.rtt.Type[] {
                                                        x10.rtt.Types.getRTT(java.util.function.BiPredicate.class)
                                                    });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { if (i == 0) return $T; if (i == 1) return $U; return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static <$T, $U> x10.serialization.X10JavaSerializable $_deserialize_body(x10.interop.Java8.Anonymous$5737<$T, $U> $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            $_obj.$T = (x10.rtt.Type) $deserializer.readObject();
            $_obj.$U = (x10.rtt.Type) $deserializer.readObject();
            $_obj.xop = $deserializer.readObject();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.interop.Java8.Anonymous$5737 $_obj = new x10.interop.Java8.Anonymous$5737((java.lang.System[]) null, (x10.rtt.Type) null, (x10.rtt.Type) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            $serializer.write(this.$T);
            $serializer.write(this.$U);
            $serializer.write(this.xop);
            
        }
        
        // constructor just for allocation
        public Anonymous$5737(final java.lang.System[] $dummy, final x10.rtt.Type $T, final x10.rtt.Type $U) {
            x10.interop.Java8.Anonymous$5737.$initParams(this, $T, $U);
            
        }
        
        private x10.rtt.Type $T;
        private x10.rtt.Type $U;
        
        // initializer of type parameters
        public static void $initParams(final Anonymous$5737 $this, final x10.rtt.Type $T, final x10.rtt.Type $U) {
            $this.$T = $T;
            $this.$U = $U;
            
        }
        // synthetic type for parameter mangling
        public static final class __0$1x10$interop$Java8$Anonymous$5737$$T$3x10$interop$Java8$Anonymous$5737$$U$3x10$lang$Boolean$2 {}
        
    
        
        //#line 138 "x10/interop/Java8.x10"
        public x10.core.fun.Fun_0_2<$T,$U,x10.core.Boolean> xop;
        
        
        //#line 140 "x10/interop/Java8.x10"
        public boolean test(final java.lang.Object t, final java.lang.Object u) {
            
            //#line 140 "x10/interop/Java8.x10"
            final x10.core.fun.Fun_0_2 t$129759 = x10.interop.Java8.Anonymous$5737.this.xop;
            
            //#line 140 "x10/interop/Java8.x10"
            final $T t$129760 = (($T)(x10.rtt.Types.<$T> cast(t,$T)));
            
            //#line 140 "x10/interop/Java8.x10"
            final $U t$129761 = (($U)(x10.rtt.Types.<$U> cast(u,$U)));
            
            //#line 140 "x10/interop/Java8.x10"
            final boolean t$129762 = x10.core.Boolean.$unbox(((x10.core.fun.Fun_0_2<$T,$U,x10.core.Boolean>)t$129759).$apply(t$129760, $T, t$129761, $U));
            
            //#line 140 "x10/interop/Java8.x10"
            return t$129762;
        }
        
        
        //#line 139 "x10/interop/Java8.x10"
        // creation method for java code (1-phase java constructor)
        public Anonymous$5737(final x10.rtt.Type $T, final x10.rtt.Type $U, final x10.core.fun.Fun_0_2<$T,$U,x10.core.Boolean> xop, __0$1x10$interop$Java8$Anonymous$5737$$T$3x10$interop$Java8$Anonymous$5737$$U$3x10$lang$Boolean$2 $dummy) {
            this((java.lang.System[]) null, $T, $U);
            x10$interop$Java8$Anonymous$5737$$init$S(xop, (x10.interop.Java8.Anonymous$5737.__0$1x10$interop$Java8$Anonymous$5737$$T$3x10$interop$Java8$Anonymous$5737$$U$3x10$lang$Boolean$2) null);
        }
        
        // constructor for non-virtual call
        final public x10.interop.Java8.Anonymous$5737<$T, $U> x10$interop$Java8$Anonymous$5737$$init$S(final x10.core.fun.Fun_0_2<$T,$U,x10.core.Boolean> xop, __0$1x10$interop$Java8$Anonymous$5737$$T$3x10$interop$Java8$Anonymous$5737$$U$3x10$lang$Boolean$2 $dummy) {
             {
                
                //#line 138 "x10/interop/Java8.x10"
                ((x10.interop.Java8.Anonymous$5737)this).xop = xop;
            }
            return this;
        }
        
    }
    
    
    //#line 160 "x10/interop/Java8.x10"
    @x10.runtime.impl.java.X10Generated
    final public static class Anonymous$6556 extends x10.core.Ref implements java.util.function.IntConsumer, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<Anonymous$6556> $RTT = 
            x10.rtt.NamedType.<Anonymous$6556> make("x10.interop.Java8.Anonymous$6556",
                                                    Anonymous$6556.class,
                                                    new x10.rtt.Type[] {
                                                        x10.rtt.Types.getRTT(java.util.function.IntConsumer.class)
                                                    });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static x10.serialization.X10JavaSerializable $_deserialize_body(x10.interop.Java8.Anonymous$6556 $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            $_obj.xop = $deserializer.readObject();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.interop.Java8.Anonymous$6556 $_obj = new x10.interop.Java8.Anonymous$6556((java.lang.System[]) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            $serializer.write(this.xop);
            
        }
        
        // constructor just for allocation
        public Anonymous$6556(final java.lang.System[] $dummy) {
            
        }
        
        // synthetic type for parameter mangling
        public static final class __0$1x10$lang$Int$2 {}
        
    
        
        //#line 159 "x10/interop/Java8.x10"
        public x10.core.fun.VoidFun_0_1<x10.core.Int> xop;
        
        
        //#line 161 "x10/interop/Java8.x10"
        public void accept(final int value) {
            
            //#line 161 "x10/interop/Java8.x10"
            final x10.core.fun.VoidFun_0_1 t$129763 = x10.interop.Java8.Anonymous$6556.this.xop;
            
            //#line 161 "x10/interop/Java8.x10"
            ((x10.core.fun.VoidFun_0_1<x10.core.Int>)t$129763).$apply(x10.core.Int.$box(value), x10.rtt.Types.INT);
        }
        
        
        //#line 160 "x10/interop/Java8.x10"
        // creation method for java code (1-phase java constructor)
        public Anonymous$6556(final x10.core.fun.VoidFun_0_1<x10.core.Int> xop, __0$1x10$lang$Int$2 $dummy) {
            this((java.lang.System[]) null);
            x10$interop$Java8$Anonymous$6556$$init$S(xop, (x10.interop.Java8.Anonymous$6556.__0$1x10$lang$Int$2) null);
        }
        
        // constructor for non-virtual call
        final public x10.interop.Java8.Anonymous$6556 x10$interop$Java8$Anonymous$6556$$init$S(final x10.core.fun.VoidFun_0_1<x10.core.Int> xop, __0$1x10$lang$Int$2 $dummy) {
             {
                
                //#line 159 "x10/interop/Java8.x10"
                this.xop = xop;
            }
            return this;
        }
        
    }
    
    
    //#line 165 "x10/interop/Java8.x10"
    @x10.runtime.impl.java.X10Generated
    final public static class Anonymous$6770 extends x10.core.Ref implements java.util.function.LongConsumer, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<Anonymous$6770> $RTT = 
            x10.rtt.NamedType.<Anonymous$6770> make("x10.interop.Java8.Anonymous$6770",
                                                    Anonymous$6770.class,
                                                    new x10.rtt.Type[] {
                                                        x10.rtt.Types.getRTT(java.util.function.LongConsumer.class)
                                                    });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static x10.serialization.X10JavaSerializable $_deserialize_body(x10.interop.Java8.Anonymous$6770 $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            $_obj.xop = $deserializer.readObject();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.interop.Java8.Anonymous$6770 $_obj = new x10.interop.Java8.Anonymous$6770((java.lang.System[]) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            $serializer.write(this.xop);
            
        }
        
        // constructor just for allocation
        public Anonymous$6770(final java.lang.System[] $dummy) {
            
        }
        
        // synthetic type for parameter mangling
        public static final class __0$1x10$lang$Long$2 {}
        
    
        
        //#line 164 "x10/interop/Java8.x10"
        public x10.core.fun.VoidFun_0_1<x10.core.Long> xop;
        
        
        //#line 166 "x10/interop/Java8.x10"
        public void accept(final long value) {
            
            //#line 166 "x10/interop/Java8.x10"
            final x10.core.fun.VoidFun_0_1 t$129764 = x10.interop.Java8.Anonymous$6770.this.xop;
            
            //#line 166 "x10/interop/Java8.x10"
            ((x10.core.fun.VoidFun_0_1<x10.core.Long>)t$129764).$apply(x10.core.Long.$box(value), x10.rtt.Types.LONG);
        }
        
        
        //#line 165 "x10/interop/Java8.x10"
        // creation method for java code (1-phase java constructor)
        public Anonymous$6770(final x10.core.fun.VoidFun_0_1<x10.core.Long> xop, __0$1x10$lang$Long$2 $dummy) {
            this((java.lang.System[]) null);
            x10$interop$Java8$Anonymous$6770$$init$S(xop, (x10.interop.Java8.Anonymous$6770.__0$1x10$lang$Long$2) null);
        }
        
        // constructor for non-virtual call
        final public x10.interop.Java8.Anonymous$6770 x10$interop$Java8$Anonymous$6770$$init$S(final x10.core.fun.VoidFun_0_1<x10.core.Long> xop, __0$1x10$lang$Long$2 $dummy) {
             {
                
                //#line 164 "x10/interop/Java8.x10"
                this.xop = xop;
            }
            return this;
        }
        
    }
    
    
    //#line 170 "x10/interop/Java8.x10"
    @x10.runtime.impl.java.X10Generated
    final public static class Anonymous$6990 extends x10.core.Ref implements java.util.function.DoubleConsumer, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<Anonymous$6990> $RTT = 
            x10.rtt.NamedType.<Anonymous$6990> make("x10.interop.Java8.Anonymous$6990",
                                                    Anonymous$6990.class,
                                                    new x10.rtt.Type[] {
                                                        x10.rtt.Types.getRTT(java.util.function.DoubleConsumer.class)
                                                    });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static x10.serialization.X10JavaSerializable $_deserialize_body(x10.interop.Java8.Anonymous$6990 $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            $_obj.xop = $deserializer.readObject();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.interop.Java8.Anonymous$6990 $_obj = new x10.interop.Java8.Anonymous$6990((java.lang.System[]) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            $serializer.write(this.xop);
            
        }
        
        // constructor just for allocation
        public Anonymous$6990(final java.lang.System[] $dummy) {
            
        }
        
        // synthetic type for parameter mangling
        public static final class __0$1x10$lang$Double$2 {}
        
    
        
        //#line 169 "x10/interop/Java8.x10"
        public x10.core.fun.VoidFun_0_1<x10.core.Double> xop;
        
        
        //#line 171 "x10/interop/Java8.x10"
        public void accept(final double value) {
            
            //#line 171 "x10/interop/Java8.x10"
            final x10.core.fun.VoidFun_0_1 t$129765 = x10.interop.Java8.Anonymous$6990.this.xop;
            
            //#line 171 "x10/interop/Java8.x10"
            ((x10.core.fun.VoidFun_0_1<x10.core.Double>)t$129765).$apply(x10.core.Double.$box(value), x10.rtt.Types.DOUBLE);
        }
        
        
        //#line 170 "x10/interop/Java8.x10"
        // creation method for java code (1-phase java constructor)
        public Anonymous$6990(final x10.core.fun.VoidFun_0_1<x10.core.Double> xop, __0$1x10$lang$Double$2 $dummy) {
            this((java.lang.System[]) null);
            x10$interop$Java8$Anonymous$6990$$init$S(xop, (x10.interop.Java8.Anonymous$6990.__0$1x10$lang$Double$2) null);
        }
        
        // constructor for non-virtual call
        final public x10.interop.Java8.Anonymous$6990 x10$interop$Java8$Anonymous$6990$$init$S(final x10.core.fun.VoidFun_0_1<x10.core.Double> xop, __0$1x10$lang$Double$2 $dummy) {
             {
                
                //#line 169 "x10/interop/Java8.x10"
                this.xop = xop;
            }
            return this;
        }
        
    }
    
    
    //#line 175 "x10/interop/Java8.x10"
    @x10.runtime.impl.java.X10Generated
    final public static class Anonymous$7213<$T> extends x10.core.Ref implements java.util.function.Consumer, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<Anonymous$7213> $RTT = 
            x10.rtt.NamedType.<Anonymous$7213> make("x10.interop.Java8.Anonymous$7213",
                                                    Anonymous$7213.class,
                                                    1,
                                                    new x10.rtt.Type[] {
                                                        x10.rtt.Types.getRTT(java.util.function.Consumer.class)
                                                    });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { if (i == 0) return $T; return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static <$T> x10.serialization.X10JavaSerializable $_deserialize_body(x10.interop.Java8.Anonymous$7213<$T> $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            $_obj.$T = (x10.rtt.Type) $deserializer.readObject();
            $_obj.xop = $deserializer.readObject();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.interop.Java8.Anonymous$7213 $_obj = new x10.interop.Java8.Anonymous$7213((java.lang.System[]) null, (x10.rtt.Type) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            $serializer.write(this.$T);
            $serializer.write(this.xop);
            
        }
        
        // constructor just for allocation
        public Anonymous$7213(final java.lang.System[] $dummy, final x10.rtt.Type $T) {
            x10.interop.Java8.Anonymous$7213.$initParams(this, $T);
            
        }
        
        private x10.rtt.Type $T;
        
        // initializer of type parameters
        public static void $initParams(final Anonymous$7213 $this, final x10.rtt.Type $T) {
            $this.$T = $T;
            
        }
        // synthetic type for parameter mangling
        public static final class __0$1x10$interop$Java8$Anonymous$7213$$T$2 {}
        
    
        
        //#line 174 "x10/interop/Java8.x10"
        public x10.core.fun.VoidFun_0_1<$T> xop;
        
        
        //#line 176 "x10/interop/Java8.x10"
        public void accept(final java.lang.Object value) {
            
            //#line 176 "x10/interop/Java8.x10"
            final x10.core.fun.VoidFun_0_1 t$129766 = x10.interop.Java8.Anonymous$7213.this.xop;
            
            //#line 176 "x10/interop/Java8.x10"
            final $T t$129767 = (($T)(x10.rtt.Types.<$T> cast(value,$T)));
            
            //#line 176 "x10/interop/Java8.x10"
            ((x10.core.fun.VoidFun_0_1<$T>)t$129766).$apply(t$129767, $T);
        }
        
        
        //#line 175 "x10/interop/Java8.x10"
        // creation method for java code (1-phase java constructor)
        public Anonymous$7213(final x10.rtt.Type $T, final x10.core.fun.VoidFun_0_1<$T> xop, __0$1x10$interop$Java8$Anonymous$7213$$T$2 $dummy) {
            this((java.lang.System[]) null, $T);
            x10$interop$Java8$Anonymous$7213$$init$S(xop, (x10.interop.Java8.Anonymous$7213.__0$1x10$interop$Java8$Anonymous$7213$$T$2) null);
        }
        
        // constructor for non-virtual call
        final public x10.interop.Java8.Anonymous$7213<$T> x10$interop$Java8$Anonymous$7213$$init$S(final x10.core.fun.VoidFun_0_1<$T> xop, __0$1x10$interop$Java8$Anonymous$7213$$T$2 $dummy) {
             {
                
                //#line 174 "x10/interop/Java8.x10"
                ((x10.interop.Java8.Anonymous$7213)this).xop = xop;
            }
            return this;
        }
        
    }
    
    
    //#line 196 "x10/interop/Java8.x10"
    @x10.runtime.impl.java.X10Generated
    final public static class Anonymous$8071<$T> extends x10.core.Ref implements java.util.function.ObjIntConsumer, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<Anonymous$8071> $RTT = 
            x10.rtt.NamedType.<Anonymous$8071> make("x10.interop.Java8.Anonymous$8071",
                                                    Anonymous$8071.class,
                                                    1,
                                                    new x10.rtt.Type[] {
                                                        x10.rtt.Types.getRTT(java.util.function.ObjIntConsumer.class)
                                                    });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { if (i == 0) return $T; return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static <$T> x10.serialization.X10JavaSerializable $_deserialize_body(x10.interop.Java8.Anonymous$8071<$T> $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            $_obj.$T = (x10.rtt.Type) $deserializer.readObject();
            $_obj.xop = $deserializer.readObject();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.interop.Java8.Anonymous$8071 $_obj = new x10.interop.Java8.Anonymous$8071((java.lang.System[]) null, (x10.rtt.Type) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            $serializer.write(this.$T);
            $serializer.write(this.xop);
            
        }
        
        // constructor just for allocation
        public Anonymous$8071(final java.lang.System[] $dummy, final x10.rtt.Type $T) {
            x10.interop.Java8.Anonymous$8071.$initParams(this, $T);
            
        }
        
        private x10.rtt.Type $T;
        
        // initializer of type parameters
        public static void $initParams(final Anonymous$8071 $this, final x10.rtt.Type $T) {
            $this.$T = $T;
            
        }
        // synthetic type for parameter mangling
        public static final class __0$1x10$interop$Java8$Anonymous$8071$$T$3x10$lang$Int$2 {}
        
    
        
        //#line 195 "x10/interop/Java8.x10"
        public x10.core.fun.VoidFun_0_2<$T,x10.core.Int> xop;
        
        
        //#line 197 "x10/interop/Java8.x10"
        public void accept(final java.lang.Object t, final int u) {
            
            //#line 197 "x10/interop/Java8.x10"
            final x10.core.fun.VoidFun_0_2 t$129768 = x10.interop.Java8.Anonymous$8071.this.xop;
            
            //#line 197 "x10/interop/Java8.x10"
            final $T t$129769 = (($T)(x10.rtt.Types.<$T> cast(t,$T)));
            
            //#line 197 "x10/interop/Java8.x10"
            ((x10.core.fun.VoidFun_0_2<$T,x10.core.Int>)t$129768).$apply(t$129769, $T, x10.core.Int.$box(u), x10.rtt.Types.INT);
        }
        
        
        //#line 196 "x10/interop/Java8.x10"
        // creation method for java code (1-phase java constructor)
        public Anonymous$8071(final x10.rtt.Type $T, final x10.core.fun.VoidFun_0_2<$T,x10.core.Int> xop, __0$1x10$interop$Java8$Anonymous$8071$$T$3x10$lang$Int$2 $dummy) {
            this((java.lang.System[]) null, $T);
            x10$interop$Java8$Anonymous$8071$$init$S(xop, (x10.interop.Java8.Anonymous$8071.__0$1x10$interop$Java8$Anonymous$8071$$T$3x10$lang$Int$2) null);
        }
        
        // constructor for non-virtual call
        final public x10.interop.Java8.Anonymous$8071<$T> x10$interop$Java8$Anonymous$8071$$init$S(final x10.core.fun.VoidFun_0_2<$T,x10.core.Int> xop, __0$1x10$interop$Java8$Anonymous$8071$$T$3x10$lang$Int$2 $dummy) {
             {
                
                //#line 195 "x10/interop/Java8.x10"
                ((x10.interop.Java8.Anonymous$8071)this).xop = xop;
            }
            return this;
        }
        
    }
    
    
    //#line 201 "x10/interop/Java8.x10"
    @x10.runtime.impl.java.X10Generated
    final public static class Anonymous$8321<$T> extends x10.core.Ref implements java.util.function.ObjLongConsumer, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<Anonymous$8321> $RTT = 
            x10.rtt.NamedType.<Anonymous$8321> make("x10.interop.Java8.Anonymous$8321",
                                                    Anonymous$8321.class,
                                                    1,
                                                    new x10.rtt.Type[] {
                                                        x10.rtt.Types.getRTT(java.util.function.ObjLongConsumer.class)
                                                    });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { if (i == 0) return $T; return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static <$T> x10.serialization.X10JavaSerializable $_deserialize_body(x10.interop.Java8.Anonymous$8321<$T> $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            $_obj.$T = (x10.rtt.Type) $deserializer.readObject();
            $_obj.xop = $deserializer.readObject();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.interop.Java8.Anonymous$8321 $_obj = new x10.interop.Java8.Anonymous$8321((java.lang.System[]) null, (x10.rtt.Type) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            $serializer.write(this.$T);
            $serializer.write(this.xop);
            
        }
        
        // constructor just for allocation
        public Anonymous$8321(final java.lang.System[] $dummy, final x10.rtt.Type $T) {
            x10.interop.Java8.Anonymous$8321.$initParams(this, $T);
            
        }
        
        private x10.rtt.Type $T;
        
        // initializer of type parameters
        public static void $initParams(final Anonymous$8321 $this, final x10.rtt.Type $T) {
            $this.$T = $T;
            
        }
        // synthetic type for parameter mangling
        public static final class __0$1x10$interop$Java8$Anonymous$8321$$T$3x10$lang$Long$2 {}
        
    
        
        //#line 200 "x10/interop/Java8.x10"
        public x10.core.fun.VoidFun_0_2<$T,x10.core.Long> xop;
        
        
        //#line 202 "x10/interop/Java8.x10"
        public void accept(final java.lang.Object t, final long u) {
            
            //#line 202 "x10/interop/Java8.x10"
            final x10.core.fun.VoidFun_0_2 t$129770 = x10.interop.Java8.Anonymous$8321.this.xop;
            
            //#line 202 "x10/interop/Java8.x10"
            final $T t$129771 = (($T)(x10.rtt.Types.<$T> cast(t,$T)));
            
            //#line 202 "x10/interop/Java8.x10"
            ((x10.core.fun.VoidFun_0_2<$T,x10.core.Long>)t$129770).$apply(t$129771, $T, x10.core.Long.$box(u), x10.rtt.Types.LONG);
        }
        
        
        //#line 201 "x10/interop/Java8.x10"
        // creation method for java code (1-phase java constructor)
        public Anonymous$8321(final x10.rtt.Type $T, final x10.core.fun.VoidFun_0_2<$T,x10.core.Long> xop, __0$1x10$interop$Java8$Anonymous$8321$$T$3x10$lang$Long$2 $dummy) {
            this((java.lang.System[]) null, $T);
            x10$interop$Java8$Anonymous$8321$$init$S(xop, (x10.interop.Java8.Anonymous$8321.__0$1x10$interop$Java8$Anonymous$8321$$T$3x10$lang$Long$2) null);
        }
        
        // constructor for non-virtual call
        final public x10.interop.Java8.Anonymous$8321<$T> x10$interop$Java8$Anonymous$8321$$init$S(final x10.core.fun.VoidFun_0_2<$T,x10.core.Long> xop, __0$1x10$interop$Java8$Anonymous$8321$$T$3x10$lang$Long$2 $dummy) {
             {
                
                //#line 200 "x10/interop/Java8.x10"
                ((x10.interop.Java8.Anonymous$8321)this).xop = xop;
            }
            return this;
        }
        
    }
    
    
    //#line 206 "x10/interop/Java8.x10"
    @x10.runtime.impl.java.X10Generated
    final public static class Anonymous$8577<$T> extends x10.core.Ref implements java.util.function.ObjDoubleConsumer, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<Anonymous$8577> $RTT = 
            x10.rtt.NamedType.<Anonymous$8577> make("x10.interop.Java8.Anonymous$8577",
                                                    Anonymous$8577.class,
                                                    1,
                                                    new x10.rtt.Type[] {
                                                        x10.rtt.Types.getRTT(java.util.function.ObjDoubleConsumer.class)
                                                    });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { if (i == 0) return $T; return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static <$T> x10.serialization.X10JavaSerializable $_deserialize_body(x10.interop.Java8.Anonymous$8577<$T> $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            $_obj.$T = (x10.rtt.Type) $deserializer.readObject();
            $_obj.xop = $deserializer.readObject();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.interop.Java8.Anonymous$8577 $_obj = new x10.interop.Java8.Anonymous$8577((java.lang.System[]) null, (x10.rtt.Type) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            $serializer.write(this.$T);
            $serializer.write(this.xop);
            
        }
        
        // constructor just for allocation
        public Anonymous$8577(final java.lang.System[] $dummy, final x10.rtt.Type $T) {
            x10.interop.Java8.Anonymous$8577.$initParams(this, $T);
            
        }
        
        private x10.rtt.Type $T;
        
        // initializer of type parameters
        public static void $initParams(final Anonymous$8577 $this, final x10.rtt.Type $T) {
            $this.$T = $T;
            
        }
        // synthetic type for parameter mangling
        public static final class __0$1x10$interop$Java8$Anonymous$8577$$T$3x10$lang$Double$2 {}
        
    
        
        //#line 205 "x10/interop/Java8.x10"
        public x10.core.fun.VoidFun_0_2<$T,x10.core.Double> xop;
        
        
        //#line 207 "x10/interop/Java8.x10"
        public void accept(final java.lang.Object t, final double u) {
            
            //#line 207 "x10/interop/Java8.x10"
            final x10.core.fun.VoidFun_0_2 t$129772 = x10.interop.Java8.Anonymous$8577.this.xop;
            
            //#line 207 "x10/interop/Java8.x10"
            final $T t$129773 = (($T)(x10.rtt.Types.<$T> cast(t,$T)));
            
            //#line 207 "x10/interop/Java8.x10"
            ((x10.core.fun.VoidFun_0_2<$T,x10.core.Double>)t$129772).$apply(t$129773, $T, x10.core.Double.$box(u), x10.rtt.Types.DOUBLE);
        }
        
        
        //#line 206 "x10/interop/Java8.x10"
        // creation method for java code (1-phase java constructor)
        public Anonymous$8577(final x10.rtt.Type $T, final x10.core.fun.VoidFun_0_2<$T,x10.core.Double> xop, __0$1x10$interop$Java8$Anonymous$8577$$T$3x10$lang$Double$2 $dummy) {
            this((java.lang.System[]) null, $T);
            x10$interop$Java8$Anonymous$8577$$init$S(xop, (x10.interop.Java8.Anonymous$8577.__0$1x10$interop$Java8$Anonymous$8577$$T$3x10$lang$Double$2) null);
        }
        
        // constructor for non-virtual call
        final public x10.interop.Java8.Anonymous$8577<$T> x10$interop$Java8$Anonymous$8577$$init$S(final x10.core.fun.VoidFun_0_2<$T,x10.core.Double> xop, __0$1x10$interop$Java8$Anonymous$8577$$T$3x10$lang$Double$2 $dummy) {
             {
                
                //#line 205 "x10/interop/Java8.x10"
                ((x10.interop.Java8.Anonymous$8577)this).xop = xop;
            }
            return this;
        }
        
    }
    
    
    //#line 211 "x10/interop/Java8.x10"
    @x10.runtime.impl.java.X10Generated
    final public static class Anonymous$8829<$T, $U> extends x10.core.Ref implements java.util.function.BiConsumer, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<Anonymous$8829> $RTT = 
            x10.rtt.NamedType.<Anonymous$8829> make("x10.interop.Java8.Anonymous$8829",
                                                    Anonymous$8829.class,
                                                    2,
                                                    new x10.rtt.Type[] {
                                                        x10.rtt.Types.getRTT(java.util.function.BiConsumer.class)
                                                    });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { if (i == 0) return $T; if (i == 1) return $U; return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static <$T, $U> x10.serialization.X10JavaSerializable $_deserialize_body(x10.interop.Java8.Anonymous$8829<$T, $U> $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            $_obj.$T = (x10.rtt.Type) $deserializer.readObject();
            $_obj.$U = (x10.rtt.Type) $deserializer.readObject();
            $_obj.xop = $deserializer.readObject();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.interop.Java8.Anonymous$8829 $_obj = new x10.interop.Java8.Anonymous$8829((java.lang.System[]) null, (x10.rtt.Type) null, (x10.rtt.Type) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            $serializer.write(this.$T);
            $serializer.write(this.$U);
            $serializer.write(this.xop);
            
        }
        
        // constructor just for allocation
        public Anonymous$8829(final java.lang.System[] $dummy, final x10.rtt.Type $T, final x10.rtt.Type $U) {
            x10.interop.Java8.Anonymous$8829.$initParams(this, $T, $U);
            
        }
        
        private x10.rtt.Type $T;
        private x10.rtt.Type $U;
        
        // initializer of type parameters
        public static void $initParams(final Anonymous$8829 $this, final x10.rtt.Type $T, final x10.rtt.Type $U) {
            $this.$T = $T;
            $this.$U = $U;
            
        }
        // synthetic type for parameter mangling
        public static final class __0$1x10$interop$Java8$Anonymous$8829$$T$3x10$interop$Java8$Anonymous$8829$$U$2 {}
        
    
        
        //#line 210 "x10/interop/Java8.x10"
        public x10.core.fun.VoidFun_0_2<$T,$U> xop;
        
        
        //#line 212 "x10/interop/Java8.x10"
        public void accept(final java.lang.Object t, final java.lang.Object u) {
            
            //#line 212 "x10/interop/Java8.x10"
            final x10.core.fun.VoidFun_0_2 t$129774 = x10.interop.Java8.Anonymous$8829.this.xop;
            
            //#line 212 "x10/interop/Java8.x10"
            final $T t$129775 = (($T)(x10.rtt.Types.<$T> cast(t,$T)));
            
            //#line 212 "x10/interop/Java8.x10"
            final $U t$129776 = (($U)(x10.rtt.Types.<$U> cast(u,$U)));
            
            //#line 212 "x10/interop/Java8.x10"
            ((x10.core.fun.VoidFun_0_2<$T,$U>)t$129774).$apply(t$129775, $T, t$129776, $U);
        }
        
        
        //#line 211 "x10/interop/Java8.x10"
        // creation method for java code (1-phase java constructor)
        public Anonymous$8829(final x10.rtt.Type $T, final x10.rtt.Type $U, final x10.core.fun.VoidFun_0_2<$T,$U> xop, __0$1x10$interop$Java8$Anonymous$8829$$T$3x10$interop$Java8$Anonymous$8829$$U$2 $dummy) {
            this((java.lang.System[]) null, $T, $U);
            x10$interop$Java8$Anonymous$8829$$init$S(xop, (x10.interop.Java8.Anonymous$8829.__0$1x10$interop$Java8$Anonymous$8829$$T$3x10$interop$Java8$Anonymous$8829$$U$2) null);
        }
        
        // constructor for non-virtual call
        final public x10.interop.Java8.Anonymous$8829<$T, $U> x10$interop$Java8$Anonymous$8829$$init$S(final x10.core.fun.VoidFun_0_2<$T,$U> xop, __0$1x10$interop$Java8$Anonymous$8829$$T$3x10$interop$Java8$Anonymous$8829$$U$2 $dummy) {
             {
                
                //#line 210 "x10/interop/Java8.x10"
                ((x10.interop.Java8.Anonymous$8829)this).xop = xop;
            }
            return this;
        }
        
    }
    
    
    //#line 235 "x10/interop/Java8.x10"
    @x10.runtime.impl.java.X10Generated
    final public static class Anonymous$9679 extends x10.core.Ref implements java.util.function.IntSupplier, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<Anonymous$9679> $RTT = 
            x10.rtt.NamedType.<Anonymous$9679> make("x10.interop.Java8.Anonymous$9679",
                                                    Anonymous$9679.class,
                                                    new x10.rtt.Type[] {
                                                        x10.rtt.Types.getRTT(java.util.function.IntSupplier.class)
                                                    });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static x10.serialization.X10JavaSerializable $_deserialize_body(x10.interop.Java8.Anonymous$9679 $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            $_obj.xop = $deserializer.readObject();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.interop.Java8.Anonymous$9679 $_obj = new x10.interop.Java8.Anonymous$9679((java.lang.System[]) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            $serializer.write(this.xop);
            
        }
        
        // constructor just for allocation
        public Anonymous$9679(final java.lang.System[] $dummy) {
            
        }
        
        // synthetic type for parameter mangling
        public static final class __0$1x10$lang$Int$2 {}
        
    
        
        //#line 234 "x10/interop/Java8.x10"
        public x10.core.fun.Fun_0_0<x10.core.Int> xop;
        
        
        //#line 236 "x10/interop/Java8.x10"
        public int getAsInt() {
            
            //#line 236 "x10/interop/Java8.x10"
            final x10.core.fun.Fun_0_0 t$129777 = x10.interop.Java8.Anonymous$9679.this.xop;
            
            //#line 236 "x10/interop/Java8.x10"
            final int t$129778 = x10.core.Int.$unbox(((x10.core.fun.Fun_0_0<x10.core.Int>)t$129777).$apply$G());
            
            //#line 236 "x10/interop/Java8.x10"
            return t$129778;
        }
        
        
        //#line 235 "x10/interop/Java8.x10"
        // creation method for java code (1-phase java constructor)
        public Anonymous$9679(final x10.core.fun.Fun_0_0<x10.core.Int> xop, __0$1x10$lang$Int$2 $dummy) {
            this((java.lang.System[]) null);
            x10$interop$Java8$Anonymous$9679$$init$S(xop, (x10.interop.Java8.Anonymous$9679.__0$1x10$lang$Int$2) null);
        }
        
        // constructor for non-virtual call
        final public x10.interop.Java8.Anonymous$9679 x10$interop$Java8$Anonymous$9679$$init$S(final x10.core.fun.Fun_0_0<x10.core.Int> xop, __0$1x10$lang$Int$2 $dummy) {
             {
                
                //#line 234 "x10/interop/Java8.x10"
                this.xop = xop;
            }
            return this;
        }
        
    }
    
    
    //#line 240 "x10/interop/Java8.x10"
    @x10.runtime.impl.java.X10Generated
    final public static class Anonymous$9883 extends x10.core.Ref implements java.util.function.LongSupplier, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<Anonymous$9883> $RTT = 
            x10.rtt.NamedType.<Anonymous$9883> make("x10.interop.Java8.Anonymous$9883",
                                                    Anonymous$9883.class,
                                                    new x10.rtt.Type[] {
                                                        x10.rtt.Types.getRTT(java.util.function.LongSupplier.class)
                                                    });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static x10.serialization.X10JavaSerializable $_deserialize_body(x10.interop.Java8.Anonymous$9883 $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            $_obj.xop = $deserializer.readObject();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.interop.Java8.Anonymous$9883 $_obj = new x10.interop.Java8.Anonymous$9883((java.lang.System[]) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            $serializer.write(this.xop);
            
        }
        
        // constructor just for allocation
        public Anonymous$9883(final java.lang.System[] $dummy) {
            
        }
        
        // synthetic type for parameter mangling
        public static final class __0$1x10$lang$Long$2 {}
        
    
        
        //#line 239 "x10/interop/Java8.x10"
        public x10.core.fun.Fun_0_0<x10.core.Long> xop;
        
        
        //#line 241 "x10/interop/Java8.x10"
        public long getAsLong() {
            
            //#line 241 "x10/interop/Java8.x10"
            final x10.core.fun.Fun_0_0 t$129779 = x10.interop.Java8.Anonymous$9883.this.xop;
            
            //#line 241 "x10/interop/Java8.x10"
            final long t$129780 = x10.core.Long.$unbox(((x10.core.fun.Fun_0_0<x10.core.Long>)t$129779).$apply$G());
            
            //#line 241 "x10/interop/Java8.x10"
            return t$129780;
        }
        
        
        //#line 240 "x10/interop/Java8.x10"
        // creation method for java code (1-phase java constructor)
        public Anonymous$9883(final x10.core.fun.Fun_0_0<x10.core.Long> xop, __0$1x10$lang$Long$2 $dummy) {
            this((java.lang.System[]) null);
            x10$interop$Java8$Anonymous$9883$$init$S(xop, (x10.interop.Java8.Anonymous$9883.__0$1x10$lang$Long$2) null);
        }
        
        // constructor for non-virtual call
        final public x10.interop.Java8.Anonymous$9883 x10$interop$Java8$Anonymous$9883$$init$S(final x10.core.fun.Fun_0_0<x10.core.Long> xop, __0$1x10$lang$Long$2 $dummy) {
             {
                
                //#line 239 "x10/interop/Java8.x10"
                this.xop = xop;
            }
            return this;
        }
        
    }
    
    
    //#line 245 "x10/interop/Java8.x10"
    @x10.runtime.impl.java.X10Generated
    final public static class Anonymous$10094 extends x10.core.Ref implements java.util.function.DoubleSupplier, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<Anonymous$10094> $RTT = 
            x10.rtt.NamedType.<Anonymous$10094> make("x10.interop.Java8.Anonymous$10094",
                                                     Anonymous$10094.class,
                                                     new x10.rtt.Type[] {
                                                         x10.rtt.Types.getRTT(java.util.function.DoubleSupplier.class)
                                                     });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static x10.serialization.X10JavaSerializable $_deserialize_body(x10.interop.Java8.Anonymous$10094 $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            $_obj.xop = $deserializer.readObject();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.interop.Java8.Anonymous$10094 $_obj = new x10.interop.Java8.Anonymous$10094((java.lang.System[]) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            $serializer.write(this.xop);
            
        }
        
        // constructor just for allocation
        public Anonymous$10094(final java.lang.System[] $dummy) {
            
        }
        
        // synthetic type for parameter mangling
        public static final class __0$1x10$lang$Double$2 {}
        
    
        
        //#line 244 "x10/interop/Java8.x10"
        public x10.core.fun.Fun_0_0<x10.core.Double> xop;
        
        
        //#line 246 "x10/interop/Java8.x10"
        public double getAsDouble() {
            
            //#line 246 "x10/interop/Java8.x10"
            final x10.core.fun.Fun_0_0 t$129781 = x10.interop.Java8.Anonymous$10094.this.xop;
            
            //#line 246 "x10/interop/Java8.x10"
            final double t$129782 = x10.core.Double.$unbox(((x10.core.fun.Fun_0_0<x10.core.Double>)t$129781).$apply$G());
            
            //#line 246 "x10/interop/Java8.x10"
            return t$129782;
        }
        
        
        //#line 245 "x10/interop/Java8.x10"
        // creation method for java code (1-phase java constructor)
        public Anonymous$10094(final x10.core.fun.Fun_0_0<x10.core.Double> xop, __0$1x10$lang$Double$2 $dummy) {
            this((java.lang.System[]) null);
            x10$interop$Java8$Anonymous$10094$$init$S(xop, (x10.interop.Java8.Anonymous$10094.__0$1x10$lang$Double$2) null);
        }
        
        // constructor for non-virtual call
        final public x10.interop.Java8.Anonymous$10094 x10$interop$Java8$Anonymous$10094$$init$S(final x10.core.fun.Fun_0_0<x10.core.Double> xop, __0$1x10$lang$Double$2 $dummy) {
             {
                
                //#line 244 "x10/interop/Java8.x10"
                this.xop = xop;
            }
            return this;
        }
        
    }
    
    
    //#line 250 "x10/interop/Java8.x10"
    @x10.runtime.impl.java.X10Generated
    final public static class Anonymous$10313 extends x10.core.Ref implements java.util.function.BooleanSupplier, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<Anonymous$10313> $RTT = 
            x10.rtt.NamedType.<Anonymous$10313> make("x10.interop.Java8.Anonymous$10313",
                                                     Anonymous$10313.class,
                                                     new x10.rtt.Type[] {
                                                         x10.rtt.Types.getRTT(java.util.function.BooleanSupplier.class)
                                                     });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static x10.serialization.X10JavaSerializable $_deserialize_body(x10.interop.Java8.Anonymous$10313 $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            $_obj.xop = $deserializer.readObject();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.interop.Java8.Anonymous$10313 $_obj = new x10.interop.Java8.Anonymous$10313((java.lang.System[]) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            $serializer.write(this.xop);
            
        }
        
        // constructor just for allocation
        public Anonymous$10313(final java.lang.System[] $dummy) {
            
        }
        
        // synthetic type for parameter mangling
        public static final class __0$1x10$lang$Boolean$2 {}
        
    
        
        //#line 249 "x10/interop/Java8.x10"
        public x10.core.fun.Fun_0_0<x10.core.Boolean> xop;
        
        
        //#line 251 "x10/interop/Java8.x10"
        public boolean getAsBoolean() {
            
            //#line 251 "x10/interop/Java8.x10"
            final x10.core.fun.Fun_0_0 t$129783 = x10.interop.Java8.Anonymous$10313.this.xop;
            
            //#line 251 "x10/interop/Java8.x10"
            final boolean t$129784 = x10.core.Boolean.$unbox(((x10.core.fun.Fun_0_0<x10.core.Boolean>)t$129783).$apply$G());
            
            //#line 251 "x10/interop/Java8.x10"
            return t$129784;
        }
        
        
        //#line 250 "x10/interop/Java8.x10"
        // creation method for java code (1-phase java constructor)
        public Anonymous$10313(final x10.core.fun.Fun_0_0<x10.core.Boolean> xop, __0$1x10$lang$Boolean$2 $dummy) {
            this((java.lang.System[]) null);
            x10$interop$Java8$Anonymous$10313$$init$S(xop, (x10.interop.Java8.Anonymous$10313.__0$1x10$lang$Boolean$2) null);
        }
        
        // constructor for non-virtual call
        final public x10.interop.Java8.Anonymous$10313 x10$interop$Java8$Anonymous$10313$$init$S(final x10.core.fun.Fun_0_0<x10.core.Boolean> xop, __0$1x10$lang$Boolean$2 $dummy) {
             {
                
                //#line 249 "x10/interop/Java8.x10"
                this.xop = xop;
            }
            return this;
        }
        
    }
    
    
    //#line 255 "x10/interop/Java8.x10"
    @x10.runtime.impl.java.X10Generated
    final public static class Anonymous$10532<$T> extends x10.core.Ref implements java.util.function.Supplier, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<Anonymous$10532> $RTT = 
            x10.rtt.NamedType.<Anonymous$10532> make("x10.interop.Java8.Anonymous$10532",
                                                     Anonymous$10532.class,
                                                     1,
                                                     new x10.rtt.Type[] {
                                                         x10.rtt.Types.getRTT(java.util.function.Supplier.class)
                                                     });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { if (i == 0) return $T; return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static <$T> x10.serialization.X10JavaSerializable $_deserialize_body(x10.interop.Java8.Anonymous$10532<$T> $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            $_obj.$T = (x10.rtt.Type) $deserializer.readObject();
            $_obj.xop = $deserializer.readObject();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.interop.Java8.Anonymous$10532 $_obj = new x10.interop.Java8.Anonymous$10532((java.lang.System[]) null, (x10.rtt.Type) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            $serializer.write(this.$T);
            $serializer.write(this.xop);
            
        }
        
        // constructor just for allocation
        public Anonymous$10532(final java.lang.System[] $dummy, final x10.rtt.Type $T) {
            x10.interop.Java8.Anonymous$10532.$initParams(this, $T);
            
        }
        
        private x10.rtt.Type $T;
        
        // initializer of type parameters
        public static void $initParams(final Anonymous$10532 $this, final x10.rtt.Type $T) {
            $this.$T = $T;
            
        }
        // synthetic type for parameter mangling
        public static final class __0$1x10$interop$Java8$Anonymous$10532$$T$2 {}
        
    
        
        //#line 254 "x10/interop/Java8.x10"
        public x10.core.fun.Fun_0_0<$T> xop;
        
        
        //#line 256 "x10/interop/Java8.x10"
        public java.lang.Object get() {
            
            //#line 256 "x10/interop/Java8.x10"
            final x10.core.fun.Fun_0_0 t$129785 = x10.interop.Java8.Anonymous$10532.this.xop;
            
            //#line 256 "x10/interop/Java8.x10"
            final $T t$129786 = (($T)(((x10.core.fun.Fun_0_0<$T>)t$129785).$apply$G()));
            
            //#line 256 "x10/interop/Java8.x10"
            return ((java.lang.Object)
                     t$129786);
        }
        
        
        //#line 255 "x10/interop/Java8.x10"
        // creation method for java code (1-phase java constructor)
        public Anonymous$10532(final x10.rtt.Type $T, final x10.core.fun.Fun_0_0<$T> xop, __0$1x10$interop$Java8$Anonymous$10532$$T$2 $dummy) {
            this((java.lang.System[]) null, $T);
            x10$interop$Java8$Anonymous$10532$$init$S(xop, (x10.interop.Java8.Anonymous$10532.__0$1x10$interop$Java8$Anonymous$10532$$T$2) null);
        }
        
        // constructor for non-virtual call
        final public x10.interop.Java8.Anonymous$10532<$T> x10$interop$Java8$Anonymous$10532$$init$S(final x10.core.fun.Fun_0_0<$T> xop, __0$1x10$interop$Java8$Anonymous$10532$$T$2 $dummy) {
             {
                
                //#line 254 "x10/interop/Java8.x10"
                ((x10.interop.Java8.Anonymous$10532)this).xop = xop;
            }
            return this;
        }
        
    }
    
    
    //#line 273 "x10/interop/Java8.x10"
    @x10.runtime.impl.java.X10Generated
    final public static class Anonymous$11198 extends x10.core.Ref implements java.util.function.LongToIntFunction, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<Anonymous$11198> $RTT = 
            x10.rtt.NamedType.<Anonymous$11198> make("x10.interop.Java8.Anonymous$11198",
                                                     Anonymous$11198.class,
                                                     new x10.rtt.Type[] {
                                                         x10.rtt.Types.getRTT(java.util.function.LongToIntFunction.class)
                                                     });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static x10.serialization.X10JavaSerializable $_deserialize_body(x10.interop.Java8.Anonymous$11198 $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            $_obj.xop = $deserializer.readObject();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.interop.Java8.Anonymous$11198 $_obj = new x10.interop.Java8.Anonymous$11198((java.lang.System[]) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            $serializer.write(this.xop);
            
        }
        
        // constructor just for allocation
        public Anonymous$11198(final java.lang.System[] $dummy) {
            
        }
        
        // synthetic type for parameter mangling
        public static final class __0$1x10$lang$Long$3x10$lang$Int$2 {}
        
    
        
        //#line 272 "x10/interop/Java8.x10"
        public x10.core.fun.Fun_0_1<x10.core.Long,x10.core.Int> xop;
        
        
        //#line 274 "x10/interop/Java8.x10"
        public int applyAsInt(final long value) {
            
            //#line 274 "x10/interop/Java8.x10"
            final x10.core.fun.Fun_0_1 t$129787 = x10.interop.Java8.Anonymous$11198.this.xop;
            
            //#line 274 "x10/interop/Java8.x10"
            final int t$129788 = x10.core.Int.$unbox(((x10.core.fun.Fun_0_1<x10.core.Long,x10.core.Int>)t$129787).$apply(x10.core.Long.$box(value), x10.rtt.Types.LONG));
            
            //#line 274 "x10/interop/Java8.x10"
            return t$129788;
        }
        
        
        //#line 273 "x10/interop/Java8.x10"
        // creation method for java code (1-phase java constructor)
        public Anonymous$11198(final x10.core.fun.Fun_0_1<x10.core.Long,x10.core.Int> xop, __0$1x10$lang$Long$3x10$lang$Int$2 $dummy) {
            this((java.lang.System[]) null);
            x10$interop$Java8$Anonymous$11198$$init$S(xop, (x10.interop.Java8.Anonymous$11198.__0$1x10$lang$Long$3x10$lang$Int$2) null);
        }
        
        // constructor for non-virtual call
        final public x10.interop.Java8.Anonymous$11198 x10$interop$Java8$Anonymous$11198$$init$S(final x10.core.fun.Fun_0_1<x10.core.Long,x10.core.Int> xop, __0$1x10$lang$Long$3x10$lang$Int$2 $dummy) {
             {
                
                //#line 272 "x10/interop/Java8.x10"
                this.xop = xop;
            }
            return this;
        }
        
    }
    
    
    //#line 278 "x10/interop/Java8.x10"
    @x10.runtime.impl.java.X10Generated
    final public static class Anonymous$11437 extends x10.core.Ref implements java.util.function.DoubleToIntFunction, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<Anonymous$11437> $RTT = 
            x10.rtt.NamedType.<Anonymous$11437> make("x10.interop.Java8.Anonymous$11437",
                                                     Anonymous$11437.class,
                                                     new x10.rtt.Type[] {
                                                         x10.rtt.Types.getRTT(java.util.function.DoubleToIntFunction.class)
                                                     });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static x10.serialization.X10JavaSerializable $_deserialize_body(x10.interop.Java8.Anonymous$11437 $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            $_obj.xop = $deserializer.readObject();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.interop.Java8.Anonymous$11437 $_obj = new x10.interop.Java8.Anonymous$11437((java.lang.System[]) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            $serializer.write(this.xop);
            
        }
        
        // constructor just for allocation
        public Anonymous$11437(final java.lang.System[] $dummy) {
            
        }
        
        // synthetic type for parameter mangling
        public static final class __0$1x10$lang$Double$3x10$lang$Int$2 {}
        
    
        
        //#line 277 "x10/interop/Java8.x10"
        public x10.core.fun.Fun_0_1<x10.core.Double,x10.core.Int> xop;
        
        
        //#line 279 "x10/interop/Java8.x10"
        public int applyAsInt(final double value) {
            
            //#line 279 "x10/interop/Java8.x10"
            final x10.core.fun.Fun_0_1 t$129789 = x10.interop.Java8.Anonymous$11437.this.xop;
            
            //#line 279 "x10/interop/Java8.x10"
            final int t$129790 = x10.core.Int.$unbox(((x10.core.fun.Fun_0_1<x10.core.Double,x10.core.Int>)t$129789).$apply(x10.core.Double.$box(value), x10.rtt.Types.DOUBLE));
            
            //#line 279 "x10/interop/Java8.x10"
            return t$129790;
        }
        
        
        //#line 278 "x10/interop/Java8.x10"
        // creation method for java code (1-phase java constructor)
        public Anonymous$11437(final x10.core.fun.Fun_0_1<x10.core.Double,x10.core.Int> xop, __0$1x10$lang$Double$3x10$lang$Int$2 $dummy) {
            this((java.lang.System[]) null);
            x10$interop$Java8$Anonymous$11437$$init$S(xop, (x10.interop.Java8.Anonymous$11437.__0$1x10$lang$Double$3x10$lang$Int$2) null);
        }
        
        // constructor for non-virtual call
        final public x10.interop.Java8.Anonymous$11437 x10$interop$Java8$Anonymous$11437$$init$S(final x10.core.fun.Fun_0_1<x10.core.Double,x10.core.Int> xop, __0$1x10$lang$Double$3x10$lang$Int$2 $dummy) {
             {
                
                //#line 277 "x10/interop/Java8.x10"
                this.xop = xop;
            }
            return this;
        }
        
    }
    
    
    //#line 283 "x10/interop/Java8.x10"
    @x10.runtime.impl.java.X10Generated
    final public static class Anonymous$11679<$T> extends x10.core.Ref implements java.util.function.ToIntFunction, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<Anonymous$11679> $RTT = 
            x10.rtt.NamedType.<Anonymous$11679> make("x10.interop.Java8.Anonymous$11679",
                                                     Anonymous$11679.class,
                                                     1,
                                                     new x10.rtt.Type[] {
                                                         x10.rtt.Types.getRTT(java.util.function.ToIntFunction.class)
                                                     });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { if (i == 0) return $T; return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static <$T> x10.serialization.X10JavaSerializable $_deserialize_body(x10.interop.Java8.Anonymous$11679<$T> $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            $_obj.$T = (x10.rtt.Type) $deserializer.readObject();
            $_obj.xop = $deserializer.readObject();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.interop.Java8.Anonymous$11679 $_obj = new x10.interop.Java8.Anonymous$11679((java.lang.System[]) null, (x10.rtt.Type) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            $serializer.write(this.$T);
            $serializer.write(this.xop);
            
        }
        
        // constructor just for allocation
        public Anonymous$11679(final java.lang.System[] $dummy, final x10.rtt.Type $T) {
            x10.interop.Java8.Anonymous$11679.$initParams(this, $T);
            
        }
        
        private x10.rtt.Type $T;
        
        // initializer of type parameters
        public static void $initParams(final Anonymous$11679 $this, final x10.rtt.Type $T) {
            $this.$T = $T;
            
        }
        // synthetic type for parameter mangling
        public static final class __0$1x10$interop$Java8$Anonymous$11679$$T$3x10$lang$Int$2 {}
        
    
        
        //#line 282 "x10/interop/Java8.x10"
        public x10.core.fun.Fun_0_1<$T,x10.core.Int> xop;
        
        
        //#line 284 "x10/interop/Java8.x10"
        public int applyAsInt(final java.lang.Object value) {
            
            //#line 284 "x10/interop/Java8.x10"
            final x10.core.fun.Fun_0_1 t$129791 = x10.interop.Java8.Anonymous$11679.this.xop;
            
            //#line 284 "x10/interop/Java8.x10"
            final $T t$129792 = (($T)(x10.rtt.Types.<$T> cast(value,$T)));
            
            //#line 284 "x10/interop/Java8.x10"
            final int t$129793 = x10.core.Int.$unbox(((x10.core.fun.Fun_0_1<$T,x10.core.Int>)t$129791).$apply(t$129792, $T));
            
            //#line 284 "x10/interop/Java8.x10"
            return t$129793;
        }
        
        
        //#line 283 "x10/interop/Java8.x10"
        // creation method for java code (1-phase java constructor)
        public Anonymous$11679(final x10.rtt.Type $T, final x10.core.fun.Fun_0_1<$T,x10.core.Int> xop, __0$1x10$interop$Java8$Anonymous$11679$$T$3x10$lang$Int$2 $dummy) {
            this((java.lang.System[]) null, $T);
            x10$interop$Java8$Anonymous$11679$$init$S(xop, (x10.interop.Java8.Anonymous$11679.__0$1x10$interop$Java8$Anonymous$11679$$T$3x10$lang$Int$2) null);
        }
        
        // constructor for non-virtual call
        final public x10.interop.Java8.Anonymous$11679<$T> x10$interop$Java8$Anonymous$11679$$init$S(final x10.core.fun.Fun_0_1<$T,x10.core.Int> xop, __0$1x10$interop$Java8$Anonymous$11679$$T$3x10$lang$Int$2 $dummy) {
             {
                
                //#line 282 "x10/interop/Java8.x10"
                ((x10.interop.Java8.Anonymous$11679)this).xop = xop;
            }
            return this;
        }
        
    }
    
    
    //#line 301 "x10/interop/Java8.x10"
    @x10.runtime.impl.java.X10Generated
    final public static class Anonymous$12383 extends x10.core.Ref implements java.util.function.IntToLongFunction, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<Anonymous$12383> $RTT = 
            x10.rtt.NamedType.<Anonymous$12383> make("x10.interop.Java8.Anonymous$12383",
                                                     Anonymous$12383.class,
                                                     new x10.rtt.Type[] {
                                                         x10.rtt.Types.getRTT(java.util.function.IntToLongFunction.class)
                                                     });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static x10.serialization.X10JavaSerializable $_deserialize_body(x10.interop.Java8.Anonymous$12383 $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            $_obj.xop = $deserializer.readObject();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.interop.Java8.Anonymous$12383 $_obj = new x10.interop.Java8.Anonymous$12383((java.lang.System[]) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            $serializer.write(this.xop);
            
        }
        
        // constructor just for allocation
        public Anonymous$12383(final java.lang.System[] $dummy) {
            
        }
        
        // synthetic type for parameter mangling
        public static final class __0$1x10$lang$Int$3x10$lang$Long$2 {}
        
    
        
        //#line 300 "x10/interop/Java8.x10"
        public x10.core.fun.Fun_0_1<x10.core.Int,x10.core.Long> xop;
        
        
        //#line 302 "x10/interop/Java8.x10"
        public long applyAsLong(final int value) {
            
            //#line 302 "x10/interop/Java8.x10"
            final x10.core.fun.Fun_0_1 t$129794 = x10.interop.Java8.Anonymous$12383.this.xop;
            
            //#line 302 "x10/interop/Java8.x10"
            final long t$129795 = x10.core.Long.$unbox(((x10.core.fun.Fun_0_1<x10.core.Int,x10.core.Long>)t$129794).$apply(x10.core.Int.$box(value), x10.rtt.Types.INT));
            
            //#line 302 "x10/interop/Java8.x10"
            return t$129795;
        }
        
        
        //#line 301 "x10/interop/Java8.x10"
        // creation method for java code (1-phase java constructor)
        public Anonymous$12383(final x10.core.fun.Fun_0_1<x10.core.Int,x10.core.Long> xop, __0$1x10$lang$Int$3x10$lang$Long$2 $dummy) {
            this((java.lang.System[]) null);
            x10$interop$Java8$Anonymous$12383$$init$S(xop, (x10.interop.Java8.Anonymous$12383.__0$1x10$lang$Int$3x10$lang$Long$2) null);
        }
        
        // constructor for non-virtual call
        final public x10.interop.Java8.Anonymous$12383 x10$interop$Java8$Anonymous$12383$$init$S(final x10.core.fun.Fun_0_1<x10.core.Int,x10.core.Long> xop, __0$1x10$lang$Int$3x10$lang$Long$2 $dummy) {
             {
                
                //#line 300 "x10/interop/Java8.x10"
                this.xop = xop;
            }
            return this;
        }
        
    }
    
    
    //#line 306 "x10/interop/Java8.x10"
    @x10.runtime.impl.java.X10Generated
    final public static class Anonymous$12625 extends x10.core.Ref implements java.util.function.DoubleToLongFunction, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<Anonymous$12625> $RTT = 
            x10.rtt.NamedType.<Anonymous$12625> make("x10.interop.Java8.Anonymous$12625",
                                                     Anonymous$12625.class,
                                                     new x10.rtt.Type[] {
                                                         x10.rtt.Types.getRTT(java.util.function.DoubleToLongFunction.class)
                                                     });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static x10.serialization.X10JavaSerializable $_deserialize_body(x10.interop.Java8.Anonymous$12625 $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            $_obj.xop = $deserializer.readObject();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.interop.Java8.Anonymous$12625 $_obj = new x10.interop.Java8.Anonymous$12625((java.lang.System[]) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            $serializer.write(this.xop);
            
        }
        
        // constructor just for allocation
        public Anonymous$12625(final java.lang.System[] $dummy) {
            
        }
        
        // synthetic type for parameter mangling
        public static final class __0$1x10$lang$Double$3x10$lang$Long$2 {}
        
    
        
        //#line 305 "x10/interop/Java8.x10"
        public x10.core.fun.Fun_0_1<x10.core.Double,x10.core.Long> xop;
        
        
        //#line 307 "x10/interop/Java8.x10"
        public long applyAsLong(final double value) {
            
            //#line 307 "x10/interop/Java8.x10"
            final x10.core.fun.Fun_0_1 t$129796 = x10.interop.Java8.Anonymous$12625.this.xop;
            
            //#line 307 "x10/interop/Java8.x10"
            final long t$129797 = x10.core.Long.$unbox(((x10.core.fun.Fun_0_1<x10.core.Double,x10.core.Long>)t$129796).$apply(x10.core.Double.$box(value), x10.rtt.Types.DOUBLE));
            
            //#line 307 "x10/interop/Java8.x10"
            return t$129797;
        }
        
        
        //#line 306 "x10/interop/Java8.x10"
        // creation method for java code (1-phase java constructor)
        public Anonymous$12625(final x10.core.fun.Fun_0_1<x10.core.Double,x10.core.Long> xop, __0$1x10$lang$Double$3x10$lang$Long$2 $dummy) {
            this((java.lang.System[]) null);
            x10$interop$Java8$Anonymous$12625$$init$S(xop, (x10.interop.Java8.Anonymous$12625.__0$1x10$lang$Double$3x10$lang$Long$2) null);
        }
        
        // constructor for non-virtual call
        final public x10.interop.Java8.Anonymous$12625 x10$interop$Java8$Anonymous$12625$$init$S(final x10.core.fun.Fun_0_1<x10.core.Double,x10.core.Long> xop, __0$1x10$lang$Double$3x10$lang$Long$2 $dummy) {
             {
                
                //#line 305 "x10/interop/Java8.x10"
                this.xop = xop;
            }
            return this;
        }
        
    }
    
    
    //#line 311 "x10/interop/Java8.x10"
    @x10.runtime.impl.java.X10Generated
    final public static class Anonymous$12872<$T> extends x10.core.Ref implements java.util.function.ToLongFunction, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<Anonymous$12872> $RTT = 
            x10.rtt.NamedType.<Anonymous$12872> make("x10.interop.Java8.Anonymous$12872",
                                                     Anonymous$12872.class,
                                                     1,
                                                     new x10.rtt.Type[] {
                                                         x10.rtt.Types.getRTT(java.util.function.ToLongFunction.class)
                                                     });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { if (i == 0) return $T; return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static <$T> x10.serialization.X10JavaSerializable $_deserialize_body(x10.interop.Java8.Anonymous$12872<$T> $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            $_obj.$T = (x10.rtt.Type) $deserializer.readObject();
            $_obj.xop = $deserializer.readObject();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.interop.Java8.Anonymous$12872 $_obj = new x10.interop.Java8.Anonymous$12872((java.lang.System[]) null, (x10.rtt.Type) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            $serializer.write(this.$T);
            $serializer.write(this.xop);
            
        }
        
        // constructor just for allocation
        public Anonymous$12872(final java.lang.System[] $dummy, final x10.rtt.Type $T) {
            x10.interop.Java8.Anonymous$12872.$initParams(this, $T);
            
        }
        
        private x10.rtt.Type $T;
        
        // initializer of type parameters
        public static void $initParams(final Anonymous$12872 $this, final x10.rtt.Type $T) {
            $this.$T = $T;
            
        }
        // synthetic type for parameter mangling
        public static final class __0$1x10$interop$Java8$Anonymous$12872$$T$3x10$lang$Long$2 {}
        
    
        
        //#line 310 "x10/interop/Java8.x10"
        public x10.core.fun.Fun_0_1<$T,x10.core.Long> xop;
        
        
        //#line 312 "x10/interop/Java8.x10"
        public long applyAsLong(final java.lang.Object value) {
            
            //#line 312 "x10/interop/Java8.x10"
            final x10.core.fun.Fun_0_1 t$129798 = x10.interop.Java8.Anonymous$12872.this.xop;
            
            //#line 312 "x10/interop/Java8.x10"
            final $T t$129799 = (($T)(x10.rtt.Types.<$T> cast(value,$T)));
            
            //#line 312 "x10/interop/Java8.x10"
            final long t$129800 = x10.core.Long.$unbox(((x10.core.fun.Fun_0_1<$T,x10.core.Long>)t$129798).$apply(t$129799, $T));
            
            //#line 312 "x10/interop/Java8.x10"
            return t$129800;
        }
        
        
        //#line 311 "x10/interop/Java8.x10"
        // creation method for java code (1-phase java constructor)
        public Anonymous$12872(final x10.rtt.Type $T, final x10.core.fun.Fun_0_1<$T,x10.core.Long> xop, __0$1x10$interop$Java8$Anonymous$12872$$T$3x10$lang$Long$2 $dummy) {
            this((java.lang.System[]) null, $T);
            x10$interop$Java8$Anonymous$12872$$init$S(xop, (x10.interop.Java8.Anonymous$12872.__0$1x10$interop$Java8$Anonymous$12872$$T$3x10$lang$Long$2) null);
        }
        
        // constructor for non-virtual call
        final public x10.interop.Java8.Anonymous$12872<$T> x10$interop$Java8$Anonymous$12872$$init$S(final x10.core.fun.Fun_0_1<$T,x10.core.Long> xop, __0$1x10$interop$Java8$Anonymous$12872$$T$3x10$lang$Long$2 $dummy) {
             {
                
                //#line 310 "x10/interop/Java8.x10"
                ((x10.interop.Java8.Anonymous$12872)this).xop = xop;
            }
            return this;
        }
        
    }
    
    
    //#line 329 "x10/interop/Java8.x10"
    @x10.runtime.impl.java.X10Generated
    final public static class Anonymous$13597 extends x10.core.Ref implements java.util.function.IntToDoubleFunction, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<Anonymous$13597> $RTT = 
            x10.rtt.NamedType.<Anonymous$13597> make("x10.interop.Java8.Anonymous$13597",
                                                     Anonymous$13597.class,
                                                     new x10.rtt.Type[] {
                                                         x10.rtt.Types.getRTT(java.util.function.IntToDoubleFunction.class)
                                                     });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static x10.serialization.X10JavaSerializable $_deserialize_body(x10.interop.Java8.Anonymous$13597 $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            $_obj.xop = $deserializer.readObject();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.interop.Java8.Anonymous$13597 $_obj = new x10.interop.Java8.Anonymous$13597((java.lang.System[]) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            $serializer.write(this.xop);
            
        }
        
        // constructor just for allocation
        public Anonymous$13597(final java.lang.System[] $dummy) {
            
        }
        
        // synthetic type for parameter mangling
        public static final class __0$1x10$lang$Int$3x10$lang$Double$2 {}
        
    
        
        //#line 328 "x10/interop/Java8.x10"
        public x10.core.fun.Fun_0_1<x10.core.Int,x10.core.Double> xop;
        
        
        //#line 330 "x10/interop/Java8.x10"
        public double applyAsDouble(final int value) {
            
            //#line 330 "x10/interop/Java8.x10"
            final x10.core.fun.Fun_0_1 t$129801 = x10.interop.Java8.Anonymous$13597.this.xop;
            
            //#line 330 "x10/interop/Java8.x10"
            final double t$129802 = x10.core.Double.$unbox(((x10.core.fun.Fun_0_1<x10.core.Int,x10.core.Double>)t$129801).$apply(x10.core.Int.$box(value), x10.rtt.Types.INT));
            
            //#line 330 "x10/interop/Java8.x10"
            return t$129802;
        }
        
        
        //#line 329 "x10/interop/Java8.x10"
        // creation method for java code (1-phase java constructor)
        public Anonymous$13597(final x10.core.fun.Fun_0_1<x10.core.Int,x10.core.Double> xop, __0$1x10$lang$Int$3x10$lang$Double$2 $dummy) {
            this((java.lang.System[]) null);
            x10$interop$Java8$Anonymous$13597$$init$S(xop, (x10.interop.Java8.Anonymous$13597.__0$1x10$lang$Int$3x10$lang$Double$2) null);
        }
        
        // constructor for non-virtual call
        final public x10.interop.Java8.Anonymous$13597 x10$interop$Java8$Anonymous$13597$$init$S(final x10.core.fun.Fun_0_1<x10.core.Int,x10.core.Double> xop, __0$1x10$lang$Int$3x10$lang$Double$2 $dummy) {
             {
                
                //#line 328 "x10/interop/Java8.x10"
                this.xop = xop;
            }
            return this;
        }
        
    }
    
    
    //#line 334 "x10/interop/Java8.x10"
    @x10.runtime.impl.java.X10Generated
    final public static class Anonymous$13845 extends x10.core.Ref implements java.util.function.LongToDoubleFunction, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<Anonymous$13845> $RTT = 
            x10.rtt.NamedType.<Anonymous$13845> make("x10.interop.Java8.Anonymous$13845",
                                                     Anonymous$13845.class,
                                                     new x10.rtt.Type[] {
                                                         x10.rtt.Types.getRTT(java.util.function.LongToDoubleFunction.class)
                                                     });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static x10.serialization.X10JavaSerializable $_deserialize_body(x10.interop.Java8.Anonymous$13845 $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            $_obj.xop = $deserializer.readObject();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.interop.Java8.Anonymous$13845 $_obj = new x10.interop.Java8.Anonymous$13845((java.lang.System[]) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            $serializer.write(this.xop);
            
        }
        
        // constructor just for allocation
        public Anonymous$13845(final java.lang.System[] $dummy) {
            
        }
        
        // synthetic type for parameter mangling
        public static final class __0$1x10$lang$Long$3x10$lang$Double$2 {}
        
    
        
        //#line 333 "x10/interop/Java8.x10"
        public x10.core.fun.Fun_0_1<x10.core.Long,x10.core.Double> xop;
        
        
        //#line 335 "x10/interop/Java8.x10"
        public double applyAsDouble(final long value) {
            
            //#line 335 "x10/interop/Java8.x10"
            final x10.core.fun.Fun_0_1 t$129803 = x10.interop.Java8.Anonymous$13845.this.xop;
            
            //#line 335 "x10/interop/Java8.x10"
            final double t$129804 = x10.core.Double.$unbox(((x10.core.fun.Fun_0_1<x10.core.Long,x10.core.Double>)t$129803).$apply(x10.core.Long.$box(value), x10.rtt.Types.LONG));
            
            //#line 335 "x10/interop/Java8.x10"
            return t$129804;
        }
        
        
        //#line 334 "x10/interop/Java8.x10"
        // creation method for java code (1-phase java constructor)
        public Anonymous$13845(final x10.core.fun.Fun_0_1<x10.core.Long,x10.core.Double> xop, __0$1x10$lang$Long$3x10$lang$Double$2 $dummy) {
            this((java.lang.System[]) null);
            x10$interop$Java8$Anonymous$13845$$init$S(xop, (x10.interop.Java8.Anonymous$13845.__0$1x10$lang$Long$3x10$lang$Double$2) null);
        }
        
        // constructor for non-virtual call
        final public x10.interop.Java8.Anonymous$13845 x10$interop$Java8$Anonymous$13845$$init$S(final x10.core.fun.Fun_0_1<x10.core.Long,x10.core.Double> xop, __0$1x10$lang$Long$3x10$lang$Double$2 $dummy) {
             {
                
                //#line 333 "x10/interop/Java8.x10"
                this.xop = xop;
            }
            return this;
        }
        
    }
    
    
    //#line 339 "x10/interop/Java8.x10"
    @x10.runtime.impl.java.X10Generated
    final public static class Anonymous$14098<$T> extends x10.core.Ref implements java.util.function.ToDoubleFunction, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<Anonymous$14098> $RTT = 
            x10.rtt.NamedType.<Anonymous$14098> make("x10.interop.Java8.Anonymous$14098",
                                                     Anonymous$14098.class,
                                                     1,
                                                     new x10.rtt.Type[] {
                                                         x10.rtt.Types.getRTT(java.util.function.ToDoubleFunction.class)
                                                     });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { if (i == 0) return $T; return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static <$T> x10.serialization.X10JavaSerializable $_deserialize_body(x10.interop.Java8.Anonymous$14098<$T> $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            $_obj.$T = (x10.rtt.Type) $deserializer.readObject();
            $_obj.xop = $deserializer.readObject();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.interop.Java8.Anonymous$14098 $_obj = new x10.interop.Java8.Anonymous$14098((java.lang.System[]) null, (x10.rtt.Type) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            $serializer.write(this.$T);
            $serializer.write(this.xop);
            
        }
        
        // constructor just for allocation
        public Anonymous$14098(final java.lang.System[] $dummy, final x10.rtt.Type $T) {
            x10.interop.Java8.Anonymous$14098.$initParams(this, $T);
            
        }
        
        private x10.rtt.Type $T;
        
        // initializer of type parameters
        public static void $initParams(final Anonymous$14098 $this, final x10.rtt.Type $T) {
            $this.$T = $T;
            
        }
        // synthetic type for parameter mangling
        public static final class __0$1x10$interop$Java8$Anonymous$14098$$T$3x10$lang$Double$2 {}
        
    
        
        //#line 338 "x10/interop/Java8.x10"
        public x10.core.fun.Fun_0_1<$T,x10.core.Double> xop;
        
        
        //#line 340 "x10/interop/Java8.x10"
        public double applyAsDouble(final java.lang.Object value) {
            
            //#line 340 "x10/interop/Java8.x10"
            final x10.core.fun.Fun_0_1 t$129805 = x10.interop.Java8.Anonymous$14098.this.xop;
            
            //#line 340 "x10/interop/Java8.x10"
            final $T t$129806 = (($T)(x10.rtt.Types.<$T> cast(value,$T)));
            
            //#line 340 "x10/interop/Java8.x10"
            final double t$129807 = x10.core.Double.$unbox(((x10.core.fun.Fun_0_1<$T,x10.core.Double>)t$129805).$apply(t$129806, $T));
            
            //#line 340 "x10/interop/Java8.x10"
            return t$129807;
        }
        
        
        //#line 339 "x10/interop/Java8.x10"
        // creation method for java code (1-phase java constructor)
        public Anonymous$14098(final x10.rtt.Type $T, final x10.core.fun.Fun_0_1<$T,x10.core.Double> xop, __0$1x10$interop$Java8$Anonymous$14098$$T$3x10$lang$Double$2 $dummy) {
            this((java.lang.System[]) null, $T);
            x10$interop$Java8$Anonymous$14098$$init$S(xop, (x10.interop.Java8.Anonymous$14098.__0$1x10$interop$Java8$Anonymous$14098$$T$3x10$lang$Double$2) null);
        }
        
        // constructor for non-virtual call
        final public x10.interop.Java8.Anonymous$14098<$T> x10$interop$Java8$Anonymous$14098$$init$S(final x10.core.fun.Fun_0_1<$T,x10.core.Double> xop, __0$1x10$interop$Java8$Anonymous$14098$$T$3x10$lang$Double$2 $dummy) {
             {
                
                //#line 338 "x10/interop/Java8.x10"
                ((x10.interop.Java8.Anonymous$14098)this).xop = xop;
            }
            return this;
        }
        
    }
    
    
    //#line 360 "x10/interop/Java8.x10"
    @x10.runtime.impl.java.X10Generated
    final public static class Anonymous$14943<$R> extends x10.core.Ref implements java.util.function.IntFunction, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<Anonymous$14943> $RTT = 
            x10.rtt.NamedType.<Anonymous$14943> make("x10.interop.Java8.Anonymous$14943",
                                                     Anonymous$14943.class,
                                                     1,
                                                     new x10.rtt.Type[] {
                                                         x10.rtt.Types.getRTT(java.util.function.IntFunction.class)
                                                     });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { if (i == 0) return $R; return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static <$R> x10.serialization.X10JavaSerializable $_deserialize_body(x10.interop.Java8.Anonymous$14943<$R> $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            $_obj.$R = (x10.rtt.Type) $deserializer.readObject();
            $_obj.xop = $deserializer.readObject();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.interop.Java8.Anonymous$14943 $_obj = new x10.interop.Java8.Anonymous$14943((java.lang.System[]) null, (x10.rtt.Type) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            $serializer.write(this.$R);
            $serializer.write(this.xop);
            
        }
        
        // constructor just for allocation
        public Anonymous$14943(final java.lang.System[] $dummy, final x10.rtt.Type $R) {
            x10.interop.Java8.Anonymous$14943.$initParams(this, $R);
            
        }
        
        private x10.rtt.Type $R;
        
        // initializer of type parameters
        public static void $initParams(final Anonymous$14943 $this, final x10.rtt.Type $R) {
            $this.$R = $R;
            
        }
        // synthetic type for parameter mangling
        public static final class __0$1x10$lang$Int$3x10$interop$Java8$Anonymous$14943$$R$2 {}
        
    
        
        //#line 359 "x10/interop/Java8.x10"
        public x10.core.fun.Fun_0_1<x10.core.Int,$R> xop;
        
        
        //#line 361 "x10/interop/Java8.x10"
        public $R apply(final int value) {
            
            //#line 361 "x10/interop/Java8.x10"
            final x10.core.fun.Fun_0_1 t$129808 = x10.interop.Java8.Anonymous$14943.this.xop;
            
            //#line 361 "x10/interop/Java8.x10"
            final $R t$129809 = (($R)((($R)
                                        ((x10.core.fun.Fun_0_1<x10.core.Int,$R>)t$129808).$apply(x10.core.Int.$box(value), x10.rtt.Types.INT))));
            
            //#line 361 "x10/interop/Java8.x10"
            return t$129809;
        }
        
        
        //#line 360 "x10/interop/Java8.x10"
        // creation method for java code (1-phase java constructor)
        public Anonymous$14943(final x10.rtt.Type $R, final x10.core.fun.Fun_0_1<x10.core.Int,$R> xop, __0$1x10$lang$Int$3x10$interop$Java8$Anonymous$14943$$R$2 $dummy) {
            this((java.lang.System[]) null, $R);
            x10$interop$Java8$Anonymous$14943$$init$S(xop, (x10.interop.Java8.Anonymous$14943.__0$1x10$lang$Int$3x10$interop$Java8$Anonymous$14943$$R$2) null);
        }
        
        // constructor for non-virtual call
        final public x10.interop.Java8.Anonymous$14943<$R> x10$interop$Java8$Anonymous$14943$$init$S(final x10.core.fun.Fun_0_1<x10.core.Int,$R> xop, __0$1x10$lang$Int$3x10$interop$Java8$Anonymous$14943$$R$2 $dummy) {
             {
                
                //#line 359 "x10/interop/Java8.x10"
                ((x10.interop.Java8.Anonymous$14943)this).xop = xop;
            }
            return this;
        }
        
    }
    
    
    //#line 365 "x10/interop/Java8.x10"
    @x10.runtime.impl.java.X10Generated
    final public static class Anonymous$15174<$R> extends x10.core.Ref implements java.util.function.LongFunction, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<Anonymous$15174> $RTT = 
            x10.rtt.NamedType.<Anonymous$15174> make("x10.interop.Java8.Anonymous$15174",
                                                     Anonymous$15174.class,
                                                     1,
                                                     new x10.rtt.Type[] {
                                                         x10.rtt.Types.getRTT(java.util.function.LongFunction.class)
                                                     });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { if (i == 0) return $R; return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static <$R> x10.serialization.X10JavaSerializable $_deserialize_body(x10.interop.Java8.Anonymous$15174<$R> $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            $_obj.$R = (x10.rtt.Type) $deserializer.readObject();
            $_obj.xop = $deserializer.readObject();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.interop.Java8.Anonymous$15174 $_obj = new x10.interop.Java8.Anonymous$15174((java.lang.System[]) null, (x10.rtt.Type) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            $serializer.write(this.$R);
            $serializer.write(this.xop);
            
        }
        
        // constructor just for allocation
        public Anonymous$15174(final java.lang.System[] $dummy, final x10.rtt.Type $R) {
            x10.interop.Java8.Anonymous$15174.$initParams(this, $R);
            
        }
        
        private x10.rtt.Type $R;
        
        // initializer of type parameters
        public static void $initParams(final Anonymous$15174 $this, final x10.rtt.Type $R) {
            $this.$R = $R;
            
        }
        // synthetic type for parameter mangling
        public static final class __0$1x10$lang$Long$3x10$interop$Java8$Anonymous$15174$$R$2 {}
        
    
        
        //#line 364 "x10/interop/Java8.x10"
        public x10.core.fun.Fun_0_1<x10.core.Long,$R> xop;
        
        
        //#line 366 "x10/interop/Java8.x10"
        public $R apply(final long value) {
            
            //#line 366 "x10/interop/Java8.x10"
            final x10.core.fun.Fun_0_1 t$129810 = x10.interop.Java8.Anonymous$15174.this.xop;
            
            //#line 366 "x10/interop/Java8.x10"
            final $R t$129811 = (($R)((($R)
                                        ((x10.core.fun.Fun_0_1<x10.core.Long,$R>)t$129810).$apply(x10.core.Long.$box(value), x10.rtt.Types.LONG))));
            
            //#line 366 "x10/interop/Java8.x10"
            return t$129811;
        }
        
        
        //#line 365 "x10/interop/Java8.x10"
        // creation method for java code (1-phase java constructor)
        public Anonymous$15174(final x10.rtt.Type $R, final x10.core.fun.Fun_0_1<x10.core.Long,$R> xop, __0$1x10$lang$Long$3x10$interop$Java8$Anonymous$15174$$R$2 $dummy) {
            this((java.lang.System[]) null, $R);
            x10$interop$Java8$Anonymous$15174$$init$S(xop, (x10.interop.Java8.Anonymous$15174.__0$1x10$lang$Long$3x10$interop$Java8$Anonymous$15174$$R$2) null);
        }
        
        // constructor for non-virtual call
        final public x10.interop.Java8.Anonymous$15174<$R> x10$interop$Java8$Anonymous$15174$$init$S(final x10.core.fun.Fun_0_1<x10.core.Long,$R> xop, __0$1x10$lang$Long$3x10$interop$Java8$Anonymous$15174$$R$2 $dummy) {
             {
                
                //#line 364 "x10/interop/Java8.x10"
                ((x10.interop.Java8.Anonymous$15174)this).xop = xop;
            }
            return this;
        }
        
    }
    
    
    //#line 370 "x10/interop/Java8.x10"
    @x10.runtime.impl.java.X10Generated
    final public static class Anonymous$15411<$R> extends x10.core.Ref implements java.util.function.DoubleFunction, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<Anonymous$15411> $RTT = 
            x10.rtt.NamedType.<Anonymous$15411> make("x10.interop.Java8.Anonymous$15411",
                                                     Anonymous$15411.class,
                                                     1,
                                                     new x10.rtt.Type[] {
                                                         x10.rtt.Types.getRTT(java.util.function.DoubleFunction.class)
                                                     });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { if (i == 0) return $R; return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static <$R> x10.serialization.X10JavaSerializable $_deserialize_body(x10.interop.Java8.Anonymous$15411<$R> $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            $_obj.$R = (x10.rtt.Type) $deserializer.readObject();
            $_obj.xop = $deserializer.readObject();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.interop.Java8.Anonymous$15411 $_obj = new x10.interop.Java8.Anonymous$15411((java.lang.System[]) null, (x10.rtt.Type) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            $serializer.write(this.$R);
            $serializer.write(this.xop);
            
        }
        
        // constructor just for allocation
        public Anonymous$15411(final java.lang.System[] $dummy, final x10.rtt.Type $R) {
            x10.interop.Java8.Anonymous$15411.$initParams(this, $R);
            
        }
        
        private x10.rtt.Type $R;
        
        // initializer of type parameters
        public static void $initParams(final Anonymous$15411 $this, final x10.rtt.Type $R) {
            $this.$R = $R;
            
        }
        // synthetic type for parameter mangling
        public static final class __0$1x10$lang$Double$3x10$interop$Java8$Anonymous$15411$$R$2 {}
        
    
        
        //#line 369 "x10/interop/Java8.x10"
        public x10.core.fun.Fun_0_1<x10.core.Double,$R> xop;
        
        
        //#line 371 "x10/interop/Java8.x10"
        public $R apply(final double value) {
            
            //#line 371 "x10/interop/Java8.x10"
            final x10.core.fun.Fun_0_1 t$129812 = x10.interop.Java8.Anonymous$15411.this.xop;
            
            //#line 371 "x10/interop/Java8.x10"
            final $R t$129813 = (($R)((($R)
                                        ((x10.core.fun.Fun_0_1<x10.core.Double,$R>)t$129812).$apply(x10.core.Double.$box(value), x10.rtt.Types.DOUBLE))));
            
            //#line 371 "x10/interop/Java8.x10"
            return t$129813;
        }
        
        
        //#line 370 "x10/interop/Java8.x10"
        // creation method for java code (1-phase java constructor)
        public Anonymous$15411(final x10.rtt.Type $R, final x10.core.fun.Fun_0_1<x10.core.Double,$R> xop, __0$1x10$lang$Double$3x10$interop$Java8$Anonymous$15411$$R$2 $dummy) {
            this((java.lang.System[]) null, $R);
            x10$interop$Java8$Anonymous$15411$$init$S(xop, (x10.interop.Java8.Anonymous$15411.__0$1x10$lang$Double$3x10$interop$Java8$Anonymous$15411$$R$2) null);
        }
        
        // constructor for non-virtual call
        final public x10.interop.Java8.Anonymous$15411<$R> x10$interop$Java8$Anonymous$15411$$init$S(final x10.core.fun.Fun_0_1<x10.core.Double,$R> xop, __0$1x10$lang$Double$3x10$interop$Java8$Anonymous$15411$$R$2 $dummy) {
             {
                
                //#line 369 "x10/interop/Java8.x10"
                ((x10.interop.Java8.Anonymous$15411)this).xop = xop;
            }
            return this;
        }
        
    }
    
    
    //#line 375 "x10/interop/Java8.x10"
    @x10.runtime.impl.java.X10Generated
    final public static class Anonymous$15645<$T, $R> extends x10.core.Ref implements java.util.function.Function, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<Anonymous$15645> $RTT = 
            x10.rtt.NamedType.<Anonymous$15645> make("x10.interop.Java8.Anonymous$15645",
                                                     Anonymous$15645.class,
                                                     2,
                                                     new x10.rtt.Type[] {
                                                         x10.rtt.Types.getRTT(java.util.function.Function.class)
                                                     });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { if (i == 0) return $T; if (i == 1) return $R; return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static <$T, $R> x10.serialization.X10JavaSerializable $_deserialize_body(x10.interop.Java8.Anonymous$15645<$T, $R> $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            $_obj.$T = (x10.rtt.Type) $deserializer.readObject();
            $_obj.$R = (x10.rtt.Type) $deserializer.readObject();
            $_obj.xop = $deserializer.readObject();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.interop.Java8.Anonymous$15645 $_obj = new x10.interop.Java8.Anonymous$15645((java.lang.System[]) null, (x10.rtt.Type) null, (x10.rtt.Type) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            $serializer.write(this.$T);
            $serializer.write(this.$R);
            $serializer.write(this.xop);
            
        }
        
        // constructor just for allocation
        public Anonymous$15645(final java.lang.System[] $dummy, final x10.rtt.Type $T, final x10.rtt.Type $R) {
            x10.interop.Java8.Anonymous$15645.$initParams(this, $T, $R);
            
        }
        
        private x10.rtt.Type $T;
        private x10.rtt.Type $R;
        
        // initializer of type parameters
        public static void $initParams(final Anonymous$15645 $this, final x10.rtt.Type $T, final x10.rtt.Type $R) {
            $this.$T = $T;
            $this.$R = $R;
            
        }
        // synthetic type for parameter mangling
        public static final class __0$1x10$interop$Java8$Anonymous$15645$$T$3x10$interop$Java8$Anonymous$15645$$R$2 {}
        
    
        
        //#line 374 "x10/interop/Java8.x10"
        public x10.core.fun.Fun_0_1<$T,$R> xop;
        
        
        //#line 376 "x10/interop/Java8.x10"
        public $R apply(final java.lang.Object value) {
            
            //#line 376 "x10/interop/Java8.x10"
            final x10.core.fun.Fun_0_1 t$129814 = x10.interop.Java8.Anonymous$15645.this.xop;
            
            //#line 376 "x10/interop/Java8.x10"
            final $T t$129815 = (($T)(x10.rtt.Types.<$T> cast(value,$T)));
            
            //#line 376 "x10/interop/Java8.x10"
            final $R t$129816 = (($R)((($R)
                                        ((x10.core.fun.Fun_0_1<$T,$R>)t$129814).$apply(t$129815, $T))));
            
            //#line 376 "x10/interop/Java8.x10"
            return t$129816;
        }
        
        
        //#line 375 "x10/interop/Java8.x10"
        // creation method for java code (1-phase java constructor)
        public Anonymous$15645(final x10.rtt.Type $T, final x10.rtt.Type $R, final x10.core.fun.Fun_0_1<$T,$R> xop, __0$1x10$interop$Java8$Anonymous$15645$$T$3x10$interop$Java8$Anonymous$15645$$R$2 $dummy) {
            this((java.lang.System[]) null, $T, $R);
            x10$interop$Java8$Anonymous$15645$$init$S(xop, (x10.interop.Java8.Anonymous$15645.__0$1x10$interop$Java8$Anonymous$15645$$T$3x10$interop$Java8$Anonymous$15645$$R$2) null);
        }
        
        // constructor for non-virtual call
        final public x10.interop.Java8.Anonymous$15645<$T, $R> x10$interop$Java8$Anonymous$15645$$init$S(final x10.core.fun.Fun_0_1<$T,$R> xop, __0$1x10$interop$Java8$Anonymous$15645$$T$3x10$interop$Java8$Anonymous$15645$$R$2 $dummy) {
             {
                
                //#line 374 "x10/interop/Java8.x10"
                ((x10.interop.Java8.Anonymous$15645)this).xop = xop;
            }
            return this;
        }
        
    }
    
    
    //#line 396 "x10/interop/Java8.x10"
    @x10.runtime.impl.java.X10Generated
    final public static class Anonymous$16507<$T, $U> extends x10.core.Ref implements java.util.function.ToIntBiFunction, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<Anonymous$16507> $RTT = 
            x10.rtt.NamedType.<Anonymous$16507> make("x10.interop.Java8.Anonymous$16507",
                                                     Anonymous$16507.class,
                                                     2,
                                                     new x10.rtt.Type[] {
                                                         x10.rtt.Types.getRTT(java.util.function.ToIntBiFunction.class)
                                                     });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { if (i == 0) return $T; if (i == 1) return $U; return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static <$T, $U> x10.serialization.X10JavaSerializable $_deserialize_body(x10.interop.Java8.Anonymous$16507<$T, $U> $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            $_obj.$T = (x10.rtt.Type) $deserializer.readObject();
            $_obj.$U = (x10.rtt.Type) $deserializer.readObject();
            $_obj.xop = $deserializer.readObject();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.interop.Java8.Anonymous$16507 $_obj = new x10.interop.Java8.Anonymous$16507((java.lang.System[]) null, (x10.rtt.Type) null, (x10.rtt.Type) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            $serializer.write(this.$T);
            $serializer.write(this.$U);
            $serializer.write(this.xop);
            
        }
        
        // constructor just for allocation
        public Anonymous$16507(final java.lang.System[] $dummy, final x10.rtt.Type $T, final x10.rtt.Type $U) {
            x10.interop.Java8.Anonymous$16507.$initParams(this, $T, $U);
            
        }
        
        private x10.rtt.Type $T;
        private x10.rtt.Type $U;
        
        // initializer of type parameters
        public static void $initParams(final Anonymous$16507 $this, final x10.rtt.Type $T, final x10.rtt.Type $U) {
            $this.$T = $T;
            $this.$U = $U;
            
        }
        // synthetic type for parameter mangling
        public static final class __0$1x10$interop$Java8$Anonymous$16507$$T$3x10$interop$Java8$Anonymous$16507$$U$3x10$lang$Int$2 {}
        
    
        
        //#line 395 "x10/interop/Java8.x10"
        public x10.core.fun.Fun_0_2<$T,$U,x10.core.Int> xop;
        
        
        //#line 397 "x10/interop/Java8.x10"
        public int applyAsInt(final java.lang.Object t, final java.lang.Object u) {
            
            //#line 397 "x10/interop/Java8.x10"
            final x10.core.fun.Fun_0_2 t$129817 = x10.interop.Java8.Anonymous$16507.this.xop;
            
            //#line 397 "x10/interop/Java8.x10"
            final $T t$129818 = (($T)(x10.rtt.Types.<$T> cast(t,$T)));
            
            //#line 397 "x10/interop/Java8.x10"
            final $U t$129819 = (($U)(x10.rtt.Types.<$U> cast(u,$U)));
            
            //#line 397 "x10/interop/Java8.x10"
            final int t$129820 = x10.core.Int.$unbox(((x10.core.fun.Fun_0_2<$T,$U,x10.core.Int>)t$129817).$apply(t$129818, $T, t$129819, $U));
            
            //#line 397 "x10/interop/Java8.x10"
            return t$129820;
        }
        
        
        //#line 396 "x10/interop/Java8.x10"
        // creation method for java code (1-phase java constructor)
        public Anonymous$16507(final x10.rtt.Type $T, final x10.rtt.Type $U, final x10.core.fun.Fun_0_2<$T,$U,x10.core.Int> xop, __0$1x10$interop$Java8$Anonymous$16507$$T$3x10$interop$Java8$Anonymous$16507$$U$3x10$lang$Int$2 $dummy) {
            this((java.lang.System[]) null, $T, $U);
            x10$interop$Java8$Anonymous$16507$$init$S(xop, (x10.interop.Java8.Anonymous$16507.__0$1x10$interop$Java8$Anonymous$16507$$T$3x10$interop$Java8$Anonymous$16507$$U$3x10$lang$Int$2) null);
        }
        
        // constructor for non-virtual call
        final public x10.interop.Java8.Anonymous$16507<$T, $U> x10$interop$Java8$Anonymous$16507$$init$S(final x10.core.fun.Fun_0_2<$T,$U,x10.core.Int> xop, __0$1x10$interop$Java8$Anonymous$16507$$T$3x10$interop$Java8$Anonymous$16507$$U$3x10$lang$Int$2 $dummy) {
             {
                
                //#line 395 "x10/interop/Java8.x10"
                ((x10.interop.Java8.Anonymous$16507)this).xop = xop;
            }
            return this;
        }
        
    }
    
    
    //#line 401 "x10/interop/Java8.x10"
    @x10.runtime.impl.java.X10Generated
    final public static class Anonymous$16781<$T, $U> extends x10.core.Ref implements java.util.function.ToLongBiFunction, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<Anonymous$16781> $RTT = 
            x10.rtt.NamedType.<Anonymous$16781> make("x10.interop.Java8.Anonymous$16781",
                                                     Anonymous$16781.class,
                                                     2,
                                                     new x10.rtt.Type[] {
                                                         x10.rtt.Types.getRTT(java.util.function.ToLongBiFunction.class)
                                                     });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { if (i == 0) return $T; if (i == 1) return $U; return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static <$T, $U> x10.serialization.X10JavaSerializable $_deserialize_body(x10.interop.Java8.Anonymous$16781<$T, $U> $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            $_obj.$T = (x10.rtt.Type) $deserializer.readObject();
            $_obj.$U = (x10.rtt.Type) $deserializer.readObject();
            $_obj.xop = $deserializer.readObject();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.interop.Java8.Anonymous$16781 $_obj = new x10.interop.Java8.Anonymous$16781((java.lang.System[]) null, (x10.rtt.Type) null, (x10.rtt.Type) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            $serializer.write(this.$T);
            $serializer.write(this.$U);
            $serializer.write(this.xop);
            
        }
        
        // constructor just for allocation
        public Anonymous$16781(final java.lang.System[] $dummy, final x10.rtt.Type $T, final x10.rtt.Type $U) {
            x10.interop.Java8.Anonymous$16781.$initParams(this, $T, $U);
            
        }
        
        private x10.rtt.Type $T;
        private x10.rtt.Type $U;
        
        // initializer of type parameters
        public static void $initParams(final Anonymous$16781 $this, final x10.rtt.Type $T, final x10.rtt.Type $U) {
            $this.$T = $T;
            $this.$U = $U;
            
        }
        // synthetic type for parameter mangling
        public static final class __0$1x10$interop$Java8$Anonymous$16781$$T$3x10$interop$Java8$Anonymous$16781$$U$3x10$lang$Long$2 {}
        
    
        
        //#line 400 "x10/interop/Java8.x10"
        public x10.core.fun.Fun_0_2<$T,$U,x10.core.Long> xop;
        
        
        //#line 402 "x10/interop/Java8.x10"
        public long applyAsLong(final java.lang.Object t, final java.lang.Object u) {
            
            //#line 402 "x10/interop/Java8.x10"
            final x10.core.fun.Fun_0_2 t$129821 = x10.interop.Java8.Anonymous$16781.this.xop;
            
            //#line 402 "x10/interop/Java8.x10"
            final $T t$129822 = (($T)(x10.rtt.Types.<$T> cast(t,$T)));
            
            //#line 402 "x10/interop/Java8.x10"
            final $U t$129823 = (($U)(x10.rtt.Types.<$U> cast(u,$U)));
            
            //#line 402 "x10/interop/Java8.x10"
            final long t$129824 = x10.core.Long.$unbox(((x10.core.fun.Fun_0_2<$T,$U,x10.core.Long>)t$129821).$apply(t$129822, $T, t$129823, $U));
            
            //#line 402 "x10/interop/Java8.x10"
            return t$129824;
        }
        
        
        //#line 401 "x10/interop/Java8.x10"
        // creation method for java code (1-phase java constructor)
        public Anonymous$16781(final x10.rtt.Type $T, final x10.rtt.Type $U, final x10.core.fun.Fun_0_2<$T,$U,x10.core.Long> xop, __0$1x10$interop$Java8$Anonymous$16781$$T$3x10$interop$Java8$Anonymous$16781$$U$3x10$lang$Long$2 $dummy) {
            this((java.lang.System[]) null, $T, $U);
            x10$interop$Java8$Anonymous$16781$$init$S(xop, (x10.interop.Java8.Anonymous$16781.__0$1x10$interop$Java8$Anonymous$16781$$T$3x10$interop$Java8$Anonymous$16781$$U$3x10$lang$Long$2) null);
        }
        
        // constructor for non-virtual call
        final public x10.interop.Java8.Anonymous$16781<$T, $U> x10$interop$Java8$Anonymous$16781$$init$S(final x10.core.fun.Fun_0_2<$T,$U,x10.core.Long> xop, __0$1x10$interop$Java8$Anonymous$16781$$T$3x10$interop$Java8$Anonymous$16781$$U$3x10$lang$Long$2 $dummy) {
             {
                
                //#line 400 "x10/interop/Java8.x10"
                ((x10.interop.Java8.Anonymous$16781)this).xop = xop;
            }
            return this;
        }
        
    }
    
    
    //#line 406 "x10/interop/Java8.x10"
    @x10.runtime.impl.java.X10Generated
    final public static class Anonymous$17062<$T, $U> extends x10.core.Ref implements java.util.function.ToDoubleBiFunction, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<Anonymous$17062> $RTT = 
            x10.rtt.NamedType.<Anonymous$17062> make("x10.interop.Java8.Anonymous$17062",
                                                     Anonymous$17062.class,
                                                     2,
                                                     new x10.rtt.Type[] {
                                                         x10.rtt.Types.getRTT(java.util.function.ToDoubleBiFunction.class)
                                                     });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { if (i == 0) return $T; if (i == 1) return $U; return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static <$T, $U> x10.serialization.X10JavaSerializable $_deserialize_body(x10.interop.Java8.Anonymous$17062<$T, $U> $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            $_obj.$T = (x10.rtt.Type) $deserializer.readObject();
            $_obj.$U = (x10.rtt.Type) $deserializer.readObject();
            $_obj.xop = $deserializer.readObject();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.interop.Java8.Anonymous$17062 $_obj = new x10.interop.Java8.Anonymous$17062((java.lang.System[]) null, (x10.rtt.Type) null, (x10.rtt.Type) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            $serializer.write(this.$T);
            $serializer.write(this.$U);
            $serializer.write(this.xop);
            
        }
        
        // constructor just for allocation
        public Anonymous$17062(final java.lang.System[] $dummy, final x10.rtt.Type $T, final x10.rtt.Type $U) {
            x10.interop.Java8.Anonymous$17062.$initParams(this, $T, $U);
            
        }
        
        private x10.rtt.Type $T;
        private x10.rtt.Type $U;
        
        // initializer of type parameters
        public static void $initParams(final Anonymous$17062 $this, final x10.rtt.Type $T, final x10.rtt.Type $U) {
            $this.$T = $T;
            $this.$U = $U;
            
        }
        // synthetic type for parameter mangling
        public static final class __0$1x10$interop$Java8$Anonymous$17062$$T$3x10$interop$Java8$Anonymous$17062$$U$3x10$lang$Double$2 {}
        
    
        
        //#line 405 "x10/interop/Java8.x10"
        public x10.core.fun.Fun_0_2<$T,$U,x10.core.Double> xop;
        
        
        //#line 407 "x10/interop/Java8.x10"
        public double applyAsDouble(final java.lang.Object t, final java.lang.Object u) {
            
            //#line 407 "x10/interop/Java8.x10"
            final x10.core.fun.Fun_0_2 t$129825 = x10.interop.Java8.Anonymous$17062.this.xop;
            
            //#line 407 "x10/interop/Java8.x10"
            final $T t$129826 = (($T)(x10.rtt.Types.<$T> cast(t,$T)));
            
            //#line 407 "x10/interop/Java8.x10"
            final $U t$129827 = (($U)(x10.rtt.Types.<$U> cast(u,$U)));
            
            //#line 407 "x10/interop/Java8.x10"
            final double t$129828 = x10.core.Double.$unbox(((x10.core.fun.Fun_0_2<$T,$U,x10.core.Double>)t$129825).$apply(t$129826, $T, t$129827, $U));
            
            //#line 407 "x10/interop/Java8.x10"
            return t$129828;
        }
        
        
        //#line 406 "x10/interop/Java8.x10"
        // creation method for java code (1-phase java constructor)
        public Anonymous$17062(final x10.rtt.Type $T, final x10.rtt.Type $U, final x10.core.fun.Fun_0_2<$T,$U,x10.core.Double> xop, __0$1x10$interop$Java8$Anonymous$17062$$T$3x10$interop$Java8$Anonymous$17062$$U$3x10$lang$Double$2 $dummy) {
            this((java.lang.System[]) null, $T, $U);
            x10$interop$Java8$Anonymous$17062$$init$S(xop, (x10.interop.Java8.Anonymous$17062.__0$1x10$interop$Java8$Anonymous$17062$$T$3x10$interop$Java8$Anonymous$17062$$U$3x10$lang$Double$2) null);
        }
        
        // constructor for non-virtual call
        final public x10.interop.Java8.Anonymous$17062<$T, $U> x10$interop$Java8$Anonymous$17062$$init$S(final x10.core.fun.Fun_0_2<$T,$U,x10.core.Double> xop, __0$1x10$interop$Java8$Anonymous$17062$$T$3x10$interop$Java8$Anonymous$17062$$U$3x10$lang$Double$2 $dummy) {
             {
                
                //#line 405 "x10/interop/Java8.x10"
                ((x10.interop.Java8.Anonymous$17062)this).xop = xop;
            }
            return this;
        }
        
    }
    
    
    //#line 411 "x10/interop/Java8.x10"
    @x10.runtime.impl.java.X10Generated
    final public static class Anonymous$17340<$T, $U, $R> extends x10.core.Ref implements java.util.function.BiFunction, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<Anonymous$17340> $RTT = 
            x10.rtt.NamedType.<Anonymous$17340> make("x10.interop.Java8.Anonymous$17340",
                                                     Anonymous$17340.class,
                                                     3,
                                                     new x10.rtt.Type[] {
                                                         x10.rtt.Types.getRTT(java.util.function.BiFunction.class)
                                                     });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { if (i == 0) return $T; if (i == 1) return $U; if (i == 2) return $R; return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static <$T, $U, $R> x10.serialization.X10JavaSerializable $_deserialize_body(x10.interop.Java8.Anonymous$17340<$T, $U, $R> $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            $_obj.$T = (x10.rtt.Type) $deserializer.readObject();
            $_obj.$U = (x10.rtt.Type) $deserializer.readObject();
            $_obj.$R = (x10.rtt.Type) $deserializer.readObject();
            $_obj.xop = $deserializer.readObject();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.interop.Java8.Anonymous$17340 $_obj = new x10.interop.Java8.Anonymous$17340((java.lang.System[]) null, (x10.rtt.Type) null, (x10.rtt.Type) null, (x10.rtt.Type) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            $serializer.write(this.$T);
            $serializer.write(this.$U);
            $serializer.write(this.$R);
            $serializer.write(this.xop);
            
        }
        
        // constructor just for allocation
        public Anonymous$17340(final java.lang.System[] $dummy, final x10.rtt.Type $T, final x10.rtt.Type $U, final x10.rtt.Type $R) {
            x10.interop.Java8.Anonymous$17340.$initParams(this, $T, $U, $R);
            
        }
        
        private x10.rtt.Type $T;
        private x10.rtt.Type $U;
        private x10.rtt.Type $R;
        
        // initializer of type parameters
        public static void $initParams(final Anonymous$17340 $this, final x10.rtt.Type $T, final x10.rtt.Type $U, final x10.rtt.Type $R) {
            $this.$T = $T;
            $this.$U = $U;
            $this.$R = $R;
            
        }
        // synthetic type for parameter mangling
        public static final class __0$1x10$interop$Java8$Anonymous$17340$$T$3x10$interop$Java8$Anonymous$17340$$U$3x10$interop$Java8$Anonymous$17340$$R$2 {}
        
    
        
        //#line 410 "x10/interop/Java8.x10"
        public x10.core.fun.Fun_0_2<$T,$U,$R> xop;
        
        
        //#line 412 "x10/interop/Java8.x10"
        public java.lang.Object apply(final java.lang.Object t, final java.lang.Object u) {
            
            //#line 412 "x10/interop/Java8.x10"
            final x10.core.fun.Fun_0_2 t$129829 = x10.interop.Java8.Anonymous$17340.this.xop;
            
            //#line 412 "x10/interop/Java8.x10"
            final $T t$129830 = (($T)(x10.rtt.Types.<$T> cast(t,$T)));
            
            //#line 412 "x10/interop/Java8.x10"
            final $U t$129831 = (($U)(x10.rtt.Types.<$U> cast(u,$U)));
            
            //#line 412 "x10/interop/Java8.x10"
            final $R t$129832 = (($R)((($R)
                                        ((x10.core.fun.Fun_0_2<$T,$U,$R>)t$129829).$apply(t$129830, $T, t$129831, $U))));
            
            //#line 412 "x10/interop/Java8.x10"
            return ((java.lang.Object)
                     t$129832);
        }
        
        
        //#line 411 "x10/interop/Java8.x10"
        // creation method for java code (1-phase java constructor)
        public Anonymous$17340(final x10.rtt.Type $T, final x10.rtt.Type $U, final x10.rtt.Type $R, final x10.core.fun.Fun_0_2<$T,$U,$R> xop, __0$1x10$interop$Java8$Anonymous$17340$$T$3x10$interop$Java8$Anonymous$17340$$U$3x10$interop$Java8$Anonymous$17340$$R$2 $dummy) {
            this((java.lang.System[]) null, $T, $U, $R);
            x10$interop$Java8$Anonymous$17340$$init$S(xop, (x10.interop.Java8.Anonymous$17340.__0$1x10$interop$Java8$Anonymous$17340$$T$3x10$interop$Java8$Anonymous$17340$$U$3x10$interop$Java8$Anonymous$17340$$R$2) null);
        }
        
        // constructor for non-virtual call
        final public x10.interop.Java8.Anonymous$17340<$T, $U, $R> x10$interop$Java8$Anonymous$17340$$init$S(final x10.core.fun.Fun_0_2<$T,$U,$R> xop, __0$1x10$interop$Java8$Anonymous$17340$$T$3x10$interop$Java8$Anonymous$17340$$U$3x10$interop$Java8$Anonymous$17340$$R$2 $dummy) {
             {
                
                //#line 410 "x10/interop/Java8.x10"
                ((x10.interop.Java8.Anonymous$17340)this).xop = xop;
            }
            return this;
        }
        
    }
    
    
    //#line 423 "x10/interop/Java8.x10"
    @x10.runtime.impl.java.X10Generated
    final public static class Anonymous$17695 extends x10.core.Ref implements java.lang.Runnable, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<Anonymous$17695> $RTT = 
            x10.rtt.NamedType.<Anonymous$17695> make("x10.interop.Java8.Anonymous$17695",
                                                     Anonymous$17695.class,
                                                     new x10.rtt.Type[] {
                                                         x10.rtt.Types.getRTT(java.lang.Runnable.class)
                                                     });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static x10.serialization.X10JavaSerializable $_deserialize_body(x10.interop.Java8.Anonymous$17695 $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            $_obj.xop = $deserializer.readObject();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.interop.Java8.Anonymous$17695 $_obj = new x10.interop.Java8.Anonymous$17695((java.lang.System[]) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            $serializer.write(this.xop);
            
        }
        
        // constructor just for allocation
        public Anonymous$17695(final java.lang.System[] $dummy) {
            
        }
        
        
    
        
        //#line 422 "x10/interop/Java8.x10"
        public x10.core.fun.VoidFun_0_0 xop;
        
        
        //#line 424 "x10/interop/Java8.x10"
        public void run() {
            
            //#line 424 "x10/interop/Java8.x10"
            final x10.core.fun.VoidFun_0_0 t$129833 = x10.interop.Java8.Anonymous$17695.this.xop;
            
            //#line 424 "x10/interop/Java8.x10"
            ((x10.core.fun.VoidFun_0_0)t$129833).$apply();
        }
        
        
        //#line 423 "x10/interop/Java8.x10"
        // creation method for java code (1-phase java constructor)
        public Anonymous$17695(final x10.core.fun.VoidFun_0_0 xop) {
            this((java.lang.System[]) null);
            x10$interop$Java8$Anonymous$17695$$init$S(xop);
        }
        
        // constructor for non-virtual call
        final public x10.interop.Java8.Anonymous$17695 x10$interop$Java8$Anonymous$17695$$init$S(final x10.core.fun.VoidFun_0_0 xop) {
             {
                
                //#line 422 "x10/interop/Java8.x10"
                this.xop = xop;
            }
            return this;
        }
        
    }
    
    @x10.runtime.impl.java.X10Generated
    final public static class $Closure$100 extends x10.core.Ref implements x10.core.fun.Fun_0_2, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<$Closure$100> $RTT = 
            x10.rtt.StaticFunType.<$Closure$100> make($Closure$100.class,
                                                      new x10.rtt.Type[] {
                                                          x10.rtt.ParameterizedType.make(x10.core.fun.Fun_0_2.$RTT, x10.rtt.Types.INT, x10.rtt.Types.INT, x10.rtt.Types.INT)
                                                      });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static x10.serialization.X10JavaSerializable $_deserialize_body(x10.interop.Java8.$Closure$100 $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            $_obj.op = $deserializer.readObject();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.interop.Java8.$Closure$100 $_obj = new x10.interop.Java8.$Closure$100((java.lang.System[]) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            $serializer.write(this.op);
            
        }
        
        // constructor just for allocation
        public $Closure$100(final java.lang.System[] $dummy) {
            
        }
        
        // dispatcher for method abstract public (Z1,Z2)=>U.operator()(a1:Z1, a2:Z2):U
        public java.lang.Object $apply(final java.lang.Object a1, final x10.rtt.Type t1, final java.lang.Object a2, final x10.rtt.Type t2) {
            return x10.core.Int.$box($apply$O(x10.core.Int.$unbox(a1), x10.core.Int.$unbox(a2)));
            
        }
        
        // dispatcher for method abstract public (Z1,Z2)=>U.operator()(a1:Z1, a2:Z2):U
        public int $apply$I(final java.lang.Object a1, final x10.rtt.Type t1, final java.lang.Object a2, final x10.rtt.Type t2) {
            return $apply$O(x10.core.Int.$unbox(a1), x10.core.Int.$unbox(a2));
            
        }
        
        
    
        
        public int $apply$O(final int left, final int right) {
            
            //#line 27 "x10/interop/Java8.x10"
            final int t$129644 = this.op.applyAsInt((int)(left), (int)(right));
            
            //#line 27 "x10/interop/Java8.x10"
            return t$129644;
        }
        
        public java.util.function.IntBinaryOperator op;
        
        public $Closure$100(final java.util.function.IntBinaryOperator op) {
             {
                this.op = ((java.util.function.IntBinaryOperator)(op));
            }
        }
        
    }
    
    @x10.runtime.impl.java.X10Generated
    final public static class $Closure$101 extends x10.core.Ref implements x10.core.fun.Fun_0_2, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<$Closure$101> $RTT = 
            x10.rtt.StaticFunType.<$Closure$101> make($Closure$101.class,
                                                      new x10.rtt.Type[] {
                                                          x10.rtt.ParameterizedType.make(x10.core.fun.Fun_0_2.$RTT, x10.rtt.Types.LONG, x10.rtt.Types.LONG, x10.rtt.Types.LONG)
                                                      });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static x10.serialization.X10JavaSerializable $_deserialize_body(x10.interop.Java8.$Closure$101 $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            $_obj.op = $deserializer.readObject();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.interop.Java8.$Closure$101 $_obj = new x10.interop.Java8.$Closure$101((java.lang.System[]) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            $serializer.write(this.op);
            
        }
        
        // constructor just for allocation
        public $Closure$101(final java.lang.System[] $dummy) {
            
        }
        
        // dispatcher for method abstract public (Z1,Z2)=>U.operator()(a1:Z1, a2:Z2):U
        public java.lang.Object $apply(final java.lang.Object a1, final x10.rtt.Type t1, final java.lang.Object a2, final x10.rtt.Type t2) {
            return x10.core.Long.$box($apply$O(x10.core.Long.$unbox(a1), x10.core.Long.$unbox(a2)));
            
        }
        
        // dispatcher for method abstract public (Z1,Z2)=>U.operator()(a1:Z1, a2:Z2):U
        public long $apply$J(final java.lang.Object a1, final x10.rtt.Type t1, final java.lang.Object a2, final x10.rtt.Type t2) {
            return $apply$O(x10.core.Long.$unbox(a1), x10.core.Long.$unbox(a2));
            
        }
        
        
    
        
        public long $apply$O(final long left, final long right) {
            
            //#line 30 "x10/interop/Java8.x10"
            final long t$129646 = this.op.applyAsLong((long)(left), (long)(right));
            
            //#line 30 "x10/interop/Java8.x10"
            return t$129646;
        }
        
        public java.util.function.LongBinaryOperator op;
        
        public $Closure$101(final java.util.function.LongBinaryOperator op) {
             {
                this.op = ((java.util.function.LongBinaryOperator)(op));
            }
        }
        
    }
    
    @x10.runtime.impl.java.X10Generated
    final public static class $Closure$102 extends x10.core.Ref implements x10.core.fun.Fun_0_2, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<$Closure$102> $RTT = 
            x10.rtt.StaticFunType.<$Closure$102> make($Closure$102.class,
                                                      new x10.rtt.Type[] {
                                                          x10.rtt.ParameterizedType.make(x10.core.fun.Fun_0_2.$RTT, x10.rtt.Types.DOUBLE, x10.rtt.Types.DOUBLE, x10.rtt.Types.DOUBLE)
                                                      });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static x10.serialization.X10JavaSerializable $_deserialize_body(x10.interop.Java8.$Closure$102 $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            $_obj.op = $deserializer.readObject();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.interop.Java8.$Closure$102 $_obj = new x10.interop.Java8.$Closure$102((java.lang.System[]) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            $serializer.write(this.op);
            
        }
        
        // constructor just for allocation
        public $Closure$102(final java.lang.System[] $dummy) {
            
        }
        
        // dispatcher for method abstract public (Z1,Z2)=>U.operator()(a1:Z1, a2:Z2):U
        public java.lang.Object $apply(final java.lang.Object a1, final x10.rtt.Type t1, final java.lang.Object a2, final x10.rtt.Type t2) {
            return x10.core.Double.$box($apply$O(x10.core.Double.$unbox(a1), x10.core.Double.$unbox(a2)));
            
        }
        
        // dispatcher for method abstract public (Z1,Z2)=>U.operator()(a1:Z1, a2:Z2):U
        public double $apply$D(final java.lang.Object a1, final x10.rtt.Type t1, final java.lang.Object a2, final x10.rtt.Type t2) {
            return $apply$O(x10.core.Double.$unbox(a1), x10.core.Double.$unbox(a2));
            
        }
        
        
    
        
        public double $apply$O(final double left, final double right) {
            
            //#line 33 "x10/interop/Java8.x10"
            final double t$129648 = this.op.applyAsDouble((double)(left), (double)(right));
            
            //#line 33 "x10/interop/Java8.x10"
            return t$129648;
        }
        
        public java.util.function.DoubleBinaryOperator op;
        
        public $Closure$102(final java.util.function.DoubleBinaryOperator op) {
             {
                this.op = ((java.util.function.DoubleBinaryOperator)(op));
            }
        }
        
    }
    
    @x10.runtime.impl.java.X10Generated
    final public static class $Closure$103<$T> extends x10.core.Ref implements x10.core.fun.Fun_0_2, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<$Closure$103> $RTT = 
            x10.rtt.StaticFunType.<$Closure$103> make($Closure$103.class,
                                                      1,
                                                      new x10.rtt.Type[] {
                                                          x10.rtt.ParameterizedType.make(x10.core.fun.Fun_0_2.$RTT, x10.rtt.UnresolvedType.PARAM(0), x10.rtt.UnresolvedType.PARAM(0), x10.rtt.UnresolvedType.PARAM(0))
                                                      });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { if (i == 0) return $T; return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static <$T> x10.serialization.X10JavaSerializable $_deserialize_body(x10.interop.Java8.$Closure$103<$T> $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            $_obj.$T = (x10.rtt.Type) $deserializer.readObject();
            $_obj.op = $deserializer.readObject();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.interop.Java8.$Closure$103 $_obj = new x10.interop.Java8.$Closure$103((java.lang.System[]) null, (x10.rtt.Type) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            $serializer.write(this.$T);
            $serializer.write(this.op);
            
        }
        
        // constructor just for allocation
        public $Closure$103(final java.lang.System[] $dummy, final x10.rtt.Type $T) {
            x10.interop.Java8.$Closure$103.$initParams(this, $T);
            
        }
        
        // dispatcher for method abstract public (Z1,Z2)=>U.operator()(a1:Z1, a2:Z2):U
        public java.lang.Object $apply(final java.lang.Object a1, final x10.rtt.Type t1, final java.lang.Object a2, final x10.rtt.Type t2) {
            return $apply__0x10$interop$Java8$$Closure$103$$T__1x10$interop$Java8$$Closure$103$$T$G(($T)a1, ($T)a2);
            
        }
        
        private x10.rtt.Type $T;
        
        // initializer of type parameters
        public static void $initParams(final $Closure$103 $this, final x10.rtt.Type $T) {
            $this.$T = $T;
            
        }
        
    
        
        public $T $apply__0x10$interop$Java8$$Closure$103$$T__1x10$interop$Java8$$Closure$103$$T$G(final $T left, final $T right) {
            
            //#line 36 "x10/interop/Java8.x10"
            final java.lang.Object t$129650 = this.op.apply(((java.lang.Object)(left)), ((java.lang.Object)(right)));
            
            //#line 36 "x10/interop/Java8.x10"
            final $T t$129651 = (($T)(x10.rtt.Types.<$T> cast(t$129650,$T)));
            
            //#line 36 "x10/interop/Java8.x10"
            return t$129651;
        }
        
        public java.util.function.BinaryOperator op;
        
        public $Closure$103(final x10.rtt.Type $T, final java.util.function.BinaryOperator op) {
            x10.interop.Java8.$Closure$103.$initParams(this, $T);
             {
                ((x10.interop.Java8.$Closure$103<$T>)this).op = ((java.util.function.BinaryOperator)(op));
            }
        }
        
    }
    
    @x10.runtime.impl.java.X10Generated
    final public static class $Closure$104 extends x10.core.Ref implements x10.core.fun.Fun_0_1, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<$Closure$104> $RTT = 
            x10.rtt.StaticFunType.<$Closure$104> make($Closure$104.class,
                                                      new x10.rtt.Type[] {
                                                          x10.rtt.ParameterizedType.make(x10.core.fun.Fun_0_1.$RTT, x10.rtt.Types.INT, x10.rtt.Types.INT)
                                                      });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static x10.serialization.X10JavaSerializable $_deserialize_body(x10.interop.Java8.$Closure$104 $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            $_obj.op = $deserializer.readObject();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.interop.Java8.$Closure$104 $_obj = new x10.interop.Java8.$Closure$104((java.lang.System[]) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            $serializer.write(this.op);
            
        }
        
        // constructor just for allocation
        public $Closure$104(final java.lang.System[] $dummy) {
            
        }
        
        // dispatcher for method abstract public (Z1)=>U.operator()(a1:Z1):U
        public java.lang.Object $apply(final java.lang.Object a1, final x10.rtt.Type t1) {
            return x10.core.Int.$box($apply$O(x10.core.Int.$unbox(a1)));
            
        }
        
        // dispatcher for method abstract public (Z1)=>U.operator()(a1:Z1):U
        public int $apply$I(final java.lang.Object a1, final x10.rtt.Type t1) {
            return $apply$O(x10.core.Int.$unbox(a1));
            
        }
        
        
    
        
        public int $apply$O(final int operand) {
            
            //#line 63 "x10/interop/Java8.x10"
            final int t$129653 = this.op.applyAsInt((int)(operand));
            
            //#line 63 "x10/interop/Java8.x10"
            return t$129653;
        }
        
        public java.util.function.IntUnaryOperator op;
        
        public $Closure$104(final java.util.function.IntUnaryOperator op) {
             {
                this.op = ((java.util.function.IntUnaryOperator)(op));
            }
        }
        
    }
    
    @x10.runtime.impl.java.X10Generated
    final public static class $Closure$105 extends x10.core.Ref implements x10.core.fun.Fun_0_1, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<$Closure$105> $RTT = 
            x10.rtt.StaticFunType.<$Closure$105> make($Closure$105.class,
                                                      new x10.rtt.Type[] {
                                                          x10.rtt.ParameterizedType.make(x10.core.fun.Fun_0_1.$RTT, x10.rtt.Types.LONG, x10.rtt.Types.LONG)
                                                      });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static x10.serialization.X10JavaSerializable $_deserialize_body(x10.interop.Java8.$Closure$105 $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            $_obj.op = $deserializer.readObject();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.interop.Java8.$Closure$105 $_obj = new x10.interop.Java8.$Closure$105((java.lang.System[]) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            $serializer.write(this.op);
            
        }
        
        // constructor just for allocation
        public $Closure$105(final java.lang.System[] $dummy) {
            
        }
        
        // dispatcher for method abstract public (Z1)=>U.operator()(a1:Z1):U
        public java.lang.Object $apply(final java.lang.Object a1, final x10.rtt.Type t1) {
            return x10.core.Long.$box($apply$O(x10.core.Long.$unbox(a1)));
            
        }
        
        // dispatcher for method abstract public (Z1)=>U.operator()(a1:Z1):U
        public long $apply$J(final java.lang.Object a1, final x10.rtt.Type t1) {
            return $apply$O(x10.core.Long.$unbox(a1));
            
        }
        
        
    
        
        public long $apply$O(final long operand) {
            
            //#line 66 "x10/interop/Java8.x10"
            final long t$129655 = this.op.applyAsLong((long)(operand));
            
            //#line 66 "x10/interop/Java8.x10"
            return t$129655;
        }
        
        public java.util.function.LongUnaryOperator op;
        
        public $Closure$105(final java.util.function.LongUnaryOperator op) {
             {
                this.op = ((java.util.function.LongUnaryOperator)(op));
            }
        }
        
    }
    
    @x10.runtime.impl.java.X10Generated
    final public static class $Closure$106 extends x10.core.Ref implements x10.core.fun.Fun_0_1, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<$Closure$106> $RTT = 
            x10.rtt.StaticFunType.<$Closure$106> make($Closure$106.class,
                                                      new x10.rtt.Type[] {
                                                          x10.rtt.ParameterizedType.make(x10.core.fun.Fun_0_1.$RTT, x10.rtt.Types.DOUBLE, x10.rtt.Types.DOUBLE)
                                                      });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static x10.serialization.X10JavaSerializable $_deserialize_body(x10.interop.Java8.$Closure$106 $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            $_obj.op = $deserializer.readObject();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.interop.Java8.$Closure$106 $_obj = new x10.interop.Java8.$Closure$106((java.lang.System[]) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            $serializer.write(this.op);
            
        }
        
        // constructor just for allocation
        public $Closure$106(final java.lang.System[] $dummy) {
            
        }
        
        // dispatcher for method abstract public (Z1)=>U.operator()(a1:Z1):U
        public java.lang.Object $apply(final java.lang.Object a1, final x10.rtt.Type t1) {
            return x10.core.Double.$box($apply$O(x10.core.Double.$unbox(a1)));
            
        }
        
        // dispatcher for method abstract public (Z1)=>U.operator()(a1:Z1):U
        public double $apply$D(final java.lang.Object a1, final x10.rtt.Type t1) {
            return $apply$O(x10.core.Double.$unbox(a1));
            
        }
        
        
    
        
        public double $apply$O(final double operand) {
            
            //#line 69 "x10/interop/Java8.x10"
            final double t$129657 = this.op.applyAsDouble((double)(operand));
            
            //#line 69 "x10/interop/Java8.x10"
            return t$129657;
        }
        
        public java.util.function.DoubleUnaryOperator op;
        
        public $Closure$106(final java.util.function.DoubleUnaryOperator op) {
             {
                this.op = ((java.util.function.DoubleUnaryOperator)(op));
            }
        }
        
    }
    
    @x10.runtime.impl.java.X10Generated
    final public static class $Closure$107<$T> extends x10.core.Ref implements x10.core.fun.Fun_0_1, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<$Closure$107> $RTT = 
            x10.rtt.StaticFunType.<$Closure$107> make($Closure$107.class,
                                                      1,
                                                      new x10.rtt.Type[] {
                                                          x10.rtt.ParameterizedType.make(x10.core.fun.Fun_0_1.$RTT, x10.rtt.UnresolvedType.PARAM(0), x10.rtt.UnresolvedType.PARAM(0))
                                                      });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { if (i == 0) return $T; return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static <$T> x10.serialization.X10JavaSerializable $_deserialize_body(x10.interop.Java8.$Closure$107<$T> $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            $_obj.$T = (x10.rtt.Type) $deserializer.readObject();
            $_obj.op = $deserializer.readObject();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.interop.Java8.$Closure$107 $_obj = new x10.interop.Java8.$Closure$107((java.lang.System[]) null, (x10.rtt.Type) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            $serializer.write(this.$T);
            $serializer.write(this.op);
            
        }
        
        // constructor just for allocation
        public $Closure$107(final java.lang.System[] $dummy, final x10.rtt.Type $T) {
            x10.interop.Java8.$Closure$107.$initParams(this, $T);
            
        }
        
        // dispatcher for method abstract public (Z1)=>U.operator()(a1:Z1):U
        public java.lang.Object $apply(final java.lang.Object a1, final x10.rtt.Type t1) {
            return $apply__0x10$interop$Java8$$Closure$107$$T$G(($T)a1);
            
        }
        
        private x10.rtt.Type $T;
        
        // initializer of type parameters
        public static void $initParams(final $Closure$107 $this, final x10.rtt.Type $T) {
            $this.$T = $T;
            
        }
        
    
        
        public $T $apply__0x10$interop$Java8$$Closure$107$$T$G(final $T operand) {
            
            //#line 72 "x10/interop/Java8.x10"
            final java.lang.Object t$129659 = this.op.apply(((java.lang.Object)(operand)));
            
            //#line 72 "x10/interop/Java8.x10"
            final $T t$129660 = (($T)(x10.rtt.Types.<$T> cast(t$129659,$T)));
            
            //#line 72 "x10/interop/Java8.x10"
            return t$129660;
        }
        
        public java.util.function.UnaryOperator op;
        
        public $Closure$107(final x10.rtt.Type $T, final java.util.function.UnaryOperator op) {
            x10.interop.Java8.$Closure$107.$initParams(this, $T);
             {
                ((x10.interop.Java8.$Closure$107<$T>)this).op = ((java.util.function.UnaryOperator)(op));
            }
        }
        
    }
    
    @x10.runtime.impl.java.X10Generated
    final public static class $Closure$108 extends x10.core.Ref implements x10.core.fun.Fun_0_1, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<$Closure$108> $RTT = 
            x10.rtt.StaticFunType.<$Closure$108> make($Closure$108.class,
                                                      new x10.rtt.Type[] {
                                                          x10.rtt.ParameterizedType.make(x10.core.fun.Fun_0_1.$RTT, x10.rtt.Types.INT, x10.rtt.Types.BOOLEAN)
                                                      });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static x10.serialization.X10JavaSerializable $_deserialize_body(x10.interop.Java8.$Closure$108 $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            $_obj.op = $deserializer.readObject();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.interop.Java8.$Closure$108 $_obj = new x10.interop.Java8.$Closure$108((java.lang.System[]) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            $serializer.write(this.op);
            
        }
        
        // constructor just for allocation
        public $Closure$108(final java.lang.System[] $dummy) {
            
        }
        
        // dispatcher for method abstract public (Z1)=>U.operator()(a1:Z1):U
        public java.lang.Object $apply(final java.lang.Object a1, final x10.rtt.Type t1) {
            return x10.core.Boolean.$box($apply$O(x10.core.Int.$unbox(a1)));
            
        }
        
        // dispatcher for method abstract public (Z1)=>U.operator()(a1:Z1):U
        public boolean $apply$Z(final java.lang.Object a1, final x10.rtt.Type t1) {
            return $apply$O(x10.core.Int.$unbox(a1));
            
        }
        
        
    
        
        public boolean $apply$O(final int value) {
            
            //#line 99 "x10/interop/Java8.x10"
            final boolean t$129662 = this.op.test((int)(value));
            
            //#line 99 "x10/interop/Java8.x10"
            return t$129662;
        }
        
        public java.util.function.IntPredicate op;
        
        public $Closure$108(final java.util.function.IntPredicate op) {
             {
                this.op = ((java.util.function.IntPredicate)(op));
            }
        }
        
    }
    
    @x10.runtime.impl.java.X10Generated
    final public static class $Closure$109 extends x10.core.Ref implements x10.core.fun.Fun_0_1, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<$Closure$109> $RTT = 
            x10.rtt.StaticFunType.<$Closure$109> make($Closure$109.class,
                                                      new x10.rtt.Type[] {
                                                          x10.rtt.ParameterizedType.make(x10.core.fun.Fun_0_1.$RTT, x10.rtt.Types.LONG, x10.rtt.Types.BOOLEAN)
                                                      });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static x10.serialization.X10JavaSerializable $_deserialize_body(x10.interop.Java8.$Closure$109 $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            $_obj.op = $deserializer.readObject();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.interop.Java8.$Closure$109 $_obj = new x10.interop.Java8.$Closure$109((java.lang.System[]) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            $serializer.write(this.op);
            
        }
        
        // constructor just for allocation
        public $Closure$109(final java.lang.System[] $dummy) {
            
        }
        
        // dispatcher for method abstract public (Z1)=>U.operator()(a1:Z1):U
        public java.lang.Object $apply(final java.lang.Object a1, final x10.rtt.Type t1) {
            return x10.core.Boolean.$box($apply$O(x10.core.Long.$unbox(a1)));
            
        }
        
        // dispatcher for method abstract public (Z1)=>U.operator()(a1:Z1):U
        public boolean $apply$Z(final java.lang.Object a1, final x10.rtt.Type t1) {
            return $apply$O(x10.core.Long.$unbox(a1));
            
        }
        
        
    
        
        public boolean $apply$O(final long value) {
            
            //#line 102 "x10/interop/Java8.x10"
            final boolean t$129664 = this.op.test((long)(value));
            
            //#line 102 "x10/interop/Java8.x10"
            return t$129664;
        }
        
        public java.util.function.LongPredicate op;
        
        public $Closure$109(final java.util.function.LongPredicate op) {
             {
                this.op = ((java.util.function.LongPredicate)(op));
            }
        }
        
    }
    
    @x10.runtime.impl.java.X10Generated
    final public static class $Closure$110 extends x10.core.Ref implements x10.core.fun.Fun_0_1, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<$Closure$110> $RTT = 
            x10.rtt.StaticFunType.<$Closure$110> make($Closure$110.class,
                                                      new x10.rtt.Type[] {
                                                          x10.rtt.ParameterizedType.make(x10.core.fun.Fun_0_1.$RTT, x10.rtt.Types.DOUBLE, x10.rtt.Types.BOOLEAN)
                                                      });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static x10.serialization.X10JavaSerializable $_deserialize_body(x10.interop.Java8.$Closure$110 $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            $_obj.op = $deserializer.readObject();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.interop.Java8.$Closure$110 $_obj = new x10.interop.Java8.$Closure$110((java.lang.System[]) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            $serializer.write(this.op);
            
        }
        
        // constructor just for allocation
        public $Closure$110(final java.lang.System[] $dummy) {
            
        }
        
        // dispatcher for method abstract public (Z1)=>U.operator()(a1:Z1):U
        public java.lang.Object $apply(final java.lang.Object a1, final x10.rtt.Type t1) {
            return x10.core.Boolean.$box($apply$O(x10.core.Double.$unbox(a1)));
            
        }
        
        // dispatcher for method abstract public (Z1)=>U.operator()(a1:Z1):U
        public boolean $apply$Z(final java.lang.Object a1, final x10.rtt.Type t1) {
            return $apply$O(x10.core.Double.$unbox(a1));
            
        }
        
        
    
        
        public boolean $apply$O(final double value) {
            
            //#line 105 "x10/interop/Java8.x10"
            final boolean t$129666 = this.op.test((double)(value));
            
            //#line 105 "x10/interop/Java8.x10"
            return t$129666;
        }
        
        public java.util.function.DoublePredicate op;
        
        public $Closure$110(final java.util.function.DoublePredicate op) {
             {
                this.op = ((java.util.function.DoublePredicate)(op));
            }
        }
        
    }
    
    @x10.runtime.impl.java.X10Generated
    final public static class $Closure$111<$T> extends x10.core.Ref implements x10.core.fun.Fun_0_1, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<$Closure$111> $RTT = 
            x10.rtt.StaticFunType.<$Closure$111> make($Closure$111.class,
                                                      1,
                                                      new x10.rtt.Type[] {
                                                          x10.rtt.ParameterizedType.make(x10.core.fun.Fun_0_1.$RTT, x10.rtt.UnresolvedType.PARAM(0), x10.rtt.Types.BOOLEAN)
                                                      });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { if (i == 0) return $T; return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static <$T> x10.serialization.X10JavaSerializable $_deserialize_body(x10.interop.Java8.$Closure$111<$T> $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            $_obj.$T = (x10.rtt.Type) $deserializer.readObject();
            $_obj.op = $deserializer.readObject();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.interop.Java8.$Closure$111 $_obj = new x10.interop.Java8.$Closure$111((java.lang.System[]) null, (x10.rtt.Type) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            $serializer.write(this.$T);
            $serializer.write(this.op);
            
        }
        
        // constructor just for allocation
        public $Closure$111(final java.lang.System[] $dummy, final x10.rtt.Type $T) {
            x10.interop.Java8.$Closure$111.$initParams(this, $T);
            
        }
        
        // dispatcher for method abstract public (Z1)=>U.operator()(a1:Z1):U
        public java.lang.Object $apply(final java.lang.Object a1, final x10.rtt.Type t1) {
            return x10.core.Boolean.$box($apply__0x10$interop$Java8$$Closure$111$$T$O(($T)a1));
            
        }
        
        // dispatcher for method abstract public (Z1)=>U.operator()(a1:Z1):U
        public boolean $apply$Z(final java.lang.Object a1, final x10.rtt.Type t1) {
            return $apply__0x10$interop$Java8$$Closure$111$$T$O(($T)a1);
            
        }
        
        private x10.rtt.Type $T;
        
        // initializer of type parameters
        public static void $initParams(final $Closure$111 $this, final x10.rtt.Type $T) {
            $this.$T = $T;
            
        }
        
    
        
        public boolean $apply__0x10$interop$Java8$$Closure$111$$T$O(final $T value) {
            
            //#line 108 "x10/interop/Java8.x10"
            final boolean t$129668 = this.op.test(((java.lang.Object)(value)));
            
            //#line 108 "x10/interop/Java8.x10"
            return t$129668;
        }
        
        public java.util.function.Predicate op;
        
        public $Closure$111(final x10.rtt.Type $T, final java.util.function.Predicate op) {
            x10.interop.Java8.$Closure$111.$initParams(this, $T);
             {
                ((x10.interop.Java8.$Closure$111<$T>)this).op = ((java.util.function.Predicate)(op));
            }
        }
        
    }
    
    @x10.runtime.impl.java.X10Generated
    final public static class $Closure$112<$T, $U> extends x10.core.Ref implements x10.core.fun.Fun_0_2, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<$Closure$112> $RTT = 
            x10.rtt.StaticFunType.<$Closure$112> make($Closure$112.class,
                                                      2,
                                                      new x10.rtt.Type[] {
                                                          x10.rtt.ParameterizedType.make(x10.core.fun.Fun_0_2.$RTT, x10.rtt.UnresolvedType.PARAM(0), x10.rtt.UnresolvedType.PARAM(1), x10.rtt.Types.BOOLEAN)
                                                      });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { if (i == 0) return $T; if (i == 1) return $U; return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static <$T, $U> x10.serialization.X10JavaSerializable $_deserialize_body(x10.interop.Java8.$Closure$112<$T, $U> $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            $_obj.$T = (x10.rtt.Type) $deserializer.readObject();
            $_obj.$U = (x10.rtt.Type) $deserializer.readObject();
            $_obj.op = $deserializer.readObject();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.interop.Java8.$Closure$112 $_obj = new x10.interop.Java8.$Closure$112((java.lang.System[]) null, (x10.rtt.Type) null, (x10.rtt.Type) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            $serializer.write(this.$T);
            $serializer.write(this.$U);
            $serializer.write(this.op);
            
        }
        
        // constructor just for allocation
        public $Closure$112(final java.lang.System[] $dummy, final x10.rtt.Type $T, final x10.rtt.Type $U) {
            x10.interop.Java8.$Closure$112.$initParams(this, $T, $U);
            
        }
        
        // dispatcher for method abstract public (Z1,Z2)=>U.operator()(a1:Z1, a2:Z2):U
        public java.lang.Object $apply(final java.lang.Object a1, final x10.rtt.Type t1, final java.lang.Object a2, final x10.rtt.Type t2) {
            return x10.core.Boolean.$box($apply__0x10$interop$Java8$$Closure$112$$T__1x10$interop$Java8$$Closure$112$$U$O(($T)a1, ($U)a2));
            
        }
        
        // dispatcher for method abstract public (Z1,Z2)=>U.operator()(a1:Z1, a2:Z2):U
        public boolean $apply$Z(final java.lang.Object a1, final x10.rtt.Type t1, final java.lang.Object a2, final x10.rtt.Type t2) {
            return $apply__0x10$interop$Java8$$Closure$112$$T__1x10$interop$Java8$$Closure$112$$U$O(($T)a1, ($U)a2);
            
        }
        
        private x10.rtt.Type $T;
        private x10.rtt.Type $U;
        
        // initializer of type parameters
        public static void $initParams(final $Closure$112 $this, final x10.rtt.Type $T, final x10.rtt.Type $U) {
            $this.$T = $T;
            $this.$U = $U;
            
        }
        
    
        
        public boolean $apply__0x10$interop$Java8$$Closure$112$$T__1x10$interop$Java8$$Closure$112$$U$O(final $T t, final $U u) {
            
            //#line 135 "x10/interop/Java8.x10"
            final boolean t$129670 = this.op.test(((java.lang.Object)(t)), ((java.lang.Object)(u)));
            
            //#line 135 "x10/interop/Java8.x10"
            return t$129670;
        }
        
        public java.util.function.BiPredicate op;
        
        public $Closure$112(final x10.rtt.Type $T, final x10.rtt.Type $U, final java.util.function.BiPredicate op) {
            x10.interop.Java8.$Closure$112.$initParams(this, $T, $U);
             {
                ((x10.interop.Java8.$Closure$112<$T, $U>)this).op = ((java.util.function.BiPredicate)(op));
            }
        }
        
    }
    
    @x10.runtime.impl.java.X10Generated
    final public static class $Closure$113 extends x10.core.Ref implements x10.core.fun.VoidFun_0_1, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<$Closure$113> $RTT = 
            x10.rtt.StaticVoidFunType.<$Closure$113> make($Closure$113.class,
                                                          new x10.rtt.Type[] {
                                                              x10.rtt.ParameterizedType.make(x10.core.fun.VoidFun_0_1.$RTT, x10.rtt.Types.INT)
                                                          });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static x10.serialization.X10JavaSerializable $_deserialize_body(x10.interop.Java8.$Closure$113 $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            $_obj.op = $deserializer.readObject();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.interop.Java8.$Closure$113 $_obj = new x10.interop.Java8.$Closure$113((java.lang.System[]) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            $serializer.write(this.op);
            
        }
        
        // constructor just for allocation
        public $Closure$113(final java.lang.System[] $dummy) {
            
        }
        
        // dispatcher for method abstract public (Z1)=>void.operator()(a1:Z1):void
        public java.lang.Object $apply(final java.lang.Object a1, final x10.rtt.Type t1) {
            $apply(x10.core.Int.$unbox(a1)); return null;
            
        }
        
        // dispatcher for method abstract public (Z1)=>void.operator()(a1:Z1):void
        public void $apply$V(final java.lang.Object a1, final x10.rtt.Type t1) {
            $apply(x10.core.Int.$unbox(a1));
            
        }
        
        
    
        
        public void $apply(final int value) {
            
            //#line 147 "x10/interop/Java8.x10"
            this.op.accept((int)(value));
        }
        
        public java.util.function.IntConsumer op;
        
        public $Closure$113(final java.util.function.IntConsumer op) {
             {
                this.op = ((java.util.function.IntConsumer)(op));
            }
        }
        
    }
    
    @x10.runtime.impl.java.X10Generated
    final public static class $Closure$114 extends x10.core.Ref implements x10.core.fun.VoidFun_0_1, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<$Closure$114> $RTT = 
            x10.rtt.StaticVoidFunType.<$Closure$114> make($Closure$114.class,
                                                          new x10.rtt.Type[] {
                                                              x10.rtt.ParameterizedType.make(x10.core.fun.VoidFun_0_1.$RTT, x10.rtt.Types.LONG)
                                                          });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static x10.serialization.X10JavaSerializable $_deserialize_body(x10.interop.Java8.$Closure$114 $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            $_obj.op = $deserializer.readObject();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.interop.Java8.$Closure$114 $_obj = new x10.interop.Java8.$Closure$114((java.lang.System[]) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            $serializer.write(this.op);
            
        }
        
        // constructor just for allocation
        public $Closure$114(final java.lang.System[] $dummy) {
            
        }
        
        // dispatcher for method abstract public (Z1)=>void.operator()(a1:Z1):void
        public java.lang.Object $apply(final java.lang.Object a1, final x10.rtt.Type t1) {
            $apply(x10.core.Long.$unbox(a1)); return null;
            
        }
        
        // dispatcher for method abstract public (Z1)=>void.operator()(a1:Z1):void
        public void $apply$V(final java.lang.Object a1, final x10.rtt.Type t1) {
            $apply(x10.core.Long.$unbox(a1));
            
        }
        
        
    
        
        public void $apply(final long value) {
            
            //#line 150 "x10/interop/Java8.x10"
            this.op.accept((long)(value));
        }
        
        public java.util.function.LongConsumer op;
        
        public $Closure$114(final java.util.function.LongConsumer op) {
             {
                this.op = ((java.util.function.LongConsumer)(op));
            }
        }
        
    }
    
    @x10.runtime.impl.java.X10Generated
    final public static class $Closure$115 extends x10.core.Ref implements x10.core.fun.VoidFun_0_1, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<$Closure$115> $RTT = 
            x10.rtt.StaticVoidFunType.<$Closure$115> make($Closure$115.class,
                                                          new x10.rtt.Type[] {
                                                              x10.rtt.ParameterizedType.make(x10.core.fun.VoidFun_0_1.$RTT, x10.rtt.Types.DOUBLE)
                                                          });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static x10.serialization.X10JavaSerializable $_deserialize_body(x10.interop.Java8.$Closure$115 $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            $_obj.op = $deserializer.readObject();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.interop.Java8.$Closure$115 $_obj = new x10.interop.Java8.$Closure$115((java.lang.System[]) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            $serializer.write(this.op);
            
        }
        
        // constructor just for allocation
        public $Closure$115(final java.lang.System[] $dummy) {
            
        }
        
        // dispatcher for method abstract public (Z1)=>void.operator()(a1:Z1):void
        public java.lang.Object $apply(final java.lang.Object a1, final x10.rtt.Type t1) {
            $apply(x10.core.Double.$unbox(a1)); return null;
            
        }
        
        // dispatcher for method abstract public (Z1)=>void.operator()(a1:Z1):void
        public void $apply$V(final java.lang.Object a1, final x10.rtt.Type t1) {
            $apply(x10.core.Double.$unbox(a1));
            
        }
        
        
    
        
        public void $apply(final double value) {
            
            //#line 153 "x10/interop/Java8.x10"
            this.op.accept((double)(value));
        }
        
        public java.util.function.DoubleConsumer op;
        
        public $Closure$115(final java.util.function.DoubleConsumer op) {
             {
                this.op = ((java.util.function.DoubleConsumer)(op));
            }
        }
        
    }
    
    @x10.runtime.impl.java.X10Generated
    final public static class $Closure$116<$T> extends x10.core.Ref implements x10.core.fun.VoidFun_0_1, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<$Closure$116> $RTT = 
            x10.rtt.StaticVoidFunType.<$Closure$116> make($Closure$116.class,
                                                          1,
                                                          new x10.rtt.Type[] {
                                                              x10.rtt.ParameterizedType.make(x10.core.fun.VoidFun_0_1.$RTT, x10.rtt.UnresolvedType.PARAM(0))
                                                          });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { if (i == 0) return $T; return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static <$T> x10.serialization.X10JavaSerializable $_deserialize_body(x10.interop.Java8.$Closure$116<$T> $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            $_obj.$T = (x10.rtt.Type) $deserializer.readObject();
            $_obj.op = $deserializer.readObject();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.interop.Java8.$Closure$116 $_obj = new x10.interop.Java8.$Closure$116((java.lang.System[]) null, (x10.rtt.Type) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            $serializer.write(this.$T);
            $serializer.write(this.op);
            
        }
        
        // constructor just for allocation
        public $Closure$116(final java.lang.System[] $dummy, final x10.rtt.Type $T) {
            x10.interop.Java8.$Closure$116.$initParams(this, $T);
            
        }
        
        // dispatcher for method abstract public (Z1)=>void.operator()(a1:Z1):void
        public java.lang.Object $apply(final java.lang.Object a1, final x10.rtt.Type t1) {
            $apply__0x10$interop$Java8$$Closure$116$$T(($T)a1); return null;
            
        }
        
        // dispatcher for method abstract public (Z1)=>void.operator()(a1:Z1):void
        public void $apply$V(final java.lang.Object a1, final x10.rtt.Type t1) {
            $apply__0x10$interop$Java8$$Closure$116$$T(($T)a1);
            
        }
        
        private x10.rtt.Type $T;
        
        // initializer of type parameters
        public static void $initParams(final $Closure$116 $this, final x10.rtt.Type $T) {
            $this.$T = $T;
            
        }
        
    
        
        public void $apply__0x10$interop$Java8$$Closure$116$$T(final $T value) {
            
            //#line 156 "x10/interop/Java8.x10"
            this.op.accept(((java.lang.Object)(value)));
        }
        
        public java.util.function.Consumer op;
        
        public $Closure$116(final x10.rtt.Type $T, final java.util.function.Consumer op) {
            x10.interop.Java8.$Closure$116.$initParams(this, $T);
             {
                ((x10.interop.Java8.$Closure$116<$T>)this).op = ((java.util.function.Consumer)(op));
            }
        }
        
    }
    
    @x10.runtime.impl.java.X10Generated
    final public static class $Closure$117<$T> extends x10.core.Ref implements x10.core.fun.VoidFun_0_2, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<$Closure$117> $RTT = 
            x10.rtt.StaticVoidFunType.<$Closure$117> make($Closure$117.class,
                                                          1,
                                                          new x10.rtt.Type[] {
                                                              x10.rtt.ParameterizedType.make(x10.core.fun.VoidFun_0_2.$RTT, x10.rtt.UnresolvedType.PARAM(0), x10.rtt.Types.INT)
                                                          });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { if (i == 0) return $T; return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static <$T> x10.serialization.X10JavaSerializable $_deserialize_body(x10.interop.Java8.$Closure$117<$T> $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            $_obj.$T = (x10.rtt.Type) $deserializer.readObject();
            $_obj.op = $deserializer.readObject();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.interop.Java8.$Closure$117 $_obj = new x10.interop.Java8.$Closure$117((java.lang.System[]) null, (x10.rtt.Type) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            $serializer.write(this.$T);
            $serializer.write(this.op);
            
        }
        
        // constructor just for allocation
        public $Closure$117(final java.lang.System[] $dummy, final x10.rtt.Type $T) {
            x10.interop.Java8.$Closure$117.$initParams(this, $T);
            
        }
        
        // dispatcher for method abstract public (Z1,Z2)=>void.operator()(a1:Z1, a2:Z2):void
        public java.lang.Object $apply(final java.lang.Object a1, final x10.rtt.Type t1, final java.lang.Object a2, final x10.rtt.Type t2) {
            $apply__0x10$interop$Java8$$Closure$117$$T(($T)a1, x10.core.Int.$unbox(a2)); return null;
            
        }
        
        // dispatcher for method abstract public (Z1,Z2)=>void.operator()(a1:Z1, a2:Z2):void
        public void $apply$V(final java.lang.Object a1, final x10.rtt.Type t1, final java.lang.Object a2, final x10.rtt.Type t2) {
            $apply__0x10$interop$Java8$$Closure$117$$T(($T)a1, x10.core.Int.$unbox(a2));
            
        }
        
        private x10.rtt.Type $T;
        
        // initializer of type parameters
        public static void $initParams(final $Closure$117 $this, final x10.rtt.Type $T) {
            $this.$T = $T;
            
        }
        
    
        
        public void $apply__0x10$interop$Java8$$Closure$117$$T(final $T t, final int u) {
            
            //#line 183 "x10/interop/Java8.x10"
            this.op.accept(((java.lang.Object)(t)), (int)(u));
        }
        
        public java.util.function.ObjIntConsumer op;
        
        public $Closure$117(final x10.rtt.Type $T, final java.util.function.ObjIntConsumer op) {
            x10.interop.Java8.$Closure$117.$initParams(this, $T);
             {
                ((x10.interop.Java8.$Closure$117<$T>)this).op = ((java.util.function.ObjIntConsumer)(op));
            }
        }
        
    }
    
    @x10.runtime.impl.java.X10Generated
    final public static class $Closure$118<$T> extends x10.core.Ref implements x10.core.fun.VoidFun_0_2, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<$Closure$118> $RTT = 
            x10.rtt.StaticVoidFunType.<$Closure$118> make($Closure$118.class,
                                                          1,
                                                          new x10.rtt.Type[] {
                                                              x10.rtt.ParameterizedType.make(x10.core.fun.VoidFun_0_2.$RTT, x10.rtt.UnresolvedType.PARAM(0), x10.rtt.Types.LONG)
                                                          });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { if (i == 0) return $T; return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static <$T> x10.serialization.X10JavaSerializable $_deserialize_body(x10.interop.Java8.$Closure$118<$T> $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            $_obj.$T = (x10.rtt.Type) $deserializer.readObject();
            $_obj.op = $deserializer.readObject();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.interop.Java8.$Closure$118 $_obj = new x10.interop.Java8.$Closure$118((java.lang.System[]) null, (x10.rtt.Type) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            $serializer.write(this.$T);
            $serializer.write(this.op);
            
        }
        
        // constructor just for allocation
        public $Closure$118(final java.lang.System[] $dummy, final x10.rtt.Type $T) {
            x10.interop.Java8.$Closure$118.$initParams(this, $T);
            
        }
        
        // dispatcher for method abstract public (Z1,Z2)=>void.operator()(a1:Z1, a2:Z2):void
        public java.lang.Object $apply(final java.lang.Object a1, final x10.rtt.Type t1, final java.lang.Object a2, final x10.rtt.Type t2) {
            $apply__0x10$interop$Java8$$Closure$118$$T(($T)a1, x10.core.Long.$unbox(a2)); return null;
            
        }
        
        // dispatcher for method abstract public (Z1,Z2)=>void.operator()(a1:Z1, a2:Z2):void
        public void $apply$V(final java.lang.Object a1, final x10.rtt.Type t1, final java.lang.Object a2, final x10.rtt.Type t2) {
            $apply__0x10$interop$Java8$$Closure$118$$T(($T)a1, x10.core.Long.$unbox(a2));
            
        }
        
        private x10.rtt.Type $T;
        
        // initializer of type parameters
        public static void $initParams(final $Closure$118 $this, final x10.rtt.Type $T) {
            $this.$T = $T;
            
        }
        
    
        
        public void $apply__0x10$interop$Java8$$Closure$118$$T(final $T t, final long u) {
            
            //#line 186 "x10/interop/Java8.x10"
            this.op.accept(((java.lang.Object)(t)), (long)(u));
        }
        
        public java.util.function.ObjLongConsumer op;
        
        public $Closure$118(final x10.rtt.Type $T, final java.util.function.ObjLongConsumer op) {
            x10.interop.Java8.$Closure$118.$initParams(this, $T);
             {
                ((x10.interop.Java8.$Closure$118<$T>)this).op = ((java.util.function.ObjLongConsumer)(op));
            }
        }
        
    }
    
    @x10.runtime.impl.java.X10Generated
    final public static class $Closure$119<$T> extends x10.core.Ref implements x10.core.fun.VoidFun_0_2, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<$Closure$119> $RTT = 
            x10.rtt.StaticVoidFunType.<$Closure$119> make($Closure$119.class,
                                                          1,
                                                          new x10.rtt.Type[] {
                                                              x10.rtt.ParameterizedType.make(x10.core.fun.VoidFun_0_2.$RTT, x10.rtt.UnresolvedType.PARAM(0), x10.rtt.Types.DOUBLE)
                                                          });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { if (i == 0) return $T; return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static <$T> x10.serialization.X10JavaSerializable $_deserialize_body(x10.interop.Java8.$Closure$119<$T> $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            $_obj.$T = (x10.rtt.Type) $deserializer.readObject();
            $_obj.op = $deserializer.readObject();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.interop.Java8.$Closure$119 $_obj = new x10.interop.Java8.$Closure$119((java.lang.System[]) null, (x10.rtt.Type) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            $serializer.write(this.$T);
            $serializer.write(this.op);
            
        }
        
        // constructor just for allocation
        public $Closure$119(final java.lang.System[] $dummy, final x10.rtt.Type $T) {
            x10.interop.Java8.$Closure$119.$initParams(this, $T);
            
        }
        
        // dispatcher for method abstract public (Z1,Z2)=>void.operator()(a1:Z1, a2:Z2):void
        public java.lang.Object $apply(final java.lang.Object a1, final x10.rtt.Type t1, final java.lang.Object a2, final x10.rtt.Type t2) {
            $apply__0x10$interop$Java8$$Closure$119$$T(($T)a1, x10.core.Double.$unbox(a2)); return null;
            
        }
        
        // dispatcher for method abstract public (Z1,Z2)=>void.operator()(a1:Z1, a2:Z2):void
        public void $apply$V(final java.lang.Object a1, final x10.rtt.Type t1, final java.lang.Object a2, final x10.rtt.Type t2) {
            $apply__0x10$interop$Java8$$Closure$119$$T(($T)a1, x10.core.Double.$unbox(a2));
            
        }
        
        private x10.rtt.Type $T;
        
        // initializer of type parameters
        public static void $initParams(final $Closure$119 $this, final x10.rtt.Type $T) {
            $this.$T = $T;
            
        }
        
    
        
        public void $apply__0x10$interop$Java8$$Closure$119$$T(final $T t, final double u) {
            
            //#line 189 "x10/interop/Java8.x10"
            this.op.accept(((java.lang.Object)(t)), (double)(u));
        }
        
        public java.util.function.ObjDoubleConsumer op;
        
        public $Closure$119(final x10.rtt.Type $T, final java.util.function.ObjDoubleConsumer op) {
            x10.interop.Java8.$Closure$119.$initParams(this, $T);
             {
                ((x10.interop.Java8.$Closure$119<$T>)this).op = ((java.util.function.ObjDoubleConsumer)(op));
            }
        }
        
    }
    
    @x10.runtime.impl.java.X10Generated
    final public static class $Closure$120<$T, $U> extends x10.core.Ref implements x10.core.fun.VoidFun_0_2, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<$Closure$120> $RTT = 
            x10.rtt.StaticVoidFunType.<$Closure$120> make($Closure$120.class,
                                                          2,
                                                          new x10.rtt.Type[] {
                                                              x10.rtt.ParameterizedType.make(x10.core.fun.VoidFun_0_2.$RTT, x10.rtt.UnresolvedType.PARAM(0), x10.rtt.UnresolvedType.PARAM(1))
                                                          });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { if (i == 0) return $T; if (i == 1) return $U; return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static <$T, $U> x10.serialization.X10JavaSerializable $_deserialize_body(x10.interop.Java8.$Closure$120<$T, $U> $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            $_obj.$T = (x10.rtt.Type) $deserializer.readObject();
            $_obj.$U = (x10.rtt.Type) $deserializer.readObject();
            $_obj.op = $deserializer.readObject();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.interop.Java8.$Closure$120 $_obj = new x10.interop.Java8.$Closure$120((java.lang.System[]) null, (x10.rtt.Type) null, (x10.rtt.Type) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            $serializer.write(this.$T);
            $serializer.write(this.$U);
            $serializer.write(this.op);
            
        }
        
        // constructor just for allocation
        public $Closure$120(final java.lang.System[] $dummy, final x10.rtt.Type $T, final x10.rtt.Type $U) {
            x10.interop.Java8.$Closure$120.$initParams(this, $T, $U);
            
        }
        
        // dispatcher for method abstract public (Z1,Z2)=>void.operator()(a1:Z1, a2:Z2):void
        public java.lang.Object $apply(final java.lang.Object a1, final x10.rtt.Type t1, final java.lang.Object a2, final x10.rtt.Type t2) {
            $apply__0x10$interop$Java8$$Closure$120$$T__1x10$interop$Java8$$Closure$120$$U(($T)a1, ($U)a2); return null;
            
        }
        
        // dispatcher for method abstract public (Z1,Z2)=>void.operator()(a1:Z1, a2:Z2):void
        public void $apply$V(final java.lang.Object a1, final x10.rtt.Type t1, final java.lang.Object a2, final x10.rtt.Type t2) {
            $apply__0x10$interop$Java8$$Closure$120$$T__1x10$interop$Java8$$Closure$120$$U(($T)a1, ($U)a2);
            
        }
        
        private x10.rtt.Type $T;
        private x10.rtt.Type $U;
        
        // initializer of type parameters
        public static void $initParams(final $Closure$120 $this, final x10.rtt.Type $T, final x10.rtt.Type $U) {
            $this.$T = $T;
            $this.$U = $U;
            
        }
        
    
        
        public void $apply__0x10$interop$Java8$$Closure$120$$T__1x10$interop$Java8$$Closure$120$$U(final $T t, final $U u) {
            
            //#line 192 "x10/interop/Java8.x10"
            this.op.accept(((java.lang.Object)(t)), ((java.lang.Object)(u)));
        }
        
        public java.util.function.BiConsumer op;
        
        public $Closure$120(final x10.rtt.Type $T, final x10.rtt.Type $U, final java.util.function.BiConsumer op) {
            x10.interop.Java8.$Closure$120.$initParams(this, $T, $U);
             {
                ((x10.interop.Java8.$Closure$120<$T, $U>)this).op = ((java.util.function.BiConsumer)(op));
            }
        }
        
    }
    
    @x10.runtime.impl.java.X10Generated
    final public static class $Closure$121 extends x10.core.Ref implements x10.core.fun.Fun_0_0, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<$Closure$121> $RTT = 
            x10.rtt.StaticFunType.<$Closure$121> make($Closure$121.class,
                                                      new x10.rtt.Type[] {
                                                          x10.rtt.ParameterizedType.make(x10.core.fun.Fun_0_0.$RTT, x10.rtt.Types.INT)
                                                      });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static x10.serialization.X10JavaSerializable $_deserialize_body(x10.interop.Java8.$Closure$121 $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            $_obj.op = $deserializer.readObject();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.interop.Java8.$Closure$121 $_obj = new x10.interop.Java8.$Closure$121((java.lang.System[]) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            $serializer.write(this.op);
            
        }
        
        // constructor just for allocation
        public $Closure$121(final java.lang.System[] $dummy) {
            
        }
        
        // bridge for method abstract public ()=>U.operator()():U
        public x10.core.Int $apply$G() {
            return x10.core.Int.$box($apply$O());
        }
        
        
    
        
        public int $apply$O() {
            
            //#line 219 "x10/interop/Java8.x10"
            final int t$129680 = this.op.getAsInt();
            
            //#line 219 "x10/interop/Java8.x10"
            return t$129680;
        }
        
        public java.util.function.IntSupplier op;
        
        public $Closure$121(final java.util.function.IntSupplier op) {
             {
                this.op = ((java.util.function.IntSupplier)(op));
            }
        }
        
    }
    
    @x10.runtime.impl.java.X10Generated
    final public static class $Closure$122 extends x10.core.Ref implements x10.core.fun.Fun_0_0, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<$Closure$122> $RTT = 
            x10.rtt.StaticFunType.<$Closure$122> make($Closure$122.class,
                                                      new x10.rtt.Type[] {
                                                          x10.rtt.ParameterizedType.make(x10.core.fun.Fun_0_0.$RTT, x10.rtt.Types.LONG)
                                                      });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static x10.serialization.X10JavaSerializable $_deserialize_body(x10.interop.Java8.$Closure$122 $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            $_obj.op = $deserializer.readObject();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.interop.Java8.$Closure$122 $_obj = new x10.interop.Java8.$Closure$122((java.lang.System[]) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            $serializer.write(this.op);
            
        }
        
        // constructor just for allocation
        public $Closure$122(final java.lang.System[] $dummy) {
            
        }
        
        // bridge for method abstract public ()=>U.operator()():U
        public x10.core.Long $apply$G() {
            return x10.core.Long.$box($apply$O());
        }
        
        
    
        
        public long $apply$O() {
            
            //#line 222 "x10/interop/Java8.x10"
            final long t$129682 = this.op.getAsLong();
            
            //#line 222 "x10/interop/Java8.x10"
            return t$129682;
        }
        
        public java.util.function.LongSupplier op;
        
        public $Closure$122(final java.util.function.LongSupplier op) {
             {
                this.op = ((java.util.function.LongSupplier)(op));
            }
        }
        
    }
    
    @x10.runtime.impl.java.X10Generated
    final public static class $Closure$123 extends x10.core.Ref implements x10.core.fun.Fun_0_0, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<$Closure$123> $RTT = 
            x10.rtt.StaticFunType.<$Closure$123> make($Closure$123.class,
                                                      new x10.rtt.Type[] {
                                                          x10.rtt.ParameterizedType.make(x10.core.fun.Fun_0_0.$RTT, x10.rtt.Types.DOUBLE)
                                                      });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static x10.serialization.X10JavaSerializable $_deserialize_body(x10.interop.Java8.$Closure$123 $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            $_obj.op = $deserializer.readObject();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.interop.Java8.$Closure$123 $_obj = new x10.interop.Java8.$Closure$123((java.lang.System[]) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            $serializer.write(this.op);
            
        }
        
        // constructor just for allocation
        public $Closure$123(final java.lang.System[] $dummy) {
            
        }
        
        // bridge for method abstract public ()=>U.operator()():U
        public x10.core.Double $apply$G() {
            return x10.core.Double.$box($apply$O());
        }
        
        
    
        
        public double $apply$O() {
            
            //#line 225 "x10/interop/Java8.x10"
            final double t$129684 = this.op.getAsDouble();
            
            //#line 225 "x10/interop/Java8.x10"
            return t$129684;
        }
        
        public java.util.function.DoubleSupplier op;
        
        public $Closure$123(final java.util.function.DoubleSupplier op) {
             {
                this.op = ((java.util.function.DoubleSupplier)(op));
            }
        }
        
    }
    
    @x10.runtime.impl.java.X10Generated
    final public static class $Closure$124 extends x10.core.Ref implements x10.core.fun.Fun_0_0, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<$Closure$124> $RTT = 
            x10.rtt.StaticFunType.<$Closure$124> make($Closure$124.class,
                                                      new x10.rtt.Type[] {
                                                          x10.rtt.ParameterizedType.make(x10.core.fun.Fun_0_0.$RTT, x10.rtt.Types.BOOLEAN)
                                                      });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static x10.serialization.X10JavaSerializable $_deserialize_body(x10.interop.Java8.$Closure$124 $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            $_obj.op = $deserializer.readObject();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.interop.Java8.$Closure$124 $_obj = new x10.interop.Java8.$Closure$124((java.lang.System[]) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            $serializer.write(this.op);
            
        }
        
        // constructor just for allocation
        public $Closure$124(final java.lang.System[] $dummy) {
            
        }
        
        // bridge for method abstract public ()=>U.operator()():U
        public x10.core.Boolean $apply$G() {
            return x10.core.Boolean.$box($apply$O());
        }
        
        
    
        
        public boolean $apply$O() {
            
            //#line 228 "x10/interop/Java8.x10"
            final boolean t$129686 = this.op.getAsBoolean();
            
            //#line 228 "x10/interop/Java8.x10"
            return t$129686;
        }
        
        public java.util.function.BooleanSupplier op;
        
        public $Closure$124(final java.util.function.BooleanSupplier op) {
             {
                this.op = ((java.util.function.BooleanSupplier)(op));
            }
        }
        
    }
    
    @x10.runtime.impl.java.X10Generated
    final public static class $Closure$125<$T> extends x10.core.Ref implements x10.core.fun.Fun_0_0, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<$Closure$125> $RTT = 
            x10.rtt.StaticFunType.<$Closure$125> make($Closure$125.class,
                                                      1,
                                                      new x10.rtt.Type[] {
                                                          x10.rtt.ParameterizedType.make(x10.core.fun.Fun_0_0.$RTT, x10.rtt.UnresolvedType.PARAM(0))
                                                      });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { if (i == 0) return $T; return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static <$T> x10.serialization.X10JavaSerializable $_deserialize_body(x10.interop.Java8.$Closure$125<$T> $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            $_obj.$T = (x10.rtt.Type) $deserializer.readObject();
            $_obj.op = $deserializer.readObject();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.interop.Java8.$Closure$125 $_obj = new x10.interop.Java8.$Closure$125((java.lang.System[]) null, (x10.rtt.Type) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            $serializer.write(this.$T);
            $serializer.write(this.op);
            
        }
        
        // constructor just for allocation
        public $Closure$125(final java.lang.System[] $dummy, final x10.rtt.Type $T) {
            x10.interop.Java8.$Closure$125.$initParams(this, $T);
            
        }
        
        private x10.rtt.Type $T;
        
        // initializer of type parameters
        public static void $initParams(final $Closure$125 $this, final x10.rtt.Type $T) {
            $this.$T = $T;
            
        }
        
    
        
        public $T $apply$G() {
            
            //#line 231 "x10/interop/Java8.x10"
            final java.lang.Object t$129688 = this.op.get();
            
            //#line 231 "x10/interop/Java8.x10"
            final $T t$129689 = (($T)(x10.rtt.Types.<$T> cast(t$129688,$T)));
            
            //#line 231 "x10/interop/Java8.x10"
            return t$129689;
        }
        
        public java.util.function.Supplier op;
        
        public $Closure$125(final x10.rtt.Type $T, final java.util.function.Supplier op) {
            x10.interop.Java8.$Closure$125.$initParams(this, $T);
             {
                ((x10.interop.Java8.$Closure$125<$T>)this).op = ((java.util.function.Supplier)(op));
            }
        }
        
    }
    
    @x10.runtime.impl.java.X10Generated
    final public static class $Closure$126 extends x10.core.Ref implements x10.core.fun.Fun_0_1, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<$Closure$126> $RTT = 
            x10.rtt.StaticFunType.<$Closure$126> make($Closure$126.class,
                                                      new x10.rtt.Type[] {
                                                          x10.rtt.ParameterizedType.make(x10.core.fun.Fun_0_1.$RTT, x10.rtt.Types.LONG, x10.rtt.Types.INT)
                                                      });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static x10.serialization.X10JavaSerializable $_deserialize_body(x10.interop.Java8.$Closure$126 $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            $_obj.op = $deserializer.readObject();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.interop.Java8.$Closure$126 $_obj = new x10.interop.Java8.$Closure$126((java.lang.System[]) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            $serializer.write(this.op);
            
        }
        
        // constructor just for allocation
        public $Closure$126(final java.lang.System[] $dummy) {
            
        }
        
        // dispatcher for method abstract public (Z1)=>U.operator()(a1:Z1):U
        public java.lang.Object $apply(final java.lang.Object a1, final x10.rtt.Type t1) {
            return x10.core.Int.$box($apply$O(x10.core.Long.$unbox(a1)));
            
        }
        
        // dispatcher for method abstract public (Z1)=>U.operator()(a1:Z1):U
        public int $apply$I(final java.lang.Object a1, final x10.rtt.Type t1) {
            return $apply$O(x10.core.Long.$unbox(a1));
            
        }
        
        
    
        
        public int $apply$O(final long value) {
            
            //#line 263 "x10/interop/Java8.x10"
            final int t$129691 = this.op.applyAsInt((long)(value));
            
            //#line 263 "x10/interop/Java8.x10"
            return t$129691;
        }
        
        public java.util.function.LongToIntFunction op;
        
        public $Closure$126(final java.util.function.LongToIntFunction op) {
             {
                this.op = ((java.util.function.LongToIntFunction)(op));
            }
        }
        
    }
    
    @x10.runtime.impl.java.X10Generated
    final public static class $Closure$127 extends x10.core.Ref implements x10.core.fun.Fun_0_1, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<$Closure$127> $RTT = 
            x10.rtt.StaticFunType.<$Closure$127> make($Closure$127.class,
                                                      new x10.rtt.Type[] {
                                                          x10.rtt.ParameterizedType.make(x10.core.fun.Fun_0_1.$RTT, x10.rtt.Types.DOUBLE, x10.rtt.Types.INT)
                                                      });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static x10.serialization.X10JavaSerializable $_deserialize_body(x10.interop.Java8.$Closure$127 $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            $_obj.op = $deserializer.readObject();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.interop.Java8.$Closure$127 $_obj = new x10.interop.Java8.$Closure$127((java.lang.System[]) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            $serializer.write(this.op);
            
        }
        
        // constructor just for allocation
        public $Closure$127(final java.lang.System[] $dummy) {
            
        }
        
        // dispatcher for method abstract public (Z1)=>U.operator()(a1:Z1):U
        public java.lang.Object $apply(final java.lang.Object a1, final x10.rtt.Type t1) {
            return x10.core.Int.$box($apply$O(x10.core.Double.$unbox(a1)));
            
        }
        
        // dispatcher for method abstract public (Z1)=>U.operator()(a1:Z1):U
        public int $apply$I(final java.lang.Object a1, final x10.rtt.Type t1) {
            return $apply$O(x10.core.Double.$unbox(a1));
            
        }
        
        
    
        
        public int $apply$O(final double value) {
            
            //#line 266 "x10/interop/Java8.x10"
            final int t$129693 = this.op.applyAsInt((double)(value));
            
            //#line 266 "x10/interop/Java8.x10"
            return t$129693;
        }
        
        public java.util.function.DoubleToIntFunction op;
        
        public $Closure$127(final java.util.function.DoubleToIntFunction op) {
             {
                this.op = ((java.util.function.DoubleToIntFunction)(op));
            }
        }
        
    }
    
    @x10.runtime.impl.java.X10Generated
    final public static class $Closure$128<$T> extends x10.core.Ref implements x10.core.fun.Fun_0_1, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<$Closure$128> $RTT = 
            x10.rtt.StaticFunType.<$Closure$128> make($Closure$128.class,
                                                      1,
                                                      new x10.rtt.Type[] {
                                                          x10.rtt.ParameterizedType.make(x10.core.fun.Fun_0_1.$RTT, x10.rtt.UnresolvedType.PARAM(0), x10.rtt.Types.INT)
                                                      });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { if (i == 0) return $T; return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static <$T> x10.serialization.X10JavaSerializable $_deserialize_body(x10.interop.Java8.$Closure$128<$T> $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            $_obj.$T = (x10.rtt.Type) $deserializer.readObject();
            $_obj.op = $deserializer.readObject();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.interop.Java8.$Closure$128 $_obj = new x10.interop.Java8.$Closure$128((java.lang.System[]) null, (x10.rtt.Type) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            $serializer.write(this.$T);
            $serializer.write(this.op);
            
        }
        
        // constructor just for allocation
        public $Closure$128(final java.lang.System[] $dummy, final x10.rtt.Type $T) {
            x10.interop.Java8.$Closure$128.$initParams(this, $T);
            
        }
        
        // dispatcher for method abstract public (Z1)=>U.operator()(a1:Z1):U
        public java.lang.Object $apply(final java.lang.Object a1, final x10.rtt.Type t1) {
            return x10.core.Int.$box($apply__0x10$interop$Java8$$Closure$128$$T$O(($T)a1));
            
        }
        
        // dispatcher for method abstract public (Z1)=>U.operator()(a1:Z1):U
        public int $apply$I(final java.lang.Object a1, final x10.rtt.Type t1) {
            return $apply__0x10$interop$Java8$$Closure$128$$T$O(($T)a1);
            
        }
        
        private x10.rtt.Type $T;
        
        // initializer of type parameters
        public static void $initParams(final $Closure$128 $this, final x10.rtt.Type $T) {
            $this.$T = $T;
            
        }
        
    
        
        public int $apply__0x10$interop$Java8$$Closure$128$$T$O(final $T value) {
            
            //#line 269 "x10/interop/Java8.x10"
            final int t$129695 = this.op.applyAsInt(((java.lang.Object)(value)));
            
            //#line 269 "x10/interop/Java8.x10"
            return t$129695;
        }
        
        public java.util.function.ToIntFunction op;
        
        public $Closure$128(final x10.rtt.Type $T, final java.util.function.ToIntFunction op) {
            x10.interop.Java8.$Closure$128.$initParams(this, $T);
             {
                ((x10.interop.Java8.$Closure$128<$T>)this).op = ((java.util.function.ToIntFunction)(op));
            }
        }
        
    }
    
    @x10.runtime.impl.java.X10Generated
    final public static class $Closure$129 extends x10.core.Ref implements x10.core.fun.Fun_0_1, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<$Closure$129> $RTT = 
            x10.rtt.StaticFunType.<$Closure$129> make($Closure$129.class,
                                                      new x10.rtt.Type[] {
                                                          x10.rtt.ParameterizedType.make(x10.core.fun.Fun_0_1.$RTT, x10.rtt.Types.INT, x10.rtt.Types.LONG)
                                                      });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static x10.serialization.X10JavaSerializable $_deserialize_body(x10.interop.Java8.$Closure$129 $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            $_obj.op = $deserializer.readObject();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.interop.Java8.$Closure$129 $_obj = new x10.interop.Java8.$Closure$129((java.lang.System[]) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            $serializer.write(this.op);
            
        }
        
        // constructor just for allocation
        public $Closure$129(final java.lang.System[] $dummy) {
            
        }
        
        // dispatcher for method abstract public (Z1)=>U.operator()(a1:Z1):U
        public java.lang.Object $apply(final java.lang.Object a1, final x10.rtt.Type t1) {
            return x10.core.Long.$box($apply$O(x10.core.Int.$unbox(a1)));
            
        }
        
        // dispatcher for method abstract public (Z1)=>U.operator()(a1:Z1):U
        public long $apply$J(final java.lang.Object a1, final x10.rtt.Type t1) {
            return $apply$O(x10.core.Int.$unbox(a1));
            
        }
        
        
    
        
        public long $apply$O(final int value) {
            
            //#line 291 "x10/interop/Java8.x10"
            final long t$129697 = this.op.applyAsLong((int)(value));
            
            //#line 291 "x10/interop/Java8.x10"
            return t$129697;
        }
        
        public java.util.function.IntToLongFunction op;
        
        public $Closure$129(final java.util.function.IntToLongFunction op) {
             {
                this.op = ((java.util.function.IntToLongFunction)(op));
            }
        }
        
    }
    
    @x10.runtime.impl.java.X10Generated
    final public static class $Closure$130 extends x10.core.Ref implements x10.core.fun.Fun_0_1, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<$Closure$130> $RTT = 
            x10.rtt.StaticFunType.<$Closure$130> make($Closure$130.class,
                                                      new x10.rtt.Type[] {
                                                          x10.rtt.ParameterizedType.make(x10.core.fun.Fun_0_1.$RTT, x10.rtt.Types.DOUBLE, x10.rtt.Types.LONG)
                                                      });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static x10.serialization.X10JavaSerializable $_deserialize_body(x10.interop.Java8.$Closure$130 $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            $_obj.op = $deserializer.readObject();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.interop.Java8.$Closure$130 $_obj = new x10.interop.Java8.$Closure$130((java.lang.System[]) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            $serializer.write(this.op);
            
        }
        
        // constructor just for allocation
        public $Closure$130(final java.lang.System[] $dummy) {
            
        }
        
        // dispatcher for method abstract public (Z1)=>U.operator()(a1:Z1):U
        public java.lang.Object $apply(final java.lang.Object a1, final x10.rtt.Type t1) {
            return x10.core.Long.$box($apply$O(x10.core.Double.$unbox(a1)));
            
        }
        
        // dispatcher for method abstract public (Z1)=>U.operator()(a1:Z1):U
        public long $apply$J(final java.lang.Object a1, final x10.rtt.Type t1) {
            return $apply$O(x10.core.Double.$unbox(a1));
            
        }
        
        
    
        
        public long $apply$O(final double value) {
            
            //#line 294 "x10/interop/Java8.x10"
            final long t$129699 = this.op.applyAsLong((double)(value));
            
            //#line 294 "x10/interop/Java8.x10"
            return t$129699;
        }
        
        public java.util.function.DoubleToLongFunction op;
        
        public $Closure$130(final java.util.function.DoubleToLongFunction op) {
             {
                this.op = ((java.util.function.DoubleToLongFunction)(op));
            }
        }
        
    }
    
    @x10.runtime.impl.java.X10Generated
    final public static class $Closure$131<$T> extends x10.core.Ref implements x10.core.fun.Fun_0_1, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<$Closure$131> $RTT = 
            x10.rtt.StaticFunType.<$Closure$131> make($Closure$131.class,
                                                      1,
                                                      new x10.rtt.Type[] {
                                                          x10.rtt.ParameterizedType.make(x10.core.fun.Fun_0_1.$RTT, x10.rtt.UnresolvedType.PARAM(0), x10.rtt.Types.LONG)
                                                      });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { if (i == 0) return $T; return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static <$T> x10.serialization.X10JavaSerializable $_deserialize_body(x10.interop.Java8.$Closure$131<$T> $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            $_obj.$T = (x10.rtt.Type) $deserializer.readObject();
            $_obj.op = $deserializer.readObject();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.interop.Java8.$Closure$131 $_obj = new x10.interop.Java8.$Closure$131((java.lang.System[]) null, (x10.rtt.Type) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            $serializer.write(this.$T);
            $serializer.write(this.op);
            
        }
        
        // constructor just for allocation
        public $Closure$131(final java.lang.System[] $dummy, final x10.rtt.Type $T) {
            x10.interop.Java8.$Closure$131.$initParams(this, $T);
            
        }
        
        // dispatcher for method abstract public (Z1)=>U.operator()(a1:Z1):U
        public java.lang.Object $apply(final java.lang.Object a1, final x10.rtt.Type t1) {
            return x10.core.Long.$box($apply__0x10$interop$Java8$$Closure$131$$T$O(($T)a1));
            
        }
        
        // dispatcher for method abstract public (Z1)=>U.operator()(a1:Z1):U
        public long $apply$J(final java.lang.Object a1, final x10.rtt.Type t1) {
            return $apply__0x10$interop$Java8$$Closure$131$$T$O(($T)a1);
            
        }
        
        private x10.rtt.Type $T;
        
        // initializer of type parameters
        public static void $initParams(final $Closure$131 $this, final x10.rtt.Type $T) {
            $this.$T = $T;
            
        }
        
    
        
        public long $apply__0x10$interop$Java8$$Closure$131$$T$O(final $T value) {
            
            //#line 297 "x10/interop/Java8.x10"
            final long t$129701 = this.op.applyAsLong(((java.lang.Object)(value)));
            
            //#line 297 "x10/interop/Java8.x10"
            return t$129701;
        }
        
        public java.util.function.ToLongFunction op;
        
        public $Closure$131(final x10.rtt.Type $T, final java.util.function.ToLongFunction op) {
            x10.interop.Java8.$Closure$131.$initParams(this, $T);
             {
                ((x10.interop.Java8.$Closure$131<$T>)this).op = ((java.util.function.ToLongFunction)(op));
            }
        }
        
    }
    
    @x10.runtime.impl.java.X10Generated
    final public static class $Closure$132 extends x10.core.Ref implements x10.core.fun.Fun_0_1, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<$Closure$132> $RTT = 
            x10.rtt.StaticFunType.<$Closure$132> make($Closure$132.class,
                                                      new x10.rtt.Type[] {
                                                          x10.rtt.ParameterizedType.make(x10.core.fun.Fun_0_1.$RTT, x10.rtt.Types.INT, x10.rtt.Types.DOUBLE)
                                                      });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static x10.serialization.X10JavaSerializable $_deserialize_body(x10.interop.Java8.$Closure$132 $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            $_obj.op = $deserializer.readObject();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.interop.Java8.$Closure$132 $_obj = new x10.interop.Java8.$Closure$132((java.lang.System[]) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            $serializer.write(this.op);
            
        }
        
        // constructor just for allocation
        public $Closure$132(final java.lang.System[] $dummy) {
            
        }
        
        // dispatcher for method abstract public (Z1)=>U.operator()(a1:Z1):U
        public java.lang.Object $apply(final java.lang.Object a1, final x10.rtt.Type t1) {
            return x10.core.Double.$box($apply$O(x10.core.Int.$unbox(a1)));
            
        }
        
        // dispatcher for method abstract public (Z1)=>U.operator()(a1:Z1):U
        public double $apply$D(final java.lang.Object a1, final x10.rtt.Type t1) {
            return $apply$O(x10.core.Int.$unbox(a1));
            
        }
        
        
    
        
        public double $apply$O(final int value) {
            
            //#line 319 "x10/interop/Java8.x10"
            final double t$129703 = this.op.applyAsDouble((int)(value));
            
            //#line 319 "x10/interop/Java8.x10"
            return t$129703;
        }
        
        public java.util.function.IntToDoubleFunction op;
        
        public $Closure$132(final java.util.function.IntToDoubleFunction op) {
             {
                this.op = ((java.util.function.IntToDoubleFunction)(op));
            }
        }
        
    }
    
    @x10.runtime.impl.java.X10Generated
    final public static class $Closure$133 extends x10.core.Ref implements x10.core.fun.Fun_0_1, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<$Closure$133> $RTT = 
            x10.rtt.StaticFunType.<$Closure$133> make($Closure$133.class,
                                                      new x10.rtt.Type[] {
                                                          x10.rtt.ParameterizedType.make(x10.core.fun.Fun_0_1.$RTT, x10.rtt.Types.LONG, x10.rtt.Types.DOUBLE)
                                                      });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static x10.serialization.X10JavaSerializable $_deserialize_body(x10.interop.Java8.$Closure$133 $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            $_obj.op = $deserializer.readObject();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.interop.Java8.$Closure$133 $_obj = new x10.interop.Java8.$Closure$133((java.lang.System[]) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            $serializer.write(this.op);
            
        }
        
        // constructor just for allocation
        public $Closure$133(final java.lang.System[] $dummy) {
            
        }
        
        // dispatcher for method abstract public (Z1)=>U.operator()(a1:Z1):U
        public java.lang.Object $apply(final java.lang.Object a1, final x10.rtt.Type t1) {
            return x10.core.Double.$box($apply$O(x10.core.Long.$unbox(a1)));
            
        }
        
        // dispatcher for method abstract public (Z1)=>U.operator()(a1:Z1):U
        public double $apply$D(final java.lang.Object a1, final x10.rtt.Type t1) {
            return $apply$O(x10.core.Long.$unbox(a1));
            
        }
        
        
    
        
        public double $apply$O(final long value) {
            
            //#line 322 "x10/interop/Java8.x10"
            final double t$129705 = this.op.applyAsDouble((long)(value));
            
            //#line 322 "x10/interop/Java8.x10"
            return t$129705;
        }
        
        public java.util.function.LongToDoubleFunction op;
        
        public $Closure$133(final java.util.function.LongToDoubleFunction op) {
             {
                this.op = ((java.util.function.LongToDoubleFunction)(op));
            }
        }
        
    }
    
    @x10.runtime.impl.java.X10Generated
    final public static class $Closure$134<$T> extends x10.core.Ref implements x10.core.fun.Fun_0_1, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<$Closure$134> $RTT = 
            x10.rtt.StaticFunType.<$Closure$134> make($Closure$134.class,
                                                      1,
                                                      new x10.rtt.Type[] {
                                                          x10.rtt.ParameterizedType.make(x10.core.fun.Fun_0_1.$RTT, x10.rtt.UnresolvedType.PARAM(0), x10.rtt.Types.DOUBLE)
                                                      });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { if (i == 0) return $T; return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static <$T> x10.serialization.X10JavaSerializable $_deserialize_body(x10.interop.Java8.$Closure$134<$T> $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            $_obj.$T = (x10.rtt.Type) $deserializer.readObject();
            $_obj.op = $deserializer.readObject();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.interop.Java8.$Closure$134 $_obj = new x10.interop.Java8.$Closure$134((java.lang.System[]) null, (x10.rtt.Type) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            $serializer.write(this.$T);
            $serializer.write(this.op);
            
        }
        
        // constructor just for allocation
        public $Closure$134(final java.lang.System[] $dummy, final x10.rtt.Type $T) {
            x10.interop.Java8.$Closure$134.$initParams(this, $T);
            
        }
        
        // dispatcher for method abstract public (Z1)=>U.operator()(a1:Z1):U
        public java.lang.Object $apply(final java.lang.Object a1, final x10.rtt.Type t1) {
            return x10.core.Double.$box($apply__0x10$interop$Java8$$Closure$134$$T$O(($T)a1));
            
        }
        
        // dispatcher for method abstract public (Z1)=>U.operator()(a1:Z1):U
        public double $apply$D(final java.lang.Object a1, final x10.rtt.Type t1) {
            return $apply__0x10$interop$Java8$$Closure$134$$T$O(($T)a1);
            
        }
        
        private x10.rtt.Type $T;
        
        // initializer of type parameters
        public static void $initParams(final $Closure$134 $this, final x10.rtt.Type $T) {
            $this.$T = $T;
            
        }
        
    
        
        public double $apply__0x10$interop$Java8$$Closure$134$$T$O(final $T value) {
            
            //#line 325 "x10/interop/Java8.x10"
            final double t$129707 = this.op.applyAsDouble(((java.lang.Object)(value)));
            
            //#line 325 "x10/interop/Java8.x10"
            return t$129707;
        }
        
        public java.util.function.ToDoubleFunction op;
        
        public $Closure$134(final x10.rtt.Type $T, final java.util.function.ToDoubleFunction op) {
            x10.interop.Java8.$Closure$134.$initParams(this, $T);
             {
                ((x10.interop.Java8.$Closure$134<$T>)this).op = ((java.util.function.ToDoubleFunction)(op));
            }
        }
        
    }
    
    @x10.runtime.impl.java.X10Generated
    final public static class $Closure$135<$R> extends x10.core.Ref implements x10.core.fun.Fun_0_1, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<$Closure$135> $RTT = 
            x10.rtt.StaticFunType.<$Closure$135> make($Closure$135.class,
                                                      1,
                                                      new x10.rtt.Type[] {
                                                          x10.rtt.ParameterizedType.make(x10.core.fun.Fun_0_1.$RTT, x10.rtt.Types.INT, x10.rtt.UnresolvedType.PARAM(0))
                                                      });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { if (i == 0) return $R; return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static <$R> x10.serialization.X10JavaSerializable $_deserialize_body(x10.interop.Java8.$Closure$135<$R> $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            $_obj.$R = (x10.rtt.Type) $deserializer.readObject();
            $_obj.op = $deserializer.readObject();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.interop.Java8.$Closure$135 $_obj = new x10.interop.Java8.$Closure$135((java.lang.System[]) null, (x10.rtt.Type) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            $serializer.write(this.$R);
            $serializer.write(this.op);
            
        }
        
        // constructor just for allocation
        public $Closure$135(final java.lang.System[] $dummy, final x10.rtt.Type $R) {
            x10.interop.Java8.$Closure$135.$initParams(this, $R);
            
        }
        
        // dispatcher for method abstract public (Z1)=>U.operator()(a1:Z1):U
        public java.lang.Object $apply(final java.lang.Object a1, final x10.rtt.Type t1) {
            return $apply$G(x10.core.Int.$unbox(a1));
            
        }
        
        private x10.rtt.Type $R;
        
        // initializer of type parameters
        public static void $initParams(final $Closure$135 $this, final x10.rtt.Type $R) {
            $this.$R = $R;
            
        }
        
    
        
        public $R $apply$G(final int value) {
            
            //#line 347 "x10/interop/Java8.x10"
            final java.lang.Object t$129709 = this.op.apply((int)(value));
            
            //#line 347 "x10/interop/Java8.x10"
            final $R t$129710 = (($R)(x10.rtt.Types.<$R> cast(t$129709,$R)));
            
            //#line 347 "x10/interop/Java8.x10"
            return t$129710;
        }
        
        public java.util.function.IntFunction op;
        
        public $Closure$135(final x10.rtt.Type $R, final java.util.function.IntFunction op) {
            x10.interop.Java8.$Closure$135.$initParams(this, $R);
             {
                ((x10.interop.Java8.$Closure$135<$R>)this).op = ((java.util.function.IntFunction)(op));
            }
        }
        
    }
    
    @x10.runtime.impl.java.X10Generated
    final public static class $Closure$136<$R> extends x10.core.Ref implements x10.core.fun.Fun_0_1, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<$Closure$136> $RTT = 
            x10.rtt.StaticFunType.<$Closure$136> make($Closure$136.class,
                                                      1,
                                                      new x10.rtt.Type[] {
                                                          x10.rtt.ParameterizedType.make(x10.core.fun.Fun_0_1.$RTT, x10.rtt.Types.LONG, x10.rtt.UnresolvedType.PARAM(0))
                                                      });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { if (i == 0) return $R; return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static <$R> x10.serialization.X10JavaSerializable $_deserialize_body(x10.interop.Java8.$Closure$136<$R> $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            $_obj.$R = (x10.rtt.Type) $deserializer.readObject();
            $_obj.op = $deserializer.readObject();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.interop.Java8.$Closure$136 $_obj = new x10.interop.Java8.$Closure$136((java.lang.System[]) null, (x10.rtt.Type) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            $serializer.write(this.$R);
            $serializer.write(this.op);
            
        }
        
        // constructor just for allocation
        public $Closure$136(final java.lang.System[] $dummy, final x10.rtt.Type $R) {
            x10.interop.Java8.$Closure$136.$initParams(this, $R);
            
        }
        
        // dispatcher for method abstract public (Z1)=>U.operator()(a1:Z1):U
        public java.lang.Object $apply(final java.lang.Object a1, final x10.rtt.Type t1) {
            return $apply$G(x10.core.Long.$unbox(a1));
            
        }
        
        private x10.rtt.Type $R;
        
        // initializer of type parameters
        public static void $initParams(final $Closure$136 $this, final x10.rtt.Type $R) {
            $this.$R = $R;
            
        }
        
    
        
        public $R $apply$G(final long value) {
            
            //#line 350 "x10/interop/Java8.x10"
            final java.lang.Object t$129712 = this.op.apply((long)(value));
            
            //#line 350 "x10/interop/Java8.x10"
            final $R t$129713 = (($R)(x10.rtt.Types.<$R> cast(t$129712,$R)));
            
            //#line 350 "x10/interop/Java8.x10"
            return t$129713;
        }
        
        public java.util.function.LongFunction op;
        
        public $Closure$136(final x10.rtt.Type $R, final java.util.function.LongFunction op) {
            x10.interop.Java8.$Closure$136.$initParams(this, $R);
             {
                ((x10.interop.Java8.$Closure$136<$R>)this).op = ((java.util.function.LongFunction)(op));
            }
        }
        
    }
    
    @x10.runtime.impl.java.X10Generated
    final public static class $Closure$137<$R> extends x10.core.Ref implements x10.core.fun.Fun_0_1, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<$Closure$137> $RTT = 
            x10.rtt.StaticFunType.<$Closure$137> make($Closure$137.class,
                                                      1,
                                                      new x10.rtt.Type[] {
                                                          x10.rtt.ParameterizedType.make(x10.core.fun.Fun_0_1.$RTT, x10.rtt.Types.DOUBLE, x10.rtt.UnresolvedType.PARAM(0))
                                                      });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { if (i == 0) return $R; return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static <$R> x10.serialization.X10JavaSerializable $_deserialize_body(x10.interop.Java8.$Closure$137<$R> $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            $_obj.$R = (x10.rtt.Type) $deserializer.readObject();
            $_obj.op = $deserializer.readObject();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.interop.Java8.$Closure$137 $_obj = new x10.interop.Java8.$Closure$137((java.lang.System[]) null, (x10.rtt.Type) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            $serializer.write(this.$R);
            $serializer.write(this.op);
            
        }
        
        // constructor just for allocation
        public $Closure$137(final java.lang.System[] $dummy, final x10.rtt.Type $R) {
            x10.interop.Java8.$Closure$137.$initParams(this, $R);
            
        }
        
        // dispatcher for method abstract public (Z1)=>U.operator()(a1:Z1):U
        public java.lang.Object $apply(final java.lang.Object a1, final x10.rtt.Type t1) {
            return $apply$G(x10.core.Double.$unbox(a1));
            
        }
        
        private x10.rtt.Type $R;
        
        // initializer of type parameters
        public static void $initParams(final $Closure$137 $this, final x10.rtt.Type $R) {
            $this.$R = $R;
            
        }
        
    
        
        public $R $apply$G(final double value) {
            
            //#line 353 "x10/interop/Java8.x10"
            final java.lang.Object t$129715 = this.op.apply((double)(value));
            
            //#line 353 "x10/interop/Java8.x10"
            final $R t$129716 = (($R)(x10.rtt.Types.<$R> cast(t$129715,$R)));
            
            //#line 353 "x10/interop/Java8.x10"
            return t$129716;
        }
        
        public java.util.function.DoubleFunction op;
        
        public $Closure$137(final x10.rtt.Type $R, final java.util.function.DoubleFunction op) {
            x10.interop.Java8.$Closure$137.$initParams(this, $R);
             {
                ((x10.interop.Java8.$Closure$137<$R>)this).op = ((java.util.function.DoubleFunction)(op));
            }
        }
        
    }
    
    @x10.runtime.impl.java.X10Generated
    final public static class $Closure$138<$T, $R> extends x10.core.Ref implements x10.core.fun.Fun_0_1, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<$Closure$138> $RTT = 
            x10.rtt.StaticFunType.<$Closure$138> make($Closure$138.class,
                                                      2,
                                                      new x10.rtt.Type[] {
                                                          x10.rtt.ParameterizedType.make(x10.core.fun.Fun_0_1.$RTT, x10.rtt.UnresolvedType.PARAM(0), x10.rtt.UnresolvedType.PARAM(1))
                                                      });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { if (i == 0) return $T; if (i == 1) return $R; return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static <$T, $R> x10.serialization.X10JavaSerializable $_deserialize_body(x10.interop.Java8.$Closure$138<$T, $R> $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            $_obj.$T = (x10.rtt.Type) $deserializer.readObject();
            $_obj.$R = (x10.rtt.Type) $deserializer.readObject();
            $_obj.op = $deserializer.readObject();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.interop.Java8.$Closure$138 $_obj = new x10.interop.Java8.$Closure$138((java.lang.System[]) null, (x10.rtt.Type) null, (x10.rtt.Type) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            $serializer.write(this.$T);
            $serializer.write(this.$R);
            $serializer.write(this.op);
            
        }
        
        // constructor just for allocation
        public $Closure$138(final java.lang.System[] $dummy, final x10.rtt.Type $T, final x10.rtt.Type $R) {
            x10.interop.Java8.$Closure$138.$initParams(this, $T, $R);
            
        }
        
        // dispatcher for method abstract public (Z1)=>U.operator()(a1:Z1):U
        public java.lang.Object $apply(final java.lang.Object a1, final x10.rtt.Type t1) {
            return $apply__0x10$interop$Java8$$Closure$138$$T$G(($T)a1);
            
        }
        
        private x10.rtt.Type $T;
        private x10.rtt.Type $R;
        
        // initializer of type parameters
        public static void $initParams(final $Closure$138 $this, final x10.rtt.Type $T, final x10.rtt.Type $R) {
            $this.$T = $T;
            $this.$R = $R;
            
        }
        
    
        
        public $R $apply__0x10$interop$Java8$$Closure$138$$T$G(final $T value) {
            
            //#line 356 "x10/interop/Java8.x10"
            final java.lang.Object t$129718 = this.op.apply(((java.lang.Object)(value)));
            
            //#line 356 "x10/interop/Java8.x10"
            final $R t$129719 = (($R)(x10.rtt.Types.<$R> cast(t$129718,$R)));
            
            //#line 356 "x10/interop/Java8.x10"
            return t$129719;
        }
        
        public java.util.function.Function op;
        
        public $Closure$138(final x10.rtt.Type $T, final x10.rtt.Type $R, final java.util.function.Function op) {
            x10.interop.Java8.$Closure$138.$initParams(this, $T, $R);
             {
                ((x10.interop.Java8.$Closure$138<$T, $R>)this).op = ((java.util.function.Function)(op));
            }
        }
        
    }
    
    @x10.runtime.impl.java.X10Generated
    final public static class $Closure$139<$T, $U> extends x10.core.Ref implements x10.core.fun.Fun_0_2, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<$Closure$139> $RTT = 
            x10.rtt.StaticFunType.<$Closure$139> make($Closure$139.class,
                                                      2,
                                                      new x10.rtt.Type[] {
                                                          x10.rtt.ParameterizedType.make(x10.core.fun.Fun_0_2.$RTT, x10.rtt.UnresolvedType.PARAM(0), x10.rtt.UnresolvedType.PARAM(1), x10.rtt.Types.INT)
                                                      });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { if (i == 0) return $T; if (i == 1) return $U; return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static <$T, $U> x10.serialization.X10JavaSerializable $_deserialize_body(x10.interop.Java8.$Closure$139<$T, $U> $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            $_obj.$T = (x10.rtt.Type) $deserializer.readObject();
            $_obj.$U = (x10.rtt.Type) $deserializer.readObject();
            $_obj.op = $deserializer.readObject();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.interop.Java8.$Closure$139 $_obj = new x10.interop.Java8.$Closure$139((java.lang.System[]) null, (x10.rtt.Type) null, (x10.rtt.Type) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            $serializer.write(this.$T);
            $serializer.write(this.$U);
            $serializer.write(this.op);
            
        }
        
        // constructor just for allocation
        public $Closure$139(final java.lang.System[] $dummy, final x10.rtt.Type $T, final x10.rtt.Type $U) {
            x10.interop.Java8.$Closure$139.$initParams(this, $T, $U);
            
        }
        
        // dispatcher for method abstract public (Z1,Z2)=>U.operator()(a1:Z1, a2:Z2):U
        public java.lang.Object $apply(final java.lang.Object a1, final x10.rtt.Type t1, final java.lang.Object a2, final x10.rtt.Type t2) {
            return x10.core.Int.$box($apply__0x10$interop$Java8$$Closure$139$$T__1x10$interop$Java8$$Closure$139$$U$O(($T)a1, ($U)a2));
            
        }
        
        // dispatcher for method abstract public (Z1,Z2)=>U.operator()(a1:Z1, a2:Z2):U
        public int $apply$I(final java.lang.Object a1, final x10.rtt.Type t1, final java.lang.Object a2, final x10.rtt.Type t2) {
            return $apply__0x10$interop$Java8$$Closure$139$$T__1x10$interop$Java8$$Closure$139$$U$O(($T)a1, ($U)a2);
            
        }
        
        private x10.rtt.Type $T;
        private x10.rtt.Type $U;
        
        // initializer of type parameters
        public static void $initParams(final $Closure$139 $this, final x10.rtt.Type $T, final x10.rtt.Type $U) {
            $this.$T = $T;
            $this.$U = $U;
            
        }
        
    
        
        public int $apply__0x10$interop$Java8$$Closure$139$$T__1x10$interop$Java8$$Closure$139$$U$O(final $T t, final $U u) {
            
            //#line 383 "x10/interop/Java8.x10"
            final int t$129721 = this.op.applyAsInt(((java.lang.Object)(t)), ((java.lang.Object)(u)));
            
            //#line 383 "x10/interop/Java8.x10"
            return t$129721;
        }
        
        public java.util.function.ToIntBiFunction op;
        
        public $Closure$139(final x10.rtt.Type $T, final x10.rtt.Type $U, final java.util.function.ToIntBiFunction op) {
            x10.interop.Java8.$Closure$139.$initParams(this, $T, $U);
             {
                ((x10.interop.Java8.$Closure$139<$T, $U>)this).op = ((java.util.function.ToIntBiFunction)(op));
            }
        }
        
    }
    
    @x10.runtime.impl.java.X10Generated
    final public static class $Closure$140<$T, $U> extends x10.core.Ref implements x10.core.fun.Fun_0_2, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<$Closure$140> $RTT = 
            x10.rtt.StaticFunType.<$Closure$140> make($Closure$140.class,
                                                      2,
                                                      new x10.rtt.Type[] {
                                                          x10.rtt.ParameterizedType.make(x10.core.fun.Fun_0_2.$RTT, x10.rtt.UnresolvedType.PARAM(0), x10.rtt.UnresolvedType.PARAM(1), x10.rtt.Types.LONG)
                                                      });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { if (i == 0) return $T; if (i == 1) return $U; return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static <$T, $U> x10.serialization.X10JavaSerializable $_deserialize_body(x10.interop.Java8.$Closure$140<$T, $U> $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            $_obj.$T = (x10.rtt.Type) $deserializer.readObject();
            $_obj.$U = (x10.rtt.Type) $deserializer.readObject();
            $_obj.op = $deserializer.readObject();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.interop.Java8.$Closure$140 $_obj = new x10.interop.Java8.$Closure$140((java.lang.System[]) null, (x10.rtt.Type) null, (x10.rtt.Type) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            $serializer.write(this.$T);
            $serializer.write(this.$U);
            $serializer.write(this.op);
            
        }
        
        // constructor just for allocation
        public $Closure$140(final java.lang.System[] $dummy, final x10.rtt.Type $T, final x10.rtt.Type $U) {
            x10.interop.Java8.$Closure$140.$initParams(this, $T, $U);
            
        }
        
        // dispatcher for method abstract public (Z1,Z2)=>U.operator()(a1:Z1, a2:Z2):U
        public java.lang.Object $apply(final java.lang.Object a1, final x10.rtt.Type t1, final java.lang.Object a2, final x10.rtt.Type t2) {
            return x10.core.Long.$box($apply__0x10$interop$Java8$$Closure$140$$T__1x10$interop$Java8$$Closure$140$$U$O(($T)a1, ($U)a2));
            
        }
        
        // dispatcher for method abstract public (Z1,Z2)=>U.operator()(a1:Z1, a2:Z2):U
        public long $apply$J(final java.lang.Object a1, final x10.rtt.Type t1, final java.lang.Object a2, final x10.rtt.Type t2) {
            return $apply__0x10$interop$Java8$$Closure$140$$T__1x10$interop$Java8$$Closure$140$$U$O(($T)a1, ($U)a2);
            
        }
        
        private x10.rtt.Type $T;
        private x10.rtt.Type $U;
        
        // initializer of type parameters
        public static void $initParams(final $Closure$140 $this, final x10.rtt.Type $T, final x10.rtt.Type $U) {
            $this.$T = $T;
            $this.$U = $U;
            
        }
        
    
        
        public long $apply__0x10$interop$Java8$$Closure$140$$T__1x10$interop$Java8$$Closure$140$$U$O(final $T t, final $U u) {
            
            //#line 386 "x10/interop/Java8.x10"
            final long t$129723 = this.op.applyAsLong(((java.lang.Object)(t)), ((java.lang.Object)(u)));
            
            //#line 386 "x10/interop/Java8.x10"
            return t$129723;
        }
        
        public java.util.function.ToLongBiFunction op;
        
        public $Closure$140(final x10.rtt.Type $T, final x10.rtt.Type $U, final java.util.function.ToLongBiFunction op) {
            x10.interop.Java8.$Closure$140.$initParams(this, $T, $U);
             {
                ((x10.interop.Java8.$Closure$140<$T, $U>)this).op = ((java.util.function.ToLongBiFunction)(op));
            }
        }
        
    }
    
    @x10.runtime.impl.java.X10Generated
    final public static class $Closure$141<$T, $U> extends x10.core.Ref implements x10.core.fun.Fun_0_2, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<$Closure$141> $RTT = 
            x10.rtt.StaticFunType.<$Closure$141> make($Closure$141.class,
                                                      2,
                                                      new x10.rtt.Type[] {
                                                          x10.rtt.ParameterizedType.make(x10.core.fun.Fun_0_2.$RTT, x10.rtt.UnresolvedType.PARAM(0), x10.rtt.UnresolvedType.PARAM(1), x10.rtt.Types.DOUBLE)
                                                      });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { if (i == 0) return $T; if (i == 1) return $U; return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static <$T, $U> x10.serialization.X10JavaSerializable $_deserialize_body(x10.interop.Java8.$Closure$141<$T, $U> $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            $_obj.$T = (x10.rtt.Type) $deserializer.readObject();
            $_obj.$U = (x10.rtt.Type) $deserializer.readObject();
            $_obj.op = $deserializer.readObject();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.interop.Java8.$Closure$141 $_obj = new x10.interop.Java8.$Closure$141((java.lang.System[]) null, (x10.rtt.Type) null, (x10.rtt.Type) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            $serializer.write(this.$T);
            $serializer.write(this.$U);
            $serializer.write(this.op);
            
        }
        
        // constructor just for allocation
        public $Closure$141(final java.lang.System[] $dummy, final x10.rtt.Type $T, final x10.rtt.Type $U) {
            x10.interop.Java8.$Closure$141.$initParams(this, $T, $U);
            
        }
        
        // dispatcher for method abstract public (Z1,Z2)=>U.operator()(a1:Z1, a2:Z2):U
        public java.lang.Object $apply(final java.lang.Object a1, final x10.rtt.Type t1, final java.lang.Object a2, final x10.rtt.Type t2) {
            return x10.core.Double.$box($apply__0x10$interop$Java8$$Closure$141$$T__1x10$interop$Java8$$Closure$141$$U$O(($T)a1, ($U)a2));
            
        }
        
        // dispatcher for method abstract public (Z1,Z2)=>U.operator()(a1:Z1, a2:Z2):U
        public double $apply$D(final java.lang.Object a1, final x10.rtt.Type t1, final java.lang.Object a2, final x10.rtt.Type t2) {
            return $apply__0x10$interop$Java8$$Closure$141$$T__1x10$interop$Java8$$Closure$141$$U$O(($T)a1, ($U)a2);
            
        }
        
        private x10.rtt.Type $T;
        private x10.rtt.Type $U;
        
        // initializer of type parameters
        public static void $initParams(final $Closure$141 $this, final x10.rtt.Type $T, final x10.rtt.Type $U) {
            $this.$T = $T;
            $this.$U = $U;
            
        }
        
    
        
        public double $apply__0x10$interop$Java8$$Closure$141$$T__1x10$interop$Java8$$Closure$141$$U$O(final $T t, final $U u) {
            
            //#line 389 "x10/interop/Java8.x10"
            final double t$129725 = this.op.applyAsDouble(((java.lang.Object)(t)), ((java.lang.Object)(u)));
            
            //#line 389 "x10/interop/Java8.x10"
            return t$129725;
        }
        
        public java.util.function.ToDoubleBiFunction op;
        
        public $Closure$141(final x10.rtt.Type $T, final x10.rtt.Type $U, final java.util.function.ToDoubleBiFunction op) {
            x10.interop.Java8.$Closure$141.$initParams(this, $T, $U);
             {
                ((x10.interop.Java8.$Closure$141<$T, $U>)this).op = ((java.util.function.ToDoubleBiFunction)(op));
            }
        }
        
    }
    
    @x10.runtime.impl.java.X10Generated
    final public static class $Closure$142<$T, $U, $R> extends x10.core.Ref implements x10.core.fun.Fun_0_2, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<$Closure$142> $RTT = 
            x10.rtt.StaticFunType.<$Closure$142> make($Closure$142.class,
                                                      3,
                                                      new x10.rtt.Type[] {
                                                          x10.rtt.ParameterizedType.make(x10.core.fun.Fun_0_2.$RTT, x10.rtt.UnresolvedType.PARAM(0), x10.rtt.UnresolvedType.PARAM(1), x10.rtt.UnresolvedType.PARAM(2))
                                                      });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { if (i == 0) return $T; if (i == 1) return $U; if (i == 2) return $R; return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static <$T, $U, $R> x10.serialization.X10JavaSerializable $_deserialize_body(x10.interop.Java8.$Closure$142<$T, $U, $R> $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            $_obj.$T = (x10.rtt.Type) $deserializer.readObject();
            $_obj.$U = (x10.rtt.Type) $deserializer.readObject();
            $_obj.$R = (x10.rtt.Type) $deserializer.readObject();
            $_obj.op = $deserializer.readObject();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.interop.Java8.$Closure$142 $_obj = new x10.interop.Java8.$Closure$142((java.lang.System[]) null, (x10.rtt.Type) null, (x10.rtt.Type) null, (x10.rtt.Type) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            $serializer.write(this.$T);
            $serializer.write(this.$U);
            $serializer.write(this.$R);
            $serializer.write(this.op);
            
        }
        
        // constructor just for allocation
        public $Closure$142(final java.lang.System[] $dummy, final x10.rtt.Type $T, final x10.rtt.Type $U, final x10.rtt.Type $R) {
            x10.interop.Java8.$Closure$142.$initParams(this, $T, $U, $R);
            
        }
        
        // dispatcher for method abstract public (Z1,Z2)=>U.operator()(a1:Z1, a2:Z2):U
        public java.lang.Object $apply(final java.lang.Object a1, final x10.rtt.Type t1, final java.lang.Object a2, final x10.rtt.Type t2) {
            return $apply__0x10$interop$Java8$$Closure$142$$T__1x10$interop$Java8$$Closure$142$$U$G(($T)a1, ($U)a2);
            
        }
        
        private x10.rtt.Type $T;
        private x10.rtt.Type $U;
        private x10.rtt.Type $R;
        
        // initializer of type parameters
        public static void $initParams(final $Closure$142 $this, final x10.rtt.Type $T, final x10.rtt.Type $U, final x10.rtt.Type $R) {
            $this.$T = $T;
            $this.$U = $U;
            $this.$R = $R;
            
        }
        
    
        
        public $R $apply__0x10$interop$Java8$$Closure$142$$T__1x10$interop$Java8$$Closure$142$$U$G(final $T t, final $U u) {
            
            //#line 392 "x10/interop/Java8.x10"
            final java.lang.Object t$129727 = this.op.apply(((java.lang.Object)(t)), ((java.lang.Object)(u)));
            
            //#line 392 "x10/interop/Java8.x10"
            final $R t$129728 = (($R)(x10.rtt.Types.<$R> cast(t$129727,$R)));
            
            //#line 392 "x10/interop/Java8.x10"
            return t$129728;
        }
        
        public java.util.function.BiFunction op;
        
        public $Closure$142(final x10.rtt.Type $T, final x10.rtt.Type $U, final x10.rtt.Type $R, final java.util.function.BiFunction op) {
            x10.interop.Java8.$Closure$142.$initParams(this, $T, $U, $R);
             {
                ((x10.interop.Java8.$Closure$142<$T, $U, $R>)this).op = ((java.util.function.BiFunction)(op));
            }
        }
        
    }
    
    @x10.runtime.impl.java.X10Generated
    final public static class $Closure$143 extends x10.core.Ref implements x10.core.fun.VoidFun_0_0, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<$Closure$143> $RTT = 
            x10.rtt.StaticVoidFunType.<$Closure$143> make($Closure$143.class,
                                                          new x10.rtt.Type[] {
                                                              x10.core.fun.VoidFun_0_0.$RTT
                                                          });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static x10.serialization.X10JavaSerializable $_deserialize_body(x10.interop.Java8.$Closure$143 $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            $_obj.op = $deserializer.readObject();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.interop.Java8.$Closure$143 $_obj = new x10.interop.Java8.$Closure$143((java.lang.System[]) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            $serializer.write(this.op);
            
        }
        
        // constructor just for allocation
        public $Closure$143(final java.lang.System[] $dummy) {
            
        }
        
        
    
        
        public void $apply() {
            
            //#line 419 "x10/interop/Java8.x10"
            this.op.run();
        }
        
        public java.lang.Runnable op;
        
        public $Closure$143(final java.lang.Runnable op) {
             {
                this.op = ((java.lang.Runnable)(op));
            }
        }
        
    }
    
}

