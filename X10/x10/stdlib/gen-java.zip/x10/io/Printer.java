package x10.io;


/**
 * Usage:
 *
 * try {
 *    val input = new File(inputFileName);
 *    val output = new File(outputFileName);
 *    val p = output.printer();
 *    for (line in input.lines()) {
 *       p.println(line);
 *    }
 *    p.flush();
 * } catch (IOException) { }
 */
@x10.runtime.impl.java.X10Generated
public class Printer extends x10.io.FilterWriter implements x10.serialization.X10JavaSerializable
{
    public static final x10.rtt.RuntimeType<Printer> $RTT = 
        x10.rtt.NamedType.<Printer> make("x10.io.Printer",
                                         Printer.class,
                                         new x10.rtt.Type[] {
                                             x10.io.FilterWriter.$RTT
                                         });
    
    public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
    
    public x10.rtt.Type<?> $getParam(int i) { return null; }
    
    private Object writeReplace() throws java.io.ObjectStreamException {
        return new x10.serialization.SerializationProxy(this);
    }
    
    public static x10.serialization.X10JavaSerializable $_deserialize_body(x10.io.Printer $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
        x10.io.FilterWriter.$_deserialize_body($_obj, $deserializer);
        $_obj.lock = $deserializer.readObject();
        return $_obj;
    }
    
    public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
        x10.io.Printer $_obj = new x10.io.Printer((java.lang.System[]) null);
        $deserializer.record_reference($_obj);
        return $_deserialize_body($_obj, $deserializer);
    }
    
    public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
        super.$_serialize($serializer);
        $serializer.write(this.lock);
        
    }
    
    // constructor just for allocation
    public Printer(final java.lang.System[] $dummy) {
        super($dummy);
        
    }
    
    

    
    
    //#line 32 "x10/io/Printer.x10"
    // creation method for java code (1-phase java constructor)
    public Printer(final x10.io.Writer w) {
        this((java.lang.System[]) null);
        x10$io$Printer$$init$S(w);
    }
    
    // constructor for non-virtual call
    final public x10.io.Printer x10$io$Printer$$init$S(final x10.io.Writer w) {
         {
            
            //#line 32 "x10/io/Printer.x10"
            /*super.*/x10$io$FilterWriter$$init$S(((x10.io.Writer)(w)));
            
            //#line 32 "x10/io/Printer.x10"
            
            
            //#line 31 "x10/io/Printer.x10"
            final x10.io.Printer this$130991 = this;
            
            //#line 36 . "x10/io/Printer.x10"
            final x10.util.concurrent.Lock t$130990 = ((x10.util.concurrent.Lock)(new x10.util.concurrent.Lock()));
            
            //#line 31 "x10/io/Printer.x10"
            this$130991.lock = ((x10.util.concurrent.Lock)(t$130990));
        }
        return this;
    }
    
    
    
    //#line 34 "x10/io/Printer.x10"
    final private static char NEWLINE = '\n';
    
    //#line 36 "x10/io/Printer.x10"
    public x10.util.concurrent.Lock lock;
    
    
    //#line 38 "x10/io/Printer.x10"
    public void println() {
        
        //#line 38 "x10/io/Printer.x10"
        this.print(x10.core.Char.$box('\n'));
    }
    
    
    //#line 40 "x10/io/Printer.x10"
    final public void println(final java.lang.Object o) {
        
        //#line 41 "x10/io/Printer.x10"
        final boolean t$130959 = ((o) == (null));
        
        //#line 41 "x10/io/Printer.x10"
        java.lang.String t$130960 =  null;
        
        //#line 41 "x10/io/Printer.x10"
        if (t$130959) {
            
            //#line 41 "x10/io/Printer.x10"
            t$130960 = "null\n";
        } else {
            
            //#line 41 "x10/io/Printer.x10"
            final java.lang.String t$130958 = x10.rtt.Types.toString(o);
            
            //#line 41 "x10/io/Printer.x10"
            t$130960 = ((t$130958) + ("\n"));
        }
        
        //#line 41 "x10/io/Printer.x10"
        this.print(((java.lang.String)(t$130960)));
    }
    
    
    //#line 44 "x10/io/Printer.x10"
    final public void println(final java.lang.Throwable e) {
        
        //#line 45 "x10/io/Printer.x10"
        final boolean t$130963 = ((e) == (null));
        
        //#line 45 "x10/io/Printer.x10"
        java.lang.String t$130964 =  null;
        
        //#line 45 "x10/io/Printer.x10"
        if (t$130963) {
            
            //#line 45 "x10/io/Printer.x10"
            t$130964 = "null\n";
        } else {
            
            //#line 45 "x10/io/Printer.x10"
            final java.lang.String t$130962 = x10.runtime.impl.java.ThrowableUtils.toString(e);
            
            //#line 45 "x10/io/Printer.x10"
            t$130964 = ((t$130962) + ("\n"));
        }
        
        //#line 45 "x10/io/Printer.x10"
        this.print(((java.lang.String)(t$130964)));
    }
    
    
    //#line 48 "x10/io/Printer.x10"
    final public void print(final java.lang.Object o) {
        
        //#line 49 "x10/io/Printer.x10"
        final boolean t$130966 = ((o) == (null));
        
        //#line 49 "x10/io/Printer.x10"
        java.lang.String t$130967 =  null;
        
        //#line 49 "x10/io/Printer.x10"
        if (t$130966) {
            
            //#line 49 "x10/io/Printer.x10"
            t$130967 = "null";
        } else {
            
            //#line 49 "x10/io/Printer.x10"
            t$130967 = x10.rtt.Types.toString(o);
        }
        
        //#line 49 "x10/io/Printer.x10"
        this.print(((java.lang.String)(t$130967)));
    }
    
    
    //#line 52 "x10/io/Printer.x10"
    public void print(final java.lang.String s) {
        
        //#line 53 "x10/io/Printer.x10"
        final x10.util.concurrent.Lock t$130969 = ((x10.util.concurrent.Lock)(this.lock));
        
        //#line 53 "x10/io/Printer.x10"
        t$130969.lock();
        
        //#line 54 "x10/io/Printer.x10"
        try {{
            
            //#line 55 "x10/io/Printer.x10"
            final boolean t$130970 = ((s) == (null));
            
            //#line 55 "x10/io/Printer.x10"
            if (t$130970) {
                
                //#line 56 "x10/io/Printer.x10"
                this.write(((java.lang.String)("null")));
            } else {
                
                //#line 58 "x10/io/Printer.x10"
                this.write(((java.lang.String)(s)));
            }
        }}finally {{
              
              //#line 61 "x10/io/Printer.x10"
              final x10.util.concurrent.Lock t$130971 = ((x10.util.concurrent.Lock)(this.lock));
              
              //#line 61 "x10/io/Printer.x10"
              t$130971.unlock();
          }}
        }
    
    
    //#line 65 "x10/io/Printer.x10"
    final public void print(final java.lang.Throwable e) {
        
        //#line 66 "x10/io/Printer.x10"
        final boolean t$130972 = ((e) == (null));
        
        //#line 66 "x10/io/Printer.x10"
        java.lang.String t$130973 =  null;
        
        //#line 66 "x10/io/Printer.x10"
        if (t$130972) {
            
            //#line 66 "x10/io/Printer.x10"
            t$130973 = "null";
        } else {
            
            //#line 66 "x10/io/Printer.x10"
            t$130973 = x10.runtime.impl.java.ThrowableUtils.toString(e);
        }
        
        //#line 66 "x10/io/Printer.x10"
        this.print(((java.lang.String)(t$130973)));
    }
    
    
    //#line 69 "x10/io/Printer.x10"
    public void printf(final java.lang.String fmt) {
        
        //#line 69 "x10/io/Printer.x10"
        final x10.core.Rail t$130975 = ((x10.core.Rail)(new x10.core.Rail<java.lang.Object>(x10.rtt.Types.ANY, ((long)(0L)))));
        
        //#line 69 "x10/io/Printer.x10"
        this.printfRail__1$1x10$lang$Any$2(((java.lang.String)(fmt)), ((x10.core.Rail)(t$130975)));
    }
    
    
    //#line 70 "x10/io/Printer.x10"
    public void printf(final java.lang.String fmt, final java.lang.Object o1) {
        
        //#line 70 "x10/io/Printer.x10"
        final java.lang.Object t$130976 = ((java.lang.Object)
                                            o1);
        
        //#line 70 "x10/io/Printer.x10"
        final x10.core.Rail t$130977 = ((x10.core.Rail)(x10.runtime.impl.java.ArrayUtils.<java.lang.Object> makeRailFromJavaArray(x10.rtt.Types.ANY, new java.lang.Object[] {t$130976})));
        
        //#line 70 "x10/io/Printer.x10"
        this.printfRail__1$1x10$lang$Any$2(((java.lang.String)(fmt)), ((x10.core.Rail)(t$130977)));
    }
    
    
    //#line 71 "x10/io/Printer.x10"
    public void printf(final java.lang.String fmt, final java.lang.Object o1, final java.lang.Object o2) {
        
        //#line 71 "x10/io/Printer.x10"
        final java.lang.Object t$130978 = ((java.lang.Object)
                                            o1);
        
        //#line 71 "x10/io/Printer.x10"
        final x10.core.Rail t$130979 = ((x10.core.Rail)(x10.runtime.impl.java.ArrayUtils.<java.lang.Object> makeRailFromJavaArray(x10.rtt.Types.ANY, new java.lang.Object[] {t$130978, o2})));
        
        //#line 71 "x10/io/Printer.x10"
        this.printfRail__1$1x10$lang$Any$2(((java.lang.String)(fmt)), ((x10.core.Rail)(t$130979)));
    }
    
    
    //#line 72 "x10/io/Printer.x10"
    public void printf(final java.lang.String fmt, final java.lang.Object o1, final java.lang.Object o2, final java.lang.Object o3) {
        
        //#line 72 "x10/io/Printer.x10"
        final java.lang.Object t$130980 = ((java.lang.Object)
                                            o1);
        
        //#line 72 "x10/io/Printer.x10"
        final x10.core.Rail t$130981 = ((x10.core.Rail)(x10.runtime.impl.java.ArrayUtils.<java.lang.Object> makeRailFromJavaArray(x10.rtt.Types.ANY, new java.lang.Object[] {t$130980, o2, o3})));
        
        //#line 72 "x10/io/Printer.x10"
        this.printfRail__1$1x10$lang$Any$2(((java.lang.String)(fmt)), ((x10.core.Rail)(t$130981)));
    }
    
    
    //#line 73 "x10/io/Printer.x10"
    public void printf(final java.lang.String fmt, final java.lang.Object o1, final java.lang.Object o2, final java.lang.Object o3, final java.lang.Object o4) {
        
        //#line 73 "x10/io/Printer.x10"
        final java.lang.Object t$130982 = ((java.lang.Object)
                                            o1);
        
        //#line 73 "x10/io/Printer.x10"
        final x10.core.Rail t$130983 = ((x10.core.Rail)(x10.runtime.impl.java.ArrayUtils.<java.lang.Object> makeRailFromJavaArray(x10.rtt.Types.ANY, new java.lang.Object[] {t$130982, o2, o3, o4})));
        
        //#line 73 "x10/io/Printer.x10"
        this.printfRail__1$1x10$lang$Any$2(((java.lang.String)(fmt)), ((x10.core.Rail)(t$130983)));
    }
    
    
    //#line 74 "x10/io/Printer.x10"
    public void printf(final java.lang.String fmt, final java.lang.Object o1, final java.lang.Object o2, final java.lang.Object o3, final java.lang.Object o4, final java.lang.Object o5) {
        
        //#line 74 "x10/io/Printer.x10"
        final java.lang.Object t$130984 = ((java.lang.Object)
                                            o1);
        
        //#line 74 "x10/io/Printer.x10"
        final x10.core.Rail t$130985 = ((x10.core.Rail)(x10.runtime.impl.java.ArrayUtils.<java.lang.Object> makeRailFromJavaArray(x10.rtt.Types.ANY, new java.lang.Object[] {t$130984, o2, o3, o4, o5})));
        
        //#line 74 "x10/io/Printer.x10"
        this.printfRail__1$1x10$lang$Any$2(((java.lang.String)(fmt)), ((x10.core.Rail)(t$130985)));
    }
    
    
    //#line 75 "x10/io/Printer.x10"
    public void printf(final java.lang.String fmt, final java.lang.Object o1, final java.lang.Object o2, final java.lang.Object o3, final java.lang.Object o4, final java.lang.Object o5, final java.lang.Object o6) {
        
        //#line 75 "x10/io/Printer.x10"
        final java.lang.Object t$130986 = ((java.lang.Object)
                                            o1);
        
        //#line 75 "x10/io/Printer.x10"
        final x10.core.Rail t$130987 = ((x10.core.Rail)(x10.runtime.impl.java.ArrayUtils.<java.lang.Object> makeRailFromJavaArray(x10.rtt.Types.ANY, new java.lang.Object[] {t$130986, o2, o3, o4, o5, o6})));
        
        //#line 75 "x10/io/Printer.x10"
        this.printfRail__1$1x10$lang$Any$2(((java.lang.String)(fmt)), ((x10.core.Rail)(t$130987)));
    }
    
    
    //#line 77 "x10/io/Printer.x10"
    public void printf__1$1x10$lang$Any$2(final java.lang.String fmt, final x10.core.Rail args) {
        
        //#line 78 "x10/io/Printer.x10"
        this.printfRail__1$1x10$lang$Any$2(((java.lang.String)(fmt)), ((x10.core.Rail)(args)));
    }
    
    
    //#line 80 "x10/io/Printer.x10"
    public void printfRail__1$1x10$lang$Any$2(final java.lang.String fmt, final x10.core.Rail args) {
        
        //#line 81 "x10/io/Printer.x10"
        final java.lang.String t$130988 = x10.runtime.impl.java.StringUtils.format(fmt,(java.lang.Object[]) (args).value);
        
        //#line 81 "x10/io/Printer.x10"
        this.print(((java.lang.String)(t$130988)));
    }
    
    
    //#line 84 "x10/io/Printer.x10"
    public void flush() {
        
        //#line 85 "x10/io/Printer.x10"
        try {{
            
            //#line 86 "x10/io/Printer.x10"
            super.flush();
        }}catch (final x10.io.IOException id$230) {
            
        }
    }
    
    
    //#line 91 "x10/io/Printer.x10"
    public void close() {
        
        //#line 92 "x10/io/Printer.x10"
        try {{
            
            //#line 93 "x10/io/Printer.x10"
            super.close();
        }}catch (final x10.io.IOException id$231) {
            
        }
    }
    
    
    //#line 31 "x10/io/Printer.x10"
    final public x10.io.Printer x10$io$Printer$$this$x10$io$Printer() {
        
        //#line 31 "x10/io/Printer.x10"
        return x10.io.Printer.this;
    }
    
    
    //#line 31 "x10/io/Printer.x10"
    final public void __fieldInitializers_x10_io_Printer() {
        
        //#line 36 "x10/io/Printer.x10"
        final x10.util.concurrent.Lock t$130989 = ((x10.util.concurrent.Lock)(new x10.util.concurrent.Lock()));
        
        //#line 31 "x10/io/Printer.x10"
        this.lock = ((x10.util.concurrent.Lock)(t$130989));
    }
    
    public static char get$NEWLINE() {
        return x10.io.Printer.NEWLINE;
    }
    
    public void x10$io$FilterWriter$flush$S() {
        super.flush();
    }
    
    public void x10$io$FilterWriter$close$S() {
        super.close();
    }
    }
    
    