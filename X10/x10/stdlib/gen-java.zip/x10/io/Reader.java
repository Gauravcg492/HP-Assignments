package x10.io;

/**
 * Usage:
 *
 * try {
 *    val input = new File(inputFileName);
 *    val output = new File(outputFileName);
 *    val p = output.printer();
 *    for (line in input.lines()) {
 *       p.println(line);
 *    }
 *    p.flush();
 * } catch (IOException) { }
 */
@x10.runtime.impl.java.X10Generated
abstract public class Reader extends x10.core.Ref implements x10.serialization.X10JavaSerializable
{
    public static final x10.rtt.RuntimeType<Reader> $RTT = 
        x10.rtt.NamedType.<Reader> make("x10.io.Reader",
                                        Reader.class);
    
    public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
    
    public x10.rtt.Type<?> $getParam(int i) { return null; }
    
    public static x10.serialization.X10JavaSerializable $_deserialize_body(x10.io.Reader $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
        return $_obj;
    }
    
    public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
        return null;
    }
    
    public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
        
    }
    
    // constructor just for allocation
    public Reader(final java.lang.System[] $dummy) {
        
    }
    
    

    
    
    //#line 31 "x10/io/Reader.x10"
    /**
     * Close the input stream
     */
    abstract public void close();
    
    
    //#line 36 "x10/io/Reader.x10"
    /**
     * Read the next Byte from the input; throws IOException if none.
     */
    abstract public byte read$O();
    
    
    //#line 44 "x10/io/Reader.x10"
    /**
     * Fill len bytes of the argument rail starting at off.
     * Throws IOException if not enough elements.
     * This is significantly faster than read(Marshal.BYTE,r,off,len)
     * since this reads multiple bytes at once if possible.
     */
    abstract public void read__0$1x10$lang$Byte$2(final x10.core.Rail r, final long off, final long len);
    
    
    //#line 53 "x10/io/Reader.x10"
    /**
     * How many bytes can be read from this stream without blocking?
     *
     * NOTE: there may actually be more bytes than this available when
     * the read is made, in particular this method may return 0 even
     * if a non-zero number of bytes are actually available.
     */
    abstract public long available$O();
    
    
    //#line 55 "x10/io/Reader.x10"
    abstract public void skip(final long v);
    
    
    //#line 57 "x10/io/Reader.x10"
    abstract public void mark(final long m);
    
    
    //#line 58 "x10/io/Reader.x10"
    abstract public void reset();
    
    
    //#line 59 "x10/io/Reader.x10"
    abstract public boolean markSupported$O();
    
    
    //#line 64 "x10/io/Reader.x10"
    /**
     * Read the next Boolean from the input; throws IOException if none.
     */
    public boolean readBoolean$O() {
        
        //#line 64 "x10/io/Reader.x10"
        x10.io.Marshal.$Shadow.get$BOOLEAN();
        
        //#line 64 "x10/io/Reader.x10"
        final x10.io.Reader r$131109 = ((x10.io.Reader)(this));
        
        //#line 56 . "x10/io/Marshal.x10"
        final byte t$131132 = r$131109.read$O();
        
        //#line 56 . "x10/io/Marshal.x10"
        final boolean t$131133 = ((byte) t$131132) != ((byte) ((byte) 0));
        
        //#line 64 "x10/io/Reader.x10"
        return t$131133;
    }
    
    
    //#line 69 "x10/io/Reader.x10"
    /**
     * Read the next Byte from the input; throws IOException if none.
     */
    public byte readByte$O() {
        
        //#line 69 "x10/io/Reader.x10"
        x10.io.Marshal.$Shadow.get$BYTE();
        
        //#line 69 "x10/io/Reader.x10"
        final x10.io.Reader r$131112 = ((x10.io.Reader)(this));
        
        //#line 63 . "x10/io/Marshal.x10"
        final byte t$131134 = r$131112.read$O();
        
        //#line 69 "x10/io/Reader.x10"
        return t$131134;
    }
    
    
    //#line 74 "x10/io/Reader.x10"
    /**
     * Read the next UByte from the input; throws IOException if none.
     */
    public byte readUByte$O() {
        
        //#line 74 "x10/io/Reader.x10"
        final x10.io.Marshal.UByteMarshal t$131135 = ((x10.io.Marshal.UByteMarshal)(x10.io.Marshal.$Shadow.get$UBYTE()));
        
        //#line 74 "x10/io/Reader.x10"
        final byte t$131136 = t$131135.read$O(((x10.io.Reader)(this)));
        
        //#line 74 "x10/io/Reader.x10"
        return t$131136;
    }
    
    
    //#line 79 "x10/io/Reader.x10"
    /**
     * Read the next Char from the input; throws IOException if none.
     */
    public char readChar$O() {
        
        //#line 79 "x10/io/Reader.x10"
        final x10.io.Marshal.CharMarshal t$131137 = ((x10.io.Marshal.CharMarshal)(x10.io.Marshal.$Shadow.get$CHAR()));
        
        //#line 79 "x10/io/Reader.x10"
        final char t$131138 = t$131137.read$O(((x10.io.Reader)(this)));
        
        //#line 79 "x10/io/Reader.x10"
        return t$131138;
    }
    
    
    //#line 84 "x10/io/Reader.x10"
    /**
     * Read the next Short from the input; throws IOException if none.
     */
    public short readShort$O() {
        
        //#line 84 "x10/io/Reader.x10"
        final x10.io.Marshal.ShortMarshal t$131139 = ((x10.io.Marshal.ShortMarshal)(x10.io.Marshal.$Shadow.get$SHORT()));
        
        //#line 84 "x10/io/Reader.x10"
        final short t$131140 = t$131139.read$O(((x10.io.Reader)(this)));
        
        //#line 84 "x10/io/Reader.x10"
        return t$131140;
    }
    
    
    //#line 89 "x10/io/Reader.x10"
    /**
     * Read the next UShort from the input; throws IOException if none.
     */
    public short readUShort$O() {
        
        //#line 89 "x10/io/Reader.x10"
        final x10.io.Marshal.UShortMarshal t$131141 = ((x10.io.Marshal.UShortMarshal)(x10.io.Marshal.$Shadow.get$USHORT()));
        
        //#line 89 "x10/io/Reader.x10"
        final short t$131142 = t$131141.read$O(((x10.io.Reader)(this)));
        
        //#line 89 "x10/io/Reader.x10"
        return t$131142;
    }
    
    
    //#line 94 "x10/io/Reader.x10"
    /**
     * Read the next Int from the input; throws IOException if none.
     */
    public int readInt$O() {
        
        //#line 94 "x10/io/Reader.x10"
        final x10.io.Marshal.IntMarshal t$131143 = ((x10.io.Marshal.IntMarshal)(x10.io.Marshal.$Shadow.get$INT()));
        
        //#line 94 "x10/io/Reader.x10"
        final int t$131144 = t$131143.read$O(((x10.io.Reader)(this)));
        
        //#line 94 "x10/io/Reader.x10"
        return t$131144;
    }
    
    
    //#line 99 "x10/io/Reader.x10"
    /**
     * Read the next UInt from the input; throws IOException if none.
     */
    public int readUInt$O() {
        
        //#line 99 "x10/io/Reader.x10"
        final x10.io.Marshal.UIntMarshal t$131145 = ((x10.io.Marshal.UIntMarshal)(x10.io.Marshal.$Shadow.get$UINT()));
        
        //#line 99 "x10/io/Reader.x10"
        final int t$131146 = t$131145.read$O(((x10.io.Reader)(this)));
        
        //#line 99 "x10/io/Reader.x10"
        return t$131146;
    }
    
    
    //#line 104 "x10/io/Reader.x10"
    /**
     * Read the next Long from the input; throws IOException if none.
     */
    public long readLong$O() {
        
        //#line 104 "x10/io/Reader.x10"
        final x10.io.Marshal.LongMarshal t$131147 = ((x10.io.Marshal.LongMarshal)(x10.io.Marshal.$Shadow.get$LONG()));
        
        //#line 104 "x10/io/Reader.x10"
        final long t$131148 = t$131147.read$O(((x10.io.Reader)(this)));
        
        //#line 104 "x10/io/Reader.x10"
        return t$131148;
    }
    
    
    //#line 109 "x10/io/Reader.x10"
    /**
     * Read the next ULong from the input; throws IOException if none.
     */
    public long readULong$O() {
        
        //#line 109 "x10/io/Reader.x10"
        final x10.io.Marshal.ULongMarshal t$131149 = ((x10.io.Marshal.ULongMarshal)(x10.io.Marshal.$Shadow.get$ULONG()));
        
        //#line 109 "x10/io/Reader.x10"
        final long t$131150 = t$131149.read$O(((x10.io.Reader)(this)));
        
        //#line 109 "x10/io/Reader.x10"
        return t$131150;
    }
    
    
    //#line 114 "x10/io/Reader.x10"
    /**
     * Read the next Float from the input; throws IOException if none.
     */
    public float readFloat$O() {
        
        //#line 114 "x10/io/Reader.x10"
        final x10.io.Marshal.FloatMarshal t$131151 = ((x10.io.Marshal.FloatMarshal)(x10.io.Marshal.$Shadow.get$FLOAT()));
        
        //#line 114 "x10/io/Reader.x10"
        final float t$131152 = t$131151.read$O(((x10.io.Reader)(this)));
        
        //#line 114 "x10/io/Reader.x10"
        return t$131152;
    }
    
    
    //#line 119 "x10/io/Reader.x10"
    /**
     * Read the next Double from the input; throws IOException if none.
     */
    public double readDouble$O() {
        
        //#line 119 "x10/io/Reader.x10"
        final x10.io.Marshal.DoubleMarshal t$131153 = ((x10.io.Marshal.DoubleMarshal)(x10.io.Marshal.$Shadow.get$DOUBLE()));
        
        //#line 119 "x10/io/Reader.x10"
        final double t$131154 = t$131153.read$O(((x10.io.Reader)(this)));
        
        //#line 119 "x10/io/Reader.x10"
        return t$131154;
    }
    
    
    //#line 124 "x10/io/Reader.x10"
    /**
     * Read the next line from the input; throws IOException if none.
     */
    public java.lang.String readLine() {
        
        //#line 124 "x10/io/Reader.x10"
        final x10.io.Marshal.LineMarshal t$131155 = ((x10.io.Marshal.LineMarshal)(x10.io.Marshal.$Shadow.get$LINE()));
        
        //#line 124 "x10/io/Reader.x10"
        final java.lang.String t$131156 = t$131155.read(((x10.io.Reader)(this)));
        
        //#line 124 "x10/io/Reader.x10"
        return t$131156;
    }
    
    
    //#line 129 "x10/io/Reader.x10"
    /**
     * Read the next value from the input; throws IOException if none.
     */
    final public <$T>$T read__0$1x10$io$Reader$$T$2$G(final x10.rtt.Type $T, final x10.io.Marshal m) {
        
        //#line 129 "x10/io/Reader.x10"
        final $T t$131157 = (($T)(((x10.io.Marshal<$T>)m).read$G(((x10.io.Reader)(this)))));
        
        //#line 129 "x10/io/Reader.x10"
        return t$131157;
    }
    
    
    //#line 135 "x10/io/Reader.x10"
    /**
     * Fill the argument rail by reading the next a.size elements. 
     * Throws IOException if not enough elements.
     */
    final public <$T>void read__0$1x10$io$Reader$$T$2__1$1x10$io$Reader$$T$2(final x10.rtt.Type $T, final x10.io.Marshal m, final x10.core.Rail a) {
        
        //#line 136 "x10/io/Reader.x10"
        final long t$131158 = ((x10.core.Rail<$T>)a).size;
        
        //#line 136 "x10/io/Reader.x10"
        this.<$T> read__0$1x10$io$Reader$$T$2__1$1x10$io$Reader$$T$2($T, ((x10.io.Marshal)(m)), ((x10.core.Rail)(a)), (long)(0L), (long)(t$131158));
    }
    
    
    //#line 143 "x10/io/Reader.x10"
    /**
     * Fill len elements of the argument rail starting at off.
     * Throws IOException if not enough elements.
     */
    final public <$T>void read__0$1x10$io$Reader$$T$2__1$1x10$io$Reader$$T$2(final x10.rtt.Type $T, final x10.io.Marshal m, final x10.core.Rail a, final long off, final long len) {
        
        //#line 144 "x10/io/Reader.x10"
        long i = off;
        
        //#line 144 "x10/io/Reader.x10"
        for (;
             true;
             ) {
            
            //#line 144 "x10/io/Reader.x10"
            final long t$131161 = ((off) + (((long)(len))));
            
            //#line 144 "x10/io/Reader.x10"
            final boolean t$131166 = ((i) < (((long)(t$131161))));
            
            //#line 144 "x10/io/Reader.x10"
            if (!(t$131166)) {
                
                //#line 144 "x10/io/Reader.x10"
                break;
            }
            
            //#line 145 "x10/io/Reader.x10"
            final x10.io.Reader this$131174 = ((x10.io.Reader)(this));
            
            //#line 129 . "x10/io/Reader.x10"
            final $T t$131176 = (($T)(((x10.io.Marshal<$T>)m).read$G(((x10.io.Reader)(this$131174)))));
            
            //#line 145 "x10/io/Reader.x10"
            ((x10.core.Rail<$T>)a).$set__1x10$lang$Rail$$T$G((long)(i), (($T)(t$131176)));
            
            //#line 144 "x10/io/Reader.x10"
            final long t$131178 = ((i) + (((long)(1L))));
            
            //#line 144 "x10/io/Reader.x10"
            i = t$131178;
        }
    }
    
    
    //#line 149 "x10/io/Reader.x10"
    public x10.io.ReaderIterator lines() {
        
        //#line 149 "x10/io/Reader.x10"
        final x10.io.ReaderIterator alloc$129939 = ((x10.io.ReaderIterator)(new x10.io.ReaderIterator<java.lang.String>((java.lang.System[]) null, x10.rtt.Types.STRING)));
        
        //#line 149 "x10/io/Reader.x10"
        final x10.io.Marshal.LineMarshal t$131167 = ((x10.io.Marshal.LineMarshal)(x10.io.Marshal.$Shadow.get$LINE()));
        
        //#line 149 "x10/io/Reader.x10"
        final x10.io.Marshal m$131118 = ((x10.io.Marshal)(((x10.io.Marshal<java.lang.String>)
                                                            t$131167)));
        
        //#line 149 "x10/io/Reader.x10"
        final x10.io.Reader r$131119 = ((x10.io.Reader)(this));
        
        //#line 32 .. "x10/io/ReaderIterator.x10"
        final java.lang.String t$131179 = (java.lang.String) x10.rtt.Types.zeroValue(x10.rtt.Types.STRING);
        
        //#line 29 .. "x10/io/ReaderIterator.x10"
        ((x10.io.ReaderIterator<java.lang.String>)alloc$129939).next = t$131179;
        
        //#line 35 . "x10/io/ReaderIterator.x10"
        ((x10.io.ReaderIterator<java.lang.String>)alloc$129939).m = ((x10.io.Marshal)(m$131118));
        
        //#line 36 . "x10/io/ReaderIterator.x10"
        ((x10.io.ReaderIterator<java.lang.String>)alloc$129939).r = ((x10.io.Reader)(r$131119));
        
        //#line 149 "x10/io/Reader.x10"
        return alloc$129939;
    }
    
    
    //#line 150 "x10/io/Reader.x10"
    public x10.io.ReaderIterator chars() {
        
        //#line 150 "x10/io/Reader.x10"
        final x10.io.ReaderIterator alloc$129940 = ((x10.io.ReaderIterator)(new x10.io.ReaderIterator<x10.core.Char>((java.lang.System[]) null, x10.rtt.Types.CHAR)));
        
        //#line 150 "x10/io/Reader.x10"
        final x10.io.Marshal.CharMarshal t$131169 = ((x10.io.Marshal.CharMarshal)(x10.io.Marshal.$Shadow.get$CHAR()));
        
        //#line 150 "x10/io/Reader.x10"
        final x10.io.Marshal m$131122 = ((x10.io.Marshal)(((x10.io.Marshal<x10.core.Char>)
                                                            t$131169)));
        
        //#line 150 "x10/io/Reader.x10"
        final x10.io.Reader r$131123 = ((x10.io.Reader)(this));
        
        //#line 32 .. "x10/io/ReaderIterator.x10"
        final char t$131180 = x10.core.Char.$unbox((x10.core.Char) x10.rtt.Types.zeroValue(x10.rtt.Types.CHAR));
        
        //#line 29 .. "x10/io/ReaderIterator.x10"
        ((x10.io.ReaderIterator<x10.core.Char>)alloc$129940).next = x10.core.Char.$box(t$131180);
        
        //#line 35 . "x10/io/ReaderIterator.x10"
        ((x10.io.ReaderIterator<x10.core.Char>)alloc$129940).m = ((x10.io.Marshal)(m$131122));
        
        //#line 36 . "x10/io/ReaderIterator.x10"
        ((x10.io.ReaderIterator<x10.core.Char>)alloc$129940).r = ((x10.io.Reader)(r$131123));
        
        //#line 150 "x10/io/Reader.x10"
        return alloc$129940;
    }
    
    
    //#line 151 "x10/io/Reader.x10"
    public x10.io.ReaderIterator bytes() {
        
        //#line 151 "x10/io/Reader.x10"
        final x10.io.ReaderIterator alloc$129941 = ((x10.io.ReaderIterator)(new x10.io.ReaderIterator<x10.core.Byte>((java.lang.System[]) null, x10.rtt.Types.BYTE)));
        
        //#line 151 "x10/io/Reader.x10"
        final x10.io.Marshal.ByteMarshal t$131171 = ((x10.io.Marshal.ByteMarshal)(x10.io.Marshal.$Shadow.get$BYTE()));
        
        //#line 151 "x10/io/Reader.x10"
        final x10.io.Marshal m$131126 = ((x10.io.Marshal)(((x10.io.Marshal<x10.core.Byte>)
                                                            t$131171)));
        
        //#line 151 "x10/io/Reader.x10"
        final x10.io.Reader r$131127 = ((x10.io.Reader)(this));
        
        //#line 32 .. "x10/io/ReaderIterator.x10"
        final byte t$131181 = x10.core.Byte.$unbox((x10.core.Byte) x10.rtt.Types.zeroValue(x10.rtt.Types.BYTE));
        
        //#line 29 .. "x10/io/ReaderIterator.x10"
        ((x10.io.ReaderIterator<x10.core.Byte>)alloc$129941).next = x10.core.Byte.$box(t$131181);
        
        //#line 35 . "x10/io/ReaderIterator.x10"
        ((x10.io.ReaderIterator<x10.core.Byte>)alloc$129941).m = ((x10.io.Marshal)(m$131126));
        
        //#line 36 . "x10/io/ReaderIterator.x10"
        ((x10.io.ReaderIterator<x10.core.Byte>)alloc$129941).r = ((x10.io.Reader)(r$131127));
        
        //#line 151 "x10/io/Reader.x10"
        return alloc$129941;
    }
    
    
    //#line 27 "x10/io/Reader.x10"
    final public x10.io.Reader x10$io$Reader$$this$x10$io$Reader() {
        
        //#line 27 "x10/io/Reader.x10"
        return x10.io.Reader.this;
    }
    
    
    //#line 27 "x10/io/Reader.x10"
    
    // constructor for non-virtual call
    final public x10.io.Reader x10$io$Reader$$init$S() {
         {
            
            //#line 27 "x10/io/Reader.x10"
            
        }
        return this;
    }
    
    
    
    //#line 27 "x10/io/Reader.x10"
    final public void __fieldInitializers_x10_io_Reader() {
        
    }
}

