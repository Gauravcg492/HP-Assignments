package x10.io;


@x10.runtime.impl.java.X10Generated
abstract public class FileSystem extends x10.core.Ref implements x10.serialization.X10JavaSerializable
{
    public static final x10.rtt.RuntimeType<FileSystem> $RTT = 
        x10.rtt.NamedType.<FileSystem> make("x10.io.FileSystem",
                                            FileSystem.class);
    
    public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
    
    public x10.rtt.Type<?> $getParam(int i) { return null; }
    
    public static x10.serialization.X10JavaSerializable $_deserialize_body(x10.io.FileSystem $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
        return $_obj;
    }
    
    public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
        return null;
    }
    
    public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
        
    }
    
    // constructor just for allocation
    public FileSystem(final java.lang.System[] $dummy) {
        
    }
    
    

    
    //#line 17 "x10/io/FileSystem.x10"
    final public static char SEPARATOR_CHAR = '/';
    
    //#line 18 "x10/io/FileSystem.x10"
    final public static java.lang.String SEPARATOR = "/";
    
    //#line 19 "x10/io/FileSystem.x10"
    final public static char PATH_SEPARATOR_CHAR = ':';
    
    //#line 20 "x10/io/FileSystem.x10"
    final public static java.lang.String PATH_SEPARATOR = ":";
    
    
    //#line 22 "x10/io/FileSystem.x10"
    public void delete(final x10.io.File id$220) {
        
        //#line 23 "x10/io/FileSystem.x10"
        final java.lang.UnsupportedOperationException t$130062 = ((java.lang.UnsupportedOperationException)(new java.lang.UnsupportedOperationException()));
        
        //#line 23 "x10/io/FileSystem.x10"
        throw t$130062;
    }
    
    
    //#line 24 "x10/io/FileSystem.x10"
    public void deleteOnExit(final x10.io.File id$221) {
        
        //#line 25 "x10/io/FileSystem.x10"
        final java.lang.UnsupportedOperationException t$130063 = ((java.lang.UnsupportedOperationException)(new java.lang.UnsupportedOperationException()));
        
        //#line 25 "x10/io/FileSystem.x10"
        throw t$130063;
    }
    
    
    //#line 26 "x10/io/FileSystem.x10"
    public void rename(final x10.io.File f, final x10.io.File t) {
        
        //#line 27 "x10/io/FileSystem.x10"
        final java.lang.UnsupportedOperationException t$130064 = ((java.lang.UnsupportedOperationException)(new java.lang.UnsupportedOperationException()));
        
        //#line 27 "x10/io/FileSystem.x10"
        throw t$130064;
    }
    
    
    //#line 28 "x10/io/FileSystem.x10"
    public void mkdir(final x10.io.File id$222) {
        
        //#line 29 "x10/io/FileSystem.x10"
        final java.lang.UnsupportedOperationException t$130065 = ((java.lang.UnsupportedOperationException)(new java.lang.UnsupportedOperationException()));
        
        //#line 29 "x10/io/FileSystem.x10"
        throw t$130065;
    }
    
    
    //#line 30 "x10/io/FileSystem.x10"
    public void mkdirs(final x10.io.File id$223) {
        
        //#line 31 "x10/io/FileSystem.x10"
        final java.lang.UnsupportedOperationException t$130066 = ((java.lang.UnsupportedOperationException)(new java.lang.UnsupportedOperationException()));
        
        //#line 31 "x10/io/FileSystem.x10"
        throw t$130066;
    }
    
    
    //#line 32 "x10/io/FileSystem.x10"
    public boolean exists$O(final x10.io.File id$224) {
        
        //#line 33 "x10/io/FileSystem.x10"
        final java.lang.UnsupportedOperationException t$130067 = ((java.lang.UnsupportedOperationException)(new java.lang.UnsupportedOperationException()));
        
        //#line 33 "x10/io/FileSystem.x10"
        throw t$130067;
    }
    
    
    //#line 34 "x10/io/FileSystem.x10"
    public long size$O(final x10.io.File id$225) {
        
        //#line 35 "x10/io/FileSystem.x10"
        final java.lang.UnsupportedOperationException t$130068 = ((java.lang.UnsupportedOperationException)(new java.lang.UnsupportedOperationException()));
        
        //#line 35 "x10/io/FileSystem.x10"
        throw t$130068;
    }
    
    
    //#line 36 "x10/io/FileSystem.x10"
    public x10.core.Rail listFiles(final x10.io.File id$226) {
        
        //#line 37 "x10/io/FileSystem.x10"
        final java.lang.UnsupportedOperationException t$130069 = ((java.lang.UnsupportedOperationException)(new java.lang.UnsupportedOperationException()));
        
        //#line 37 "x10/io/FileSystem.x10"
        throw t$130069;
    }
    
    
    //#line 38 "x10/io/FileSystem.x10"
    public x10.core.Rail listFiles__1$1x10$io$File$3x10$lang$Boolean$2(final x10.io.File id$227, final x10.core.fun.Fun_0_1 id$229) {
        
        //#line 39 "x10/io/FileSystem.x10"
        final java.lang.UnsupportedOperationException t$130070 = ((java.lang.UnsupportedOperationException)(new java.lang.UnsupportedOperationException()));
        
        //#line 39 "x10/io/FileSystem.x10"
        throw t$130070;
    }
    
    
    //#line 16 "x10/io/FileSystem.x10"
    final public x10.io.FileSystem x10$io$FileSystem$$this$x10$io$FileSystem() {
        
        //#line 16 "x10/io/FileSystem.x10"
        return x10.io.FileSystem.this;
    }
    
    
    //#line 16 "x10/io/FileSystem.x10"
    
    // constructor for non-virtual call
    final public x10.io.FileSystem x10$io$FileSystem$$init$S() {
         {
            
            //#line 16 "x10/io/FileSystem.x10"
            
        }
        return this;
    }
    
    
    
    //#line 16 "x10/io/FileSystem.x10"
    final public void __fieldInitializers_x10_io_FileSystem() {
        
    }
    
    public static char get$SEPARATOR_CHAR() {
        return x10.io.FileSystem.SEPARATOR_CHAR;
    }
    
    public static java.lang.String get$SEPARATOR() {
        return x10.io.FileSystem.SEPARATOR;
    }
    
    public static char get$PATH_SEPARATOR_CHAR() {
        return x10.io.FileSystem.PATH_SEPARATOR_CHAR;
    }
    
    public static java.lang.String get$PATH_SEPARATOR() {
        return x10.io.FileSystem.PATH_SEPARATOR;
    }
}

