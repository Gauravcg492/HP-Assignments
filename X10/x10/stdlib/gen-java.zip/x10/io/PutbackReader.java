package x10.io;


@x10.runtime.impl.java.X10Generated
public class PutbackReader extends x10.io.FilterReader implements x10.serialization.X10JavaSerializable
{
    public static final x10.rtt.RuntimeType<PutbackReader> $RTT = 
        x10.rtt.NamedType.<PutbackReader> make("x10.io.PutbackReader",
                                               PutbackReader.class,
                                               new x10.rtt.Type[] {
                                                   x10.io.FilterReader.$RTT
                                               });
    
    public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
    
    public x10.rtt.Type<?> $getParam(int i) { return null; }
    
    private Object writeReplace() throws java.io.ObjectStreamException {
        return new x10.serialization.SerializationProxy(this);
    }
    
    public static x10.serialization.X10JavaSerializable $_deserialize_body(x10.io.PutbackReader $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
        x10.io.FilterReader.$_deserialize_body($_obj, $deserializer);
        $_obj.putback = $deserializer.readObject();
        return $_obj;
    }
    
    public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
        x10.io.PutbackReader $_obj = new x10.io.PutbackReader((java.lang.System[]) null);
        $deserializer.record_reference($_obj);
        return $_deserialize_body($_obj, $deserializer);
    }
    
    public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
        super.$_serialize($serializer);
        $serializer.write(this.putback);
        
    }
    
    // constructor just for allocation
    public PutbackReader(final java.lang.System[] $dummy) {
        super($dummy);
        
    }
    
    

    
    //#line 17 "x10/io/PutbackReader.x10"
    public x10.util.GrowableRail<x10.core.Byte> putback;
    
    
    //#line 19 "x10/io/PutbackReader.x10"
    // creation method for java code (1-phase java constructor)
    public PutbackReader(final x10.io.Reader r) {
        this((java.lang.System[]) null);
        x10$io$PutbackReader$$init$S(r);
    }
    
    // constructor for non-virtual call
    final public x10.io.PutbackReader x10$io$PutbackReader$$init$S(final x10.io.Reader r) {
         {
            
            //#line 20 "x10/io/PutbackReader.x10"
            /*super.*/x10$io$FilterReader$$init$S(((x10.io.Reader)(r)));
            
            //#line 19 "x10/io/PutbackReader.x10"
            
            
            //#line 21 "x10/io/PutbackReader.x10"
            final x10.util.GrowableRail alloc$131055 = ((x10.util.GrowableRail)(new x10.util.GrowableRail<x10.core.Byte>((java.lang.System[]) null, x10.rtt.Types.BYTE)));
            
            //#line 50 . "x10/util/GrowableRail.x10"
            alloc$131055.x10$util$GrowableRail$$init$S(((long)(0L)));
            
            //#line 21 "x10/io/PutbackReader.x10"
            this.putback = ((x10.util.GrowableRail)(alloc$131055));
        }
        return this;
    }
    
    
    
    //#line 24 "x10/io/PutbackReader.x10"
    public byte read$O() {
        
        //#line 25 "x10/io/PutbackReader.x10"
        final x10.util.GrowableRail this$131059 = ((x10.util.GrowableRail)(this.putback));
        
        //#line 166 . "x10/util/GrowableRail.x10"
        final long t$131067 = ((x10.util.GrowableRail<x10.core.Byte>)this$131059).size;
        
        //#line 25 "x10/io/PutbackReader.x10"
        final boolean t$131072 = ((t$131067) > (((long)(0L))));
        
        //#line 25 "x10/io/PutbackReader.x10"
        if (t$131072) {
            
            //#line 26 "x10/io/PutbackReader.x10"
            final x10.util.GrowableRail t$131069 = ((x10.util.GrowableRail)(this.putback));
            
            //#line 26 "x10/io/PutbackReader.x10"
            final x10.util.GrowableRail this$131061 = ((x10.util.GrowableRail)(this.putback));
            
            //#line 166 . "x10/util/GrowableRail.x10"
            final long t$131068 = ((x10.util.GrowableRail<x10.core.Byte>)this$131061).size;
            
            //#line 26 "x10/io/PutbackReader.x10"
            final long t$131070 = ((t$131068) - (((long)(1L))));
            
            //#line 26 "x10/io/PutbackReader.x10"
            final byte p = x10.core.Byte.$unbox(((x10.util.GrowableRail<x10.core.Byte>)t$131069).$apply$G((long)(t$131070)));
            
            //#line 27 "x10/io/PutbackReader.x10"
            final x10.util.GrowableRail t$131071 = ((x10.util.GrowableRail)(this.putback));
            
            //#line 27 "x10/io/PutbackReader.x10"
            ((x10.util.GrowableRail<x10.core.Byte>)t$131071).removeLast$G();
            
            //#line 28 "x10/io/PutbackReader.x10"
            return p;
        }
        
        //#line 30 "x10/io/PutbackReader.x10"
        final byte t$131073 = super.read$O();
        
        //#line 30 "x10/io/PutbackReader.x10"
        return t$131073;
    }
    
    
    //#line 33 "x10/io/PutbackReader.x10"
    public void read__0$1x10$lang$Byte$2(final x10.core.Rail r, final int off, final int len) {
        
        //#line 34 "x10/io/PutbackReader.x10"
        int read = 0;
        {
            
            //#line 35 "x10/io/PutbackReader.x10"
            final byte[] r$value$131108 = ((byte[])r.value);
            
            //#line 35 "x10/io/PutbackReader.x10"
            while (true) {
                
                //#line 35 "x10/io/PutbackReader.x10"
                final x10.util.GrowableRail this$131063 = ((x10.util.GrowableRail)(this.putback));
                
                //#line 166 . "x10/util/GrowableRail.x10"
                final long t$131074 = ((x10.util.GrowableRail<x10.core.Byte>)this$131063).size;
                
                //#line 35 "x10/io/PutbackReader.x10"
                final boolean t$131085 = ((t$131074) > (((long)(0L))));
                
                //#line 35 "x10/io/PutbackReader.x10"
                if (!(t$131085)) {
                    
                    //#line 35 "x10/io/PutbackReader.x10"
                    break;
                }
                
                //#line 36 "x10/io/PutbackReader.x10"
                final boolean t$131097 = ((read) >= (((int)(len))));
                
                //#line 36 "x10/io/PutbackReader.x10"
                if (t$131097) {
                    
                    //#line 36 "x10/io/PutbackReader.x10"
                    break;
                }
                
                //#line 37 "x10/io/PutbackReader.x10"
                final x10.util.GrowableRail t$131098 = ((x10.util.GrowableRail)(this.putback));
                
                //#line 37 "x10/io/PutbackReader.x10"
                final x10.util.GrowableRail this$131099 = ((x10.util.GrowableRail)(this.putback));
                
                //#line 166 . "x10/util/GrowableRail.x10"
                final long t$131100 = ((x10.util.GrowableRail<x10.core.Byte>)this$131099).size;
                
                //#line 37 "x10/io/PutbackReader.x10"
                final long t$131101 = ((t$131100) - (((long)(1L))));
                
                //#line 37 "x10/io/PutbackReader.x10"
                final byte p$131102 = x10.core.Byte.$unbox(((x10.util.GrowableRail<x10.core.Byte>)t$131098).$apply$G((long)(t$131101)));
                
                //#line 38 "x10/io/PutbackReader.x10"
                final x10.util.GrowableRail t$131103 = ((x10.util.GrowableRail)(this.putback));
                
                //#line 38 "x10/io/PutbackReader.x10"
                ((x10.util.GrowableRail<x10.core.Byte>)t$131103).removeLast$G();
                
                //#line 39 "x10/io/PutbackReader.x10"
                final long t$131105 = ((long)(((int)(read))));
                
                //#line 39 "x10/io/PutbackReader.x10"
                r$value$131108[(int)t$131105]=p$131102;
                
                //#line 40 "x10/io/PutbackReader.x10"
                final int t$131107 = ((read) + (((int)(1))));
                
                //#line 40 "x10/io/PutbackReader.x10"
                read = t$131107;
            }
        }
        
        //#line 42 "x10/io/PutbackReader.x10"
        final boolean t$131093 = ((read) < (((int)(len))));
        
        //#line 42 "x10/io/PutbackReader.x10"
        if (t$131093) {
            
            //#line 42 "x10/io/PutbackReader.x10"
            final int t$131088 = ((off) + (((int)(read))));
            
            //#line 42 "x10/io/PutbackReader.x10"
            final long t$131091 = ((long)(((int)(t$131088))));
            
            //#line 42 "x10/io/PutbackReader.x10"
            final int t$131090 = ((len) - (((int)(read))));
            
            //#line 42 "x10/io/PutbackReader.x10"
            final long t$131092 = ((long)(((int)(t$131090))));
            
            //#line 42 "x10/io/PutbackReader.x10"
            super.read__0$1x10$lang$Byte$2(((x10.core.Rail)(r)), (long)(t$131091), (long)(t$131092));
        }
    }
    
    
    //#line 45 "x10/io/PutbackReader.x10"
    public void putback(final byte p) {
        
        //#line 46 "x10/io/PutbackReader.x10"
        final x10.util.GrowableRail t$131094 = ((x10.util.GrowableRail)(this.putback));
        
        //#line 46 "x10/io/PutbackReader.x10"
        ((x10.util.GrowableRail<x10.core.Byte>)t$131094).add__0x10$util$GrowableRail$$T(x10.core.Byte.$box(p));
    }
    
    
    //#line 16 "x10/io/PutbackReader.x10"
    final public x10.io.PutbackReader x10$io$PutbackReader$$this$x10$io$PutbackReader() {
        
        //#line 16 "x10/io/PutbackReader.x10"
        return x10.io.PutbackReader.this;
    }
    
    
    //#line 16 "x10/io/PutbackReader.x10"
    final public void __fieldInitializers_x10_io_PutbackReader() {
        
    }
    
    public byte x10$io$FilterReader$read$S$O() {
        return super.read$O();
    }
    
    public void x10$io$FilterReader$read$S__0$1x10$lang$Byte$2(final x10.core.Rail a0, final long a1, final long a2) {
        super.read__0$1x10$lang$Byte$2(((x10.core.Rail)(a0)), (long)(a1), (long)(a2));
    }
}

