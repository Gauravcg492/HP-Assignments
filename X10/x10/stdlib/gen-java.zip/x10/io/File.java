package x10.io;


/**
 * Represents a file path.
 * Modeled after java.nio.file.Path.
 *
 * Usage:
 * <pre>
 * try {
 *    val input = new File(inputFileName);
 *    val output = new File(outputFileName);
 *    val p = output.printer();
 *    for (line in input.lines()) {
 *       p.println(line);
 *    }
 *    p.flush();
 * } catch (IOException) { }
 * </pre>
 */
@x10.runtime.impl.java.X10Generated
public class File extends x10.core.Ref implements x10.serialization.X10JavaSerializable
{
    public static final x10.rtt.RuntimeType<File> $RTT = 
        x10.rtt.NamedType.<File> make("x10.io.File",
                                      File.class);
    
    public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
    
    public x10.rtt.Type<?> $getParam(int i) { return null; }
    
    private Object writeReplace() throws java.io.ObjectStreamException {
        return new x10.serialization.SerializationProxy(this);
    }
    
    public static x10.serialization.X10JavaSerializable $_deserialize_body(x10.io.File $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
        $_obj.absolute = $deserializer.readBoolean();
        $_obj.name = $deserializer.readObject();
        $_obj.parent = $deserializer.readObject();
        return $_obj;
    }
    
    public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
        x10.io.File $_obj = new x10.io.File((java.lang.System[]) null);
        $deserializer.record_reference($_obj);
        return $_deserialize_body($_obj, $deserializer);
    }
    
    public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
        $serializer.write(this.absolute);
        $serializer.write(this.name);
        $serializer.write(this.parent);
        
    }
    
    // constructor just for allocation
    public File(final java.lang.System[] $dummy) {
        
    }
    
    

    
    //#line 36 "x10/io/File.x10"
    ;
    
    
    //#line 118 "x10/io/File.x10"
    final public static char SEPARATOR = '/';
    
    //#line 119 "x10/io/File.x10"
    final public static char PATH_SEPARATOR = ':';
    
    //#line 123 "x10/io/File.x10"
    public x10.io.File parent;
    
    //#line 124 "x10/io/File.x10"
    public java.lang.String name;
    
    //#line 125 "x10/io/File.x10"
    public boolean absolute;
    
    
    //#line 127 "x10/io/File.x10"
    // creation method for java code (1-phase java constructor)
    public File(final java.lang.String fullName) {
        this((java.lang.System[]) null);
        x10$io$File$$init$S(fullName);
    }
    
    // constructor for non-virtual call
    final public x10.io.File x10$io$File$$init$S(final java.lang.String fullName) {
         {
            
            //#line 127 "x10/io/File.x10"
            
            
            //#line 128 "x10/io/File.x10"
            final int i = (fullName).lastIndexOf(((char)('/')));
            
            //#line 129 "x10/io/File.x10"
            final boolean t$129949 = ((int) i) == ((int) 0);
            
            //#line 129 "x10/io/File.x10"
            if (t$129949) {
                
                //#line 130 "x10/io/File.x10"
                this.parent = null;
                
                //#line 131 "x10/io/File.x10"
                this.name = ((java.lang.String)(fullName));
                
                //#line 132 "x10/io/File.x10"
                this.absolute = true;
            } else {
                
                //#line 134 "x10/io/File.x10"
                final boolean t$129948 = ((i) >= (((int)(0))));
                
                //#line 134 "x10/io/File.x10"
                if (t$129948) {
                    
                    //#line 135 "x10/io/File.x10"
                    final x10.io.File alloc$129905 = ((x10.io.File)(new x10.io.File((java.lang.System[]) null)));
                    
                    //#line 135 "x10/io/File.x10"
                    final java.lang.String t$130014 = (fullName).substring(((int)(0)), ((int)(i)));
                    
                    //#line 135 "x10/io/File.x10"
                    alloc$129905.x10$io$File$$init$S(t$130014);
                    
                    //#line 135 "x10/io/File.x10"
                    this.parent = ((x10.io.File)(alloc$129905));
                    
                    //#line 136 "x10/io/File.x10"
                    final int t$129943 = ((i) + (((int)(1))));
                    
                    //#line 136 "x10/io/File.x10"
                    final int t$129944 = (fullName).length();
                    
                    //#line 136 "x10/io/File.x10"
                    final java.lang.String t$129945 = (fullName).substring(((int)(t$129943)), ((int)(t$129944)));
                    
                    //#line 136 "x10/io/File.x10"
                    this.name = ((java.lang.String)(t$129945));
                    
                    //#line 137 "x10/io/File.x10"
                    final char t$129946 = (fullName).charAt(((int)(0)));
                    
                    //#line 137 "x10/io/File.x10"
                    final boolean t$129947 = ((char) t$129946) == ((char) ':');
                    
                    //#line 137 "x10/io/File.x10"
                    this.absolute = t$129947;
                } else {
                    
                    //#line 140 "x10/io/File.x10"
                    this.parent = null;
                    
                    //#line 141 "x10/io/File.x10"
                    this.name = ((java.lang.String)(fullName));
                    
                    //#line 142 "x10/io/File.x10"
                    this.absolute = false;
                }
            }
        }
        return this;
    }
    
    
    
    //#line 146 "x10/io/File.x10"
    // creation method for java code (1-phase java constructor)
    public File(final x10.io.File p, final java.lang.String n) {
        this((java.lang.System[]) null);
        x10$io$File$$init$S(p, n);
    }
    
    // constructor for non-virtual call
    final public x10.io.File x10$io$File$$init$S(final x10.io.File p, final java.lang.String n) {
         {
            
            //#line 146 "x10/io/File.x10"
            
            
            //#line 147 "x10/io/File.x10"
            assert ((p) != (null));
            
            //#line 148 "x10/io/File.x10"
            this.parent = ((x10.io.File)(p));
            
            //#line 149 "x10/io/File.x10"
            this.name = ((java.lang.String)(n));
            
            //#line 150 "x10/io/File.x10"
            boolean t$129950 = ((p) != (null));
            
            //#line 150 "x10/io/File.x10"
            if (t$129950) {
                
                //#line 150 "x10/io/File.x10"
                t$129950 = p.absolute;
            }
            
            //#line 150 "x10/io/File.x10"
            this.absolute = t$129950;
        }
        return this;
    }
    
    
    
    //#line 153 "x10/io/File.x10"
    public java.lang.String toString() {
        
        //#line 153 "x10/io/File.x10"
        final java.lang.String t$129952 = this.getPath();
        
        //#line 153 "x10/io/File.x10"
        return t$129952;
    }
    
    
    //#line 155 "x10/io/File.x10"
    public x10.io.ReaderIterator lines() {
        
        //#line 156 "x10/io/File.x10"
        final x10.io.FileReader t$129953 = this.openRead();
        
        //#line 156 "x10/io/File.x10"
        final x10.io.ReaderIterator t$129954 = t$129953.lines();
        
        //#line 156 "x10/io/File.x10"
        return t$129954;
    }
    
    
    //#line 157 "x10/io/File.x10"
    public x10.io.ReaderIterator chars() {
        
        //#line 158 "x10/io/File.x10"
        final x10.io.FileReader t$129955 = this.openRead();
        
        //#line 158 "x10/io/File.x10"
        final x10.io.ReaderIterator t$129956 = t$129955.chars();
        
        //#line 158 "x10/io/File.x10"
        return t$129956;
    }
    
    
    //#line 159 "x10/io/File.x10"
    public x10.io.ReaderIterator bytes() {
        
        //#line 160 "x10/io/File.x10"
        final x10.io.FileReader t$129957 = this.openRead();
        
        //#line 160 "x10/io/File.x10"
        final x10.io.ReaderIterator t$129958 = t$129957.bytes();
        
        //#line 160 "x10/io/File.x10"
        return t$129958;
    }
    
    
    //#line 161 "x10/io/File.x10"
    public x10.io.FileReader openRead() {
        
        //#line 162 "x10/io/File.x10"
        final x10.io.FileReader alloc$129906 = ((x10.io.FileReader)(new x10.io.FileReader((java.lang.System[]) null)));
        
        //#line 162 "x10/io/File.x10"
        alloc$129906.x10$io$FileReader$$init$S(((x10.io.File)(this)));
        
        //#line 162 "x10/io/File.x10"
        return alloc$129906;
    }
    
    
    //#line 163 "x10/io/File.x10"
    public x10.io.FileWriter openWrite() {
        
        //#line 163 "x10/io/File.x10"
        final x10.io.FileWriter t$129959 = this.openWrite((boolean)(false));
        
        //#line 163 "x10/io/File.x10"
        return t$129959;
    }
    
    
    //#line 164 "x10/io/File.x10"
    public x10.io.FileWriter openWrite(final boolean append) {
        
        //#line 165 "x10/io/File.x10"
        final x10.io.FileWriter alloc$129907 = ((x10.io.FileWriter)(new x10.io.FileWriter((java.lang.System[]) null)));
        
        //#line 165 "x10/io/File.x10"
        alloc$129907.x10$io$FileWriter$$init$S(((x10.io.File)(this)), ((boolean)(append)));
        
        //#line 165 "x10/io/File.x10"
        return alloc$129907;
    }
    
    
    //#line 166 "x10/io/File.x10"
    public x10.io.Printer printer() {
        
        //#line 166 "x10/io/File.x10"
        final x10.io.Printer t$129960 = this.printer((boolean)(false));
        
        //#line 166 "x10/io/File.x10"
        return t$129960;
    }
    
    
    //#line 167 "x10/io/File.x10"
    public x10.io.Printer printer(final boolean append) {
        
        //#line 168 "x10/io/File.x10"
        final x10.io.Printer alloc$129908 = ((x10.io.Printer)(new x10.io.Printer((java.lang.System[]) null)));
        
        //#line 168 "x10/io/File.x10"
        final x10.io.FileWriter t$130017 = this.openWrite((boolean)(append));
        
        //#line 168 "x10/io/File.x10"
        alloc$129908.x10$io$Printer$$init$S(((x10.io.Writer)(t$130017)));
        
        //#line 168 "x10/io/File.x10"
        return alloc$129908;
    }
    
    
    //#line 170 "x10/io/File.x10"
    public java.lang.String getName() {
        
        //#line 170 "x10/io/File.x10"
        final java.lang.String t$129962 = ((java.lang.String)(this.name));
        
        //#line 170 "x10/io/File.x10"
        return t$129962;
    }
    
    
    //#line 171 "x10/io/File.x10"
    public x10.io.File getParentFile() {
        
        //#line 171 "x10/io/File.x10"
        final x10.io.File t$129963 = ((x10.io.File)(this.parent));
        
        //#line 171 "x10/io/File.x10"
        return t$129963;
    }
    
    
    //#line 172 "x10/io/File.x10"
    public java.lang.String getPath() {
        
        //#line 172 "x10/io/File.x10"
        final x10.io.File t$129964 = ((x10.io.File)(this.parent));
        
        //#line 172 "x10/io/File.x10"
        final boolean t$129969 = ((t$129964) == (null));
        
        //#line 172 "x10/io/File.x10"
        java.lang.String t$129970 =  null;
        
        //#line 172 "x10/io/File.x10"
        if (t$129969) {
            
            //#line 172 "x10/io/File.x10"
            t$129970 = this.name;
        } else {
            
            //#line 172 "x10/io/File.x10"
            final x10.io.File t$129965 = ((x10.io.File)(this.parent));
            
            //#line 172 "x10/io/File.x10"
            final java.lang.String t$129966 = t$129965.getPath();
            
            //#line 172 "x10/io/File.x10"
            final java.lang.String t$129967 = ((t$129966) + ((x10.core.Char.$box('/'))));
            
            //#line 172 "x10/io/File.x10"
            final java.lang.String t$129968 = ((java.lang.String)(this.name));
            
            //#line 172 "x10/io/File.x10"
            t$129970 = ((t$129967) + (t$129968));
        }
        
        //#line 172 "x10/io/File.x10"
        return t$129970;
    }
    
    
    //#line 173 "x10/io/File.x10"
    public boolean isAbsolute$O() {
        
        //#line 173 "x10/io/File.x10"
        final boolean t$129972 = this.absolute;
        
        //#line 173 "x10/io/File.x10"
        return t$129972;
    }
    
    
    //#line 175 "x10/io/File.x10"
    public x10.core.io.NativeFile nativeFile() {
        
        //#line 175 "x10/io/File.x10"
        final java.lang.String t$129973 = this.getPath();
        
        //#line 175 "x10/io/File.x10"
        final x10.core.io.NativeFile t$129974 = ((x10.core.io.NativeFile)(new x10.core.io.NativeFile(t$129973)));
        
        //#line 175 "x10/io/File.x10"
        return t$129974;
    }
    
    
    //#line 177 "x10/io/File.x10"
    public x10.io.File getAbsoluteFile() {
        
        //#line 177 "x10/io/File.x10"
        final x10.io.File alloc$129909 = ((x10.io.File)(new x10.io.File((java.lang.System[]) null)));
        
        //#line 177 "x10/io/File.x10"
        final x10.core.io.NativeFile t$130018 = ((x10.core.io.NativeFile)(this.nativeFile()));
        
        //#line 177 "x10/io/File.x10"
        final java.lang.String t$130019 = t$130018.getAbsolutePath();
        
        //#line 177 "x10/io/File.x10"
        alloc$129909.x10$io$File$$init$S(t$130019);
        
        //#line 177 "x10/io/File.x10"
        return alloc$129909;
    }
    
    
    //#line 178 "x10/io/File.x10"
    public x10.io.File getCanonicalFile() {
        
        //#line 179 "x10/io/File.x10"
        final x10.io.File alloc$129910 = ((x10.io.File)(new x10.io.File((java.lang.System[]) null)));
        
        //#line 179 "x10/io/File.x10"
        final x10.core.io.NativeFile t$130020 = ((x10.core.io.NativeFile)(this.nativeFile()));
        
        //#line 179 "x10/io/File.x10"
        final java.lang.String t$130021 = t$130020.getCanonicalPath();
        
        //#line 179 "x10/io/File.x10"
        alloc$129910.x10$io$File$$init$S(t$130021);
        
        //#line 179 "x10/io/File.x10"
        return alloc$129910;
    }
    
    
    //#line 181 "x10/io/File.x10"
    public boolean exists$O() {
        
        //#line 181 "x10/io/File.x10"
        final x10.core.io.NativeFile t$129979 = ((x10.core.io.NativeFile)(this.nativeFile()));
        
        //#line 181 "x10/io/File.x10"
        final boolean t$129980 = t$129979.exists();
        
        //#line 181 "x10/io/File.x10"
        return t$129980;
    }
    
    
    //#line 184 "x10/io/File.x10"
    public boolean isSymbolicLink$O() {
        
        //#line 184 "x10/io/File.x10"
        final java.lang.UnsupportedOperationException t$129981 = ((java.lang.UnsupportedOperationException)(new java.lang.UnsupportedOperationException()));
        
        //#line 184 "x10/io/File.x10"
        throw t$129981;
    }
    
    
    //#line 185 "x10/io/File.x10"
    public boolean isAlias$O() {
        
        //#line 185 "x10/io/File.x10"
        final java.lang.UnsupportedOperationException t$129982 = ((java.lang.UnsupportedOperationException)(new java.lang.UnsupportedOperationException()));
        
        //#line 185 "x10/io/File.x10"
        throw t$129982;
    }
    
    
    //#line 186 "x10/io/File.x10"
    public boolean hardLinkCount$O() {
        
        //#line 186 "x10/io/File.x10"
        final java.lang.UnsupportedOperationException t$129983 = ((java.lang.UnsupportedOperationException)(new java.lang.UnsupportedOperationException()));
        
        //#line 186 "x10/io/File.x10"
        throw t$129983;
    }
    
    
    //#line 187 "x10/io/File.x10"
    public long inodeNumber$O() {
        
        //#line 187 "x10/io/File.x10"
        final java.lang.UnsupportedOperationException t$129984 = ((java.lang.UnsupportedOperationException)(new java.lang.UnsupportedOperationException()));
        
        //#line 187 "x10/io/File.x10"
        throw t$129984;
    }
    
    
    //#line 188 "x10/io/File.x10"
    public int permissions$O() {
        
        //#line 188 "x10/io/File.x10"
        final java.lang.UnsupportedOperationException t$129985 = ((java.lang.UnsupportedOperationException)(new java.lang.UnsupportedOperationException()));
        
        //#line 188 "x10/io/File.x10"
        throw t$129985;
    }
    
    
    //#line 191 "x10/io/File.x10"
    public boolean isDirectory$O() {
        
        //#line 191 "x10/io/File.x10"
        final x10.core.io.NativeFile t$129986 = ((x10.core.io.NativeFile)(this.nativeFile()));
        
        //#line 191 "x10/io/File.x10"
        final boolean t$129987 = t$129986.isDirectory();
        
        //#line 191 "x10/io/File.x10"
        return t$129987;
    }
    
    
    //#line 192 "x10/io/File.x10"
    public boolean isFile$O() {
        
        //#line 192 "x10/io/File.x10"
        final x10.core.io.NativeFile t$129988 = ((x10.core.io.NativeFile)(this.nativeFile()));
        
        //#line 192 "x10/io/File.x10"
        final boolean t$129989 = t$129988.isFile();
        
        //#line 192 "x10/io/File.x10"
        return t$129989;
    }
    
    
    //#line 193 "x10/io/File.x10"
    public boolean isHidden$O() {
        
        //#line 193 "x10/io/File.x10"
        final x10.core.io.NativeFile t$129990 = ((x10.core.io.NativeFile)(this.nativeFile()));
        
        //#line 193 "x10/io/File.x10"
        final boolean t$129991 = t$129990.isHidden();
        
        //#line 193 "x10/io/File.x10"
        return t$129991;
    }
    
    
    //#line 195 "x10/io/File.x10"
    public long lastModified$O() {
        
        //#line 195 "x10/io/File.x10"
        final x10.core.io.NativeFile t$129992 = ((x10.core.io.NativeFile)(this.nativeFile()));
        
        //#line 195 "x10/io/File.x10"
        final long t$129993 = t$129992.lastModified();
        
        //#line 195 "x10/io/File.x10"
        return t$129993;
    }
    
    
    //#line 196 "x10/io/File.x10"
    public boolean setLastModified$O(final long t) {
        
        //#line 196 "x10/io/File.x10"
        final x10.core.io.NativeFile t$129994 = ((x10.core.io.NativeFile)(this.nativeFile()));
        
        //#line 196 "x10/io/File.x10"
        final boolean t$129995 = t$129994.setLastModified(((long)(t)));
        
        //#line 196 "x10/io/File.x10"
        return t$129995;
    }
    
    
    //#line 197 "x10/io/File.x10"
    public long size$O() {
        
        //#line 197 "x10/io/File.x10"
        final x10.core.io.NativeFile t$129996 = ((x10.core.io.NativeFile)(this.nativeFile()));
        
        //#line 197 "x10/io/File.x10"
        final long t$129997 = t$129996.length();
        
        //#line 197 "x10/io/File.x10"
        return t$129997;
    }
    
    
    //#line 199 "x10/io/File.x10"
    public int compareTo(final java.lang.Object f) {
        
        //#line 199 "x10/io/File.x10"
        final java.lang.UnsupportedOperationException t$129998 = ((java.lang.UnsupportedOperationException)(new java.lang.UnsupportedOperationException()));
        
        //#line 199 "x10/io/File.x10"
        throw t$129998;
    }
    
    
    //#line 201 "x10/io/File.x10"
    public boolean canRead$O() {
        
        //#line 201 "x10/io/File.x10"
        final x10.core.io.NativeFile t$129999 = ((x10.core.io.NativeFile)(this.nativeFile()));
        
        //#line 201 "x10/io/File.x10"
        final boolean t$130000 = t$129999.canRead();
        
        //#line 201 "x10/io/File.x10"
        return t$130000;
    }
    
    
    //#line 202 "x10/io/File.x10"
    public boolean canWrite$O() {
        
        //#line 202 "x10/io/File.x10"
        final x10.core.io.NativeFile t$130001 = ((x10.core.io.NativeFile)(this.nativeFile()));
        
        //#line 202 "x10/io/File.x10"
        final boolean t$130002 = t$130001.canWrite();
        
        //#line 202 "x10/io/File.x10"
        return t$130002;
    }
    
    
    //#line 204 "x10/io/File.x10"
    public boolean delete$O() {
        
        //#line 204 "x10/io/File.x10"
        final x10.core.io.NativeFile t$130003 = ((x10.core.io.NativeFile)(this.nativeFile()));
        
        //#line 204 "x10/io/File.x10"
        final boolean t$130004 = t$130003.delete();
        
        //#line 204 "x10/io/File.x10"
        return t$130004;
    }
    
    
    //#line 205 "x10/io/File.x10"
    public x10.core.Rail list() {
        
        //#line 205 "x10/io/File.x10"
        final x10.core.io.NativeFile t$130005 = ((x10.core.io.NativeFile)(this.nativeFile()));
        
        //#line 205 "x10/io/File.x10"
        final x10.core.Rail t$130006 = t$130005.listInternal();
        
        //#line 205 "x10/io/File.x10"
        return t$130006;
    }
    
    
    //#line 206 "x10/io/File.x10"
    public boolean mkdir$O() {
        
        //#line 206 "x10/io/File.x10"
        final x10.core.io.NativeFile t$130007 = ((x10.core.io.NativeFile)(this.nativeFile()));
        
        //#line 206 "x10/io/File.x10"
        final boolean t$130008 = t$130007.mkdir();
        
        //#line 206 "x10/io/File.x10"
        return t$130008;
    }
    
    
    //#line 207 "x10/io/File.x10"
    public boolean mkdirs$O() {
        
        //#line 207 "x10/io/File.x10"
        final x10.core.io.NativeFile t$130009 = ((x10.core.io.NativeFile)(this.nativeFile()));
        
        //#line 207 "x10/io/File.x10"
        final boolean t$130010 = t$130009.mkdirs();
        
        //#line 207 "x10/io/File.x10"
        return t$130010;
    }
    
    
    //#line 208 "x10/io/File.x10"
    public boolean renameTo$O(final x10.io.File dest) {
        
        //#line 208 "x10/io/File.x10"
        final x10.core.io.NativeFile t$130011 = ((x10.core.io.NativeFile)(this.nativeFile()));
        
        //#line 208 "x10/io/File.x10"
        final x10.core.io.NativeFile t$130012 = ((x10.core.io.NativeFile)(dest.nativeFile()));
        
        //#line 208 "x10/io/File.x10"
        final boolean t$130013 = t$130011.renameTo(t$130012);
        
        //#line 208 "x10/io/File.x10"
        return t$130013;
    }
    
    
    //#line 35 "x10/io/File.x10"
    final public x10.io.File x10$io$File$$this$x10$io$File() {
        
        //#line 35 "x10/io/File.x10"
        return x10.io.File.this;
    }
    
    
    //#line 35 "x10/io/File.x10"
    final public void __fieldInitializers_x10_io_File() {
        
    }
    
    public static char get$SEPARATOR() {
        return x10.io.File.SEPARATOR;
    }
    
    public static char get$PATH_SEPARATOR() {
        return x10.io.File.PATH_SEPARATOR;
    }
}

