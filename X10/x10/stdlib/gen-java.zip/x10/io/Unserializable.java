package x10.io;

/**
 * Types that implement this marker interface indicate that 
 * they cannot be serialized from one place to another.
 * Any attempt to serialize an instance of a type will result in
 * a NotSerializableException being thrown during serialization.
 * 
 * @see NotSerializableException
 */
@x10.runtime.impl.java.X10Generated
public interface Unserializable extends x10.core.Any
{
    public static final x10.rtt.RuntimeType<Unserializable> $RTT = 
        x10.rtt.NamedType.<Unserializable> make("x10.io.Unserializable",
                                                Unserializable.class);
    
    
}

