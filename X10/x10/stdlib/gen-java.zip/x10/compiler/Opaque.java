package x10.compiler;


/** Annotation to mark property methods as being opaque to the constraint
 * solver.
 * 
 * This means they are not inlined, although the body (X10 code) is still used
 * to implement constraint checks in casts.
 */
@x10.runtime.impl.java.X10Generated
public interface Opaque extends x10.lang.annotations.MethodAnnotation, x10.serialization.X10JavaSerializable
{
    public static final x10.rtt.RuntimeType<Opaque> $RTT = 
        x10.rtt.NamedType.<Opaque> make("x10.compiler.Opaque",
                                        Opaque.class,
                                        new x10.rtt.Type[] {
                                            x10.lang.annotations.MethodAnnotation.$RTT
                                        });
    
    
}

