package x10.compiler;


/**
 * This annotation on a var field instructs the compiler frontend to not
 * implicitly initialize this field to the type's default value.
 */
@x10.runtime.impl.java.X10Generated
public interface Uninitialized extends x10.lang.annotations.FieldAnnotation, x10.serialization.X10JavaSerializable
{
    public static final x10.rtt.RuntimeType<Uninitialized> $RTT = 
        x10.rtt.NamedType.<Uninitialized> make("x10.compiler.Uninitialized",
                                               Uninitialized.class,
                                               new x10.rtt.Type[] {
                                                   x10.lang.annotations.FieldAnnotation.$RTT
                                               });
    
    
}

