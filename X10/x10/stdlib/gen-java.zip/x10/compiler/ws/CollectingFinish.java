package x10.compiler.ws;


@x10.runtime.impl.java.X10Generated
abstract public class CollectingFinish<$T> extends x10.compiler.ws.FinishFrame implements x10.serialization.X10JavaSerializable
{
    public static final x10.rtt.RuntimeType<CollectingFinish> $RTT = 
        x10.rtt.NamedType.<CollectingFinish> make("x10.compiler.ws.CollectingFinish",
                                                  CollectingFinish.class,
                                                  1,
                                                  new x10.rtt.Type[] {
                                                      x10.compiler.ws.FinishFrame.$RTT
                                                  });
    
    public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
    
    public x10.rtt.Type<?> $getParam(int i) { if (i == 0) return $T; return null; }
    
    public static <$T> x10.serialization.X10JavaSerializable $_deserialize_body(x10.compiler.ws.CollectingFinish<$T> $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
        x10.compiler.ws.FinishFrame.$_deserialize_body($_obj, $deserializer);
        $_obj.$T = (x10.rtt.Type) $deserializer.readObject();
        $_obj.reducer = $deserializer.readObject();
        $_obj.resultRail = $deserializer.readObject();
        return $_obj;
    }
    
    public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
        return null;
    }
    
    public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
        super.$_serialize($serializer);
        $serializer.write(this.$T);
        $serializer.write(this.reducer);
        $serializer.write(this.resultRail);
        
    }
    
    // constructor just for allocation
    public CollectingFinish(final java.lang.System[] $dummy, final x10.rtt.Type $T) {
        super($dummy);
        x10.compiler.ws.CollectingFinish.$initParams(this, $T);
        
    }
    
    private x10.rtt.Type $T;
    
    // initializer of type parameters
    public static void $initParams(final CollectingFinish $this, final x10.rtt.Type $T) {
        $this.$T = $T;
        
    }
    // synthetic type for parameter mangling
    public static final class __1$1x10$compiler$ws$CollectingFinish$$T$2 {}
    

    
    //#line 27 "x10/compiler/ws/CollectingFinish.x10"
    public x10.lang.Reducible<$T> reducer;
    
    //#line 28 "x10/compiler/ws/CollectingFinish.x10"
    public x10.core.Rail<$T> resultRail;
    
    
    //#line 31 "x10/compiler/ws/CollectingFinish.x10"
    
    // constructor for non-virtual call
    final public x10.compiler.ws.CollectingFinish<$T> x10$compiler$ws$CollectingFinish$$init$S(final x10.compiler.ws.Frame up, final x10.lang.Reducible<$T> rd, __1$1x10$compiler$ws$CollectingFinish$$T$2 $dummy) {
         {
            
            //#line 32 "x10/compiler/ws/CollectingFinish.x10"
            /*super.*/x10$compiler$ws$FinishFrame$$init$S(((x10.compiler.ws.Frame)(up)));
            
            //#line 31 "x10/compiler/ws/CollectingFinish.x10"
            
            
            //#line 33 "x10/compiler/ws/CollectingFinish.x10"
            ((x10.compiler.ws.CollectingFinish<$T>)this).reducer = ((x10.lang.Reducible)(rd));
            {
                
                //#line 36 "x10/compiler/ws/CollectingFinish.x10"
                final int size = x10.xrx.Runtime.get$NTHREADS();
                
                //#line 37 "x10/compiler/ws/CollectingFinish.x10"
                final long t$115890 = ((long)(((int)(size))));
                
                //#line 37 "x10/compiler/ws/CollectingFinish.x10"
                final x10.core.Rail t$115891 = ((x10.core.Rail)(x10.core.Rail.<$T>makeUnsafe($T, ((long)(t$115890)), false)));
                
                //#line 37 "x10/compiler/ws/CollectingFinish.x10"
                ((x10.compiler.ws.CollectingFinish<$T>)this).resultRail = ((x10.core.Rail)(t$115891));
                {
                    
                    //#line 38 "x10/compiler/ws/CollectingFinish.x10"
                    int i = 0;
                    
                    //#line 38 "x10/compiler/ws/CollectingFinish.x10"
                    for (;
                         true;
                         ) {
                        
                        //#line 38 "x10/compiler/ws/CollectingFinish.x10"
                        final boolean t$115901 = ((i) < (((int)(size))));
                        
                        //#line 38 "x10/compiler/ws/CollectingFinish.x10"
                        if (!(t$115901)) {
                            
                            //#line 38 "x10/compiler/ws/CollectingFinish.x10"
                            break;
                        }
                        
                        //#line 39 "x10/compiler/ws/CollectingFinish.x10"
                        final x10.core.Rail t$115926 = ((x10.core.Rail)(this.resultRail));
                        
                        //#line 39 "x10/compiler/ws/CollectingFinish.x10"
                        final long t$115928 = ((long)(((int)(i))));
                        
                        //#line 39 "x10/compiler/ws/CollectingFinish.x10"
                        final x10.lang.Reducible t$115929 = ((x10.lang.Reducible)(this.reducer));
                        
                        //#line 39 "x10/compiler/ws/CollectingFinish.x10"
                        final $T t$115930 = (($T)(((x10.lang.Reducible<$T>)t$115929).zero$G()));
                        
                        //#line 39 "x10/compiler/ws/CollectingFinish.x10"
                        ((x10.core.Rail<$T>)t$115926).$set__1x10$lang$Rail$$T$G((long)(t$115928), (($T)(t$115930)));
                        
                        //#line 38 "x10/compiler/ws/CollectingFinish.x10"
                        final int t$115932 = ((i) + (((int)(1))));
                        
                        //#line 38 "x10/compiler/ws/CollectingFinish.x10"
                        i = t$115932;
                    }
                }
            }
        }
        return this;
    }
    
    
    
    //#line 74 "x10/compiler/ws/CollectingFinish.x10"
    final public void accept__0x10$compiler$ws$CollectingFinish$$T(final $T t, final x10.compiler.ws.Worker worker) {
        {
            
            //#line 86 "x10/compiler/ws/CollectingFinish.x10"
            final int id = worker.id;
            
            //#line 87 "x10/compiler/ws/CollectingFinish.x10"
            final x10.core.Rail t$115906 = ((x10.core.Rail)(this.resultRail));
            
            //#line 87 "x10/compiler/ws/CollectingFinish.x10"
            final long t$115907 = ((long)(((int)(id))));
            
            //#line 87 "x10/compiler/ws/CollectingFinish.x10"
            final x10.lang.Reducible t$115904 = ((x10.lang.Reducible)(this.reducer));
            
            //#line 87 "x10/compiler/ws/CollectingFinish.x10"
            final x10.core.Rail t$115902 = ((x10.core.Rail)(this.resultRail));
            
            //#line 87 "x10/compiler/ws/CollectingFinish.x10"
            final long t$115903 = ((long)(((int)(id))));
            
            //#line 87 "x10/compiler/ws/CollectingFinish.x10"
            final $T t$115905 = (($T)(((x10.core.Rail<$T>)t$115902).$apply$G((long)(t$115903))));
            
            //#line 87 "x10/compiler/ws/CollectingFinish.x10"
            final $T t$115908 = (($T)((($T)
                                        ((x10.lang.Reducible<$T>)t$115904).$apply((($T)(t$115905)), $T, (($T)(t)), $T))));
            
            //#line 87 "x10/compiler/ws/CollectingFinish.x10"
            ((x10.core.Rail<$T>)t$115906).$set__1x10$lang$Rail$$T$G((long)(t$115907), (($T)(t$115908)));
        }
    }
    
    
    //#line 92 "x10/compiler/ws/CollectingFinish.x10"
    final public $T fastResult$G(final x10.compiler.ws.Worker worker) {
        {
            
            //#line 97 "x10/compiler/ws/CollectingFinish.x10"
            final x10.core.Rail t$115910 = ((x10.core.Rail)(this.resultRail));
            
            //#line 97 "x10/compiler/ws/CollectingFinish.x10"
            final int t$115909 = worker.id;
            
            //#line 97 "x10/compiler/ws/CollectingFinish.x10"
            final long t$115911 = ((long)(((int)(t$115909))));
            
            //#line 97 "x10/compiler/ws/CollectingFinish.x10"
            final $T result = (($T)(((x10.core.Rail<$T>)t$115910).$apply$G((long)(t$115911))));
            
            //#line 98 "x10/compiler/ws/CollectingFinish.x10"
            x10.runtime.impl.java.EvalUtils.eval(this.resultRail);
            {
                
            }
            
            //#line 99 "x10/compiler/ws/CollectingFinish.x10"
            return result;
        }
    }
    
    
    //#line 104 "x10/compiler/ws/CollectingFinish.x10"
    final public $T result$G() {
        {
            
            //#line 115 "x10/compiler/ws/CollectingFinish.x10"
            final x10.core.Rail t$115912 = ((x10.core.Rail)(this.resultRail));
            
            //#line 115 "x10/compiler/ws/CollectingFinish.x10"
            $T result = (($T)(((x10.core.Rail<$T>)t$115912).$apply$G((long)(0L))));
            
            //#line 116 "x10/compiler/ws/CollectingFinish.x10"
            final int size = x10.xrx.Runtime.get$NTHREADS();
            {
                
                //#line 117 "x10/compiler/ws/CollectingFinish.x10"
                int i = 1;
                
                //#line 117 "x10/compiler/ws/CollectingFinish.x10"
                for (;
                     true;
                     ) {
                    
                    //#line 117 "x10/compiler/ws/CollectingFinish.x10"
                    final boolean t$115924 = ((i) < (((int)(size))));
                    
                    //#line 117 "x10/compiler/ws/CollectingFinish.x10"
                    if (!(t$115924)) {
                        
                        //#line 117 "x10/compiler/ws/CollectingFinish.x10"
                        break;
                    }
                    
                    //#line 118 "x10/compiler/ws/CollectingFinish.x10"
                    final x10.lang.Reducible t$115934 = ((x10.lang.Reducible)(this.reducer));
                    
                    //#line 118 "x10/compiler/ws/CollectingFinish.x10"
                    final x10.core.Rail t$115936 = ((x10.core.Rail)(this.resultRail));
                    
                    //#line 118 "x10/compiler/ws/CollectingFinish.x10"
                    final long t$115938 = ((long)(((int)(i))));
                    
                    //#line 118 "x10/compiler/ws/CollectingFinish.x10"
                    final $T t$115939 = (($T)(((x10.core.Rail<$T>)t$115936).$apply$G((long)(t$115938))));
                    
                    //#line 118 "x10/compiler/ws/CollectingFinish.x10"
                    final $T t$115940 = (($T)((($T)
                                                ((x10.lang.Reducible<$T>)t$115934).$apply((($T)(result)), $T, (($T)(t$115939)), $T))));
                    
                    //#line 118 "x10/compiler/ws/CollectingFinish.x10"
                    result = (($T)(t$115940));
                    
                    //#line 117 "x10/compiler/ws/CollectingFinish.x10"
                    final int t$115942 = ((i) + (((int)(1))));
                    
                    //#line 117 "x10/compiler/ws/CollectingFinish.x10"
                    i = t$115942;
                }
            }
            
            //#line 120 "x10/compiler/ws/CollectingFinish.x10"
            x10.runtime.impl.java.EvalUtils.eval(this.resultRail);
            {
                
            }
            
            //#line 121 "x10/compiler/ws/CollectingFinish.x10"
            ;
            
            //#line 121 "x10/compiler/ws/CollectingFinish.x10"
            return result;
        }
    }
    
    
    //#line 26 "x10/compiler/ws/CollectingFinish.x10"
    final public x10.compiler.ws.CollectingFinish x10$compiler$ws$CollectingFinish$$this$x10$compiler$ws$CollectingFinish() {
        
        //#line 26 "x10/compiler/ws/CollectingFinish.x10"
        return x10.compiler.ws.CollectingFinish.this;
    }
    
    
    //#line 26 "x10/compiler/ws/CollectingFinish.x10"
    final public void __fieldInitializers_x10_compiler_ws_CollectingFinish() {
        
    }
}

