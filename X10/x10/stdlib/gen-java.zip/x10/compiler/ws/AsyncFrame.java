package x10.compiler.ws;


@x10.runtime.impl.java.X10Generated
abstract public class AsyncFrame extends x10.compiler.ws.Frame implements x10.serialization.X10JavaSerializable
{
    public static final x10.rtt.RuntimeType<AsyncFrame> $RTT = 
        x10.rtt.NamedType.<AsyncFrame> make("x10.compiler.ws.AsyncFrame",
                                            AsyncFrame.class,
                                            new x10.rtt.Type[] {
                                                x10.compiler.ws.Frame.$RTT
                                            });
    
    public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
    
    public x10.rtt.Type<?> $getParam(int i) { return null; }
    
    public static x10.serialization.X10JavaSerializable $_deserialize_body(x10.compiler.ws.AsyncFrame $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
        x10.compiler.ws.Frame.$_deserialize_body($_obj, $deserializer);
        return $_obj;
    }
    
    public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
        return null;
    }
    
    public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
        super.$_serialize($serializer);
        
    }
    
    // constructor just for allocation
    public AsyncFrame(final java.lang.System[] $dummy) {
        super($dummy);
        
    }
    
    

    
    
    //#line 21 "x10/compiler/ws/AsyncFrame.x10"
    
    // constructor for non-virtual call
    final public x10.compiler.ws.AsyncFrame x10$compiler$ws$AsyncFrame$$init$S(final x10.compiler.ws.Frame up) {
         {
            
            //#line 22 "x10/compiler/ws/AsyncFrame.x10"
            final x10.compiler.ws.Frame this$115507 = this;
            
            //#line 31 . "x10/compiler/ws/Frame.x10"
            this$115507.up = ((x10.compiler.ws.Frame)(up));
            
            //#line 21 "x10/compiler/ws/AsyncFrame.x10"
            
        }
        return this;
    }
    
    
    
    //#line 30 "x10/compiler/ws/AsyncFrame.x10"
    final public x10.compiler.ws.FinishFrame ff() {
        
        //#line 30 "x10/compiler/ws/AsyncFrame.x10"
        final x10.compiler.ws.Frame t$115670 = ((x10.compiler.ws.Frame)(this.up));
        
        //#line 30 "x10/compiler/ws/AsyncFrame.x10"
        final x10.compiler.ws.FinishFrame t$115671 = ((x10.compiler.ws.FinishFrame) t$115670);
        
        //#line 30 "x10/compiler/ws/AsyncFrame.x10"
        return t$115671;
    }
    
    
    //#line 35 "x10/compiler/ws/AsyncFrame.x10"
    final public void poll(final x10.compiler.ws.Worker worker) {
        
        //#line 36 "x10/compiler/ws/AsyncFrame.x10"
        final x10.core.Deque t$115672 = ((x10.core.Deque)(worker.deque));
        
        //#line 36 "x10/compiler/ws/AsyncFrame.x10"
        final java.lang.Object t$115673 = t$115672.poll();
        
        //#line 36 "x10/compiler/ws/AsyncFrame.x10"
        final boolean t$115674 = ((null) == (t$115673));
        
        //#line 36 "x10/compiler/ws/AsyncFrame.x10"
        if (t$115674) {
            
            //#line 36 "x10/compiler/ws/AsyncFrame.x10"
            this.pollSlow(((x10.compiler.ws.Worker)(worker)));
        }
    }
    
    
    //#line 39 "x10/compiler/ws/AsyncFrame.x10"
    final public void pollSlow(final x10.compiler.ws.Worker worker) {
        
        //#line 40 "x10/compiler/ws/AsyncFrame.x10"
        final x10.util.concurrent.Lock lock = ((x10.util.concurrent.Lock)(worker.lock));
        
        //#line 41 "x10/compiler/ws/AsyncFrame.x10"
        lock.lock();
        
        //#line 42 "x10/compiler/ws/AsyncFrame.x10"
        lock.unlock();
        
        //#line 43 "x10/compiler/ws/AsyncFrame.x10"
        final x10.compiler.ws.AsyncFrame this$115512 = ((x10.compiler.ws.AsyncFrame)(this));
        
        //#line 30 . "x10/compiler/ws/AsyncFrame.x10"
        final x10.compiler.ws.Frame t$115675 = ((x10.compiler.ws.Frame)(this$115512.up));
        
        //#line 43 "x10/compiler/ws/AsyncFrame.x10"
        x10.compiler.ws.FinishFrame ff = ((x10.compiler.ws.FinishFrame) t$115675);
        
        //#line 52 "x10/compiler/ws/AsyncFrame.x10"
        worker.unroll(((x10.compiler.ws.Frame)(ff)));
    }
    
    
    //#line 55 "x10/compiler/ws/AsyncFrame.x10"
    final public void caught(final java.lang.RuntimeException t) {
        
        //#line 56 "x10/compiler/ws/AsyncFrame.x10"
        final x10.compiler.ws.AsyncFrame this$115659 = ((x10.compiler.ws.AsyncFrame)(this));
        
        //#line 30 . "x10/compiler/ws/AsyncFrame.x10"
        final x10.compiler.ws.Frame t$115677 = ((x10.compiler.ws.Frame)(this$115659.up));
        
        //#line 30 . "x10/compiler/ws/AsyncFrame.x10"
        final x10.compiler.ws.FinishFrame t$115678 = ((x10.compiler.ws.FinishFrame) t$115677);
        
        //#line 56 "x10/compiler/ws/AsyncFrame.x10"
        t$115678.caught(((java.lang.Throwable)(t)));
    }
    
    
    //#line 20 "x10/compiler/ws/AsyncFrame.x10"
    final public x10.compiler.ws.AsyncFrame x10$compiler$ws$AsyncFrame$$this$x10$compiler$ws$AsyncFrame() {
        
        //#line 20 "x10/compiler/ws/AsyncFrame.x10"
        return x10.compiler.ws.AsyncFrame.this;
    }
    
    
    //#line 20 "x10/compiler/ws/AsyncFrame.x10"
    final public void __fieldInitializers_x10_compiler_ws_AsyncFrame() {
        
    }
}

