package x10.compiler.ws;


@x10.runtime.impl.java.X10Generated
final public class Worker extends x10.core.Ref implements x10.serialization.X10JavaSerializable
{
    public static final x10.rtt.RuntimeType<Worker> $RTT = 
        x10.rtt.NamedType.<Worker> make("x10.compiler.ws.Worker",
                                        Worker.class);
    
    public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
    
    public x10.rtt.Type<?> $getParam(int i) { return null; }
    
    private Object writeReplace() throws java.io.ObjectStreamException {
        return new x10.serialization.SerializationProxy(this);
    }
    
    public static x10.serialization.X10JavaSerializable $_deserialize_body(x10.compiler.ws.Worker $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
        $_obj.deque = $deserializer.readObject();
        $_obj.fifo = $deserializer.readObject();
        $_obj.id = $deserializer.readInt();
        $_obj.lock = $deserializer.readObject();
        $_obj.random = $deserializer.readObject();
        $_obj.throwable = $deserializer.readObject();
        $_obj.workers = $deserializer.readObject();
        return $_obj;
    }
    
    public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
        x10.compiler.ws.Worker $_obj = new x10.compiler.ws.Worker((java.lang.System[]) null);
        $deserializer.record_reference($_obj);
        return $_deserialize_body($_obj, $deserializer);
    }
    
    public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
        $serializer.write(this.deque);
        $serializer.write(this.fifo);
        $serializer.write(this.id);
        $serializer.write(this.lock);
        $serializer.write(this.random);
        $serializer.write(this.throwable);
        $serializer.write(this.workers);
        
    }
    
    // constructor just for allocation
    public Worker(final java.lang.System[] $dummy) {
        
    }
    
    // synthetic type for parameter mangling
    public static final class __1$1x10$compiler$ws$Worker$2 {}
    

    
    //#line 24 "x10/compiler/ws/Worker.x10"
    public x10.core.Rail<x10.compiler.ws.Worker> workers;
    
    //#line 25 "x10/compiler/ws/Worker.x10"
    public x10.util.Random random;
    
    //#line 27 "x10/compiler/ws/Worker.x10"
    public int id;
    
    //#line 28 "x10/compiler/ws/Worker.x10"
    public x10.core.Deque deque;
    
    //#line 29 "x10/compiler/ws/Worker.x10"
    public x10.core.Deque fifo;
    
    //#line 30 "x10/compiler/ws/Worker.x10"
    public x10.util.concurrent.Lock lock;
    
    //#line 32 "x10/compiler/ws/Worker.x10"
    public java.lang.RuntimeException throwable;
    
    
    //#line 34 "x10/compiler/ws/Worker.x10"
    // creation method for java code (1-phase java constructor)
    public Worker(final int i, final x10.core.Rail<x10.compiler.ws.Worker> workers, __1$1x10$compiler$ws$Worker$2 $dummy) {
        this((java.lang.System[]) null);
        x10$compiler$ws$Worker$$init$S(i, workers, (x10.compiler.ws.Worker.__1$1x10$compiler$ws$Worker$2) null);
    }
    
    // constructor for non-virtual call
    final public x10.compiler.ws.Worker x10$compiler$ws$Worker$$init$S(final int i, final x10.core.Rail<x10.compiler.ws.Worker> workers, __1$1x10$compiler$ws$Worker$2 $dummy) {
         {
            
            //#line 34 "x10/compiler/ws/Worker.x10"
            
            
            //#line 23 "x10/compiler/ws/Worker.x10"
            this.__fieldInitializers_x10_compiler_ws_Worker();
            
            //#line 35 "x10/compiler/ws/Worker.x10"
            final x10.util.Random alloc$115653 = ((x10.util.Random)(new x10.util.Random((java.lang.System[]) null)));
            
            //#line 35 "x10/compiler/ws/Worker.x10"
            final long t$117703 = ((long)(((int)(8))));
            
            //#line 35 "x10/compiler/ws/Worker.x10"
            final int t$117704 = ((i) << (int)(((long)(t$117703))));
            
            //#line 35 "x10/compiler/ws/Worker.x10"
            final int t$117706 = ((i) + (((int)(t$117704))));
            
            //#line 35 "x10/compiler/ws/Worker.x10"
            final long t$117705 = ((long)(((int)(16))));
            
            //#line 35 "x10/compiler/ws/Worker.x10"
            final int t$117707 = ((i) << (int)(((long)(t$117705))));
            
            //#line 35 "x10/compiler/ws/Worker.x10"
            final int t$117709 = ((t$117706) + (((int)(t$117707))));
            
            //#line 35 "x10/compiler/ws/Worker.x10"
            final long t$117708 = ((long)(((int)(24))));
            
            //#line 35 "x10/compiler/ws/Worker.x10"
            final int t$117710 = ((i) << (int)(((long)(t$117708))));
            
            //#line 35 "x10/compiler/ws/Worker.x10"
            final int t$117711 = ((t$117709) + (((int)(t$117710))));
            
            //#line 35 "x10/compiler/ws/Worker.x10"
            final long seed$117669 = ((long)(((int)(t$117711))));
            
            //#line 24 ... "x10/util/Random.x10"
            alloc$115653.seed = 0L;
            
            //#line 24 ... "x10/util/Random.x10"
            alloc$115653.storedGaussian = 0.0;
            
            //#line 24 ... "x10/util/Random.x10"
            alloc$115653.haveStoredGaussian = false;
            
            //#line 36 .. "x10/util/Random.x10"
            alloc$115653.seed = seed$117669;
            
            //#line 37 .. "x10/util/Random.x10"
            alloc$115653.gamma = -7046029254386353131L;
            
            //#line 35 "x10/compiler/ws/Worker.x10"
            this.random = ((x10.util.Random)(alloc$115653));
            
            //#line 36 "x10/compiler/ws/Worker.x10"
            this.id = i;
            
            //#line 37 "x10/compiler/ws/Worker.x10"
            this.workers = ((x10.core.Rail)(workers));
        }
        return this;
    }
    
    
    
    //#line 40 "x10/compiler/ws/Worker.x10"
    public void migrate() {
        
        //#line 41 "x10/compiler/ws/Worker.x10"
        x10.compiler.ws.RegularFrame k =  null;
        
        //#line 42 "x10/compiler/ws/Worker.x10"
        final x10.util.concurrent.Lock t$117712 = ((x10.util.concurrent.Lock)(this.lock));
        
        //#line 42 "x10/compiler/ws/Worker.x10"
        t$117712.lock();
        
        //#line 43 "x10/compiler/ws/Worker.x10"
        while (true) {
            
            //#line 43 "x10/compiler/ws/Worker.x10"
            final x10.core.Deque t$117713 = ((x10.core.Deque)(this.deque));
            
            //#line 43 "x10/compiler/ws/Worker.x10"
            final java.lang.Object t$117714 = t$117713.steal();
            
            //#line 43 "x10/compiler/ws/Worker.x10"
            final x10.compiler.ws.RegularFrame t$117715 = ((x10.compiler.ws.RegularFrame) t$117714);
            
            //#line 43 "x10/compiler/ws/Worker.x10"
            final x10.compiler.ws.RegularFrame t$117716 = k = ((x10.compiler.ws.RegularFrame)(t$117715));
            
            //#line 43 "x10/compiler/ws/Worker.x10"
            final boolean t$117724 = ((null) != (t$117716));
            
            //#line 43 "x10/compiler/ws/Worker.x10"
            if (!(t$117724)) {
                
                //#line 43 "x10/compiler/ws/Worker.x10"
                break;
            }
            
            //#line 47 "x10/compiler/ws/Worker.x10"
            final x10.util.concurrent.Monitor t$117829 = ((x10.util.concurrent.Monitor)(x10.xrx.Runtime.get$atomicMonitor()));
            
            //#line 47 "x10/compiler/ws/Worker.x10"
            t$117829.lock();
            
            //#line 47 "x10/compiler/ws/Worker.x10"
            final x10.compiler.ws.FinishFrame obj$117831 = ((x10.compiler.ws.FinishFrame)(t$117715.ff));
            
            //#line 47 "x10/compiler/ws/Worker.x10"
            final int t$117832 = obj$117831.asyncs;
            
            //#line 47 "x10/compiler/ws/Worker.x10"
            final int t$117833 = ((t$117832) + (((int)(1))));
            
            //#line 47 "x10/compiler/ws/Worker.x10"
            obj$117831.asyncs = t$117833;
            
            //#line 47 "x10/compiler/ws/Worker.x10"
            final x10.util.concurrent.Monitor t$117834 = ((x10.util.concurrent.Monitor)(x10.xrx.Runtime.get$atomicMonitor()));
            
            //#line 47 "x10/compiler/ws/Worker.x10"
            t$117834.unlock();
            
            //#line 48 "x10/compiler/ws/Worker.x10"
            final x10.core.Deque t$117835 = ((x10.core.Deque)(this.fifo));
            
            //#line 48 "x10/compiler/ws/Worker.x10"
            t$117835.push(((java.lang.Object)(t$117715)));
        }
        
        //#line 50 "x10/compiler/ws/Worker.x10"
        final x10.util.concurrent.Lock t$117725 = ((x10.util.concurrent.Lock)(this.lock));
        
        //#line 50 "x10/compiler/ws/Worker.x10"
        t$117725.unlock();
    }
    
    
    //#line 53 "x10/compiler/ws/Worker.x10"
    public void run() {
        
        //#line 54 "x10/compiler/ws/Worker.x10"
        try {{
            
            //#line 55 "x10/compiler/ws/Worker.x10"
            while (true) {
                
                //#line 56 "x10/compiler/ws/Worker.x10"
                final java.lang.Object k = this.find();
                
                //#line 57 "x10/compiler/ws/Worker.x10"
                final boolean t$117726 = ((null) == (k));
                
                //#line 57 "x10/compiler/ws/Worker.x10"
                if (t$117726) {
                    
                    //#line 57 "x10/compiler/ws/Worker.x10"
                    return;
                }
                
                //#line 58 "x10/compiler/ws/Worker.x10"
                try {{
                    
                    //#line 59 "x10/compiler/ws/Worker.x10"
                    final x10.compiler.ws.Frame t$117727 = ((x10.compiler.ws.Frame) k);
                    
                    //#line 59 "x10/compiler/ws/Worker.x10"
                    this.unroll(((x10.compiler.ws.Frame)(t$117727)));
                }}catch (final x10.compiler.Abort id$116) {
                    
                }
            }
        }}catch (final java.lang.RuntimeException t) {
            
            //#line 63 "x10/compiler/ws/Worker.x10"
            final java.lang.String t$117728 = (("Uncaught exception at place ") + (x10.x10rt.X10RT.here()));
            
            //#line 63 "x10/compiler/ws/Worker.x10"
            final java.lang.String t$117729 = ((t$117728) + (" in WS worker: "));
            
            //#line 63 "x10/compiler/ws/Worker.x10"
            final java.lang.String t$117730 = ((t$117729) + (t));
            
            //#line 63 "x10/compiler/ws/Worker.x10"
            java.lang.System.err.println(t$117730);
            
            //#line 64 "x10/compiler/ws/Worker.x10"
            t.printStackTrace();
        }
    }
    
    
    //#line 68 "x10/compiler/ws/Worker.x10"
    public java.lang.Object find() {
        
        //#line 69 "x10/compiler/ws/Worker.x10"
        java.lang.Object k =  null;
        
        //#line 71 "x10/compiler/ws/Worker.x10"
        final x10.core.Deque t$117731 = ((x10.core.Deque)(this.fifo));
        
        //#line 71 "x10/compiler/ws/Worker.x10"
        final java.lang.Object t$117732 = t$117731.steal();
        
        //#line 71 "x10/compiler/ws/Worker.x10"
        k = ((java.lang.Object)(t$117732));
        
        //#line 72 "x10/compiler/ws/Worker.x10"
        while (true) {
            
            //#line 72 "x10/compiler/ws/Worker.x10"
            final boolean t$117761 = ((null) == (k));
            
            //#line 72 "x10/compiler/ws/Worker.x10"
            if (!(t$117761)) {
                
                //#line 72 "x10/compiler/ws/Worker.x10"
                break;
            }
            
            //#line 321 . "x10/xrx/Runtime.x10"
            final x10.xrx.Pool t$117837 = ((x10.xrx.Pool)(x10.xrx.Runtime.get$pool()));
            
            //#line 321 . "x10/xrx/Runtime.x10"
            final boolean t$117838 = t$117837.wsEnd;
            
            //#line 73 "x10/compiler/ws/Worker.x10"
            if (t$117838) {
                
                //#line 73 "x10/compiler/ws/Worker.x10"
                return null;
            }
            
            //#line 75 "x10/compiler/ws/Worker.x10"
            final x10.util.Random t$117839 = ((x10.util.Random)(this.random));
            
            //#line 75 "x10/compiler/ws/Worker.x10"
            final int t$117840 = x10.xrx.Runtime.get$NTHREADS();
            
            //#line 75 "x10/compiler/ws/Worker.x10"
            final int rand$117841 = t$117839.nextInt$O((int)(t$117840));
            
            //#line 76 "x10/compiler/ws/Worker.x10"
            final x10.core.Rail t$117842 = ((x10.core.Rail)(this.workers));
            
            //#line 76 "x10/compiler/ws/Worker.x10"
            final long t$117843 = ((long)(((int)(rand$117841))));
            
            //#line 76 "x10/compiler/ws/Worker.x10"
            final x10.compiler.ws.Worker victim$117844 = ((x10.compiler.ws.Worker[])t$117842.value)[(int)t$117843];
            
            //#line 77 "x10/compiler/ws/Worker.x10"
            final x10.core.Deque t$117845 = ((x10.core.Deque)(victim$117844.fifo));
            
            //#line 77 "x10/compiler/ws/Worker.x10"
            final java.lang.Object t$117846 = t$117845.steal();
            
            //#line 77 "x10/compiler/ws/Worker.x10"
            k = ((java.lang.Object)(t$117846));
            
            //#line 78 "x10/compiler/ws/Worker.x10"
            final boolean t$117848 = ((null) != (k));
            
            //#line 78 "x10/compiler/ws/Worker.x10"
            if (t$117848) {
                
                //#line 78 "x10/compiler/ws/Worker.x10"
                break;
            }
            
            //#line 80 "x10/compiler/ws/Worker.x10"
            final x10.util.concurrent.Lock t$117849 = ((x10.util.concurrent.Lock)(victim$117844.lock));
            
            //#line 80 "x10/compiler/ws/Worker.x10"
            final boolean t$117850 = t$117849.tryLock();
            
            //#line 80 "x10/compiler/ws/Worker.x10"
            if (t$117850) {
                
                //#line 81 "x10/compiler/ws/Worker.x10"
                final x10.core.Deque t$117851 = ((x10.core.Deque)(victim$117844.deque));
                
                //#line 81 "x10/compiler/ws/Worker.x10"
                final java.lang.Object t$117852 = t$117851.steal();
                
                //#line 81 "x10/compiler/ws/Worker.x10"
                k = ((java.lang.Object)(t$117852));
                
                //#line 82 "x10/compiler/ws/Worker.x10"
                final boolean t$117854 = ((null) != (k));
                
                //#line 82 "x10/compiler/ws/Worker.x10"
                if (t$117854) {
                    
                    //#line 83 "x10/compiler/ws/Worker.x10"
                    x10.compiler.ws.RegularFrame r$117856 = ((x10.compiler.ws.RegularFrame) k);
                    
                    //#line 88 "x10/compiler/ws/Worker.x10"
                    final x10.util.concurrent.Monitor t$117857 = ((x10.util.concurrent.Monitor)(x10.xrx.Runtime.get$atomicMonitor()));
                    
                    //#line 88 "x10/compiler/ws/Worker.x10"
                    t$117857.lock();
                    
                    //#line 88 "x10/compiler/ws/Worker.x10"
                    final x10.compiler.ws.FinishFrame obj$117859 = ((x10.compiler.ws.FinishFrame)(r$117856.ff));
                    
                    //#line 88 "x10/compiler/ws/Worker.x10"
                    final int t$117860 = obj$117859.asyncs;
                    
                    //#line 88 "x10/compiler/ws/Worker.x10"
                    final int t$117861 = ((t$117860) + (((int)(1))));
                    
                    //#line 88 "x10/compiler/ws/Worker.x10"
                    obj$117859.asyncs = t$117861;
                    
                    //#line 88 "x10/compiler/ws/Worker.x10"
                    final x10.util.concurrent.Monitor t$117862 = ((x10.util.concurrent.Monitor)(x10.xrx.Runtime.get$atomicMonitor()));
                    
                    //#line 88 "x10/compiler/ws/Worker.x10"
                    t$117862.unlock();
                }
                
                //#line 90 "x10/compiler/ws/Worker.x10"
                final x10.util.concurrent.Lock t$117863 = ((x10.util.concurrent.Lock)(victim$117844.lock));
                
                //#line 90 "x10/compiler/ws/Worker.x10"
                t$117863.unlock();
            }
            
            //#line 92 "x10/compiler/ws/Worker.x10"
            final boolean t$117865 = ((null) != (k));
            
            //#line 92 "x10/compiler/ws/Worker.x10"
            if (t$117865) {
                
                //#line 92 "x10/compiler/ws/Worker.x10"
                break;
            }
            
            //#line 94 "x10/compiler/ws/Worker.x10"
            x10.runtime.impl.java.Runtime.eventProbe();
            
            //#line 95 "x10/compiler/ws/Worker.x10"
            final x10.core.Deque t$117866 = ((x10.core.Deque)(this.fifo));
            
            //#line 95 "x10/compiler/ws/Worker.x10"
            final java.lang.Object t$117867 = t$117866.steal();
            
            //#line 95 "x10/compiler/ws/Worker.x10"
            k = ((java.lang.Object)(t$117867));
        }
        
        //#line 97 "x10/compiler/ws/Worker.x10"
        return k;
    }
    
    
    //#line 100 "x10/compiler/ws/Worker.x10"
    public void unroll(x10.compiler.ws.Frame frame) {
        
        //#line 101 "x10/compiler/ws/Worker.x10"
        x10.compiler.ws.Frame up =  null;
        
        //#line 102 "x10/compiler/ws/Worker.x10"
        while (true) {
            
            //#line 103 "x10/compiler/ws/Worker.x10"
            frame.wrapResume(((x10.compiler.ws.Worker)(this)));
            
            //#line 104 "x10/compiler/ws/Worker.x10"
            final x10.compiler.ws.Frame t$117765 = ((x10.compiler.ws.Frame)(frame.up));
            
            //#line 104 "x10/compiler/ws/Worker.x10"
            up = ((x10.compiler.ws.Frame)(t$117765));
            
            //#line 105 "x10/compiler/ws/Worker.x10"
            up.wrapBack(((x10.compiler.ws.Worker)(this)), ((x10.compiler.ws.Frame)(frame)));
            
            //#line 107 "x10/compiler/ws/Worker.x10"
            frame = ((x10.compiler.ws.Frame)(up));
        }
    }
    
    
    //#line 111 "x10/compiler/ws/Worker.x10"
    public static void wsRunAsync(final long id, final x10.core.fun.VoidFun_0_0 body) {
        
        //#line 112 "x10/compiler/ws/Worker.x10"
        final long t$117769 = ((long)x10.x10rt.X10RT.hereId());
        
        //#line 112 "x10/compiler/ws/Worker.x10"
        final boolean t$117770 = ((long) id) == ((long) t$117769);
        
        //#line 112 "x10/compiler/ws/Worker.x10"
        if (t$117770) {
            
            //#line 113 "x10/compiler/ws/Worker.x10"
            final x10.core.fun.VoidFun_0_0 copy = ((x10.core.fun.VoidFun_0_0)(x10.xrx.Runtime.<x10.core.fun.VoidFun_0_0> deepCopy__0x10$xrx$Runtime$$T$G(x10.core.fun.VoidFun_0_0.$RTT, ((x10.core.fun.VoidFun_0_0)(body)), ((x10.xrx.Runtime.Profile)(null)))));
            
            //#line 114 "x10/compiler/ws/Worker.x10"
            ((x10.core.fun.VoidFun_0_0)copy).$apply();
        } else {
            
            //#line 117 "x10/compiler/ws/Worker.x10"
            x10.runtime.impl.java.EvalUtils.eval(((x10.xrx.Runtime.Profile)
                                                   (null)));
            
            //#line 75 . "x10/xrx/Runtime.x10"
            x10.xrx.Runtime.x10rtSendMessage((long)(id), ((x10.core.fun.VoidFun_0_0)(body)), ((x10.xrx.Runtime.Profile)(null)), ((x10.core.fun.VoidFun_0_0)(null)));
        }
    }
    
    
    //#line 122 "x10/compiler/ws/Worker.x10"
    public static void runAsyncAt(final x10.lang.Place place, final x10.compiler.ws.RegularFrame frame) {
        
        //#line 123 "x10/compiler/ws/Worker.x10"
        final x10.core.fun.VoidFun_0_0 body = ((x10.core.fun.VoidFun_0_0)(new x10.compiler.ws.Worker.$Closure_runAsyncAt(frame)));
        
        //#line 124 "x10/compiler/ws/Worker.x10"
        final long t$117772 = place.id;
        
        //#line 124 "x10/compiler/ws/Worker.x10"
        x10.compiler.ws.Worker.wsRunAsync((long)(t$117772), ((x10.core.fun.VoidFun_0_0)(body)));
    }
    
    
    //#line 127 "x10/compiler/ws/Worker.x10"
    public static void runAt(final x10.lang.Place place, final x10.compiler.ws.RegularFrame frame) {
        
        //#line 128 "x10/compiler/ws/Worker.x10"
        final x10.core.fun.VoidFun_0_0 body = ((x10.core.fun.VoidFun_0_0)(new x10.compiler.ws.Worker.$Closure_runAt(frame)));
        
        //#line 129 "x10/compiler/ws/Worker.x10"
        final long t$117774 = place.id;
        
        //#line 129 "x10/compiler/ws/Worker.x10"
        x10.compiler.ws.Worker.wsRunAsync((long)(t$117774), ((x10.core.fun.VoidFun_0_0)(body)));
        
        //#line 130 "x10/compiler/ws/Worker.x10"
        final x10.compiler.Abort t$117775 = ((x10.compiler.Abort)(x10.compiler.Abort.get$ABORT()));
        
        //#line 130 "x10/compiler/ws/Worker.x10"
        throw t$117775;
    }
    
    
    //#line 133 "x10/compiler/ws/Worker.x10"
    public static void stop() {
        
        //#line 134 "x10/compiler/ws/Worker.x10"
        final x10.core.fun.VoidFun_0_0 body = ((x10.core.fun.VoidFun_0_0)(new x10.compiler.ws.Worker.$Closure_stop()));
        
        //#line 135 "x10/compiler/ws/Worker.x10"
        final x10.lang.PlaceGroup t$117873 = ((x10.lang.PlaceGroup)(x10.lang.Place.places()));
        
        //#line 135 "x10/compiler/ws/Worker.x10"
        final x10.lang.Iterator p$117874 = t$117873.iterator();
        
        //#line 135 "x10/compiler/ws/Worker.x10"
        for (;
             true;
             ) {
            
            //#line 135 "x10/compiler/ws/Worker.x10"
            final boolean t$117875 = ((x10.lang.Iterator<x10.lang.Place>)p$117874).hasNext$O();
            
            //#line 135 "x10/compiler/ws/Worker.x10"
            if (!(t$117875)) {
                
                //#line 135 "x10/compiler/ws/Worker.x10"
                break;
            }
            
            //#line 135 "x10/compiler/ws/Worker.x10"
            final x10.lang.Place p$117868 = ((x10.lang.Place)(((x10.lang.Iterator<x10.lang.Place>)p$117874).next$G()));
            
            //#line 136 "x10/compiler/ws/Worker.x10"
            final boolean t$117869 = (!x10.rtt.Equality.equalsequals((p$117868),(x10.x10rt.X10RT.here())));
            
            //#line 136 "x10/compiler/ws/Worker.x10"
            if (t$117869) {
                
                //#line 137 "x10/compiler/ws/Worker.x10"
                final long id$117870 = p$117868.id;
                
                //#line 137 "x10/compiler/ws/Worker.x10"
                x10.runtime.impl.java.EvalUtils.eval(((x10.xrx.Runtime.Profile)
                                                       (null)));
                
                //#line 75 . "x10/xrx/Runtime.x10"
                x10.xrx.Runtime.x10rtSendMessage((long)(id$117870), ((x10.core.fun.VoidFun_0_0)(body)), ((x10.xrx.Runtime.Profile)(null)), ((x10.core.fun.VoidFun_0_0)(null)));
            }
        }
        
        //#line 318 . "x10/xrx/Runtime.x10"
        final x10.xrx.Pool t$117876 = ((x10.xrx.Pool)(x10.xrx.Runtime.get$pool()));
        
        //#line 318 . "x10/xrx/Runtime.x10"
        t$117876.wsEnd = true;
    }
    
    
    //#line 144 "x10/compiler/ws/Worker.x10"
    public static x10.compiler.ws.Worker startHere() {
        
        //#line 299 . "x10/xrx/Runtime.x10"
        final x10.xrx.Pool t$117891 = ((x10.xrx.Pool)(x10.xrx.Runtime.get$pool()));
        
        //#line 299 . "x10/xrx/Runtime.x10"
        final x10.core.Deque t$117892 = ((x10.core.Deque)(new x10.core.Deque()));
        
        //#line 299 . "x10/xrx/Runtime.x10"
        t$117891.wsBlockedContinuations = ((x10.core.Deque)(t$117892));
        
        //#line 146 "x10/compiler/ws/Worker.x10"
        final int t$117783 = x10.xrx.Runtime.get$NTHREADS();
        
        //#line 146 "x10/compiler/ws/Worker.x10"
        final long t$117784 = ((long)(((int)(t$117783))));
        
        //#line 146 "x10/compiler/ws/Worker.x10"
        final x10.core.Rail workers = ((x10.core.Rail)(new x10.core.Rail<x10.compiler.ws.Worker>(x10.compiler.ws.Worker.$RTT, t$117784)));
        
        //#line 147 "x10/compiler/ws/Worker.x10"
        int i$117893 = 0;
        {
            
            //#line 147 "x10/compiler/ws/Worker.x10"
            final x10.compiler.ws.Worker[] workers$value$117921 = ((x10.compiler.ws.Worker[])workers.value);
            
            //#line 147 "x10/compiler/ws/Worker.x10"
            for (;
                 true;
                 ) {
                
                //#line 147 "x10/compiler/ws/Worker.x10"
                final int t$117895 = x10.xrx.Runtime.get$NTHREADS();
                
                //#line 147 "x10/compiler/ws/Worker.x10"
                final boolean t$117896 = ((i$117893) < (((int)(t$117895))));
                
                //#line 147 "x10/compiler/ws/Worker.x10"
                if (!(t$117896)) {
                    
                    //#line 147 "x10/compiler/ws/Worker.x10"
                    break;
                }
                
                //#line 148 "x10/compiler/ws/Worker.x10"
                final long t$117879 = ((long)(((int)(i$117893))));
                
                //#line 148 "x10/compiler/ws/Worker.x10"
                final x10.compiler.ws.Worker alloc$117880 = ((x10.compiler.ws.Worker)(new x10.compiler.ws.Worker((java.lang.System[]) null)));
                
                //#line 148 "x10/compiler/ws/Worker.x10"
                alloc$117880.x10$compiler$ws$Worker$$init$S(i$117893, ((x10.core.Rail)(workers)), (x10.compiler.ws.Worker.__1$1x10$compiler$ws$Worker$2) null);
                
                //#line 148 "x10/compiler/ws/Worker.x10"
                workers$value$117921[(int)t$117879]=alloc$117880;
                
                //#line 147 "x10/compiler/ws/Worker.x10"
                final int t$117882 = ((i$117893) + (((int)(1))));
                
                //#line 147 "x10/compiler/ws/Worker.x10"
                i$117893 = t$117882;
            }
        }
        
        //#line 150 "x10/compiler/ws/Worker.x10"
        final x10.compiler.ws.Worker t$117796 = ((x10.compiler.ws.Worker[])workers.value)[(int)0L];
        
        //#line 331 .. "x10/xrx/Runtime.x10"
        final x10.core.Thread t$117794 = x10.core.Thread.currentThread();
        
        //#line 331 .. "x10/xrx/Runtime.x10"
        final x10.xrx.Worker t$117795 = x10.rtt.Types.<x10.xrx.Worker> cast(t$117794,x10.xrx.Worker.$RTT);
        
        //#line 303 . "x10/xrx/Runtime.x10"
        final x10.core.Deque t$117797 = ((x10.core.Deque)(t$117795.wsfifo));
        
        //#line 150 "x10/compiler/ws/Worker.x10"
        t$117796.fifo = ((x10.core.Deque)(t$117797));
        
        //#line 151 "x10/compiler/ws/Worker.x10"
        int i$117897 = 1;
        {
            
            //#line 151 "x10/compiler/ws/Worker.x10"
            final x10.compiler.ws.Worker[] workers$value$117922 = ((x10.compiler.ws.Worker[])workers.value);
            
            //#line 151 "x10/compiler/ws/Worker.x10"
            for (;
                 true;
                 ) {
                
                //#line 151 "x10/compiler/ws/Worker.x10"
                final int t$117899 = x10.xrx.Runtime.get$NTHREADS();
                
                //#line 151 "x10/compiler/ws/Worker.x10"
                final boolean t$117900 = ((i$117897) < (((int)(t$117899))));
                
                //#line 151 "x10/compiler/ws/Worker.x10"
                if (!(t$117900)) {
                    
                    //#line 151 "x10/compiler/ws/Worker.x10"
                    break;
                }
                
                //#line 152 "x10/compiler/ws/Worker.x10"
                final long t$117884 = ((long)(((int)(i$117897))));
                
                //#line 152 "x10/compiler/ws/Worker.x10"
                final x10.compiler.ws.Worker worker$117885 = ((x10.compiler.ws.Worker)workers$value$117922[(int)t$117884]);
                
                //#line 153 "x10/compiler/ws/Worker.x10"
                x10.xrx.Runtime.runAsync(((x10.core.fun.VoidFun_0_0)(new x10.compiler.ws.Worker.$Closure$53(worker$117885))));
                
                //#line 151 "x10/compiler/ws/Worker.x10"
                final int t$117890 = ((i$117897) + (((int)(1))));
                
                //#line 151 "x10/compiler/ws/Worker.x10"
                i$117897 = t$117890;
            }
        }
        
        //#line 158 "x10/compiler/ws/Worker.x10"
        final x10.compiler.ws.Worker t$117809 = ((x10.compiler.ws.Worker[])workers.value)[(int)0L];
        
        //#line 158 "x10/compiler/ws/Worker.x10"
        return t$117809;
    }
    
    
    //#line 161 "x10/compiler/ws/Worker.x10"
    public static x10.compiler.ws.Worker start() {
        
        //#line 162 "x10/compiler/ws/Worker.x10"
        final x10.compiler.ws.Worker worker = x10.compiler.ws.Worker.startHere();
        
        //#line 163 "x10/compiler/ws/Worker.x10"
        final x10.lang.PlaceGroup t$117904 = ((x10.lang.PlaceGroup)(x10.lang.Place.places()));
        
        //#line 163 "x10/compiler/ws/Worker.x10"
        final x10.lang.Iterator p$117905 = t$117904.iterator();
        
        //#line 163 "x10/compiler/ws/Worker.x10"
        for (;
             true;
             ) {
            
            //#line 163 "x10/compiler/ws/Worker.x10"
            final boolean t$117906 = ((x10.lang.Iterator<x10.lang.Place>)p$117905).hasNext$O();
            
            //#line 163 "x10/compiler/ws/Worker.x10"
            if (!(t$117906)) {
                
                //#line 163 "x10/compiler/ws/Worker.x10"
                break;
            }
            
            //#line 163 "x10/compiler/ws/Worker.x10"
            final x10.lang.Place p$117901 = ((x10.lang.Place)(((x10.lang.Iterator<x10.lang.Place>)p$117905).next$G()));
            
            //#line 164 "x10/compiler/ws/Worker.x10"
            final boolean t$117902 = (!x10.rtt.Equality.equalsequals((p$117901),(x10.x10rt.X10RT.here())));
            
            //#line 164 "x10/compiler/ws/Worker.x10"
            if (t$117902) {
                
                //#line 165 "x10/compiler/ws/Worker.x10"
                x10.xrx.Runtime.runAsync(((x10.lang.Place)(p$117901)), ((x10.core.fun.VoidFun_0_0)(new x10.compiler.ws.Worker.$Closure$54())), ((x10.xrx.Runtime.Profile)(null)));
            }
        }
        
        //#line 168 "x10/compiler/ws/Worker.x10"
        return worker;
    }
    
    
    //#line 171 "x10/compiler/ws/Worker.x10"
    public static void main(final x10.compiler.ws.MainFrame frame) {
        
        //#line 172 "x10/compiler/ws/Worker.x10"
        final x10.compiler.ws.Worker worker = ((x10.compiler.ws.Worker)(x10.compiler.ws.Worker.start()));
        
        //#line 173 "x10/compiler/ws/Worker.x10"
        final x10.compiler.ws.FinishFrame ff = ((x10.compiler.ws.FinishFrame)(frame.ff));
        
        //#line 174 "x10/compiler/ws/Worker.x10"
        boolean finalize = true;
        
        //#line 175 "x10/compiler/ws/Worker.x10"
        try {{
            
            //#line 176 "x10/compiler/ws/Worker.x10"
            frame.fast(((x10.compiler.ws.Worker)(worker)));
        }}catch (final x10.compiler.Abort t) {
            
            //#line 178 "x10/compiler/ws/Worker.x10"
            finalize = false;
            
            //#line 179 "x10/compiler/ws/Worker.x10"
            worker.run();
        }catch (final java.lang.RuntimeException t) {
            
            //#line 181 "x10/compiler/ws/Worker.x10"
            ff.caught(((java.lang.Throwable)(t)));
        }finally {{
             
             //#line 183 "x10/compiler/ws/Worker.x10"
             if (finalize) {
                 
                 //#line 183 "x10/compiler/ws/Worker.x10"
                 x10.compiler.ws.Worker.stop();
             }
         }}
        
        //#line 117 . "x10/compiler/ws/FinishFrame.x10"
        final x10.util.GrowableRail t$117909 = ((x10.util.GrowableRail)(ff.exceptions));
        
        //#line 117 . "x10/compiler/ws/FinishFrame.x10"
        final boolean t$117910 = ((null) != (t$117909));
        
        //#line 117 . "x10/compiler/ws/FinishFrame.x10"
        if (t$117910) {
            
            //#line 118 . "x10/compiler/ws/FinishFrame.x10"
            while (true) {
                
                //#line 118 . "x10/compiler/ws/FinishFrame.x10"
                final x10.util.GrowableRail this$117911 = ((x10.util.GrowableRail)(ff.exceptions));
                
                //#line 160 .. "x10/util/GrowableRail.x10"
                final long t$117912 = ((x10.util.GrowableRail<java.lang.Throwable>)this$117911).size;
                
                //#line 160 .. "x10/util/GrowableRail.x10"
                final boolean t$117913 = ((long) t$117912) == ((long) 0L);
                
                //#line 118 . "x10/compiler/ws/FinishFrame.x10"
                final boolean t$117914 = !(t$117913);
                
                //#line 118 . "x10/compiler/ws/FinishFrame.x10"
                if (!(t$117914)) {
                    
                    //#line 118 . "x10/compiler/ws/FinishFrame.x10"
                    break;
                }
                
                //#line 119 . "x10/compiler/ws/FinishFrame.x10"
                final x10.util.GrowableRail t$117907 = ((x10.util.GrowableRail)(ff.exceptions));
                
                //#line 119 . "x10/compiler/ws/FinishFrame.x10"
                final java.lang.Throwable t$117908 = ((x10.util.GrowableRail<java.lang.Throwable>)t$117907).removeLast$G();
                
                //#line 119 . "x10/compiler/ws/FinishFrame.x10"
                x10.xrx.Runtime.pushException(((java.lang.Throwable)(t$117908)));
            }
        }
        }
    
    
    //#line 188 "x10/compiler/ws/Worker.x10"
    public void rethrow() {
        
        //#line 189 "x10/compiler/ws/Worker.x10"
        final java.lang.RuntimeException t$117823 = ((java.lang.RuntimeException)(this.throwable));
        
        //#line 189 "x10/compiler/ws/Worker.x10"
        final boolean t$117824 = ((null) != (t$117823));
        
        //#line 189 "x10/compiler/ws/Worker.x10"
        if (t$117824) {
            
            //#line 190 "x10/compiler/ws/Worker.x10"
            final java.lang.RuntimeException t = ((java.lang.RuntimeException)(this.throwable));
            
            //#line 191 "x10/compiler/ws/Worker.x10"
            this.throwable = null;
            
            //#line 192 "x10/compiler/ws/Worker.x10"
            throw t;
        }
    }
    
    
    //#line 23 "x10/compiler/ws/Worker.x10"
    final public x10.compiler.ws.Worker x10$compiler$ws$Worker$$this$x10$compiler$ws$Worker() {
        
        //#line 23 "x10/compiler/ws/Worker.x10"
        return x10.compiler.ws.Worker.this;
    }
    
    
    //#line 23 "x10/compiler/ws/Worker.x10"
    final public void __fieldInitializers_x10_compiler_ws_Worker() {
        
        //#line 28 "x10/compiler/ws/Worker.x10"
        final x10.core.Deque t$117825 = ((x10.core.Deque)(new x10.core.Deque()));
        
        //#line 23 "x10/compiler/ws/Worker.x10"
        this.deque = ((x10.core.Deque)(t$117825));
        
        //#line 29 "x10/compiler/ws/Worker.x10"
        final x10.core.Deque t$117826 = ((x10.core.Deque)(this.deque));
        
        //#line 23 "x10/compiler/ws/Worker.x10"
        this.fifo = t$117826;
        
        //#line 30 "x10/compiler/ws/Worker.x10"
        final x10.util.concurrent.Lock t$117827 = ((x10.util.concurrent.Lock)(new x10.util.concurrent.Lock()));
        
        //#line 23 "x10/compiler/ws/Worker.x10"
        this.lock = ((x10.util.concurrent.Lock)(t$117827));
        
        //#line 23 "x10/compiler/ws/Worker.x10"
        this.throwable = null;
    }
    
    @x10.runtime.impl.java.X10Generated
    final public static class $Closure_runAsyncAt extends x10.core.Ref implements x10.core.fun.VoidFun_0_0, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<$Closure_runAsyncAt> $RTT = 
            x10.rtt.StaticVoidFunType.<$Closure_runAsyncAt> make($Closure_runAsyncAt.class,
                                                                 new x10.rtt.Type[] {
                                                                     x10.core.fun.VoidFun_0_0.$RTT
                                                                 });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static x10.serialization.X10JavaSerializable $_deserialize_body(x10.compiler.ws.Worker.$Closure_runAsyncAt $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            $_obj.frame = $deserializer.readObject();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.compiler.ws.Worker.$Closure_runAsyncAt $_obj = new x10.compiler.ws.Worker.$Closure_runAsyncAt((java.lang.System[]) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            $serializer.write(this.frame);
            
        }
        
        // constructor just for allocation
        public $Closure_runAsyncAt(final java.lang.System[] $dummy) {
            
        }
        
        
    
        
        public void $apply() {
            
            //#line 123 "x10/compiler/ws/Worker.x10"
            final x10.core.Deque t$117771 = x10.xrx.Runtime.wsFIFO();
            
            //#line 123 "x10/compiler/ws/Worker.x10"
            t$117771.push(((java.lang.Object)(this.frame)));
        }
        
        public x10.compiler.ws.RegularFrame frame;
        
        public $Closure_runAsyncAt(final x10.compiler.ws.RegularFrame frame) {
             {
                this.frame = ((x10.compiler.ws.RegularFrame)(frame));
            }
        }
        
    }
    
    @x10.runtime.impl.java.X10Generated
    final public static class $Closure_runAt extends x10.core.Ref implements x10.core.fun.VoidFun_0_0, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<$Closure_runAt> $RTT = 
            x10.rtt.StaticVoidFunType.<$Closure_runAt> make($Closure_runAt.class,
                                                            new x10.rtt.Type[] {
                                                                x10.core.fun.VoidFun_0_0.$RTT
                                                            });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static x10.serialization.X10JavaSerializable $_deserialize_body(x10.compiler.ws.Worker.$Closure_runAt $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            $_obj.frame = $deserializer.readObject();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.compiler.ws.Worker.$Closure_runAt $_obj = new x10.compiler.ws.Worker.$Closure_runAt((java.lang.System[]) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            $serializer.write(this.frame);
            
        }
        
        // constructor just for allocation
        public $Closure_runAt(final java.lang.System[] $dummy) {
            
        }
        
        
    
        
        public void $apply() {
            
            //#line 128 "x10/compiler/ws/Worker.x10"
            final x10.core.Deque t$117773 = x10.xrx.Runtime.wsFIFO();
            
            //#line 128 "x10/compiler/ws/Worker.x10"
            t$117773.push(((java.lang.Object)(this.frame)));
        }
        
        public x10.compiler.ws.RegularFrame frame;
        
        public $Closure_runAt(final x10.compiler.ws.RegularFrame frame) {
             {
                this.frame = ((x10.compiler.ws.RegularFrame)(frame));
            }
        }
        
    }
    
    @x10.runtime.impl.java.X10Generated
    final public static class $Closure_stop extends x10.core.Ref implements x10.core.fun.VoidFun_0_0, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<$Closure_stop> $RTT = 
            x10.rtt.StaticVoidFunType.<$Closure_stop> make($Closure_stop.class,
                                                           new x10.rtt.Type[] {
                                                               x10.core.fun.VoidFun_0_0.$RTT
                                                           });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static x10.serialization.X10JavaSerializable $_deserialize_body(x10.compiler.ws.Worker.$Closure_stop $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.compiler.ws.Worker.$Closure_stop $_obj = new x10.compiler.ws.Worker.$Closure_stop((java.lang.System[]) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            
        }
        
        // constructor just for allocation
        public $Closure_stop(final java.lang.System[] $dummy) {
            
        }
        
        
    
        
        public void $apply() {
            
            //#line 134 "x10/compiler/ws/Worker.x10"
            x10.xrx.Runtime.wsEnd();
        }
        
        public $Closure_stop() {
             {
                
            }
        }
        
    }
    
    @x10.runtime.impl.java.X10Generated
    final public static class $Closure$53 extends x10.core.Ref implements x10.core.fun.VoidFun_0_0, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<$Closure$53> $RTT = 
            x10.rtt.StaticVoidFunType.<$Closure$53> make($Closure$53.class,
                                                         new x10.rtt.Type[] {
                                                             x10.core.fun.VoidFun_0_0.$RTT
                                                         });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static x10.serialization.X10JavaSerializable $_deserialize_body(x10.compiler.ws.Worker.$Closure$53 $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            $_obj.worker$117885 = $deserializer.readObject();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.compiler.ws.Worker.$Closure$53 $_obj = new x10.compiler.ws.Worker.$Closure$53((java.lang.System[]) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            $serializer.write(this.worker$117885);
            
        }
        
        // constructor just for allocation
        public $Closure$53(final java.lang.System[] $dummy) {
            
        }
        
        
    
        
        public void $apply() {
            
            //#line 153 "x10/compiler/ws/Worker.x10"
            try {{
                
                //#line 331 .. "x10/xrx/Runtime.x10"
                final x10.core.Thread t$117886 = x10.core.Thread.currentThread();
                
                //#line 331 .. "x10/xrx/Runtime.x10"
                final x10.xrx.Worker t$117887 = x10.rtt.Types.<x10.xrx.Worker> cast(t$117886,x10.xrx.Worker.$RTT);
                
                //#line 303 . "x10/xrx/Runtime.x10"
                final x10.core.Deque t$117888 = ((x10.core.Deque)(t$117887.wsfifo));
                
                //#line 154 "x10/compiler/ws/Worker.x10"
                this.worker$117885.fifo = ((x10.core.Deque)(t$117888));
                
                //#line 155 "x10/compiler/ws/Worker.x10"
                this.worker$117885.run();
            }}catch (java.lang.Error __lowerer__var__0__) {
                
                //#line 153 "x10/compiler/ws/Worker.x10"
                throw __lowerer__var__0__;
            }catch (java.lang.Throwable __lowerer__var__1__) {
                
                //#line 153 "x10/compiler/ws/Worker.x10"
                throw x10.rtt.Types.EXCEPTION.isInstance(__lowerer__var__1__) ? (java.lang.RuntimeException)(__lowerer__var__1__) : new x10.lang.WrappedThrowable(__lowerer__var__1__);
            }
        }
        
        public x10.compiler.ws.Worker worker$117885;
        
        public $Closure$53(final x10.compiler.ws.Worker worker$117885) {
             {
                this.worker$117885 = ((x10.compiler.ws.Worker)(worker$117885));
            }
        }
        
    }
    
    @x10.runtime.impl.java.X10Generated
    final public static class $Closure$54 extends x10.core.Ref implements x10.core.fun.VoidFun_0_0, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<$Closure$54> $RTT = 
            x10.rtt.StaticVoidFunType.<$Closure$54> make($Closure$54.class,
                                                         new x10.rtt.Type[] {
                                                             x10.core.fun.VoidFun_0_0.$RTT
                                                         });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static x10.serialization.X10JavaSerializable $_deserialize_body(x10.compiler.ws.Worker.$Closure$54 $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.compiler.ws.Worker.$Closure$54 $_obj = new x10.compiler.ws.Worker.$Closure$54((java.lang.System[]) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            
        }
        
        // constructor just for allocation
        public $Closure$54(final java.lang.System[] $dummy) {
            
        }
        
        
    
        
        public void $apply() {
            
            //#line 165 "x10/compiler/ws/Worker.x10"
            try {{
                
                //#line 165 "x10/compiler/ws/Worker.x10"
                final x10.compiler.ws.Worker t$117903 = x10.compiler.ws.Worker.startHere();
                
                //#line 165 "x10/compiler/ws/Worker.x10"
                t$117903.run();
            }}catch (java.lang.Error __lowerer__var__0__) {
                
                //#line 165 "x10/compiler/ws/Worker.x10"
                throw __lowerer__var__0__;
            }catch (java.lang.Throwable __lowerer__var__1__) {
                
                //#line 165 "x10/compiler/ws/Worker.x10"
                throw x10.rtt.Types.EXCEPTION.isInstance(__lowerer__var__1__) ? (java.lang.RuntimeException)(__lowerer__var__1__) : new x10.lang.WrappedThrowable(__lowerer__var__1__);
            }
        }
        
        public $Closure$54() {
             {
                
            }
        }
        
    }
    
    }
    
    