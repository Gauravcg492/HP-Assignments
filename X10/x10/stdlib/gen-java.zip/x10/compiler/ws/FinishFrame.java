package x10.compiler.ws;


@x10.runtime.impl.java.X10Generated
abstract public class FinishFrame extends x10.compiler.ws.Frame implements x10.serialization.X10JavaSerializable
{
    public static final x10.rtt.RuntimeType<FinishFrame> $RTT = 
        x10.rtt.NamedType.<FinishFrame> make("x10.compiler.ws.FinishFrame",
                                             FinishFrame.class,
                                             new x10.rtt.Type[] {
                                                 x10.compiler.ws.Frame.$RTT
                                             });
    
    public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
    
    public x10.rtt.Type<?> $getParam(int i) { return null; }
    
    public static x10.serialization.X10JavaSerializable $_deserialize_body(x10.compiler.ws.FinishFrame $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
        x10.compiler.ws.Frame.$_deserialize_body($_obj, $deserializer);
        $_obj.asyncs = $deserializer.readInt();
        return $_obj;
    }
    
    public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
        return null;
    }
    
    public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
        super.$_serialize($serializer);
        $serializer.write(this.asyncs);
        
    }
    
    // constructor just for allocation
    public FinishFrame(final java.lang.System[] $dummy) {
        super($dummy);
        
    }
    
    

    
    //#line 27 "x10/compiler/ws/FinishFrame.x10"
    public int asyncs;
    
    //#line 28 "x10/compiler/ws/FinishFrame.x10"
    public transient x10.util.GrowableRail<java.lang.Throwable> exceptions;
    
    
    //#line 33 "x10/compiler/ws/FinishFrame.x10"
    
    // constructor for non-virtual call
    final public x10.compiler.ws.FinishFrame x10$compiler$ws$FinishFrame$$init$S(final x10.compiler.ws.Frame up) {
         {
            
            //#line 34 "x10/compiler/ws/FinishFrame.x10"
            final x10.compiler.ws.Frame this$115944 = this;
            
            //#line 31 . "x10/compiler/ws/Frame.x10"
            this$115944.up = ((x10.compiler.ws.Frame)(up));
            
            //#line 33 "x10/compiler/ws/FinishFrame.x10"
            
            
            //#line 35 "x10/compiler/ws/FinishFrame.x10"
            this.exceptions = null;
            {
                
                //#line 40 "x10/compiler/ws/FinishFrame.x10"
                this.asyncs = 1;
            }
        }
        return this;
    }
    
    
    
    //#line 70 "x10/compiler/ws/FinishFrame.x10"
    public void wrapBack(final x10.compiler.ws.Worker worker, final x10.compiler.ws.Frame frame) {
        
        //#line 71 "x10/compiler/ws/FinishFrame.x10"
        final java.lang.RuntimeException t$116936 = ((java.lang.RuntimeException)(worker.throwable));
        
        //#line 71 "x10/compiler/ws/FinishFrame.x10"
        final boolean t$116938 = ((null) != (t$116936));
        
        //#line 71 "x10/compiler/ws/FinishFrame.x10"
        if (t$116938) {
            
            //#line 73 "x10/compiler/ws/FinishFrame.x10"
            final java.lang.RuntimeException t$116937 = ((java.lang.RuntimeException)(worker.throwable));
            
            //#line 73 "x10/compiler/ws/FinishFrame.x10"
            this.caught(((java.lang.Throwable)(t$116937)));
            
            //#line 74 "x10/compiler/ws/FinishFrame.x10"
            worker.throwable = null;
        }
    }
    
    
    //#line 79 "x10/compiler/ws/FinishFrame.x10"
    public void wrapResume(final x10.compiler.ws.Worker worker) {
        
        //#line 80 "x10/compiler/ws/FinishFrame.x10"
        int n =  0;
        
        //#line 81 "x10/compiler/ws/FinishFrame.x10"
        final x10.util.concurrent.Monitor t$116939 = ((x10.util.concurrent.Monitor)(x10.xrx.Runtime.get$atomicMonitor()));
        
        //#line 81 "x10/compiler/ws/FinishFrame.x10"
        t$116939.lock();
        
        //#line 81 "x10/compiler/ws/FinishFrame.x10"
        final int t$116940 = this.asyncs;
        
        //#line 81 "x10/compiler/ws/FinishFrame.x10"
        final int t$116941 = ((t$116940) - (((int)(1))));
        
        //#line 81 "x10/compiler/ws/FinishFrame.x10"
        final int t$116942 = this.asyncs = t$116941;
        
        //#line 81 "x10/compiler/ws/FinishFrame.x10"
        n = t$116942;
        
        //#line 81 "x10/compiler/ws/FinishFrame.x10"
        final x10.util.concurrent.Monitor t$116943 = ((x10.util.concurrent.Monitor)(x10.xrx.Runtime.get$atomicMonitor()));
        
        //#line 81 "x10/compiler/ws/FinishFrame.x10"
        t$116943.unlock();
        
        //#line 82 "x10/compiler/ws/FinishFrame.x10"
        final boolean t$116946 = ((int) 0) != ((int) n);
        
        //#line 82 "x10/compiler/ws/FinishFrame.x10"
        if (t$116946) {
            
            //#line 82 "x10/compiler/ws/FinishFrame.x10"
            final x10.compiler.Abort t$116945 = ((x10.compiler.Abort)(x10.compiler.Abort.get$ABORT()));
            
            //#line 82 "x10/compiler/ws/FinishFrame.x10"
            throw t$116945;
        }
        
        //#line 83 "x10/compiler/ws/FinishFrame.x10"
        final x10.util.GrowableRail t$116947 = ((x10.util.GrowableRail)(this.exceptions));
        
        //#line 83 "x10/compiler/ws/FinishFrame.x10"
        final x10.lang.MultipleExceptions t$116948 = x10.lang.MultipleExceptions.make__0$1x10$lang$CheckedThrowable$2(((x10.util.GrowableRail)(t$116947)));
        
        //#line 83 "x10/compiler/ws/FinishFrame.x10"
        worker.throwable = ((java.lang.RuntimeException)(t$116948));
    }
    
    
    //#line 86 "x10/compiler/ws/FinishFrame.x10"
    final public void append__0$1x10$lang$CheckedThrowable$2(final x10.util.GrowableRail s) {
        
        //#line 87 "x10/compiler/ws/FinishFrame.x10"
        final boolean t$116958 = ((null) != (s));
        
        //#line 87 "x10/compiler/ws/FinishFrame.x10"
        if (t$116958) {
            
            //#line 88 "x10/compiler/ws/FinishFrame.x10"
            final x10.util.concurrent.Monitor t$116949 = ((x10.util.concurrent.Monitor)(x10.xrx.Runtime.get$atomicMonitor()));
            
            //#line 88 "x10/compiler/ws/FinishFrame.x10"
            t$116949.lock();
            
            //#line 89 "x10/compiler/ws/FinishFrame.x10"
            final x10.util.GrowableRail t$116950 = ((x10.util.GrowableRail)(this.exceptions));
            
            //#line 89 "x10/compiler/ws/FinishFrame.x10"
            final boolean t$116951 = ((null) == (t$116950));
            
            //#line 89 "x10/compiler/ws/FinishFrame.x10"
            if (t$116951) {
                
                //#line 89 "x10/compiler/ws/FinishFrame.x10"
                final x10.util.GrowableRail alloc$115668 = ((x10.util.GrowableRail)(new x10.util.GrowableRail<java.lang.Throwable>((java.lang.System[]) null, x10.rtt.Types.CHECKED_THROWABLE)));
                
                //#line 50 . "x10/util/GrowableRail.x10"
                alloc$115668.x10$util$GrowableRail$$init$S(((long)(0L)));
                
                //#line 89 "x10/compiler/ws/FinishFrame.x10"
                this.exceptions = ((x10.util.GrowableRail)(alloc$115668));
            }
            
            //#line 90 "x10/compiler/ws/FinishFrame.x10"
            while (true) {
                
                //#line 160 . "x10/util/GrowableRail.x10"
                final long t$116952 = ((x10.util.GrowableRail<java.lang.Throwable>)s).size;
                
                //#line 160 . "x10/util/GrowableRail.x10"
                final boolean t$116953 = ((long) t$116952) == ((long) 0L);
                
                //#line 90 "x10/compiler/ws/FinishFrame.x10"
                final boolean t$116956 = !(t$116953);
                
                //#line 90 "x10/compiler/ws/FinishFrame.x10"
                if (!(t$116956)) {
                    
                    //#line 90 "x10/compiler/ws/FinishFrame.x10"
                    break;
                }
                
                //#line 90 "x10/compiler/ws/FinishFrame.x10"
                final x10.util.GrowableRail t$116989 = ((x10.util.GrowableRail)(this.exceptions));
                
                //#line 90 "x10/compiler/ws/FinishFrame.x10"
                final java.lang.Throwable t$116990 = ((x10.util.GrowableRail<java.lang.Throwable>)s).removeLast$G();
                
                //#line 90 "x10/compiler/ws/FinishFrame.x10"
                ((x10.util.GrowableRail<java.lang.Throwable>)t$116989).add__0x10$util$GrowableRail$$T(((java.lang.Throwable)(t$116990)));
            }
            
            //#line 91 "x10/compiler/ws/FinishFrame.x10"
            final x10.util.concurrent.Monitor t$116957 = ((x10.util.concurrent.Monitor)(x10.xrx.Runtime.get$atomicMonitor()));
            
            //#line 91 "x10/compiler/ws/FinishFrame.x10"
            t$116957.unlock();
        }
    }
    
    
    //#line 95 "x10/compiler/ws/FinishFrame.x10"
    final public void append(final x10.compiler.ws.FinishFrame ff) {
        
        //#line 96 "x10/compiler/ws/FinishFrame.x10"
        final x10.compiler.ws.FinishFrame this$116929 = ((x10.compiler.ws.FinishFrame)(this));
        
        //#line 96 "x10/compiler/ws/FinishFrame.x10"
        final x10.util.GrowableRail s$116927 = ((x10.util.GrowableRail)(ff.exceptions));
        
        //#line 87 . "x10/compiler/ws/FinishFrame.x10"
        final boolean t$116993 = ((null) != (s$116927));
        
        //#line 87 . "x10/compiler/ws/FinishFrame.x10"
        if (t$116993) {
            
            //#line 88 . "x10/compiler/ws/FinishFrame.x10"
            final x10.util.concurrent.Monitor t$116994 = ((x10.util.concurrent.Monitor)(x10.xrx.Runtime.get$atomicMonitor()));
            
            //#line 88 . "x10/compiler/ws/FinishFrame.x10"
            t$116994.lock();
            
            //#line 89 . "x10/compiler/ws/FinishFrame.x10"
            final x10.util.GrowableRail t$116995 = ((x10.util.GrowableRail)(this$116929.exceptions));
            
            //#line 89 . "x10/compiler/ws/FinishFrame.x10"
            final boolean t$116996 = ((null) == (t$116995));
            
            //#line 89 . "x10/compiler/ws/FinishFrame.x10"
            if (t$116996) {
                
                //#line 89 . "x10/compiler/ws/FinishFrame.x10"
                final x10.util.GrowableRail alloc$116997 = ((x10.util.GrowableRail)(new x10.util.GrowableRail<java.lang.Throwable>((java.lang.System[]) null, x10.rtt.Types.CHECKED_THROWABLE)));
                
                //#line 50 .. "x10/util/GrowableRail.x10"
                alloc$116997.x10$util$GrowableRail$$init$S(((long)(0L)));
                
                //#line 89 . "x10/compiler/ws/FinishFrame.x10"
                this$116929.exceptions = ((x10.util.GrowableRail)(alloc$116997));
            }
            
            //#line 90 . "x10/compiler/ws/FinishFrame.x10"
            while (true) {
                
                //#line 160 .. "x10/util/GrowableRail.x10"
                final long t$116998 = ((x10.util.GrowableRail<java.lang.Throwable>)s$116927).size;
                
                //#line 160 .. "x10/util/GrowableRail.x10"
                final boolean t$116999 = ((long) t$116998) == ((long) 0L);
                
                //#line 90 . "x10/compiler/ws/FinishFrame.x10"
                final boolean t$117000 = !(t$116999);
                
                //#line 90 . "x10/compiler/ws/FinishFrame.x10"
                if (!(t$117000)) {
                    
                    //#line 90 . "x10/compiler/ws/FinishFrame.x10"
                    break;
                }
                
                //#line 90 . "x10/compiler/ws/FinishFrame.x10"
                final x10.util.GrowableRail t$116991 = ((x10.util.GrowableRail)(this$116929.exceptions));
                
                //#line 90 . "x10/compiler/ws/FinishFrame.x10"
                final java.lang.Throwable t$116992 = ((x10.util.GrowableRail<java.lang.Throwable>)s$116927).removeLast$G();
                
                //#line 90 . "x10/compiler/ws/FinishFrame.x10"
                ((x10.util.GrowableRail<java.lang.Throwable>)t$116991).add__0x10$util$GrowableRail$$T(((java.lang.Throwable)(t$116992)));
            }
            
            //#line 91 . "x10/compiler/ws/FinishFrame.x10"
            final x10.util.concurrent.Monitor t$117001 = ((x10.util.concurrent.Monitor)(x10.xrx.Runtime.get$atomicMonitor()));
            
            //#line 91 . "x10/compiler/ws/FinishFrame.x10"
            t$117001.unlock();
        }
    }
    
    
    //#line 99 "x10/compiler/ws/FinishFrame.x10"
    final public void caught(final java.lang.Throwable t) {
        
        //#line 101 "x10/compiler/ws/FinishFrame.x10"
        final x10.compiler.Abort t$116969 = ((x10.compiler.Abort)(x10.compiler.Abort.get$ABORT()));
        
        //#line 101 "x10/compiler/ws/FinishFrame.x10"
        final boolean t$116971 = x10.rtt.Equality.equalsequals((t),(t$116969));
        
        //#line 101 "x10/compiler/ws/FinishFrame.x10"
        if (t$116971) {
            
            //#line 101 "x10/compiler/ws/FinishFrame.x10"
            final x10.compiler.Abort t$116970 = ((x10.compiler.Abort)(x10.compiler.Abort.get$ABORT()));
            
            //#line 101 "x10/compiler/ws/FinishFrame.x10"
            throw t$116970;
        }
        
        //#line 102 "x10/compiler/ws/FinishFrame.x10"
        final x10.util.concurrent.Monitor t$116972 = ((x10.util.concurrent.Monitor)(x10.xrx.Runtime.get$atomicMonitor()));
        
        //#line 102 "x10/compiler/ws/FinishFrame.x10"
        t$116972.lock();
        
        //#line 103 "x10/compiler/ws/FinishFrame.x10"
        final x10.util.GrowableRail t$116973 = ((x10.util.GrowableRail)(this.exceptions));
        
        //#line 103 "x10/compiler/ws/FinishFrame.x10"
        final boolean t$116974 = ((null) == (t$116973));
        
        //#line 103 "x10/compiler/ws/FinishFrame.x10"
        if (t$116974) {
            
            //#line 103 "x10/compiler/ws/FinishFrame.x10"
            final x10.util.GrowableRail alloc$115669 = ((x10.util.GrowableRail)(new x10.util.GrowableRail<java.lang.Throwable>((java.lang.System[]) null, x10.rtt.Types.CHECKED_THROWABLE)));
            
            //#line 50 . "x10/util/GrowableRail.x10"
            alloc$115669.x10$util$GrowableRail$$init$S(((long)(0L)));
            
            //#line 103 "x10/compiler/ws/FinishFrame.x10"
            this.exceptions = ((x10.util.GrowableRail)(alloc$115669));
        }
        
        //#line 104 "x10/compiler/ws/FinishFrame.x10"
        final x10.util.GrowableRail t$116975 = ((x10.util.GrowableRail)(this.exceptions));
        
        //#line 104 "x10/compiler/ws/FinishFrame.x10"
        ((x10.util.GrowableRail<java.lang.Throwable>)t$116975).add__0x10$util$GrowableRail$$T(((java.lang.Throwable)(t)));
        
        //#line 105 "x10/compiler/ws/FinishFrame.x10"
        final x10.util.concurrent.Monitor t$116976 = ((x10.util.concurrent.Monitor)(x10.xrx.Runtime.get$atomicMonitor()));
        
        //#line 105 "x10/compiler/ws/FinishFrame.x10"
        t$116976.unlock();
    }
    
    
    //#line 108 "x10/compiler/ws/FinishFrame.x10"
    final public void rethrow() {
        
        //#line 109 "x10/compiler/ws/FinishFrame.x10"
        final x10.util.GrowableRail t$116977 = ((x10.util.GrowableRail)(this.exceptions));
        
        //#line 109 "x10/compiler/ws/FinishFrame.x10"
        final boolean t$116978 = ((null) != (t$116977));
        
        //#line 109 "x10/compiler/ws/FinishFrame.x10"
        if (t$116978) {
            
            //#line 109 "x10/compiler/ws/FinishFrame.x10"
            this.rethrowSlow();
        }
    }
    
    
    //#line 112 "x10/compiler/ws/FinishFrame.x10"
    final public void rethrowSlow() {
        
        //#line 113 "x10/compiler/ws/FinishFrame.x10"
        final x10.util.GrowableRail t$116979 = ((x10.util.GrowableRail)(this.exceptions));
        
        //#line 113 "x10/compiler/ws/FinishFrame.x10"
        final x10.lang.MultipleExceptions t$116980 = ((x10.lang.MultipleExceptions)(new x10.lang.MultipleExceptions(t$116979, (x10.lang.MultipleExceptions.__0$1x10$lang$CheckedThrowable$2) null)));
        
        //#line 113 "x10/compiler/ws/FinishFrame.x10"
        throw t$116980;
    }
    
    
    //#line 116 "x10/compiler/ws/FinishFrame.x10"
    final public void check() {
        
        //#line 117 "x10/compiler/ws/FinishFrame.x10"
        final x10.util.GrowableRail t$116981 = ((x10.util.GrowableRail)(this.exceptions));
        
        //#line 117 "x10/compiler/ws/FinishFrame.x10"
        final boolean t$116987 = ((null) != (t$116981));
        
        //#line 117 "x10/compiler/ws/FinishFrame.x10"
        if (t$116987) {
            
            //#line 118 "x10/compiler/ws/FinishFrame.x10"
            while (true) {
                
                //#line 118 "x10/compiler/ws/FinishFrame.x10"
                final x10.util.GrowableRail this$116934 = ((x10.util.GrowableRail)(this.exceptions));
                
                //#line 160 . "x10/util/GrowableRail.x10"
                final long t$116982 = ((x10.util.GrowableRail<java.lang.Throwable>)this$116934).size;
                
                //#line 160 . "x10/util/GrowableRail.x10"
                final boolean t$116983 = ((long) t$116982) == ((long) 0L);
                
                //#line 118 "x10/compiler/ws/FinishFrame.x10"
                final boolean t$116986 = !(t$116983);
                
                //#line 118 "x10/compiler/ws/FinishFrame.x10"
                if (!(t$116986)) {
                    
                    //#line 118 "x10/compiler/ws/FinishFrame.x10"
                    break;
                }
                
                //#line 119 "x10/compiler/ws/FinishFrame.x10"
                final x10.util.GrowableRail t$117002 = ((x10.util.GrowableRail)(this.exceptions));
                
                //#line 119 "x10/compiler/ws/FinishFrame.x10"
                final java.lang.Throwable t$117003 = ((x10.util.GrowableRail<java.lang.Throwable>)t$117002).removeLast$G();
                
                //#line 119 "x10/compiler/ws/FinishFrame.x10"
                x10.xrx.Runtime.pushException(((java.lang.Throwable)(t$117003)));
            }
        }
    }
    
    
    //#line 26 "x10/compiler/ws/FinishFrame.x10"
    final public x10.compiler.ws.FinishFrame x10$compiler$ws$FinishFrame$$this$x10$compiler$ws$FinishFrame() {
        
        //#line 26 "x10/compiler/ws/FinishFrame.x10"
        return x10.compiler.ws.FinishFrame.this;
    }
    
    
    //#line 26 "x10/compiler/ws/FinishFrame.x10"
    final public void __fieldInitializers_x10_compiler_ws_FinishFrame() {
        
    }
}

