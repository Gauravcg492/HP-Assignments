package x10.compiler.ws;


@x10.runtime.impl.java.X10Generated
abstract public class RegularFrame extends x10.compiler.ws.Frame implements x10.serialization.X10JavaSerializable
{
    public static final x10.rtt.RuntimeType<RegularFrame> $RTT = 
        x10.rtt.NamedType.<RegularFrame> make("x10.compiler.ws.RegularFrame",
                                              RegularFrame.class,
                                              new x10.rtt.Type[] {
                                                  x10.compiler.ws.Frame.$RTT
                                              });
    
    public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
    
    public x10.rtt.Type<?> $getParam(int i) { return null; }
    
    public static x10.serialization.X10JavaSerializable $_deserialize_body(x10.compiler.ws.RegularFrame $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
        x10.compiler.ws.Frame.$_deserialize_body($_obj, $deserializer);
        $_obj.ff = $deserializer.readObject();
        return $_obj;
    }
    
    public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
        return null;
    }
    
    public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
        super.$_serialize($serializer);
        $serializer.write(this.ff);
        
    }
    
    // constructor just for allocation
    public RegularFrame(final java.lang.System[] $dummy) {
        super($dummy);
        
    }
    
    

    
    //#line 24 "x10/compiler/ws/RegularFrame.x10"
    public x10.compiler.ws.FinishFrame ff;
    
    
    //#line 26 "x10/compiler/ws/RegularFrame.x10"
    
    // constructor for non-virtual call
    final public x10.compiler.ws.RegularFrame x10$compiler$ws$RegularFrame$$init$S(final x10.compiler.ws.Frame up, final x10.compiler.ws.FinishFrame ff) {
         {
            
            //#line 27 "x10/compiler/ws/RegularFrame.x10"
            final x10.compiler.ws.Frame this$117015 = this;
            
            //#line 31 . "x10/compiler/ws/Frame.x10"
            this$117015.up = ((x10.compiler.ws.Frame)(up));
            
            //#line 26 "x10/compiler/ws/RegularFrame.x10"
            
            
            //#line 28 "x10/compiler/ws/RegularFrame.x10"
            this.ff = ((x10.compiler.ws.FinishFrame)(ff));
        }
        return this;
    }
    
    
    
    //#line 40 "x10/compiler/ws/RegularFrame.x10"
    final public void push(final x10.compiler.ws.Worker worker) {
        
        //#line 41 "x10/compiler/ws/RegularFrame.x10"
        final x10.core.Deque t$117022 = ((x10.core.Deque)(worker.deque));
        
        //#line 41 "x10/compiler/ws/RegularFrame.x10"
        t$117022.push(((java.lang.Object)(this)));
    }
    
    
    //#line 44 "x10/compiler/ws/RegularFrame.x10"
    final public void continueLater(final x10.compiler.ws.Worker worker) {
        
        //#line 45 "x10/compiler/ws/RegularFrame.x10"
        worker.migrate();
        
        //#line 46 "x10/compiler/ws/RegularFrame.x10"
        x10.compiler.ws.RegularFrame k = this;
        
        //#line 50 "x10/compiler/ws/RegularFrame.x10"
        final java.lang.Object k$117020 = ((java.lang.Object)(((java.lang.Object)
                                                                k)));
        
        //#line 307 . "x10/xrx/Runtime.x10"
        final x10.xrx.Pool t$117031 = ((x10.xrx.Pool)(x10.xrx.Runtime.get$pool()));
        
        //#line 307 . "x10/xrx/Runtime.x10"
        final x10.core.Deque t$117032 = ((x10.core.Deque)(t$117031.wsBlockedContinuations));
        
        //#line 307 . "x10/xrx/Runtime.x10"
        t$117032.push(((java.lang.Object)(k$117020)));
        
        //#line 51 "x10/compiler/ws/RegularFrame.x10"
        final x10.compiler.Abort t$117026 = ((x10.compiler.Abort)(x10.compiler.Abort.get$ABORT()));
        
        //#line 51 "x10/compiler/ws/RegularFrame.x10"
        throw t$117026;
    }
    
    
    //#line 54 "x10/compiler/ws/RegularFrame.x10"
    final public void continueNow(final x10.compiler.ws.Worker worker) {
        
        //#line 55 "x10/compiler/ws/RegularFrame.x10"
        worker.migrate();
        
        //#line 56 "x10/compiler/ws/RegularFrame.x10"
        x10.compiler.ws.RegularFrame k = this;
        
        //#line 60 "x10/compiler/ws/RegularFrame.x10"
        final x10.core.Deque t$117027 = ((x10.core.Deque)(worker.fifo));
        
        //#line 60 "x10/compiler/ws/RegularFrame.x10"
        t$117027.push(((java.lang.Object)(k)));
        
        //#line 61 "x10/compiler/ws/RegularFrame.x10"
        final x10.compiler.Abort t$117029 = ((x10.compiler.Abort)(x10.compiler.Abort.get$ABORT()));
        
        //#line 61 "x10/compiler/ws/RegularFrame.x10"
        throw t$117029;
    }
    
    
    //#line 23 "x10/compiler/ws/RegularFrame.x10"
    final public x10.compiler.ws.RegularFrame x10$compiler$ws$RegularFrame$$this$x10$compiler$ws$RegularFrame() {
        
        //#line 23 "x10/compiler/ws/RegularFrame.x10"
        return x10.compiler.ws.RegularFrame.this;
    }
    
    
    //#line 23 "x10/compiler/ws/RegularFrame.x10"
    final public void __fieldInitializers_x10_compiler_ws_RegularFrame() {
        
    }
}

