package x10.compiler;


/**
 * This annotation on a transient field tells the compiler not to generate an 
 * error if the field does not have a default value.
 */
@x10.runtime.impl.java.X10Generated
public interface SuppressTransientError extends x10.lang.annotations.FieldAnnotation, x10.serialization.X10JavaSerializable
{
    public static final x10.rtt.RuntimeType<SuppressTransientError> $RTT = 
        x10.rtt.NamedType.<SuppressTransientError> make("x10.compiler.SuppressTransientError",
                                                        SuppressTransientError.class,
                                                        new x10.rtt.Type[] {
                                                            x10.lang.annotations.FieldAnnotation.$RTT
                                                        });
    
    
}

