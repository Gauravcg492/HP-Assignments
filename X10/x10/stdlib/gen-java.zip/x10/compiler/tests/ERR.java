package x10.compiler.tests;


/**
 * @ERR marks a compiler error on the line where the @ERR marker is written.
 */
@x10.runtime.impl.java.X10Generated
public interface ERR extends x10.lang.annotations.MethodAnnotation, x10.lang.annotations.ClassAnnotation, x10.lang.annotations.FieldAnnotation, x10.lang.annotations.ImportAnnotation, x10.lang.annotations.PackageAnnotation, x10.lang.annotations.TypeAnnotation, x10.lang.annotations.ExpressionAnnotation, x10.lang.annotations.StatementAnnotation, x10.serialization.X10JavaSerializable
{
    public static final x10.rtt.RuntimeType<ERR> $RTT = 
        x10.rtt.NamedType.<ERR> make("x10.compiler.tests.ERR",
                                     ERR.class,
                                     new x10.rtt.Type[] {
                                         x10.lang.annotations.MethodAnnotation.$RTT,
                                         x10.lang.annotations.ClassAnnotation.$RTT,
                                         x10.lang.annotations.FieldAnnotation.$RTT,
                                         x10.lang.annotations.ImportAnnotation.$RTT,
                                         x10.lang.annotations.PackageAnnotation.$RTT,
                                         x10.lang.annotations.TypeAnnotation.$RTT,
                                         x10.lang.annotations.ExpressionAnnotation.$RTT,
                                         x10.lang.annotations.StatementAnnotation.$RTT
                                     });
    
    
}

