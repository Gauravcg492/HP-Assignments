package x10.compiler.tests;


/**
 * @ShouldBeErr marks that a compiler should report an error on that line.
 */
@x10.runtime.impl.java.X10Generated
public interface ShouldBeErr extends x10.lang.annotations.MethodAnnotation, x10.lang.annotations.ClassAnnotation, x10.lang.annotations.FieldAnnotation, x10.lang.annotations.ImportAnnotation, x10.lang.annotations.PackageAnnotation, x10.lang.annotations.TypeAnnotation, x10.lang.annotations.ExpressionAnnotation, x10.lang.annotations.StatementAnnotation, x10.serialization.X10JavaSerializable
{
    public static final x10.rtt.RuntimeType<ShouldBeErr> $RTT = 
        x10.rtt.NamedType.<ShouldBeErr> make("x10.compiler.tests.ShouldBeErr",
                                             ShouldBeErr.class,
                                             new x10.rtt.Type[] {
                                                 x10.lang.annotations.MethodAnnotation.$RTT,
                                                 x10.lang.annotations.ClassAnnotation.$RTT,
                                                 x10.lang.annotations.FieldAnnotation.$RTT,
                                                 x10.lang.annotations.ImportAnnotation.$RTT,
                                                 x10.lang.annotations.PackageAnnotation.$RTT,
                                                 x10.lang.annotations.TypeAnnotation.$RTT,
                                                 x10.lang.annotations.ExpressionAnnotation.$RTT,
                                                 x10.lang.annotations.StatementAnnotation.$RTT
                                             });
    
    
}

