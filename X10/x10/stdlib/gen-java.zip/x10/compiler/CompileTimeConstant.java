package x10.compiler;


/**
 * Annotation to allow the compiler front-end access to command-line constants.
 * 
 * option: the name of a static field in x10.Configuration, possibly prepended by "!".
 * 
 * The Inliner will replace a call to such a method with a Lit node representing the value of the option
 * (negated, if the name is preceded by "!" and the type is boolean or Boolean).
 */
@x10.runtime.impl.java.X10Generated
public interface CompileTimeConstant extends x10.lang.annotations.MethodAnnotation, x10.serialization.X10JavaSerializable
{
    public static final x10.rtt.RuntimeType<CompileTimeConstant> $RTT = 
        x10.rtt.NamedType.<CompileTimeConstant> make("x10.compiler.CompileTimeConstant",
                                                     CompileTimeConstant.class,
                                                     new x10.rtt.Type[] {
                                                         x10.lang.annotations.MethodAnnotation.$RTT
                                                     });
    
    
}

