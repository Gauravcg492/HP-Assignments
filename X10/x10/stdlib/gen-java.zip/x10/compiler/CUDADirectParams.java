package x10.compiler;


/**
 * An annotation that instructs the CUDA backend to use conventional CUDA
 * kernel parameters to pass the capture enviornment, instead of DMA'ing a
 * structure to the GPU and passing a pointer to this structure.
 */
@x10.runtime.impl.java.X10Generated
public interface CUDADirectParams extends x10.lang.annotations.StatementAnnotation, x10.serialization.X10JavaSerializable
{
    public static final x10.rtt.RuntimeType<CUDADirectParams> $RTT = 
        x10.rtt.NamedType.<CUDADirectParams> make("x10.compiler.CUDADirectParams",
                                                  CUDADirectParams.class,
                                                  new x10.rtt.Type[] {
                                                      x10.lang.annotations.StatementAnnotation.$RTT
                                                  });
    
    
}

