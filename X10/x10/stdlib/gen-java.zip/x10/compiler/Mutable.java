package x10.compiler;


/** An annotation on a struct that enables mutable fields
 * EXPERIMENTAL
 */
@x10.runtime.impl.java.X10Generated
public interface Mutable extends x10.lang.annotations.ClassAnnotation, x10.serialization.X10JavaSerializable
{
    public static final x10.rtt.RuntimeType<Mutable> $RTT = 
        x10.rtt.NamedType.<Mutable> make("x10.compiler.Mutable",
                                         Mutable.class,
                                         new x10.rtt.Type[] {
                                             x10.lang.annotations.ClassAnnotation.$RTT
                                         });
    
    
}

