package x10.compiler;


/**
 * A single-place lazy-initialised worker-local store.
 * On first access by a particular worker thread, a worker-local instance
 * of type T is created using the provided init operation.
 */
@x10.runtime.impl.java.X10Generated
final public class WorkerLocal<$T> extends x10.core.Ref implements x10.core.fun.Fun_0_0, x10.core.fun.VoidFun_0_1, x10.serialization.X10JavaSerializable
{
    public static final x10.rtt.RuntimeType<WorkerLocal> $RTT = 
        x10.rtt.NamedType.<WorkerLocal> make("x10.compiler.WorkerLocal",
                                             WorkerLocal.class,
                                             1,
                                             new x10.rtt.Type[] {
                                                 x10.rtt.ParameterizedType.make(x10.core.fun.Fun_0_0.$RTT, x10.rtt.UnresolvedType.PARAM(0)),
                                                 x10.rtt.ParameterizedType.make(x10.core.fun.VoidFun_0_1.$RTT, x10.rtt.UnresolvedType.PARAM(0))
                                             });
    
    public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
    
    public x10.rtt.Type<?> $getParam(int i) { if (i == 0) return $T; return null; }
    
    private Object writeReplace() throws java.io.ObjectStreamException {
        return new x10.serialization.SerializationProxy(this);
    }
    
    public static <$T> x10.serialization.X10JavaSerializable $_deserialize_body(x10.compiler.WorkerLocal<$T> $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
        $_obj.$T = (x10.rtt.Type) $deserializer.readObject();
        $_obj.init = $deserializer.readObject();
        return $_obj;
    }
    
    public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
        x10.compiler.WorkerLocal $_obj = new x10.compiler.WorkerLocal((java.lang.System[]) null, (x10.rtt.Type) null);
        $deserializer.record_reference($_obj);
        return $_deserialize_body($_obj, $deserializer);
    }
    
    public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
        $serializer.write(this.$T);
        $serializer.write(this.init);
        
    }
    
    // constructor just for allocation
    public WorkerLocal(final java.lang.System[] $dummy, final x10.rtt.Type $T) {
        x10.compiler.WorkerLocal.$initParams(this, $T);
        
    }
    
    // dispatcher for method abstract public (Z1)=>void.operator()(a1:Z1){}:void
    public java.lang.Object $apply(final java.lang.Object a1, final x10.rtt.Type t1) {
        $apply__0x10$compiler$WorkerLocal$$T(($T)a1); return null;
        
    }
    
    // dispatcher for method abstract public (Z1)=>void.operator()(a1:Z1){}:void
    public void $apply$V(final java.lang.Object a1, final x10.rtt.Type t1) {
        $apply__0x10$compiler$WorkerLocal$$T(($T)a1);
        
    }
    
    private x10.rtt.Type $T;
    
    // initializer of type parameters
    public static void $initParams(final WorkerLocal $this, final x10.rtt.Type $T) {
        $this.$T = $T;
        
    }
    // synthetic type for parameter mangling
    public static final class __0$1x10$compiler$WorkerLocal$$T$2 {}
    

    
    //#line 23 "x10/compiler/WorkerLocal.x10"
    public transient x10.core.Rail<$T> store;
    
    //#line 24 "x10/compiler/WorkerLocal.x10"
    public x10.core.fun.Fun_0_0<$T> init;
    
    
    //#line 26 "x10/compiler/WorkerLocal.x10"
    // creation method for java code (1-phase java constructor)
    public WorkerLocal(final x10.rtt.Type $T, final x10.core.fun.Fun_0_0<$T> init, __0$1x10$compiler$WorkerLocal$$T$2 $dummy) {
        this((java.lang.System[]) null, $T);
        x10$compiler$WorkerLocal$$init$S(init, (x10.compiler.WorkerLocal.__0$1x10$compiler$WorkerLocal$$T$2) null);
    }
    
    // constructor for non-virtual call
    final public x10.compiler.WorkerLocal<$T> x10$compiler$WorkerLocal$$init$S(final x10.core.fun.Fun_0_0<$T> init, __0$1x10$compiler$WorkerLocal$$T$2 $dummy) {
         {
            
            //#line 26 "x10/compiler/WorkerLocal.x10"
            
            
            //#line 22 "x10/compiler/WorkerLocal.x10"
            final x10.compiler.WorkerLocal this$115460 = this;
            
            //#line 22 "x10/compiler/WorkerLocal.x10"
            ((x10.compiler.WorkerLocal<$T>)this$115460).init = null;
            
            //#line 27 "x10/compiler/WorkerLocal.x10"
            final int t$115400 = x10.xrx.Runtime.get$MAX_THREADS();
            
            //#line 27 "x10/compiler/WorkerLocal.x10"
            final long t$115401 = ((long)(((int)(t$115400))));
            
            //#line 27 "x10/compiler/WorkerLocal.x10"
            final x10.core.Rail t$115402 = ((x10.core.Rail)(new x10.core.Rail<$T>($T, t$115401)));
            
            //#line 27 "x10/compiler/WorkerLocal.x10"
            ((x10.compiler.WorkerLocal<$T>)this).store = ((x10.core.Rail)(t$115402));
            
            //#line 28 "x10/compiler/WorkerLocal.x10"
            ((x10.compiler.WorkerLocal<$T>)this).init = ((x10.core.fun.Fun_0_0)(init));
        }
        return this;
    }
    
    
    
    //#line 31 "x10/compiler/WorkerLocal.x10"
    public $T $apply$G() {
        
        //#line 32 "x10/compiler/WorkerLocal.x10"
        final x10.core.Rail t$115406 = ((x10.core.Rail)(this.store));
        
        //#line 331 .. "x10/xrx/Runtime.x10"
        final x10.core.Thread t$115403 = x10.core.Thread.currentThread();
        
        //#line 331 .. "x10/xrx/Runtime.x10"
        final x10.xrx.Worker t$115404 = x10.rtt.Types.<x10.xrx.Worker> cast(t$115403,x10.xrx.Worker.$RTT);
        
        //#line 336 . "x10/xrx/Runtime.x10"
        final int t$115405 = t$115404.workerId;
        
        //#line 32 "x10/compiler/WorkerLocal.x10"
        final long t$115407 = ((long)(((int)(t$115405))));
        
        //#line 32 "x10/compiler/WorkerLocal.x10"
        $T t = (($T)(((x10.core.Rail<$T>)t$115406).$apply$G((long)(t$115407))));
        
        //#line 33 "x10/compiler/WorkerLocal.x10"
        final boolean t$115417 = ((t) == (null));
        
        //#line 33 "x10/compiler/WorkerLocal.x10"
        if (t$115417) {
            
            //#line 34 "x10/compiler/WorkerLocal.x10"
            final x10.core.fun.Fun_0_0 t$115409 = ((x10.core.fun.Fun_0_0)(this.init));
            
            //#line 34 "x10/compiler/WorkerLocal.x10"
            final $T t$115410 = (($T)(((x10.core.fun.Fun_0_0<$T>)t$115409).$apply$G()));
            
            //#line 34 "x10/compiler/WorkerLocal.x10"
            t = (($T)(t$115410));
            
            //#line 35 "x10/compiler/WorkerLocal.x10"
            final x10.core.Rail t$115414 = ((x10.core.Rail)(this.store));
            
            //#line 331 .. "x10/xrx/Runtime.x10"
            final x10.core.Thread t$115411 = x10.core.Thread.currentThread();
            
            //#line 331 .. "x10/xrx/Runtime.x10"
            final x10.xrx.Worker t$115412 = x10.rtt.Types.<x10.xrx.Worker> cast(t$115411,x10.xrx.Worker.$RTT);
            
            //#line 336 . "x10/xrx/Runtime.x10"
            final int t$115413 = t$115412.workerId;
            
            //#line 35 "x10/compiler/WorkerLocal.x10"
            final long t$115415 = ((long)(((int)(t$115413))));
            
            //#line 35 "x10/compiler/WorkerLocal.x10"
            ((x10.core.Rail<$T>)t$115414).$set__1x10$lang$Rail$$T$G((long)(t$115415), (($T)(t)));
        }
        
        //#line 37 "x10/compiler/WorkerLocal.x10"
        return t;
    }
    
    
    //#line 40 "x10/compiler/WorkerLocal.x10"
    public void $apply__0x10$compiler$WorkerLocal$$T(final $T t) {
        
        //#line 41 "x10/compiler/WorkerLocal.x10"
        final x10.core.Rail t$115422 = ((x10.core.Rail)(this.store));
        
        //#line 331 .. "x10/xrx/Runtime.x10"
        final x10.core.Thread t$115419 = x10.core.Thread.currentThread();
        
        //#line 331 .. "x10/xrx/Runtime.x10"
        final x10.xrx.Worker t$115420 = x10.rtt.Types.<x10.xrx.Worker> cast(t$115419,x10.xrx.Worker.$RTT);
        
        //#line 336 . "x10/xrx/Runtime.x10"
        final int t$115421 = t$115420.workerId;
        
        //#line 41 "x10/compiler/WorkerLocal.x10"
        final long t$115423 = ((long)(((int)(t$115421))));
        
        //#line 41 "x10/compiler/WorkerLocal.x10"
        ((x10.core.Rail<$T>)t$115422).$set__1x10$lang$Rail$$T$G((long)(t$115423), (($T)(t)));
    }
    
    
    //#line 48 "x10/compiler/WorkerLocal.x10"
    /**
     * Set the init operation for this worker local handle, and clear all
     * current values.
     */
    public void resetAll__0$1x10$compiler$WorkerLocal$$T$2(final x10.core.fun.Fun_0_0 init) {
        
        //#line 49 "x10/compiler/WorkerLocal.x10"
        final x10.core.Rail t$115424 = ((x10.core.Rail)(this.store));
        
        //#line 49 "x10/compiler/WorkerLocal.x10"
        ((x10.core.Rail<$T>)t$115424).clear();
        
        //#line 50 "x10/compiler/WorkerLocal.x10"
        ((x10.compiler.WorkerLocal<$T>)this).init = ((x10.core.fun.Fun_0_0)(init));
    }
    
    
    //#line 56 "x10/compiler/WorkerLocal.x10"
    /** 
     * Apply the given operation in parallel to each thread local value.
     */
    public void applyToAll__0$1x10$compiler$WorkerLocal$$T$2(final x10.core.fun.VoidFun_0_1 op) {
        {
            
            //#line 57 "x10/compiler/WorkerLocal.x10"
            x10.xrx.Runtime.ensureNotInAtomic();
            
            //#line 57 "x10/compiler/WorkerLocal.x10"
            final x10.xrx.FinishState fs$115504 = x10.xrx.Runtime.startFinish();
            
            //#line 57 "x10/compiler/WorkerLocal.x10"
            try {{
                {
                    
                    //#line 57 "x10/compiler/WorkerLocal.x10"
                    final x10.core.Rail t$115425 = ((x10.core.Rail)(this.store));
                    
                    //#line 57 "x10/compiler/WorkerLocal.x10"
                    final long t$115426 = ((x10.core.Rail<$T>)t$115425).size;
                    
                    //#line 57 "x10/compiler/WorkerLocal.x10"
                    final long i$114082max$114084 = ((t$115426) - (((long)(1L))));
                    
                    //#line 57 "x10/compiler/WorkerLocal.x10"
                    long i$115467 = 0L;
                    
                    //#line 57 "x10/compiler/WorkerLocal.x10"
                    for (;
                         true;
                         ) {
                        
                        //#line 57 "x10/compiler/WorkerLocal.x10"
                        final boolean t$115469 = ((i$115467) <= (((long)(i$114082max$114084))));
                        
                        //#line 57 "x10/compiler/WorkerLocal.x10"
                        if (!(t$115469)) {
                            
                            //#line 57 "x10/compiler/WorkerLocal.x10"
                            break;
                        }
                        
                        //#line 58 "x10/compiler/WorkerLocal.x10"
                        final x10.core.Rail t$115461 = ((x10.core.Rail)(this.store));
                        
                        //#line 58 "x10/compiler/WorkerLocal.x10"
                        final $T t$115462 = (($T)(((x10.core.Rail<$T>)t$115461).$apply$G((long)(i$115467))));
                        
                        //#line 59 "x10/compiler/WorkerLocal.x10"
                        final boolean t$115463 = ((t$115462) != (null));
                        
                        //#line 59 "x10/compiler/WorkerLocal.x10"
                        if (t$115463) {
                            
                            //#line 60 "x10/compiler/WorkerLocal.x10"
                            x10.xrx.Runtime.runAsync(((x10.core.fun.VoidFun_0_0)(new x10.compiler.WorkerLocal.$Closure$48<$T>($T, op, t$115462, (x10.compiler.WorkerLocal.$Closure$48.__0$1x10$compiler$WorkerLocal$$Closure$48$$T$2__1x10$compiler$WorkerLocal$$Closure$48$$T) null))));
                        }
                        
                        //#line 57 "x10/compiler/WorkerLocal.x10"
                        final long t$115466 = ((i$115467) + (((long)(1L))));
                        
                        //#line 57 "x10/compiler/WorkerLocal.x10"
                        i$115467 = t$115466;
                    }
                }
            }}catch (java.lang.Throwable ct$115502) {
                
                //#line 57 "x10/compiler/WorkerLocal.x10"
                x10.xrx.Runtime.pushException(((java.lang.Throwable)(ct$115502)));
                
                //#line 57 "x10/compiler/WorkerLocal.x10"
                throw new java.lang.RuntimeException();
            }finally {{
                 
                 //#line 57 "x10/compiler/WorkerLocal.x10"
                 x10.xrx.Runtime.stopFinish(((x10.xrx.FinishState)(fs$115504)));
             }}
            }
        
        //#line 63 "x10/compiler/WorkerLocal.x10"
        return;
        }
    
    
    //#line 69 "x10/compiler/WorkerLocal.x10"
    /** 
     * Reduce partial results from each thread and return combined result.
     */
    public $T reduce__0$1x10$compiler$WorkerLocal$$T$3x10$compiler$WorkerLocal$$T$3x10$compiler$WorkerLocal$$T$2$G(final x10.core.fun.Fun_0_2 op) {
        
        //#line 70 "x10/compiler/WorkerLocal.x10"
        $T result = null;
        
        //#line 71 "x10/compiler/WorkerLocal.x10"
        final x10.core.Rail t$115483 = ((x10.core.Rail)(this.store));
        
        //#line 71 "x10/compiler/WorkerLocal.x10"
        final long t$115484 = ((x10.core.Rail<$T>)t$115483).size;
        
        //#line 71 "x10/compiler/WorkerLocal.x10"
        final long i$114100max$115485 = ((t$115484) - (((long)(1L))));
        
        //#line 71 "x10/compiler/WorkerLocal.x10"
        long i$115480 = 0L;
        
        //#line 71 "x10/compiler/WorkerLocal.x10"
        for (;
             true;
             ) {
            
            //#line 71 "x10/compiler/WorkerLocal.x10"
            final boolean t$115482 = ((i$115480) <= (((long)(i$114100max$115485))));
            
            //#line 71 "x10/compiler/WorkerLocal.x10"
            if (!(t$115482)) {
                
                //#line 71 "x10/compiler/WorkerLocal.x10"
                break;
            }
            
            //#line 72 "x10/compiler/WorkerLocal.x10"
            final x10.core.Rail t$115470 = ((x10.core.Rail)(this.store));
            
            //#line 72 "x10/compiler/WorkerLocal.x10"
            final $T t$115471 = (($T)(((x10.core.Rail<$T>)t$115470).$apply$G((long)(i$115480))));
            
            //#line 73 "x10/compiler/WorkerLocal.x10"
            final boolean t$115472 = ((t$115471) != (null));
            
            //#line 73 "x10/compiler/WorkerLocal.x10"
            if (t$115472) {
                
                //#line 74 "x10/compiler/WorkerLocal.x10"
                final boolean t$115474 = ((result) == (null));
                
                //#line 74 "x10/compiler/WorkerLocal.x10"
                if (t$115474) {
                    
                    //#line 74 "x10/compiler/WorkerLocal.x10"
                    result = (($T)(t$115471));
                } else {
                    
                    //#line 75 "x10/compiler/WorkerLocal.x10"
                    final $T t$115476 = (($T)((($T)
                                                ((x10.core.fun.Fun_0_2<$T,$T,$T>)op).$apply(result, $T, t$115471, $T))));
                    
                    //#line 75 "x10/compiler/WorkerLocal.x10"
                    result = (($T)(t$115476));
                }
            }
            
            //#line 71 "x10/compiler/WorkerLocal.x10"
            final long t$115479 = ((i$115480) + (((long)(1L))));
            
            //#line 71 "x10/compiler/WorkerLocal.x10"
            i$115480 = t$115479;
        }
        
        //#line 78 "x10/compiler/WorkerLocal.x10"
        return result;
    }
    
    
    //#line 90 "x10/compiler/WorkerLocal.x10"
    /** 
     * Reduce partial results from each thread using the given 'result' as
     * the initial value.  
     * This can be used e.g. to sum a Rail[Double] 'in place' as follows:
     * result_worker.reduceLocal( result, 
     *   (a:Rail[Double],b:Rail[Double]) => 
     *      { a.map(result, b, (x:Double,y:Double)=>(x+y) ) as Rail[Double] }
     *   );
     */
    public $T reduce__0x10$compiler$WorkerLocal$$T__1$1x10$compiler$WorkerLocal$$T$3x10$compiler$WorkerLocal$$T$3x10$compiler$WorkerLocal$$T$2$G($T result, final x10.core.fun.Fun_0_2 op) {
        
        //#line 91 "x10/compiler/WorkerLocal.x10"
        final x10.core.Rail t$115497 = ((x10.core.Rail)(this.store));
        
        //#line 91 "x10/compiler/WorkerLocal.x10"
        final long t$115498 = ((x10.core.Rail<$T>)t$115497).size;
        
        //#line 91 "x10/compiler/WorkerLocal.x10"
        final long i$114118max$115499 = ((t$115498) - (((long)(1L))));
        
        //#line 91 "x10/compiler/WorkerLocal.x10"
        long i$115494 = 0L;
        
        //#line 91 "x10/compiler/WorkerLocal.x10"
        for (;
             true;
             ) {
            
            //#line 91 "x10/compiler/WorkerLocal.x10"
            final boolean t$115496 = ((i$115494) <= (((long)(i$114118max$115499))));
            
            //#line 91 "x10/compiler/WorkerLocal.x10"
            if (!(t$115496)) {
                
                //#line 91 "x10/compiler/WorkerLocal.x10"
                break;
            }
            
            //#line 92 "x10/compiler/WorkerLocal.x10"
            final x10.core.Rail t$115486 = ((x10.core.Rail)(this.store));
            
            //#line 92 "x10/compiler/WorkerLocal.x10"
            final $T t$115487 = (($T)(((x10.core.Rail<$T>)t$115486).$apply$G((long)(i$115494))));
            
            //#line 93 "x10/compiler/WorkerLocal.x10"
            final boolean t$115488 = ((t$115487) != (null));
            
            //#line 93 "x10/compiler/WorkerLocal.x10"
            if (t$115488) {
                
                //#line 94 "x10/compiler/WorkerLocal.x10"
                final $T t$115490 = (($T)((($T)
                                            ((x10.core.fun.Fun_0_2<$T,$T,$T>)op).$apply(result, $T, t$115487, $T))));
                
                //#line 94 "x10/compiler/WorkerLocal.x10"
                result = (($T)(t$115490));
            }
            
            //#line 91 "x10/compiler/WorkerLocal.x10"
            final long t$115493 = ((i$115494) + (((long)(1L))));
            
            //#line 91 "x10/compiler/WorkerLocal.x10"
            i$115494 = t$115493;
        }
        
        //#line 97 "x10/compiler/WorkerLocal.x10"
        return result;
    }
    
    
    //#line 22 "x10/compiler/WorkerLocal.x10"
    final public x10.compiler.WorkerLocal x10$compiler$WorkerLocal$$this$x10$compiler$WorkerLocal() {
        
        //#line 22 "x10/compiler/WorkerLocal.x10"
        return x10.compiler.WorkerLocal.this;
    }
    
    
    //#line 22 "x10/compiler/WorkerLocal.x10"
    final public void __fieldInitializers_x10_compiler_WorkerLocal() {
        
        //#line 22 "x10/compiler/WorkerLocal.x10"
        ((x10.compiler.WorkerLocal<$T>)this).init = null;
    }
    
    @x10.runtime.impl.java.X10Generated
    final public static class $Closure$48<$T> extends x10.core.Ref implements x10.core.fun.VoidFun_0_0, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<$Closure$48> $RTT = 
            x10.rtt.StaticVoidFunType.<$Closure$48> make($Closure$48.class,
                                                         1,
                                                         new x10.rtt.Type[] {
                                                             x10.core.fun.VoidFun_0_0.$RTT
                                                         });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { if (i == 0) return $T; return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static <$T> x10.serialization.X10JavaSerializable $_deserialize_body(x10.compiler.WorkerLocal.$Closure$48<$T> $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            $_obj.$T = (x10.rtt.Type) $deserializer.readObject();
            $_obj.op = $deserializer.readObject();
            $_obj.t$115462 = $deserializer.readObject();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.compiler.WorkerLocal.$Closure$48 $_obj = new x10.compiler.WorkerLocal.$Closure$48((java.lang.System[]) null, (x10.rtt.Type) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            $serializer.write(this.$T);
            $serializer.write(this.op);
            $serializer.write(this.t$115462);
            
        }
        
        // constructor just for allocation
        public $Closure$48(final java.lang.System[] $dummy, final x10.rtt.Type $T) {
            x10.compiler.WorkerLocal.$Closure$48.$initParams(this, $T);
            
        }
        
        private x10.rtt.Type $T;
        
        // initializer of type parameters
        public static void $initParams(final $Closure$48 $this, final x10.rtt.Type $T) {
            $this.$T = $T;
            
        }
        // synthetic type for parameter mangling
        public static final class __0$1x10$compiler$WorkerLocal$$Closure$48$$T$2__1x10$compiler$WorkerLocal$$Closure$48$$T {}
        
    
        
        public void $apply() {
            
            //#line 60 "x10/compiler/WorkerLocal.x10"
            try {{
                
                //#line 60 "x10/compiler/WorkerLocal.x10"
                ((x10.core.fun.VoidFun_0_1<$T>)this.op).$apply(this.t$115462, $T);
            }}catch (java.lang.Error __lowerer__var__0__) {
                
                //#line 60 "x10/compiler/WorkerLocal.x10"
                throw __lowerer__var__0__;
            }catch (java.lang.Throwable __lowerer__var__1__) {
                
                //#line 60 "x10/compiler/WorkerLocal.x10"
                throw x10.rtt.Types.EXCEPTION.isInstance(__lowerer__var__1__) ? (java.lang.RuntimeException)(__lowerer__var__1__) : new x10.lang.WrappedThrowable(__lowerer__var__1__);
            }
        }
        
        public x10.core.fun.VoidFun_0_1<$T> op;
        public $T t$115462;
        
        public $Closure$48(final x10.rtt.Type $T, final x10.core.fun.VoidFun_0_1<$T> op, final $T t$115462, __0$1x10$compiler$WorkerLocal$$Closure$48$$T$2__1x10$compiler$WorkerLocal$$Closure$48$$T $dummy) {
            x10.compiler.WorkerLocal.$Closure$48.$initParams(this, $T);
             {
                ((x10.compiler.WorkerLocal.$Closure$48<$T>)this).op = ((x10.core.fun.VoidFun_0_1)(op));
                ((x10.compiler.WorkerLocal.$Closure$48<$T>)this).t$115462 = (($T)(t$115462));
            }
        }
        
    }
    
    }
    
    