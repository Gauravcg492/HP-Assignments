package x10.compiler;


/** 
 * An annotation that requests the compiler to stack allocate an object
 * must be used *exactly* as the following for now:
 * <pre>
 *   @StackAllocate val v = @StackAllocateUninitialized new T(...);
 * </pre>
 * This annotation causes the compiler to elide the call to the
 * constructor on the stack allocated storage.  Therefore, the 
 * storage will be uninitialized.
 *
 * The intended use is demonstrated in the KMeans benchmark,
 * where uninitialized stack allocated Rails are used to 
 * express a hand-unrolled loop.
 */
@x10.runtime.impl.java.X10Generated
public interface StackAllocateUninitialized extends x10.lang.annotations.ExpressionAnnotation, x10.serialization.X10JavaSerializable
{
    public static final x10.rtt.RuntimeType<StackAllocateUninitialized> $RTT = 
        x10.rtt.NamedType.<StackAllocateUninitialized> make("x10.compiler.StackAllocateUninitialized",
                                                            StackAllocateUninitialized.class,
                                                            new x10.rtt.Type[] {
                                                                x10.lang.annotations.ExpressionAnnotation.$RTT
                                                            });
    
    
}

