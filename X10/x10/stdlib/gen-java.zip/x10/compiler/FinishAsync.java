package x10.compiler;


@x10.runtime.impl.java.X10Generated
public interface FinishAsync extends x10.lang.annotations.StatementAnnotation, x10.serialization.X10JavaSerializable
{
    public static final x10.rtt.RuntimeType<FinishAsync> $RTT = 
        x10.rtt.NamedType.<FinishAsync> make("x10.compiler.FinishAsync",
                                             FinishAsync.class,
                                             new x10.rtt.Type[] {
                                                 x10.lang.annotations.StatementAnnotation.$RTT
                                             });
    
    
}

