package x10.compiler;

/**
 * A restricted form of an Uncounted async whose body
 * is not allowed to perform blocking operations. 
 * Therefore the body must not contain finish, at, or when.
 *
 * The runtime provides stronger progress guarantees for 
 * remote asyncs annotated as Immediate.  In particular the 
 * Runtime at each Place will always maintain at least one
 * worker thread that can execute Immediate asyncs as they are
 * dequeued from the network.
 */
@x10.runtime.impl.java.X10Generated
public interface Immediate extends x10.compiler.Uncounted, x10.compiler.RemoteInvocation, x10.serialization.X10JavaSerializable
{
    public static final x10.rtt.RuntimeType<Immediate> $RTT = 
        x10.rtt.NamedType.<Immediate> make("x10.compiler.Immediate",
                                           Immediate.class,
                                           new x10.rtt.Type[] {
                                               x10.compiler.Uncounted.$RTT,
                                               x10.compiler.RemoteInvocation.$RTT
                                           });
    
    
}

