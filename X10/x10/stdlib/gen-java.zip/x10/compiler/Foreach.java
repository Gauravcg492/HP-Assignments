package x10.compiler;


/**
 * Parallel iteration over a set of indices using different patterns of
 * local activity creation; this is intended to be used by the compiler to
 * implement the <code>foreach</code> construct.
 * <p>
 * The <code>body</code> closure is executed for each value of the index, 
 * making use of available local parallelism. The iteration must be both 
 * <em>serializable</em> and <em>parallelizable</em>; in other words, it is 
 * correct to execute <code>body</code> for each index in sequence, and it is 
 * also correct to execute <code>body</code> in parallel for any subset of 
 * indices.</p>
 * <p>There is an implied <code>finish</code> i.e. all iterations must complete
 * before <code>foreach</code> is complete.</p>
 * <p>Restrictions:</p>
 * <ul>
 * <li>A conditional atomic statement (<code>when</code>) may not be included 
 * as it could introduce ordering dependencies. Unconditional <code>atomic</code>
 * may be included as it cannot create an ordering dependency.</li>
 * <li>Changing place with <code>at</code> is not recommended as it may introduce
 * arbitrary delays.</p>
 * </ul>
 */
@x10.runtime.impl.java.X10Generated
final public class Foreach extends x10.core.Ref implements x10.serialization.X10JavaSerializable
{
    public static final x10.rtt.RuntimeType<Foreach> $RTT = 
        x10.rtt.NamedType.<Foreach> make("x10.compiler.Foreach",
                                         Foreach.class);
    
    public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
    
    public x10.rtt.Type<?> $getParam(int i) { return null; }
    
    private Object writeReplace() throws java.io.ObjectStreamException {
        return new x10.serialization.SerializationProxy(this);
    }
    
    public static x10.serialization.X10JavaSerializable $_deserialize_body(x10.compiler.Foreach $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
        return $_obj;
    }
    
    public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
        x10.compiler.Foreach $_obj = new x10.compiler.Foreach((java.lang.System[]) null);
        $deserializer.record_reference($_obj);
        return $_deserialize_body($_obj, $deserializer);
    }
    
    public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
        
    }
    
    // constructor just for allocation
    public Foreach(final java.lang.System[] $dummy) {
        
    }
    
    

    
    
    //#line 50 "x10/compiler/Foreach.x10"
    /**
     * Iterate over a range of indices in sequence in a single activity.
     * This may be used for debugging purposes or as a compiler target where
     * there is no benefit to be gained from parallelizing an iteration.
     * @param min the minimum value of the index
     * @param max the maximum value of the index
     * @param body a closure that executes over a single value of the index
     */
    public static void sequential__2$1x10$lang$Long$2(final long min, final long max, final x10.core.fun.VoidFun_0_1<x10.core.Long> body) {
        
        //#line 52 "x10/compiler/Foreach.x10"
        long i$113115 = min;
        
        //#line 52 "x10/compiler/Foreach.x10"
        for (;
             true;
             ) {
            
            //#line 52 "x10/compiler/Foreach.x10"
            final boolean t$113117 = ((i$113115) <= (((long)(max))));
            
            //#line 52 "x10/compiler/Foreach.x10"
            if (!(t$113117)) {
                
                //#line 52 "x10/compiler/Foreach.x10"
                break;
            }
            
            //#line 52 "x10/compiler/Foreach.x10"
            ((x10.core.fun.VoidFun_0_1<x10.core.Long>)body).$apply(x10.core.Long.$box(i$113115), x10.rtt.Types.LONG);
            
            //#line 52 "x10/compiler/Foreach.x10"
            final long t$113114 = ((i$113115) + (((long)(1L))));
            
            //#line 52 "x10/compiler/Foreach.x10"
            i$113115 = t$113114;
        }
    }
    
    
    //#line 63 "x10/compiler/Foreach.x10"
    /**
     * Iterate over a range of indices in sequence in a single activity.
     * @param min0 the minimum value of the first index dimension
     * @param max0 the maximum value of the first index dimension
     * @param min1 the minimum value of the second index dimension
     * @param max1 the maximum value of the second index dimension
     * @param body a closure that executes over a single value of the index [i,j]
     */
    public static void sequential__4$1x10$lang$Long$3x10$lang$Long$2(final long min0, final long max0, final long min1, final long max1, final x10.core.fun.VoidFun_0_2<x10.core.Long,x10.core.Long> body) {
        
        //#line 66 "x10/compiler/Foreach.x10"
        long i$113129 = min0;
        
        //#line 66 "x10/compiler/Foreach.x10"
        for (;
             true;
             ) {
            
            //#line 66 "x10/compiler/Foreach.x10"
            final boolean t$113131 = ((i$113129) <= (((long)(max0))));
            
            //#line 66 "x10/compiler/Foreach.x10"
            if (!(t$113131)) {
                
                //#line 66 "x10/compiler/Foreach.x10"
                break;
            }
            
            //#line 67 "x10/compiler/Foreach.x10"
            long i$113121 = min1;
            
            //#line 67 "x10/compiler/Foreach.x10"
            for (;
                 true;
                 ) {
                
                //#line 67 "x10/compiler/Foreach.x10"
                final boolean t$113123 = ((i$113121) <= (((long)(max1))));
                
                //#line 67 "x10/compiler/Foreach.x10"
                if (!(t$113123)) {
                    
                    //#line 67 "x10/compiler/Foreach.x10"
                    break;
                }
                
                //#line 68 "x10/compiler/Foreach.x10"
                ((x10.core.fun.VoidFun_0_2<x10.core.Long,x10.core.Long>)body).$apply(x10.core.Long.$box(i$113129), x10.rtt.Types.LONG, x10.core.Long.$box(i$113121), x10.rtt.Types.LONG);
                
                //#line 67 "x10/compiler/Foreach.x10"
                final long t$113120 = ((i$113121) + (((long)(1L))));
                
                //#line 67 "x10/compiler/Foreach.x10"
                i$113121 = t$113120;
            }
            
            //#line 66 "x10/compiler/Foreach.x10"
            final long t$113128 = ((i$113129) + (((long)(1L))));
            
            //#line 66 "x10/compiler/Foreach.x10"
            i$113129 = t$113128;
        }
    }
    
    
    //#line 81 "x10/compiler/Foreach.x10"
    /**
     * Iterate over a range of indices in sequence in a single activity.
     * This may be used for debugging purposes or as a compiler target where
     * there is no benefit to be gained from parallelizing an iteration.
     * @param min the minimum value of the index
     * @param max the maximum value of the index
     * @param body a closure that executes over a contiguous range of indices
     */
    public static void sequential__2$1x10$lang$Long$3x10$lang$Long$2(final long min, final long max, final x10.core.fun.VoidFun_0_2<x10.core.Long,x10.core.Long> body) {
        
        //#line 83 "x10/compiler/Foreach.x10"
        ((x10.core.fun.VoidFun_0_2<x10.core.Long,x10.core.Long>)body).$apply(x10.core.Long.$box(min), x10.rtt.Types.LONG, x10.core.Long.$box(max), x10.rtt.Types.LONG);
    }
    
    
    //#line 92 "x10/compiler/Foreach.x10"
    /**
     * Iterate over a dense rectangular block of indices in single sequence in a
     * single activity.
     * @param space the 2D dense space over which to iterate
     * @param body a closure that executes over a single index [i,j]
     */
    public static void sequential__1$1x10$lang$Long$3x10$lang$Long$2(final x10.array.DenseIterationSpace_2 space, final x10.core.fun.VoidFun_0_2<x10.core.Long,x10.core.Long> body) {
        
        //#line 94 "x10/compiler/Foreach.x10"
        final long min$111804 = space.min0;
        
        //#line 94 "x10/compiler/Foreach.x10"
        final long max$111805 = space.max0;
        
        //#line 94 "x10/compiler/Foreach.x10"
        final long min$111806 = space.min1;
        
        //#line 94 "x10/compiler/Foreach.x10"
        final long max$111807 = space.max1;
        
        //#line 66 . "x10/compiler/Foreach.x10"
        long i$113143 = min$111804;
        
        //#line 66 . "x10/compiler/Foreach.x10"
        for (;
             true;
             ) {
            
            //#line 66 . "x10/compiler/Foreach.x10"
            final boolean t$113145 = ((i$113143) <= (((long)(max$111805))));
            
            //#line 66 . "x10/compiler/Foreach.x10"
            if (!(t$113145)) {
                
                //#line 66 . "x10/compiler/Foreach.x10"
                break;
            }
            
            //#line 67 . "x10/compiler/Foreach.x10"
            long i$113135 = min$111806;
            
            //#line 67 . "x10/compiler/Foreach.x10"
            for (;
                 true;
                 ) {
                
                //#line 67 . "x10/compiler/Foreach.x10"
                final boolean t$113137 = ((i$113135) <= (((long)(max$111807))));
                
                //#line 67 . "x10/compiler/Foreach.x10"
                if (!(t$113137)) {
                    
                    //#line 67 . "x10/compiler/Foreach.x10"
                    break;
                }
                
                //#line 68 . "x10/compiler/Foreach.x10"
                ((x10.core.fun.VoidFun_0_2<x10.core.Long,x10.core.Long>)body).$apply(x10.core.Long.$box(i$113143), x10.rtt.Types.LONG, x10.core.Long.$box(i$113135), x10.rtt.Types.LONG);
                
                //#line 67 . "x10/compiler/Foreach.x10"
                final long t$113134 = ((i$113135) + (((long)(1L))));
                
                //#line 67 . "x10/compiler/Foreach.x10"
                i$113135 = t$113134;
            }
            
            //#line 66 . "x10/compiler/Foreach.x10"
            final long t$113142 = ((i$113143) + (((long)(1L))));
            
            //#line 66 . "x10/compiler/Foreach.x10"
            i$113143 = t$113142;
        }
    }
    
    
    //#line 105 "x10/compiler/Foreach.x10"
    /**
     * Reduce over a range of indices in sequence in a single activity.
     * @param min the minimum value of the index
     * @param max the maximum value of the index
     * @param body a closure that executes over a single value of the index
     * @param reduce the reduction operation
     * @param identity the identity value for the reduction operation such that reduce(identity,f)=f
     */
    public static <$T>$T sequentialReduce__2$1x10$lang$Long$3x10$compiler$Foreach$$T$2__3$1x10$compiler$Foreach$$T$3x10$compiler$Foreach$$T$3x10$compiler$Foreach$$T$2__4x10$compiler$Foreach$$T$G(final x10.rtt.Type $T, final long min, final long max, final x10.core.fun.Fun_0_1<x10.core.Long,$T> body, final x10.core.fun.Fun_0_2<$T,$T,$T> reduce, final $T identity) {
        
        //#line 108 "x10/compiler/Foreach.x10"
        $T myRes = (($T)(identity));
        
        //#line 109 "x10/compiler/Foreach.x10"
        long i$113154 = min;
        
        //#line 109 "x10/compiler/Foreach.x10"
        for (;
             true;
             ) {
            
            //#line 109 "x10/compiler/Foreach.x10"
            final boolean t$113156 = ((i$113154) <= (((long)(max))));
            
            //#line 109 "x10/compiler/Foreach.x10"
            if (!(t$113156)) {
                
                //#line 109 "x10/compiler/Foreach.x10"
                break;
            }
            
            //#line 110 "x10/compiler/Foreach.x10"
            final $T t$113149 = (($T)((($T)
                                        ((x10.core.fun.Fun_0_1<x10.core.Long,$T>)body).$apply(x10.core.Long.$box(i$113154), x10.rtt.Types.LONG))));
            
            //#line 110 "x10/compiler/Foreach.x10"
            final $T t$113150 = (($T)((($T)
                                        ((x10.core.fun.Fun_0_2<$T,$T,$T>)reduce).$apply(myRes, $T, t$113149, $T))));
            
            //#line 110 "x10/compiler/Foreach.x10"
            myRes = (($T)(t$113150));
            
            //#line 109 "x10/compiler/Foreach.x10"
            final long t$113153 = ((i$113154) + (((long)(1L))));
            
            //#line 109 "x10/compiler/Foreach.x10"
            i$113154 = t$113153;
        }
        
        //#line 112 "x10/compiler/Foreach.x10"
        return myRes;
    }
    
    
    //#line 123 "x10/compiler/Foreach.x10"
    /**
     * Reduce over a range of indices in sequence in a single activity.
     * @param min the minimum value of the index
     * @param max the maximum value of the index
     * @param body a closure that executes over a contiguous range of indices, 
     *   returning the reduced value for that range
     * @param reduce the reduction operation
     */
    public static <$T>$T sequentialReduce__2$1x10$lang$Long$3x10$lang$Long$3x10$compiler$Foreach$$T$2__3$1x10$compiler$Foreach$$T$3x10$compiler$Foreach$$T$3x10$compiler$Foreach$$T$2$G(final x10.rtt.Type $T, final long min, final long max, final x10.core.fun.Fun_0_2<x10.core.Long,x10.core.Long,$T> body, final x10.core.fun.Fun_0_2<$T,$T,$T> reduce) {
        
        //#line 126 "x10/compiler/Foreach.x10"
        final $T t$112370 = (($T)((($T)
                                    ((x10.core.fun.Fun_0_2<x10.core.Long,x10.core.Long,$T>)body).$apply(x10.core.Long.$box(min), x10.rtt.Types.LONG, x10.core.Long.$box(max), x10.rtt.Types.LONG))));
        
        //#line 126 "x10/compiler/Foreach.x10"
        return t$112370;
    }
    
    
    //#line 136 "x10/compiler/Foreach.x10"
    /**
     * Reduce over a range of indices in sequence in a single activity.
     * @param space the 2D dense space over which to reduce
     * @param body a closure that executes over a single index [i,j]
     * @param reduce the reduction operation
     * @param identity the identity value for the reduction operation such that reduce(identity,f)=f
     */
    public static <$T>$T sequentialReduce__1$1x10$lang$Long$3x10$lang$Long$3x10$compiler$Foreach$$T$2__2$1x10$compiler$Foreach$$T$3x10$compiler$Foreach$$T$3x10$compiler$Foreach$$T$2__3x10$compiler$Foreach$$T$G(final x10.rtt.Type $T, final x10.array.DenseIterationSpace_2 space, final x10.core.fun.Fun_0_2<x10.core.Long,x10.core.Long,$T> body, final x10.core.fun.Fun_0_2<$T,$T,$T> reduce, final $T identity) {
        
        //#line 139 "x10/compiler/Foreach.x10"
        $T myRes = (($T)(identity));
        
        //#line 140 "x10/compiler/Foreach.x10"
        final long i$111517min$113176 = space.min0;
        
        //#line 140 "x10/compiler/Foreach.x10"
        final long i$111517max$113177 = space.max0;
        
        //#line 140 "x10/compiler/Foreach.x10"
        long i$113173 = i$111517min$113176;
        
        //#line 140 "x10/compiler/Foreach.x10"
        for (;
             true;
             ) {
            
            //#line 140 "x10/compiler/Foreach.x10"
            final boolean t$113175 = ((i$113173) <= (((long)(i$111517max$113177))));
            
            //#line 140 "x10/compiler/Foreach.x10"
            if (!(t$113175)) {
                
                //#line 140 "x10/compiler/Foreach.x10"
                break;
            }
            
            //#line 141 "x10/compiler/Foreach.x10"
            final long i$111499min$113168 = space.min1;
            
            //#line 141 "x10/compiler/Foreach.x10"
            final long i$111499max$113169 = space.max1;
            
            //#line 141 "x10/compiler/Foreach.x10"
            long i$113165 = i$111499min$113168;
            
            //#line 141 "x10/compiler/Foreach.x10"
            for (;
                 true;
                 ) {
                
                //#line 141 "x10/compiler/Foreach.x10"
                final boolean t$113167 = ((i$113165) <= (((long)(i$111499max$113169))));
                
                //#line 141 "x10/compiler/Foreach.x10"
                if (!(t$113167)) {
                    
                    //#line 141 "x10/compiler/Foreach.x10"
                    break;
                }
                
                //#line 142 "x10/compiler/Foreach.x10"
                final $T t$113160 = (($T)((($T)
                                            ((x10.core.fun.Fun_0_2<x10.core.Long,x10.core.Long,$T>)body).$apply(x10.core.Long.$box(i$113173), x10.rtt.Types.LONG, x10.core.Long.$box(i$113165), x10.rtt.Types.LONG))));
                
                //#line 142 "x10/compiler/Foreach.x10"
                final $T t$113161 = (($T)((($T)
                                            ((x10.core.fun.Fun_0_2<$T,$T,$T>)reduce).$apply(myRes, $T, t$113160, $T))));
                
                //#line 142 "x10/compiler/Foreach.x10"
                myRes = (($T)(t$113161));
                
                //#line 141 "x10/compiler/Foreach.x10"
                final long t$113164 = ((i$113165) + (((long)(1L))));
                
                //#line 141 "x10/compiler/Foreach.x10"
                i$113165 = t$113164;
            }
            
            //#line 140 "x10/compiler/Foreach.x10"
            final long t$113172 = ((i$113173) + (((long)(1L))));
            
            //#line 140 "x10/compiler/Foreach.x10"
            i$113173 = t$113172;
        }
        
        //#line 145 "x10/compiler/Foreach.x10"
        return myRes;
    }
    
    
    //#line 155 "x10/compiler/Foreach.x10"
    /**
     * Iterate over a range of indices in parallel using a basic async
     * transformation. A separate async is started for every index in min..max
     * @param min the minimum value of the index
     * @param max the maximum value of the index
     * @param body a closure that executes over a single value of the index
     */
    public static void basic__2$1x10$lang$Long$2(final long min, final long max, final x10.core.fun.VoidFun_0_1<x10.core.Long> body) {
        
        //#line 157 "x10/compiler/Foreach.x10"
        final int t$112385 = x10.xrx.Runtime.get$NTHREADS();
        
        //#line 157 "x10/compiler/Foreach.x10"
        final boolean t$112396 = ((int) t$112385) == ((int) 1);
        
        //#line 157 "x10/compiler/Foreach.x10"
        if (t$112396) {
            
            //#line 52 . "x10/compiler/Foreach.x10"
            long i$113181 = min;
            
            //#line 52 . "x10/compiler/Foreach.x10"
            for (;
                 true;
                 ) {
                
                //#line 52 . "x10/compiler/Foreach.x10"
                final boolean t$113183 = ((i$113181) <= (((long)(max))));
                
                //#line 52 . "x10/compiler/Foreach.x10"
                if (!(t$113183)) {
                    
                    //#line 52 . "x10/compiler/Foreach.x10"
                    break;
                }
                
                //#line 52 . "x10/compiler/Foreach.x10"
                ((x10.core.fun.VoidFun_0_1<x10.core.Long>)body).$apply(x10.core.Long.$box(i$113181), x10.rtt.Types.LONG);
                
                //#line 52 . "x10/compiler/Foreach.x10"
                final long t$113180 = ((i$113181) + (((long)(1L))));
                
                //#line 52 . "x10/compiler/Foreach.x10"
                i$113181 = t$113180;
            }
        } else {
            {
                
                //#line 160 "x10/compiler/Foreach.x10"
                x10.xrx.Runtime.ensureNotInAtomic();
                
                //#line 160 "x10/compiler/Foreach.x10"
                final x10.xrx.FinishState fs$113929 = x10.xrx.Runtime.startFinish();
                
                //#line 160 "x10/compiler/Foreach.x10"
                try {{
                    {
                        
                        //#line 160 "x10/compiler/Foreach.x10"
                        final long i$111535max$111537 = max;
                        
                        //#line 160 "x10/compiler/Foreach.x10"
                        long i$113189 = min;
                        
                        //#line 160 "x10/compiler/Foreach.x10"
                        for (;
                             true;
                             ) {
                            
                            //#line 160 "x10/compiler/Foreach.x10"
                            final boolean t$113191 = ((i$113189) <= (((long)(i$111535max$111537))));
                            
                            //#line 160 "x10/compiler/Foreach.x10"
                            if (!(t$113191)) {
                                
                                //#line 160 "x10/compiler/Foreach.x10"
                                break;
                            }
                            
                            //#line 160 "x10/compiler/Foreach.x10"
                            final long i$113186 = i$113189;
                            
                            //#line 160 "x10/compiler/Foreach.x10"
                            x10.xrx.Runtime.runAsync(((x10.core.fun.VoidFun_0_0)(new x10.compiler.Foreach.$Closure$22(body, i$113186, (x10.compiler.Foreach.$Closure$22.__0$1x10$lang$Long$2) null))));
                            
                            //#line 160 "x10/compiler/Foreach.x10"
                            final long t$113188 = ((i$113189) + (((long)(1L))));
                            
                            //#line 160 "x10/compiler/Foreach.x10"
                            i$113189 = t$113188;
                        }
                    }
                }}catch (java.lang.Throwable ct$113927) {
                    
                    //#line 160 "x10/compiler/Foreach.x10"
                    x10.xrx.Runtime.pushException(((java.lang.Throwable)(ct$113927)));
                    
                    //#line 160 "x10/compiler/Foreach.x10"
                    throw new java.lang.RuntimeException();
                }finally {{
                     
                     //#line 160 "x10/compiler/Foreach.x10"
                     x10.xrx.Runtime.stopFinish(((x10.xrx.FinishState)(fs$113929)));
                 }}
                }
            }
        }
    
    
    //#line 172 "x10/compiler/Foreach.x10"
    /**
     * Iterate over a range of indices in parallel using a basic async
     * transformation. A separate async is started for every index in min..max
     * @param min0 the minimum value of the first index dimension
     * @param max0 the maximum value of the first index dimension
     * @param min1 the minimum value of the second index dimension
     * @param max1 the maximum value of the second index dimension
     * @param body a closure that executes over a single value of the index [i,j]
     */
    public static void basic__4$1x10$lang$Long$3x10$lang$Long$2(final long min0, final long max0, final long min1, final long max1, final x10.core.fun.VoidFun_0_2<x10.core.Long,x10.core.Long> body) {
        
        //#line 175 "x10/compiler/Foreach.x10"
        final int t$112397 = x10.xrx.Runtime.get$NTHREADS();
        
        //#line 175 "x10/compiler/Foreach.x10"
        final boolean t$112418 = ((int) t$112397) == ((int) 1);
        
        //#line 175 "x10/compiler/Foreach.x10"
        if (t$112418) {
            
            //#line 66 . "x10/compiler/Foreach.x10"
            long i$113203 = min0;
            
            //#line 66 . "x10/compiler/Foreach.x10"
            for (;
                 true;
                 ) {
                
                //#line 66 . "x10/compiler/Foreach.x10"
                final boolean t$113205 = ((i$113203) <= (((long)(max0))));
                
                //#line 66 . "x10/compiler/Foreach.x10"
                if (!(t$113205)) {
                    
                    //#line 66 . "x10/compiler/Foreach.x10"
                    break;
                }
                
                //#line 67 . "x10/compiler/Foreach.x10"
                long i$113195 = min1;
                
                //#line 67 . "x10/compiler/Foreach.x10"
                for (;
                     true;
                     ) {
                    
                    //#line 67 . "x10/compiler/Foreach.x10"
                    final boolean t$113197 = ((i$113195) <= (((long)(max1))));
                    
                    //#line 67 . "x10/compiler/Foreach.x10"
                    if (!(t$113197)) {
                        
                        //#line 67 . "x10/compiler/Foreach.x10"
                        break;
                    }
                    
                    //#line 68 . "x10/compiler/Foreach.x10"
                    ((x10.core.fun.VoidFun_0_2<x10.core.Long,x10.core.Long>)body).$apply(x10.core.Long.$box(i$113203), x10.rtt.Types.LONG, x10.core.Long.$box(i$113195), x10.rtt.Types.LONG);
                    
                    //#line 67 . "x10/compiler/Foreach.x10"
                    final long t$113194 = ((i$113195) + (((long)(1L))));
                    
                    //#line 67 . "x10/compiler/Foreach.x10"
                    i$113195 = t$113194;
                }
                
                //#line 66 . "x10/compiler/Foreach.x10"
                final long t$113202 = ((i$113203) + (((long)(1L))));
                
                //#line 66 . "x10/compiler/Foreach.x10"
                i$113203 = t$113202;
            }
        } else {
            {
                
                //#line 178 "x10/compiler/Foreach.x10"
                x10.xrx.Runtime.ensureNotInAtomic();
                
                //#line 178 "x10/compiler/Foreach.x10"
                final x10.xrx.FinishState fs$113935 = x10.xrx.Runtime.startFinish();
                
                //#line 178 "x10/compiler/Foreach.x10"
                try {{
                    {
                        
                        //#line 178 "x10/compiler/Foreach.x10"
                        final long i$111571max$111573 = max0;
                        
                        //#line 178 "x10/compiler/Foreach.x10"
                        long i$113219 = min0;
                        
                        //#line 178 "x10/compiler/Foreach.x10"
                        for (;
                             true;
                             ) {
                            
                            //#line 178 "x10/compiler/Foreach.x10"
                            final boolean t$113221 = ((i$113219) <= (((long)(i$111571max$111573))));
                            
                            //#line 178 "x10/compiler/Foreach.x10"
                            if (!(t$113221)) {
                                
                                //#line 178 "x10/compiler/Foreach.x10"
                                break;
                            }
                            
                            //#line 178 "x10/compiler/Foreach.x10"
                            final long i$113216 = i$113219;
                            
                            //#line 179 "x10/compiler/Foreach.x10"
                            final long i$111553max$113215 = max1;
                            
                            //#line 179 "x10/compiler/Foreach.x10"
                            long i$113211 = min1;
                            
                            //#line 179 "x10/compiler/Foreach.x10"
                            for (;
                                 true;
                                 ) {
                                
                                //#line 179 "x10/compiler/Foreach.x10"
                                final boolean t$113213 = ((i$113211) <= (((long)(i$111553max$113215))));
                                
                                //#line 179 "x10/compiler/Foreach.x10"
                                if (!(t$113213)) {
                                    
                                    //#line 179 "x10/compiler/Foreach.x10"
                                    break;
                                }
                                
                                //#line 179 "x10/compiler/Foreach.x10"
                                final long j$113208 = i$113211;
                                
                                //#line 180 "x10/compiler/Foreach.x10"
                                x10.xrx.Runtime.runAsync(((x10.core.fun.VoidFun_0_0)(new x10.compiler.Foreach.$Closure$23(body, i$113216, j$113208, (x10.compiler.Foreach.$Closure$23.__0$1x10$lang$Long$3x10$lang$Long$2) null))));
                                
                                //#line 179 "x10/compiler/Foreach.x10"
                                final long t$113210 = ((i$113211) + (((long)(1L))));
                                
                                //#line 179 "x10/compiler/Foreach.x10"
                                i$113211 = t$113210;
                            }
                            
                            //#line 178 "x10/compiler/Foreach.x10"
                            final long t$113218 = ((i$113219) + (((long)(1L))));
                            
                            //#line 178 "x10/compiler/Foreach.x10"
                            i$113219 = t$113218;
                        }
                    }
                }}catch (java.lang.Throwable ct$113933) {
                    
                    //#line 178 "x10/compiler/Foreach.x10"
                    x10.xrx.Runtime.pushException(((java.lang.Throwable)(ct$113933)));
                    
                    //#line 178 "x10/compiler/Foreach.x10"
                    throw new java.lang.RuntimeException();
                }finally {{
                     
                     //#line 178 "x10/compiler/Foreach.x10"
                     x10.xrx.Runtime.stopFinish(((x10.xrx.FinishState)(fs$113935)));
                 }}
                }
            }
        }
    
    
    //#line 195 "x10/compiler/Foreach.x10"
    /**
     * Iterate over a range of indices in parallel using a block decomposition.
     * <code>Runtime.NTHREADS</code> activities are created, one for each
     * worker thread.  Each activity executes sequentially over all indices in
     * a contiguous block, and the blocks are of approximately equal size.
     * @param min the minimum value of the index
     * @param max the maximum value of the index
     * @param body a closure that executes over a contiguous range of indices
     */
    public static void block__2$1x10$lang$Long$3x10$lang$Long$2(final long min, final long max, final x10.core.fun.VoidFun_0_2<x10.core.Long,x10.core.Long> body) {
        
        //#line 197 "x10/compiler/Foreach.x10"
        final int nthreads = x10.xrx.Runtime.get$NTHREADS();
        
        //#line 198 "x10/compiler/Foreach.x10"
        final boolean t$112439 = ((int) nthreads) == ((int) 1);
        
        //#line 198 "x10/compiler/Foreach.x10"
        if (t$112439) {
            
            //#line 83 . "x10/compiler/Foreach.x10"
            ((x10.core.fun.VoidFun_0_2<x10.core.Long,x10.core.Long>)body).$apply(x10.core.Long.$box(min), x10.rtt.Types.LONG, x10.core.Long.$box(max), x10.rtt.Types.LONG);
        } else {
            
            //#line 201 "x10/compiler/Foreach.x10"
            final long t$112419 = ((max) - (((long)(min))));
            
            //#line 201 "x10/compiler/Foreach.x10"
            final long numElems = ((t$112419) + (((long)(1L))));
            
            //#line 202 "x10/compiler/Foreach.x10"
            final boolean t$112420 = ((numElems) < (((long)(1L))));
            
            //#line 202 "x10/compiler/Foreach.x10"
            if (t$112420) {
                
                //#line 202 "x10/compiler/Foreach.x10"
                return;
            }
            
            //#line 203 "x10/compiler/Foreach.x10"
            final long t$112421 = ((long)(((int)(nthreads))));
            
            //#line 203 "x10/compiler/Foreach.x10"
            final long blockSize = ((numElems) / (((long)(t$112421))));
            
            //#line 204 "x10/compiler/Foreach.x10"
            final long t$112422 = ((long)(((int)(nthreads))));
            
            //#line 204 "x10/compiler/Foreach.x10"
            final long t$112423 = ((t$112422) * (((long)(blockSize))));
            
            //#line 204 "x10/compiler/Foreach.x10"
            final long leftOver = ((numElems) - (((long)(t$112423))));
            {
                
                //#line 205 "x10/compiler/Foreach.x10"
                x10.xrx.Runtime.ensureNotInAtomic();
                
                //#line 205 "x10/compiler/Foreach.x10"
                final x10.xrx.FinishState fs$113941 = x10.xrx.Runtime.startFinish();
                
                //#line 205 "x10/compiler/Foreach.x10"
                try {{
                    {
                        
                        //#line 205 "x10/compiler/Foreach.x10"
                        final long t$112425 = ((long)(((int)(nthreads))));
                        
                        //#line 205 "x10/compiler/Foreach.x10"
                        long t = ((t$112425) - (((long)(1L))));
                        
                        //#line 205 "x10/compiler/Foreach.x10"
                        for (;
                             true;
                             ) {
                            
                            //#line 205 "x10/compiler/Foreach.x10"
                            final boolean t$112438 = ((t) >= (((long)(0L))));
                            
                            //#line 205 "x10/compiler/Foreach.x10"
                            if (!(t$112438)) {
                                
                                //#line 205 "x10/compiler/Foreach.x10"
                                break;
                            }
                            
                            //#line 206 "x10/compiler/Foreach.x10"
                            final long myT$113222 = t;
                            
                            //#line 207 "x10/compiler/Foreach.x10"
                            x10.xrx.Runtime.runAsync(((x10.core.fun.VoidFun_0_0)(new x10.compiler.Foreach.$Closure$24(blockSize, myT$113222, min, leftOver, body, (x10.compiler.Foreach.$Closure$24.__4$1x10$lang$Long$3x10$lang$Long$2) null))));
                            
                            //#line 205 "x10/compiler/Foreach.x10"
                            final long t$113235 = ((t) - (((long)(1L))));
                            
                            //#line 205 "x10/compiler/Foreach.x10"
                            t = t$113235;
                        }
                    }
                }}catch (java.lang.Throwable ct$113939) {
                    
                    //#line 205 "x10/compiler/Foreach.x10"
                    x10.xrx.Runtime.pushException(((java.lang.Throwable)(ct$113939)));
                    
                    //#line 205 "x10/compiler/Foreach.x10"
                    throw new java.lang.RuntimeException();
                }finally {{
                     
                     //#line 205 "x10/compiler/Foreach.x10"
                     x10.xrx.Runtime.stopFinish(((x10.xrx.FinishState)(fs$113941)));
                 }}
                }
            }
        }
    
    
    //#line 225 "x10/compiler/Foreach.x10"
    /**
     * Iterate over a range of indices in parallel using a block decomposition.
     * <code>Runtime.NTHREADS</code> activities are created, one for each
     * worker thread.  Each activity executes sequentially over all indices in
     * a contiguous block, and the blocks are of approximately equal size.
     * @param min the minimum value of the index
     * @param max the maximum value of the index
     * @param body a closure that executes over a single value of the index
     */
    public static void block__2$1x10$lang$Long$2(final long min, final long max, final x10.core.fun.VoidFun_0_1<x10.core.Long> body) {
        
        //#line 228 "x10/compiler/Foreach.x10"
        final long min$111852 = min;
        
        //#line 196 . "x10/compiler/Foreach.x10"
        __ret$111863: {
            
            //#line 197 . "x10/compiler/Foreach.x10"
            final int nthreads$111855 = x10.xrx.Runtime.get$NTHREADS();
            //#line 198 . "x10/compiler/Foreach.x10"
            final boolean t$112470 = ((int) nthreads$111855) == ((int) 1);
            //#line 198 . "x10/compiler/Foreach.x10"
            if (t$112470) {
                
                //#line 52 .... "x10/compiler/Foreach.x10"
                long i$113239 = min;
                
                //#line 52 .... "x10/compiler/Foreach.x10"
                for (;
                     true;
                     ) {
                    
                    //#line 52 .... "x10/compiler/Foreach.x10"
                    final boolean t$113241 = ((i$113239) <= (((long)(max))));
                    
                    //#line 52 .... "x10/compiler/Foreach.x10"
                    if (!(t$113241)) {
                        
                        //#line 52 .... "x10/compiler/Foreach.x10"
                        break;
                    }
                    
                    //#line 52 .... "x10/compiler/Foreach.x10"
                    ((x10.core.fun.VoidFun_0_1<x10.core.Long>)body).$apply(x10.core.Long.$box(i$113239), x10.rtt.Types.LONG);
                    
                    //#line 52 .... "x10/compiler/Foreach.x10"
                    final long t$113238 = ((i$113239) + (((long)(1L))));
                    
                    //#line 52 .... "x10/compiler/Foreach.x10"
                    i$113239 = t$113238;
                }
            } else {
                
                //#line 201 . "x10/compiler/Foreach.x10"
                final long t$112445 = ((max) - (((long)(min))));
                
                //#line 201 . "x10/compiler/Foreach.x10"
                final long numElems$111856 = ((t$112445) + (((long)(1L))));
                
                //#line 202 . "x10/compiler/Foreach.x10"
                final boolean t$112446 = ((numElems$111856) < (((long)(1L))));
                
                //#line 202 . "x10/compiler/Foreach.x10"
                if (t$112446) {
                    
                    //#line 202 . "x10/compiler/Foreach.x10"
                    break __ret$111863;
                }
                
                //#line 203 . "x10/compiler/Foreach.x10"
                final long t$112447 = ((long)(((int)(nthreads$111855))));
                
                //#line 203 . "x10/compiler/Foreach.x10"
                final long blockSize$111857 = ((numElems$111856) / (((long)(t$112447))));
                
                //#line 204 . "x10/compiler/Foreach.x10"
                final long t$112448 = ((long)(((int)(nthreads$111855))));
                
                //#line 204 . "x10/compiler/Foreach.x10"
                final long t$112449 = ((t$112448) * (((long)(blockSize$111857))));
                
                //#line 204 . "x10/compiler/Foreach.x10"
                final long leftOver$111858 = ((numElems$111856) - (((long)(t$112449))));
                {
                    
                    //#line 205 . "x10/compiler/Foreach.x10"
                    x10.xrx.Runtime.ensureNotInAtomic();
                    
                    //#line 205 . "x10/compiler/Foreach.x10"
                    final x10.xrx.FinishState fs$113947 = x10.xrx.Runtime.startFinish();
                    
                    //#line 205 . "x10/compiler/Foreach.x10"
                    try {{
                        {
                            
                            //#line 205 . "x10/compiler/Foreach.x10"
                            final long t$112451 = ((long)(((int)(nthreads$111855))));
                            
                            //#line 205 . "x10/compiler/Foreach.x10"
                            long t$111859 = ((t$112451) - (((long)(1L))));
                            
                            //#line 205 . "x10/compiler/Foreach.x10"
                            for (;
                                 true;
                                 ) {
                                
                                //#line 205 . "x10/compiler/Foreach.x10"
                                final boolean t$112469 = ((t$111859) >= (((long)(0L))));
                                
                                //#line 205 . "x10/compiler/Foreach.x10"
                                if (!(t$112469)) {
                                    
                                    //#line 205 . "x10/compiler/Foreach.x10"
                                    break;
                                }
                                
                                //#line 206 . "x10/compiler/Foreach.x10"
                                final long myT$113260 = t$111859;
                                
                                //#line 207 . "x10/compiler/Foreach.x10"
                                x10.xrx.Runtime.runAsync(((x10.core.fun.VoidFun_0_0)(new x10.compiler.Foreach.$Closure$25(blockSize$111857, myT$113260, min$111852, leftOver$111858, body, (x10.compiler.Foreach.$Closure$25.__4$1x10$lang$Long$2) null))));
                                
                                //#line 205 . "x10/compiler/Foreach.x10"
                                final long t$113275 = ((t$111859) - (((long)(1L))));
                                
                                //#line 205 . "x10/compiler/Foreach.x10"
                                t$111859 = t$113275;
                            }
                        }
                    }}catch (java.lang.Throwable ct$113945) {
                        
                        //#line 205 . "x10/compiler/Foreach.x10"
                        x10.xrx.Runtime.pushException(((java.lang.Throwable)(ct$113945)));
                        
                        //#line 205 . "x10/compiler/Foreach.x10"
                        throw new java.lang.RuntimeException();
                    }finally {{
                         
                         //#line 205 . "x10/compiler/Foreach.x10"
                         x10.xrx.Runtime.stopFinish(((x10.xrx.FinishState)(fs$113947)));
                     }}
                    }
                }
            }
        }
    
    
    //#line 242 "x10/compiler/Foreach.x10"
    /**
     * Reduce over a range of indices in parallel using a block decomposition.
     * <code>Runtime.NTHREADS</code> activities are created, one for each
     * worker thread.  Each activity executes sequentially over all indices in
     * a contiguous block, and the blocks are of approximately equal size.
     * @param min the minimum value of the index
     * @param max the maximum value of the index
     * @param body a closure that executes over a contiguous range of indices, 
     *   returning the reduced value for that range
     * @param reduce the reduction operation
     */
    public static <$T>$T blockReduce__2$1x10$lang$Long$3x10$lang$Long$3x10$compiler$Foreach$$T$2__3$1x10$compiler$Foreach$$T$3x10$compiler$Foreach$$T$3x10$compiler$Foreach$$T$2$G(final x10.rtt.Type $T, final long min, final long max, final x10.core.fun.Fun_0_2<x10.core.Long,x10.core.Long,$T> body, final x10.core.fun.Fun_0_2<$T,$T,$T> reduce) {
        
        //#line 245 "x10/compiler/Foreach.x10"
        final int nthreads = x10.xrx.Runtime.get$NTHREADS();
        
        //#line 246 "x10/compiler/Foreach.x10"
        final boolean t$112505 = ((int) nthreads) == ((int) 1);
        
        //#line 246 "x10/compiler/Foreach.x10"
        if (t$112505) {
            
            //#line 247 "x10/compiler/Foreach.x10"
            final $T t$112471 = (($T)((($T)
                                        ((x10.core.fun.Fun_0_2<x10.core.Long,x10.core.Long,$T>)body).$apply(x10.core.Long.$box(min), x10.rtt.Types.LONG, x10.core.Long.$box(max), x10.rtt.Types.LONG))));
            
            //#line 247 "x10/compiler/Foreach.x10"
            return t$112471;
        } else {
            
            //#line 249 "x10/compiler/Foreach.x10"
            final long t$112472 = ((max) - (((long)(min))));
            
            //#line 249 "x10/compiler/Foreach.x10"
            final long numElems = ((t$112472) + (((long)(1L))));
            
            //#line 250 "x10/compiler/Foreach.x10"
            final boolean t$112474 = ((numElems) < (((long)(1L))));
            
            //#line 250 "x10/compiler/Foreach.x10"
            if (t$112474) {
                
                //#line 250 "x10/compiler/Foreach.x10"
                final $T t$112473 = (($T)((($T)
                                            ((x10.core.fun.Fun_0_2<x10.core.Long,x10.core.Long,$T>)body).$apply(x10.core.Long.$box(min), x10.rtt.Types.LONG, x10.core.Long.$box(max), x10.rtt.Types.LONG))));
                
                //#line 250 "x10/compiler/Foreach.x10"
                return t$112473;
            }
            
            //#line 251 "x10/compiler/Foreach.x10"
            final long t$112475 = ((long)(((int)(nthreads))));
            
            //#line 251 "x10/compiler/Foreach.x10"
            final long blockSize = ((numElems) / (((long)(t$112475))));
            
            //#line 252 "x10/compiler/Foreach.x10"
            final long t$112476 = ((long)(((int)(nthreads))));
            
            //#line 252 "x10/compiler/Foreach.x10"
            final long t$112477 = ((t$112476) * (((long)(blockSize))));
            
            //#line 252 "x10/compiler/Foreach.x10"
            final long leftOver = ((numElems) - (((long)(t$112477))));
            
            //#line 253 "x10/compiler/Foreach.x10"
            final long t$112478 = ((long)(((int)(nthreads))));
            
            //#line 253 "x10/compiler/Foreach.x10"
            final x10.core.Rail results = ((x10.core.Rail)(x10.core.Rail.<$T>makeUnsafe($T, ((long)(t$112478)), false)));
            {
                
                //#line 254 "x10/compiler/Foreach.x10"
                x10.xrx.Runtime.ensureNotInAtomic();
                
                //#line 254 "x10/compiler/Foreach.x10"
                final x10.xrx.FinishState fs$113953 = x10.xrx.Runtime.startFinish();
                
                //#line 254 "x10/compiler/Foreach.x10"
                try {{
                    {
                        
                        //#line 254 "x10/compiler/Foreach.x10"
                        final long t$112480 = ((long)(((int)(nthreads))));
                        
                        //#line 254 "x10/compiler/Foreach.x10"
                        long t = ((t$112480) - (((long)(1L))));
                        
                        //#line 254 "x10/compiler/Foreach.x10"
                        for (;
                             true;
                             ) {
                            
                            //#line 254 "x10/compiler/Foreach.x10"
                            final boolean t$112494 = ((t) >= (((long)(0L))));
                            
                            //#line 254 "x10/compiler/Foreach.x10"
                            if (!(t$112494)) {
                                
                                //#line 254 "x10/compiler/Foreach.x10"
                                break;
                            }
                            
                            //#line 255 "x10/compiler/Foreach.x10"
                            final long myT$113276 = t;
                            
                            //#line 256 "x10/compiler/Foreach.x10"
                            x10.xrx.Runtime.runAsync(((x10.core.fun.VoidFun_0_0)(new x10.compiler.Foreach.$Closure$26<$T>($T, blockSize, myT$113276, min, leftOver, body, results, (x10.compiler.Foreach.$Closure$26.__4$1x10$lang$Long$3x10$lang$Long$3x10$compiler$Foreach$$Closure$26$$T$2__5$1x10$compiler$Foreach$$Closure$26$$T$2) null))));
                            
                            //#line 254 "x10/compiler/Foreach.x10"
                            final long t$113290 = ((t) - (((long)(1L))));
                            
                            //#line 254 "x10/compiler/Foreach.x10"
                            t = t$113290;
                        }
                    }
                }}catch (java.lang.Throwable ct$113951) {
                    
                    //#line 254 "x10/compiler/Foreach.x10"
                    x10.xrx.Runtime.pushException(((java.lang.Throwable)(ct$113951)));
                    
                    //#line 254 "x10/compiler/Foreach.x10"
                    throw new java.lang.RuntimeException();
                }finally {{
                     
                     //#line 254 "x10/compiler/Foreach.x10"
                     x10.xrx.Runtime.stopFinish(((x10.xrx.FinishState)(fs$113953)));
                 }}
                }
            
            //#line 262 "x10/compiler/Foreach.x10"
            $T res = (($T)(((x10.core.Rail<$T>)results).$apply$G((long)(0L))));
            
            //#line 263 "x10/compiler/Foreach.x10"
            final long t$113300 = ((long)(((int)(nthreads))));
            
            //#line 263 "x10/compiler/Foreach.x10"
            final long i$111589max$113301 = ((t$113300) - (((long)(1L))));
            
            //#line 263 "x10/compiler/Foreach.x10"
            long i$113297 = 1L;
            
            //#line 263 "x10/compiler/Foreach.x10"
            for (;
                 true;
                 ) {
                
                //#line 263 "x10/compiler/Foreach.x10"
                final boolean t$113299 = ((i$113297) <= (((long)(i$111589max$113301))));
                
                //#line 263 "x10/compiler/Foreach.x10"
                if (!(t$113299)) {
                    
                    //#line 263 "x10/compiler/Foreach.x10"
                    break;
                }
                
                //#line 264 "x10/compiler/Foreach.x10"
                final $T t$113292 = (($T)(((x10.core.Rail<$T>)results).$apply$G((long)(i$113297))));
                
                //#line 264 "x10/compiler/Foreach.x10"
                final $T t$113293 = (($T)((($T)
                                            ((x10.core.fun.Fun_0_2<$T,$T,$T>)reduce).$apply(res, $T, t$113292, $T))));
                
                //#line 264 "x10/compiler/Foreach.x10"
                res = (($T)(t$113293));
                
                //#line 263 "x10/compiler/Foreach.x10"
                final long t$113296 = ((i$113297) + (((long)(1L))));
                
                //#line 263 "x10/compiler/Foreach.x10"
                i$113297 = t$113296;
            }
            
            //#line 266 "x10/compiler/Foreach.x10"
            return res;
            }
        }
    
    
    //#line 281 "x10/compiler/Foreach.x10"
    /**
     * Reduce over a range of indices in parallel using a block decomposition.
     * <code>Runtime.NTHREADS</code> activities are created, one for each
     * worker thread.  Each activity executes sequentially over all indices in
     * a contiguous block, and the blocks are of approximately equal size.
     * @param min the minimum value of the index
     * @param max the maximum value of the index
     * @param body a closure that executes over a single value of the index
     * @param reduce the reduction operation
     * @param identity the identity value for the reduction operation such that reduce(identity,f)=f
     */
    public static <$T>$T blockReduce__2$1x10$lang$Long$3x10$compiler$Foreach$$T$2__3$1x10$compiler$Foreach$$T$3x10$compiler$Foreach$$T$3x10$compiler$Foreach$$T$2__4x10$compiler$Foreach$$T$G(final x10.rtt.Type $T, final long min, final long max, final x10.core.fun.Fun_0_1<x10.core.Long,$T> body, final x10.core.fun.Fun_0_2<$T,$T,$T> reduce, final $T identity) {
        
        //#line 292 "x10/compiler/Foreach.x10"
        final long min$111890 = min;
        
        //#line 292 "x10/compiler/Foreach.x10"
        final x10.core.fun.Fun_0_2 reduce$111893 = ((x10.core.fun.Fun_0_2)(reduce));
        
        //#line 242 . "x10/compiler/Foreach.x10"
        $T ret$111908 =  null;
        
        //#line 244 . "x10/compiler/Foreach.x10"
        __ret$111909: {
            
            //#line 245 . "x10/compiler/Foreach.x10"
            final int nthreads$111894 = x10.xrx.Runtime.get$NTHREADS();
            //#line 246 . "x10/compiler/Foreach.x10"
            final boolean t$112564 = ((int) nthreads$111894) == ((int) 1);
            //#line 246 . "x10/compiler/Foreach.x10"
            if (t$112564) {
                
                //#line 285 .. "x10/compiler/Foreach.x10"
                $T myRes$111912 = (($T)(identity));
                
                //#line 286 .. "x10/compiler/Foreach.x10"
                long i$113308 = min;
                
                //#line 286 .. "x10/compiler/Foreach.x10"
                for (;
                     true;
                     ) {
                    
                    //#line 286 .. "x10/compiler/Foreach.x10"
                    final boolean t$113310 = ((i$113308) <= (((long)(max))));
                    
                    //#line 286 .. "x10/compiler/Foreach.x10"
                    if (!(t$113310)) {
                        
                        //#line 286 .. "x10/compiler/Foreach.x10"
                        break;
                    }
                    
                    //#line 287 .. "x10/compiler/Foreach.x10"
                    final $T t$113303 = (($T)((($T)
                                                ((x10.core.fun.Fun_0_1<x10.core.Long,$T>)body).$apply(x10.core.Long.$box(i$113308), x10.rtt.Types.LONG))));
                    
                    //#line 287 .. "x10/compiler/Foreach.x10"
                    final $T t$113304 = (($T)((($T)
                                                ((x10.core.fun.Fun_0_2<$T,$T,$T>)reduce).$apply(myRes$111912, $T, t$113303, $T))));
                    
                    //#line 287 .. "x10/compiler/Foreach.x10"
                    myRes$111912 = (($T)(t$113304));
                    
                    //#line 286 .. "x10/compiler/Foreach.x10"
                    final long t$113307 = ((i$113308) + (((long)(1L))));
                    
                    //#line 286 .. "x10/compiler/Foreach.x10"
                    i$113308 = t$113307;
                }
                
                //#line 247 . "x10/compiler/Foreach.x10"
                ret$111908 = (($T)(myRes$111912));
                
                //#line 247 . "x10/compiler/Foreach.x10"
                break __ret$111909;
            } else {
                
                //#line 249 . "x10/compiler/Foreach.x10"
                final long t$112515 = ((max) - (((long)(min))));
                
                //#line 249 . "x10/compiler/Foreach.x10"
                final long numElems$111895 = ((t$112515) + (((long)(1L))));
                
                //#line 250 . "x10/compiler/Foreach.x10"
                final boolean t$112525 = ((numElems$111895) < (((long)(1L))));
                
                //#line 250 . "x10/compiler/Foreach.x10"
                if (t$112525) {
                    
                    //#line 285 .. "x10/compiler/Foreach.x10"
                    $T myRes$111920 = (($T)(identity));
                    
                    //#line 286 .. "x10/compiler/Foreach.x10"
                    long i$113319 = min;
                    
                    //#line 286 .. "x10/compiler/Foreach.x10"
                    for (;
                         true;
                         ) {
                        
                        //#line 286 .. "x10/compiler/Foreach.x10"
                        final boolean t$113321 = ((i$113319) <= (((long)(max))));
                        
                        //#line 286 .. "x10/compiler/Foreach.x10"
                        if (!(t$113321)) {
                            
                            //#line 286 .. "x10/compiler/Foreach.x10"
                            break;
                        }
                        
                        //#line 287 .. "x10/compiler/Foreach.x10"
                        final $T t$113314 = (($T)((($T)
                                                    ((x10.core.fun.Fun_0_1<x10.core.Long,$T>)body).$apply(x10.core.Long.$box(i$113319), x10.rtt.Types.LONG))));
                        
                        //#line 287 .. "x10/compiler/Foreach.x10"
                        final $T t$113315 = (($T)((($T)
                                                    ((x10.core.fun.Fun_0_2<$T,$T,$T>)reduce).$apply(myRes$111920, $T, t$113314, $T))));
                        
                        //#line 287 .. "x10/compiler/Foreach.x10"
                        myRes$111920 = (($T)(t$113315));
                        
                        //#line 286 .. "x10/compiler/Foreach.x10"
                        final long t$113318 = ((i$113319) + (((long)(1L))));
                        
                        //#line 286 .. "x10/compiler/Foreach.x10"
                        i$113319 = t$113318;
                    }
                    
                    //#line 250 . "x10/compiler/Foreach.x10"
                    ret$111908 = (($T)(myRes$111920));
                    
                    //#line 250 . "x10/compiler/Foreach.x10"
                    break __ret$111909;
                }
                
                //#line 251 . "x10/compiler/Foreach.x10"
                final long t$112526 = ((long)(((int)(nthreads$111894))));
                
                //#line 251 . "x10/compiler/Foreach.x10"
                final long blockSize$111896 = ((numElems$111895) / (((long)(t$112526))));
                
                //#line 252 . "x10/compiler/Foreach.x10"
                final long t$112527 = ((long)(((int)(nthreads$111894))));
                
                //#line 252 . "x10/compiler/Foreach.x10"
                final long t$112528 = ((t$112527) * (((long)(blockSize$111896))));
                
                //#line 252 . "x10/compiler/Foreach.x10"
                final long leftOver$111897 = ((numElems$111895) - (((long)(t$112528))));
                
                //#line 253 . "x10/compiler/Foreach.x10"
                final long t$112529 = ((long)(((int)(nthreads$111894))));
                
                //#line 253 . "x10/compiler/Foreach.x10"
                final x10.core.Rail results$111898 = ((x10.core.Rail)(x10.core.Rail.<$T>makeUnsafe($T, ((long)(t$112529)), false)));
                {
                    
                    //#line 254 . "x10/compiler/Foreach.x10"
                    x10.xrx.Runtime.ensureNotInAtomic();
                    
                    //#line 254 . "x10/compiler/Foreach.x10"
                    final x10.xrx.FinishState fs$113959 = x10.xrx.Runtime.startFinish();
                    
                    //#line 254 . "x10/compiler/Foreach.x10"
                    try {{
                        {
                            
                            //#line 254 . "x10/compiler/Foreach.x10"
                            final long t$112531 = ((long)(((int)(nthreads$111894))));
                            
                            //#line 254 . "x10/compiler/Foreach.x10"
                            long t$111899 = ((t$112531) - (((long)(1L))));
                            
                            //#line 254 . "x10/compiler/Foreach.x10"
                            for (;
                                 true;
                                 ) {
                                
                                //#line 254 . "x10/compiler/Foreach.x10"
                                final boolean t$112553 = ((t$111899) >= (((long)(0L))));
                                
                                //#line 254 . "x10/compiler/Foreach.x10"
                                if (!(t$112553)) {
                                    
                                    //#line 254 . "x10/compiler/Foreach.x10"
                                    break;
                                }
                                
                                //#line 255 . "x10/compiler/Foreach.x10"
                                final long myT$113335 = t$111899;
                                
                                //#line 256 . "x10/compiler/Foreach.x10"
                                x10.xrx.Runtime.runAsync(((x10.core.fun.VoidFun_0_0)(new x10.compiler.Foreach.$Closure$27<$T>($T, blockSize$111896, myT$113335, min$111890, leftOver$111897, identity, body, reduce, results$111898, (x10.compiler.Foreach.$Closure$27.$_9021ff2d) null))));
                                
                                //#line 254 . "x10/compiler/Foreach.x10"
                                final long t$113352 = ((t$111899) - (((long)(1L))));
                                
                                //#line 254 . "x10/compiler/Foreach.x10"
                                t$111899 = t$113352;
                            }
                        }
                    }}catch (java.lang.Throwable ct$113957) {
                        
                        //#line 254 . "x10/compiler/Foreach.x10"
                        x10.xrx.Runtime.pushException(((java.lang.Throwable)(ct$113957)));
                        
                        //#line 254 . "x10/compiler/Foreach.x10"
                        throw new java.lang.RuntimeException();
                    }finally {{
                         
                         //#line 254 . "x10/compiler/Foreach.x10"
                         x10.xrx.Runtime.stopFinish(((x10.xrx.FinishState)(fs$113959)));
                     }}
                    }
                
                //#line 262 . "x10/compiler/Foreach.x10"
                $T res$111903 = (($T)(((x10.core.Rail<$T>)results$111898).$apply$G((long)(0L))));
                
                //#line 263 . "x10/compiler/Foreach.x10"
                final long t$113362 = ((long)(((int)(nthreads$111894))));
                
                //#line 263 . "x10/compiler/Foreach.x10"
                final long i$111589max$113363 = ((t$113362) - (((long)(1L))));
                
                //#line 263 . "x10/compiler/Foreach.x10"
                long i$113359 = 1L;
                
                //#line 263 . "x10/compiler/Foreach.x10"
                for (;
                     true;
                     ) {
                    
                    //#line 263 . "x10/compiler/Foreach.x10"
                    final boolean t$113361 = ((i$113359) <= (((long)(i$111589max$113363))));
                    
                    //#line 263 . "x10/compiler/Foreach.x10"
                    if (!(t$113361)) {
                        
                        //#line 263 . "x10/compiler/Foreach.x10"
                        break;
                    }
                    
                    //#line 264 . "x10/compiler/Foreach.x10"
                    final $T t$113354 = (($T)(((x10.core.Rail<$T>)results$111898).$apply$G((long)(i$113359))));
                    
                    //#line 264 . "x10/compiler/Foreach.x10"
                    final $T t$113355 = (($T)((($T)
                                                ((x10.core.fun.Fun_0_2<$T,$T,$T>)reduce$111893).$apply(res$111903, $T, t$113354, $T))));
                    
                    //#line 264 . "x10/compiler/Foreach.x10"
                    res$111903 = (($T)(t$113355));
                    
                    //#line 263 . "x10/compiler/Foreach.x10"
                    final long t$113358 = ((i$113359) + (((long)(1L))));
                    
                    //#line 263 . "x10/compiler/Foreach.x10"
                    i$113359 = t$113358;
                }
                
                //#line 266 . "x10/compiler/Foreach.x10"
                ret$111908 = (($T)(res$111903));
                
                //#line 266 . "x10/compiler/Foreach.x10"
                break __ret$111909;
                }
            }
        
        //#line 292 "x10/compiler/Foreach.x10"
        return ret$111908;
        }
    
    
    //#line 306 "x10/compiler/Foreach.x10"
    /**
     * Iterate over a range of indices in parallel using a block decomposition.
     * <code>Runtime.NTHREADS</code> activities are created, one for each
     * worker thread.  Each activity executes sequentially over all indices in
     * a contiguous block, and the blocks are of approximately equal size.
     * @param min0 the minimum value of the first index dimension
     * @param max0 the maximum value of the first index dimension
     * @param min1 the minimum value of the second index dimension
     * @param max1 the maximum value of the second index dimension
     * @param body a closure that executes over a single index [i,j]
     */
    public static void block__4$1x10$lang$Long$3x10$lang$Long$2(final long min0, final long max0, final long min1, final long max1, final x10.core.fun.VoidFun_0_2<x10.core.Long,x10.core.Long> body) {
        
        //#line 309 "x10/compiler/Foreach.x10"
        final x10.array.DenseIterationSpace_2 alloc$111424 = ((x10.array.DenseIterationSpace_2)(new x10.array.DenseIterationSpace_2((java.lang.System[]) null)));
        
        //#line 309 "x10/compiler/Foreach.x10"
        alloc$111424.x10$array$DenseIterationSpace_2$$init$S(((long)(min0)), ((long)(min1)), ((long)(max0)), ((long)(max1)));
        
        //#line 309 "x10/compiler/Foreach.x10"
        final x10.array.DenseIterationSpace_2 space$111934 = ((x10.array.DenseIterationSpace_2)(alloc$111424));
        
        //#line 309 "x10/compiler/Foreach.x10"
        final x10.core.fun.VoidFun_0_2 body$111935 = ((x10.core.fun.VoidFun_0_2)(body));
        
        //#line 323 . "x10/compiler/Foreach.x10"
        final int t$113414 = x10.xrx.Runtime.get$NTHREADS();
        
        //#line 323 . "x10/compiler/Foreach.x10"
        final boolean t$113415 = ((int) t$113414) == ((int) 1);
        
        //#line 323 . "x10/compiler/Foreach.x10"
        if (t$113415) {
            
            //#line 94 .. "x10/compiler/Foreach.x10"
            final long min$113380 = alloc$111424.min0;
            
            //#line 94 .. "x10/compiler/Foreach.x10"
            final long max$113381 = alloc$111424.max0;
            
            //#line 94 .. "x10/compiler/Foreach.x10"
            final long min$113382 = alloc$111424.min1;
            
            //#line 94 .. "x10/compiler/Foreach.x10"
            final long max$113383 = alloc$111424.max1;
            
            //#line 66 ... "x10/compiler/Foreach.x10"
            long i$113375 = min$113380;
            
            //#line 66 ... "x10/compiler/Foreach.x10"
            for (;
                 true;
                 ) {
                
                //#line 66 ... "x10/compiler/Foreach.x10"
                final boolean t$113377 = ((i$113375) <= (((long)(max$113381))));
                
                //#line 66 ... "x10/compiler/Foreach.x10"
                if (!(t$113377)) {
                    
                    //#line 66 ... "x10/compiler/Foreach.x10"
                    break;
                }
                
                //#line 67 ... "x10/compiler/Foreach.x10"
                long i$113367 = min$113382;
                
                //#line 67 ... "x10/compiler/Foreach.x10"
                for (;
                     true;
                     ) {
                    
                    //#line 67 ... "x10/compiler/Foreach.x10"
                    final boolean t$113369 = ((i$113367) <= (((long)(max$113383))));
                    
                    //#line 67 ... "x10/compiler/Foreach.x10"
                    if (!(t$113369)) {
                        
                        //#line 67 ... "x10/compiler/Foreach.x10"
                        break;
                    }
                    
                    //#line 68 ... "x10/compiler/Foreach.x10"
                    ((x10.core.fun.VoidFun_0_2<x10.core.Long,x10.core.Long>)body).$apply(x10.core.Long.$box(i$113375), x10.rtt.Types.LONG, x10.core.Long.$box(i$113367), x10.rtt.Types.LONG);
                    
                    //#line 67 ... "x10/compiler/Foreach.x10"
                    final long t$113366 = ((i$113367) + (((long)(1L))));
                    
                    //#line 67 ... "x10/compiler/Foreach.x10"
                    i$113367 = t$113366;
                }
                
                //#line 66 ... "x10/compiler/Foreach.x10"
                final long t$113374 = ((i$113375) + (((long)(1L))));
                
                //#line 66 ... "x10/compiler/Foreach.x10"
                i$113375 = t$113374;
            }
        } else {
            {
                
                //#line 326 . "x10/compiler/Foreach.x10"
                x10.xrx.Runtime.ensureNotInAtomic();
                
                //#line 326 . "x10/compiler/Foreach.x10"
                final x10.xrx.FinishState fs$113965 = x10.xrx.Runtime.startFinish();
                
                //#line 326 . "x10/compiler/Foreach.x10"
                try {{
                    {
                        
                        //#line 326 . "x10/compiler/Foreach.x10"
                        final int t$113418 = x10.xrx.Runtime.get$NTHREADS();
                        
                        //#line 326 . "x10/compiler/Foreach.x10"
                        final long t$113419 = ((long)(((int)(t$113418))));
                        
                        //#line 326 . "x10/compiler/Foreach.x10"
                        long t$113420 = ((t$113419) - (((long)(1L))));
                        
                        //#line 326 . "x10/compiler/Foreach.x10"
                        for (;
                             true;
                             ) {
                            
                            //#line 326 . "x10/compiler/Foreach.x10"
                            final boolean t$113422 = ((t$113420) >= (((long)(0L))));
                            
                            //#line 326 . "x10/compiler/Foreach.x10"
                            if (!(t$113422)) {
                                
                                //#line 326 . "x10/compiler/Foreach.x10"
                                break;
                            }
                            
                            //#line 327 . "x10/compiler/Foreach.x10"
                            final long myT$113406 = t$113420;
                            
                            //#line 328 . "x10/compiler/Foreach.x10"
                            x10.xrx.Runtime.runAsync(((x10.core.fun.VoidFun_0_0)(new x10.compiler.Foreach.$Closure$28(space$111934, myT$113406, body$111935, (x10.compiler.Foreach.$Closure$28.__2$1x10$lang$Long$3x10$lang$Long$2) null))));
                            
                            //#line 326 . "x10/compiler/Foreach.x10"
                            final long t$113413 = ((t$113420) - (((long)(1L))));
                            
                            //#line 326 . "x10/compiler/Foreach.x10"
                            t$113420 = t$113413;
                        }
                    }
                }}catch (java.lang.Throwable ct$113963) {
                    
                    //#line 326 . "x10/compiler/Foreach.x10"
                    x10.xrx.Runtime.pushException(((java.lang.Throwable)(ct$113963)));
                    
                    //#line 326 . "x10/compiler/Foreach.x10"
                    throw new java.lang.RuntimeException();
                }finally {{
                     
                     //#line 326 . "x10/compiler/Foreach.x10"
                     x10.xrx.Runtime.stopFinish(((x10.xrx.FinishState)(fs$113965)));
                 }}
                }
            }
        }
    
    
    //#line 321 "x10/compiler/Foreach.x10"
    /**
     * Iterate over a dense rectangular block of indices in parallel using
     * a block decomposition.
     * <code>Runtime.NTHREADS</code> activities are created, one for each
     * worker thread.  Each activity executes sequentially over all indices in
     * a contiguous block, and the blocks are of approximately equal size.
     * @param space the 2D dense space over which to iterate
     * @param body a closure that executes over a single index [i,j]
     */
    public static void block__1$1x10$lang$Long$3x10$lang$Long$2(final x10.array.DenseIterationSpace_2 space, final x10.core.fun.VoidFun_0_2<x10.core.Long,x10.core.Long> body) {
        
        //#line 323 "x10/compiler/Foreach.x10"
        final int t$112597 = x10.xrx.Runtime.get$NTHREADS();
        
        //#line 323 "x10/compiler/Foreach.x10"
        final boolean t$112627 = ((int) t$112597) == ((int) 1);
        
        //#line 323 "x10/compiler/Foreach.x10"
        if (t$112627) {
            
            //#line 94 . "x10/compiler/Foreach.x10"
            final long min$113439 = space.min0;
            
            //#line 94 . "x10/compiler/Foreach.x10"
            final long max$113440 = space.max0;
            
            //#line 94 . "x10/compiler/Foreach.x10"
            final long min$113441 = space.min1;
            
            //#line 94 . "x10/compiler/Foreach.x10"
            final long max$113442 = space.max1;
            
            //#line 66 .. "x10/compiler/Foreach.x10"
            long i$113434 = min$113439;
            
            //#line 66 .. "x10/compiler/Foreach.x10"
            for (;
                 true;
                 ) {
                
                //#line 66 .. "x10/compiler/Foreach.x10"
                final boolean t$113436 = ((i$113434) <= (((long)(max$113440))));
                
                //#line 66 .. "x10/compiler/Foreach.x10"
                if (!(t$113436)) {
                    
                    //#line 66 .. "x10/compiler/Foreach.x10"
                    break;
                }
                
                //#line 67 .. "x10/compiler/Foreach.x10"
                long i$113426 = min$113441;
                
                //#line 67 .. "x10/compiler/Foreach.x10"
                for (;
                     true;
                     ) {
                    
                    //#line 67 .. "x10/compiler/Foreach.x10"
                    final boolean t$113428 = ((i$113426) <= (((long)(max$113442))));
                    
                    //#line 67 .. "x10/compiler/Foreach.x10"
                    if (!(t$113428)) {
                        
                        //#line 67 .. "x10/compiler/Foreach.x10"
                        break;
                    }
                    
                    //#line 68 .. "x10/compiler/Foreach.x10"
                    ((x10.core.fun.VoidFun_0_2<x10.core.Long,x10.core.Long>)body).$apply(x10.core.Long.$box(i$113434), x10.rtt.Types.LONG, x10.core.Long.$box(i$113426), x10.rtt.Types.LONG);
                    
                    //#line 67 .. "x10/compiler/Foreach.x10"
                    final long t$113425 = ((i$113426) + (((long)(1L))));
                    
                    //#line 67 .. "x10/compiler/Foreach.x10"
                    i$113426 = t$113425;
                }
                
                //#line 66 .. "x10/compiler/Foreach.x10"
                final long t$113433 = ((i$113434) + (((long)(1L))));
                
                //#line 66 .. "x10/compiler/Foreach.x10"
                i$113434 = t$113433;
            }
        } else {
            {
                
                //#line 326 "x10/compiler/Foreach.x10"
                x10.xrx.Runtime.ensureNotInAtomic();
                
                //#line 326 "x10/compiler/Foreach.x10"
                final x10.xrx.FinishState fs$113971 = x10.xrx.Runtime.startFinish();
                
                //#line 326 "x10/compiler/Foreach.x10"
                try {{
                    {
                        
                        //#line 326 "x10/compiler/Foreach.x10"
                        final int t$112609 = x10.xrx.Runtime.get$NTHREADS();
                        
                        //#line 326 "x10/compiler/Foreach.x10"
                        final long t$112610 = ((long)(((int)(t$112609))));
                        
                        //#line 326 "x10/compiler/Foreach.x10"
                        long t = ((t$112610) - (((long)(1L))));
                        
                        //#line 326 "x10/compiler/Foreach.x10"
                        for (;
                             true;
                             ) {
                            
                            //#line 326 "x10/compiler/Foreach.x10"
                            final boolean t$112626 = ((t) >= (((long)(0L))));
                            
                            //#line 326 "x10/compiler/Foreach.x10"
                            if (!(t$112626)) {
                                
                                //#line 326 "x10/compiler/Foreach.x10"
                                break;
                            }
                            
                            //#line 327 "x10/compiler/Foreach.x10"
                            final long myT$113465 = t;
                            
                            //#line 328 "x10/compiler/Foreach.x10"
                            x10.xrx.Runtime.runAsync(((x10.core.fun.VoidFun_0_0)(new x10.compiler.Foreach.$Closure$29(space, myT$113465, body, (x10.compiler.Foreach.$Closure$29.__2$1x10$lang$Long$3x10$lang$Long$2) null))));
                            
                            //#line 326 "x10/compiler/Foreach.x10"
                            final long t$113472 = ((t) - (((long)(1L))));
                            
                            //#line 326 "x10/compiler/Foreach.x10"
                            t = t$113472;
                        }
                    }
                }}catch (java.lang.Throwable ct$113969) {
                    
                    //#line 326 "x10/compiler/Foreach.x10"
                    x10.xrx.Runtime.pushException(((java.lang.Throwable)(ct$113969)));
                    
                    //#line 326 "x10/compiler/Foreach.x10"
                    throw new java.lang.RuntimeException();
                }finally {{
                     
                     //#line 326 "x10/compiler/Foreach.x10"
                     x10.xrx.Runtime.stopFinish(((x10.xrx.FinishState)(fs$113971)));
                 }}
                }
            }
        }
    
    
    //#line 346 "x10/compiler/Foreach.x10"
    /**
     * Reduce over a range of indices in parallel using a block decomposition.
     * <code>Runtime.NTHREADS</code> activities are created, one for each
     * worker thread.  Each activity executes sequentially over all indices in
     * a contiguous block, and the blocks are of approximately equal size.
     * @param space the 2D dense space over which to reduce
     * @param body a closure that executes over a single index [i,j]
     * @param reduce the reduction operation
     * @param identity the identity value for the reduction operation such that reduce(identity,f)=f
     */
    public static <$T>$T blockReduce__1$1x10$lang$Long$3x10$lang$Long$3x10$compiler$Foreach$$T$2__2$1x10$compiler$Foreach$$T$3x10$compiler$Foreach$$T$3x10$compiler$Foreach$$T$2__3x10$compiler$Foreach$$T$G(final x10.rtt.Type $T, final x10.array.DenseIterationSpace_2 space, final x10.core.fun.Fun_0_2<x10.core.Long,x10.core.Long,$T> body, final x10.core.fun.Fun_0_2<$T,$T,$T> reduce, final $T identity) {
        
        //#line 349 "x10/compiler/Foreach.x10"
        final int t$112628 = x10.xrx.Runtime.get$NTHREADS();
        
        //#line 349 "x10/compiler/Foreach.x10"
        final boolean t$112679 = ((int) t$112628) == ((int) 1);
        
        //#line 349 "x10/compiler/Foreach.x10"
        if (t$112679) {
            
            //#line 139 . "x10/compiler/Foreach.x10"
            $T myRes$112012 = (($T)(identity));
            
            //#line 140 . "x10/compiler/Foreach.x10"
            final long i$111517min$113490 = space.min0;
            
            //#line 140 . "x10/compiler/Foreach.x10"
            final long i$111517max$113491 = space.max0;
            
            //#line 140 . "x10/compiler/Foreach.x10"
            long i$113487 = i$111517min$113490;
            
            //#line 140 . "x10/compiler/Foreach.x10"
            for (;
                 true;
                 ) {
                
                //#line 140 . "x10/compiler/Foreach.x10"
                final boolean t$113489 = ((i$113487) <= (((long)(i$111517max$113491))));
                
                //#line 140 . "x10/compiler/Foreach.x10"
                if (!(t$113489)) {
                    
                    //#line 140 . "x10/compiler/Foreach.x10"
                    break;
                }
                
                //#line 141 . "x10/compiler/Foreach.x10"
                final long i$111499min$113482 = space.min1;
                
                //#line 141 . "x10/compiler/Foreach.x10"
                final long i$111499max$113483 = space.max1;
                
                //#line 141 . "x10/compiler/Foreach.x10"
                long i$113479 = i$111499min$113482;
                
                //#line 141 . "x10/compiler/Foreach.x10"
                for (;
                     true;
                     ) {
                    
                    //#line 141 . "x10/compiler/Foreach.x10"
                    final boolean t$113481 = ((i$113479) <= (((long)(i$111499max$113483))));
                    
                    //#line 141 . "x10/compiler/Foreach.x10"
                    if (!(t$113481)) {
                        
                        //#line 141 . "x10/compiler/Foreach.x10"
                        break;
                    }
                    
                    //#line 142 . "x10/compiler/Foreach.x10"
                    final $T t$113474 = (($T)((($T)
                                                ((x10.core.fun.Fun_0_2<x10.core.Long,x10.core.Long,$T>)body).$apply(x10.core.Long.$box(i$113487), x10.rtt.Types.LONG, x10.core.Long.$box(i$113479), x10.rtt.Types.LONG))));
                    
                    //#line 142 . "x10/compiler/Foreach.x10"
                    final $T t$113475 = (($T)((($T)
                                                ((x10.core.fun.Fun_0_2<$T,$T,$T>)reduce).$apply(myRes$112012, $T, t$113474, $T))));
                    
                    //#line 142 . "x10/compiler/Foreach.x10"
                    myRes$112012 = (($T)(t$113475));
                    
                    //#line 141 . "x10/compiler/Foreach.x10"
                    final long t$113478 = ((i$113479) + (((long)(1L))));
                    
                    //#line 141 . "x10/compiler/Foreach.x10"
                    i$113479 = t$113478;
                }
                
                //#line 140 . "x10/compiler/Foreach.x10"
                final long t$113486 = ((i$113487) + (((long)(1L))));
                
                //#line 140 . "x10/compiler/Foreach.x10"
                i$113487 = t$113486;
            }
            
            //#line 350 "x10/compiler/Foreach.x10"
            return myRes$112012;
        } else {
            
            //#line 352 "x10/compiler/Foreach.x10"
            final int t$112643 = x10.xrx.Runtime.get$NTHREADS();
            
            //#line 352 "x10/compiler/Foreach.x10"
            final long t$112644 = ((long)(((int)(t$112643))));
            
            //#line 352 "x10/compiler/Foreach.x10"
            final x10.core.Rail results = ((x10.core.Rail)(x10.core.Rail.<$T>makeUnsafe($T, ((long)(t$112644)), false)));
            {
                
                //#line 353 "x10/compiler/Foreach.x10"
                x10.xrx.Runtime.ensureNotInAtomic();
                
                //#line 353 "x10/compiler/Foreach.x10"
                final x10.xrx.FinishState fs$113977 = x10.xrx.Runtime.startFinish();
                
                //#line 353 "x10/compiler/Foreach.x10"
                try {{
                    {
                        
                        //#line 353 "x10/compiler/Foreach.x10"
                        final int t$112646 = x10.xrx.Runtime.get$NTHREADS();
                        
                        //#line 353 "x10/compiler/Foreach.x10"
                        final long t$112647 = ((long)(((int)(t$112646))));
                        
                        //#line 353 "x10/compiler/Foreach.x10"
                        long t = ((t$112647) - (((long)(1L))));
                        
                        //#line 353 "x10/compiler/Foreach.x10"
                        for (;
                             true;
                             ) {
                            
                            //#line 353 "x10/compiler/Foreach.x10"
                            final boolean t$112667 = ((t) >= (((long)(0L))));
                            
                            //#line 353 "x10/compiler/Foreach.x10"
                            if (!(t$112667)) {
                                
                                //#line 353 "x10/compiler/Foreach.x10"
                                break;
                            }
                            
                            //#line 354 "x10/compiler/Foreach.x10"
                            final long myT$113511 = t;
                            
                            //#line 355 "x10/compiler/Foreach.x10"
                            final int t$113512 = x10.xrx.Runtime.get$NTHREADS();
                            
                            //#line 355 "x10/compiler/Foreach.x10"
                            final long t$113513 = ((long)(((int)(t$113512))));
                            
                            //#line 355 "x10/compiler/Foreach.x10"
                            final x10.array.DenseIterationSpace_2 block$113514 = ((x10.array.DenseIterationSpace_2)(x10.array.BlockingUtils.partitionBlockBlock(((x10.array.IterationSpace)(space)), (long)(t$113513), (long)(t))));
                            
                            //#line 356 "x10/compiler/Foreach.x10"
                            x10.xrx.Runtime.runAsync(((x10.core.fun.VoidFun_0_0)(new x10.compiler.Foreach.$Closure$30<$T>($T, identity, block$113514, body, reduce, results, myT$113511, (x10.compiler.Foreach.$Closure$30.$_273ec00a) null))));
                            
                            //#line 353 "x10/compiler/Foreach.x10"
                            final long t$113522 = ((t) - (((long)(1L))));
                            
                            //#line 353 "x10/compiler/Foreach.x10"
                            t = t$113522;
                        }
                    }
                }}catch (java.lang.Throwable ct$113975) {
                    
                    //#line 353 "x10/compiler/Foreach.x10"
                    x10.xrx.Runtime.pushException(((java.lang.Throwable)(ct$113975)));
                    
                    //#line 353 "x10/compiler/Foreach.x10"
                    throw new java.lang.RuntimeException();
                }finally {{
                     
                     //#line 353 "x10/compiler/Foreach.x10"
                     x10.xrx.Runtime.stopFinish(((x10.xrx.FinishState)(fs$113977)));
                 }}
                }
            
            //#line 358 "x10/compiler/Foreach.x10"
            $T res = (($T)(((x10.core.Rail<$T>)results).$apply$G((long)(0L))));
            
            //#line 359 "x10/compiler/Foreach.x10"
            final int t$113532 = x10.xrx.Runtime.get$NTHREADS();
            
            //#line 359 "x10/compiler/Foreach.x10"
            final long t$113533 = ((long)(((int)(t$113532))));
            
            //#line 359 "x10/compiler/Foreach.x10"
            final long i$111625max$113534 = ((t$113533) - (((long)(1L))));
            
            //#line 359 "x10/compiler/Foreach.x10"
            long i$113529 = 1L;
            
            //#line 359 "x10/compiler/Foreach.x10"
            for (;
                 true;
                 ) {
                
                //#line 359 "x10/compiler/Foreach.x10"
                final boolean t$113531 = ((i$113529) <= (((long)(i$111625max$113534))));
                
                //#line 359 "x10/compiler/Foreach.x10"
                if (!(t$113531)) {
                    
                    //#line 359 "x10/compiler/Foreach.x10"
                    break;
                }
                
                //#line 360 "x10/compiler/Foreach.x10"
                final $T t$113524 = (($T)(((x10.core.Rail<$T>)results).$apply$G((long)(i$113529))));
                
                //#line 360 "x10/compiler/Foreach.x10"
                final $T t$113525 = (($T)((($T)
                                            ((x10.core.fun.Fun_0_2<$T,$T,$T>)reduce).$apply(res, $T, t$113524, $T))));
                
                //#line 360 "x10/compiler/Foreach.x10"
                res = (($T)(t$113525));
                
                //#line 359 "x10/compiler/Foreach.x10"
                final long t$113528 = ((i$113529) + (((long)(1L))));
                
                //#line 359 "x10/compiler/Foreach.x10"
                i$113529 = t$113528;
            }
            
            //#line 362 "x10/compiler/Foreach.x10"
            return res;
            }
        }
    
    
    //#line 375 "x10/compiler/Foreach.x10"
    /**
     * Iterate over a range of indices in parallel using a cyclic decomposition.
     * <code>Runtime.NTHREADS</code> activities are created, one for each
     * worker thread.  Given T=Runtime.NTHREADS, activity for thread number 
     * <code>t</code> executes iterations (t, t+T, t+2 &times; T, ...).
     * @param min the minimum value of the index
     * @param max the maximum value of the index
     * @param body a closure that executes over a single value of the index
     */
    public static void cyclic__2$1x10$lang$Long$2(final long min, final long max, final x10.core.fun.VoidFun_0_1<x10.core.Long> body) {
        
        //#line 377 "x10/compiler/Foreach.x10"
        final int t$112680 = x10.xrx.Runtime.get$NTHREADS();
        
        //#line 377 "x10/compiler/Foreach.x10"
        final boolean t$112701 = ((int) t$112680) == ((int) 1);
        
        //#line 377 "x10/compiler/Foreach.x10"
        if (t$112701) {
            
            //#line 52 . "x10/compiler/Foreach.x10"
            long i$113538 = min;
            
            //#line 52 . "x10/compiler/Foreach.x10"
            for (;
                 true;
                 ) {
                
                //#line 52 . "x10/compiler/Foreach.x10"
                final boolean t$113540 = ((i$113538) <= (((long)(max))));
                
                //#line 52 . "x10/compiler/Foreach.x10"
                if (!(t$113540)) {
                    
                    //#line 52 . "x10/compiler/Foreach.x10"
                    break;
                }
                
                //#line 52 . "x10/compiler/Foreach.x10"
                ((x10.core.fun.VoidFun_0_1<x10.core.Long>)body).$apply(x10.core.Long.$box(i$113538), x10.rtt.Types.LONG);
                
                //#line 52 . "x10/compiler/Foreach.x10"
                final long t$113537 = ((i$113538) + (((long)(1L))));
                
                //#line 52 . "x10/compiler/Foreach.x10"
                i$113538 = t$113537;
            }
        } else {
            {
                
                //#line 380 "x10/compiler/Foreach.x10"
                x10.xrx.Runtime.ensureNotInAtomic();
                
                //#line 380 "x10/compiler/Foreach.x10"
                final x10.xrx.FinishState fs$113983 = x10.xrx.Runtime.startFinish();
                
                //#line 380 "x10/compiler/Foreach.x10"
                try {{
                    {
                        
                        //#line 380 "x10/compiler/Foreach.x10"
                        final int t$112686 = x10.xrx.Runtime.get$NTHREADS();
                        
                        //#line 380 "x10/compiler/Foreach.x10"
                        final long t$112687 = ((long)(((int)(t$112686))));
                        
                        //#line 380 "x10/compiler/Foreach.x10"
                        final long i$111643max$111645 = ((t$112687) - (((long)(1L))));
                        
                        //#line 380 "x10/compiler/Foreach.x10"
                        long i$113554 = 0L;
                        
                        //#line 380 "x10/compiler/Foreach.x10"
                        for (;
                             true;
                             ) {
                            
                            //#line 380 "x10/compiler/Foreach.x10"
                            final boolean t$113556 = ((i$113554) <= (((long)(i$111643max$111645))));
                            
                            //#line 380 "x10/compiler/Foreach.x10"
                            if (!(t$113556)) {
                                
                                //#line 380 "x10/compiler/Foreach.x10"
                                break;
                            }
                            
                            //#line 380 "x10/compiler/Foreach.x10"
                            final long t$113551 = i$113554;
                            
                            //#line 380 "x10/compiler/Foreach.x10"
                            x10.xrx.Runtime.runAsync(((x10.core.fun.VoidFun_0_0)(new x10.compiler.Foreach.$Closure$31(min, t$113551, max, body, (x10.compiler.Foreach.$Closure$31.__3$1x10$lang$Long$2) null))));
                            
                            //#line 380 "x10/compiler/Foreach.x10"
                            final long t$113553 = ((i$113554) + (((long)(1L))));
                            
                            //#line 380 "x10/compiler/Foreach.x10"
                            i$113554 = t$113553;
                        }
                    }
                }}catch (java.lang.Throwable ct$113981) {
                    
                    //#line 380 "x10/compiler/Foreach.x10"
                    x10.xrx.Runtime.pushException(((java.lang.Throwable)(ct$113981)));
                    
                    //#line 380 "x10/compiler/Foreach.x10"
                    throw new java.lang.RuntimeException();
                }finally {{
                     
                     //#line 380 "x10/compiler/Foreach.x10"
                     x10.xrx.Runtime.stopFinish(((x10.xrx.FinishState)(fs$113983)));
                 }}
                }
            }
        }
    
    
    //#line 399 "x10/compiler/Foreach.x10"
    /**
     * Reduce over a range of indices in parallel using a cyclic decomposition.
     * <code>Runtime.NTHREADS</code> activities are created, one for each
     * worker thread.  Given T=Runtime.NTHREADS, activity for thread number 
     * <code>t</code> executes iterations (t, t+T, t+2 &times; T, ...).
     * @param min the minimum value of the index
     * @param max the maximum value of the index
     * @param body a closure that executes over a single value of the index
     * @param reduce the reduction operation
     * @param identity the identity value for the reduction operation such that reduce(identity,f)=f
     */
    public static <$T>$T cyclicReduce__2$1x10$lang$Long$3x10$compiler$Foreach$$T$2__3$1x10$compiler$Foreach$$T$3x10$compiler$Foreach$$T$3x10$compiler$Foreach$$T$2__4x10$compiler$Foreach$$T$G(final x10.rtt.Type $T, final long min, final long max, final x10.core.fun.Fun_0_1<x10.core.Long,$T> body, final x10.core.fun.Fun_0_2<$T,$T,$T> reduce, final $T identity) {
        
        //#line 402 "x10/compiler/Foreach.x10"
        final int t$112702 = x10.xrx.Runtime.get$NTHREADS();
        
        //#line 402 "x10/compiler/Foreach.x10"
        final boolean t$112744 = ((int) t$112702) == ((int) 1);
        
        //#line 402 "x10/compiler/Foreach.x10"
        if (t$112744) {
            
            //#line 108 . "x10/compiler/Foreach.x10"
            $T myRes$112049 = (($T)(identity));
            
            //#line 109 . "x10/compiler/Foreach.x10"
            long i$113563 = min;
            
            //#line 109 . "x10/compiler/Foreach.x10"
            for (;
                 true;
                 ) {
                
                //#line 109 . "x10/compiler/Foreach.x10"
                final boolean t$113565 = ((i$113563) <= (((long)(max))));
                
                //#line 109 . "x10/compiler/Foreach.x10"
                if (!(t$113565)) {
                    
                    //#line 109 . "x10/compiler/Foreach.x10"
                    break;
                }
                
                //#line 110 . "x10/compiler/Foreach.x10"
                final $T t$113558 = (($T)((($T)
                                            ((x10.core.fun.Fun_0_1<x10.core.Long,$T>)body).$apply(x10.core.Long.$box(i$113563), x10.rtt.Types.LONG))));
                
                //#line 110 . "x10/compiler/Foreach.x10"
                final $T t$113559 = (($T)((($T)
                                            ((x10.core.fun.Fun_0_2<$T,$T,$T>)reduce).$apply(myRes$112049, $T, t$113558, $T))));
                
                //#line 110 . "x10/compiler/Foreach.x10"
                myRes$112049 = (($T)(t$113559));
                
                //#line 109 . "x10/compiler/Foreach.x10"
                final long t$113562 = ((i$113563) + (((long)(1L))));
                
                //#line 109 . "x10/compiler/Foreach.x10"
                i$113563 = t$113562;
            }
            
            //#line 403 "x10/compiler/Foreach.x10"
            return myRes$112049;
        } else {
            
            //#line 405 "x10/compiler/Foreach.x10"
            final int t$112712 = x10.xrx.Runtime.get$NTHREADS();
            
            //#line 405 "x10/compiler/Foreach.x10"
            final long t$112713 = ((long)(((int)(t$112712))));
            
            //#line 405 "x10/compiler/Foreach.x10"
            final x10.core.Rail results = ((x10.core.Rail)(x10.core.Rail.<$T>makeUnsafe($T, ((long)(t$112713)), false)));
            {
                
                //#line 406 "x10/compiler/Foreach.x10"
                x10.xrx.Runtime.ensureNotInAtomic();
                
                //#line 406 "x10/compiler/Foreach.x10"
                final x10.xrx.FinishState fs$113989 = x10.xrx.Runtime.startFinish();
                
                //#line 406 "x10/compiler/Foreach.x10"
                try {{
                    {
                        
                        //#line 406 "x10/compiler/Foreach.x10"
                        final int t$112714 = x10.xrx.Runtime.get$NTHREADS();
                        
                        //#line 406 "x10/compiler/Foreach.x10"
                        final long t$112715 = ((long)(((int)(t$112714))));
                        
                        //#line 406 "x10/compiler/Foreach.x10"
                        final long i$111661max$111663 = ((t$112715) - (((long)(1L))));
                        
                        //#line 406 "x10/compiler/Foreach.x10"
                        long i$113584 = 0L;
                        
                        //#line 406 "x10/compiler/Foreach.x10"
                        for (;
                             true;
                             ) {
                            
                            //#line 406 "x10/compiler/Foreach.x10"
                            final boolean t$113586 = ((i$113584) <= (((long)(i$111661max$111663))));
                            
                            //#line 406 "x10/compiler/Foreach.x10"
                            if (!(t$113586)) {
                                
                                //#line 406 "x10/compiler/Foreach.x10"
                                break;
                            }
                            
                            //#line 406 "x10/compiler/Foreach.x10"
                            final long t$113581 = i$113584;
                            
                            //#line 406 "x10/compiler/Foreach.x10"
                            x10.xrx.Runtime.runAsync(((x10.core.fun.VoidFun_0_0)(new x10.compiler.Foreach.$Closure$32<$T>($T, identity, min, t$113581, max, body, reduce, results, (x10.compiler.Foreach.$Closure$32.$_eec31cb6) null))));
                            
                            //#line 406 "x10/compiler/Foreach.x10"
                            final long t$113583 = ((i$113584) + (((long)(1L))));
                            
                            //#line 406 "x10/compiler/Foreach.x10"
                            i$113584 = t$113583;
                        }
                    }
                }}catch (java.lang.Throwable ct$113987) {
                    
                    //#line 406 "x10/compiler/Foreach.x10"
                    x10.xrx.Runtime.pushException(((java.lang.Throwable)(ct$113987)));
                    
                    //#line 406 "x10/compiler/Foreach.x10"
                    throw new java.lang.RuntimeException();
                }finally {{
                     
                     //#line 406 "x10/compiler/Foreach.x10"
                     x10.xrx.Runtime.stopFinish(((x10.xrx.FinishState)(fs$113989)));
                 }}
                }
            
            //#line 413 "x10/compiler/Foreach.x10"
            $T res = (($T)(((x10.core.Rail<$T>)results).$apply$G((long)(0L))));
            
            //#line 414 "x10/compiler/Foreach.x10"
            final int t$113596 = x10.xrx.Runtime.get$NTHREADS();
            
            //#line 414 "x10/compiler/Foreach.x10"
            final long t$113597 = ((long)(((int)(t$113596))));
            
            //#line 414 "x10/compiler/Foreach.x10"
            final long i$111679max$113598 = ((t$113597) - (((long)(1L))));
            
            //#line 414 "x10/compiler/Foreach.x10"
            long i$113593 = 1L;
            
            //#line 414 "x10/compiler/Foreach.x10"
            for (;
                 true;
                 ) {
                
                //#line 414 "x10/compiler/Foreach.x10"
                final boolean t$113595 = ((i$113593) <= (((long)(i$111679max$113598))));
                
                //#line 414 "x10/compiler/Foreach.x10"
                if (!(t$113595)) {
                    
                    //#line 414 "x10/compiler/Foreach.x10"
                    break;
                }
                
                //#line 415 "x10/compiler/Foreach.x10"
                final $T t$113588 = (($T)(((x10.core.Rail<$T>)results).$apply$G((long)(i$113593))));
                
                //#line 415 "x10/compiler/Foreach.x10"
                final $T t$113589 = (($T)((($T)
                                            ((x10.core.fun.Fun_0_2<$T,$T,$T>)reduce).$apply(res, $T, t$113588, $T))));
                
                //#line 415 "x10/compiler/Foreach.x10"
                res = (($T)(t$113589));
                
                //#line 414 "x10/compiler/Foreach.x10"
                final long t$113592 = ((i$113593) + (((long)(1L))));
                
                //#line 414 "x10/compiler/Foreach.x10"
                i$113593 = t$113592;
            }
            
            //#line 417 "x10/compiler/Foreach.x10"
            return res;
            }
        }
    
    
    //#line 431 "x10/compiler/Foreach.x10"
    /**
     * Iterate over a range of indices in parallel using recursive bisection.
     * The range is divided into two approximately equal pieces, with each 
     * piece constituting an activity. Bisection recurs until each activity is
     * less than or equal to a maximum grain size.
     * @param min the minimum value of the index
     * @param max the maximum value of the index
     * @param grainSize the maximum grain size for an activity
     * @param body a closure that executes over a contiguous range of indices
     */
    public static void bisect__3$1x10$lang$Long$3x10$lang$Long$2(final long min, final long max, final long grainSize, final x10.core.fun.VoidFun_0_2<x10.core.Long,x10.core.Long> body) {
        
        //#line 434 "x10/compiler/Foreach.x10"
        final int t$112745 = x10.xrx.Runtime.get$NTHREADS();
        
        //#line 434 "x10/compiler/Foreach.x10"
        final boolean t$112747 = ((int) t$112745) == ((int) 1);
        
        //#line 434 "x10/compiler/Foreach.x10"
        if (t$112747) {
            
            //#line 83 . "x10/compiler/Foreach.x10"
            ((x10.core.fun.VoidFun_0_2<x10.core.Long,x10.core.Long>)body).$apply(x10.core.Long.$box(min), x10.rtt.Types.LONG, x10.core.Long.$box(max), x10.rtt.Types.LONG);
        } else {
            {
                
                //#line 437 "x10/compiler/Foreach.x10"
                x10.xrx.Runtime.ensureNotInAtomic();
                
                //#line 437 "x10/compiler/Foreach.x10"
                final x10.xrx.FinishState fs$113993 = x10.xrx.Runtime.startFinish();
                
                //#line 437 "x10/compiler/Foreach.x10"
                try {{
                    {
                        
                        //#line 437 "x10/compiler/Foreach.x10"
                        final long t$112746 = ((max) + (((long)(1L))));
                        
                        //#line 437 "x10/compiler/Foreach.x10"
                        x10.compiler.Foreach.doBisect1D__3$1x10$lang$Long$3x10$lang$Long$2((long)(min), (long)(t$112746), (long)(grainSize), ((x10.core.fun.VoidFun_0_2)(body)));
                    }
                }}catch (java.lang.Throwable ct$113991) {
                    
                    //#line 437 "x10/compiler/Foreach.x10"
                    x10.xrx.Runtime.pushException(((java.lang.Throwable)(ct$113991)));
                    
                    //#line 437 "x10/compiler/Foreach.x10"
                    throw new java.lang.RuntimeException();
                }finally {{
                     
                     //#line 437 "x10/compiler/Foreach.x10"
                     x10.xrx.Runtime.stopFinish(((x10.xrx.FinishState)(fs$113993)));
                 }}
                }
            }
        }
    
    
    //#line 450 "x10/compiler/Foreach.x10"
    /**
     * Iterate over a range of indices in parallel using recursive bisection.
     * The range is divided into two approximately equal pieces, with each 
     * piece constituting an activity. Bisection recurs until a minimum grain
     * size of (max-min+1) / (Runtime.NTHREADS &times; 8) is reached.
     * @param min the minimum value of the index
     * @param max the maximum value of the index
     * @param body a closure that executes over a contiguous range of indices
     */
    public static void bisect__2$1x10$lang$Long$3x10$lang$Long$2(final long min, final long max, final x10.core.fun.VoidFun_0_2<x10.core.Long,x10.core.Long> body) {
        
        //#line 452 "x10/compiler/Foreach.x10"
        final long t$112750 = ((max) - (((long)(min))));
        
        //#line 452 "x10/compiler/Foreach.x10"
        final int t$112748 = x10.xrx.Runtime.get$NTHREADS();
        
        //#line 452 "x10/compiler/Foreach.x10"
        final long t$112749 = ((long)(((int)(t$112748))));
        
        //#line 452 "x10/compiler/Foreach.x10"
        final long t$112751 = ((t$112749) * (((long)(8L))));
        
        //#line 452 "x10/compiler/Foreach.x10"
        final long t$112752 = ((t$112750) / (((long)(t$112751))));
        
        //#line 452 "x10/compiler/Foreach.x10"
        final long grainSize = java.lang.Math.max(((long)(1L)),((long)(t$112752)));
        
        //#line 434 . "x10/compiler/Foreach.x10"
        final int t$113599 = x10.xrx.Runtime.get$NTHREADS();
        
        //#line 434 . "x10/compiler/Foreach.x10"
        final boolean t$113600 = ((int) t$113599) == ((int) 1);
        
        //#line 434 . "x10/compiler/Foreach.x10"
        if (t$113600) {
            
            //#line 83 .. "x10/compiler/Foreach.x10"
            ((x10.core.fun.VoidFun_0_2<x10.core.Long,x10.core.Long>)body).$apply(x10.core.Long.$box(min), x10.rtt.Types.LONG, x10.core.Long.$box(max), x10.rtt.Types.LONG);
        } else {
            {
                
                //#line 437 . "x10/compiler/Foreach.x10"
                x10.xrx.Runtime.ensureNotInAtomic();
                
                //#line 437 . "x10/compiler/Foreach.x10"
                final x10.xrx.FinishState fs$113997 = x10.xrx.Runtime.startFinish();
                
                //#line 437 . "x10/compiler/Foreach.x10"
                try {{
                    {
                        
                        //#line 437 . "x10/compiler/Foreach.x10"
                        final long t$113604 = ((max) + (((long)(1L))));
                        
                        //#line 437 . "x10/compiler/Foreach.x10"
                        x10.compiler.Foreach.doBisect1D__3$1x10$lang$Long$3x10$lang$Long$2((long)(min), (long)(t$113604), (long)(grainSize), ((x10.core.fun.VoidFun_0_2)(body)));
                    }
                }}catch (java.lang.Throwable ct$113995) {
                    
                    //#line 437 . "x10/compiler/Foreach.x10"
                    x10.xrx.Runtime.pushException(((java.lang.Throwable)(ct$113995)));
                    
                    //#line 437 . "x10/compiler/Foreach.x10"
                    throw new java.lang.RuntimeException();
                }finally {{
                     
                     //#line 437 . "x10/compiler/Foreach.x10"
                     x10.xrx.Runtime.stopFinish(((x10.xrx.FinishState)(fs$113997)));
                 }}
                }
            }
        }
    
    
    //#line 466 "x10/compiler/Foreach.x10"
    /**
     * Iterate over a range of indices in parallel using recursive bisection.
     * The range is divided into two approximately equal pieces, with each 
     * piece constituting an activity. Bisection recurs until each activity is
     * less than or equal to a maximum grain size.
     * @param min the minimum value of the index
     * @param max the maximum value of the index
     * @param grainSize the maximum grain size for an activity
     * @param body a closure that executes over a single value of the index
     */
    public static void bisect__3$1x10$lang$Long$2(final long min, final long max, final long grainSize, final x10.core.fun.VoidFun_0_1<x10.core.Long> body) {
        
        //#line 469 "x10/compiler/Foreach.x10"
        final int t$112756 = x10.xrx.Runtime.get$NTHREADS();
        
        //#line 469 "x10/compiler/Foreach.x10"
        final boolean t$112769 = ((int) t$112756) == ((int) 1);
        
        //#line 469 "x10/compiler/Foreach.x10"
        if (t$112769) {
            
            //#line 52 . "x10/compiler/Foreach.x10"
            long i$113608 = min;
            
            //#line 52 . "x10/compiler/Foreach.x10"
            for (;
                 true;
                 ) {
                
                //#line 52 . "x10/compiler/Foreach.x10"
                final boolean t$113610 = ((i$113608) <= (((long)(max))));
                
                //#line 52 . "x10/compiler/Foreach.x10"
                if (!(t$113610)) {
                    
                    //#line 52 . "x10/compiler/Foreach.x10"
                    break;
                }
                
                //#line 52 . "x10/compiler/Foreach.x10"
                ((x10.core.fun.VoidFun_0_1<x10.core.Long>)body).$apply(x10.core.Long.$box(i$113608), x10.rtt.Types.LONG);
                
                //#line 52 . "x10/compiler/Foreach.x10"
                final long t$113607 = ((i$113608) + (((long)(1L))));
                
                //#line 52 . "x10/compiler/Foreach.x10"
                i$113608 = t$113607;
            }
        } else {
            {
                
                //#line 476 "x10/compiler/Foreach.x10"
                x10.xrx.Runtime.ensureNotInAtomic();
                
                //#line 476 "x10/compiler/Foreach.x10"
                final x10.xrx.FinishState fs$114001 = x10.xrx.Runtime.startFinish();
                
                //#line 476 "x10/compiler/Foreach.x10"
                try {{
                    {
                        
                        //#line 476 "x10/compiler/Foreach.x10"
                        final long t$112767 = ((max) + (((long)(1L))));
                        
                        //#line 473 "x10/compiler/Foreach.x10"
                        final x10.core.fun.VoidFun_0_2 t$112768 = ((x10.core.fun.VoidFun_0_2)(new x10.compiler.Foreach.$Closure$33(body, (x10.compiler.Foreach.$Closure$33.__0$1x10$lang$Long$2) null)));
                        
                        //#line 476 "x10/compiler/Foreach.x10"
                        x10.compiler.Foreach.doBisect1D__3$1x10$lang$Long$3x10$lang$Long$2((long)(min), (long)(t$112767), (long)(grainSize), ((x10.core.fun.VoidFun_0_2)(t$112768)));
                    }
                }}catch (java.lang.Throwable ct$113999) {
                    
                    //#line 476 "x10/compiler/Foreach.x10"
                    x10.xrx.Runtime.pushException(((java.lang.Throwable)(ct$113999)));
                    
                    //#line 476 "x10/compiler/Foreach.x10"
                    throw new java.lang.RuntimeException();
                }finally {{
                     
                     //#line 476 "x10/compiler/Foreach.x10"
                     x10.xrx.Runtime.stopFinish(((x10.xrx.FinishState)(fs$114001)));
                 }}
                }
            }
        }
    
    
    //#line 489 "x10/compiler/Foreach.x10"
    /**
     * Iterate over a range of indices in parallel using recursive bisection.
     * The range is divided into two approximately equal pieces, with each 
     * piece constituting an activity. Bisection recurs until a minimum grain
     * size of (max-min+1) / (Runtime.NTHREADS &times; 8) is reached.
     * @param min the minimum value of the index
     * @param max the maximum value of the index
     * @param body a closure that executes over a contiguous range of indices
     */
    public static void bisect__2$1x10$lang$Long$2(final long min, final long max, final x10.core.fun.VoidFun_0_1<x10.core.Long> body) {
        
        //#line 491 "x10/compiler/Foreach.x10"
        final long t$112772 = ((max) - (((long)(min))));
        
        //#line 491 "x10/compiler/Foreach.x10"
        final int t$112770 = x10.xrx.Runtime.get$NTHREADS();
        
        //#line 491 "x10/compiler/Foreach.x10"
        final long t$112771 = ((long)(((int)(t$112770))));
        
        //#line 491 "x10/compiler/Foreach.x10"
        final long t$112773 = ((t$112771) * (((long)(8L))));
        
        //#line 491 "x10/compiler/Foreach.x10"
        final long t$112774 = ((t$112772) / (((long)(t$112773))));
        
        //#line 491 "x10/compiler/Foreach.x10"
        final long grainSize = java.lang.Math.max(((long)(1L)),((long)(t$112774)));
        
        //#line 492 "x10/compiler/Foreach.x10"
        final long min$112076 = min;
        
        //#line 492 "x10/compiler/Foreach.x10"
        final long grainSize$112078 = grainSize;
        
        //#line 492 "x10/compiler/Foreach.x10"
        final x10.core.fun.VoidFun_0_1 body$112079 = ((x10.core.fun.VoidFun_0_1)(body));
        
        //#line 469 . "x10/compiler/Foreach.x10"
        final int t$113633 = x10.xrx.Runtime.get$NTHREADS();
        
        //#line 469 . "x10/compiler/Foreach.x10"
        final boolean t$113634 = ((int) t$113633) == ((int) 1);
        
        //#line 469 . "x10/compiler/Foreach.x10"
        if (t$113634) {
            
            //#line 52 .. "x10/compiler/Foreach.x10"
            long i$113622 = min;
            
            //#line 52 .. "x10/compiler/Foreach.x10"
            for (;
                 true;
                 ) {
                
                //#line 52 .. "x10/compiler/Foreach.x10"
                final boolean t$113624 = ((i$113622) <= (((long)(max))));
                
                //#line 52 .. "x10/compiler/Foreach.x10"
                if (!(t$113624)) {
                    
                    //#line 52 .. "x10/compiler/Foreach.x10"
                    break;
                }
                
                //#line 52 .. "x10/compiler/Foreach.x10"
                ((x10.core.fun.VoidFun_0_1<x10.core.Long>)body).$apply(x10.core.Long.$box(i$113622), x10.rtt.Types.LONG);
                
                //#line 52 .. "x10/compiler/Foreach.x10"
                final long t$113621 = ((i$113622) + (((long)(1L))));
                
                //#line 52 .. "x10/compiler/Foreach.x10"
                i$113622 = t$113621;
            }
        } else {
            {
                
                //#line 476 . "x10/compiler/Foreach.x10"
                x10.xrx.Runtime.ensureNotInAtomic();
                
                //#line 476 . "x10/compiler/Foreach.x10"
                final x10.xrx.FinishState fs$114005 = x10.xrx.Runtime.startFinish();
                
                //#line 476 . "x10/compiler/Foreach.x10"
                try {{
                    {
                        
                        //#line 476 . "x10/compiler/Foreach.x10"
                        final long t$113638 = ((max) + (((long)(1L))));
                        
                        //#line 473 . "x10/compiler/Foreach.x10"
                        final x10.core.fun.VoidFun_0_2 t$113639 = ((x10.core.fun.VoidFun_0_2)(new x10.compiler.Foreach.$Closure$34(body$112079, (x10.compiler.Foreach.$Closure$34.__0$1x10$lang$Long$2) null)));
                        
                        //#line 476 . "x10/compiler/Foreach.x10"
                        x10.compiler.Foreach.doBisect1D__3$1x10$lang$Long$3x10$lang$Long$2((long)(min$112076), (long)(t$113638), (long)(grainSize$112078), ((x10.core.fun.VoidFun_0_2)(t$113639)));
                    }
                }}catch (java.lang.Throwable ct$114003) {
                    
                    //#line 476 . "x10/compiler/Foreach.x10"
                    x10.xrx.Runtime.pushException(((java.lang.Throwable)(ct$114003)));
                    
                    //#line 476 . "x10/compiler/Foreach.x10"
                    throw new java.lang.RuntimeException();
                }finally {{
                     
                     //#line 476 . "x10/compiler/Foreach.x10"
                     x10.xrx.Runtime.stopFinish(((x10.xrx.FinishState)(fs$114005)));
                 }}
                }
            }
        }
    
    
    //#line 495 "x10/compiler/Foreach.x10"
    private static void doBisect1D__3$1x10$lang$Long$3x10$lang$Long$2(final long start, final long end, final long grainSize, final x10.core.fun.VoidFun_0_2<x10.core.Long,x10.core.Long> body) {
        
        //#line 498 "x10/compiler/Foreach.x10"
        final long t$112789 = ((end) - (((long)(start))));
        
        //#line 498 "x10/compiler/Foreach.x10"
        final boolean t$112795 = ((t$112789) > (((long)(grainSize))));
        
        //#line 498 "x10/compiler/Foreach.x10"
        if (t$112795) {
            
            //#line 499 "x10/compiler/Foreach.x10"
            x10.xrx.Runtime.runAsync(((x10.core.fun.VoidFun_0_0)(new x10.compiler.Foreach.$Closure$35(start, end, grainSize, body, (x10.compiler.Foreach.$Closure$35.__3$1x10$lang$Long$3x10$lang$Long$2) null))));
            
            //#line 500 "x10/compiler/Foreach.x10"
            final long t$112792 = ((start) + (((long)(end))));
            
            //#line 500 "x10/compiler/Foreach.x10"
            final long t$112793 = ((t$112792) / (((long)(2L))));
            
            //#line 500 "x10/compiler/Foreach.x10"
            x10.compiler.Foreach.doBisect1D__3$1x10$lang$Long$3x10$lang$Long$2((long)(start), (long)(t$112793), (long)(grainSize), ((x10.core.fun.VoidFun_0_2)(body)));
        } else {
            
            //#line 502 "x10/compiler/Foreach.x10"
            final long t$112794 = ((end) - (((long)(1L))));
            
            //#line 502 "x10/compiler/Foreach.x10"
            ((x10.core.fun.VoidFun_0_2<x10.core.Long,x10.core.Long>)body).$apply(x10.core.Long.$box(start), x10.rtt.Types.LONG, x10.core.Long.$box(t$112794), x10.rtt.Types.LONG);
        }
    }
    
    public static void doBisect1D$P__3$1x10$lang$Long$3x10$lang$Long$2(final long start, final long end, final long grainSize, final x10.core.fun.VoidFun_0_2<x10.core.Long,x10.core.Long> body) {
        x10.compiler.Foreach.doBisect1D__3$1x10$lang$Long$3x10$lang$Long$2((long)(start), (long)(end), (long)(grainSize), ((x10.core.fun.VoidFun_0_2)(body)));
    }
    
    
    //#line 518 "x10/compiler/Foreach.x10"
    /**
     * Reduce over a range of indices in parallel using recursive bisection.
     * The range is divided into two approximately equal pieces, with each 
     * piece constituting an activity. Bisection recurs until each activity is
     * less than or equal to a maximum grain size.
     * @param min the minimum value of the index
     * @param max the maximum value of the index
     * @param grainSize the maximum grain size for an activity
     * @param body a closure that executes over a single value of the index
     * @param reduce the reduction operation
     * @param identity the identity value for the reduction operation such that reduce(identity,f)=f
     */
    public static <$T>$T bisectReduce__3$1x10$lang$Long$3x10$compiler$Foreach$$T$2__4$1x10$compiler$Foreach$$T$3x10$compiler$Foreach$$T$3x10$compiler$Foreach$$T$2__5x10$compiler$Foreach$$T$G(final x10.rtt.Type $T, final long min, final long max, final long grainSize, final x10.core.fun.Fun_0_1<x10.core.Long,$T> body, final x10.core.fun.Fun_0_2<$T,$T,$T> reduce, final $T identity) {
        
        //#line 530 "x10/compiler/Foreach.x10"
        final long min$112096 = min;
        
        //#line 530 "x10/compiler/Foreach.x10"
        final long grainSize$112098 = grainSize;
        
        //#line 530 "x10/compiler/Foreach.x10"
        final x10.core.fun.Fun_0_2 reduce$112100 = ((x10.core.fun.Fun_0_2)(reduce));
        
        //#line 545 . "x10/compiler/Foreach.x10"
        $T ret$112101 =  null;
        
        //#line 548 . "x10/compiler/Foreach.x10"
        __ret$112102: {
            
            //#line 549 . "x10/compiler/Foreach.x10"
            final int t$112796 = x10.xrx.Runtime.get$NTHREADS();
            //#line 549 . "x10/compiler/Foreach.x10"
            final boolean t$112818 = ((int) t$112796) == ((int) 1);
            //#line 549 . "x10/compiler/Foreach.x10"
            if (t$112818) {
                
                //#line 524 ... "x10/compiler/Foreach.x10"
                $T myRes$112110 = (($T)(identity));
                
                //#line 525 ... "x10/compiler/Foreach.x10"
                long i$113650 = min;
                
                //#line 525 ... "x10/compiler/Foreach.x10"
                for (;
                     true;
                     ) {
                    
                    //#line 525 ... "x10/compiler/Foreach.x10"
                    final boolean t$113652 = ((i$113650) <= (((long)(max))));
                    
                    //#line 525 ... "x10/compiler/Foreach.x10"
                    if (!(t$113652)) {
                        
                        //#line 525 ... "x10/compiler/Foreach.x10"
                        break;
                    }
                    
                    //#line 526 ... "x10/compiler/Foreach.x10"
                    final $T t$113645 = (($T)((($T)
                                                ((x10.core.fun.Fun_0_1<x10.core.Long,$T>)body).$apply(x10.core.Long.$box(i$113650), x10.rtt.Types.LONG))));
                    
                    //#line 526 ... "x10/compiler/Foreach.x10"
                    final $T t$113646 = (($T)((($T)
                                                ((x10.core.fun.Fun_0_2<$T,$T,$T>)reduce).$apply(myRes$112110, $T, t$113645, $T))));
                    
                    //#line 526 ... "x10/compiler/Foreach.x10"
                    myRes$112110 = (($T)(t$113646));
                    
                    //#line 525 ... "x10/compiler/Foreach.x10"
                    final long t$113649 = ((i$113650) + (((long)(1L))));
                    
                    //#line 525 ... "x10/compiler/Foreach.x10"
                    i$113650 = t$113649;
                }
                
                //#line 550 . "x10/compiler/Foreach.x10"
                ret$112101 = (($T)(myRes$112110));
                
                //#line 550 . "x10/compiler/Foreach.x10"
                break __ret$112102;
            } else {
                
                //#line 552 . "x10/compiler/Foreach.x10"
                final long t$112815 = ((max) + (((long)(1L))));
                
                //#line 523 "x10/compiler/Foreach.x10"
                final x10.core.fun.Fun_0_2 t$112816 = ((x10.core.fun.Fun_0_2)(new x10.compiler.Foreach.$Closure$36<$T>($T, identity, body, reduce, (x10.compiler.Foreach.$Closure$36.__0x10$compiler$Foreach$$Closure$36$$T__1$1x10$lang$Long$3x10$compiler$Foreach$$Closure$36$$T$2__2$1x10$compiler$Foreach$$Closure$36$$T$3x10$compiler$Foreach$$Closure$36$$T$3x10$compiler$Foreach$$Closure$36$$T$2) null)));
                
                //#line 552 . "x10/compiler/Foreach.x10"
                final $T t$112817 = (($T)(x10.compiler.Foreach.<$T> doBisectReduce1D__3$1x10$lang$Long$3x10$lang$Long$3x10$compiler$Foreach$$T$2__4$1x10$compiler$Foreach$$T$3x10$compiler$Foreach$$T$3x10$compiler$Foreach$$T$2$G($T, (long)(min$112096), (long)(t$112815), (long)(grainSize$112098), ((x10.core.fun.Fun_0_2)(t$112816)), ((x10.core.fun.Fun_0_2)(reduce$112100)))));
                
                //#line 552 . "x10/compiler/Foreach.x10"
                ret$112101 = (($T)(t$112817));
                
                //#line 552 . "x10/compiler/Foreach.x10"
                break __ret$112102;
            }
        }
        
        //#line 530 "x10/compiler/Foreach.x10"
        return ret$112101;
    }
    
    
    //#line 545 "x10/compiler/Foreach.x10"
    /**
     * Reduce over a range of indices in parallel using recursive bisection.
     * The range is divided into two approximately equal pieces, with each 
     * piece constituting an activity. Bisection recurs until each activity is
     * less than or equal to a maximum grain size.
     * @param min the minimum value of the index
     * @param max the maximum value of the index
     * @param grainSize the maximum grain size for an activity
     * @param body a closure that executes over a contiguous range of indices, 
     *   returning the reduced value for that range
     * @param reduce the reduction operation
     */
    public static <$T>$T bisectReduce__3$1x10$lang$Long$3x10$lang$Long$3x10$compiler$Foreach$$T$2__4$1x10$compiler$Foreach$$T$3x10$compiler$Foreach$$T$3x10$compiler$Foreach$$T$2$G(final x10.rtt.Type $T, final long min, final long max, final long grainSize, final x10.core.fun.Fun_0_2<x10.core.Long,x10.core.Long,$T> body, final x10.core.fun.Fun_0_2<$T,$T,$T> reduce) {
        
        //#line 549 "x10/compiler/Foreach.x10"
        final int t$112820 = x10.xrx.Runtime.get$NTHREADS();
        
        //#line 549 "x10/compiler/Foreach.x10"
        final boolean t$112824 = ((int) t$112820) == ((int) 1);
        
        //#line 549 "x10/compiler/Foreach.x10"
        if (t$112824) {
            
            //#line 126 . "x10/compiler/Foreach.x10"
            final $T t$112821 = (($T)((($T)
                                        ((x10.core.fun.Fun_0_2<x10.core.Long,x10.core.Long,$T>)body).$apply(x10.core.Long.$box(min), x10.rtt.Types.LONG, x10.core.Long.$box(max), x10.rtt.Types.LONG))));
            
            //#line 550 "x10/compiler/Foreach.x10"
            return t$112821;
        } else {
            
            //#line 552 "x10/compiler/Foreach.x10"
            final long t$112822 = ((max) + (((long)(1L))));
            
            //#line 552 "x10/compiler/Foreach.x10"
            final $T t$112823 = (($T)(x10.compiler.Foreach.<$T> doBisectReduce1D__3$1x10$lang$Long$3x10$lang$Long$3x10$compiler$Foreach$$T$2__4$1x10$compiler$Foreach$$T$3x10$compiler$Foreach$$T$3x10$compiler$Foreach$$T$2$G($T, (long)(min), (long)(t$112822), (long)(grainSize), ((x10.core.fun.Fun_0_2)(body)), ((x10.core.fun.Fun_0_2)(reduce)))));
            
            //#line 552 "x10/compiler/Foreach.x10"
            return t$112823;
        }
    }
    
    
    //#line 567 "x10/compiler/Foreach.x10"
    /**
     * Reduce over a range of indices in parallel using recursive bisection.
     * The range is divided into two approximately equal pieces, with each 
     * piece constituting an activity. Bisection recurs until a minimum grain
     * size of (max-min+1) / (Runtime.NTHREADS &times; 8) is reached.
     * @param min the minimum value of the index
     * @param max the maximum value of the index
     * @param body a closure that executes over a contiguous range of indices, 
     *   returning the reduced value for that range
     * @param reduce the reduction operation
     */
    public static <$T>$T bisectReduce__2$1x10$lang$Long$3x10$lang$Long$3x10$compiler$Foreach$$T$2__3$1x10$compiler$Foreach$$T$3x10$compiler$Foreach$$T$3x10$compiler$Foreach$$T$2$G(final x10.rtt.Type $T, final long min, final long max, final x10.core.fun.Fun_0_2<x10.core.Long,x10.core.Long,$T> body, final x10.core.fun.Fun_0_2<$T,$T,$T> reduce) {
        
        //#line 570 "x10/compiler/Foreach.x10"
        final long t$112827 = ((max) - (((long)(min))));
        
        //#line 570 "x10/compiler/Foreach.x10"
        final int t$112825 = x10.xrx.Runtime.get$NTHREADS();
        
        //#line 570 "x10/compiler/Foreach.x10"
        final long t$112826 = ((long)(((int)(t$112825))));
        
        //#line 570 "x10/compiler/Foreach.x10"
        final long t$112828 = ((t$112826) * (((long)(8L))));
        
        //#line 570 "x10/compiler/Foreach.x10"
        final long t$112829 = ((t$112827) / (((long)(t$112828))));
        
        //#line 570 "x10/compiler/Foreach.x10"
        final long grainSize = java.lang.Math.max(((long)(1L)),((long)(t$112829)));
        
        //#line 545 . "x10/compiler/Foreach.x10"
        $T ret$112126 =  null;
        
        //#line 548 . "x10/compiler/Foreach.x10"
        __ret$112127: {
            
            //#line 549 . "x10/compiler/Foreach.x10"
            final int t$112830 = x10.xrx.Runtime.get$NTHREADS();
            //#line 549 . "x10/compiler/Foreach.x10"
            final boolean t$112834 = ((int) t$112830) == ((int) 1);
            //#line 549 . "x10/compiler/Foreach.x10"
            if (t$112834) {
                
                //#line 126 .. "x10/compiler/Foreach.x10"
                final $T t$112831 = (($T)((($T)
                                            ((x10.core.fun.Fun_0_2<x10.core.Long,x10.core.Long,$T>)body).$apply(x10.core.Long.$box(min), x10.rtt.Types.LONG, x10.core.Long.$box(max), x10.rtt.Types.LONG))));
                
                //#line 550 . "x10/compiler/Foreach.x10"
                ret$112126 = (($T)(t$112831));
                
                //#line 550 . "x10/compiler/Foreach.x10"
                break __ret$112127;
            } else {
                
                //#line 552 . "x10/compiler/Foreach.x10"
                final long t$112832 = ((max) + (((long)(1L))));
                
                //#line 552 . "x10/compiler/Foreach.x10"
                final $T t$112833 = (($T)(x10.compiler.Foreach.<$T> doBisectReduce1D__3$1x10$lang$Long$3x10$lang$Long$3x10$compiler$Foreach$$T$2__4$1x10$compiler$Foreach$$T$3x10$compiler$Foreach$$T$3x10$compiler$Foreach$$T$2$G($T, (long)(min), (long)(t$112832), (long)(grainSize), ((x10.core.fun.Fun_0_2)(body)), ((x10.core.fun.Fun_0_2)(reduce)))));
                
                //#line 552 . "x10/compiler/Foreach.x10"
                ret$112126 = (($T)(t$112833));
                
                //#line 552 . "x10/compiler/Foreach.x10"
                break __ret$112127;
            }
        }
        
        //#line 571 "x10/compiler/Foreach.x10"
        return ret$112126;
    }
    
    
    //#line 583 "x10/compiler/Foreach.x10"
    /**
     * Reduce over a range of indices in parallel using recursive bisection.
     * The range is divided into two approximately equal pieces, with each 
     * piece constituting an activity. Bisection recurs until a minimum grain
     * size of (max-min+1) / (Runtime.NTHREADS &times; 8) is reached.
     * @param min the minimum value of the index
     * @param max the maximum value of the index
     * @param body a closure that executes over a contiguous range of indices
     */
    public static <$T>$T bisectReduce__2$1x10$lang$Long$3x10$compiler$Foreach$$T$2__3$1x10$compiler$Foreach$$T$3x10$compiler$Foreach$$T$3x10$compiler$Foreach$$T$2__4x10$compiler$Foreach$$T$G(final x10.rtt.Type $T, final long min, final long max, final x10.core.fun.Fun_0_1<x10.core.Long,$T> body, final x10.core.fun.Fun_0_2<$T,$T,$T> reduce, final $T identity) {
        
        //#line 586 "x10/compiler/Foreach.x10"
        final long t$112838 = ((max) - (((long)(min))));
        
        //#line 586 "x10/compiler/Foreach.x10"
        final int t$112836 = x10.xrx.Runtime.get$NTHREADS();
        
        //#line 586 "x10/compiler/Foreach.x10"
        final long t$112837 = ((long)(((int)(t$112836))));
        
        //#line 586 "x10/compiler/Foreach.x10"
        final long t$112839 = ((t$112837) * (((long)(8L))));
        
        //#line 586 "x10/compiler/Foreach.x10"
        final long t$112840 = ((t$112838) / (((long)(t$112839))));
        
        //#line 586 "x10/compiler/Foreach.x10"
        final long grainSize = java.lang.Math.max(((long)(1L)),((long)(t$112840)));
        
        //#line 587 "x10/compiler/Foreach.x10"
        final x10.core.fun.Fun_0_1 body$112136 = ((x10.core.fun.Fun_0_1)(body));
        
        //#line 587 "x10/compiler/Foreach.x10"
        final x10.core.fun.Fun_0_2 reduce$112137 = ((x10.core.fun.Fun_0_2)(reduce));
        
        //#line 587 "x10/compiler/Foreach.x10"
        final $T identity$112138 = (($T)(identity));
        
        //#line 518 . "x10/compiler/Foreach.x10"
        $T ret$112147 =  null;
        
        //#line 530 . "x10/compiler/Foreach.x10"
        final long min$113688 = min;
        
        //#line 530 . "x10/compiler/Foreach.x10"
        final long grainSize$113690 = grainSize;
        
        //#line 530 . "x10/compiler/Foreach.x10"
        final x10.core.fun.Fun_0_2 reduce$113691 = ((x10.core.fun.Fun_0_2)(reduce));
        
        //#line 545 .. "x10/compiler/Foreach.x10"
        $T ret$113692 =  null;
        
        //#line 548 .. "x10/compiler/Foreach.x10"
        __ret$113693: {
            
            //#line 549 .. "x10/compiler/Foreach.x10"
            final int t$113694 = x10.xrx.Runtime.get$NTHREADS();
            //#line 549 .. "x10/compiler/Foreach.x10"
            final boolean t$113695 = ((int) t$113694) == ((int) 1);
            //#line 549 .. "x10/compiler/Foreach.x10"
            if (t$113695) {
                
                //#line 524 ..... "x10/compiler/Foreach.x10"
                $T myRes$113701 = (($T)(identity));
                
                //#line 525 ..... "x10/compiler/Foreach.x10"
                long i$113672 = min;
                
                //#line 525 ..... "x10/compiler/Foreach.x10"
                for (;
                     true;
                     ) {
                    
                    //#line 525 ..... "x10/compiler/Foreach.x10"
                    final boolean t$113674 = ((i$113672) <= (((long)(max))));
                    
                    //#line 525 ..... "x10/compiler/Foreach.x10"
                    if (!(t$113674)) {
                        
                        //#line 525 ..... "x10/compiler/Foreach.x10"
                        break;
                    }
                    
                    //#line 526 ..... "x10/compiler/Foreach.x10"
                    final $T t$113667 = (($T)((($T)
                                                ((x10.core.fun.Fun_0_1<x10.core.Long,$T>)body).$apply(x10.core.Long.$box(i$113672), x10.rtt.Types.LONG))));
                    
                    //#line 526 ..... "x10/compiler/Foreach.x10"
                    final $T t$113668 = (($T)((($T)
                                                ((x10.core.fun.Fun_0_2<$T,$T,$T>)reduce).$apply(myRes$113701, $T, t$113667, $T))));
                    
                    //#line 526 ..... "x10/compiler/Foreach.x10"
                    myRes$113701 = (($T)(t$113668));
                    
                    //#line 525 ..... "x10/compiler/Foreach.x10"
                    final long t$113671 = ((i$113672) + (((long)(1L))));
                    
                    //#line 525 ..... "x10/compiler/Foreach.x10"
                    i$113672 = t$113671;
                }
                
                //#line 550 .. "x10/compiler/Foreach.x10"
                ret$113692 = (($T)(myRes$113701));
                
                //#line 550 .. "x10/compiler/Foreach.x10"
                break __ret$113693;
            } else {
                
                //#line 552 .. "x10/compiler/Foreach.x10"
                final long t$113703 = ((max) + (((long)(1L))));
                
                //#line 523 . "x10/compiler/Foreach.x10"
                final x10.core.fun.Fun_0_2 t$113704 = ((x10.core.fun.Fun_0_2)(new x10.compiler.Foreach.$Closure$37<$T>($T, identity$112138, body$112136, reduce$112137, (x10.compiler.Foreach.$Closure$37.__0x10$compiler$Foreach$$Closure$37$$T__1$1x10$lang$Long$3x10$compiler$Foreach$$Closure$37$$T$2__2$1x10$compiler$Foreach$$Closure$37$$T$3x10$compiler$Foreach$$Closure$37$$T$3x10$compiler$Foreach$$Closure$37$$T$2) null)));
                
                //#line 552 .. "x10/compiler/Foreach.x10"
                final $T t$113709 = (($T)(x10.compiler.Foreach.<$T> doBisectReduce1D__3$1x10$lang$Long$3x10$lang$Long$3x10$compiler$Foreach$$T$2__4$1x10$compiler$Foreach$$T$3x10$compiler$Foreach$$T$3x10$compiler$Foreach$$T$2$G($T, (long)(min$113688), (long)(t$113703), (long)(grainSize$113690), ((x10.core.fun.Fun_0_2)(t$113704)), ((x10.core.fun.Fun_0_2)(reduce$113691)))));
                
                //#line 552 .. "x10/compiler/Foreach.x10"
                ret$113692 = (($T)(t$113709));
                
                //#line 552 .. "x10/compiler/Foreach.x10"
                break __ret$113693;
            }
        }
        
        //#line 530 . "x10/compiler/Foreach.x10"
        ret$112147 = (($T)(ret$113692));
        
        //#line 587 "x10/compiler/Foreach.x10"
        return ret$112147;
    }
    
    
    //#line 590 "x10/compiler/Foreach.x10"
    private static <$T>$T doBisectReduce1D__3$1x10$lang$Long$3x10$lang$Long$3x10$compiler$Foreach$$T$2__4$1x10$compiler$Foreach$$T$3x10$compiler$Foreach$$T$3x10$compiler$Foreach$$T$2$G(final x10.rtt.Type $T, final long start, final long end, final long grainSize, final x10.core.fun.Fun_0_2<x10.core.Long,x10.core.Long,$T> body, final x10.core.fun.Fun_0_2<$T,$T,$T> reduce) {
        
        //#line 594 "x10/compiler/Foreach.x10"
        final long t$112866 = ((end) - (((long)(start))));
        
        //#line 594 "x10/compiler/Foreach.x10"
        final boolean t$112876 = ((t$112866) > (((long)(grainSize))));
        
        //#line 594 "x10/compiler/Foreach.x10"
        if (t$112876) {
            
            //#line 595 "x10/compiler/Foreach.x10"
            final $T asyncResult;
            
            //#line 596 "x10/compiler/Foreach.x10"
            final $T syncResult;
            {
                
                //#line 597 "x10/compiler/Foreach.x10"
                x10.xrx.Runtime.ensureNotInAtomic();
                
                //#line 597 "x10/compiler/Foreach.x10"
                final x10.xrx.FinishState fs$114013 = x10.xrx.Runtime.startFinish();
                {
                    
                    //#line 597 "x10/compiler/Foreach.x10"
                    final $T[] $asyncResult$114047 = ($T[]) new java.lang.Object[1];
                    
                    //#line 597 "x10/compiler/Foreach.x10"
                    try {{
                        {
                            
                            //#line 598 "x10/compiler/Foreach.x10"
                            x10.xrx.Runtime.runAsync(((x10.core.fun.VoidFun_0_0)(new x10.compiler.Foreach.$Closure$38<$T>($T, start, end, grainSize, body, reduce, $asyncResult$114047, (x10.compiler.Foreach.$Closure$38.__3$1x10$lang$Long$3x10$lang$Long$3x10$compiler$Foreach$$Closure$38$$T$2__4$1x10$compiler$Foreach$$Closure$38$$T$3x10$compiler$Foreach$$Closure$38$$T$3x10$compiler$Foreach$$Closure$38$$T$2) null))));
                            
                            //#line 599 "x10/compiler/Foreach.x10"
                            final long t$112870 = ((start) + (((long)(end))));
                            
                            //#line 599 "x10/compiler/Foreach.x10"
                            final long t$112871 = ((t$112870) / (((long)(2L))));
                            
                            //#line 599 "x10/compiler/Foreach.x10"
                            final $T t$112872 = (($T)(x10.compiler.Foreach.<$T> doBisectReduce1D__3$1x10$lang$Long$3x10$lang$Long$3x10$compiler$Foreach$$T$2__4$1x10$compiler$Foreach$$T$3x10$compiler$Foreach$$T$3x10$compiler$Foreach$$T$2$G($T, (long)(start), (long)(t$112871), (long)(grainSize), ((x10.core.fun.Fun_0_2)(body)), ((x10.core.fun.Fun_0_2)(reduce)))));
                            
                            //#line 599 "x10/compiler/Foreach.x10"
                            syncResult = (($T)(t$112872));
                        }
                    }}catch (java.lang.Throwable ct$114011) {
                        
                        //#line 597 "x10/compiler/Foreach.x10"
                        x10.xrx.Runtime.pushException(((java.lang.Throwable)(ct$114011)));
                        
                        //#line 597 "x10/compiler/Foreach.x10"
                        throw new java.lang.RuntimeException();
                    }finally {{
                         
                         //#line 597 "x10/compiler/Foreach.x10"
                         x10.xrx.Runtime.stopFinish(((x10.xrx.FinishState)(fs$114013)));
                     }}
                    
                    //#line 597 "x10/compiler/Foreach.x10"
                    asyncResult = (($T)((($T)$asyncResult$114047[(int)0])));
                    }
                }
            
            //#line 601 "x10/compiler/Foreach.x10"
            final $T t$112873 = (($T)((($T)
                                        ((x10.core.fun.Fun_0_2<$T,$T,$T>)reduce).$apply(syncResult, $T, asyncResult, $T))));
            
            //#line 601 "x10/compiler/Foreach.x10"
            return t$112873;
            } else {
                
                //#line 603 "x10/compiler/Foreach.x10"
                final long t$112874 = ((end) - (((long)(1L))));
                
                //#line 603 "x10/compiler/Foreach.x10"
                final $T t$112875 = (($T)((($T)
                                            ((x10.core.fun.Fun_0_2<x10.core.Long,x10.core.Long,$T>)body).$apply(x10.core.Long.$box(start), x10.rtt.Types.LONG, x10.core.Long.$box(t$112874), x10.rtt.Types.LONG))));
                
                //#line 603 "x10/compiler/Foreach.x10"
                return t$112875;
            }
        }
    
    public static <$T>$T doBisectReduce1D$P__3$1x10$lang$Long$3x10$lang$Long$3x10$compiler$Foreach$$T$2__4$1x10$compiler$Foreach$$T$3x10$compiler$Foreach$$T$3x10$compiler$Foreach$$T$2$G(final x10.rtt.Type $T, final long start, final long end, final long grainSize, final x10.core.fun.Fun_0_2<x10.core.Long,x10.core.Long,$T> body, final x10.core.fun.Fun_0_2<$T,$T,$T> reduce) {
        return x10.compiler.Foreach.<$T> doBisectReduce1D__3$1x10$lang$Long$3x10$lang$Long$3x10$compiler$Foreach$$T$2__4$1x10$compiler$Foreach$$T$3x10$compiler$Foreach$$T$3x10$compiler$Foreach$$T$2$G($T, (long)(start), (long)(end), (long)(grainSize), ((x10.core.fun.Fun_0_2)(body)), ((x10.core.fun.Fun_0_2)(reduce)));
    }
    
    
    //#line 622 "x10/compiler/Foreach.x10"
    /**
     * Iterate over a dense rectangular set of indices in parallel using 
     * two-dimensional recursive bisection. The index set is divided along the
     * largest dimension into two approximately equal pieces, with each piece  
     * constituting an activity. Bisection recurs on each subblock until each 
     * activity is smaller than or equal to a maximum grain size in each 
     * dimension.
     * @param min0 the minimum value of the first index dimension
     * @param max0 the maximum value of the first index dimension
     * @param min1 the minimum value of the second index dimension
     * @param max1 the maximum value of the second index dimension
     * @param grainSize0 the maximum grain size for the first index dimension
     * @param grainSize1 the maximum grain size for the second index dimension
     * @param body a closure that executes over a rectangular block of indices
     */
    public static void bisect__6$1x10$lang$Long$3x10$lang$Long$3x10$lang$Long$3x10$lang$Long$2(final long min0, final long max0, final long min1, final long max1, final long grainSize0, final long grainSize1, final x10.core.fun.VoidFun_0_4<x10.core.Long,x10.core.Long,x10.core.Long,x10.core.Long> body) {
        
        //#line 626 "x10/compiler/Foreach.x10"
        final int t$112877 = x10.xrx.Runtime.get$NTHREADS();
        
        //#line 626 "x10/compiler/Foreach.x10"
        final boolean t$112880 = ((int) t$112877) == ((int) 1);
        
        //#line 626 "x10/compiler/Foreach.x10"
        if (t$112880) {
            
            //#line 627 "x10/compiler/Foreach.x10"
            ((x10.core.fun.VoidFun_0_4<x10.core.Long,x10.core.Long,x10.core.Long,x10.core.Long>)body).$apply(x10.core.Long.$box(min0), x10.rtt.Types.LONG, x10.core.Long.$box(max0), x10.rtt.Types.LONG, x10.core.Long.$box(min1), x10.rtt.Types.LONG, x10.core.Long.$box(max1), x10.rtt.Types.LONG);
        } else {
            {
                
                //#line 629 "x10/compiler/Foreach.x10"
                x10.xrx.Runtime.ensureNotInAtomic();
                
                //#line 629 "x10/compiler/Foreach.x10"
                final x10.xrx.FinishState fs$114017 = x10.xrx.Runtime.startFinish();
                
                //#line 629 "x10/compiler/Foreach.x10"
                try {{
                    {
                        
                        //#line 629 "x10/compiler/Foreach.x10"
                        final long t$112878 = ((max0) + (((long)(1L))));
                        
                        //#line 629 "x10/compiler/Foreach.x10"
                        final long t$112879 = ((max1) + (((long)(1L))));
                        
                        //#line 629 "x10/compiler/Foreach.x10"
                        x10.compiler.Foreach.doBisect2D__6$1x10$lang$Long$3x10$lang$Long$3x10$lang$Long$3x10$lang$Long$2((long)(min0), (long)(t$112878), (long)(min1), (long)(t$112879), (long)(grainSize0), (long)(grainSize1), ((x10.core.fun.VoidFun_0_4)(body)));
                    }
                }}catch (java.lang.Throwable ct$114015) {
                    
                    //#line 629 "x10/compiler/Foreach.x10"
                    x10.xrx.Runtime.pushException(((java.lang.Throwable)(ct$114015)));
                    
                    //#line 629 "x10/compiler/Foreach.x10"
                    throw new java.lang.RuntimeException();
                }finally {{
                     
                     //#line 629 "x10/compiler/Foreach.x10"
                     x10.xrx.Runtime.stopFinish(((x10.xrx.FinishState)(fs$114017)));
                 }}
                }
            }
        }
    
    
    //#line 648 "x10/compiler/Foreach.x10"
    /**
     * Iterate over a dense rectangular set of indices in parallel using 
     * two-dimensional recursive bisection. The index set is divided along the
     * largest dimension into two approximately equal pieces, with each piece  
     * constituting an activity. Bisection recurs on each subblock until each 
     * activity is smaller than or equal to a grain size of 
     * (max-min+1) / Runtime.NTHREADS in each dimension.
     * <p>TODO divide each dim by N ~= sqrt(Runtime.NTHREADS &times; 8), biased
     *   towards more divisions in longer dim
     * @param min0 the minimum value of the first index dimension
     * @param max0 the maximum value of the first index dimension
     * @param min1 the minimum value of the second index dimension
     * @param max1 the maximum value of the second index dimension
     * @param body a closure that executes over a rectangular block of indices
     */
    public static void bisect__4$1x10$lang$Long$3x10$lang$Long$3x10$lang$Long$3x10$lang$Long$2(final long min0, final long max0, final long min1, final long max1, final x10.core.fun.VoidFun_0_4<x10.core.Long,x10.core.Long,x10.core.Long,x10.core.Long> body) {
        
        //#line 651 "x10/compiler/Foreach.x10"
        final long t$112882 = ((max0) - (((long)(min0))));
        
        //#line 651 "x10/compiler/Foreach.x10"
        final int t$112881 = x10.xrx.Runtime.get$NTHREADS();
        
        //#line 651 "x10/compiler/Foreach.x10"
        final long t$112883 = ((long)(((int)(t$112881))));
        
        //#line 651 "x10/compiler/Foreach.x10"
        final long t$112884 = ((t$112882) / (((long)(t$112883))));
        
        //#line 651 "x10/compiler/Foreach.x10"
        final long grainSize0 = java.lang.Math.max(((long)(1L)),((long)(t$112884)));
        
        //#line 652 "x10/compiler/Foreach.x10"
        final long t$112886 = ((max1) - (((long)(min1))));
        
        //#line 652 "x10/compiler/Foreach.x10"
        final int t$112885 = x10.xrx.Runtime.get$NTHREADS();
        
        //#line 652 "x10/compiler/Foreach.x10"
        final long t$112887 = ((long)(((int)(t$112885))));
        
        //#line 652 "x10/compiler/Foreach.x10"
        final long t$112888 = ((t$112886) / (((long)(t$112887))));
        
        //#line 652 "x10/compiler/Foreach.x10"
        final long grainSize1 = java.lang.Math.max(((long)(1L)),((long)(t$112888)));
        
        //#line 626 . "x10/compiler/Foreach.x10"
        final int t$113711 = x10.xrx.Runtime.get$NTHREADS();
        
        //#line 626 . "x10/compiler/Foreach.x10"
        final boolean t$113712 = ((int) t$113711) == ((int) 1);
        
        //#line 626 . "x10/compiler/Foreach.x10"
        if (t$113712) {
            
            //#line 627 . "x10/compiler/Foreach.x10"
            ((x10.core.fun.VoidFun_0_4<x10.core.Long,x10.core.Long,x10.core.Long,x10.core.Long>)body).$apply(x10.core.Long.$box(min0), x10.rtt.Types.LONG, x10.core.Long.$box(max0), x10.rtt.Types.LONG, x10.core.Long.$box(min1), x10.rtt.Types.LONG, x10.core.Long.$box(max1), x10.rtt.Types.LONG);
        } else {
            {
                
                //#line 629 . "x10/compiler/Foreach.x10"
                x10.xrx.Runtime.ensureNotInAtomic();
                
                //#line 629 . "x10/compiler/Foreach.x10"
                final x10.xrx.FinishState fs$114021 = x10.xrx.Runtime.startFinish();
                
                //#line 629 . "x10/compiler/Foreach.x10"
                try {{
                    {
                        
                        //#line 629 . "x10/compiler/Foreach.x10"
                        final long t$113713 = ((max0) + (((long)(1L))));
                        
                        //#line 629 . "x10/compiler/Foreach.x10"
                        final long t$113714 = ((max1) + (((long)(1L))));
                        
                        //#line 629 . "x10/compiler/Foreach.x10"
                        x10.compiler.Foreach.doBisect2D__6$1x10$lang$Long$3x10$lang$Long$3x10$lang$Long$3x10$lang$Long$2((long)(min0), (long)(t$113713), (long)(min1), (long)(t$113714), (long)(grainSize0), (long)(grainSize1), ((x10.core.fun.VoidFun_0_4)(body)));
                    }
                }}catch (java.lang.Throwable ct$114019) {
                    
                    //#line 629 . "x10/compiler/Foreach.x10"
                    x10.xrx.Runtime.pushException(((java.lang.Throwable)(ct$114019)));
                    
                    //#line 629 . "x10/compiler/Foreach.x10"
                    throw new java.lang.RuntimeException();
                }finally {{
                     
                     //#line 629 . "x10/compiler/Foreach.x10"
                     x10.xrx.Runtime.stopFinish(((x10.xrx.FinishState)(fs$114021)));
                 }}
                }
            }
        }
    
    
    //#line 671 "x10/compiler/Foreach.x10"
    /**
     * Iterate over a dense rectangular set of indices in parallel using 
     * two-dimensional recursive bisection. The index set is divided along the
     * largest dimension into two approximately equal pieces, with each piece  
     * constituting an activity. Bisection recurs on each subblock until each 
     * activity is smaller than or equal to a maximum grain size in each 
     * dimension.
     * @param min0 the minimum value of the first index dimension
     * @param max0 the maximum value of the first index dimension
     * @param min1 the minimum value of the second index dimension
     * @param max1 the maximum value of the second index dimension
     * @param grainSize0 the maximum grain size for the first index dimension
     * @param grainSize1 the maximum grain size for the second index dimension
     * @param body a closure that executes over a single index [i,j]
     */
    public static void bisect__6$1x10$lang$Long$3x10$lang$Long$2(final long min0, final long max0, final long min1, final long max1, final long grainSize0, final long grainSize1, final x10.core.fun.VoidFun_0_2<x10.core.Long,x10.core.Long> body) {
        
        //#line 681 "x10/compiler/Foreach.x10"
        final long min$112177 = min0;
        
        //#line 681 "x10/compiler/Foreach.x10"
        final long min$112179 = min1;
        
        //#line 681 "x10/compiler/Foreach.x10"
        final long grainSize$112181 = grainSize0;
        
        //#line 681 "x10/compiler/Foreach.x10"
        final long grainSize$112182 = grainSize1;
        
        //#line 626 . "x10/compiler/Foreach.x10"
        final int t$113745 = x10.xrx.Runtime.get$NTHREADS();
        
        //#line 626 . "x10/compiler/Foreach.x10"
        final boolean t$113746 = ((int) t$113745) == ((int) 1);
        
        //#line 626 . "x10/compiler/Foreach.x10"
        if (t$113746) {
            
            //#line 677 .. "x10/compiler/Foreach.x10"
            long i$113726 = min0;
            
            //#line 677 .. "x10/compiler/Foreach.x10"
            for (;
                 true;
                 ) {
                
                //#line 677 .. "x10/compiler/Foreach.x10"
                final boolean t$113728 = ((i$113726) <= (((long)(max0))));
                
                //#line 677 .. "x10/compiler/Foreach.x10"
                if (!(t$113728)) {
                    
                    //#line 677 .. "x10/compiler/Foreach.x10"
                    break;
                }
                
                //#line 678 .. "x10/compiler/Foreach.x10"
                long i$113718 = min1;
                
                //#line 678 .. "x10/compiler/Foreach.x10"
                for (;
                     true;
                     ) {
                    
                    //#line 678 .. "x10/compiler/Foreach.x10"
                    final boolean t$113720 = ((i$113718) <= (((long)(max1))));
                    
                    //#line 678 .. "x10/compiler/Foreach.x10"
                    if (!(t$113720)) {
                        
                        //#line 678 .. "x10/compiler/Foreach.x10"
                        break;
                    }
                    
                    //#line 679 .. "x10/compiler/Foreach.x10"
                    ((x10.core.fun.VoidFun_0_2<x10.core.Long,x10.core.Long>)body).$apply(x10.core.Long.$box(i$113726), x10.rtt.Types.LONG, x10.core.Long.$box(i$113718), x10.rtt.Types.LONG);
                    
                    //#line 678 .. "x10/compiler/Foreach.x10"
                    final long t$113717 = ((i$113718) + (((long)(1L))));
                    
                    //#line 678 .. "x10/compiler/Foreach.x10"
                    i$113718 = t$113717;
                }
                
                //#line 677 .. "x10/compiler/Foreach.x10"
                final long t$113725 = ((i$113726) + (((long)(1L))));
                
                //#line 677 .. "x10/compiler/Foreach.x10"
                i$113726 = t$113725;
            }
        } else {
            {
                
                //#line 629 . "x10/compiler/Foreach.x10"
                x10.xrx.Runtime.ensureNotInAtomic();
                
                //#line 629 . "x10/compiler/Foreach.x10"
                final x10.xrx.FinishState fs$114025 = x10.xrx.Runtime.startFinish();
                
                //#line 629 . "x10/compiler/Foreach.x10"
                try {{
                    {
                        
                        //#line 629 . "x10/compiler/Foreach.x10"
                        final long t$113751 = ((max0) + (((long)(1L))));
                        
                        //#line 629 . "x10/compiler/Foreach.x10"
                        final long t$113752 = ((max1) + (((long)(1L))));
                        
                        //#line 676 "x10/compiler/Foreach.x10"
                        final x10.core.fun.VoidFun_0_4 t$113753 = ((x10.core.fun.VoidFun_0_4)(new x10.compiler.Foreach.$Closure$39(body, (x10.compiler.Foreach.$Closure$39.__0$1x10$lang$Long$3x10$lang$Long$2) null)));
                        
                        //#line 629 . "x10/compiler/Foreach.x10"
                        x10.compiler.Foreach.doBisect2D__6$1x10$lang$Long$3x10$lang$Long$3x10$lang$Long$3x10$lang$Long$2((long)(min$112177), (long)(t$113751), (long)(min$112179), (long)(t$113752), (long)(grainSize$112181), (long)(grainSize$112182), ((x10.core.fun.VoidFun_0_4)(t$113753)));
                    }
                }}catch (java.lang.Throwable ct$114023) {
                    
                    //#line 629 . "x10/compiler/Foreach.x10"
                    x10.xrx.Runtime.pushException(((java.lang.Throwable)(ct$114023)));
                    
                    //#line 629 . "x10/compiler/Foreach.x10"
                    throw new java.lang.RuntimeException();
                }finally {{
                     
                     //#line 629 . "x10/compiler/Foreach.x10"
                     x10.xrx.Runtime.stopFinish(((x10.xrx.FinishState)(fs$114025)));
                 }}
                }
            }
        }
    
    
    //#line 699 "x10/compiler/Foreach.x10"
    /**
     * Iterate over a dense rectangular set of indices in parallel using 
     * two-dimensional recursive bisection. The index set is divided along the
     * largest dimension into two approximately equal pieces, with each piece  
     * constituting an activity. Bisection recurs on each subblock until each 
     * activity is smaller than or equal to a grain size of 
     * (max-min+1) / Runtime.NTHREADS in each dimension.
     * <p>TODO divide each dim by N ~= sqrt(Runtime.NTHREADS &times; 8), biased
     *   towards more divisions in longer dim
     * @param min0 the minimum value of the first index dimension
     * @param max0 the maximum value of the first index dimension
     * @param min1 the minimum value of the second index dimension
     * @param max1 the maximum value of the second index dimension
     * @param body a closure that executes over a single index [i,j]
     */
    public static void bisect__4$1x10$lang$Long$3x10$lang$Long$2(final long min0, final long max0, final long min1, final long max1, final x10.core.fun.VoidFun_0_2<x10.core.Long,x10.core.Long> body) {
        
        //#line 702 "x10/compiler/Foreach.x10"
        final long t$112919 = ((max0) - (((long)(min0))));
        
        //#line 702 "x10/compiler/Foreach.x10"
        final int t$112918 = x10.xrx.Runtime.get$NTHREADS();
        
        //#line 702 "x10/compiler/Foreach.x10"
        final long t$112920 = ((long)(((int)(t$112918))));
        
        //#line 702 "x10/compiler/Foreach.x10"
        final long t$112921 = ((t$112919) / (((long)(t$112920))));
        
        //#line 702 "x10/compiler/Foreach.x10"
        final long grainSize0 = java.lang.Math.max(((long)(1L)),((long)(t$112921)));
        
        //#line 703 "x10/compiler/Foreach.x10"
        final long t$112923 = ((max1) - (((long)(min1))));
        
        //#line 703 "x10/compiler/Foreach.x10"
        final int t$112922 = x10.xrx.Runtime.get$NTHREADS();
        
        //#line 703 "x10/compiler/Foreach.x10"
        final long t$112924 = ((long)(((int)(t$112922))));
        
        //#line 703 "x10/compiler/Foreach.x10"
        final long t$112925 = ((t$112923) / (((long)(t$112924))));
        
        //#line 703 "x10/compiler/Foreach.x10"
        final long grainSize1 = java.lang.Math.max(((long)(1L)),((long)(t$112925)));
        
        //#line 704 "x10/compiler/Foreach.x10"
        final x10.core.fun.VoidFun_0_2 body$112204 = ((x10.core.fun.VoidFun_0_2)(body));
        
        //#line 681 . "x10/compiler/Foreach.x10"
        final long min$113805 = min0;
        
        //#line 681 . "x10/compiler/Foreach.x10"
        final long min$113807 = min1;
        
        //#line 681 . "x10/compiler/Foreach.x10"
        final long grainSize$113809 = grainSize0;
        
        //#line 681 . "x10/compiler/Foreach.x10"
        final long grainSize$113810 = grainSize1;
        
        //#line 626 .. "x10/compiler/Foreach.x10"
        final int t$113790 = x10.xrx.Runtime.get$NTHREADS();
        
        //#line 626 .. "x10/compiler/Foreach.x10"
        final boolean t$113791 = ((int) t$113790) == ((int) 1);
        
        //#line 626 .. "x10/compiler/Foreach.x10"
        if (t$113791) {
            
            //#line 677 .... "x10/compiler/Foreach.x10"
            long i$113771 = min0;
            
            //#line 677 .... "x10/compiler/Foreach.x10"
            for (;
                 true;
                 ) {
                
                //#line 677 .... "x10/compiler/Foreach.x10"
                final boolean t$113773 = ((i$113771) <= (((long)(max0))));
                
                //#line 677 .... "x10/compiler/Foreach.x10"
                if (!(t$113773)) {
                    
                    //#line 677 .... "x10/compiler/Foreach.x10"
                    break;
                }
                
                //#line 678 .... "x10/compiler/Foreach.x10"
                long i$113763 = min1;
                
                //#line 678 .... "x10/compiler/Foreach.x10"
                for (;
                     true;
                     ) {
                    
                    //#line 678 .... "x10/compiler/Foreach.x10"
                    final boolean t$113765 = ((i$113763) <= (((long)(max1))));
                    
                    //#line 678 .... "x10/compiler/Foreach.x10"
                    if (!(t$113765)) {
                        
                        //#line 678 .... "x10/compiler/Foreach.x10"
                        break;
                    }
                    
                    //#line 679 .... "x10/compiler/Foreach.x10"
                    ((x10.core.fun.VoidFun_0_2<x10.core.Long,x10.core.Long>)body).$apply(x10.core.Long.$box(i$113771), x10.rtt.Types.LONG, x10.core.Long.$box(i$113763), x10.rtt.Types.LONG);
                    
                    //#line 678 .... "x10/compiler/Foreach.x10"
                    final long t$113762 = ((i$113763) + (((long)(1L))));
                    
                    //#line 678 .... "x10/compiler/Foreach.x10"
                    i$113763 = t$113762;
                }
                
                //#line 677 .... "x10/compiler/Foreach.x10"
                final long t$113770 = ((i$113771) + (((long)(1L))));
                
                //#line 677 .... "x10/compiler/Foreach.x10"
                i$113771 = t$113770;
            }
        } else {
            {
                
                //#line 629 .. "x10/compiler/Foreach.x10"
                x10.xrx.Runtime.ensureNotInAtomic();
                
                //#line 629 .. "x10/compiler/Foreach.x10"
                final x10.xrx.FinishState fs$114029 = x10.xrx.Runtime.startFinish();
                
                //#line 629 .. "x10/compiler/Foreach.x10"
                try {{
                    {
                        
                        //#line 629 .. "x10/compiler/Foreach.x10"
                        final long t$113796 = ((max0) + (((long)(1L))));
                        
                        //#line 629 .. "x10/compiler/Foreach.x10"
                        final long t$113797 = ((max1) + (((long)(1L))));
                        
                        //#line 676 . "x10/compiler/Foreach.x10"
                        final x10.core.fun.VoidFun_0_4 t$113798 = ((x10.core.fun.VoidFun_0_4)(new x10.compiler.Foreach.$Closure$40(body$112204, (x10.compiler.Foreach.$Closure$40.__0$1x10$lang$Long$3x10$lang$Long$2) null)));
                        
                        //#line 629 .. "x10/compiler/Foreach.x10"
                        x10.compiler.Foreach.doBisect2D__6$1x10$lang$Long$3x10$lang$Long$3x10$lang$Long$3x10$lang$Long$2((long)(min$113805), (long)(t$113796), (long)(min$113807), (long)(t$113797), (long)(grainSize$113809), (long)(grainSize$113810), ((x10.core.fun.VoidFun_0_4)(t$113798)));
                    }
                }}catch (java.lang.Throwable ct$114027) {
                    
                    //#line 629 .. "x10/compiler/Foreach.x10"
                    x10.xrx.Runtime.pushException(((java.lang.Throwable)(ct$114027)));
                    
                    //#line 629 .. "x10/compiler/Foreach.x10"
                    throw new java.lang.RuntimeException();
                }finally {{
                     
                     //#line 629 .. "x10/compiler/Foreach.x10"
                     x10.xrx.Runtime.stopFinish(((x10.xrx.FinishState)(fs$114029)));
                 }}
                }
            }
        }
    
    
    //#line 711 "x10/compiler/Foreach.x10"
    /**
     * Perform a parallel iteration using recursive bisection.
     * Do not wait for termination.
     */
    private static void doBisect2D__6$1x10$lang$Long$3x10$lang$Long$3x10$lang$Long$3x10$lang$Long$2(final long s0, final long e0, final long s1, final long e1, final long g1, final long g2, final x10.core.fun.VoidFun_0_4<x10.core.Long,x10.core.Long,x10.core.Long,x10.core.Long> body) {
        
        //#line 715 "x10/compiler/Foreach.x10"
        final long t$112951 = ((e0) - (((long)(s0))));
        
        //#line 715 "x10/compiler/Foreach.x10"
        boolean t$112956 = ((t$112951) > (((long)(g1))));
        
        //#line 715 "x10/compiler/Foreach.x10"
        if (t$112956) {
            
            //#line 715 "x10/compiler/Foreach.x10"
            final long t$112952 = ((e0) - (((long)(s0))));
            
            //#line 715 "x10/compiler/Foreach.x10"
            final long t$112953 = ((e1) - (((long)(s1))));
            
            //#line 715 "x10/compiler/Foreach.x10"
            boolean t$112955 = ((t$112952) >= (((long)(t$112953))));
            
            //#line 715 "x10/compiler/Foreach.x10"
            if (!(t$112955)) {
                
                //#line 715 "x10/compiler/Foreach.x10"
                final long t$112954 = ((e1) - (((long)(s1))));
                
                //#line 715 "x10/compiler/Foreach.x10"
                t$112955 = ((t$112954) <= (((long)(g2))));
            }
            
            //#line 715 "x10/compiler/Foreach.x10"
            t$112956 = t$112955;
        }
        
        //#line 715 "x10/compiler/Foreach.x10"
        if (t$112956) {
            
            //#line 716 "x10/compiler/Foreach.x10"
            x10.xrx.Runtime.runAsync(((x10.core.fun.VoidFun_0_0)(new x10.compiler.Foreach.$Closure$41(s0, e0, s1, e1, g1, g2, body, (x10.compiler.Foreach.$Closure$41.__6$1x10$lang$Long$3x10$lang$Long$3x10$lang$Long$3x10$lang$Long$2) null))));
            
            //#line 717 "x10/compiler/Foreach.x10"
            final long t$112959 = ((s0) + (((long)(e0))));
            
            //#line 717 "x10/compiler/Foreach.x10"
            final long t$112960 = ((t$112959) / (((long)(2L))));
            
            //#line 717 "x10/compiler/Foreach.x10"
            x10.compiler.Foreach.doBisect2D__6$1x10$lang$Long$3x10$lang$Long$3x10$lang$Long$3x10$lang$Long$2((long)(s0), (long)(t$112960), (long)(s1), (long)(e1), (long)(g1), (long)(g2), ((x10.core.fun.VoidFun_0_4)(body)));
        } else {
            
            //#line 718 "x10/compiler/Foreach.x10"
            final long t$112961 = ((e1) - (((long)(s1))));
            
            //#line 718 "x10/compiler/Foreach.x10"
            final boolean t$112968 = ((t$112961) > (((long)(g2))));
            
            //#line 718 "x10/compiler/Foreach.x10"
            if (t$112968) {
                
                //#line 719 "x10/compiler/Foreach.x10"
                x10.xrx.Runtime.runAsync(((x10.core.fun.VoidFun_0_0)(new x10.compiler.Foreach.$Closure$42(s1, e1, s0, e0, g1, g2, body, (x10.compiler.Foreach.$Closure$42.__6$1x10$lang$Long$3x10$lang$Long$3x10$lang$Long$3x10$lang$Long$2) null))));
                
                //#line 720 "x10/compiler/Foreach.x10"
                final long t$112964 = ((s1) + (((long)(e1))));
                
                //#line 720 "x10/compiler/Foreach.x10"
                final long t$112965 = ((t$112964) / (((long)(2L))));
                
                //#line 720 "x10/compiler/Foreach.x10"
                x10.compiler.Foreach.doBisect2D__6$1x10$lang$Long$3x10$lang$Long$3x10$lang$Long$3x10$lang$Long$2((long)(s0), (long)(e0), (long)(s1), (long)(t$112965), (long)(g1), (long)(g2), ((x10.core.fun.VoidFun_0_4)(body)));
            } else {
                
                //#line 722 "x10/compiler/Foreach.x10"
                final long t$112966 = ((e0) - (((long)(1L))));
                
                //#line 722 "x10/compiler/Foreach.x10"
                final long t$112967 = ((e1) - (((long)(1L))));
                
                //#line 722 "x10/compiler/Foreach.x10"
                ((x10.core.fun.VoidFun_0_4<x10.core.Long,x10.core.Long,x10.core.Long,x10.core.Long>)body).$apply(x10.core.Long.$box(s0), x10.rtt.Types.LONG, x10.core.Long.$box(t$112966), x10.rtt.Types.LONG, x10.core.Long.$box(s1), x10.rtt.Types.LONG, x10.core.Long.$box(t$112967), x10.rtt.Types.LONG);
            }
        }
    }
    
    public static void doBisect2D$P__6$1x10$lang$Long$3x10$lang$Long$3x10$lang$Long$3x10$lang$Long$2(final long s0, final long e0, final long s1, final long e1, final long g1, final long g2, final x10.core.fun.VoidFun_0_4<x10.core.Long,x10.core.Long,x10.core.Long,x10.core.Long> body) {
        x10.compiler.Foreach.doBisect2D__6$1x10$lang$Long$3x10$lang$Long$3x10$lang$Long$3x10$lang$Long$2((long)(s0), (long)(e0), (long)(s1), (long)(e1), (long)(g1), (long)(g2), ((x10.core.fun.VoidFun_0_4)(body)));
    }
    
    
    //#line 743 "x10/compiler/Foreach.x10"
    /**
     * Reduce over a dense rectangular set of indices in parallel using 
     * two-dimensional recursive bisection. The index set is divided along the
     * largest dimension into two approximately equal pieces, with each piece  
     * constituting an activity. Bisection recurs on each subblock until each 
     * activity is smaller than or equal to a maximum grain size in each 
     * dimension.
     * @param min0 the minimum value of the first index dimension
     * @param max0 the maximum value of the first index dimension
     * @param min1 the minimum value of the second index dimension
     * @param max1 the maximum value of the second index dimension
     * @param grainSize0 the maximum grain size for the first index dimension
     * @param grainSize1 the maximum grain size for the second index dimension
     * @param body a closure that executes over a single index [i,j]
     * @param reduce the reduction operation
     * @param identity the identity value for the reduction operation such that reduce(identity,f)=f
     */
    public static <$T>$T bisectReduce__6$1x10$lang$Long$3x10$lang$Long$3x10$compiler$Foreach$$T$2__7$1x10$compiler$Foreach$$T$3x10$compiler$Foreach$$T$3x10$compiler$Foreach$$T$2__8x10$compiler$Foreach$$T$G(final x10.rtt.Type $T, final long min0, final long max0, final long min1, final long max1, final long grainSize0, final long grainSize1, final x10.core.fun.Fun_0_2<x10.core.Long,x10.core.Long,$T> body, final x10.core.fun.Fun_0_2<$T,$T,$T> reduce, final $T identity) {
        
        //#line 748 "x10/compiler/Foreach.x10"
        final int t$112970 = x10.xrx.Runtime.get$NTHREADS();
        
        //#line 748 "x10/compiler/Foreach.x10"
        final boolean t$113003 = ((int) t$112970) == ((int) 1);
        
        //#line 748 "x10/compiler/Foreach.x10"
        if (t$113003) {
            
            //#line 749 "x10/compiler/Foreach.x10"
            final x10.array.DenseIterationSpace_2 alloc$111425 = ((x10.array.DenseIterationSpace_2)(new x10.array.DenseIterationSpace_2((java.lang.System[]) null)));
            
            //#line 749 "x10/compiler/Foreach.x10"
            alloc$111425.x10$array$DenseIterationSpace_2$$init$S(((long)(min0)), ((long)(min1)), ((long)(max0)), ((long)(max1)));
            
            //#line 139 . "x10/compiler/Foreach.x10"
            $T myRes$112244 = (($T)(identity));
            
            //#line 140 . "x10/compiler/Foreach.x10"
            final long i$111517min$113828 = alloc$111425.min0;
            
            //#line 140 . "x10/compiler/Foreach.x10"
            final long i$111517max$113829 = alloc$111425.max0;
            
            //#line 140 . "x10/compiler/Foreach.x10"
            long i$113825 = i$111517min$113828;
            
            //#line 140 . "x10/compiler/Foreach.x10"
            for (;
                 true;
                 ) {
                
                //#line 140 . "x10/compiler/Foreach.x10"
                final boolean t$113827 = ((i$113825) <= (((long)(i$111517max$113829))));
                
                //#line 140 . "x10/compiler/Foreach.x10"
                if (!(t$113827)) {
                    
                    //#line 140 . "x10/compiler/Foreach.x10"
                    break;
                }
                
                //#line 141 . "x10/compiler/Foreach.x10"
                final long i$111499min$113820 = alloc$111425.min1;
                
                //#line 141 . "x10/compiler/Foreach.x10"
                final long i$111499max$113821 = alloc$111425.max1;
                
                //#line 141 . "x10/compiler/Foreach.x10"
                long i$113817 = i$111499min$113820;
                
                //#line 141 . "x10/compiler/Foreach.x10"
                for (;
                     true;
                     ) {
                    
                    //#line 141 . "x10/compiler/Foreach.x10"
                    final boolean t$113819 = ((i$113817) <= (((long)(i$111499max$113821))));
                    
                    //#line 141 . "x10/compiler/Foreach.x10"
                    if (!(t$113819)) {
                        
                        //#line 141 . "x10/compiler/Foreach.x10"
                        break;
                    }
                    
                    //#line 142 . "x10/compiler/Foreach.x10"
                    final $T t$113812 = (($T)((($T)
                                                ((x10.core.fun.Fun_0_2<x10.core.Long,x10.core.Long,$T>)body).$apply(x10.core.Long.$box(i$113825), x10.rtt.Types.LONG, x10.core.Long.$box(i$113817), x10.rtt.Types.LONG))));
                    
                    //#line 142 . "x10/compiler/Foreach.x10"
                    final $T t$113813 = (($T)((($T)
                                                ((x10.core.fun.Fun_0_2<$T,$T,$T>)reduce).$apply(myRes$112244, $T, t$113812, $T))));
                    
                    //#line 142 . "x10/compiler/Foreach.x10"
                    myRes$112244 = (($T)(t$113813));
                    
                    //#line 141 . "x10/compiler/Foreach.x10"
                    final long t$113816 = ((i$113817) + (((long)(1L))));
                    
                    //#line 141 . "x10/compiler/Foreach.x10"
                    i$113817 = t$113816;
                }
                
                //#line 140 . "x10/compiler/Foreach.x10"
                final long t$113824 = ((i$113825) + (((long)(1L))));
                
                //#line 140 . "x10/compiler/Foreach.x10"
                i$113825 = t$113824;
            }
            
            //#line 749 "x10/compiler/Foreach.x10"
            return myRes$112244;
        } else {
            
            //#line 761 "x10/compiler/Foreach.x10"
            final long t$112999 = ((max0) + (((long)(1L))));
            
            //#line 761 "x10/compiler/Foreach.x10"
            final long t$113000 = ((max1) + (((long)(1L))));
            
            //#line 752 "x10/compiler/Foreach.x10"
            final x10.core.fun.Fun_0_4 t$113001 = ((x10.core.fun.Fun_0_4)(new x10.compiler.Foreach.$Closure$43<$T>($T, identity, body, reduce, (x10.compiler.Foreach.$Closure$43.__0x10$compiler$Foreach$$Closure$43$$T__1$1x10$lang$Long$3x10$lang$Long$3x10$compiler$Foreach$$Closure$43$$T$2__2$1x10$compiler$Foreach$$Closure$43$$T$3x10$compiler$Foreach$$Closure$43$$T$3x10$compiler$Foreach$$Closure$43$$T$2) null)));
            
            //#line 761 "x10/compiler/Foreach.x10"
            final $T t$113002 = (($T)(x10.compiler.Foreach.<$T> doBisectReduce2D__6$1x10$lang$Long$3x10$lang$Long$3x10$lang$Long$3x10$lang$Long$3x10$compiler$Foreach$$T$2__7$1x10$compiler$Foreach$$T$3x10$compiler$Foreach$$T$3x10$compiler$Foreach$$T$2$G($T, (long)(min0), (long)(t$112999), (long)(min1), (long)(t$113000), (long)(grainSize0), (long)(grainSize1), ((x10.core.fun.Fun_0_4)(t$113001)), ((x10.core.fun.Fun_0_2)(reduce)))));
            
            //#line 761 "x10/compiler/Foreach.x10"
            return t$113002;
        }
    }
    
    
    //#line 779 "x10/compiler/Foreach.x10"
    /**
     * Reduce over a dense rectangular set of indices in parallel using 
     * two-dimensional recursive bisection. The index set is divided along the
     * largest dimension into two approximately equal pieces, with each piece  
     * constituting an activity. Bisection recurs on each subblock until each 
     * activity is smaller than or equal to a maximum grain size in each 
     * dimension.
     * @param space the 2D dense space over which to reduce
     * @param grainSize0 the maximum grain size for the first index dimension
     * @param grainSize1 the maximum grain size for the second index dimension
     * @param body a closure that executes over a single index [i,j]
     * @param reduce the reduction operation
     * @param identity the identity value for the reduction operation such that reduce(identity,f)=f
     */
    public static <$T>$T bisectReduce__3$1x10$lang$Long$3x10$lang$Long$3x10$compiler$Foreach$$T$2__4$1x10$compiler$Foreach$$T$3x10$compiler$Foreach$$T$3x10$compiler$Foreach$$T$2__5x10$compiler$Foreach$$T$G(final x10.rtt.Type $T, final x10.array.DenseIterationSpace_2 space, final long grainSize0, final long grainSize1, final x10.core.fun.Fun_0_2<x10.core.Long,x10.core.Long,$T> body, final x10.core.fun.Fun_0_2<$T,$T,$T> reduce, final $T identity) {
        
        //#line 783 "x10/compiler/Foreach.x10"
        final long min$112254 = space.min0;
        
        //#line 783 "x10/compiler/Foreach.x10"
        final long max$112255 = space.max0;
        
        //#line 783 "x10/compiler/Foreach.x10"
        final long min$112256 = space.min1;
        
        //#line 783 "x10/compiler/Foreach.x10"
        final long max$112257 = space.max1;
        
        //#line 783 "x10/compiler/Foreach.x10"
        final long grainSize$112258 = grainSize0;
        
        //#line 783 "x10/compiler/Foreach.x10"
        final long grainSize$112259 = grainSize1;
        
        //#line 783 "x10/compiler/Foreach.x10"
        final x10.core.fun.Fun_0_2 body$112260 = ((x10.core.fun.Fun_0_2)(body));
        
        //#line 783 "x10/compiler/Foreach.x10"
        final x10.core.fun.Fun_0_2 reduce$112261 = ((x10.core.fun.Fun_0_2)(reduce));
        
        //#line 783 "x10/compiler/Foreach.x10"
        final $T identity$112262 = (($T)(identity));
        
        //#line 743 . "x10/compiler/Foreach.x10"
        $T ret$112278 =  null;
        
        //#line 747 . "x10/compiler/Foreach.x10"
        __ret$112279: {
            
            //#line 748 . "x10/compiler/Foreach.x10"
            final int t$113004 = x10.xrx.Runtime.get$NTHREADS();
            //#line 748 . "x10/compiler/Foreach.x10"
            final boolean t$113037 = ((int) t$113004) == ((int) 1);
            //#line 748 . "x10/compiler/Foreach.x10"
            if (t$113037) {
                
                //#line 749 . "x10/compiler/Foreach.x10"
                final x10.array.DenseIterationSpace_2 alloc$112263 = ((x10.array.DenseIterationSpace_2)(new x10.array.DenseIterationSpace_2((java.lang.System[]) null)));
                
                //#line 749 . "x10/compiler/Foreach.x10"
                alloc$112263.x10$array$DenseIterationSpace_2$$init$S(((long)(min$112254)), ((long)(min$112256)), ((long)(max$112255)), ((long)(max$112257)));
                
                //#line 139 .. "x10/compiler/Foreach.x10"
                $T myRes$112284 = (($T)(identity));
                
                //#line 140 .. "x10/compiler/Foreach.x10"
                final long i$111517min$113866 = alloc$112263.min0;
                
                //#line 140 .. "x10/compiler/Foreach.x10"
                final long i$111517max$113867 = alloc$112263.max0;
                
                //#line 140 .. "x10/compiler/Foreach.x10"
                long i$113863 = i$111517min$113866;
                
                //#line 140 .. "x10/compiler/Foreach.x10"
                for (;
                     true;
                     ) {
                    
                    //#line 140 .. "x10/compiler/Foreach.x10"
                    final boolean t$113865 = ((i$113863) <= (((long)(i$111517max$113867))));
                    
                    //#line 140 .. "x10/compiler/Foreach.x10"
                    if (!(t$113865)) {
                        
                        //#line 140 .. "x10/compiler/Foreach.x10"
                        break;
                    }
                    
                    //#line 141 .. "x10/compiler/Foreach.x10"
                    final long i$111499min$113858 = alloc$112263.min1;
                    
                    //#line 141 .. "x10/compiler/Foreach.x10"
                    final long i$111499max$113859 = alloc$112263.max1;
                    
                    //#line 141 .. "x10/compiler/Foreach.x10"
                    long i$113855 = i$111499min$113858;
                    
                    //#line 141 .. "x10/compiler/Foreach.x10"
                    for (;
                         true;
                         ) {
                        
                        //#line 141 .. "x10/compiler/Foreach.x10"
                        final boolean t$113857 = ((i$113855) <= (((long)(i$111499max$113859))));
                        
                        //#line 141 .. "x10/compiler/Foreach.x10"
                        if (!(t$113857)) {
                            
                            //#line 141 .. "x10/compiler/Foreach.x10"
                            break;
                        }
                        
                        //#line 142 .. "x10/compiler/Foreach.x10"
                        final $T t$113850 = (($T)((($T)
                                                    ((x10.core.fun.Fun_0_2<x10.core.Long,x10.core.Long,$T>)body).$apply(x10.core.Long.$box(i$113863), x10.rtt.Types.LONG, x10.core.Long.$box(i$113855), x10.rtt.Types.LONG))));
                        
                        //#line 142 .. "x10/compiler/Foreach.x10"
                        final $T t$113851 = (($T)((($T)
                                                    ((x10.core.fun.Fun_0_2<$T,$T,$T>)reduce).$apply(myRes$112284, $T, t$113850, $T))));
                        
                        //#line 142 .. "x10/compiler/Foreach.x10"
                        myRes$112284 = (($T)(t$113851));
                        
                        //#line 141 .. "x10/compiler/Foreach.x10"
                        final long t$113854 = ((i$113855) + (((long)(1L))));
                        
                        //#line 141 .. "x10/compiler/Foreach.x10"
                        i$113855 = t$113854;
                    }
                    
                    //#line 140 .. "x10/compiler/Foreach.x10"
                    final long t$113862 = ((i$113863) + (((long)(1L))));
                    
                    //#line 140 .. "x10/compiler/Foreach.x10"
                    i$113863 = t$113862;
                }
                
                //#line 749 . "x10/compiler/Foreach.x10"
                ret$112278 = (($T)(myRes$112284));
                
                //#line 749 . "x10/compiler/Foreach.x10"
                break __ret$112279;
            } else {
                
                //#line 761 . "x10/compiler/Foreach.x10"
                final long t$113033 = ((max$112255) + (((long)(1L))));
                
                //#line 761 . "x10/compiler/Foreach.x10"
                final long t$113034 = ((max$112257) + (((long)(1L))));
                
                //#line 752 . "x10/compiler/Foreach.x10"
                final x10.core.fun.Fun_0_4 t$113035 = ((x10.core.fun.Fun_0_4)(new x10.compiler.Foreach.$Closure$44<$T>($T, identity$112262, body$112260, reduce$112261, (x10.compiler.Foreach.$Closure$44.__0x10$compiler$Foreach$$Closure$44$$T__1$1x10$lang$Long$3x10$lang$Long$3x10$compiler$Foreach$$Closure$44$$T$2__2$1x10$compiler$Foreach$$Closure$44$$T$3x10$compiler$Foreach$$Closure$44$$T$3x10$compiler$Foreach$$Closure$44$$T$2) null)));
                
                //#line 761 . "x10/compiler/Foreach.x10"
                final $T t$113036 = (($T)(x10.compiler.Foreach.<$T> doBisectReduce2D__6$1x10$lang$Long$3x10$lang$Long$3x10$lang$Long$3x10$lang$Long$3x10$compiler$Foreach$$T$2__7$1x10$compiler$Foreach$$T$3x10$compiler$Foreach$$T$3x10$compiler$Foreach$$T$2$G($T, (long)(min$112254), (long)(t$113033), (long)(min$112256), (long)(t$113034), (long)(grainSize$112258), (long)(grainSize$112259), ((x10.core.fun.Fun_0_4)(t$113035)), ((x10.core.fun.Fun_0_2)(reduce$112261)))));
                
                //#line 761 . "x10/compiler/Foreach.x10"
                ret$112278 = (($T)(t$113036));
                
                //#line 761 . "x10/compiler/Foreach.x10"
                break __ret$112279;
            }
        }
        
        //#line 783 "x10/compiler/Foreach.x10"
        return ret$112278;
    }
    
    
    //#line 798 "x10/compiler/Foreach.x10"
    /**
     * Reduce over a dense rectangular set of indices in parallel using 
     * two-dimensional recursive bisection. The index set is divided along the
     * largest dimension into two approximately equal pieces, with each piece  
     * constituting an activity. Bisection recurs on each subblock until each 
     * activity is smaller than or equal to a maximum grain size in each 
     * dimension.
     * @param space the 2D dense space over which to reduce
     * @param body a closure that executes over a single index [i,j]
     * @param reduce the reduction operation
     * @param identity the identity value for the reduction operation such that reduce(identity,f)=f
     */
    public static <$T>$T bisectReduce__1$1x10$lang$Long$3x10$lang$Long$3x10$compiler$Foreach$$T$2__2$1x10$compiler$Foreach$$T$3x10$compiler$Foreach$$T$3x10$compiler$Foreach$$T$2__3x10$compiler$Foreach$$T$G(final x10.rtt.Type $T, final x10.array.DenseIterationSpace_2 space, final x10.core.fun.Fun_0_2<x10.core.Long,x10.core.Long,$T> body, final x10.core.fun.Fun_0_2<$T,$T,$T> reduce, final $T identity) {
        
        //#line 801 "x10/compiler/Foreach.x10"
        final long t$113039 = space.max0;
        
        //#line 801 "x10/compiler/Foreach.x10"
        final long t$113040 = space.min0;
        
        //#line 801 "x10/compiler/Foreach.x10"
        final long t$113042 = ((t$113039) - (((long)(t$113040))));
        
        //#line 801 "x10/compiler/Foreach.x10"
        final int t$113041 = x10.xrx.Runtime.get$NTHREADS();
        
        //#line 801 "x10/compiler/Foreach.x10"
        final long t$113043 = ((long)(((int)(t$113041))));
        
        //#line 801 "x10/compiler/Foreach.x10"
        final long t$113044 = ((t$113042) / (((long)(t$113043))));
        
        //#line 801 "x10/compiler/Foreach.x10"
        final long grainSize0 = java.lang.Math.max(((long)(1L)),((long)(t$113044)));
        
        //#line 802 "x10/compiler/Foreach.x10"
        final long t$113045 = space.max1;
        
        //#line 802 "x10/compiler/Foreach.x10"
        final long t$113046 = space.min1;
        
        //#line 802 "x10/compiler/Foreach.x10"
        final long t$113048 = ((t$113045) - (((long)(t$113046))));
        
        //#line 802 "x10/compiler/Foreach.x10"
        final int t$113047 = x10.xrx.Runtime.get$NTHREADS();
        
        //#line 802 "x10/compiler/Foreach.x10"
        final long t$113049 = ((long)(((int)(t$113047))));
        
        //#line 802 "x10/compiler/Foreach.x10"
        final long t$113050 = ((t$113048) / (((long)(t$113049))));
        
        //#line 802 "x10/compiler/Foreach.x10"
        final long grainSize1 = java.lang.Math.max(((long)(1L)),((long)(t$113050)));
        
        //#line 803 "x10/compiler/Foreach.x10"
        final long min$112294 = space.min0;
        
        //#line 803 "x10/compiler/Foreach.x10"
        final long max$112295 = space.max0;
        
        //#line 803 "x10/compiler/Foreach.x10"
        final long min$112296 = space.min1;
        
        //#line 803 "x10/compiler/Foreach.x10"
        final long max$112297 = space.max1;
        
        //#line 803 "x10/compiler/Foreach.x10"
        final long grainSize$112298 = grainSize0;
        
        //#line 803 "x10/compiler/Foreach.x10"
        final long grainSize$112299 = grainSize1;
        
        //#line 803 "x10/compiler/Foreach.x10"
        final x10.core.fun.Fun_0_2 body$112300 = ((x10.core.fun.Fun_0_2)(body));
        
        //#line 803 "x10/compiler/Foreach.x10"
        final x10.core.fun.Fun_0_2 reduce$112301 = ((x10.core.fun.Fun_0_2)(reduce));
        
        //#line 803 "x10/compiler/Foreach.x10"
        final $T identity$112302 = (($T)(identity));
        
        //#line 743 . "x10/compiler/Foreach.x10"
        $T ret$112318 =  null;
        
        //#line 747 . "x10/compiler/Foreach.x10"
        __ret$112319: {
            
            //#line 748 . "x10/compiler/Foreach.x10"
            final int t$113051 = x10.xrx.Runtime.get$NTHREADS();
            //#line 748 . "x10/compiler/Foreach.x10"
            final boolean t$113084 = ((int) t$113051) == ((int) 1);
            //#line 748 . "x10/compiler/Foreach.x10"
            if (t$113084) {
                
                //#line 749 . "x10/compiler/Foreach.x10"
                final x10.array.DenseIterationSpace_2 alloc$112303 = ((x10.array.DenseIterationSpace_2)(new x10.array.DenseIterationSpace_2((java.lang.System[]) null)));
                
                //#line 749 . "x10/compiler/Foreach.x10"
                alloc$112303.x10$array$DenseIterationSpace_2$$init$S(((long)(min$112294)), ((long)(min$112296)), ((long)(max$112295)), ((long)(max$112297)));
                
                //#line 139 .. "x10/compiler/Foreach.x10"
                $T myRes$112324 = (($T)(identity));
                
                //#line 140 .. "x10/compiler/Foreach.x10"
                final long i$111517min$113904 = alloc$112303.min0;
                
                //#line 140 .. "x10/compiler/Foreach.x10"
                final long i$111517max$113905 = alloc$112303.max0;
                
                //#line 140 .. "x10/compiler/Foreach.x10"
                long i$113901 = i$111517min$113904;
                
                //#line 140 .. "x10/compiler/Foreach.x10"
                for (;
                     true;
                     ) {
                    
                    //#line 140 .. "x10/compiler/Foreach.x10"
                    final boolean t$113903 = ((i$113901) <= (((long)(i$111517max$113905))));
                    
                    //#line 140 .. "x10/compiler/Foreach.x10"
                    if (!(t$113903)) {
                        
                        //#line 140 .. "x10/compiler/Foreach.x10"
                        break;
                    }
                    
                    //#line 141 .. "x10/compiler/Foreach.x10"
                    final long i$111499min$113896 = alloc$112303.min1;
                    
                    //#line 141 .. "x10/compiler/Foreach.x10"
                    final long i$111499max$113897 = alloc$112303.max1;
                    
                    //#line 141 .. "x10/compiler/Foreach.x10"
                    long i$113893 = i$111499min$113896;
                    
                    //#line 141 .. "x10/compiler/Foreach.x10"
                    for (;
                         true;
                         ) {
                        
                        //#line 141 .. "x10/compiler/Foreach.x10"
                        final boolean t$113895 = ((i$113893) <= (((long)(i$111499max$113897))));
                        
                        //#line 141 .. "x10/compiler/Foreach.x10"
                        if (!(t$113895)) {
                            
                            //#line 141 .. "x10/compiler/Foreach.x10"
                            break;
                        }
                        
                        //#line 142 .. "x10/compiler/Foreach.x10"
                        final $T t$113888 = (($T)((($T)
                                                    ((x10.core.fun.Fun_0_2<x10.core.Long,x10.core.Long,$T>)body).$apply(x10.core.Long.$box(i$113901), x10.rtt.Types.LONG, x10.core.Long.$box(i$113893), x10.rtt.Types.LONG))));
                        
                        //#line 142 .. "x10/compiler/Foreach.x10"
                        final $T t$113889 = (($T)((($T)
                                                    ((x10.core.fun.Fun_0_2<$T,$T,$T>)reduce).$apply(myRes$112324, $T, t$113888, $T))));
                        
                        //#line 142 .. "x10/compiler/Foreach.x10"
                        myRes$112324 = (($T)(t$113889));
                        
                        //#line 141 .. "x10/compiler/Foreach.x10"
                        final long t$113892 = ((i$113893) + (((long)(1L))));
                        
                        //#line 141 .. "x10/compiler/Foreach.x10"
                        i$113893 = t$113892;
                    }
                    
                    //#line 140 .. "x10/compiler/Foreach.x10"
                    final long t$113900 = ((i$113901) + (((long)(1L))));
                    
                    //#line 140 .. "x10/compiler/Foreach.x10"
                    i$113901 = t$113900;
                }
                
                //#line 749 . "x10/compiler/Foreach.x10"
                ret$112318 = (($T)(myRes$112324));
                
                //#line 749 . "x10/compiler/Foreach.x10"
                break __ret$112319;
            } else {
                
                //#line 761 . "x10/compiler/Foreach.x10"
                final long t$113080 = ((max$112295) + (((long)(1L))));
                
                //#line 761 . "x10/compiler/Foreach.x10"
                final long t$113081 = ((max$112297) + (((long)(1L))));
                
                //#line 752 . "x10/compiler/Foreach.x10"
                final x10.core.fun.Fun_0_4 t$113082 = ((x10.core.fun.Fun_0_4)(new x10.compiler.Foreach.$Closure$45<$T>($T, identity$112302, body$112300, reduce$112301, (x10.compiler.Foreach.$Closure$45.__0x10$compiler$Foreach$$Closure$45$$T__1$1x10$lang$Long$3x10$lang$Long$3x10$compiler$Foreach$$Closure$45$$T$2__2$1x10$compiler$Foreach$$Closure$45$$T$3x10$compiler$Foreach$$Closure$45$$T$3x10$compiler$Foreach$$Closure$45$$T$2) null)));
                
                //#line 761 . "x10/compiler/Foreach.x10"
                final $T t$113083 = (($T)(x10.compiler.Foreach.<$T> doBisectReduce2D__6$1x10$lang$Long$3x10$lang$Long$3x10$lang$Long$3x10$lang$Long$3x10$compiler$Foreach$$T$2__7$1x10$compiler$Foreach$$T$3x10$compiler$Foreach$$T$3x10$compiler$Foreach$$T$2$G($T, (long)(min$112294), (long)(t$113080), (long)(min$112296), (long)(t$113081), (long)(grainSize$112298), (long)(grainSize$112299), ((x10.core.fun.Fun_0_4)(t$113082)), ((x10.core.fun.Fun_0_2)(reduce$112301)))));
                
                //#line 761 . "x10/compiler/Foreach.x10"
                ret$112318 = (($T)(t$113083));
                
                //#line 761 . "x10/compiler/Foreach.x10"
                break __ret$112319;
            }
        }
        
        //#line 803 "x10/compiler/Foreach.x10"
        return ret$112318;
    }
    
    
    //#line 811 "x10/compiler/Foreach.x10"
    /**
     * Perform a parallel reduction using recursive bisection.
     * Results of each branch are reduced together at each level of the tree.
     * Wait for termination of all nested asyncs.
     */
    private static <$T>$T doBisectReduce2D__6$1x10$lang$Long$3x10$lang$Long$3x10$lang$Long$3x10$lang$Long$3x10$compiler$Foreach$$T$2__7$1x10$compiler$Foreach$$T$3x10$compiler$Foreach$$T$3x10$compiler$Foreach$$T$2$G(final x10.rtt.Type $T, final long s0, final long e0, final long s1, final long e1, final long g1, final long g2, final x10.core.fun.Fun_0_4<x10.core.Long,x10.core.Long,x10.core.Long,x10.core.Long,$T> body, final x10.core.fun.Fun_0_2<$T,$T,$T> reduce) {
        
        //#line 816 "x10/compiler/Foreach.x10"
        final long t$113086 = ((e0) - (((long)(s0))));
        
        //#line 816 "x10/compiler/Foreach.x10"
        boolean t$113091 = ((t$113086) > (((long)(g1))));
        
        //#line 816 "x10/compiler/Foreach.x10"
        if (t$113091) {
            
            //#line 816 "x10/compiler/Foreach.x10"
            final long t$113087 = ((e0) - (((long)(s0))));
            
            //#line 816 "x10/compiler/Foreach.x10"
            final long t$113088 = ((e1) - (((long)(s1))));
            
            //#line 816 "x10/compiler/Foreach.x10"
            boolean t$113090 = ((t$113087) >= (((long)(t$113088))));
            
            //#line 816 "x10/compiler/Foreach.x10"
            if (!(t$113090)) {
                
                //#line 816 "x10/compiler/Foreach.x10"
                final long t$113089 = ((e1) - (((long)(s1))));
                
                //#line 816 "x10/compiler/Foreach.x10"
                t$113090 = ((t$113089) <= (((long)(g2))));
            }
            
            //#line 816 "x10/compiler/Foreach.x10"
            t$113091 = t$113090;
        }
        
        //#line 816 "x10/compiler/Foreach.x10"
        if (t$113091) {
            
            //#line 817 "x10/compiler/Foreach.x10"
            final $T asyncResult;
            
            //#line 818 "x10/compiler/Foreach.x10"
            final $T syncResult;
            {
                
                //#line 819 "x10/compiler/Foreach.x10"
                x10.xrx.Runtime.ensureNotInAtomic();
                
                //#line 819 "x10/compiler/Foreach.x10"
                final x10.xrx.FinishState fs$114039 = x10.xrx.Runtime.startFinish();
                {
                    
                    //#line 819 "x10/compiler/Foreach.x10"
                    final $T[] $asyncResult$114048 = ($T[]) new java.lang.Object[1];
                    
                    //#line 819 "x10/compiler/Foreach.x10"
                    try {{
                        {
                            
                            //#line 820 "x10/compiler/Foreach.x10"
                            x10.xrx.Runtime.runAsync(((x10.core.fun.VoidFun_0_0)(new x10.compiler.Foreach.$Closure$46<$T>($T, s0, e0, s1, e1, g1, g2, body, reduce, $asyncResult$114048, (x10.compiler.Foreach.$Closure$46.__6$1x10$lang$Long$3x10$lang$Long$3x10$lang$Long$3x10$lang$Long$3x10$compiler$Foreach$$Closure$46$$T$2__7$1x10$compiler$Foreach$$Closure$46$$T$3x10$compiler$Foreach$$Closure$46$$T$3x10$compiler$Foreach$$Closure$46$$T$2) null))));
                            
                            //#line 821 "x10/compiler/Foreach.x10"
                            final long t$113095 = ((s0) + (((long)(e0))));
                            
                            //#line 821 "x10/compiler/Foreach.x10"
                            final long t$113096 = ((t$113095) / (((long)(2L))));
                            
                            //#line 821 "x10/compiler/Foreach.x10"
                            final $T t$113097 = (($T)(x10.compiler.Foreach.<$T> doBisectReduce2D__6$1x10$lang$Long$3x10$lang$Long$3x10$lang$Long$3x10$lang$Long$3x10$compiler$Foreach$$T$2__7$1x10$compiler$Foreach$$T$3x10$compiler$Foreach$$T$3x10$compiler$Foreach$$T$2$G($T, (long)(s0), (long)(t$113096), (long)(s1), (long)(e1), (long)(g1), (long)(g2), ((x10.core.fun.Fun_0_4)(body)), ((x10.core.fun.Fun_0_2)(reduce)))));
                            
                            //#line 821 "x10/compiler/Foreach.x10"
                            syncResult = (($T)(t$113097));
                        }
                    }}catch (java.lang.Throwable ct$114037) {
                        
                        //#line 819 "x10/compiler/Foreach.x10"
                        x10.xrx.Runtime.pushException(((java.lang.Throwable)(ct$114037)));
                        
                        //#line 819 "x10/compiler/Foreach.x10"
                        throw new java.lang.RuntimeException();
                    }finally {{
                         
                         //#line 819 "x10/compiler/Foreach.x10"
                         x10.xrx.Runtime.stopFinish(((x10.xrx.FinishState)(fs$114039)));
                     }}
                    
                    //#line 819 "x10/compiler/Foreach.x10"
                    asyncResult = (($T)((($T)$asyncResult$114048[(int)0])));
                    }
                }
            
            //#line 823 "x10/compiler/Foreach.x10"
            final $T t$113098 = (($T)((($T)
                                        ((x10.core.fun.Fun_0_2<$T,$T,$T>)reduce).$apply(asyncResult, $T, syncResult, $T))));
            
            //#line 823 "x10/compiler/Foreach.x10"
            return t$113098;
            } else {
                
                //#line 824 "x10/compiler/Foreach.x10"
                final long t$113099 = ((e1) - (((long)(s1))));
                
                //#line 824 "x10/compiler/Foreach.x10"
                final boolean t$113110 = ((t$113099) > (((long)(g2))));
                
                //#line 824 "x10/compiler/Foreach.x10"
                if (t$113110) {
                    
                    //#line 825 "x10/compiler/Foreach.x10"
                    final $T asyncResult;
                    
                    //#line 826 "x10/compiler/Foreach.x10"
                    final $T syncResult;
                    {
                        
                        //#line 827 "x10/compiler/Foreach.x10"
                        x10.xrx.Runtime.ensureNotInAtomic();
                        
                        //#line 827 "x10/compiler/Foreach.x10"
                        final x10.xrx.FinishState fs$114045 = x10.xrx.Runtime.startFinish();
                        {
                            
                            //#line 827 "x10/compiler/Foreach.x10"
                            final $T[] $asyncResult$114049 = ($T[]) new java.lang.Object[1];
                            
                            //#line 827 "x10/compiler/Foreach.x10"
                            try {{
                                {
                                    
                                    //#line 828 "x10/compiler/Foreach.x10"
                                    x10.xrx.Runtime.runAsync(((x10.core.fun.VoidFun_0_0)(new x10.compiler.Foreach.$Closure$47<$T>($T, s1, e1, s0, e0, g1, g2, body, reduce, $asyncResult$114049, (x10.compiler.Foreach.$Closure$47.__6$1x10$lang$Long$3x10$lang$Long$3x10$lang$Long$3x10$lang$Long$3x10$compiler$Foreach$$Closure$47$$T$2__7$1x10$compiler$Foreach$$Closure$47$$T$3x10$compiler$Foreach$$Closure$47$$T$3x10$compiler$Foreach$$Closure$47$$T$2) null))));
                                    
                                    //#line 829 "x10/compiler/Foreach.x10"
                                    final long t$113103 = ((s1) + (((long)(e1))));
                                    
                                    //#line 829 "x10/compiler/Foreach.x10"
                                    final long t$113104 = ((t$113103) / (((long)(2L))));
                                    
                                    //#line 829 "x10/compiler/Foreach.x10"
                                    final $T t$113105 = (($T)(x10.compiler.Foreach.<$T> doBisectReduce2D__6$1x10$lang$Long$3x10$lang$Long$3x10$lang$Long$3x10$lang$Long$3x10$compiler$Foreach$$T$2__7$1x10$compiler$Foreach$$T$3x10$compiler$Foreach$$T$3x10$compiler$Foreach$$T$2$G($T, (long)(s0), (long)(e0), (long)(s1), (long)(t$113104), (long)(g1), (long)(g2), ((x10.core.fun.Fun_0_4)(body)), ((x10.core.fun.Fun_0_2)(reduce)))));
                                    
                                    //#line 829 "x10/compiler/Foreach.x10"
                                    syncResult = (($T)(t$113105));
                                }
                            }}catch (java.lang.Throwable ct$114043) {
                                
                                //#line 827 "x10/compiler/Foreach.x10"
                                x10.xrx.Runtime.pushException(((java.lang.Throwable)(ct$114043)));
                                
                                //#line 827 "x10/compiler/Foreach.x10"
                                throw new java.lang.RuntimeException();
                            }finally {{
                                 
                                 //#line 827 "x10/compiler/Foreach.x10"
                                 x10.xrx.Runtime.stopFinish(((x10.xrx.FinishState)(fs$114045)));
                             }}
                            
                            //#line 827 "x10/compiler/Foreach.x10"
                            asyncResult = (($T)((($T)$asyncResult$114049[(int)0])));
                            }
                        }
                    
                    //#line 831 "x10/compiler/Foreach.x10"
                    final $T t$113106 = (($T)((($T)
                                                ((x10.core.fun.Fun_0_2<$T,$T,$T>)reduce).$apply(asyncResult, $T, syncResult, $T))));
                    
                    //#line 831 "x10/compiler/Foreach.x10"
                    return t$113106;
                    } else {
                        
                        //#line 833 "x10/compiler/Foreach.x10"
                        final long t$113107 = ((e0) - (((long)(1L))));
                        
                        //#line 833 "x10/compiler/Foreach.x10"
                        final long t$113108 = ((e1) - (((long)(1L))));
                        
                        //#line 833 "x10/compiler/Foreach.x10"
                        final $T t$113109 = (($T)((($T)
                                                    ((x10.core.fun.Fun_0_4<x10.core.Long,x10.core.Long,x10.core.Long,x10.core.Long,$T>)body).$apply(x10.core.Long.$box(s0), x10.rtt.Types.LONG, x10.core.Long.$box(t$113107), x10.rtt.Types.LONG, x10.core.Long.$box(s1), x10.rtt.Types.LONG, x10.core.Long.$box(t$113108), x10.rtt.Types.LONG))));
                        
                        //#line 833 "x10/compiler/Foreach.x10"
                        return t$113109;
                    }
                }
        }
        
        public static <$T>$T doBisectReduce2D$P__6$1x10$lang$Long$3x10$lang$Long$3x10$lang$Long$3x10$lang$Long$3x10$compiler$Foreach$$T$2__7$1x10$compiler$Foreach$$T$3x10$compiler$Foreach$$T$3x10$compiler$Foreach$$T$2$G(final x10.rtt.Type $T, final long s0, final long e0, final long s1, final long e1, final long g1, final long g2, final x10.core.fun.Fun_0_4<x10.core.Long,x10.core.Long,x10.core.Long,x10.core.Long,$T> body, final x10.core.fun.Fun_0_2<$T,$T,$T> reduce) {
            return x10.compiler.Foreach.<$T> doBisectReduce2D__6$1x10$lang$Long$3x10$lang$Long$3x10$lang$Long$3x10$lang$Long$3x10$compiler$Foreach$$T$2__7$1x10$compiler$Foreach$$T$3x10$compiler$Foreach$$T$3x10$compiler$Foreach$$T$2$G($T, (long)(s0), (long)(e0), (long)(s1), (long)(e1), (long)(g1), (long)(g2), ((x10.core.fun.Fun_0_4)(body)), ((x10.core.fun.Fun_0_2)(reduce)));
        }
        
        
        //#line 41 "x10/compiler/Foreach.x10"
        final public x10.compiler.Foreach x10$compiler$Foreach$$this$x10$compiler$Foreach() {
            
            //#line 41 "x10/compiler/Foreach.x10"
            return x10.compiler.Foreach.this;
        }
        
        
        //#line 41 "x10/compiler/Foreach.x10"
        // creation method for java code (1-phase java constructor)
        public Foreach() {
            this((java.lang.System[]) null);
            x10$compiler$Foreach$$init$S();
        }
        
        // constructor for non-virtual call
        final public x10.compiler.Foreach x10$compiler$Foreach$$init$S() {
             {
                
                //#line 41 "x10/compiler/Foreach.x10"
                
            }
            return this;
        }
        
        
        
        //#line 41 "x10/compiler/Foreach.x10"
        final public void __fieldInitializers_x10_compiler_Foreach() {
            
        }
        
        @x10.runtime.impl.java.X10Generated
        final public static class $Closure$22 extends x10.core.Ref implements x10.core.fun.VoidFun_0_0, x10.serialization.X10JavaSerializable
        {
            public static final x10.rtt.RuntimeType<$Closure$22> $RTT = 
                x10.rtt.StaticVoidFunType.<$Closure$22> make($Closure$22.class,
                                                             new x10.rtt.Type[] {
                                                                 x10.core.fun.VoidFun_0_0.$RTT
                                                             });
            
            public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
            
            public x10.rtt.Type<?> $getParam(int i) { return null; }
            
            private Object writeReplace() throws java.io.ObjectStreamException {
                return new x10.serialization.SerializationProxy(this);
            }
            
            public static x10.serialization.X10JavaSerializable $_deserialize_body(x10.compiler.Foreach.$Closure$22 $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
                $_obj.body = $deserializer.readObject();
                $_obj.i$113186 = $deserializer.readLong();
                return $_obj;
            }
            
            public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
                x10.compiler.Foreach.$Closure$22 $_obj = new x10.compiler.Foreach.$Closure$22((java.lang.System[]) null);
                $deserializer.record_reference($_obj);
                return $_deserialize_body($_obj, $deserializer);
            }
            
            public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
                $serializer.write(this.body);
                $serializer.write(this.i$113186);
                
            }
            
            // constructor just for allocation
            public $Closure$22(final java.lang.System[] $dummy) {
                
            }
            
            // synthetic type for parameter mangling
            public static final class __0$1x10$lang$Long$2 {}
            
        
            
            public void $apply() {
                
                //#line 160 "x10/compiler/Foreach.x10"
                try {{
                    
                    //#line 160 "x10/compiler/Foreach.x10"
                    ((x10.core.fun.VoidFun_0_1<x10.core.Long>)this.body).$apply(x10.core.Long.$box(this.i$113186), x10.rtt.Types.LONG);
                }}catch (java.lang.Error __lowerer__var__0__) {
                    
                    //#line 160 "x10/compiler/Foreach.x10"
                    throw __lowerer__var__0__;
                }catch (java.lang.Throwable __lowerer__var__1__) {
                    
                    //#line 160 "x10/compiler/Foreach.x10"
                    throw x10.rtt.Types.EXCEPTION.isInstance(__lowerer__var__1__) ? (java.lang.RuntimeException)(__lowerer__var__1__) : new x10.lang.WrappedThrowable(__lowerer__var__1__);
                }
            }
            
            public x10.core.fun.VoidFun_0_1<x10.core.Long> body;
            public long i$113186;
            
            public $Closure$22(final x10.core.fun.VoidFun_0_1<x10.core.Long> body, final long i$113186, __0$1x10$lang$Long$2 $dummy) {
                 {
                    this.body = ((x10.core.fun.VoidFun_0_1)(body));
                    this.i$113186 = i$113186;
                }
            }
            
        }
        
        @x10.runtime.impl.java.X10Generated
        final public static class $Closure$23 extends x10.core.Ref implements x10.core.fun.VoidFun_0_0, x10.serialization.X10JavaSerializable
        {
            public static final x10.rtt.RuntimeType<$Closure$23> $RTT = 
                x10.rtt.StaticVoidFunType.<$Closure$23> make($Closure$23.class,
                                                             new x10.rtt.Type[] {
                                                                 x10.core.fun.VoidFun_0_0.$RTT
                                                             });
            
            public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
            
            public x10.rtt.Type<?> $getParam(int i) { return null; }
            
            private Object writeReplace() throws java.io.ObjectStreamException {
                return new x10.serialization.SerializationProxy(this);
            }
            
            public static x10.serialization.X10JavaSerializable $_deserialize_body(x10.compiler.Foreach.$Closure$23 $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
                $_obj.body = $deserializer.readObject();
                $_obj.i$113216 = $deserializer.readLong();
                $_obj.j$113208 = $deserializer.readLong();
                return $_obj;
            }
            
            public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
                x10.compiler.Foreach.$Closure$23 $_obj = new x10.compiler.Foreach.$Closure$23((java.lang.System[]) null);
                $deserializer.record_reference($_obj);
                return $_deserialize_body($_obj, $deserializer);
            }
            
            public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
                $serializer.write(this.body);
                $serializer.write(this.i$113216);
                $serializer.write(this.j$113208);
                
            }
            
            // constructor just for allocation
            public $Closure$23(final java.lang.System[] $dummy) {
                
            }
            
            // synthetic type for parameter mangling
            public static final class __0$1x10$lang$Long$3x10$lang$Long$2 {}
            
        
            
            public void $apply() {
                
                //#line 180 "x10/compiler/Foreach.x10"
                try {{
                    
                    //#line 180 "x10/compiler/Foreach.x10"
                    ((x10.core.fun.VoidFun_0_2<x10.core.Long,x10.core.Long>)this.body).$apply(x10.core.Long.$box(this.i$113216), x10.rtt.Types.LONG, x10.core.Long.$box(this.j$113208), x10.rtt.Types.LONG);
                }}catch (java.lang.Error __lowerer__var__0__) {
                    
                    //#line 180 "x10/compiler/Foreach.x10"
                    throw __lowerer__var__0__;
                }catch (java.lang.Throwable __lowerer__var__1__) {
                    
                    //#line 180 "x10/compiler/Foreach.x10"
                    throw x10.rtt.Types.EXCEPTION.isInstance(__lowerer__var__1__) ? (java.lang.RuntimeException)(__lowerer__var__1__) : new x10.lang.WrappedThrowable(__lowerer__var__1__);
                }
            }
            
            public x10.core.fun.VoidFun_0_2<x10.core.Long,x10.core.Long> body;
            public long i$113216;
            public long j$113208;
            
            public $Closure$23(final x10.core.fun.VoidFun_0_2<x10.core.Long,x10.core.Long> body, final long i$113216, final long j$113208, __0$1x10$lang$Long$3x10$lang$Long$2 $dummy) {
                 {
                    this.body = ((x10.core.fun.VoidFun_0_2)(body));
                    this.i$113216 = i$113216;
                    this.j$113208 = j$113208;
                }
            }
            
        }
        
        @x10.runtime.impl.java.X10Generated
        final public static class $Closure$24 extends x10.core.Ref implements x10.core.fun.VoidFun_0_0, x10.serialization.X10JavaSerializable
        {
            public static final x10.rtt.RuntimeType<$Closure$24> $RTT = 
                x10.rtt.StaticVoidFunType.<$Closure$24> make($Closure$24.class,
                                                             new x10.rtt.Type[] {
                                                                 x10.core.fun.VoidFun_0_0.$RTT
                                                             });
            
            public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
            
            public x10.rtt.Type<?> $getParam(int i) { return null; }
            
            private Object writeReplace() throws java.io.ObjectStreamException {
                return new x10.serialization.SerializationProxy(this);
            }
            
            public static x10.serialization.X10JavaSerializable $_deserialize_body(x10.compiler.Foreach.$Closure$24 $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
                $_obj.blockSize = $deserializer.readLong();
                $_obj.body = $deserializer.readObject();
                $_obj.leftOver = $deserializer.readLong();
                $_obj.min = $deserializer.readLong();
                $_obj.myT$113222 = $deserializer.readLong();
                return $_obj;
            }
            
            public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
                x10.compiler.Foreach.$Closure$24 $_obj = new x10.compiler.Foreach.$Closure$24((java.lang.System[]) null);
                $deserializer.record_reference($_obj);
                return $_deserialize_body($_obj, $deserializer);
            }
            
            public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
                $serializer.write(this.blockSize);
                $serializer.write(this.body);
                $serializer.write(this.leftOver);
                $serializer.write(this.min);
                $serializer.write(this.myT$113222);
                
            }
            
            // constructor just for allocation
            public $Closure$24(final java.lang.System[] $dummy) {
                
            }
            
            // synthetic type for parameter mangling
            public static final class __4$1x10$lang$Long$3x10$lang$Long$2 {}
            
        
            
            public void $apply() {
                
                //#line 207 "x10/compiler/Foreach.x10"
                try {{
                    
                    //#line 208 "x10/compiler/Foreach.x10"
                    final long t$113223 = ((this.blockSize) * (((long)(this.myT$113222))));
                    
                    //#line 208 "x10/compiler/Foreach.x10"
                    final long t$113224 = ((this.min) + (((long)(t$113223))));
                    
                    //#line 208 "x10/compiler/Foreach.x10"
                    final boolean t$113225 = ((this.myT$113222) < (((long)(this.leftOver))));
                    
                    //#line 208 "x10/compiler/Foreach.x10"
                    long t$113226 =  0;
                    
                    //#line 208 "x10/compiler/Foreach.x10"
                    if (t$113225) {
                        
                        //#line 208 "x10/compiler/Foreach.x10"
                        t$113226 = this.myT$113222;
                    } else {
                        
                        //#line 208 "x10/compiler/Foreach.x10"
                        t$113226 = this.leftOver;
                    }
                    
                    //#line 208 "x10/compiler/Foreach.x10"
                    final long lo$113228 = ((t$113224) + (((long)(t$113226))));
                    
                    //#line 209 "x10/compiler/Foreach.x10"
                    final long t$113229 = ((lo$113228) + (((long)(this.blockSize))));
                    
                    //#line 209 "x10/compiler/Foreach.x10"
                    final boolean t$113230 = ((this.myT$113222) < (((long)(this.leftOver))));
                    
                    //#line 209 "x10/compiler/Foreach.x10"
                    long t$113231 =  0;
                    
                    //#line 209 "x10/compiler/Foreach.x10"
                    if (t$113230) {
                        
                        //#line 209 "x10/compiler/Foreach.x10"
                        t$113231 = 0L;
                    } else {
                        
                        //#line 209 "x10/compiler/Foreach.x10"
                        t$113231 = -1L;
                    }
                    
                    //#line 209 "x10/compiler/Foreach.x10"
                    final long hi$113233 = ((t$113229) + (((long)(t$113231))));
                    
                    //#line 210 "x10/compiler/Foreach.x10"
                    ((x10.core.fun.VoidFun_0_2<x10.core.Long,x10.core.Long>)this.body).$apply(x10.core.Long.$box(lo$113228), x10.rtt.Types.LONG, x10.core.Long.$box(hi$113233), x10.rtt.Types.LONG);
                }}catch (java.lang.Error __lowerer__var__0__) {
                    
                    //#line 207 "x10/compiler/Foreach.x10"
                    throw __lowerer__var__0__;
                }catch (java.lang.Throwable __lowerer__var__1__) {
                    
                    //#line 207 "x10/compiler/Foreach.x10"
                    throw x10.rtt.Types.EXCEPTION.isInstance(__lowerer__var__1__) ? (java.lang.RuntimeException)(__lowerer__var__1__) : new x10.lang.WrappedThrowable(__lowerer__var__1__);
                }
            }
            
            public long blockSize;
            public long myT$113222;
            public long min;
            public long leftOver;
            public x10.core.fun.VoidFun_0_2<x10.core.Long,x10.core.Long> body;
            
            public $Closure$24(final long blockSize, final long myT$113222, final long min, final long leftOver, final x10.core.fun.VoidFun_0_2<x10.core.Long,x10.core.Long> body, __4$1x10$lang$Long$3x10$lang$Long$2 $dummy) {
                 {
                    this.blockSize = blockSize;
                    this.myT$113222 = myT$113222;
                    this.min = min;
                    this.leftOver = leftOver;
                    this.body = ((x10.core.fun.VoidFun_0_2)(body));
                }
            }
            
        }
        
        @x10.runtime.impl.java.X10Generated
        final public static class $Closure$25 extends x10.core.Ref implements x10.core.fun.VoidFun_0_0, x10.serialization.X10JavaSerializable
        {
            public static final x10.rtt.RuntimeType<$Closure$25> $RTT = 
                x10.rtt.StaticVoidFunType.<$Closure$25> make($Closure$25.class,
                                                             new x10.rtt.Type[] {
                                                                 x10.core.fun.VoidFun_0_0.$RTT
                                                             });
            
            public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
            
            public x10.rtt.Type<?> $getParam(int i) { return null; }
            
            private Object writeReplace() throws java.io.ObjectStreamException {
                return new x10.serialization.SerializationProxy(this);
            }
            
            public static x10.serialization.X10JavaSerializable $_deserialize_body(x10.compiler.Foreach.$Closure$25 $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
                $_obj.blockSize$111857 = $deserializer.readLong();
                $_obj.body = $deserializer.readObject();
                $_obj.leftOver$111858 = $deserializer.readLong();
                $_obj.min$111852 = $deserializer.readLong();
                $_obj.myT$113260 = $deserializer.readLong();
                return $_obj;
            }
            
            public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
                x10.compiler.Foreach.$Closure$25 $_obj = new x10.compiler.Foreach.$Closure$25((java.lang.System[]) null);
                $deserializer.record_reference($_obj);
                return $_deserialize_body($_obj, $deserializer);
            }
            
            public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
                $serializer.write(this.blockSize$111857);
                $serializer.write(this.body);
                $serializer.write(this.leftOver$111858);
                $serializer.write(this.min$111852);
                $serializer.write(this.myT$113260);
                
            }
            
            // constructor just for allocation
            public $Closure$25(final java.lang.System[] $dummy) {
                
            }
            
            // synthetic type for parameter mangling
            public static final class __4$1x10$lang$Long$2 {}
            
        
            
            public void $apply() {
                
                //#line 207 . "x10/compiler/Foreach.x10"
                try {{
                    
                    //#line 208 . "x10/compiler/Foreach.x10"
                    final long t$113261 = ((this.blockSize$111857) * (((long)(this.myT$113260))));
                    
                    //#line 208 . "x10/compiler/Foreach.x10"
                    final long t$113262 = ((this.min$111852) + (((long)(t$113261))));
                    
                    //#line 208 . "x10/compiler/Foreach.x10"
                    final boolean t$113263 = ((this.myT$113260) < (((long)(this.leftOver$111858))));
                    
                    //#line 208 . "x10/compiler/Foreach.x10"
                    long t$113264 =  0;
                    
                    //#line 208 . "x10/compiler/Foreach.x10"
                    if (t$113263) {
                        
                        //#line 208 . "x10/compiler/Foreach.x10"
                        t$113264 = this.myT$113260;
                    } else {
                        
                        //#line 208 . "x10/compiler/Foreach.x10"
                        t$113264 = this.leftOver$111858;
                    }
                    
                    //#line 208 . "x10/compiler/Foreach.x10"
                    final long lo$113266 = ((t$113262) + (((long)(t$113264))));
                    
                    //#line 209 . "x10/compiler/Foreach.x10"
                    final long t$113267 = ((lo$113266) + (((long)(this.blockSize$111857))));
                    
                    //#line 209 . "x10/compiler/Foreach.x10"
                    final boolean t$113268 = ((this.myT$113260) < (((long)(this.leftOver$111858))));
                    
                    //#line 209 . "x10/compiler/Foreach.x10"
                    long t$113269 =  0;
                    
                    //#line 209 . "x10/compiler/Foreach.x10"
                    if (t$113268) {
                        
                        //#line 209 . "x10/compiler/Foreach.x10"
                        t$113269 = 0L;
                    } else {
                        
                        //#line 209 . "x10/compiler/Foreach.x10"
                        t$113269 = -1L;
                    }
                    
                    //#line 209 . "x10/compiler/Foreach.x10"
                    final long hi$113271 = ((t$113267) + (((long)(t$113269))));
                    
                    //#line 52 ... "x10/compiler/Foreach.x10"
                    long i$113252 = lo$113266;
                    
                    //#line 52 ... "x10/compiler/Foreach.x10"
                    for (;
                         true;
                         ) {
                        
                        //#line 52 ... "x10/compiler/Foreach.x10"
                        final boolean t$113254 = ((i$113252) <= (((long)(hi$113271))));
                        
                        //#line 52 ... "x10/compiler/Foreach.x10"
                        if (!(t$113254)) {
                            
                            //#line 52 ... "x10/compiler/Foreach.x10"
                            break;
                        }
                        
                        //#line 52 ... "x10/compiler/Foreach.x10"
                        ((x10.core.fun.VoidFun_0_1<x10.core.Long>)this.body).$apply(x10.core.Long.$box(i$113252), x10.rtt.Types.LONG);
                        
                        //#line 52 ... "x10/compiler/Foreach.x10"
                        final long t$113251 = ((i$113252) + (((long)(1L))));
                        
                        //#line 52 ... "x10/compiler/Foreach.x10"
                        i$113252 = t$113251;
                    }
                }}catch (java.lang.Error __lowerer__var__0__) {
                    
                    //#line 207 . "x10/compiler/Foreach.x10"
                    throw __lowerer__var__0__;
                }catch (java.lang.Throwable __lowerer__var__1__) {
                    
                    //#line 207 . "x10/compiler/Foreach.x10"
                    throw x10.rtt.Types.EXCEPTION.isInstance(__lowerer__var__1__) ? (java.lang.RuntimeException)(__lowerer__var__1__) : new x10.lang.WrappedThrowable(__lowerer__var__1__);
                }
            }
            
            public long blockSize$111857;
            public long myT$113260;
            public long min$111852;
            public long leftOver$111858;
            public x10.core.fun.VoidFun_0_1<x10.core.Long> body;
            
            public $Closure$25(final long blockSize$111857, final long myT$113260, final long min$111852, final long leftOver$111858, final x10.core.fun.VoidFun_0_1<x10.core.Long> body, __4$1x10$lang$Long$2 $dummy) {
                 {
                    this.blockSize$111857 = blockSize$111857;
                    this.myT$113260 = myT$113260;
                    this.min$111852 = min$111852;
                    this.leftOver$111858 = leftOver$111858;
                    this.body = body;
                }
            }
            
        }
        
        @x10.runtime.impl.java.X10Generated
        final public static class $Closure$26<$T> extends x10.core.Ref implements x10.core.fun.VoidFun_0_0, x10.serialization.X10JavaSerializable
        {
            public static final x10.rtt.RuntimeType<$Closure$26> $RTT = 
                x10.rtt.StaticVoidFunType.<$Closure$26> make($Closure$26.class,
                                                             1,
                                                             new x10.rtt.Type[] {
                                                                 x10.core.fun.VoidFun_0_0.$RTT
                                                             });
            
            public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
            
            public x10.rtt.Type<?> $getParam(int i) { if (i == 0) return $T; return null; }
            
            private Object writeReplace() throws java.io.ObjectStreamException {
                return new x10.serialization.SerializationProxy(this);
            }
            
            public static <$T> x10.serialization.X10JavaSerializable $_deserialize_body(x10.compiler.Foreach.$Closure$26<$T> $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
                $_obj.$T = (x10.rtt.Type) $deserializer.readObject();
                $_obj.blockSize = $deserializer.readLong();
                $_obj.body = $deserializer.readObject();
                $_obj.leftOver = $deserializer.readLong();
                $_obj.min = $deserializer.readLong();
                $_obj.myT$113276 = $deserializer.readLong();
                $_obj.results = $deserializer.readObject();
                return $_obj;
            }
            
            public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
                x10.compiler.Foreach.$Closure$26 $_obj = new x10.compiler.Foreach.$Closure$26((java.lang.System[]) null, (x10.rtt.Type) null);
                $deserializer.record_reference($_obj);
                return $_deserialize_body($_obj, $deserializer);
            }
            
            public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
                $serializer.write(this.$T);
                $serializer.write(this.blockSize);
                $serializer.write(this.body);
                $serializer.write(this.leftOver);
                $serializer.write(this.min);
                $serializer.write(this.myT$113276);
                $serializer.write(this.results);
                
            }
            
            // constructor just for allocation
            public $Closure$26(final java.lang.System[] $dummy, final x10.rtt.Type $T) {
                x10.compiler.Foreach.$Closure$26.$initParams(this, $T);
                
            }
            
            private x10.rtt.Type $T;
            
            // initializer of type parameters
            public static void $initParams(final $Closure$26 $this, final x10.rtt.Type $T) {
                $this.$T = $T;
                
            }
            // synthetic type for parameter mangling
            public static final class __4$1x10$lang$Long$3x10$lang$Long$3x10$compiler$Foreach$$Closure$26$$T$2__5$1x10$compiler$Foreach$$Closure$26$$T$2 {}
            
        
            
            public void $apply() {
                
                //#line 256 "x10/compiler/Foreach.x10"
                try {{
                    
                    //#line 257 "x10/compiler/Foreach.x10"
                    final long t$113277 = ((this.blockSize) * (((long)(this.myT$113276))));
                    
                    //#line 257 "x10/compiler/Foreach.x10"
                    final long t$113278 = ((this.min) + (((long)(t$113277))));
                    
                    //#line 257 "x10/compiler/Foreach.x10"
                    final boolean t$113279 = ((this.myT$113276) < (((long)(this.leftOver))));
                    
                    //#line 257 "x10/compiler/Foreach.x10"
                    long t$113280 =  0;
                    
                    //#line 257 "x10/compiler/Foreach.x10"
                    if (t$113279) {
                        
                        //#line 257 "x10/compiler/Foreach.x10"
                        t$113280 = this.myT$113276;
                    } else {
                        
                        //#line 257 "x10/compiler/Foreach.x10"
                        t$113280 = this.leftOver;
                    }
                    
                    //#line 257 "x10/compiler/Foreach.x10"
                    final long lo$113282 = ((t$113278) + (((long)(t$113280))));
                    
                    //#line 258 "x10/compiler/Foreach.x10"
                    final long t$113283 = ((lo$113282) + (((long)(this.blockSize))));
                    
                    //#line 258 "x10/compiler/Foreach.x10"
                    final boolean t$113284 = ((this.myT$113276) < (((long)(this.leftOver))));
                    
                    //#line 258 "x10/compiler/Foreach.x10"
                    long t$113285 =  0;
                    
                    //#line 258 "x10/compiler/Foreach.x10"
                    if (t$113284) {
                        
                        //#line 258 "x10/compiler/Foreach.x10"
                        t$113285 = 0L;
                    } else {
                        
                        //#line 258 "x10/compiler/Foreach.x10"
                        t$113285 = -1L;
                    }
                    
                    //#line 258 "x10/compiler/Foreach.x10"
                    final long hi$113287 = ((t$113283) + (((long)(t$113285))));
                    
                    //#line 259 "x10/compiler/Foreach.x10"
                    final $T t$113288 = (($T)((($T)
                                                ((x10.core.fun.Fun_0_2<x10.core.Long,x10.core.Long,$T>)this.body).$apply(x10.core.Long.$box(lo$113282), x10.rtt.Types.LONG, x10.core.Long.$box(hi$113287), x10.rtt.Types.LONG))));
                    
                    //#line 259 "x10/compiler/Foreach.x10"
                    ((x10.core.Rail<$T>)this.results).$set__1x10$lang$Rail$$T$G((long)(this.myT$113276), (($T)(t$113288)));
                }}catch (java.lang.Error __lowerer__var__0__) {
                    
                    //#line 256 "x10/compiler/Foreach.x10"
                    throw __lowerer__var__0__;
                }catch (java.lang.Throwable __lowerer__var__1__) {
                    
                    //#line 256 "x10/compiler/Foreach.x10"
                    throw x10.rtt.Types.EXCEPTION.isInstance(__lowerer__var__1__) ? (java.lang.RuntimeException)(__lowerer__var__1__) : new x10.lang.WrappedThrowable(__lowerer__var__1__);
                }
            }
            
            public long blockSize;
            public long myT$113276;
            public long min;
            public long leftOver;
            public x10.core.fun.Fun_0_2<x10.core.Long,x10.core.Long,$T> body;
            public x10.core.Rail<$T> results;
            
            public $Closure$26(final x10.rtt.Type $T, final long blockSize, final long myT$113276, final long min, final long leftOver, final x10.core.fun.Fun_0_2<x10.core.Long,x10.core.Long,$T> body, final x10.core.Rail<$T> results, __4$1x10$lang$Long$3x10$lang$Long$3x10$compiler$Foreach$$Closure$26$$T$2__5$1x10$compiler$Foreach$$Closure$26$$T$2 $dummy) {
                x10.compiler.Foreach.$Closure$26.$initParams(this, $T);
                 {
                    ((x10.compiler.Foreach.$Closure$26<$T>)this).blockSize = blockSize;
                    ((x10.compiler.Foreach.$Closure$26<$T>)this).myT$113276 = myT$113276;
                    ((x10.compiler.Foreach.$Closure$26<$T>)this).min = min;
                    ((x10.compiler.Foreach.$Closure$26<$T>)this).leftOver = leftOver;
                    ((x10.compiler.Foreach.$Closure$26<$T>)this).body = ((x10.core.fun.Fun_0_2)(body));
                    ((x10.compiler.Foreach.$Closure$26<$T>)this).results = ((x10.core.Rail)(results));
                }
            }
            
        }
        
        @x10.runtime.impl.java.X10Generated
        final public static class $Closure$27<$T> extends x10.core.Ref implements x10.core.fun.VoidFun_0_0, x10.serialization.X10JavaSerializable
        {
            public static final x10.rtt.RuntimeType<$Closure$27> $RTT = 
                x10.rtt.StaticVoidFunType.<$Closure$27> make($Closure$27.class,
                                                             1,
                                                             new x10.rtt.Type[] {
                                                                 x10.core.fun.VoidFun_0_0.$RTT
                                                             });
            
            public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
            
            public x10.rtt.Type<?> $getParam(int i) { if (i == 0) return $T; return null; }
            
            private Object writeReplace() throws java.io.ObjectStreamException {
                return new x10.serialization.SerializationProxy(this);
            }
            
            public static <$T> x10.serialization.X10JavaSerializable $_deserialize_body(x10.compiler.Foreach.$Closure$27<$T> $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
                $_obj.$T = (x10.rtt.Type) $deserializer.readObject();
                $_obj.blockSize$111896 = $deserializer.readLong();
                $_obj.body = $deserializer.readObject();
                $_obj.identity = $deserializer.readObject();
                $_obj.leftOver$111897 = $deserializer.readLong();
                $_obj.min$111890 = $deserializer.readLong();
                $_obj.myT$113335 = $deserializer.readLong();
                $_obj.reduce = $deserializer.readObject();
                $_obj.results$111898 = $deserializer.readObject();
                return $_obj;
            }
            
            public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
                x10.compiler.Foreach.$Closure$27 $_obj = new x10.compiler.Foreach.$Closure$27((java.lang.System[]) null, (x10.rtt.Type) null);
                $deserializer.record_reference($_obj);
                return $_deserialize_body($_obj, $deserializer);
            }
            
            public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
                $serializer.write(this.$T);
                $serializer.write(this.blockSize$111896);
                $serializer.write(this.body);
                $serializer.write(this.identity);
                $serializer.write(this.leftOver$111897);
                $serializer.write(this.min$111890);
                $serializer.write(this.myT$113335);
                $serializer.write(this.reduce);
                $serializer.write(this.results$111898);
                
            }
            
            // constructor just for allocation
            public $Closure$27(final java.lang.System[] $dummy, final x10.rtt.Type $T) {
                x10.compiler.Foreach.$Closure$27.$initParams(this, $T);
                
            }
            
            private x10.rtt.Type $T;
            
            // initializer of type parameters
            public static void $initParams(final $Closure$27 $this, final x10.rtt.Type $T) {
                $this.$T = $T;
                
            }
            // synthetic type for parameter mangling for __4x10$compiler$Foreach$$Closure$27$$T__5$1x10$lang$Long$3x10$compiler$Foreach$$Closure$27$$T$2__6$1x10$compiler$Foreach$$Closure$27$$T$3x10$compiler$Foreach$$Closure$27$$T$3x10$compiler$Foreach$$Closure$27$$T$2__7$1x10$compiler$Foreach$$Closure$27$$T$2
            public static final class $_9021ff2d {}
            
        
            
            public void $apply() {
                
                //#line 256 . "x10/compiler/Foreach.x10"
                try {{
                    
                    //#line 257 . "x10/compiler/Foreach.x10"
                    final long t$113336 = ((this.blockSize$111896) * (((long)(this.myT$113335))));
                    
                    //#line 257 . "x10/compiler/Foreach.x10"
                    final long t$113337 = ((this.min$111890) + (((long)(t$113336))));
                    
                    //#line 257 . "x10/compiler/Foreach.x10"
                    final boolean t$113338 = ((this.myT$113335) < (((long)(this.leftOver$111897))));
                    
                    //#line 257 . "x10/compiler/Foreach.x10"
                    long t$113339 =  0;
                    
                    //#line 257 . "x10/compiler/Foreach.x10"
                    if (t$113338) {
                        
                        //#line 257 . "x10/compiler/Foreach.x10"
                        t$113339 = this.myT$113335;
                    } else {
                        
                        //#line 257 . "x10/compiler/Foreach.x10"
                        t$113339 = this.leftOver$111897;
                    }
                    
                    //#line 257 . "x10/compiler/Foreach.x10"
                    final long lo$113341 = ((t$113337) + (((long)(t$113339))));
                    
                    //#line 258 . "x10/compiler/Foreach.x10"
                    final long t$113342 = ((lo$113341) + (((long)(this.blockSize$111896))));
                    
                    //#line 258 . "x10/compiler/Foreach.x10"
                    final boolean t$113343 = ((this.myT$113335) < (((long)(this.leftOver$111897))));
                    
                    //#line 258 . "x10/compiler/Foreach.x10"
                    long t$113344 =  0;
                    
                    //#line 258 . "x10/compiler/Foreach.x10"
                    if (t$113343) {
                        
                        //#line 258 . "x10/compiler/Foreach.x10"
                        t$113344 = 0L;
                    } else {
                        
                        //#line 258 . "x10/compiler/Foreach.x10"
                        t$113344 = -1L;
                    }
                    
                    //#line 258 . "x10/compiler/Foreach.x10"
                    final long hi$113346 = ((t$113342) + (((long)(t$113344))));
                    
                    //#line 285 .. "x10/compiler/Foreach.x10"
                    $T myRes$113349 = (($T)(this.identity));
                    
                    //#line 286 .. "x10/compiler/Foreach.x10"
                    long i$113330 = lo$113341;
                    
                    //#line 286 .. "x10/compiler/Foreach.x10"
                    for (;
                         true;
                         ) {
                        
                        //#line 286 .. "x10/compiler/Foreach.x10"
                        final boolean t$113332 = ((i$113330) <= (((long)(hi$113346))));
                        
                        //#line 286 .. "x10/compiler/Foreach.x10"
                        if (!(t$113332)) {
                            
                            //#line 286 .. "x10/compiler/Foreach.x10"
                            break;
                        }
                        
                        //#line 287 .. "x10/compiler/Foreach.x10"
                        final $T t$113325 = (($T)((($T)
                                                    ((x10.core.fun.Fun_0_1<x10.core.Long,$T>)this.body).$apply(x10.core.Long.$box(i$113330), x10.rtt.Types.LONG))));
                        
                        //#line 287 .. "x10/compiler/Foreach.x10"
                        final $T t$113326 = (($T)((($T)
                                                    ((x10.core.fun.Fun_0_2<$T,$T,$T>)this.reduce).$apply(myRes$113349, $T, t$113325, $T))));
                        
                        //#line 287 .. "x10/compiler/Foreach.x10"
                        myRes$113349 = (($T)(t$113326));
                        
                        //#line 286 .. "x10/compiler/Foreach.x10"
                        final long t$113329 = ((i$113330) + (((long)(1L))));
                        
                        //#line 286 .. "x10/compiler/Foreach.x10"
                        i$113330 = t$113329;
                    }
                    
                    //#line 259 . "x10/compiler/Foreach.x10"
                    ((x10.core.Rail<$T>)this.results$111898).$set__1x10$lang$Rail$$T$G((long)(this.myT$113335), (($T)(myRes$113349)));
                }}catch (java.lang.Error __lowerer__var__0__) {
                    
                    //#line 256 . "x10/compiler/Foreach.x10"
                    throw __lowerer__var__0__;
                }catch (java.lang.Throwable __lowerer__var__1__) {
                    
                    //#line 256 . "x10/compiler/Foreach.x10"
                    throw x10.rtt.Types.EXCEPTION.isInstance(__lowerer__var__1__) ? (java.lang.RuntimeException)(__lowerer__var__1__) : new x10.lang.WrappedThrowable(__lowerer__var__1__);
                }
            }
            
            public long blockSize$111896;
            public long myT$113335;
            public long min$111890;
            public long leftOver$111897;
            public $T identity;
            public x10.core.fun.Fun_0_1<x10.core.Long,$T> body;
            public x10.core.fun.Fun_0_2<$T,$T,$T> reduce;
            public x10.core.Rail<$T> results$111898;
            
            public $Closure$27(final x10.rtt.Type $T, final long blockSize$111896, final long myT$113335, final long min$111890, final long leftOver$111897, final $T identity, final x10.core.fun.Fun_0_1<x10.core.Long,$T> body, final x10.core.fun.Fun_0_2<$T,$T,$T> reduce, final x10.core.Rail<$T> results$111898, $_9021ff2d $dummy) {
                x10.compiler.Foreach.$Closure$27.$initParams(this, $T);
                 {
                    ((x10.compiler.Foreach.$Closure$27<$T>)this).blockSize$111896 = blockSize$111896;
                    ((x10.compiler.Foreach.$Closure$27<$T>)this).myT$113335 = myT$113335;
                    ((x10.compiler.Foreach.$Closure$27<$T>)this).min$111890 = min$111890;
                    ((x10.compiler.Foreach.$Closure$27<$T>)this).leftOver$111897 = leftOver$111897;
                    ((x10.compiler.Foreach.$Closure$27<$T>)this).identity = (($T)(identity));
                    ((x10.compiler.Foreach.$Closure$27<$T>)this).body = ((x10.core.fun.Fun_0_1)(body));
                    ((x10.compiler.Foreach.$Closure$27<$T>)this).reduce = ((x10.core.fun.Fun_0_2)(reduce));
                    ((x10.compiler.Foreach.$Closure$27<$T>)this).results$111898 = ((x10.core.Rail)(results$111898));
                }
            }
            
        }
        
        @x10.runtime.impl.java.X10Generated
        final public static class $Closure$28 extends x10.core.Ref implements x10.core.fun.VoidFun_0_0, x10.serialization.X10JavaSerializable
        {
            public static final x10.rtt.RuntimeType<$Closure$28> $RTT = 
                x10.rtt.StaticVoidFunType.<$Closure$28> make($Closure$28.class,
                                                             new x10.rtt.Type[] {
                                                                 x10.core.fun.VoidFun_0_0.$RTT
                                                             });
            
            public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
            
            public x10.rtt.Type<?> $getParam(int i) { return null; }
            
            private Object writeReplace() throws java.io.ObjectStreamException {
                return new x10.serialization.SerializationProxy(this);
            }
            
            public static x10.serialization.X10JavaSerializable $_deserialize_body(x10.compiler.Foreach.$Closure$28 $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
                $_obj.body$111935 = $deserializer.readObject();
                $_obj.myT$113406 = $deserializer.readLong();
                $_obj.space$111934 = $deserializer.readObject();
                return $_obj;
            }
            
            public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
                x10.compiler.Foreach.$Closure$28 $_obj = new x10.compiler.Foreach.$Closure$28((java.lang.System[]) null);
                $deserializer.record_reference($_obj);
                return $_deserialize_body($_obj, $deserializer);
            }
            
            public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
                $serializer.write(this.body$111935);
                $serializer.write(this.myT$113406);
                $serializer.write(this.space$111934);
                
            }
            
            // constructor just for allocation
            public $Closure$28(final java.lang.System[] $dummy) {
                
            }
            
            // synthetic type for parameter mangling
            public static final class __2$1x10$lang$Long$3x10$lang$Long$2 {}
            
        
            
            public void $apply() {
                
                //#line 328 . "x10/compiler/Foreach.x10"
                try {{
                    
                    //#line 329 . "x10/compiler/Foreach.x10"
                    final int t$113407 = x10.xrx.Runtime.get$NTHREADS();
                    
                    //#line 329 . "x10/compiler/Foreach.x10"
                    final long t$113408 = ((long)(((int)(t$113407))));
                    
                    //#line 329 . "x10/compiler/Foreach.x10"
                    final x10.array.DenseIterationSpace_2 block$113409 = ((x10.array.DenseIterationSpace_2)(x10.array.BlockingUtils.partitionBlockBlock(((x10.array.IterationSpace)(this.space$111934)), (long)(t$113408), (long)(this.myT$113406))));
                    
                    //#line 94 .. "x10/compiler/Foreach.x10"
                    final long min$113401 = block$113409.min0;
                    
                    //#line 94 .. "x10/compiler/Foreach.x10"
                    final long max$113402 = block$113409.max0;
                    
                    //#line 94 .. "x10/compiler/Foreach.x10"
                    final long min$113403 = block$113409.min1;
                    
                    //#line 94 .. "x10/compiler/Foreach.x10"
                    final long max$113404 = block$113409.max1;
                    
                    //#line 66 ... "x10/compiler/Foreach.x10"
                    long i$113396 = min$113401;
                    
                    //#line 66 ... "x10/compiler/Foreach.x10"
                    for (;
                         true;
                         ) {
                        
                        //#line 66 ... "x10/compiler/Foreach.x10"
                        final boolean t$113398 = ((i$113396) <= (((long)(max$113402))));
                        
                        //#line 66 ... "x10/compiler/Foreach.x10"
                        if (!(t$113398)) {
                            
                            //#line 66 ... "x10/compiler/Foreach.x10"
                            break;
                        }
                        
                        //#line 67 ... "x10/compiler/Foreach.x10"
                        long i$113388 = min$113403;
                        
                        //#line 67 ... "x10/compiler/Foreach.x10"
                        for (;
                             true;
                             ) {
                            
                            //#line 67 ... "x10/compiler/Foreach.x10"
                            final boolean t$113390 = ((i$113388) <= (((long)(max$113404))));
                            
                            //#line 67 ... "x10/compiler/Foreach.x10"
                            if (!(t$113390)) {
                                
                                //#line 67 ... "x10/compiler/Foreach.x10"
                                break;
                            }
                            
                            //#line 68 ... "x10/compiler/Foreach.x10"
                            ((x10.core.fun.VoidFun_0_2<x10.core.Long,x10.core.Long>)this.body$111935).$apply(x10.core.Long.$box(i$113396), x10.rtt.Types.LONG, x10.core.Long.$box(i$113388), x10.rtt.Types.LONG);
                            
                            //#line 67 ... "x10/compiler/Foreach.x10"
                            final long t$113387 = ((i$113388) + (((long)(1L))));
                            
                            //#line 67 ... "x10/compiler/Foreach.x10"
                            i$113388 = t$113387;
                        }
                        
                        //#line 66 ... "x10/compiler/Foreach.x10"
                        final long t$113395 = ((i$113396) + (((long)(1L))));
                        
                        //#line 66 ... "x10/compiler/Foreach.x10"
                        i$113396 = t$113395;
                    }
                }}catch (java.lang.Error __lowerer__var__0__) {
                    
                    //#line 328 . "x10/compiler/Foreach.x10"
                    throw __lowerer__var__0__;
                }catch (java.lang.Throwable __lowerer__var__1__) {
                    
                    //#line 328 . "x10/compiler/Foreach.x10"
                    throw x10.rtt.Types.EXCEPTION.isInstance(__lowerer__var__1__) ? (java.lang.RuntimeException)(__lowerer__var__1__) : new x10.lang.WrappedThrowable(__lowerer__var__1__);
                }
            }
            
            public x10.array.DenseIterationSpace_2 space$111934;
            public long myT$113406;
            public x10.core.fun.VoidFun_0_2<x10.core.Long,x10.core.Long> body$111935;
            
            public $Closure$28(final x10.array.DenseIterationSpace_2 space$111934, final long myT$113406, final x10.core.fun.VoidFun_0_2<x10.core.Long,x10.core.Long> body$111935, __2$1x10$lang$Long$3x10$lang$Long$2 $dummy) {
                 {
                    this.space$111934 = ((x10.array.DenseIterationSpace_2)(space$111934));
                    this.myT$113406 = myT$113406;
                    this.body$111935 = ((x10.core.fun.VoidFun_0_2)(body$111935));
                }
            }
            
        }
        
        @x10.runtime.impl.java.X10Generated
        final public static class $Closure$29 extends x10.core.Ref implements x10.core.fun.VoidFun_0_0, x10.serialization.X10JavaSerializable
        {
            public static final x10.rtt.RuntimeType<$Closure$29> $RTT = 
                x10.rtt.StaticVoidFunType.<$Closure$29> make($Closure$29.class,
                                                             new x10.rtt.Type[] {
                                                                 x10.core.fun.VoidFun_0_0.$RTT
                                                             });
            
            public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
            
            public x10.rtt.Type<?> $getParam(int i) { return null; }
            
            private Object writeReplace() throws java.io.ObjectStreamException {
                return new x10.serialization.SerializationProxy(this);
            }
            
            public static x10.serialization.X10JavaSerializable $_deserialize_body(x10.compiler.Foreach.$Closure$29 $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
                $_obj.body = $deserializer.readObject();
                $_obj.myT$113465 = $deserializer.readLong();
                $_obj.space = $deserializer.readObject();
                return $_obj;
            }
            
            public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
                x10.compiler.Foreach.$Closure$29 $_obj = new x10.compiler.Foreach.$Closure$29((java.lang.System[]) null);
                $deserializer.record_reference($_obj);
                return $_deserialize_body($_obj, $deserializer);
            }
            
            public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
                $serializer.write(this.body);
                $serializer.write(this.myT$113465);
                $serializer.write(this.space);
                
            }
            
            // constructor just for allocation
            public $Closure$29(final java.lang.System[] $dummy) {
                
            }
            
            // synthetic type for parameter mangling
            public static final class __2$1x10$lang$Long$3x10$lang$Long$2 {}
            
        
            
            public void $apply() {
                
                //#line 328 "x10/compiler/Foreach.x10"
                try {{
                    
                    //#line 329 "x10/compiler/Foreach.x10"
                    final int t$113466 = x10.xrx.Runtime.get$NTHREADS();
                    
                    //#line 329 "x10/compiler/Foreach.x10"
                    final long t$113467 = ((long)(((int)(t$113466))));
                    
                    //#line 329 "x10/compiler/Foreach.x10"
                    final x10.array.DenseIterationSpace_2 block$113468 = ((x10.array.DenseIterationSpace_2)(x10.array.BlockingUtils.partitionBlockBlock(((x10.array.IterationSpace)(this.space)), (long)(t$113467), (long)(this.myT$113465))));
                    
                    //#line 94 . "x10/compiler/Foreach.x10"
                    final long min$113460 = block$113468.min0;
                    
                    //#line 94 . "x10/compiler/Foreach.x10"
                    final long max$113461 = block$113468.max0;
                    
                    //#line 94 . "x10/compiler/Foreach.x10"
                    final long min$113462 = block$113468.min1;
                    
                    //#line 94 . "x10/compiler/Foreach.x10"
                    final long max$113463 = block$113468.max1;
                    
                    //#line 66 .. "x10/compiler/Foreach.x10"
                    long i$113455 = min$113460;
                    
                    //#line 66 .. "x10/compiler/Foreach.x10"
                    for (;
                         true;
                         ) {
                        
                        //#line 66 .. "x10/compiler/Foreach.x10"
                        final boolean t$113457 = ((i$113455) <= (((long)(max$113461))));
                        
                        //#line 66 .. "x10/compiler/Foreach.x10"
                        if (!(t$113457)) {
                            
                            //#line 66 .. "x10/compiler/Foreach.x10"
                            break;
                        }
                        
                        //#line 67 .. "x10/compiler/Foreach.x10"
                        long i$113447 = min$113462;
                        
                        //#line 67 .. "x10/compiler/Foreach.x10"
                        for (;
                             true;
                             ) {
                            
                            //#line 67 .. "x10/compiler/Foreach.x10"
                            final boolean t$113449 = ((i$113447) <= (((long)(max$113463))));
                            
                            //#line 67 .. "x10/compiler/Foreach.x10"
                            if (!(t$113449)) {
                                
                                //#line 67 .. "x10/compiler/Foreach.x10"
                                break;
                            }
                            
                            //#line 68 .. "x10/compiler/Foreach.x10"
                            ((x10.core.fun.VoidFun_0_2<x10.core.Long,x10.core.Long>)this.body).$apply(x10.core.Long.$box(i$113455), x10.rtt.Types.LONG, x10.core.Long.$box(i$113447), x10.rtt.Types.LONG);
                            
                            //#line 67 .. "x10/compiler/Foreach.x10"
                            final long t$113446 = ((i$113447) + (((long)(1L))));
                            
                            //#line 67 .. "x10/compiler/Foreach.x10"
                            i$113447 = t$113446;
                        }
                        
                        //#line 66 .. "x10/compiler/Foreach.x10"
                        final long t$113454 = ((i$113455) + (((long)(1L))));
                        
                        //#line 66 .. "x10/compiler/Foreach.x10"
                        i$113455 = t$113454;
                    }
                }}catch (java.lang.Error __lowerer__var__0__) {
                    
                    //#line 328 "x10/compiler/Foreach.x10"
                    throw __lowerer__var__0__;
                }catch (java.lang.Throwable __lowerer__var__1__) {
                    
                    //#line 328 "x10/compiler/Foreach.x10"
                    throw x10.rtt.Types.EXCEPTION.isInstance(__lowerer__var__1__) ? (java.lang.RuntimeException)(__lowerer__var__1__) : new x10.lang.WrappedThrowable(__lowerer__var__1__);
                }
            }
            
            public x10.array.DenseIterationSpace_2 space;
            public long myT$113465;
            public x10.core.fun.VoidFun_0_2<x10.core.Long,x10.core.Long> body;
            
            public $Closure$29(final x10.array.DenseIterationSpace_2 space, final long myT$113465, final x10.core.fun.VoidFun_0_2<x10.core.Long,x10.core.Long> body, __2$1x10$lang$Long$3x10$lang$Long$2 $dummy) {
                 {
                    this.space = ((x10.array.DenseIterationSpace_2)(space));
                    this.myT$113465 = myT$113465;
                    this.body = body;
                }
            }
            
        }
        
        @x10.runtime.impl.java.X10Generated
        final public static class $Closure$30<$T> extends x10.core.Ref implements x10.core.fun.VoidFun_0_0, x10.serialization.X10JavaSerializable
        {
            public static final x10.rtt.RuntimeType<$Closure$30> $RTT = 
                x10.rtt.StaticVoidFunType.<$Closure$30> make($Closure$30.class,
                                                             1,
                                                             new x10.rtt.Type[] {
                                                                 x10.core.fun.VoidFun_0_0.$RTT
                                                             });
            
            public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
            
            public x10.rtt.Type<?> $getParam(int i) { if (i == 0) return $T; return null; }
            
            private Object writeReplace() throws java.io.ObjectStreamException {
                return new x10.serialization.SerializationProxy(this);
            }
            
            public static <$T> x10.serialization.X10JavaSerializable $_deserialize_body(x10.compiler.Foreach.$Closure$30<$T> $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
                $_obj.$T = (x10.rtt.Type) $deserializer.readObject();
                $_obj.block$113514 = $deserializer.readObject();
                $_obj.body = $deserializer.readObject();
                $_obj.identity = $deserializer.readObject();
                $_obj.myT$113511 = $deserializer.readLong();
                $_obj.reduce = $deserializer.readObject();
                $_obj.results = $deserializer.readObject();
                return $_obj;
            }
            
            public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
                x10.compiler.Foreach.$Closure$30 $_obj = new x10.compiler.Foreach.$Closure$30((java.lang.System[]) null, (x10.rtt.Type) null);
                $deserializer.record_reference($_obj);
                return $_deserialize_body($_obj, $deserializer);
            }
            
            public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
                $serializer.write(this.$T);
                $serializer.write(this.block$113514);
                $serializer.write(this.body);
                $serializer.write(this.identity);
                $serializer.write(this.myT$113511);
                $serializer.write(this.reduce);
                $serializer.write(this.results);
                
            }
            
            // constructor just for allocation
            public $Closure$30(final java.lang.System[] $dummy, final x10.rtt.Type $T) {
                x10.compiler.Foreach.$Closure$30.$initParams(this, $T);
                
            }
            
            private x10.rtt.Type $T;
            
            // initializer of type parameters
            public static void $initParams(final $Closure$30 $this, final x10.rtt.Type $T) {
                $this.$T = $T;
                
            }
            // synthetic type for parameter mangling for __0x10$compiler$Foreach$$Closure$30$$T__2$1x10$lang$Long$3x10$lang$Long$3x10$compiler$Foreach$$Closure$30$$T$2__3$1x10$compiler$Foreach$$Closure$30$$T$3x10$compiler$Foreach$$Closure$30$$T$3x10$compiler$Foreach$$Closure$30$$T$2__4$1x10$compiler$Foreach$$Closure$30$$T$2
            public static final class $_273ec00a {}
            
        
            
            public void $apply() {
                
                //#line 356 "x10/compiler/Foreach.x10"
                try {{
                    
                    //#line 139 . "x10/compiler/Foreach.x10"
                    $T myRes$113519 = (($T)(this.identity));
                    
                    //#line 140 . "x10/compiler/Foreach.x10"
                    final long i$111517min$113509 = this.block$113514.min0;
                    
                    //#line 140 . "x10/compiler/Foreach.x10"
                    final long i$111517max$113510 = this.block$113514.max0;
                    
                    //#line 140 . "x10/compiler/Foreach.x10"
                    long i$113506 = i$111517min$113509;
                    
                    //#line 140 . "x10/compiler/Foreach.x10"
                    for (;
                         true;
                         ) {
                        
                        //#line 140 . "x10/compiler/Foreach.x10"
                        final boolean t$113508 = ((i$113506) <= (((long)(i$111517max$113510))));
                        
                        //#line 140 . "x10/compiler/Foreach.x10"
                        if (!(t$113508)) {
                            
                            //#line 140 . "x10/compiler/Foreach.x10"
                            break;
                        }
                        
                        //#line 141 . "x10/compiler/Foreach.x10"
                        final long i$111499min$113501 = this.block$113514.min1;
                        
                        //#line 141 . "x10/compiler/Foreach.x10"
                        final long i$111499max$113502 = this.block$113514.max1;
                        
                        //#line 141 . "x10/compiler/Foreach.x10"
                        long i$113498 = i$111499min$113501;
                        
                        //#line 141 . "x10/compiler/Foreach.x10"
                        for (;
                             true;
                             ) {
                            
                            //#line 141 . "x10/compiler/Foreach.x10"
                            final boolean t$113500 = ((i$113498) <= (((long)(i$111499max$113502))));
                            
                            //#line 141 . "x10/compiler/Foreach.x10"
                            if (!(t$113500)) {
                                
                                //#line 141 . "x10/compiler/Foreach.x10"
                                break;
                            }
                            
                            //#line 142 . "x10/compiler/Foreach.x10"
                            final $T t$113493 = (($T)((($T)
                                                        ((x10.core.fun.Fun_0_2<x10.core.Long,x10.core.Long,$T>)this.body).$apply(x10.core.Long.$box(i$113506), x10.rtt.Types.LONG, x10.core.Long.$box(i$113498), x10.rtt.Types.LONG))));
                            
                            //#line 142 . "x10/compiler/Foreach.x10"
                            final $T t$113494 = (($T)((($T)
                                                        ((x10.core.fun.Fun_0_2<$T,$T,$T>)this.reduce).$apply(myRes$113519, $T, t$113493, $T))));
                            
                            //#line 142 . "x10/compiler/Foreach.x10"
                            myRes$113519 = (($T)(t$113494));
                            
                            //#line 141 . "x10/compiler/Foreach.x10"
                            final long t$113497 = ((i$113498) + (((long)(1L))));
                            
                            //#line 141 . "x10/compiler/Foreach.x10"
                            i$113498 = t$113497;
                        }
                        
                        //#line 140 . "x10/compiler/Foreach.x10"
                        final long t$113505 = ((i$113506) + (((long)(1L))));
                        
                        //#line 140 . "x10/compiler/Foreach.x10"
                        i$113506 = t$113505;
                    }
                    
                    //#line 356 "x10/compiler/Foreach.x10"
                    ((x10.core.Rail<$T>)this.results).$set__1x10$lang$Rail$$T$G((long)(this.myT$113511), (($T)(myRes$113519)));
                }}catch (java.lang.Error __lowerer__var__0__) {
                    
                    //#line 356 "x10/compiler/Foreach.x10"
                    throw __lowerer__var__0__;
                }catch (java.lang.Throwable __lowerer__var__1__) {
                    
                    //#line 356 "x10/compiler/Foreach.x10"
                    throw x10.rtt.Types.EXCEPTION.isInstance(__lowerer__var__1__) ? (java.lang.RuntimeException)(__lowerer__var__1__) : new x10.lang.WrappedThrowable(__lowerer__var__1__);
                }
            }
            
            public $T identity;
            public x10.array.DenseIterationSpace_2 block$113514;
            public x10.core.fun.Fun_0_2<x10.core.Long,x10.core.Long,$T> body;
            public x10.core.fun.Fun_0_2<$T,$T,$T> reduce;
            public x10.core.Rail<$T> results;
            public long myT$113511;
            
            public $Closure$30(final x10.rtt.Type $T, final $T identity, final x10.array.DenseIterationSpace_2 block$113514, final x10.core.fun.Fun_0_2<x10.core.Long,x10.core.Long,$T> body, final x10.core.fun.Fun_0_2<$T,$T,$T> reduce, final x10.core.Rail<$T> results, final long myT$113511, $_273ec00a $dummy) {
                x10.compiler.Foreach.$Closure$30.$initParams(this, $T);
                 {
                    ((x10.compiler.Foreach.$Closure$30<$T>)this).identity = (($T)(identity));
                    ((x10.compiler.Foreach.$Closure$30<$T>)this).block$113514 = ((x10.array.DenseIterationSpace_2)(block$113514));
                    ((x10.compiler.Foreach.$Closure$30<$T>)this).body = body;
                    ((x10.compiler.Foreach.$Closure$30<$T>)this).reduce = reduce;
                    ((x10.compiler.Foreach.$Closure$30<$T>)this).results = ((x10.core.Rail)(results));
                    ((x10.compiler.Foreach.$Closure$30<$T>)this).myT$113511 = myT$113511;
                }
            }
            
        }
        
        @x10.runtime.impl.java.X10Generated
        final public static class $Closure$31 extends x10.core.Ref implements x10.core.fun.VoidFun_0_0, x10.serialization.X10JavaSerializable
        {
            public static final x10.rtt.RuntimeType<$Closure$31> $RTT = 
                x10.rtt.StaticVoidFunType.<$Closure$31> make($Closure$31.class,
                                                             new x10.rtt.Type[] {
                                                                 x10.core.fun.VoidFun_0_0.$RTT
                                                             });
            
            public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
            
            public x10.rtt.Type<?> $getParam(int i) { return null; }
            
            private Object writeReplace() throws java.io.ObjectStreamException {
                return new x10.serialization.SerializationProxy(this);
            }
            
            public static x10.serialization.X10JavaSerializable $_deserialize_body(x10.compiler.Foreach.$Closure$31 $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
                $_obj.body = $deserializer.readObject();
                $_obj.max = $deserializer.readLong();
                $_obj.min = $deserializer.readLong();
                $_obj.t$113551 = $deserializer.readLong();
                return $_obj;
            }
            
            public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
                x10.compiler.Foreach.$Closure$31 $_obj = new x10.compiler.Foreach.$Closure$31((java.lang.System[]) null);
                $deserializer.record_reference($_obj);
                return $_deserialize_body($_obj, $deserializer);
            }
            
            public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
                $serializer.write(this.body);
                $serializer.write(this.max);
                $serializer.write(this.min);
                $serializer.write(this.t$113551);
                
            }
            
            // constructor just for allocation
            public $Closure$31(final java.lang.System[] $dummy) {
                
            }
            
            // synthetic type for parameter mangling
            public static final class __3$1x10$lang$Long$2 {}
            
        
            
            public void $apply() {
                
                //#line 380 "x10/compiler/Foreach.x10"
                try {{
                    
                    //#line 381 "x10/compiler/Foreach.x10"
                    long i$113548 = ((this.min) + (((long)(this.t$113551))));
                    
                    //#line 381 "x10/compiler/Foreach.x10"
                    for (;
                         true;
                         ) {
                        
                        //#line 381 "x10/compiler/Foreach.x10"
                        final boolean t$113550 = ((i$113548) <= (((long)(this.max))));
                        
                        //#line 381 "x10/compiler/Foreach.x10"
                        if (!(t$113550)) {
                            
                            //#line 381 "x10/compiler/Foreach.x10"
                            break;
                        }
                        
                        //#line 382 "x10/compiler/Foreach.x10"
                        ((x10.core.fun.VoidFun_0_1<x10.core.Long>)this.body).$apply(x10.core.Long.$box(i$113548), x10.rtt.Types.LONG);
                        
                        //#line 381 "x10/compiler/Foreach.x10"
                        final int t$113545 = x10.xrx.Runtime.get$NTHREADS();
                        
                        //#line 381 "x10/compiler/Foreach.x10"
                        final long t$113546 = ((long)(((int)(t$113545))));
                        
                        //#line 381 "x10/compiler/Foreach.x10"
                        final long t$113547 = ((i$113548) + (((long)(t$113546))));
                        
                        //#line 381 "x10/compiler/Foreach.x10"
                        i$113548 = t$113547;
                    }
                }}catch (java.lang.Error __lowerer__var__0__) {
                    
                    //#line 380 "x10/compiler/Foreach.x10"
                    throw __lowerer__var__0__;
                }catch (java.lang.Throwable __lowerer__var__1__) {
                    
                    //#line 380 "x10/compiler/Foreach.x10"
                    throw x10.rtt.Types.EXCEPTION.isInstance(__lowerer__var__1__) ? (java.lang.RuntimeException)(__lowerer__var__1__) : new x10.lang.WrappedThrowable(__lowerer__var__1__);
                }
            }
            
            public long min;
            public long t$113551;
            public long max;
            public x10.core.fun.VoidFun_0_1<x10.core.Long> body;
            
            public $Closure$31(final long min, final long t$113551, final long max, final x10.core.fun.VoidFun_0_1<x10.core.Long> body, __3$1x10$lang$Long$2 $dummy) {
                 {
                    this.min = min;
                    this.t$113551 = t$113551;
                    this.max = max;
                    this.body = ((x10.core.fun.VoidFun_0_1)(body));
                }
            }
            
        }
        
        @x10.runtime.impl.java.X10Generated
        final public static class $Closure$32<$T> extends x10.core.Ref implements x10.core.fun.VoidFun_0_0, x10.serialization.X10JavaSerializable
        {
            public static final x10.rtt.RuntimeType<$Closure$32> $RTT = 
                x10.rtt.StaticVoidFunType.<$Closure$32> make($Closure$32.class,
                                                             1,
                                                             new x10.rtt.Type[] {
                                                                 x10.core.fun.VoidFun_0_0.$RTT
                                                             });
            
            public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
            
            public x10.rtt.Type<?> $getParam(int i) { if (i == 0) return $T; return null; }
            
            private Object writeReplace() throws java.io.ObjectStreamException {
                return new x10.serialization.SerializationProxy(this);
            }
            
            public static <$T> x10.serialization.X10JavaSerializable $_deserialize_body(x10.compiler.Foreach.$Closure$32<$T> $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
                $_obj.$T = (x10.rtt.Type) $deserializer.readObject();
                $_obj.body = $deserializer.readObject();
                $_obj.identity = $deserializer.readObject();
                $_obj.max = $deserializer.readLong();
                $_obj.min = $deserializer.readLong();
                $_obj.reduce = $deserializer.readObject();
                $_obj.results = $deserializer.readObject();
                $_obj.t$113581 = $deserializer.readLong();
                return $_obj;
            }
            
            public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
                x10.compiler.Foreach.$Closure$32 $_obj = new x10.compiler.Foreach.$Closure$32((java.lang.System[]) null, (x10.rtt.Type) null);
                $deserializer.record_reference($_obj);
                return $_deserialize_body($_obj, $deserializer);
            }
            
            public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
                $serializer.write(this.$T);
                $serializer.write(this.body);
                $serializer.write(this.identity);
                $serializer.write(this.max);
                $serializer.write(this.min);
                $serializer.write(this.reduce);
                $serializer.write(this.results);
                $serializer.write(this.t$113581);
                
            }
            
            // constructor just for allocation
            public $Closure$32(final java.lang.System[] $dummy, final x10.rtt.Type $T) {
                x10.compiler.Foreach.$Closure$32.$initParams(this, $T);
                
            }
            
            private x10.rtt.Type $T;
            
            // initializer of type parameters
            public static void $initParams(final $Closure$32 $this, final x10.rtt.Type $T) {
                $this.$T = $T;
                
            }
            // synthetic type for parameter mangling for __0x10$compiler$Foreach$$Closure$32$$T__4$1x10$lang$Long$3x10$compiler$Foreach$$Closure$32$$T$2__5$1x10$compiler$Foreach$$Closure$32$$T$3x10$compiler$Foreach$$Closure$32$$T$3x10$compiler$Foreach$$Closure$32$$T$2__6$1x10$compiler$Foreach$$Closure$32$$T$2
            public static final class $_eec31cb6 {}
            
        
            
            public void $apply() {
                
                //#line 406 "x10/compiler/Foreach.x10"
                try {{
                    
                    //#line 407 "x10/compiler/Foreach.x10"
                    $T myRes$113579 = (($T)(this.identity));
                    
                    //#line 408 "x10/compiler/Foreach.x10"
                    long i$113576 = ((this.min) + (((long)(this.t$113581))));
                    
                    //#line 408 "x10/compiler/Foreach.x10"
                    for (;
                         true;
                         ) {
                        
                        //#line 408 "x10/compiler/Foreach.x10"
                        final boolean t$113578 = ((i$113576) <= (((long)(this.max))));
                        
                        //#line 408 "x10/compiler/Foreach.x10"
                        if (!(t$113578)) {
                            
                            //#line 408 "x10/compiler/Foreach.x10"
                            break;
                        }
                        
                        //#line 409 "x10/compiler/Foreach.x10"
                        final $T t$113570 = (($T)((($T)
                                                    ((x10.core.fun.Fun_0_1<x10.core.Long,$T>)this.body).$apply(x10.core.Long.$box(i$113576), x10.rtt.Types.LONG))));
                        
                        //#line 409 "x10/compiler/Foreach.x10"
                        final $T t$113571 = (($T)((($T)
                                                    ((x10.core.fun.Fun_0_2<$T,$T,$T>)this.reduce).$apply(myRes$113579, $T, t$113570, $T))));
                        
                        //#line 409 "x10/compiler/Foreach.x10"
                        myRes$113579 = (($T)(t$113571));
                        
                        //#line 408 "x10/compiler/Foreach.x10"
                        final int t$113573 = x10.xrx.Runtime.get$NTHREADS();
                        
                        //#line 408 "x10/compiler/Foreach.x10"
                        final long t$113574 = ((long)(((int)(t$113573))));
                        
                        //#line 408 "x10/compiler/Foreach.x10"
                        final long t$113575 = ((i$113576) + (((long)(t$113574))));
                        
                        //#line 408 "x10/compiler/Foreach.x10"
                        i$113576 = t$113575;
                    }
                    
                    //#line 411 "x10/compiler/Foreach.x10"
                    ((x10.core.Rail<$T>)this.results).$set__1x10$lang$Rail$$T$G((long)(this.t$113581), (($T)(myRes$113579)));
                }}catch (java.lang.Error __lowerer__var__0__) {
                    
                    //#line 406 "x10/compiler/Foreach.x10"
                    throw __lowerer__var__0__;
                }catch (java.lang.Throwable __lowerer__var__1__) {
                    
                    //#line 406 "x10/compiler/Foreach.x10"
                    throw x10.rtt.Types.EXCEPTION.isInstance(__lowerer__var__1__) ? (java.lang.RuntimeException)(__lowerer__var__1__) : new x10.lang.WrappedThrowable(__lowerer__var__1__);
                }
            }
            
            public $T identity;
            public long min;
            public long t$113581;
            public long max;
            public x10.core.fun.Fun_0_1<x10.core.Long,$T> body;
            public x10.core.fun.Fun_0_2<$T,$T,$T> reduce;
            public x10.core.Rail<$T> results;
            
            public $Closure$32(final x10.rtt.Type $T, final $T identity, final long min, final long t$113581, final long max, final x10.core.fun.Fun_0_1<x10.core.Long,$T> body, final x10.core.fun.Fun_0_2<$T,$T,$T> reduce, final x10.core.Rail<$T> results, $_eec31cb6 $dummy) {
                x10.compiler.Foreach.$Closure$32.$initParams(this, $T);
                 {
                    ((x10.compiler.Foreach.$Closure$32<$T>)this).identity = (($T)(identity));
                    ((x10.compiler.Foreach.$Closure$32<$T>)this).min = min;
                    ((x10.compiler.Foreach.$Closure$32<$T>)this).t$113581 = t$113581;
                    ((x10.compiler.Foreach.$Closure$32<$T>)this).max = max;
                    ((x10.compiler.Foreach.$Closure$32<$T>)this).body = ((x10.core.fun.Fun_0_1)(body));
                    ((x10.compiler.Foreach.$Closure$32<$T>)this).reduce = ((x10.core.fun.Fun_0_2)(reduce));
                    ((x10.compiler.Foreach.$Closure$32<$T>)this).results = ((x10.core.Rail)(results));
                }
            }
            
        }
        
        @x10.runtime.impl.java.X10Generated
        final public static class $Closure$33 extends x10.core.Ref implements x10.core.fun.VoidFun_0_2, x10.serialization.X10JavaSerializable
        {
            public static final x10.rtt.RuntimeType<$Closure$33> $RTT = 
                x10.rtt.StaticVoidFunType.<$Closure$33> make($Closure$33.class,
                                                             new x10.rtt.Type[] {
                                                                 x10.rtt.ParameterizedType.make(x10.core.fun.VoidFun_0_2.$RTT, x10.rtt.Types.LONG, x10.rtt.Types.LONG)
                                                             });
            
            public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
            
            public x10.rtt.Type<?> $getParam(int i) { return null; }
            
            private Object writeReplace() throws java.io.ObjectStreamException {
                return new x10.serialization.SerializationProxy(this);
            }
            
            public static x10.serialization.X10JavaSerializable $_deserialize_body(x10.compiler.Foreach.$Closure$33 $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
                $_obj.body = $deserializer.readObject();
                return $_obj;
            }
            
            public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
                x10.compiler.Foreach.$Closure$33 $_obj = new x10.compiler.Foreach.$Closure$33((java.lang.System[]) null);
                $deserializer.record_reference($_obj);
                return $_deserialize_body($_obj, $deserializer);
            }
            
            public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
                $serializer.write(this.body);
                
            }
            
            // constructor just for allocation
            public $Closure$33(final java.lang.System[] $dummy) {
                
            }
            
            // dispatcher for method abstract public (Z1,Z2)=>void.operator()(a1:Z1, a2:Z2):void
            public java.lang.Object $apply(final java.lang.Object a1, final x10.rtt.Type t1, final java.lang.Object a2, final x10.rtt.Type t2) {
                $apply(x10.core.Long.$unbox(a1), x10.core.Long.$unbox(a2)); return null;
                
            }
            
            // dispatcher for method abstract public (Z1,Z2)=>void.operator()(a1:Z1, a2:Z2):void
            public void $apply$V(final java.lang.Object a1, final x10.rtt.Type t1, final java.lang.Object a2, final x10.rtt.Type t2) {
                $apply(x10.core.Long.$unbox(a1), x10.core.Long.$unbox(a2));
                
            }
            
            // synthetic type for parameter mangling
            public static final class __0$1x10$lang$Long$2 {}
            
        
            
            public void $apply(final long start, final long end) {
                
                //#line 474 "x10/compiler/Foreach.x10"
                long i$113616 = start;
                
                //#line 474 "x10/compiler/Foreach.x10"
                for (;
                     true;
                     ) {
                    
                    //#line 474 "x10/compiler/Foreach.x10"
                    final boolean t$113618 = ((i$113616) <= (((long)(end))));
                    
                    //#line 474 "x10/compiler/Foreach.x10"
                    if (!(t$113618)) {
                        
                        //#line 474 "x10/compiler/Foreach.x10"
                        break;
                    }
                    
                    //#line 474 "x10/compiler/Foreach.x10"
                    ((x10.core.fun.VoidFun_0_1<x10.core.Long>)this.body).$apply(x10.core.Long.$box(i$113616), x10.rtt.Types.LONG);
                    
                    //#line 474 "x10/compiler/Foreach.x10"
                    final long t$113615 = ((i$113616) + (((long)(1L))));
                    
                    //#line 474 "x10/compiler/Foreach.x10"
                    i$113616 = t$113615;
                }
            }
            
            public x10.core.fun.VoidFun_0_1<x10.core.Long> body;
            
            public $Closure$33(final x10.core.fun.VoidFun_0_1<x10.core.Long> body, __0$1x10$lang$Long$2 $dummy) {
                 {
                    this.body = ((x10.core.fun.VoidFun_0_1)(body));
                }
            }
            
        }
        
        @x10.runtime.impl.java.X10Generated
        final public static class $Closure$34 extends x10.core.Ref implements x10.core.fun.VoidFun_0_2, x10.serialization.X10JavaSerializable
        {
            public static final x10.rtt.RuntimeType<$Closure$34> $RTT = 
                x10.rtt.StaticVoidFunType.<$Closure$34> make($Closure$34.class,
                                                             new x10.rtt.Type[] {
                                                                 x10.rtt.ParameterizedType.make(x10.core.fun.VoidFun_0_2.$RTT, x10.rtt.Types.LONG, x10.rtt.Types.LONG)
                                                             });
            
            public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
            
            public x10.rtt.Type<?> $getParam(int i) { return null; }
            
            private Object writeReplace() throws java.io.ObjectStreamException {
                return new x10.serialization.SerializationProxy(this);
            }
            
            public static x10.serialization.X10JavaSerializable $_deserialize_body(x10.compiler.Foreach.$Closure$34 $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
                $_obj.body$112079 = $deserializer.readObject();
                return $_obj;
            }
            
            public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
                x10.compiler.Foreach.$Closure$34 $_obj = new x10.compiler.Foreach.$Closure$34((java.lang.System[]) null);
                $deserializer.record_reference($_obj);
                return $_deserialize_body($_obj, $deserializer);
            }
            
            public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
                $serializer.write(this.body$112079);
                
            }
            
            // constructor just for allocation
            public $Closure$34(final java.lang.System[] $dummy) {
                
            }
            
            // dispatcher for method abstract public (Z1,Z2)=>void.operator()(a1:Z1, a2:Z2):void
            public java.lang.Object $apply(final java.lang.Object a1, final x10.rtt.Type t1, final java.lang.Object a2, final x10.rtt.Type t2) {
                $apply(x10.core.Long.$unbox(a1), x10.core.Long.$unbox(a2)); return null;
                
            }
            
            // dispatcher for method abstract public (Z1,Z2)=>void.operator()(a1:Z1, a2:Z2):void
            public void $apply$V(final java.lang.Object a1, final x10.rtt.Type t1, final java.lang.Object a2, final x10.rtt.Type t2) {
                $apply(x10.core.Long.$unbox(a1), x10.core.Long.$unbox(a2));
                
            }
            
            // synthetic type for parameter mangling
            public static final class __0$1x10$lang$Long$2 {}
            
        
            
            public void $apply(final long start$113640, final long end$113641) {
                
                //#line 474 . "x10/compiler/Foreach.x10"
                long i$113630 = start$113640;
                
                //#line 474 . "x10/compiler/Foreach.x10"
                for (;
                     true;
                     ) {
                    
                    //#line 474 . "x10/compiler/Foreach.x10"
                    final boolean t$113632 = ((i$113630) <= (((long)(end$113641))));
                    
                    //#line 474 . "x10/compiler/Foreach.x10"
                    if (!(t$113632)) {
                        
                        //#line 474 . "x10/compiler/Foreach.x10"
                        break;
                    }
                    
                    //#line 474 . "x10/compiler/Foreach.x10"
                    ((x10.core.fun.VoidFun_0_1<x10.core.Long>)this.body$112079).$apply(x10.core.Long.$box(i$113630), x10.rtt.Types.LONG);
                    
                    //#line 474 . "x10/compiler/Foreach.x10"
                    final long t$113629 = ((i$113630) + (((long)(1L))));
                    
                    //#line 474 . "x10/compiler/Foreach.x10"
                    i$113630 = t$113629;
                }
            }
            
            public x10.core.fun.VoidFun_0_1<x10.core.Long> body$112079;
            
            public $Closure$34(final x10.core.fun.VoidFun_0_1<x10.core.Long> body$112079, __0$1x10$lang$Long$2 $dummy) {
                 {
                    this.body$112079 = ((x10.core.fun.VoidFun_0_1)(body$112079));
                }
            }
            
        }
        
        @x10.runtime.impl.java.X10Generated
        final public static class $Closure$35 extends x10.core.Ref implements x10.core.fun.VoidFun_0_0, x10.serialization.X10JavaSerializable
        {
            public static final x10.rtt.RuntimeType<$Closure$35> $RTT = 
                x10.rtt.StaticVoidFunType.<$Closure$35> make($Closure$35.class,
                                                             new x10.rtt.Type[] {
                                                                 x10.core.fun.VoidFun_0_0.$RTT
                                                             });
            
            public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
            
            public x10.rtt.Type<?> $getParam(int i) { return null; }
            
            private Object writeReplace() throws java.io.ObjectStreamException {
                return new x10.serialization.SerializationProxy(this);
            }
            
            public static x10.serialization.X10JavaSerializable $_deserialize_body(x10.compiler.Foreach.$Closure$35 $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
                $_obj.body = $deserializer.readObject();
                $_obj.end = $deserializer.readLong();
                $_obj.grainSize = $deserializer.readLong();
                $_obj.start = $deserializer.readLong();
                return $_obj;
            }
            
            public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
                x10.compiler.Foreach.$Closure$35 $_obj = new x10.compiler.Foreach.$Closure$35((java.lang.System[]) null);
                $deserializer.record_reference($_obj);
                return $_deserialize_body($_obj, $deserializer);
            }
            
            public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
                $serializer.write(this.body);
                $serializer.write(this.end);
                $serializer.write(this.grainSize);
                $serializer.write(this.start);
                
            }
            
            // constructor just for allocation
            public $Closure$35(final java.lang.System[] $dummy) {
                
            }
            
            // synthetic type for parameter mangling
            public static final class __3$1x10$lang$Long$3x10$lang$Long$2 {}
            
        
            
            public void $apply() {
                
                //#line 499 "x10/compiler/Foreach.x10"
                try {{
                    
                    //#line 499 "x10/compiler/Foreach.x10"
                    final long t$112790 = ((this.start) + (((long)(this.end))));
                    
                    //#line 499 "x10/compiler/Foreach.x10"
                    final long t$112791 = ((t$112790) / (((long)(2L))));
                    
                    //#line 499 "x10/compiler/Foreach.x10"
                    x10.compiler.Foreach.doBisect1D__3$1x10$lang$Long$3x10$lang$Long$2((long)(t$112791), (long)(this.end), (long)(this.grainSize), ((x10.core.fun.VoidFun_0_2)(this.body)));
                }}catch (java.lang.Error __lowerer__var__0__) {
                    
                    //#line 499 "x10/compiler/Foreach.x10"
                    throw __lowerer__var__0__;
                }catch (java.lang.Throwable __lowerer__var__1__) {
                    
                    //#line 499 "x10/compiler/Foreach.x10"
                    throw x10.rtt.Types.EXCEPTION.isInstance(__lowerer__var__1__) ? (java.lang.RuntimeException)(__lowerer__var__1__) : new x10.lang.WrappedThrowable(__lowerer__var__1__);
                }
            }
            
            public long start;
            public long end;
            public long grainSize;
            public x10.core.fun.VoidFun_0_2<x10.core.Long,x10.core.Long> body;
            
            public $Closure$35(final long start, final long end, final long grainSize, final x10.core.fun.VoidFun_0_2<x10.core.Long,x10.core.Long> body, __3$1x10$lang$Long$3x10$lang$Long$2 $dummy) {
                 {
                    this.start = start;
                    this.end = end;
                    this.grainSize = grainSize;
                    this.body = ((x10.core.fun.VoidFun_0_2)(body));
                }
            }
            
        }
        
        @x10.runtime.impl.java.X10Generated
        final public static class $Closure$36<$T> extends x10.core.Ref implements x10.core.fun.Fun_0_2, x10.serialization.X10JavaSerializable
        {
            public static final x10.rtt.RuntimeType<$Closure$36> $RTT = 
                x10.rtt.StaticFunType.<$Closure$36> make($Closure$36.class,
                                                         1,
                                                         new x10.rtt.Type[] {
                                                             x10.rtt.ParameterizedType.make(x10.core.fun.Fun_0_2.$RTT, x10.rtt.Types.LONG, x10.rtt.Types.LONG, x10.rtt.UnresolvedType.PARAM(0))
                                                         });
            
            public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
            
            public x10.rtt.Type<?> $getParam(int i) { if (i == 0) return $T; return null; }
            
            private Object writeReplace() throws java.io.ObjectStreamException {
                return new x10.serialization.SerializationProxy(this);
            }
            
            public static <$T> x10.serialization.X10JavaSerializable $_deserialize_body(x10.compiler.Foreach.$Closure$36<$T> $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
                $_obj.$T = (x10.rtt.Type) $deserializer.readObject();
                $_obj.body = $deserializer.readObject();
                $_obj.identity = $deserializer.readObject();
                $_obj.reduce = $deserializer.readObject();
                return $_obj;
            }
            
            public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
                x10.compiler.Foreach.$Closure$36 $_obj = new x10.compiler.Foreach.$Closure$36((java.lang.System[]) null, (x10.rtt.Type) null);
                $deserializer.record_reference($_obj);
                return $_deserialize_body($_obj, $deserializer);
            }
            
            public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
                $serializer.write(this.$T);
                $serializer.write(this.body);
                $serializer.write(this.identity);
                $serializer.write(this.reduce);
                
            }
            
            // constructor just for allocation
            public $Closure$36(final java.lang.System[] $dummy, final x10.rtt.Type $T) {
                x10.compiler.Foreach.$Closure$36.$initParams(this, $T);
                
            }
            
            // dispatcher for method abstract public (Z1,Z2)=>U.operator()(a1:Z1, a2:Z2):U
            public java.lang.Object $apply(final java.lang.Object a1, final x10.rtt.Type t1, final java.lang.Object a2, final x10.rtt.Type t2) {
                return $apply$G(x10.core.Long.$unbox(a1), x10.core.Long.$unbox(a2));
                
            }
            
            private x10.rtt.Type $T;
            
            // initializer of type parameters
            public static void $initParams(final $Closure$36 $this, final x10.rtt.Type $T) {
                $this.$T = $T;
                
            }
            // synthetic type for parameter mangling
            public static final class __0x10$compiler$Foreach$$Closure$36$$T__1$1x10$lang$Long$3x10$compiler$Foreach$$Closure$36$$T$2__2$1x10$compiler$Foreach$$Closure$36$$T$3x10$compiler$Foreach$$Closure$36$$T$3x10$compiler$Foreach$$Closure$36$$T$2 {}
            
        
            
            public $T $apply$G(final long start, final long end) {
                
                //#line 524 "x10/compiler/Foreach.x10"
                $T myRes = (($T)(this.identity));
                
                //#line 525 "x10/compiler/Foreach.x10"
                long i$113661 = start;
                
                //#line 525 "x10/compiler/Foreach.x10"
                for (;
                     true;
                     ) {
                    
                    //#line 525 "x10/compiler/Foreach.x10"
                    final boolean t$113663 = ((i$113661) <= (((long)(end))));
                    
                    //#line 525 "x10/compiler/Foreach.x10"
                    if (!(t$113663)) {
                        
                        //#line 525 "x10/compiler/Foreach.x10"
                        break;
                    }
                    
                    //#line 526 "x10/compiler/Foreach.x10"
                    final $T t$113656 = (($T)((($T)
                                                ((x10.core.fun.Fun_0_1<x10.core.Long,$T>)this.body).$apply(x10.core.Long.$box(i$113661), x10.rtt.Types.LONG))));
                    
                    //#line 526 "x10/compiler/Foreach.x10"
                    final $T t$113657 = (($T)((($T)
                                                ((x10.core.fun.Fun_0_2<$T,$T,$T>)this.reduce).$apply(myRes, $T, t$113656, $T))));
                    
                    //#line 526 "x10/compiler/Foreach.x10"
                    myRes = (($T)(t$113657));
                    
                    //#line 525 "x10/compiler/Foreach.x10"
                    final long t$113660 = ((i$113661) + (((long)(1L))));
                    
                    //#line 525 "x10/compiler/Foreach.x10"
                    i$113661 = t$113660;
                }
                
                //#line 528 "x10/compiler/Foreach.x10"
                return myRes;
            }
            
            public $T identity;
            public x10.core.fun.Fun_0_1<x10.core.Long,$T> body;
            public x10.core.fun.Fun_0_2<$T,$T,$T> reduce;
            
            public $Closure$36(final x10.rtt.Type $T, final $T identity, final x10.core.fun.Fun_0_1<x10.core.Long,$T> body, final x10.core.fun.Fun_0_2<$T,$T,$T> reduce, __0x10$compiler$Foreach$$Closure$36$$T__1$1x10$lang$Long$3x10$compiler$Foreach$$Closure$36$$T$2__2$1x10$compiler$Foreach$$Closure$36$$T$3x10$compiler$Foreach$$Closure$36$$T$3x10$compiler$Foreach$$Closure$36$$T$2 $dummy) {
                x10.compiler.Foreach.$Closure$36.$initParams(this, $T);
                 {
                    ((x10.compiler.Foreach.$Closure$36<$T>)this).identity = (($T)(identity));
                    ((x10.compiler.Foreach.$Closure$36<$T>)this).body = ((x10.core.fun.Fun_0_1)(body));
                    ((x10.compiler.Foreach.$Closure$36<$T>)this).reduce = ((x10.core.fun.Fun_0_2)(reduce));
                }
            }
            
        }
        
        @x10.runtime.impl.java.X10Generated
        final public static class $Closure$37<$T> extends x10.core.Ref implements x10.core.fun.Fun_0_2, x10.serialization.X10JavaSerializable
        {
            public static final x10.rtt.RuntimeType<$Closure$37> $RTT = 
                x10.rtt.StaticFunType.<$Closure$37> make($Closure$37.class,
                                                         1,
                                                         new x10.rtt.Type[] {
                                                             x10.rtt.ParameterizedType.make(x10.core.fun.Fun_0_2.$RTT, x10.rtt.Types.LONG, x10.rtt.Types.LONG, x10.rtt.UnresolvedType.PARAM(0))
                                                         });
            
            public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
            
            public x10.rtt.Type<?> $getParam(int i) { if (i == 0) return $T; return null; }
            
            private Object writeReplace() throws java.io.ObjectStreamException {
                return new x10.serialization.SerializationProxy(this);
            }
            
            public static <$T> x10.serialization.X10JavaSerializable $_deserialize_body(x10.compiler.Foreach.$Closure$37<$T> $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
                $_obj.$T = (x10.rtt.Type) $deserializer.readObject();
                $_obj.body$112136 = $deserializer.readObject();
                $_obj.identity$112138 = $deserializer.readObject();
                $_obj.reduce$112137 = $deserializer.readObject();
                return $_obj;
            }
            
            public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
                x10.compiler.Foreach.$Closure$37 $_obj = new x10.compiler.Foreach.$Closure$37((java.lang.System[]) null, (x10.rtt.Type) null);
                $deserializer.record_reference($_obj);
                return $_deserialize_body($_obj, $deserializer);
            }
            
            public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
                $serializer.write(this.$T);
                $serializer.write(this.body$112136);
                $serializer.write(this.identity$112138);
                $serializer.write(this.reduce$112137);
                
            }
            
            // constructor just for allocation
            public $Closure$37(final java.lang.System[] $dummy, final x10.rtt.Type $T) {
                x10.compiler.Foreach.$Closure$37.$initParams(this, $T);
                
            }
            
            // dispatcher for method abstract public (Z1,Z2)=>U.operator()(a1:Z1, a2:Z2):U
            public java.lang.Object $apply(final java.lang.Object a1, final x10.rtt.Type t1, final java.lang.Object a2, final x10.rtt.Type t2) {
                return $apply$G(x10.core.Long.$unbox(a1), x10.core.Long.$unbox(a2));
                
            }
            
            private x10.rtt.Type $T;
            
            // initializer of type parameters
            public static void $initParams(final $Closure$37 $this, final x10.rtt.Type $T) {
                $this.$T = $T;
                
            }
            // synthetic type for parameter mangling
            public static final class __0x10$compiler$Foreach$$Closure$37$$T__1$1x10$lang$Long$3x10$compiler$Foreach$$Closure$37$$T$2__2$1x10$compiler$Foreach$$Closure$37$$T$3x10$compiler$Foreach$$Closure$37$$T$3x10$compiler$Foreach$$Closure$37$$T$2 {}
            
        
            
            public $T $apply$G(final long start$113705, final long end$113706) {
                
                //#line 524 . "x10/compiler/Foreach.x10"
                $T myRes$113707 = (($T)(this.identity$112138));
                
                //#line 525 . "x10/compiler/Foreach.x10"
                long i$113683 = start$113705;
                
                //#line 525 . "x10/compiler/Foreach.x10"
                for (;
                     true;
                     ) {
                    
                    //#line 525 . "x10/compiler/Foreach.x10"
                    final boolean t$113685 = ((i$113683) <= (((long)(end$113706))));
                    
                    //#line 525 . "x10/compiler/Foreach.x10"
                    if (!(t$113685)) {
                        
                        //#line 525 . "x10/compiler/Foreach.x10"
                        break;
                    }
                    
                    //#line 526 . "x10/compiler/Foreach.x10"
                    final $T t$113678 = (($T)((($T)
                                                ((x10.core.fun.Fun_0_1<x10.core.Long,$T>)this.body$112136).$apply(x10.core.Long.$box(i$113683), x10.rtt.Types.LONG))));
                    
                    //#line 526 . "x10/compiler/Foreach.x10"
                    final $T t$113679 = (($T)((($T)
                                                ((x10.core.fun.Fun_0_2<$T,$T,$T>)this.reduce$112137).$apply(myRes$113707, $T, t$113678, $T))));
                    
                    //#line 526 . "x10/compiler/Foreach.x10"
                    myRes$113707 = (($T)(t$113679));
                    
                    //#line 525 . "x10/compiler/Foreach.x10"
                    final long t$113682 = ((i$113683) + (((long)(1L))));
                    
                    //#line 525 . "x10/compiler/Foreach.x10"
                    i$113683 = t$113682;
                }
                
                //#line 528 . "x10/compiler/Foreach.x10"
                return myRes$113707;
            }
            
            public $T identity$112138;
            public x10.core.fun.Fun_0_1<x10.core.Long,$T> body$112136;
            public x10.core.fun.Fun_0_2<$T,$T,$T> reduce$112137;
            
            public $Closure$37(final x10.rtt.Type $T, final $T identity$112138, final x10.core.fun.Fun_0_1<x10.core.Long,$T> body$112136, final x10.core.fun.Fun_0_2<$T,$T,$T> reduce$112137, __0x10$compiler$Foreach$$Closure$37$$T__1$1x10$lang$Long$3x10$compiler$Foreach$$Closure$37$$T$2__2$1x10$compiler$Foreach$$Closure$37$$T$3x10$compiler$Foreach$$Closure$37$$T$3x10$compiler$Foreach$$Closure$37$$T$2 $dummy) {
                x10.compiler.Foreach.$Closure$37.$initParams(this, $T);
                 {
                    ((x10.compiler.Foreach.$Closure$37<$T>)this).identity$112138 = (($T)(identity$112138));
                    ((x10.compiler.Foreach.$Closure$37<$T>)this).body$112136 = ((x10.core.fun.Fun_0_1)(body$112136));
                    ((x10.compiler.Foreach.$Closure$37<$T>)this).reduce$112137 = ((x10.core.fun.Fun_0_2)(reduce$112137));
                }
            }
            
        }
        
        @x10.runtime.impl.java.X10Generated
        final public static class $Closure$38<$T> extends x10.core.Ref implements x10.core.fun.VoidFun_0_0, x10.serialization.X10JavaSerializable
        {
            public static final x10.rtt.RuntimeType<$Closure$38> $RTT = 
                x10.rtt.StaticVoidFunType.<$Closure$38> make($Closure$38.class,
                                                             1,
                                                             new x10.rtt.Type[] {
                                                                 x10.core.fun.VoidFun_0_0.$RTT
                                                             });
            
            public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
            
            public x10.rtt.Type<?> $getParam(int i) { if (i == 0) return $T; return null; }
            
            private Object writeReplace() throws java.io.ObjectStreamException {
                return new x10.serialization.SerializationProxy(this);
            }
            
            public static <$T> x10.serialization.X10JavaSerializable $_deserialize_body(x10.compiler.Foreach.$Closure$38<$T> $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
                $_obj.$T = (x10.rtt.Type) $deserializer.readObject();
                $_obj.$asyncResult$114047 = $deserializer.readObject();
                $_obj.body = $deserializer.readObject();
                $_obj.end = $deserializer.readLong();
                $_obj.grainSize = $deserializer.readLong();
                $_obj.reduce = $deserializer.readObject();
                $_obj.start = $deserializer.readLong();
                return $_obj;
            }
            
            public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
                x10.compiler.Foreach.$Closure$38 $_obj = new x10.compiler.Foreach.$Closure$38((java.lang.System[]) null, (x10.rtt.Type) null);
                $deserializer.record_reference($_obj);
                return $_deserialize_body($_obj, $deserializer);
            }
            
            public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
                $serializer.write(this.$T);
                $serializer.write(this.$asyncResult$114047);
                $serializer.write(this.body);
                $serializer.write(this.end);
                $serializer.write(this.grainSize);
                $serializer.write(this.reduce);
                $serializer.write(this.start);
                
            }
            
            // constructor just for allocation
            public $Closure$38(final java.lang.System[] $dummy, final x10.rtt.Type $T) {
                x10.compiler.Foreach.$Closure$38.$initParams(this, $T);
                
            }
            
            private x10.rtt.Type $T;
            
            // initializer of type parameters
            public static void $initParams(final $Closure$38 $this, final x10.rtt.Type $T) {
                $this.$T = $T;
                
            }
            // synthetic type for parameter mangling
            public static final class __3$1x10$lang$Long$3x10$lang$Long$3x10$compiler$Foreach$$Closure$38$$T$2__4$1x10$compiler$Foreach$$Closure$38$$T$3x10$compiler$Foreach$$Closure$38$$T$3x10$compiler$Foreach$$Closure$38$$T$2 {}
            
        
            
            public void $apply() {
                
                //#line 598 "x10/compiler/Foreach.x10"
                try {{
                    
                    //#line 598 "x10/compiler/Foreach.x10"
                    final long t$112867 = ((this.start) + (((long)(this.end))));
                    
                    //#line 598 "x10/compiler/Foreach.x10"
                    final long t$112868 = ((t$112867) / (((long)(2L))));
                    
                    //#line 598 "x10/compiler/Foreach.x10"
                    final $T t$112869 = (($T)(x10.compiler.Foreach.<$T> doBisectReduce1D__3$1x10$lang$Long$3x10$lang$Long$3x10$compiler$Foreach$$T$2__4$1x10$compiler$Foreach$$T$3x10$compiler$Foreach$$T$3x10$compiler$Foreach$$T$2$G($T, (long)(t$112868), (long)(this.end), (long)(this.grainSize), ((x10.core.fun.Fun_0_2)(this.body)), ((x10.core.fun.Fun_0_2)(this.reduce)))));
                    
                    //#line 598 "x10/compiler/Foreach.x10"
                    this.$asyncResult$114047[(int)0]=t$112869;
                }}catch (java.lang.Error __lowerer__var__0__) {
                    
                    //#line 598 "x10/compiler/Foreach.x10"
                    throw __lowerer__var__0__;
                }catch (java.lang.Throwable __lowerer__var__1__) {
                    
                    //#line 598 "x10/compiler/Foreach.x10"
                    throw x10.rtt.Types.EXCEPTION.isInstance(__lowerer__var__1__) ? (java.lang.RuntimeException)(__lowerer__var__1__) : new x10.lang.WrappedThrowable(__lowerer__var__1__);
                }
            }
            
            public long start;
            public long end;
            public long grainSize;
            public x10.core.fun.Fun_0_2<x10.core.Long,x10.core.Long,$T> body;
            public x10.core.fun.Fun_0_2<$T,$T,$T> reduce;
            public $T[] $asyncResult$114047;
            
            public $Closure$38(final x10.rtt.Type $T, final long start, final long end, final long grainSize, final x10.core.fun.Fun_0_2<x10.core.Long,x10.core.Long,$T> body, final x10.core.fun.Fun_0_2<$T,$T,$T> reduce, final $T[] $asyncResult$114047, __3$1x10$lang$Long$3x10$lang$Long$3x10$compiler$Foreach$$Closure$38$$T$2__4$1x10$compiler$Foreach$$Closure$38$$T$3x10$compiler$Foreach$$Closure$38$$T$3x10$compiler$Foreach$$Closure$38$$T$2 $dummy) {
                x10.compiler.Foreach.$Closure$38.$initParams(this, $T);
                 {
                    ((x10.compiler.Foreach.$Closure$38<$T>)this).start = start;
                    ((x10.compiler.Foreach.$Closure$38<$T>)this).end = end;
                    ((x10.compiler.Foreach.$Closure$38<$T>)this).grainSize = grainSize;
                    ((x10.compiler.Foreach.$Closure$38<$T>)this).body = ((x10.core.fun.Fun_0_2)(body));
                    ((x10.compiler.Foreach.$Closure$38<$T>)this).reduce = ((x10.core.fun.Fun_0_2)(reduce));
                    ((x10.compiler.Foreach.$Closure$38<$T>)this).$asyncResult$114047 = $asyncResult$114047;
                }
            }
            
        }
        
        @x10.runtime.impl.java.X10Generated
        final public static class $Closure$39 extends x10.core.Ref implements x10.core.fun.VoidFun_0_4, x10.serialization.X10JavaSerializable
        {
            public static final x10.rtt.RuntimeType<$Closure$39> $RTT = 
                x10.rtt.StaticVoidFunType.<$Closure$39> make($Closure$39.class,
                                                             new x10.rtt.Type[] {
                                                                 x10.rtt.ParameterizedType.make(x10.core.fun.VoidFun_0_4.$RTT, x10.rtt.Types.LONG, x10.rtt.Types.LONG, x10.rtt.Types.LONG, x10.rtt.Types.LONG)
                                                             });
            
            public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
            
            public x10.rtt.Type<?> $getParam(int i) { return null; }
            
            private Object writeReplace() throws java.io.ObjectStreamException {
                return new x10.serialization.SerializationProxy(this);
            }
            
            public static x10.serialization.X10JavaSerializable $_deserialize_body(x10.compiler.Foreach.$Closure$39 $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
                $_obj.body = $deserializer.readObject();
                return $_obj;
            }
            
            public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
                x10.compiler.Foreach.$Closure$39 $_obj = new x10.compiler.Foreach.$Closure$39((java.lang.System[]) null);
                $deserializer.record_reference($_obj);
                return $_deserialize_body($_obj, $deserializer);
            }
            
            public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
                $serializer.write(this.body);
                
            }
            
            // constructor just for allocation
            public $Closure$39(final java.lang.System[] $dummy) {
                
            }
            
            // dispatcher for method abstract public (Z1,Z2,Z3,Z4)=>void.operator()(a1:Z1, a2:Z2, a3:Z3, a4:Z4):void
            public java.lang.Object $apply(final java.lang.Object a1, final x10.rtt.Type t1, final java.lang.Object a2, final x10.rtt.Type t2, final java.lang.Object a3, final x10.rtt.Type t3, final java.lang.Object a4, final x10.rtt.Type t4) {
                $apply(x10.core.Long.$unbox(a1), x10.core.Long.$unbox(a2), x10.core.Long.$unbox(a3), x10.core.Long.$unbox(a4)); return null;
                
            }
            
            // dispatcher for method abstract public (Z1,Z2,Z3,Z4)=>void.operator()(a1:Z1, a2:Z2, a3:Z3, a4:Z4):void
            public void $apply$V(final java.lang.Object a1, final x10.rtt.Type t1, final java.lang.Object a2, final x10.rtt.Type t2, final java.lang.Object a3, final x10.rtt.Type t3, final java.lang.Object a4, final x10.rtt.Type t4) {
                $apply(x10.core.Long.$unbox(a1), x10.core.Long.$unbox(a2), x10.core.Long.$unbox(a3), x10.core.Long.$unbox(a4));
                
            }
            
            // synthetic type for parameter mangling
            public static final class __0$1x10$lang$Long$3x10$lang$Long$2 {}
            
        
            
            public void $apply(final long min$113754, final long max$113755, final long min$113756, final long max$113757) {
                
                //#line 677 "x10/compiler/Foreach.x10"
                long i$113742 = min$113754;
                
                //#line 677 "x10/compiler/Foreach.x10"
                for (;
                     true;
                     ) {
                    
                    //#line 677 "x10/compiler/Foreach.x10"
                    final boolean t$113744 = ((i$113742) <= (((long)(max$113755))));
                    
                    //#line 677 "x10/compiler/Foreach.x10"
                    if (!(t$113744)) {
                        
                        //#line 677 "x10/compiler/Foreach.x10"
                        break;
                    }
                    
                    //#line 678 "x10/compiler/Foreach.x10"
                    long i$113734 = min$113756;
                    
                    //#line 678 "x10/compiler/Foreach.x10"
                    for (;
                         true;
                         ) {
                        
                        //#line 678 "x10/compiler/Foreach.x10"
                        final boolean t$113736 = ((i$113734) <= (((long)(max$113757))));
                        
                        //#line 678 "x10/compiler/Foreach.x10"
                        if (!(t$113736)) {
                            
                            //#line 678 "x10/compiler/Foreach.x10"
                            break;
                        }
                        
                        //#line 679 "x10/compiler/Foreach.x10"
                        ((x10.core.fun.VoidFun_0_2<x10.core.Long,x10.core.Long>)this.body).$apply(x10.core.Long.$box(i$113742), x10.rtt.Types.LONG, x10.core.Long.$box(i$113734), x10.rtt.Types.LONG);
                        
                        //#line 678 "x10/compiler/Foreach.x10"
                        final long t$113733 = ((i$113734) + (((long)(1L))));
                        
                        //#line 678 "x10/compiler/Foreach.x10"
                        i$113734 = t$113733;
                    }
                    
                    //#line 677 "x10/compiler/Foreach.x10"
                    final long t$113741 = ((i$113742) + (((long)(1L))));
                    
                    //#line 677 "x10/compiler/Foreach.x10"
                    i$113742 = t$113741;
                }
            }
            
            public x10.core.fun.VoidFun_0_2<x10.core.Long,x10.core.Long> body;
            
            public $Closure$39(final x10.core.fun.VoidFun_0_2<x10.core.Long,x10.core.Long> body, __0$1x10$lang$Long$3x10$lang$Long$2 $dummy) {
                 {
                    this.body = ((x10.core.fun.VoidFun_0_2)(body));
                }
            }
            
        }
        
        @x10.runtime.impl.java.X10Generated
        final public static class $Closure$40 extends x10.core.Ref implements x10.core.fun.VoidFun_0_4, x10.serialization.X10JavaSerializable
        {
            public static final x10.rtt.RuntimeType<$Closure$40> $RTT = 
                x10.rtt.StaticVoidFunType.<$Closure$40> make($Closure$40.class,
                                                             new x10.rtt.Type[] {
                                                                 x10.rtt.ParameterizedType.make(x10.core.fun.VoidFun_0_4.$RTT, x10.rtt.Types.LONG, x10.rtt.Types.LONG, x10.rtt.Types.LONG, x10.rtt.Types.LONG)
                                                             });
            
            public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
            
            public x10.rtt.Type<?> $getParam(int i) { return null; }
            
            private Object writeReplace() throws java.io.ObjectStreamException {
                return new x10.serialization.SerializationProxy(this);
            }
            
            public static x10.serialization.X10JavaSerializable $_deserialize_body(x10.compiler.Foreach.$Closure$40 $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
                $_obj.body$112204 = $deserializer.readObject();
                return $_obj;
            }
            
            public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
                x10.compiler.Foreach.$Closure$40 $_obj = new x10.compiler.Foreach.$Closure$40((java.lang.System[]) null);
                $deserializer.record_reference($_obj);
                return $_deserialize_body($_obj, $deserializer);
            }
            
            public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
                $serializer.write(this.body$112204);
                
            }
            
            // constructor just for allocation
            public $Closure$40(final java.lang.System[] $dummy) {
                
            }
            
            // dispatcher for method abstract public (Z1,Z2,Z3,Z4)=>void.operator()(a1:Z1, a2:Z2, a3:Z3, a4:Z4):void
            public java.lang.Object $apply(final java.lang.Object a1, final x10.rtt.Type t1, final java.lang.Object a2, final x10.rtt.Type t2, final java.lang.Object a3, final x10.rtt.Type t3, final java.lang.Object a4, final x10.rtt.Type t4) {
                $apply(x10.core.Long.$unbox(a1), x10.core.Long.$unbox(a2), x10.core.Long.$unbox(a3), x10.core.Long.$unbox(a4)); return null;
                
            }
            
            // dispatcher for method abstract public (Z1,Z2,Z3,Z4)=>void.operator()(a1:Z1, a2:Z2, a3:Z3, a4:Z4):void
            public void $apply$V(final java.lang.Object a1, final x10.rtt.Type t1, final java.lang.Object a2, final x10.rtt.Type t2, final java.lang.Object a3, final x10.rtt.Type t3, final java.lang.Object a4, final x10.rtt.Type t4) {
                $apply(x10.core.Long.$unbox(a1), x10.core.Long.$unbox(a2), x10.core.Long.$unbox(a3), x10.core.Long.$unbox(a4));
                
            }
            
            // synthetic type for parameter mangling
            public static final class __0$1x10$lang$Long$3x10$lang$Long$2 {}
            
        
            
            public void $apply(final long min$113799, final long max$113800, final long min$113801, final long max$113802) {
                
                //#line 677 . "x10/compiler/Foreach.x10"
                long i$113787 = min$113799;
                
                //#line 677 . "x10/compiler/Foreach.x10"
                for (;
                     true;
                     ) {
                    
                    //#line 677 . "x10/compiler/Foreach.x10"
                    final boolean t$113789 = ((i$113787) <= (((long)(max$113800))));
                    
                    //#line 677 . "x10/compiler/Foreach.x10"
                    if (!(t$113789)) {
                        
                        //#line 677 . "x10/compiler/Foreach.x10"
                        break;
                    }
                    
                    //#line 678 . "x10/compiler/Foreach.x10"
                    long i$113779 = min$113801;
                    
                    //#line 678 . "x10/compiler/Foreach.x10"
                    for (;
                         true;
                         ) {
                        
                        //#line 678 . "x10/compiler/Foreach.x10"
                        final boolean t$113781 = ((i$113779) <= (((long)(max$113802))));
                        
                        //#line 678 . "x10/compiler/Foreach.x10"
                        if (!(t$113781)) {
                            
                            //#line 678 . "x10/compiler/Foreach.x10"
                            break;
                        }
                        
                        //#line 679 . "x10/compiler/Foreach.x10"
                        ((x10.core.fun.VoidFun_0_2<x10.core.Long,x10.core.Long>)this.body$112204).$apply(x10.core.Long.$box(i$113787), x10.rtt.Types.LONG, x10.core.Long.$box(i$113779), x10.rtt.Types.LONG);
                        
                        //#line 678 . "x10/compiler/Foreach.x10"
                        final long t$113778 = ((i$113779) + (((long)(1L))));
                        
                        //#line 678 . "x10/compiler/Foreach.x10"
                        i$113779 = t$113778;
                    }
                    
                    //#line 677 . "x10/compiler/Foreach.x10"
                    final long t$113786 = ((i$113787) + (((long)(1L))));
                    
                    //#line 677 . "x10/compiler/Foreach.x10"
                    i$113787 = t$113786;
                }
            }
            
            public x10.core.fun.VoidFun_0_2<x10.core.Long,x10.core.Long> body$112204;
            
            public $Closure$40(final x10.core.fun.VoidFun_0_2<x10.core.Long,x10.core.Long> body$112204, __0$1x10$lang$Long$3x10$lang$Long$2 $dummy) {
                 {
                    this.body$112204 = ((x10.core.fun.VoidFun_0_2)(body$112204));
                }
            }
            
        }
        
        @x10.runtime.impl.java.X10Generated
        final public static class $Closure$41 extends x10.core.Ref implements x10.core.fun.VoidFun_0_0, x10.serialization.X10JavaSerializable
        {
            public static final x10.rtt.RuntimeType<$Closure$41> $RTT = 
                x10.rtt.StaticVoidFunType.<$Closure$41> make($Closure$41.class,
                                                             new x10.rtt.Type[] {
                                                                 x10.core.fun.VoidFun_0_0.$RTT
                                                             });
            
            public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
            
            public x10.rtt.Type<?> $getParam(int i) { return null; }
            
            private Object writeReplace() throws java.io.ObjectStreamException {
                return new x10.serialization.SerializationProxy(this);
            }
            
            public static x10.serialization.X10JavaSerializable $_deserialize_body(x10.compiler.Foreach.$Closure$41 $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
                $_obj.body = $deserializer.readObject();
                $_obj.e0 = $deserializer.readLong();
                $_obj.e1 = $deserializer.readLong();
                $_obj.g1 = $deserializer.readLong();
                $_obj.g2 = $deserializer.readLong();
                $_obj.s0 = $deserializer.readLong();
                $_obj.s1 = $deserializer.readLong();
                return $_obj;
            }
            
            public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
                x10.compiler.Foreach.$Closure$41 $_obj = new x10.compiler.Foreach.$Closure$41((java.lang.System[]) null);
                $deserializer.record_reference($_obj);
                return $_deserialize_body($_obj, $deserializer);
            }
            
            public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
                $serializer.write(this.body);
                $serializer.write(this.e0);
                $serializer.write(this.e1);
                $serializer.write(this.g1);
                $serializer.write(this.g2);
                $serializer.write(this.s0);
                $serializer.write(this.s1);
                
            }
            
            // constructor just for allocation
            public $Closure$41(final java.lang.System[] $dummy) {
                
            }
            
            // synthetic type for parameter mangling
            public static final class __6$1x10$lang$Long$3x10$lang$Long$3x10$lang$Long$3x10$lang$Long$2 {}
            
        
            
            public void $apply() {
                
                //#line 716 "x10/compiler/Foreach.x10"
                try {{
                    
                    //#line 716 "x10/compiler/Foreach.x10"
                    final long t$112957 = ((this.s0) + (((long)(this.e0))));
                    
                    //#line 716 "x10/compiler/Foreach.x10"
                    final long t$112958 = ((t$112957) / (((long)(2L))));
                    
                    //#line 716 "x10/compiler/Foreach.x10"
                    x10.compiler.Foreach.doBisect2D__6$1x10$lang$Long$3x10$lang$Long$3x10$lang$Long$3x10$lang$Long$2((long)(t$112958), (long)(this.e0), (long)(this.s1), (long)(this.e1), (long)(this.g1), (long)(this.g2), ((x10.core.fun.VoidFun_0_4)(this.body)));
                }}catch (java.lang.Error __lowerer__var__0__) {
                    
                    //#line 716 "x10/compiler/Foreach.x10"
                    throw __lowerer__var__0__;
                }catch (java.lang.Throwable __lowerer__var__1__) {
                    
                    //#line 716 "x10/compiler/Foreach.x10"
                    throw x10.rtt.Types.EXCEPTION.isInstance(__lowerer__var__1__) ? (java.lang.RuntimeException)(__lowerer__var__1__) : new x10.lang.WrappedThrowable(__lowerer__var__1__);
                }
            }
            
            public long s0;
            public long e0;
            public long s1;
            public long e1;
            public long g1;
            public long g2;
            public x10.core.fun.VoidFun_0_4<x10.core.Long,x10.core.Long,x10.core.Long,x10.core.Long> body;
            
            public $Closure$41(final long s0, final long e0, final long s1, final long e1, final long g1, final long g2, final x10.core.fun.VoidFun_0_4<x10.core.Long,x10.core.Long,x10.core.Long,x10.core.Long> body, __6$1x10$lang$Long$3x10$lang$Long$3x10$lang$Long$3x10$lang$Long$2 $dummy) {
                 {
                    this.s0 = s0;
                    this.e0 = e0;
                    this.s1 = s1;
                    this.e1 = e1;
                    this.g1 = g1;
                    this.g2 = g2;
                    this.body = ((x10.core.fun.VoidFun_0_4)(body));
                }
            }
            
        }
        
        @x10.runtime.impl.java.X10Generated
        final public static class $Closure$42 extends x10.core.Ref implements x10.core.fun.VoidFun_0_0, x10.serialization.X10JavaSerializable
        {
            public static final x10.rtt.RuntimeType<$Closure$42> $RTT = 
                x10.rtt.StaticVoidFunType.<$Closure$42> make($Closure$42.class,
                                                             new x10.rtt.Type[] {
                                                                 x10.core.fun.VoidFun_0_0.$RTT
                                                             });
            
            public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
            
            public x10.rtt.Type<?> $getParam(int i) { return null; }
            
            private Object writeReplace() throws java.io.ObjectStreamException {
                return new x10.serialization.SerializationProxy(this);
            }
            
            public static x10.serialization.X10JavaSerializable $_deserialize_body(x10.compiler.Foreach.$Closure$42 $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
                $_obj.body = $deserializer.readObject();
                $_obj.e0 = $deserializer.readLong();
                $_obj.e1 = $deserializer.readLong();
                $_obj.g1 = $deserializer.readLong();
                $_obj.g2 = $deserializer.readLong();
                $_obj.s0 = $deserializer.readLong();
                $_obj.s1 = $deserializer.readLong();
                return $_obj;
            }
            
            public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
                x10.compiler.Foreach.$Closure$42 $_obj = new x10.compiler.Foreach.$Closure$42((java.lang.System[]) null);
                $deserializer.record_reference($_obj);
                return $_deserialize_body($_obj, $deserializer);
            }
            
            public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
                $serializer.write(this.body);
                $serializer.write(this.e0);
                $serializer.write(this.e1);
                $serializer.write(this.g1);
                $serializer.write(this.g2);
                $serializer.write(this.s0);
                $serializer.write(this.s1);
                
            }
            
            // constructor just for allocation
            public $Closure$42(final java.lang.System[] $dummy) {
                
            }
            
            // synthetic type for parameter mangling
            public static final class __6$1x10$lang$Long$3x10$lang$Long$3x10$lang$Long$3x10$lang$Long$2 {}
            
        
            
            public void $apply() {
                
                //#line 719 "x10/compiler/Foreach.x10"
                try {{
                    
                    //#line 719 "x10/compiler/Foreach.x10"
                    final long t$112962 = ((this.s1) + (((long)(this.e1))));
                    
                    //#line 719 "x10/compiler/Foreach.x10"
                    final long t$112963 = ((t$112962) / (((long)(2L))));
                    
                    //#line 719 "x10/compiler/Foreach.x10"
                    x10.compiler.Foreach.doBisect2D__6$1x10$lang$Long$3x10$lang$Long$3x10$lang$Long$3x10$lang$Long$2((long)(this.s0), (long)(this.e0), (long)(t$112963), (long)(this.e1), (long)(this.g1), (long)(this.g2), ((x10.core.fun.VoidFun_0_4)(this.body)));
                }}catch (java.lang.Error __lowerer__var__0__) {
                    
                    //#line 719 "x10/compiler/Foreach.x10"
                    throw __lowerer__var__0__;
                }catch (java.lang.Throwable __lowerer__var__1__) {
                    
                    //#line 719 "x10/compiler/Foreach.x10"
                    throw x10.rtt.Types.EXCEPTION.isInstance(__lowerer__var__1__) ? (java.lang.RuntimeException)(__lowerer__var__1__) : new x10.lang.WrappedThrowable(__lowerer__var__1__);
                }
            }
            
            public long s1;
            public long e1;
            public long s0;
            public long e0;
            public long g1;
            public long g2;
            public x10.core.fun.VoidFun_0_4<x10.core.Long,x10.core.Long,x10.core.Long,x10.core.Long> body;
            
            public $Closure$42(final long s1, final long e1, final long s0, final long e0, final long g1, final long g2, final x10.core.fun.VoidFun_0_4<x10.core.Long,x10.core.Long,x10.core.Long,x10.core.Long> body, __6$1x10$lang$Long$3x10$lang$Long$3x10$lang$Long$3x10$lang$Long$2 $dummy) {
                 {
                    this.s1 = s1;
                    this.e1 = e1;
                    this.s0 = s0;
                    this.e0 = e0;
                    this.g1 = g1;
                    this.g2 = g2;
                    this.body = ((x10.core.fun.VoidFun_0_4)(body));
                }
            }
            
        }
        
        @x10.runtime.impl.java.X10Generated
        final public static class $Closure$43<$T> extends x10.core.Ref implements x10.core.fun.Fun_0_4, x10.serialization.X10JavaSerializable
        {
            public static final x10.rtt.RuntimeType<$Closure$43> $RTT = 
                x10.rtt.StaticFunType.<$Closure$43> make($Closure$43.class,
                                                         1,
                                                         new x10.rtt.Type[] {
                                                             x10.rtt.ParameterizedType.make(x10.core.fun.Fun_0_4.$RTT, x10.rtt.Types.LONG, x10.rtt.Types.LONG, x10.rtt.Types.LONG, x10.rtt.Types.LONG, x10.rtt.UnresolvedType.PARAM(0))
                                                         });
            
            public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
            
            public x10.rtt.Type<?> $getParam(int i) { if (i == 0) return $T; return null; }
            
            private Object writeReplace() throws java.io.ObjectStreamException {
                return new x10.serialization.SerializationProxy(this);
            }
            
            public static <$T> x10.serialization.X10JavaSerializable $_deserialize_body(x10.compiler.Foreach.$Closure$43<$T> $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
                $_obj.$T = (x10.rtt.Type) $deserializer.readObject();
                $_obj.body = $deserializer.readObject();
                $_obj.identity = $deserializer.readObject();
                $_obj.reduce = $deserializer.readObject();
                return $_obj;
            }
            
            public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
                x10.compiler.Foreach.$Closure$43 $_obj = new x10.compiler.Foreach.$Closure$43((java.lang.System[]) null, (x10.rtt.Type) null);
                $deserializer.record_reference($_obj);
                return $_deserialize_body($_obj, $deserializer);
            }
            
            public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
                $serializer.write(this.$T);
                $serializer.write(this.body);
                $serializer.write(this.identity);
                $serializer.write(this.reduce);
                
            }
            
            // constructor just for allocation
            public $Closure$43(final java.lang.System[] $dummy, final x10.rtt.Type $T) {
                x10.compiler.Foreach.$Closure$43.$initParams(this, $T);
                
            }
            
            // dispatcher for method abstract public (Z1,Z2,Z3,Z4)=>U.operator()(a1:Z1, a2:Z2, a3:Z3, a4:Z4):U
            public java.lang.Object $apply(final java.lang.Object a1, final x10.rtt.Type t1, final java.lang.Object a2, final x10.rtt.Type t2, final java.lang.Object a3, final x10.rtt.Type t3, final java.lang.Object a4, final x10.rtt.Type t4) {
                return $apply$G(x10.core.Long.$unbox(a1), x10.core.Long.$unbox(a2), x10.core.Long.$unbox(a3), x10.core.Long.$unbox(a4));
                
            }
            
            private x10.rtt.Type $T;
            
            // initializer of type parameters
            public static void $initParams(final $Closure$43 $this, final x10.rtt.Type $T) {
                $this.$T = $T;
                
            }
            // synthetic type for parameter mangling
            public static final class __0x10$compiler$Foreach$$Closure$43$$T__1$1x10$lang$Long$3x10$lang$Long$3x10$compiler$Foreach$$Closure$43$$T$2__2$1x10$compiler$Foreach$$Closure$43$$T$3x10$compiler$Foreach$$Closure$43$$T$3x10$compiler$Foreach$$Closure$43$$T$2 {}
            
        
            
            public $T $apply$G(final long min0, final long max0, final long min1, final long max1) {
                
                //#line 753 "x10/compiler/Foreach.x10"
                $T myResult = (($T)(this.identity));
                
                //#line 754 "x10/compiler/Foreach.x10"
                long i$113844 = min0;
                
                //#line 754 "x10/compiler/Foreach.x10"
                for (;
                     true;
                     ) {
                    
                    //#line 754 "x10/compiler/Foreach.x10"
                    final boolean t$113846 = ((i$113844) <= (((long)(max0))));
                    
                    //#line 754 "x10/compiler/Foreach.x10"
                    if (!(t$113846)) {
                        
                        //#line 754 "x10/compiler/Foreach.x10"
                        break;
                    }
                    
                    //#line 755 "x10/compiler/Foreach.x10"
                    long i$113836 = min1;
                    
                    //#line 755 "x10/compiler/Foreach.x10"
                    for (;
                         true;
                         ) {
                        
                        //#line 755 "x10/compiler/Foreach.x10"
                        final boolean t$113838 = ((i$113836) <= (((long)(max1))));
                        
                        //#line 755 "x10/compiler/Foreach.x10"
                        if (!(t$113838)) {
                            
                            //#line 755 "x10/compiler/Foreach.x10"
                            break;
                        }
                        
                        //#line 756 "x10/compiler/Foreach.x10"
                        final $T t$113831 = (($T)((($T)
                                                    ((x10.core.fun.Fun_0_2<x10.core.Long,x10.core.Long,$T>)this.body).$apply(x10.core.Long.$box(i$113844), x10.rtt.Types.LONG, x10.core.Long.$box(i$113836), x10.rtt.Types.LONG))));
                        
                        //#line 756 "x10/compiler/Foreach.x10"
                        final $T t$113832 = (($T)((($T)
                                                    ((x10.core.fun.Fun_0_2<$T,$T,$T>)this.reduce).$apply(myResult, $T, t$113831, $T))));
                        
                        //#line 756 "x10/compiler/Foreach.x10"
                        myResult = (($T)(t$113832));
                        
                        //#line 755 "x10/compiler/Foreach.x10"
                        final long t$113835 = ((i$113836) + (((long)(1L))));
                        
                        //#line 755 "x10/compiler/Foreach.x10"
                        i$113836 = t$113835;
                    }
                    
                    //#line 754 "x10/compiler/Foreach.x10"
                    final long t$113843 = ((i$113844) + (((long)(1L))));
                    
                    //#line 754 "x10/compiler/Foreach.x10"
                    i$113844 = t$113843;
                }
                
                //#line 759 "x10/compiler/Foreach.x10"
                return myResult;
            }
            
            public $T identity;
            public x10.core.fun.Fun_0_2<x10.core.Long,x10.core.Long,$T> body;
            public x10.core.fun.Fun_0_2<$T,$T,$T> reduce;
            
            public $Closure$43(final x10.rtt.Type $T, final $T identity, final x10.core.fun.Fun_0_2<x10.core.Long,x10.core.Long,$T> body, final x10.core.fun.Fun_0_2<$T,$T,$T> reduce, __0x10$compiler$Foreach$$Closure$43$$T__1$1x10$lang$Long$3x10$lang$Long$3x10$compiler$Foreach$$Closure$43$$T$2__2$1x10$compiler$Foreach$$Closure$43$$T$3x10$compiler$Foreach$$Closure$43$$T$3x10$compiler$Foreach$$Closure$43$$T$2 $dummy) {
                x10.compiler.Foreach.$Closure$43.$initParams(this, $T);
                 {
                    ((x10.compiler.Foreach.$Closure$43<$T>)this).identity = (($T)(identity));
                    ((x10.compiler.Foreach.$Closure$43<$T>)this).body = ((x10.core.fun.Fun_0_2)(body));
                    ((x10.compiler.Foreach.$Closure$43<$T>)this).reduce = ((x10.core.fun.Fun_0_2)(reduce));
                }
            }
            
        }
        
        @x10.runtime.impl.java.X10Generated
        final public static class $Closure$44<$T> extends x10.core.Ref implements x10.core.fun.Fun_0_4, x10.serialization.X10JavaSerializable
        {
            public static final x10.rtt.RuntimeType<$Closure$44> $RTT = 
                x10.rtt.StaticFunType.<$Closure$44> make($Closure$44.class,
                                                         1,
                                                         new x10.rtt.Type[] {
                                                             x10.rtt.ParameterizedType.make(x10.core.fun.Fun_0_4.$RTT, x10.rtt.Types.LONG, x10.rtt.Types.LONG, x10.rtt.Types.LONG, x10.rtt.Types.LONG, x10.rtt.UnresolvedType.PARAM(0))
                                                         });
            
            public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
            
            public x10.rtt.Type<?> $getParam(int i) { if (i == 0) return $T; return null; }
            
            private Object writeReplace() throws java.io.ObjectStreamException {
                return new x10.serialization.SerializationProxy(this);
            }
            
            public static <$T> x10.serialization.X10JavaSerializable $_deserialize_body(x10.compiler.Foreach.$Closure$44<$T> $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
                $_obj.$T = (x10.rtt.Type) $deserializer.readObject();
                $_obj.body$112260 = $deserializer.readObject();
                $_obj.identity$112262 = $deserializer.readObject();
                $_obj.reduce$112261 = $deserializer.readObject();
                return $_obj;
            }
            
            public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
                x10.compiler.Foreach.$Closure$44 $_obj = new x10.compiler.Foreach.$Closure$44((java.lang.System[]) null, (x10.rtt.Type) null);
                $deserializer.record_reference($_obj);
                return $_deserialize_body($_obj, $deserializer);
            }
            
            public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
                $serializer.write(this.$T);
                $serializer.write(this.body$112260);
                $serializer.write(this.identity$112262);
                $serializer.write(this.reduce$112261);
                
            }
            
            // constructor just for allocation
            public $Closure$44(final java.lang.System[] $dummy, final x10.rtt.Type $T) {
                x10.compiler.Foreach.$Closure$44.$initParams(this, $T);
                
            }
            
            // dispatcher for method abstract public (Z1,Z2,Z3,Z4)=>U.operator()(a1:Z1, a2:Z2, a3:Z3, a4:Z4):U
            public java.lang.Object $apply(final java.lang.Object a1, final x10.rtt.Type t1, final java.lang.Object a2, final x10.rtt.Type t2, final java.lang.Object a3, final x10.rtt.Type t3, final java.lang.Object a4, final x10.rtt.Type t4) {
                return $apply$G(x10.core.Long.$unbox(a1), x10.core.Long.$unbox(a2), x10.core.Long.$unbox(a3), x10.core.Long.$unbox(a4));
                
            }
            
            private x10.rtt.Type $T;
            
            // initializer of type parameters
            public static void $initParams(final $Closure$44 $this, final x10.rtt.Type $T) {
                $this.$T = $T;
                
            }
            // synthetic type for parameter mangling
            public static final class __0x10$compiler$Foreach$$Closure$44$$T__1$1x10$lang$Long$3x10$lang$Long$3x10$compiler$Foreach$$Closure$44$$T$2__2$1x10$compiler$Foreach$$Closure$44$$T$3x10$compiler$Foreach$$Closure$44$$T$3x10$compiler$Foreach$$Closure$44$$T$2 {}
            
        
            
            public $T $apply$G(final long min$112265, final long max$112266, final long min$112267, final long max$112268) {
                
                //#line 753 . "x10/compiler/Foreach.x10"
                $T myResult$112269 = (($T)(this.identity$112262));
                
                //#line 754 . "x10/compiler/Foreach.x10"
                long i$113882 = min$112265;
                
                //#line 754 . "x10/compiler/Foreach.x10"
                for (;
                     true;
                     ) {
                    
                    //#line 754 . "x10/compiler/Foreach.x10"
                    final boolean t$113884 = ((i$113882) <= (((long)(max$112266))));
                    
                    //#line 754 . "x10/compiler/Foreach.x10"
                    if (!(t$113884)) {
                        
                        //#line 754 . "x10/compiler/Foreach.x10"
                        break;
                    }
                    
                    //#line 755 . "x10/compiler/Foreach.x10"
                    long i$113874 = min$112267;
                    
                    //#line 755 . "x10/compiler/Foreach.x10"
                    for (;
                         true;
                         ) {
                        
                        //#line 755 . "x10/compiler/Foreach.x10"
                        final boolean t$113876 = ((i$113874) <= (((long)(max$112268))));
                        
                        //#line 755 . "x10/compiler/Foreach.x10"
                        if (!(t$113876)) {
                            
                            //#line 755 . "x10/compiler/Foreach.x10"
                            break;
                        }
                        
                        //#line 756 . "x10/compiler/Foreach.x10"
                        final $T t$113869 = (($T)((($T)
                                                    ((x10.core.fun.Fun_0_2<x10.core.Long,x10.core.Long,$T>)this.body$112260).$apply(x10.core.Long.$box(i$113882), x10.rtt.Types.LONG, x10.core.Long.$box(i$113874), x10.rtt.Types.LONG))));
                        
                        //#line 756 . "x10/compiler/Foreach.x10"
                        final $T t$113870 = (($T)((($T)
                                                    ((x10.core.fun.Fun_0_2<$T,$T,$T>)this.reduce$112261).$apply(myResult$112269, $T, t$113869, $T))));
                        
                        //#line 756 . "x10/compiler/Foreach.x10"
                        myResult$112269 = (($T)(t$113870));
                        
                        //#line 755 . "x10/compiler/Foreach.x10"
                        final long t$113873 = ((i$113874) + (((long)(1L))));
                        
                        //#line 755 . "x10/compiler/Foreach.x10"
                        i$113874 = t$113873;
                    }
                    
                    //#line 754 . "x10/compiler/Foreach.x10"
                    final long t$113881 = ((i$113882) + (((long)(1L))));
                    
                    //#line 754 . "x10/compiler/Foreach.x10"
                    i$113882 = t$113881;
                }
                
                //#line 759 . "x10/compiler/Foreach.x10"
                return myResult$112269;
            }
            
            public $T identity$112262;
            public x10.core.fun.Fun_0_2<x10.core.Long,x10.core.Long,$T> body$112260;
            public x10.core.fun.Fun_0_2<$T,$T,$T> reduce$112261;
            
            public $Closure$44(final x10.rtt.Type $T, final $T identity$112262, final x10.core.fun.Fun_0_2<x10.core.Long,x10.core.Long,$T> body$112260, final x10.core.fun.Fun_0_2<$T,$T,$T> reduce$112261, __0x10$compiler$Foreach$$Closure$44$$T__1$1x10$lang$Long$3x10$lang$Long$3x10$compiler$Foreach$$Closure$44$$T$2__2$1x10$compiler$Foreach$$Closure$44$$T$3x10$compiler$Foreach$$Closure$44$$T$3x10$compiler$Foreach$$Closure$44$$T$2 $dummy) {
                x10.compiler.Foreach.$Closure$44.$initParams(this, $T);
                 {
                    ((x10.compiler.Foreach.$Closure$44<$T>)this).identity$112262 = (($T)(identity$112262));
                    ((x10.compiler.Foreach.$Closure$44<$T>)this).body$112260 = ((x10.core.fun.Fun_0_2)(body$112260));
                    ((x10.compiler.Foreach.$Closure$44<$T>)this).reduce$112261 = ((x10.core.fun.Fun_0_2)(reduce$112261));
                }
            }
            
        }
        
        @x10.runtime.impl.java.X10Generated
        final public static class $Closure$45<$T> extends x10.core.Ref implements x10.core.fun.Fun_0_4, x10.serialization.X10JavaSerializable
        {
            public static final x10.rtt.RuntimeType<$Closure$45> $RTT = 
                x10.rtt.StaticFunType.<$Closure$45> make($Closure$45.class,
                                                         1,
                                                         new x10.rtt.Type[] {
                                                             x10.rtt.ParameterizedType.make(x10.core.fun.Fun_0_4.$RTT, x10.rtt.Types.LONG, x10.rtt.Types.LONG, x10.rtt.Types.LONG, x10.rtt.Types.LONG, x10.rtt.UnresolvedType.PARAM(0))
                                                         });
            
            public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
            
            public x10.rtt.Type<?> $getParam(int i) { if (i == 0) return $T; return null; }
            
            private Object writeReplace() throws java.io.ObjectStreamException {
                return new x10.serialization.SerializationProxy(this);
            }
            
            public static <$T> x10.serialization.X10JavaSerializable $_deserialize_body(x10.compiler.Foreach.$Closure$45<$T> $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
                $_obj.$T = (x10.rtt.Type) $deserializer.readObject();
                $_obj.body$112300 = $deserializer.readObject();
                $_obj.identity$112302 = $deserializer.readObject();
                $_obj.reduce$112301 = $deserializer.readObject();
                return $_obj;
            }
            
            public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
                x10.compiler.Foreach.$Closure$45 $_obj = new x10.compiler.Foreach.$Closure$45((java.lang.System[]) null, (x10.rtt.Type) null);
                $deserializer.record_reference($_obj);
                return $_deserialize_body($_obj, $deserializer);
            }
            
            public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
                $serializer.write(this.$T);
                $serializer.write(this.body$112300);
                $serializer.write(this.identity$112302);
                $serializer.write(this.reduce$112301);
                
            }
            
            // constructor just for allocation
            public $Closure$45(final java.lang.System[] $dummy, final x10.rtt.Type $T) {
                x10.compiler.Foreach.$Closure$45.$initParams(this, $T);
                
            }
            
            // dispatcher for method abstract public (Z1,Z2,Z3,Z4)=>U.operator()(a1:Z1, a2:Z2, a3:Z3, a4:Z4):U
            public java.lang.Object $apply(final java.lang.Object a1, final x10.rtt.Type t1, final java.lang.Object a2, final x10.rtt.Type t2, final java.lang.Object a3, final x10.rtt.Type t3, final java.lang.Object a4, final x10.rtt.Type t4) {
                return $apply$G(x10.core.Long.$unbox(a1), x10.core.Long.$unbox(a2), x10.core.Long.$unbox(a3), x10.core.Long.$unbox(a4));
                
            }
            
            private x10.rtt.Type $T;
            
            // initializer of type parameters
            public static void $initParams(final $Closure$45 $this, final x10.rtt.Type $T) {
                $this.$T = $T;
                
            }
            // synthetic type for parameter mangling
            public static final class __0x10$compiler$Foreach$$Closure$45$$T__1$1x10$lang$Long$3x10$lang$Long$3x10$compiler$Foreach$$Closure$45$$T$2__2$1x10$compiler$Foreach$$Closure$45$$T$3x10$compiler$Foreach$$Closure$45$$T$3x10$compiler$Foreach$$Closure$45$$T$2 {}
            
        
            
            public $T $apply$G(final long min$112305, final long max$112306, final long min$112307, final long max$112308) {
                
                //#line 753 . "x10/compiler/Foreach.x10"
                $T myResult$112309 = (($T)(this.identity$112302));
                
                //#line 754 . "x10/compiler/Foreach.x10"
                long i$113920 = min$112305;
                
                //#line 754 . "x10/compiler/Foreach.x10"
                for (;
                     true;
                     ) {
                    
                    //#line 754 . "x10/compiler/Foreach.x10"
                    final boolean t$113922 = ((i$113920) <= (((long)(max$112306))));
                    
                    //#line 754 . "x10/compiler/Foreach.x10"
                    if (!(t$113922)) {
                        
                        //#line 754 . "x10/compiler/Foreach.x10"
                        break;
                    }
                    
                    //#line 755 . "x10/compiler/Foreach.x10"
                    long i$113912 = min$112307;
                    
                    //#line 755 . "x10/compiler/Foreach.x10"
                    for (;
                         true;
                         ) {
                        
                        //#line 755 . "x10/compiler/Foreach.x10"
                        final boolean t$113914 = ((i$113912) <= (((long)(max$112308))));
                        
                        //#line 755 . "x10/compiler/Foreach.x10"
                        if (!(t$113914)) {
                            
                            //#line 755 . "x10/compiler/Foreach.x10"
                            break;
                        }
                        
                        //#line 756 . "x10/compiler/Foreach.x10"
                        final $T t$113907 = (($T)((($T)
                                                    ((x10.core.fun.Fun_0_2<x10.core.Long,x10.core.Long,$T>)this.body$112300).$apply(x10.core.Long.$box(i$113920), x10.rtt.Types.LONG, x10.core.Long.$box(i$113912), x10.rtt.Types.LONG))));
                        
                        //#line 756 . "x10/compiler/Foreach.x10"
                        final $T t$113908 = (($T)((($T)
                                                    ((x10.core.fun.Fun_0_2<$T,$T,$T>)this.reduce$112301).$apply(myResult$112309, $T, t$113907, $T))));
                        
                        //#line 756 . "x10/compiler/Foreach.x10"
                        myResult$112309 = (($T)(t$113908));
                        
                        //#line 755 . "x10/compiler/Foreach.x10"
                        final long t$113911 = ((i$113912) + (((long)(1L))));
                        
                        //#line 755 . "x10/compiler/Foreach.x10"
                        i$113912 = t$113911;
                    }
                    
                    //#line 754 . "x10/compiler/Foreach.x10"
                    final long t$113919 = ((i$113920) + (((long)(1L))));
                    
                    //#line 754 . "x10/compiler/Foreach.x10"
                    i$113920 = t$113919;
                }
                
                //#line 759 . "x10/compiler/Foreach.x10"
                return myResult$112309;
            }
            
            public $T identity$112302;
            public x10.core.fun.Fun_0_2<x10.core.Long,x10.core.Long,$T> body$112300;
            public x10.core.fun.Fun_0_2<$T,$T,$T> reduce$112301;
            
            public $Closure$45(final x10.rtt.Type $T, final $T identity$112302, final x10.core.fun.Fun_0_2<x10.core.Long,x10.core.Long,$T> body$112300, final x10.core.fun.Fun_0_2<$T,$T,$T> reduce$112301, __0x10$compiler$Foreach$$Closure$45$$T__1$1x10$lang$Long$3x10$lang$Long$3x10$compiler$Foreach$$Closure$45$$T$2__2$1x10$compiler$Foreach$$Closure$45$$T$3x10$compiler$Foreach$$Closure$45$$T$3x10$compiler$Foreach$$Closure$45$$T$2 $dummy) {
                x10.compiler.Foreach.$Closure$45.$initParams(this, $T);
                 {
                    ((x10.compiler.Foreach.$Closure$45<$T>)this).identity$112302 = (($T)(identity$112302));
                    ((x10.compiler.Foreach.$Closure$45<$T>)this).body$112300 = ((x10.core.fun.Fun_0_2)(body$112300));
                    ((x10.compiler.Foreach.$Closure$45<$T>)this).reduce$112301 = ((x10.core.fun.Fun_0_2)(reduce$112301));
                }
            }
            
        }
        
        @x10.runtime.impl.java.X10Generated
        final public static class $Closure$46<$T> extends x10.core.Ref implements x10.core.fun.VoidFun_0_0, x10.serialization.X10JavaSerializable
        {
            public static final x10.rtt.RuntimeType<$Closure$46> $RTT = 
                x10.rtt.StaticVoidFunType.<$Closure$46> make($Closure$46.class,
                                                             1,
                                                             new x10.rtt.Type[] {
                                                                 x10.core.fun.VoidFun_0_0.$RTT
                                                             });
            
            public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
            
            public x10.rtt.Type<?> $getParam(int i) { if (i == 0) return $T; return null; }
            
            private Object writeReplace() throws java.io.ObjectStreamException {
                return new x10.serialization.SerializationProxy(this);
            }
            
            public static <$T> x10.serialization.X10JavaSerializable $_deserialize_body(x10.compiler.Foreach.$Closure$46<$T> $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
                $_obj.$T = (x10.rtt.Type) $deserializer.readObject();
                $_obj.$asyncResult$114048 = $deserializer.readObject();
                $_obj.body = $deserializer.readObject();
                $_obj.e0 = $deserializer.readLong();
                $_obj.e1 = $deserializer.readLong();
                $_obj.g1 = $deserializer.readLong();
                $_obj.g2 = $deserializer.readLong();
                $_obj.reduce = $deserializer.readObject();
                $_obj.s0 = $deserializer.readLong();
                $_obj.s1 = $deserializer.readLong();
                return $_obj;
            }
            
            public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
                x10.compiler.Foreach.$Closure$46 $_obj = new x10.compiler.Foreach.$Closure$46((java.lang.System[]) null, (x10.rtt.Type) null);
                $deserializer.record_reference($_obj);
                return $_deserialize_body($_obj, $deserializer);
            }
            
            public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
                $serializer.write(this.$T);
                $serializer.write(this.$asyncResult$114048);
                $serializer.write(this.body);
                $serializer.write(this.e0);
                $serializer.write(this.e1);
                $serializer.write(this.g1);
                $serializer.write(this.g2);
                $serializer.write(this.reduce);
                $serializer.write(this.s0);
                $serializer.write(this.s1);
                
            }
            
            // constructor just for allocation
            public $Closure$46(final java.lang.System[] $dummy, final x10.rtt.Type $T) {
                x10.compiler.Foreach.$Closure$46.$initParams(this, $T);
                
            }
            
            private x10.rtt.Type $T;
            
            // initializer of type parameters
            public static void $initParams(final $Closure$46 $this, final x10.rtt.Type $T) {
                $this.$T = $T;
                
            }
            // synthetic type for parameter mangling
            public static final class __6$1x10$lang$Long$3x10$lang$Long$3x10$lang$Long$3x10$lang$Long$3x10$compiler$Foreach$$Closure$46$$T$2__7$1x10$compiler$Foreach$$Closure$46$$T$3x10$compiler$Foreach$$Closure$46$$T$3x10$compiler$Foreach$$Closure$46$$T$2 {}
            
        
            
            public void $apply() {
                
                //#line 820 "x10/compiler/Foreach.x10"
                try {{
                    
                    //#line 820 "x10/compiler/Foreach.x10"
                    final long t$113092 = ((this.s0) + (((long)(this.e0))));
                    
                    //#line 820 "x10/compiler/Foreach.x10"
                    final long t$113093 = ((t$113092) / (((long)(2L))));
                    
                    //#line 820 "x10/compiler/Foreach.x10"
                    final $T t$113094 = (($T)(x10.compiler.Foreach.<$T> doBisectReduce2D__6$1x10$lang$Long$3x10$lang$Long$3x10$lang$Long$3x10$lang$Long$3x10$compiler$Foreach$$T$2__7$1x10$compiler$Foreach$$T$3x10$compiler$Foreach$$T$3x10$compiler$Foreach$$T$2$G($T, (long)(t$113093), (long)(this.e0), (long)(this.s1), (long)(this.e1), (long)(this.g1), (long)(this.g2), ((x10.core.fun.Fun_0_4)(this.body)), ((x10.core.fun.Fun_0_2)(this.reduce)))));
                    
                    //#line 820 "x10/compiler/Foreach.x10"
                    this.$asyncResult$114048[(int)0]=t$113094;
                }}catch (java.lang.Error __lowerer__var__0__) {
                    
                    //#line 820 "x10/compiler/Foreach.x10"
                    throw __lowerer__var__0__;
                }catch (java.lang.Throwable __lowerer__var__1__) {
                    
                    //#line 820 "x10/compiler/Foreach.x10"
                    throw x10.rtt.Types.EXCEPTION.isInstance(__lowerer__var__1__) ? (java.lang.RuntimeException)(__lowerer__var__1__) : new x10.lang.WrappedThrowable(__lowerer__var__1__);
                }
            }
            
            public long s0;
            public long e0;
            public long s1;
            public long e1;
            public long g1;
            public long g2;
            public x10.core.fun.Fun_0_4<x10.core.Long,x10.core.Long,x10.core.Long,x10.core.Long,$T> body;
            public x10.core.fun.Fun_0_2<$T,$T,$T> reduce;
            public $T[] $asyncResult$114048;
            
            public $Closure$46(final x10.rtt.Type $T, final long s0, final long e0, final long s1, final long e1, final long g1, final long g2, final x10.core.fun.Fun_0_4<x10.core.Long,x10.core.Long,x10.core.Long,x10.core.Long,$T> body, final x10.core.fun.Fun_0_2<$T,$T,$T> reduce, final $T[] $asyncResult$114048, __6$1x10$lang$Long$3x10$lang$Long$3x10$lang$Long$3x10$lang$Long$3x10$compiler$Foreach$$Closure$46$$T$2__7$1x10$compiler$Foreach$$Closure$46$$T$3x10$compiler$Foreach$$Closure$46$$T$3x10$compiler$Foreach$$Closure$46$$T$2 $dummy) {
                x10.compiler.Foreach.$Closure$46.$initParams(this, $T);
                 {
                    ((x10.compiler.Foreach.$Closure$46<$T>)this).s0 = s0;
                    ((x10.compiler.Foreach.$Closure$46<$T>)this).e0 = e0;
                    ((x10.compiler.Foreach.$Closure$46<$T>)this).s1 = s1;
                    ((x10.compiler.Foreach.$Closure$46<$T>)this).e1 = e1;
                    ((x10.compiler.Foreach.$Closure$46<$T>)this).g1 = g1;
                    ((x10.compiler.Foreach.$Closure$46<$T>)this).g2 = g2;
                    ((x10.compiler.Foreach.$Closure$46<$T>)this).body = ((x10.core.fun.Fun_0_4)(body));
                    ((x10.compiler.Foreach.$Closure$46<$T>)this).reduce = ((x10.core.fun.Fun_0_2)(reduce));
                    ((x10.compiler.Foreach.$Closure$46<$T>)this).$asyncResult$114048 = $asyncResult$114048;
                }
            }
            
        }
        
        @x10.runtime.impl.java.X10Generated
        final public static class $Closure$47<$T> extends x10.core.Ref implements x10.core.fun.VoidFun_0_0, x10.serialization.X10JavaSerializable
        {
            public static final x10.rtt.RuntimeType<$Closure$47> $RTT = 
                x10.rtt.StaticVoidFunType.<$Closure$47> make($Closure$47.class,
                                                             1,
                                                             new x10.rtt.Type[] {
                                                                 x10.core.fun.VoidFun_0_0.$RTT
                                                             });
            
            public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
            
            public x10.rtt.Type<?> $getParam(int i) { if (i == 0) return $T; return null; }
            
            private Object writeReplace() throws java.io.ObjectStreamException {
                return new x10.serialization.SerializationProxy(this);
            }
            
            public static <$T> x10.serialization.X10JavaSerializable $_deserialize_body(x10.compiler.Foreach.$Closure$47<$T> $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
                $_obj.$T = (x10.rtt.Type) $deserializer.readObject();
                $_obj.$asyncResult$114049 = $deserializer.readObject();
                $_obj.body = $deserializer.readObject();
                $_obj.e0 = $deserializer.readLong();
                $_obj.e1 = $deserializer.readLong();
                $_obj.g1 = $deserializer.readLong();
                $_obj.g2 = $deserializer.readLong();
                $_obj.reduce = $deserializer.readObject();
                $_obj.s0 = $deserializer.readLong();
                $_obj.s1 = $deserializer.readLong();
                return $_obj;
            }
            
            public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
                x10.compiler.Foreach.$Closure$47 $_obj = new x10.compiler.Foreach.$Closure$47((java.lang.System[]) null, (x10.rtt.Type) null);
                $deserializer.record_reference($_obj);
                return $_deserialize_body($_obj, $deserializer);
            }
            
            public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
                $serializer.write(this.$T);
                $serializer.write(this.$asyncResult$114049);
                $serializer.write(this.body);
                $serializer.write(this.e0);
                $serializer.write(this.e1);
                $serializer.write(this.g1);
                $serializer.write(this.g2);
                $serializer.write(this.reduce);
                $serializer.write(this.s0);
                $serializer.write(this.s1);
                
            }
            
            // constructor just for allocation
            public $Closure$47(final java.lang.System[] $dummy, final x10.rtt.Type $T) {
                x10.compiler.Foreach.$Closure$47.$initParams(this, $T);
                
            }
            
            private x10.rtt.Type $T;
            
            // initializer of type parameters
            public static void $initParams(final $Closure$47 $this, final x10.rtt.Type $T) {
                $this.$T = $T;
                
            }
            // synthetic type for parameter mangling
            public static final class __6$1x10$lang$Long$3x10$lang$Long$3x10$lang$Long$3x10$lang$Long$3x10$compiler$Foreach$$Closure$47$$T$2__7$1x10$compiler$Foreach$$Closure$47$$T$3x10$compiler$Foreach$$Closure$47$$T$3x10$compiler$Foreach$$Closure$47$$T$2 {}
            
        
            
            public void $apply() {
                
                //#line 828 "x10/compiler/Foreach.x10"
                try {{
                    
                    //#line 828 "x10/compiler/Foreach.x10"
                    final long t$113100 = ((this.s1) + (((long)(this.e1))));
                    
                    //#line 828 "x10/compiler/Foreach.x10"
                    final long t$113101 = ((t$113100) / (((long)(2L))));
                    
                    //#line 828 "x10/compiler/Foreach.x10"
                    final $T t$113102 = (($T)(x10.compiler.Foreach.<$T> doBisectReduce2D__6$1x10$lang$Long$3x10$lang$Long$3x10$lang$Long$3x10$lang$Long$3x10$compiler$Foreach$$T$2__7$1x10$compiler$Foreach$$T$3x10$compiler$Foreach$$T$3x10$compiler$Foreach$$T$2$G($T, (long)(this.s0), (long)(this.e0), (long)(t$113101), (long)(this.e1), (long)(this.g1), (long)(this.g2), ((x10.core.fun.Fun_0_4)(this.body)), ((x10.core.fun.Fun_0_2)(this.reduce)))));
                    
                    //#line 828 "x10/compiler/Foreach.x10"
                    this.$asyncResult$114049[(int)0]=t$113102;
                }}catch (java.lang.Error __lowerer__var__0__) {
                    
                    //#line 828 "x10/compiler/Foreach.x10"
                    throw __lowerer__var__0__;
                }catch (java.lang.Throwable __lowerer__var__1__) {
                    
                    //#line 828 "x10/compiler/Foreach.x10"
                    throw x10.rtt.Types.EXCEPTION.isInstance(__lowerer__var__1__) ? (java.lang.RuntimeException)(__lowerer__var__1__) : new x10.lang.WrappedThrowable(__lowerer__var__1__);
                }
            }
            
            public long s1;
            public long e1;
            public long s0;
            public long e0;
            public long g1;
            public long g2;
            public x10.core.fun.Fun_0_4<x10.core.Long,x10.core.Long,x10.core.Long,x10.core.Long,$T> body;
            public x10.core.fun.Fun_0_2<$T,$T,$T> reduce;
            public $T[] $asyncResult$114049;
            
            public $Closure$47(final x10.rtt.Type $T, final long s1, final long e1, final long s0, final long e0, final long g1, final long g2, final x10.core.fun.Fun_0_4<x10.core.Long,x10.core.Long,x10.core.Long,x10.core.Long,$T> body, final x10.core.fun.Fun_0_2<$T,$T,$T> reduce, final $T[] $asyncResult$114049, __6$1x10$lang$Long$3x10$lang$Long$3x10$lang$Long$3x10$lang$Long$3x10$compiler$Foreach$$Closure$47$$T$2__7$1x10$compiler$Foreach$$Closure$47$$T$3x10$compiler$Foreach$$Closure$47$$T$3x10$compiler$Foreach$$Closure$47$$T$2 $dummy) {
                x10.compiler.Foreach.$Closure$47.$initParams(this, $T);
                 {
                    ((x10.compiler.Foreach.$Closure$47<$T>)this).s1 = s1;
                    ((x10.compiler.Foreach.$Closure$47<$T>)this).e1 = e1;
                    ((x10.compiler.Foreach.$Closure$47<$T>)this).s0 = s0;
                    ((x10.compiler.Foreach.$Closure$47<$T>)this).e0 = e0;
                    ((x10.compiler.Foreach.$Closure$47<$T>)this).g1 = g1;
                    ((x10.compiler.Foreach.$Closure$47<$T>)this).g2 = g2;
                    ((x10.compiler.Foreach.$Closure$47<$T>)this).body = ((x10.core.fun.Fun_0_4)(body));
                    ((x10.compiler.Foreach.$Closure$47<$T>)this).reduce = ((x10.core.fun.Fun_0_2)(reduce));
                    ((x10.compiler.Foreach.$Closure$47<$T>)this).$asyncResult$114049 = $asyncResult$114049;
                }
            }
            
        }
        
    }
    
    