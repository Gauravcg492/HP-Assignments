package x10.compiler;


/**
 * This annotation on a loop requests that the body of the loop should
 * be unrolled the specified number of times.
 */
@x10.runtime.impl.java.X10Generated
public interface Unroll extends x10.lang.annotations.StatementAnnotation, x10.serialization.X10JavaSerializable
{
    public static final x10.rtt.RuntimeType<Unroll> $RTT = 
        x10.rtt.NamedType.<Unroll> make("x10.compiler.Unroll",
                                        Unroll.class,
                                        new x10.rtt.Type[] {
                                            x10.lang.annotations.StatementAnnotation.$RTT
                                        });
    
    
}

