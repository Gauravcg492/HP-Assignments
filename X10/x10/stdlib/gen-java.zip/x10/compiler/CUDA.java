package x10.compiler;


/**
 * An annotation that instructs the C++ backend to compile the block as a CUDA
 * kernel.  This implies that the block should be capable of running on a GPU,
 * which means restrictions on what language features are allowed.
 */
@x10.runtime.impl.java.X10Generated
public interface CUDA extends x10.lang.annotations.StatementAnnotation, x10.lang.annotations.MethodAnnotation, x10.serialization.X10JavaSerializable
{
    public static final x10.rtt.RuntimeType<CUDA> $RTT = 
        x10.rtt.NamedType.<CUDA> make("x10.compiler.CUDA",
                                      CUDA.class,
                                      new x10.rtt.Type[] {
                                          x10.lang.annotations.StatementAnnotation.$RTT,
                                          x10.lang.annotations.MethodAnnotation.$RTT
                                      });
    
    
}

