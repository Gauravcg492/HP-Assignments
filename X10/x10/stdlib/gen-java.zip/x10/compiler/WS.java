package x10.compiler;


/**
 * Temporary annotation to mark a method as a target for WSCodeGenerator
 */
@x10.runtime.impl.java.X10Generated
public interface WS extends x10.lang.annotations.MethodAnnotation, x10.serialization.X10JavaSerializable
{
    public static final x10.rtt.RuntimeType<WS> $RTT = 
        x10.rtt.NamedType.<WS> make("x10.compiler.WS",
                                    WS.class,
                                    new x10.rtt.Type[] {
                                        x10.lang.annotations.MethodAnnotation.$RTT
                                    });
    
    
}

