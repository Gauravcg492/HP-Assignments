package x10.compiler;


/**
 * NonEscaping is an annotation that can be used on methods to mark the fact the method
 * does not escape "this" nor "super" during construction.
 * (See also @NoThisAccess annotation.)
 *
 * <p>All constructors and field initializers are implicitly NonEscaping.
 *
 * <p>It is considered good practice to mark all methods called from a constructor as @NonEscaping.
 *
 * Object construction (or initialization) in X10 is more strict than Java:
 * X10 has restricting rules that prevent seeing the default value of val fields
 * (as opposed to final fields in Java, because it is possible to see the default value of final fields in Java)
 * You can read the value of a val field only after it is definitely been assigned.
 *
 * <p>@NonEscaping marks the fact that "this" does not escape (also called leak) from the method.
 * A method is NonEscaping if:
 * 1) the method is either final, private, or the entire class is final.
 * 2) in the method body, "this" and "super" are only used in field access, field assignment,
 *    and as the reciever of NonEscaping methods.
 *    Calling a superclass method is legal only of the method is explicitly NonEscaping.
 *
 * <p>@NonEscaping is not checked on native methods because they do not have a body.
 */
@x10.runtime.impl.java.X10Generated
public interface NonEscaping extends x10.lang.annotations.MethodAnnotation, x10.lang.annotations.FieldAnnotation, x10.serialization.X10JavaSerializable
{
    public static final x10.rtt.RuntimeType<NonEscaping> $RTT = 
        x10.rtt.NamedType.<NonEscaping> make("x10.compiler.NonEscaping",
                                             NonEscaping.class,
                                             new x10.rtt.Type[] {
                                                 x10.lang.annotations.MethodAnnotation.$RTT,
                                                 x10.lang.annotations.FieldAnnotation.$RTT
                                             });
    
    
}

