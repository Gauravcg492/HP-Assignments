package x10.compiler;


/**
 * Used for generating static initialization code in Java backend.
 * 
 */
;

