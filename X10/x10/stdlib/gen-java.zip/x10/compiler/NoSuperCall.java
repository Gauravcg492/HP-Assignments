package x10.compiler;


/**
 * This annotation is used to allow the programmer
 * to direct the compiler not to insert a super
 * constructor invocation in annotated constructor.
 * This annotation is intended to be used internally
 * by the compiler. It should not be used otherwise.</p>
 *
 * This annotation is processed by the X10 compiler's
 * FieldInitializerMover visitor.
 */
@x10.runtime.impl.java.X10Generated
public interface NoSuperCall extends x10.lang.annotations.MethodAnnotation, x10.serialization.X10JavaSerializable
{
    public static final x10.rtt.RuntimeType<NoSuperCall> $RTT = 
        x10.rtt.NamedType.<NoSuperCall> make("x10.compiler.NoSuperCall",
                                             NoSuperCall.class,
                                             new x10.rtt.Type[] {
                                                 x10.lang.annotations.MethodAnnotation.$RTT
                                             });
    
    
}

