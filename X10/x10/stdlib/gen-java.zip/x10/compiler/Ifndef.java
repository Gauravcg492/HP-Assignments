package x10.compiler;


@x10.runtime.impl.java.X10Generated
public interface Ifndef extends x10.lang.annotations.FieldAnnotation, x10.lang.annotations.MethodAnnotation, x10.lang.annotations.StatementAnnotation, x10.lang.annotations.ClassAnnotation, x10.serialization.X10JavaSerializable
{
    public static final x10.rtt.RuntimeType<Ifndef> $RTT = 
        x10.rtt.NamedType.<Ifndef> make("x10.compiler.Ifndef",
                                        Ifndef.class,
                                        new x10.rtt.Type[] {
                                            x10.lang.annotations.FieldAnnotation.$RTT,
                                            x10.lang.annotations.MethodAnnotation.$RTT,
                                            x10.lang.annotations.StatementAnnotation.$RTT,
                                            x10.lang.annotations.ClassAnnotation.$RTT
                                        });
    
    
}

