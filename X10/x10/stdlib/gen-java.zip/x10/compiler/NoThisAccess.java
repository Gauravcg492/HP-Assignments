package x10.compiler;


/**
 * This annotation on a method allows it to be called by dynamically dispatching during construction.
 * (See also @NonEscaping annotation.)
 *
 * <p>@NoThisAccess marks the fact that "this" cannot be used at all in the method.
 * The compiler checks @NoThisAccess as follows:
 * 1) @NoThisAccess must be preserved by overriding, i.e., when overriding a method annotated with
 *  @NoThisAccess then the overriding method must be annotated with @NoThisAccess.
 * 2) The method cannot access "this" or "super" at all (cannot escape "this", read, nor write from any field).
 *
 * @NoThisAccess is different from @NonEscaping as follows:
 * 1) @NoThisAccess methods cannot access "this" at all, whereas @NonEscaping can read and write to the fields of "this".
 * 2) @NoThisAccess methods can be called after the constructor call (either super(...) or this(...)),
 * whereas @NonEscaping methods can be called only after the property call (property(...)).
 * 3) @NoThisAccess can be overriden, whereas @NonEscaping methods must be private/final.
 *
 * <p>@NoThisAccess is not checked on native methods because they do not have a body.
 */
@x10.runtime.impl.java.X10Generated
public interface NoThisAccess extends x10.lang.annotations.MethodAnnotation, x10.serialization.X10JavaSerializable
{
    public static final x10.rtt.RuntimeType<NoThisAccess> $RTT = 
        x10.rtt.NamedType.<NoThisAccess> make("x10.compiler.NoThisAccess",
                                              NoThisAccess.class,
                                              new x10.rtt.Type[] {
                                                  x10.lang.annotations.MethodAnnotation.$RTT
                                              });
    
    
}

