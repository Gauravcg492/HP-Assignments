package x10.compiler;


/**
 * This annotation indicates that when a transient field
 * is deserialized, it should be initialized with the result
 * of the argument expression.  The expression will be evaluated
 * after all non-transient fields are deserialized and initialized.
 *
 * TODO: This really should be 
 *    TransientInitExpr[T](init:T)
 * but we can't say that in X10 2.4.
 */
@x10.runtime.impl.java.X10Generated
public interface TransientInitExpr extends x10.compiler.SuppressTransientError, x10.serialization.X10JavaSerializable
{
    public static final x10.rtt.RuntimeType<TransientInitExpr> $RTT = 
        x10.rtt.NamedType.<TransientInitExpr> make("x10.compiler.TransientInitExpr",
                                                   TransientInitExpr.class,
                                                   new x10.rtt.Type[] {
                                                       x10.compiler.SuppressTransientError.$RTT
                                                   });
    
    
}

