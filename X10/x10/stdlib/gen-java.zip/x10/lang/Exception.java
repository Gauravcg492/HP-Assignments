package x10.lang;


/**
 * The class Exception and its subclasses are a form of Throwable that indicates conditions that
 * a reasonable application might want to catch.
 */
;

