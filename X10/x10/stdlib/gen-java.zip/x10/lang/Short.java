package x10.lang;


/**
 * Short is a 16-bit signed two's complement integral data type, with
 * values ranging from -32768 to 32767, inclusive.  All of the normal
 * arithmetic and bitwise operations are defined on Short, and Short
 * is closed under those operations.  There are also static methods
 * that define conversions from other data types, including String,
 * as well as some Short constants.
 */
;


