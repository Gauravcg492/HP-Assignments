package x10.lang;


/**
 * The primary operation on a PlaceLocalHandle is to use it to access an object
 * on the current place.  If the current place is not part of the PlaceGroup
 * over which the PlaceLocalHandle is defined, a BadPlaceException will be thrown.</p>
 *
 * A key concept for correct usage of PlaceLocalHandles is that in different places,
 * the Handle may be mapped to distinct objects.  For example (assuming >1 Place):
 * <pre>
 *   val plh:PlaceLocalHandle[T] = ....;
 *   val obj:T = plh();
 *   at (here.next()) Console.out.println(plh() == obj);
 * </pre>
 * may print either true or false depending on how the application is
 * using the particular PlaceLocalHandle (mapping the same object at
 * multiple places or mapping distinct object at each place).</p>
 */
@x10.runtime.impl.java.X10Generated
final public class PlaceLocalHandle<$T> extends x10.core.Struct implements x10.serialization.X10JavaSerializable
{
    public static final x10.rtt.RuntimeType<PlaceLocalHandle> $RTT = 
        x10.rtt.NamedStructType.<PlaceLocalHandle> make("x10.lang.PlaceLocalHandle",
                                                        PlaceLocalHandle.class,
                                                        1,
                                                        new x10.rtt.Type[] {
                                                            x10.rtt.Types.STRUCT
                                                        });
    
    public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
    
    public x10.rtt.Type<?> $getParam(int i) { if (i == 0) return $T; return null; }
    
    private Object writeReplace() throws java.io.ObjectStreamException {
        return new x10.serialization.SerializationProxy(this);
    }
    
    public static <$T> x10.serialization.X10JavaSerializable $_deserialize_body(x10.lang.PlaceLocalHandle<$T> $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
        $_obj.$T = (x10.rtt.Type) $deserializer.readObject();
        $_obj.__NATIVE_FIELD__ = $deserializer.readObject();
        return $_obj;
    }
    
    public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
        x10.lang.PlaceLocalHandle $_obj = new x10.lang.PlaceLocalHandle(null, (java.lang.System) null);
        return $_deserialize_body($_obj, $deserializer);
    }
    
    public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
        $serializer.write(this.$T);
        $serializer.write(this.__NATIVE_FIELD__);
        
    }
    
    // zero value constructor
    public PlaceLocalHandle(final x10.rtt.Type $T, final java.lang.System $dummy) { this.$T = $T; this.__NATIVE_FIELD__ = new x10.core.PlaceLocalHandle<$T>($T, $dummy); }
    
    // constructor just for allocation
    public PlaceLocalHandle(final java.lang.System[] $dummy, final x10.rtt.Type $T) {
        x10.lang.PlaceLocalHandle.$initParams(this, $T);
        
    }
    
    private x10.rtt.Type $T;
    
    // initializer of type parameters
    public static void $initParams(final PlaceLocalHandle $this, final x10.rtt.Type $T) {
        $this.$T = $T;
        
    }
    

    
    //#line 35 "x10/lang/PlaceLocalHandle.x10"
    public x10.core.PlaceLocalHandle<$T> __NATIVE_FIELD__;
    
    
    //#line 35 "x10/lang/PlaceLocalHandle.x10"
    public PlaceLocalHandle(final x10.rtt.Type $T, final x10.core.PlaceLocalHandle<$T> id0) {
        x10.lang.PlaceLocalHandle.$initParams(this, $T);
         {
            
            //#line 35 "x10/lang/PlaceLocalHandle.x10"
            ((x10.lang.PlaceLocalHandle<$T>)this).__NATIVE_FIELD__ = id0;
        }
    }
    
    
    
    //#line 38 "x10/lang/PlaceLocalHandle.x10"
    public PlaceLocalHandle(final x10.rtt.Type $T) {
        x10.lang.PlaceLocalHandle.$initParams(this, $T);
         {
            
            //#line 35 "x10/lang/PlaceLocalHandle.x10"
            ((x10.lang.PlaceLocalHandle<$T>)this).__NATIVE_FIELD__ = new x10.core.PlaceLocalHandle<$T>((java.lang.System[]) null, $T).x10$core$PlaceLocalHandle$$init$S();
        }
    }
    
    
    
    //#line 43 "x10/lang/PlaceLocalHandle.x10"
    /**
     * @return the object mapped to the handle at the current place
     */
    final public $T $apply$G() {
        
        //#line 35 "x10/lang/PlaceLocalHandle.x10"
        final x10.core.PlaceLocalHandle t$135469 = this.__NATIVE_FIELD__;
        
        //#line 35 "x10/lang/PlaceLocalHandle.x10"
        final $T t$135470 = (($T)(((x10.core.PlaceLocalHandle<$T>)t$135469).$apply$G()));
        
        //#line 35 "x10/lang/PlaceLocalHandle.x10"
        return t$135470;
    }
    
    
    //#line 46 "x10/lang/PlaceLocalHandle.x10"
    final public void set__0x10$lang$PlaceLocalHandle$$T(final $T newVal) {
        
        //#line 35 "x10/lang/PlaceLocalHandle.x10"
        final x10.core.PlaceLocalHandle t$135471 = this.__NATIVE_FIELD__;
        
        //#line 35 "x10/lang/PlaceLocalHandle.x10"
        ((x10.core.PlaceLocalHandle<$T>)t$135471).set__0x10$lang$PlaceLocalHandle$$T((($T)(newVal)));
    }
    
    
    //#line 48 "x10/lang/PlaceLocalHandle.x10"
    final public int hashCode() {
        
        //#line 35 "x10/lang/PlaceLocalHandle.x10"
        final x10.core.PlaceLocalHandle t$135472 = this.__NATIVE_FIELD__;
        
        //#line 35 "x10/lang/PlaceLocalHandle.x10"
        final int t$135473 = ((x10.core.PlaceLocalHandle<$T>)t$135472).hashCode();
        
        //#line 35 "x10/lang/PlaceLocalHandle.x10"
        return t$135473;
    }
    
    
    //#line 50 "x10/lang/PlaceLocalHandle.x10"
    final public java.lang.String toString() {
        
        //#line 35 "x10/lang/PlaceLocalHandle.x10"
        final x10.core.PlaceLocalHandle t$135474 = this.__NATIVE_FIELD__;
        
        //#line 35 "x10/lang/PlaceLocalHandle.x10"
        final java.lang.String t$135475 = ((x10.core.PlaceLocalHandle<$T>)t$135474).toString();
        
        //#line 35 "x10/lang/PlaceLocalHandle.x10"
        return t$135475;
    }
    
    
    //#line 63 "x10/lang/PlaceLocalHandle.x10"
    /**
     * Create a distributed object with local state of type T
     * at each place in the argument PlaceGroup.  The local object will be initialized
     * by evaluating init at each place.  When this method returns, the local objects
     * will be initialized and available via the returned PlaceLocalHandle instance
     * at every place in the PlaceGroup.
     *
     * @param pg a PlaceGroup specifiying the places where local objects should be created.
     * @param init the initialization closure used to create the local object.
     * @return a PlaceLocalHandle that can be used to access the local objects.
     */
    final public static <$T>x10.lang.PlaceLocalHandle make__1$1x10$lang$PlaceLocalHandle$$T$2(final x10.rtt.Type $T, final x10.lang.PlaceGroup pg, final x10.core.fun.Fun_0_0<$T> init) {
        
        //#line 64 "x10/lang/PlaceLocalHandle.x10"
        final x10.lang.PlaceLocalHandle handle = new x10.lang.PlaceLocalHandle<$T>($T);
        {
            
            //#line 65 "x10/lang/PlaceLocalHandle.x10"
            x10.xrx.Runtime.ensureNotInAtomic();
            
            //#line 65 "x10/lang/PlaceLocalHandle.x10"
            final x10.xrx.FinishState fs$135561 = x10.xrx.Runtime.startFinish();
            
            //#line 65 "x10/lang/PlaceLocalHandle.x10"
            try {{
                {
                    
                    //#line 65 "x10/lang/PlaceLocalHandle.x10"
                    final x10.lang.Iterator p$105546 = pg.iterator();
                    
                    //#line 65 "x10/lang/PlaceLocalHandle.x10"
                    for (;
                         true;
                         ) {
                        
                        //#line 65 "x10/lang/PlaceLocalHandle.x10"
                        final boolean t$135478 = ((x10.lang.Iterator<x10.lang.Place>)p$105546).hasNext$O();
                        
                        //#line 65 "x10/lang/PlaceLocalHandle.x10"
                        if (!(t$135478)) {
                            
                            //#line 65 "x10/lang/PlaceLocalHandle.x10"
                            break;
                        }
                        
                        //#line 65 "x10/lang/PlaceLocalHandle.x10"
                        final x10.lang.Place p$135527 = ((x10.lang.Place)(((x10.lang.Iterator<x10.lang.Place>)p$105546).next$G()));
                        
                        //#line 66 "x10/lang/PlaceLocalHandle.x10"
                        x10.xrx.Runtime.runAsync(((x10.lang.Place)(p$135527)), ((x10.core.fun.VoidFun_0_0)(new x10.lang.PlaceLocalHandle.$Closure$171<$T>($T, init, handle, (x10.lang.PlaceLocalHandle.$Closure$171.__0$1x10$lang$PlaceLocalHandle$$Closure$171$$T$2__1$1x10$lang$PlaceLocalHandle$$Closure$171$$T$2) null))), ((x10.xrx.Runtime.Profile)(null)));
                    }
                }
            }}catch (java.lang.Throwable ct$135559) {
                
                //#line 65 "x10/lang/PlaceLocalHandle.x10"
                x10.xrx.Runtime.pushException(((java.lang.Throwable)(ct$135559)));
                
                //#line 65 "x10/lang/PlaceLocalHandle.x10"
                throw new java.lang.RuntimeException();
            }finally {{
                 
                 //#line 65 "x10/lang/PlaceLocalHandle.x10"
                 x10.xrx.Runtime.stopFinish(((x10.xrx.FinishState)(fs$135561)));
             }}
            }
        
        //#line 68 "x10/lang/PlaceLocalHandle.x10"
        return handle;
        }
    
    
    //#line 84 "x10/lang/PlaceLocalHandle.x10"
    /**
     * Create a distributed object with local state of type T
     * at each place in the argument PlaceGroup.  The local object will be initialized
     * by evaluating init at each place.  When this method returns, the local objects
     * will be initialized and available via the returned PlaceLocalHandle instance
     * at every place in the PlaceGroup.
     *
     * @param pg a PlaceGroup specifiying the places where local objects should be created.
     * @param init the initialization closure used to create the local object.
     * @param ignoreIfDead a filter to indicate if a place can be silently ignored if it is 
     *        already known to be dead at the time make first attempt to access it.
     * @return a PlaceLocalHandle that can be used to access the local objects.
     */
    final public static <$T>x10.lang.PlaceLocalHandle make__1$1x10$lang$PlaceLocalHandle$$T$2__2$1x10$lang$Place$3x10$lang$Boolean$2(final x10.rtt.Type $T, final x10.lang.PlaceGroup pg, final x10.core.fun.Fun_0_0<$T> init, final x10.core.fun.Fun_0_1<x10.lang.Place,x10.core.Boolean> ignoreIfDead) {
        
        //#line 86 "x10/lang/PlaceLocalHandle.x10"
        final x10.lang.PlaceLocalHandle handle = new x10.lang.PlaceLocalHandle<$T>($T);
        {
            
            //#line 87 "x10/lang/PlaceLocalHandle.x10"
            x10.xrx.Runtime.ensureNotInAtomic();
            
            //#line 87 "x10/lang/PlaceLocalHandle.x10"
            final x10.xrx.FinishState fs$135569 = x10.xrx.Runtime.startFinish();
            
            //#line 87 "x10/lang/PlaceLocalHandle.x10"
            try {{
                {
                    
                    //#line 87 "x10/lang/PlaceLocalHandle.x10"
                    final x10.lang.Iterator p$105548 = pg.iterator();
                    
                    //#line 87 "x10/lang/PlaceLocalHandle.x10"
                    for (;
                         true;
                         ) {
                        
                        //#line 87 "x10/lang/PlaceLocalHandle.x10"
                        final boolean t$135485 = ((x10.lang.Iterator<x10.lang.Place>)p$105548).hasNext$O();
                        
                        //#line 87 "x10/lang/PlaceLocalHandle.x10"
                        if (!(t$135485)) {
                            
                            //#line 87 "x10/lang/PlaceLocalHandle.x10"
                            break;
                        }
                        
                        //#line 87 "x10/lang/PlaceLocalHandle.x10"
                        final x10.lang.Place p$135529 = ((x10.lang.Place)(((x10.lang.Iterator<x10.lang.Place>)p$105548).next$G()));
                        
                        //#line 88 "x10/lang/PlaceLocalHandle.x10"
                        final boolean t$135530 = p$135529.isDead$O();
                        
                        //#line 88 "x10/lang/PlaceLocalHandle.x10"
                        boolean t$135531 = !(t$135530);
                        
                        //#line 88 "x10/lang/PlaceLocalHandle.x10"
                        if (!(t$135531)) {
                            
                            //#line 88 "x10/lang/PlaceLocalHandle.x10"
                            final boolean t$135532 = x10.core.Boolean.$unbox(((x10.core.fun.Fun_0_1<x10.lang.Place,x10.core.Boolean>)ignoreIfDead).$apply(p$135529, x10.lang.Place.$RTT));
                            
                            //#line 88 "x10/lang/PlaceLocalHandle.x10"
                            t$135531 = !(t$135532);
                        }
                        
                        //#line 88 "x10/lang/PlaceLocalHandle.x10"
                        if (t$135531) {
                            
                            //#line 89 "x10/lang/PlaceLocalHandle.x10"
                            x10.xrx.Runtime.runAsync(((x10.lang.Place)(p$135529)), ((x10.core.fun.VoidFun_0_0)(new x10.lang.PlaceLocalHandle.$Closure$172<$T>($T, init, handle, (x10.lang.PlaceLocalHandle.$Closure$172.__0$1x10$lang$PlaceLocalHandle$$Closure$172$$T$2__1$1x10$lang$PlaceLocalHandle$$Closure$172$$T$2) null))), ((x10.xrx.Runtime.Profile)(null)));
                        }
                    }
                }
            }}catch (java.lang.Throwable ct$135567) {
                
                //#line 87 "x10/lang/PlaceLocalHandle.x10"
                x10.xrx.Runtime.pushException(((java.lang.Throwable)(ct$135567)));
                
                //#line 87 "x10/lang/PlaceLocalHandle.x10"
                throw new java.lang.RuntimeException();
            }finally {{
                 
                 //#line 87 "x10/lang/PlaceLocalHandle.x10"
                 x10.xrx.Runtime.stopFinish(((x10.xrx.FinishState)(fs$135569)));
             }}
            }
        
        //#line 92 "x10/lang/PlaceLocalHandle.x10"
        return handle;
        }
    
    
    //#line 109 "x10/lang/PlaceLocalHandle.x10"
    /**
     * Create a distributed object with local state of type T
     * at each place in the argument PlaceGroup.  For each place in the
     * argument PlaceGroup, the local_init closure will be evaluated in the 
     * current place to yield a value of type U.  This value will then be serialized 
     * to the target place and passed as an argument to the init closure. 
     * When this method returns, the local objects will be initialized and available 
     * via the returned PlaceLocalHandle instance at every place in the distribution.
     *
     * @param dist a distribution specifiying the places where local objects should be created.
     * @param init_here a closure to compute the local portion of the initialization (evaluated in the current place)
     * @param init_there a closure to be evaluated in each place to create the local objects.
     * @return a PlaceLocalHandle that can be used to access the local objects.
     */
    final public static <$T, $U>x10.lang.PlaceLocalHandle make__1$1x10$lang$Place$3x10$lang$PlaceLocalHandle$$U$2__2$1x10$lang$PlaceLocalHandle$$U$3x10$lang$PlaceLocalHandle$$T$2(final x10.rtt.Type $T, final x10.rtt.Type $U, final x10.lang.PlaceGroup pg, final x10.core.fun.Fun_0_1<x10.lang.Place,$U> init_here, final x10.core.fun.Fun_0_1<$U,$T> init_there) {
        
        //#line 110 "x10/lang/PlaceLocalHandle.x10"
        final x10.lang.PlaceLocalHandle handle = new x10.lang.PlaceLocalHandle<$T>($T);
        {
            
            //#line 111 "x10/lang/PlaceLocalHandle.x10"
            x10.xrx.Runtime.ensureNotInAtomic();
            
            //#line 111 "x10/lang/PlaceLocalHandle.x10"
            final x10.xrx.FinishState fs$135577 = x10.xrx.Runtime.startFinish();
            
            //#line 111 "x10/lang/PlaceLocalHandle.x10"
            try {{
                {
                    
                    //#line 111 "x10/lang/PlaceLocalHandle.x10"
                    final x10.lang.Iterator p$105550 = pg.iterator();
                    
                    //#line 111 "x10/lang/PlaceLocalHandle.x10"
                    for (;
                         true;
                         ) {
                        
                        //#line 111 "x10/lang/PlaceLocalHandle.x10"
                        final boolean t$135488 = ((x10.lang.Iterator<x10.lang.Place>)p$105550).hasNext$O();
                        
                        //#line 111 "x10/lang/PlaceLocalHandle.x10"
                        if (!(t$135488)) {
                            
                            //#line 111 "x10/lang/PlaceLocalHandle.x10"
                            break;
                        }
                        
                        //#line 111 "x10/lang/PlaceLocalHandle.x10"
                        final x10.lang.Place p$135535 = ((x10.lang.Place)(((x10.lang.Iterator<x10.lang.Place>)p$105550).next$G()));
                        
                        //#line 112 "x10/lang/PlaceLocalHandle.x10"
                        final $U v$135536 = (($U)((($U)
                                                    ((x10.core.fun.Fun_0_1<x10.lang.Place,$U>)init_here).$apply(p$135535, x10.lang.Place.$RTT))));
                        
                        //#line 113 "x10/lang/PlaceLocalHandle.x10"
                        x10.xrx.Runtime.runAsync(((x10.lang.Place)(p$135535)), ((x10.core.fun.VoidFun_0_0)(new x10.lang.PlaceLocalHandle.$Closure$173<$T, $U>($T, $U, init_there, v$135536, handle, (x10.lang.PlaceLocalHandle.$Closure$173.__0$1x10$lang$PlaceLocalHandle$$Closure$173$$U$3x10$lang$PlaceLocalHandle$$Closure$173$$T$2__1x10$lang$PlaceLocalHandle$$Closure$173$$U__2$1x10$lang$PlaceLocalHandle$$Closure$173$$T$2) null))), ((x10.xrx.Runtime.Profile)(null)));
                    }
                }
            }}catch (java.lang.Throwable ct$135575) {
                
                //#line 111 "x10/lang/PlaceLocalHandle.x10"
                x10.xrx.Runtime.pushException(((java.lang.Throwable)(ct$135575)));
                
                //#line 111 "x10/lang/PlaceLocalHandle.x10"
                throw new java.lang.RuntimeException();
            }finally {{
                 
                 //#line 111 "x10/lang/PlaceLocalHandle.x10"
                 x10.xrx.Runtime.stopFinish(((x10.xrx.FinishState)(fs$135577)));
             }}
            }
        
        //#line 115 "x10/lang/PlaceLocalHandle.x10"
        return handle;
        }
    
    
    //#line 134 "x10/lang/PlaceLocalHandle.x10"
    /**
     * Create a distributed object with local state of type T
     * at each place in the argument PlaceGroup.  For each place in the
     * argument PlaceGroup, the local_init closure will be evaluated in the 
     * current place to yield a value of type U.  This value will then be serialized 
     * to the target place and passed as an argument to the init closure. 
     * When this method returns, the local objects will be initialized and available 
     * via the returned PlaceLocalHandle instance at every place in the distribution.
     *
     * @param dist a distribution specifiying the places where local objects should be created.
     * @param init_here a closure to compute the local portion of the initialization (evaluated in the current place)
     * @param init_there a closure to be evaluated in each place to create the local objects.
     * @param ignoreIfDead a filter to indicate if a place can be silently ignored if it is 
     *        already known to be dead at the time make first attempt to access it.
     * @return a PlaceLocalHandle that can be used to access the local objects.
     */
    final public static <$T, $U>x10.lang.PlaceLocalHandle make__1$1x10$lang$Place$3x10$lang$PlaceLocalHandle$$U$2__2$1x10$lang$PlaceLocalHandle$$U$3x10$lang$PlaceLocalHandle$$T$2__3$1x10$lang$Place$3x10$lang$Boolean$2(final x10.rtt.Type $T, final x10.rtt.Type $U, final x10.lang.PlaceGroup pg, final x10.core.fun.Fun_0_1<x10.lang.Place,$U> init_here, final x10.core.fun.Fun_0_1<$U,$T> init_there, final x10.core.fun.Fun_0_1<x10.lang.Place,x10.core.Boolean> ignoreIfDead) {
        
        //#line 136 "x10/lang/PlaceLocalHandle.x10"
        final x10.lang.PlaceLocalHandle handle = new x10.lang.PlaceLocalHandle<$T>($T);
        {
            
            //#line 137 "x10/lang/PlaceLocalHandle.x10"
            x10.xrx.Runtime.ensureNotInAtomic();
            
            //#line 137 "x10/lang/PlaceLocalHandle.x10"
            final x10.xrx.FinishState fs$135585 = x10.xrx.Runtime.startFinish();
            
            //#line 137 "x10/lang/PlaceLocalHandle.x10"
            try {{
                {
                    
                    //#line 137 "x10/lang/PlaceLocalHandle.x10"
                    final x10.lang.Iterator p$105552 = pg.iterator();
                    
                    //#line 137 "x10/lang/PlaceLocalHandle.x10"
                    for (;
                         true;
                         ) {
                        
                        //#line 137 "x10/lang/PlaceLocalHandle.x10"
                        final boolean t$135495 = ((x10.lang.Iterator<x10.lang.Place>)p$105552).hasNext$O();
                        
                        //#line 137 "x10/lang/PlaceLocalHandle.x10"
                        if (!(t$135495)) {
                            
                            //#line 137 "x10/lang/PlaceLocalHandle.x10"
                            break;
                        }
                        
                        //#line 137 "x10/lang/PlaceLocalHandle.x10"
                        final x10.lang.Place p$135538 = ((x10.lang.Place)(((x10.lang.Iterator<x10.lang.Place>)p$105552).next$G()));
                        
                        //#line 138 "x10/lang/PlaceLocalHandle.x10"
                        final $U v$135539 = (($U)((($U)
                                                    ((x10.core.fun.Fun_0_1<x10.lang.Place,$U>)init_here).$apply(p$135538, x10.lang.Place.$RTT))));
                        
                        //#line 139 "x10/lang/PlaceLocalHandle.x10"
                        final boolean t$135540 = p$135538.isDead$O();
                        
                        //#line 139 "x10/lang/PlaceLocalHandle.x10"
                        boolean t$135541 = !(t$135540);
                        
                        //#line 139 "x10/lang/PlaceLocalHandle.x10"
                        if (!(t$135541)) {
                            
                            //#line 139 "x10/lang/PlaceLocalHandle.x10"
                            final boolean t$135542 = x10.core.Boolean.$unbox(((x10.core.fun.Fun_0_1<x10.lang.Place,x10.core.Boolean>)ignoreIfDead).$apply(p$135538, x10.lang.Place.$RTT));
                            
                            //#line 139 "x10/lang/PlaceLocalHandle.x10"
                            t$135541 = !(t$135542);
                        }
                        
                        //#line 139 "x10/lang/PlaceLocalHandle.x10"
                        if (t$135541) {
                            
                            //#line 140 "x10/lang/PlaceLocalHandle.x10"
                            x10.xrx.Runtime.runAsync(((x10.lang.Place)(p$135538)), ((x10.core.fun.VoidFun_0_0)(new x10.lang.PlaceLocalHandle.$Closure$174<$T, $U>($T, $U, init_there, v$135539, handle, (x10.lang.PlaceLocalHandle.$Closure$174.__0$1x10$lang$PlaceLocalHandle$$Closure$174$$U$3x10$lang$PlaceLocalHandle$$Closure$174$$T$2__1x10$lang$PlaceLocalHandle$$Closure$174$$U__2$1x10$lang$PlaceLocalHandle$$Closure$174$$T$2) null))), ((x10.xrx.Runtime.Profile)(null)));
                        }
                    }
                }
            }}catch (java.lang.Throwable ct$135583) {
                
                //#line 137 "x10/lang/PlaceLocalHandle.x10"
                x10.xrx.Runtime.pushException(((java.lang.Throwable)(ct$135583)));
                
                //#line 137 "x10/lang/PlaceLocalHandle.x10"
                throw new java.lang.RuntimeException();
            }finally {{
                 
                 //#line 137 "x10/lang/PlaceLocalHandle.x10"
                 x10.xrx.Runtime.stopFinish(((x10.xrx.FinishState)(fs$135585)));
             }}
            }
        
        //#line 143 "x10/lang/PlaceLocalHandle.x10"
        return handle;
        }
    
    
    //#line 164 "x10/lang/PlaceLocalHandle.x10"
    /**
     * Create a distributed object with local state of type T
     * at each place in the argument PlaceGroup.  The local object will be initialized
     * by evaluating init at each place.  When this method returns, the local objects
     * will be initialized and available via the returned PlaceLocalHandle instance
     * at every place in the PlaceGroup.
     *
     * Requires an initialization closure which has no exposed at/async constructs
     * (any async/at must be nested inside of a finish).
     *
     * @param pg a PlaceGroup specifiying the places where local objects should be created.
     * @param init the initialization closure used to create the local object.
     * @return a PlaceLocalHandle that can be used to access the local objects.
     */
    final public static <$T>x10.lang.PlaceLocalHandle makeFlat__1$1x10$lang$PlaceLocalHandle$$T$2(final x10.rtt.Type $T, final x10.lang.PlaceGroup pg, final x10.core.fun.Fun_0_0<$T> init) {
        
        //#line 165 "x10/lang/PlaceLocalHandle.x10"
        final x10.lang.PlaceLocalHandle handle = new x10.lang.PlaceLocalHandle<$T>($T);
        
        //#line 166 "x10/lang/PlaceLocalHandle.x10"
        final x10.core.fun.VoidFun_0_0 t$135497 = ((x10.core.fun.VoidFun_0_0)(new x10.lang.PlaceLocalHandle.$Closure$175<$T>($T, init, handle, (x10.lang.PlaceLocalHandle.$Closure$175.__0$1x10$lang$PlaceLocalHandle$$Closure$175$$T$2__1$1x10$lang$PlaceLocalHandle$$Closure$175$$T$2) null)));
        
        //#line 166 "x10/lang/PlaceLocalHandle.x10"
        pg.broadcastFlat(((x10.core.fun.VoidFun_0_0)(t$135497)));
        
        //#line 167 "x10/lang/PlaceLocalHandle.x10"
        return handle;
    }
    
    
    //#line 186 "x10/lang/PlaceLocalHandle.x10"
    /**
     * Create a distributed object with local state of type T
     * at each place in the argument PlaceGroup.  The local object will be initialized
     * by evaluating init at each place.  When this method returns, the local objects
     * will be initialized and available via the returned PlaceLocalHandle instance
     * at every place in the PlaceGroup.
     *
     * Requires an initialization closure which has no exposed at/async constructs
     * (any async/at must be nested inside of a finish).
     *
     * @param pg a PlaceGroup specifiying the places where local objects should be created.
     * @param init the initialization closure used to create the local object.
     * @param ignoreIfDead a filter to indicate if a place can be silently ignored if it is 
     *        already known to be dead at the time make first attempt to access it.
     * @return a PlaceLocalHandle that can be used to access the local objects.
     */
    final public static <$T>x10.lang.PlaceLocalHandle makeFlat__1$1x10$lang$PlaceLocalHandle$$T$2__2$1x10$lang$Place$3x10$lang$Boolean$2(final x10.rtt.Type $T, final x10.lang.PlaceGroup pg, final x10.core.fun.Fun_0_0<$T> init, final x10.core.fun.Fun_0_1<x10.lang.Place,x10.core.Boolean> ignoreIfDead) {
        
        //#line 188 "x10/lang/PlaceLocalHandle.x10"
        final x10.lang.PlaceLocalHandle handle = new x10.lang.PlaceLocalHandle<$T>($T);
        
        //#line 189 "x10/lang/PlaceLocalHandle.x10"
        final x10.core.fun.VoidFun_0_0 t$135499 = ((x10.core.fun.VoidFun_0_0)(new x10.lang.PlaceLocalHandle.$Closure$176<$T>($T, init, handle, (x10.lang.PlaceLocalHandle.$Closure$176.__0$1x10$lang$PlaceLocalHandle$$Closure$176$$T$2__1$1x10$lang$PlaceLocalHandle$$Closure$176$$T$2) null)));
        
        //#line 189 "x10/lang/PlaceLocalHandle.x10"
        pg.broadcastFlat__1$1x10$lang$Place$3x10$lang$Boolean$2(((x10.core.fun.VoidFun_0_0)(t$135499)), ((x10.core.fun.Fun_0_1)(ignoreIfDead)));
        
        //#line 190 "x10/lang/PlaceLocalHandle.x10"
        return handle;
    }
    
    
    //#line 210 "x10/lang/PlaceLocalHandle.x10"
    /**
     * Create a distributed object with local state of type T
     * at each place in the argument PlaceGroup.  For each place in the
     * argument PlaceGroup, the local_init closure will be evaluated in the 
     * current place to yield a value of type U.  This value will then be serialized 
     * to the target place and passed as an argument to the init closure. 
     * When this method returns, the local objects will be initialized and available 
     * via the returned PlaceLocalHandle instance at every place in the distribution.
     *
     * Requires an init_there initialization closure which has no exposed at/async constructs
     * (any async/at must be nested inside of a finish).
     *
     * @param dist a distribution specifiying the places where local objects should be created.
     * @param init_here a closure to compute the local portion of the initialization (evaluated in the current place)
     * @param init_there a closure to be evaluated in each place to create the local objects.
     * @return a PlaceLocalHandle that can be used to access the local objects.
     */
    final public static <$T, $U>x10.lang.PlaceLocalHandle makeFlat__1$1x10$lang$Place$3x10$lang$PlaceLocalHandle$$U$2__2$1x10$lang$PlaceLocalHandle$$U$3x10$lang$PlaceLocalHandle$$T$2(final x10.rtt.Type $T, final x10.rtt.Type $U, final x10.lang.PlaceGroup pg, final x10.core.fun.Fun_0_1<x10.lang.Place,$U> init_here, final x10.core.fun.Fun_0_1<$U,$T> init_there) {
        
        //#line 211 "x10/lang/PlaceLocalHandle.x10"
        final x10.lang.PlaceLocalHandle handle = new x10.lang.PlaceLocalHandle<$T>($T);
        {
            
            //#line 212 "x10/lang/PlaceLocalHandle.x10"
            x10.xrx.Runtime.ensureNotInAtomic();
            
            //#line 212 "x10/lang/PlaceLocalHandle.x10"
            final x10.xrx.FinishState fs$135594 = x10.xrx.Runtime.startFinish((int)(x10.compiler.Pragma.FINISH_SPMD));
            
            //#line 212 "x10/lang/PlaceLocalHandle.x10"
            try {{
                {
                    
                    //#line 212 "x10/lang/PlaceLocalHandle.x10"
                    final x10.lang.Iterator p$105554 = pg.iterator();
                    
                    //#line 212 "x10/lang/PlaceLocalHandle.x10"
                    for (;
                         true;
                         ) {
                        
                        //#line 212 "x10/lang/PlaceLocalHandle.x10"
                        final boolean t$135502 = ((x10.lang.Iterator<x10.lang.Place>)p$105554).hasNext$O();
                        
                        //#line 212 "x10/lang/PlaceLocalHandle.x10"
                        if (!(t$135502)) {
                            
                            //#line 212 "x10/lang/PlaceLocalHandle.x10"
                            break;
                        }
                        
                        //#line 212 "x10/lang/PlaceLocalHandle.x10"
                        final x10.lang.Place p$135545 = ((x10.lang.Place)(((x10.lang.Iterator<x10.lang.Place>)p$105554).next$G()));
                        
                        //#line 213 "x10/lang/PlaceLocalHandle.x10"
                        final $U v$135546 = (($U)((($U)
                                                    ((x10.core.fun.Fun_0_1<x10.lang.Place,$U>)init_here).$apply(p$135545, x10.lang.Place.$RTT))));
                        
                        //#line 214 "x10/lang/PlaceLocalHandle.x10"
                        x10.xrx.Runtime.runAsync(((x10.lang.Place)(p$135545)), ((x10.core.fun.VoidFun_0_0)(new x10.lang.PlaceLocalHandle.$Closure$177<$T, $U>($T, $U, init_there, v$135546, handle, (x10.lang.PlaceLocalHandle.$Closure$177.__0$1x10$lang$PlaceLocalHandle$$Closure$177$$U$3x10$lang$PlaceLocalHandle$$Closure$177$$T$2__1x10$lang$PlaceLocalHandle$$Closure$177$$U__2$1x10$lang$PlaceLocalHandle$$Closure$177$$T$2) null))), ((x10.xrx.Runtime.Profile)(null)));
                    }
                }
            }}catch (java.lang.Throwable ct$135591) {
                
                //#line 212 "x10/lang/PlaceLocalHandle.x10"
                x10.xrx.Runtime.pushException(((java.lang.Throwable)(ct$135591)));
                
                //#line 212 "x10/lang/PlaceLocalHandle.x10"
                throw new java.lang.RuntimeException();
            }finally {{
                 
                 //#line 212 "x10/lang/PlaceLocalHandle.x10"
                 x10.xrx.Runtime.stopFinish(((x10.xrx.FinishState)(fs$135594)));
             }}
            }
        
        //#line 216 "x10/lang/PlaceLocalHandle.x10"
        return handle;
        }
    
    
    //#line 238 "x10/lang/PlaceLocalHandle.x10"
    /**
     * Create a distributed object with local state of type T
     * at each place in the argument PlaceGroup.  For each place in the
     * argument PlaceGroup, the local_init closure will be evaluated in the 
     * current place to yield a value of type U.  This value will then be serialized 
     * to the target place and passed as an argument to the init closure. 
     * When this method returns, the local objects will be initialized and available 
     * via the returned PlaceLocalHandle instance at every place in the distribution.
     *
     * Requires an init_there initialization closure which has no exposed at/async constructs
     * (any async/at must be nested inside of a finish).
     *
     * @param dist a distribution specifiying the places where local objects should be created.
     * @param init_here a closure to compute the local portion of the initialization (evaluated in the current place)
     * @param init_there a closure to be evaluated in each place to create the local objects.
     * @param ignoreIfDead a filter to indicate if a place can be silently ignored if it is 
     *        already known to be dead at the time make first attempt to access it.
     * @return a PlaceLocalHandle that can be used to access the local objects.
     */
    final public static <$T, $U>x10.lang.PlaceLocalHandle makeFlat__1$1x10$lang$Place$3x10$lang$PlaceLocalHandle$$U$2__2$1x10$lang$PlaceLocalHandle$$U$3x10$lang$PlaceLocalHandle$$T$2__3$1x10$lang$Place$3x10$lang$Boolean$2(final x10.rtt.Type $T, final x10.rtt.Type $U, final x10.lang.PlaceGroup pg, final x10.core.fun.Fun_0_1<x10.lang.Place,$U> init_here, final x10.core.fun.Fun_0_1<$U,$T> init_there, final x10.core.fun.Fun_0_1<x10.lang.Place,x10.core.Boolean> ignoreIfDead) {
        
        //#line 240 "x10/lang/PlaceLocalHandle.x10"
        final x10.lang.PlaceLocalHandle handle = new x10.lang.PlaceLocalHandle<$T>($T);
        {
            
            //#line 241 "x10/lang/PlaceLocalHandle.x10"
            x10.xrx.Runtime.ensureNotInAtomic();
            
            //#line 241 "x10/lang/PlaceLocalHandle.x10"
            final x10.xrx.FinishState fs$135603 = x10.xrx.Runtime.startFinish((int)(x10.compiler.Pragma.FINISH_SPMD));
            
            //#line 241 "x10/lang/PlaceLocalHandle.x10"
            try {{
                {
                    
                    //#line 241 "x10/lang/PlaceLocalHandle.x10"
                    final x10.lang.Iterator p$105556 = pg.iterator();
                    
                    //#line 241 "x10/lang/PlaceLocalHandle.x10"
                    for (;
                         true;
                         ) {
                        
                        //#line 241 "x10/lang/PlaceLocalHandle.x10"
                        final boolean t$135509 = ((x10.lang.Iterator<x10.lang.Place>)p$105556).hasNext$O();
                        
                        //#line 241 "x10/lang/PlaceLocalHandle.x10"
                        if (!(t$135509)) {
                            
                            //#line 241 "x10/lang/PlaceLocalHandle.x10"
                            break;
                        }
                        
                        //#line 241 "x10/lang/PlaceLocalHandle.x10"
                        final x10.lang.Place p$135548 = ((x10.lang.Place)(((x10.lang.Iterator<x10.lang.Place>)p$105556).next$G()));
                        
                        //#line 242 "x10/lang/PlaceLocalHandle.x10"
                        final $U v$135549 = (($U)((($U)
                                                    ((x10.core.fun.Fun_0_1<x10.lang.Place,$U>)init_here).$apply(p$135548, x10.lang.Place.$RTT))));
                        
                        //#line 243 "x10/lang/PlaceLocalHandle.x10"
                        final boolean t$135550 = p$135548.isDead$O();
                        
                        //#line 243 "x10/lang/PlaceLocalHandle.x10"
                        boolean t$135551 = !(t$135550);
                        
                        //#line 243 "x10/lang/PlaceLocalHandle.x10"
                        if (!(t$135551)) {
                            
                            //#line 243 "x10/lang/PlaceLocalHandle.x10"
                            final boolean t$135552 = x10.core.Boolean.$unbox(((x10.core.fun.Fun_0_1<x10.lang.Place,x10.core.Boolean>)ignoreIfDead).$apply(p$135548, x10.lang.Place.$RTT));
                            
                            //#line 243 "x10/lang/PlaceLocalHandle.x10"
                            t$135551 = !(t$135552);
                        }
                        
                        //#line 243 "x10/lang/PlaceLocalHandle.x10"
                        if (t$135551) {
                            
                            //#line 244 "x10/lang/PlaceLocalHandle.x10"
                            x10.xrx.Runtime.runAsync(((x10.lang.Place)(p$135548)), ((x10.core.fun.VoidFun_0_0)(new x10.lang.PlaceLocalHandle.$Closure$178<$T, $U>($T, $U, init_there, v$135549, handle, (x10.lang.PlaceLocalHandle.$Closure$178.__0$1x10$lang$PlaceLocalHandle$$Closure$178$$U$3x10$lang$PlaceLocalHandle$$Closure$178$$T$2__1x10$lang$PlaceLocalHandle$$Closure$178$$U__2$1x10$lang$PlaceLocalHandle$$Closure$178$$T$2) null))), ((x10.xrx.Runtime.Profile)(null)));
                        }
                    }
                }
            }}catch (java.lang.Throwable ct$135600) {
                
                //#line 241 "x10/lang/PlaceLocalHandle.x10"
                x10.xrx.Runtime.pushException(((java.lang.Throwable)(ct$135600)));
                
                //#line 241 "x10/lang/PlaceLocalHandle.x10"
                throw new java.lang.RuntimeException();
            }finally {{
                 
                 //#line 241 "x10/lang/PlaceLocalHandle.x10"
                 x10.xrx.Runtime.stopFinish(((x10.xrx.FinishState)(fs$135603)));
             }}
            }
        
        //#line 247 "x10/lang/PlaceLocalHandle.x10"
        return handle;
        }
    
    
    //#line 259 "x10/lang/PlaceLocalHandle.x10"
    /**
     * Augment the PlaceGroup at which the argument PlaceLocalHandle has
     * a value with the given place by evaluating the argument initialization 
     * closure at that Place to and storing its result in the PlaceLocalHandle.
     *
     * @param plh a place local handle to extend with a new Place
     * @param place the Place at which to extend it
     * @param init a closure to be evaluated at place to create the value to be stored
     */
    final public static <$T>void addPlace__0$1x10$lang$PlaceLocalHandle$$T$2__2$1x10$lang$PlaceLocalHandle$$T$2(final x10.rtt.Type $T, final x10.lang.PlaceLocalHandle<$T> plh, final x10.lang.Place place, final x10.core.fun.Fun_0_0<$T> init) {
        {
            
            //#line 261 "x10/lang/PlaceLocalHandle.x10"
            x10.xrx.Runtime.runAt(((x10.lang.Place)(place)), ((x10.core.fun.VoidFun_0_0)(new x10.lang.PlaceLocalHandle.$Closure$179<$T>($T, init, plh, (x10.lang.PlaceLocalHandle.$Closure$179.__0$1x10$lang$PlaceLocalHandle$$Closure$179$$T$2__1$1x10$lang$PlaceLocalHandle$$Closure$179$$T$2) null))), ((x10.xrx.Runtime.Profile)(null)));
        }
    }
    
    
    //#line 269 "x10/lang/PlaceLocalHandle.x10"
    /**
     * Release the local state of the argument PlaceLocalHandle at
     * every place in the argument PlaceGroup (by storing null
     * as the value for the PlaceLocalHandle at that Place).
     */
    final public static <$T>void destroy__1$1x10$lang$PlaceLocalHandle$$T$2(final x10.rtt.Type $T, final x10.lang.PlaceGroup pg, final x10.lang.PlaceLocalHandle<$T> plh) {
        
        //#line 270 "x10/lang/PlaceLocalHandle.x10"
        final x10.core.fun.VoidFun_0_0 t$135511 = ((x10.core.fun.VoidFun_0_0)(new x10.lang.PlaceLocalHandle.$Closure$180<$T>($T, plh, (x10.lang.PlaceLocalHandle.$Closure$180.__0$1x10$lang$PlaceLocalHandle$$Closure$180$$T$2) null)));
        
        //#line 270 "x10/lang/PlaceLocalHandle.x10"
        pg.broadcastFlat(((x10.core.fun.VoidFun_0_0)(t$135511)));
    }
    
    
    //#line 278 "x10/lang/PlaceLocalHandle.x10"
    /**
     * Release the local state of the argument PlaceLocalHandle at
     * every place in the argument PlaceGroup (by storing null
     * as the value for the PlaceLocalHandle at that Place).
     */
    final public static <$T>void destroy__1$1x10$lang$PlaceLocalHandle$$T$2__2$1x10$lang$Place$3x10$lang$Boolean$2(final x10.rtt.Type $T, final x10.lang.PlaceGroup pg, final x10.lang.PlaceLocalHandle<$T> plh, final x10.core.fun.Fun_0_1<x10.lang.Place,x10.core.Boolean> ignoreIfDead) {
        
        //#line 280 "x10/lang/PlaceLocalHandle.x10"
        final x10.core.fun.VoidFun_0_0 t$135512 = ((x10.core.fun.VoidFun_0_0)(new x10.lang.PlaceLocalHandle.$Closure$181<$T>($T, plh, (x10.lang.PlaceLocalHandle.$Closure$181.__0$1x10$lang$PlaceLocalHandle$$Closure$181$$T$2) null)));
        
        //#line 280 "x10/lang/PlaceLocalHandle.x10"
        pg.broadcastFlat__1$1x10$lang$Place$3x10$lang$Boolean$2(((x10.core.fun.VoidFun_0_0)(t$135512)), ((x10.core.fun.Fun_0_1)(ignoreIfDead)));
    }
    
    
    //#line 35 "x10/lang/PlaceLocalHandle.x10"
    final public java.lang.String typeName() {
        try {
            return x10.rtt.Types.typeName(this);
        }
        catch (java.lang.Throwable exc$206433) {
            throw x10.runtime.impl.java.ThrowableUtils.ensureX10Exception(exc$206433);
        }
        
    }
    
    
    
    //#line 35 "x10/lang/PlaceLocalHandle.x10"
    final public boolean equals(java.lang.Object other) {
        
        //#line 35 "x10/lang/PlaceLocalHandle.x10"
        final boolean t$135516 = x10.lang.PlaceLocalHandle.$RTT.isInstance(other, $T);
        
        //#line 35 "x10/lang/PlaceLocalHandle.x10"
        final boolean t$135517 = !(t$135516);
        
        //#line 35 "x10/lang/PlaceLocalHandle.x10"
        if (t$135517) {
            
            //#line 35 "x10/lang/PlaceLocalHandle.x10"
            return false;
        }
        
        //#line 35 "x10/lang/PlaceLocalHandle.x10"
        final x10.lang.PlaceLocalHandle t$135519 = ((x10.lang.PlaceLocalHandle)x10.rtt.Types.asStruct(x10.rtt.ParameterizedType.make(x10.lang.PlaceLocalHandle.$RTT, $T),other));
        
        //#line 35 "x10/lang/PlaceLocalHandle.x10"
        final boolean t$135520 = this.equals__0$1x10$lang$PlaceLocalHandle$$T$2$O(((x10.lang.PlaceLocalHandle)(t$135519)));
        
        //#line 35 "x10/lang/PlaceLocalHandle.x10"
        return t$135520;
    }
    
    
    //#line 35 "x10/lang/PlaceLocalHandle.x10"
    final public boolean equals__0$1x10$lang$PlaceLocalHandle$$T$2$O(x10.lang.PlaceLocalHandle other) {
        
        //#line 35 "x10/lang/PlaceLocalHandle.x10"
        return true;
    }
    
    
    //#line 35 "x10/lang/PlaceLocalHandle.x10"
    final public boolean _struct_equals$O(java.lang.Object other) {
        
        //#line 35 "x10/lang/PlaceLocalHandle.x10"
        final boolean t$135522 = x10.lang.PlaceLocalHandle.$RTT.isInstance(other, $T);
        
        //#line 35 "x10/lang/PlaceLocalHandle.x10"
        final boolean t$135523 = !(t$135522);
        
        //#line 35 "x10/lang/PlaceLocalHandle.x10"
        if (t$135523) {
            
            //#line 35 "x10/lang/PlaceLocalHandle.x10"
            return false;
        }
        
        //#line 35 "x10/lang/PlaceLocalHandle.x10"
        final x10.lang.PlaceLocalHandle t$135525 = ((x10.lang.PlaceLocalHandle)x10.rtt.Types.asStruct(x10.rtt.ParameterizedType.make(x10.lang.PlaceLocalHandle.$RTT, $T),other));
        
        //#line 35 "x10/lang/PlaceLocalHandle.x10"
        final boolean t$135526 = this._struct_equals__0$1x10$lang$PlaceLocalHandle$$T$2$O(((x10.lang.PlaceLocalHandle)(t$135525)));
        
        //#line 35 "x10/lang/PlaceLocalHandle.x10"
        return t$135526;
    }
    
    
    //#line 35 "x10/lang/PlaceLocalHandle.x10"
    final public boolean _struct_equals__0$1x10$lang$PlaceLocalHandle$$T$2$O(x10.lang.PlaceLocalHandle other) {
        
        //#line 35 "x10/lang/PlaceLocalHandle.x10"
        return true;
    }
    
    
    //#line 33 "x10/lang/PlaceLocalHandle.x10"
    final public x10.lang.PlaceLocalHandle x10$lang$PlaceLocalHandle$$this$x10$lang$PlaceLocalHandle() {
        
        //#line 33 "x10/lang/PlaceLocalHandle.x10"
        return x10.lang.PlaceLocalHandle.this;
    }
    
    
    //#line 33 "x10/lang/PlaceLocalHandle.x10"
    final public void __fieldInitializers_x10_lang_PlaceLocalHandle() {
        
    }
    
    @x10.runtime.impl.java.X10Generated
    final public static class $Closure$171<$T> extends x10.core.Ref implements x10.core.fun.VoidFun_0_0, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<$Closure$171> $RTT = 
            x10.rtt.StaticVoidFunType.<$Closure$171> make($Closure$171.class,
                                                          1,
                                                          new x10.rtt.Type[] {
                                                              x10.core.fun.VoidFun_0_0.$RTT
                                                          });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { if (i == 0) return $T; return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static <$T> x10.serialization.X10JavaSerializable $_deserialize_body(x10.lang.PlaceLocalHandle.$Closure$171<$T> $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            $_obj.$T = (x10.rtt.Type) $deserializer.readObject();
            $_obj.handle = $deserializer.readObject();
            $_obj.init = $deserializer.readObject();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.lang.PlaceLocalHandle.$Closure$171 $_obj = new x10.lang.PlaceLocalHandle.$Closure$171((java.lang.System[]) null, (x10.rtt.Type) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            $serializer.write(this.$T);
            $serializer.write(this.handle);
            $serializer.write(this.init);
            
        }
        
        // constructor just for allocation
        public $Closure$171(final java.lang.System[] $dummy, final x10.rtt.Type $T) {
            x10.lang.PlaceLocalHandle.$Closure$171.$initParams(this, $T);
            
        }
        
        private x10.rtt.Type $T;
        
        // initializer of type parameters
        public static void $initParams(final $Closure$171 $this, final x10.rtt.Type $T) {
            $this.$T = $T;
            
        }
        // synthetic type for parameter mangling
        public static final class __0$1x10$lang$PlaceLocalHandle$$Closure$171$$T$2__1$1x10$lang$PlaceLocalHandle$$Closure$171$$T$2 {}
        
    
        
        public void $apply() {
            
            //#line 66 "x10/lang/PlaceLocalHandle.x10"
            try {{
                
                //#line 66 "x10/lang/PlaceLocalHandle.x10"
                final $T t$135528 = (($T)(((x10.core.fun.Fun_0_0<$T>)this.init).$apply$G()));
                
                //#line 66 "x10/lang/PlaceLocalHandle.x10"
                ((x10.lang.PlaceLocalHandle<$T>)this.handle).set__0x10$lang$PlaceLocalHandle$$T((($T)(t$135528)));
            }}catch (java.lang.Error __lowerer__var__0__) {
                
                //#line 66 "x10/lang/PlaceLocalHandle.x10"
                throw __lowerer__var__0__;
            }catch (java.lang.Throwable __lowerer__var__1__) {
                
                //#line 66 "x10/lang/PlaceLocalHandle.x10"
                throw x10.rtt.Types.EXCEPTION.isInstance(__lowerer__var__1__) ? (java.lang.RuntimeException)(__lowerer__var__1__) : new x10.lang.WrappedThrowable(__lowerer__var__1__);
            }
        }
        
        public x10.core.fun.Fun_0_0<$T> init;
        public x10.lang.PlaceLocalHandle<$T> handle;
        
        public $Closure$171(final x10.rtt.Type $T, final x10.core.fun.Fun_0_0<$T> init, final x10.lang.PlaceLocalHandle<$T> handle, __0$1x10$lang$PlaceLocalHandle$$Closure$171$$T$2__1$1x10$lang$PlaceLocalHandle$$Closure$171$$T$2 $dummy) {
            x10.lang.PlaceLocalHandle.$Closure$171.$initParams(this, $T);
             {
                ((x10.lang.PlaceLocalHandle.$Closure$171<$T>)this).init = ((x10.core.fun.Fun_0_0)(init));
                ((x10.lang.PlaceLocalHandle.$Closure$171<$T>)this).handle = ((x10.lang.PlaceLocalHandle)(handle));
            }
        }
        
    }
    
    @x10.runtime.impl.java.X10Generated
    final public static class $Closure$172<$T> extends x10.core.Ref implements x10.core.fun.VoidFun_0_0, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<$Closure$172> $RTT = 
            x10.rtt.StaticVoidFunType.<$Closure$172> make($Closure$172.class,
                                                          1,
                                                          new x10.rtt.Type[] {
                                                              x10.core.fun.VoidFun_0_0.$RTT
                                                          });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { if (i == 0) return $T; return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static <$T> x10.serialization.X10JavaSerializable $_deserialize_body(x10.lang.PlaceLocalHandle.$Closure$172<$T> $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            $_obj.$T = (x10.rtt.Type) $deserializer.readObject();
            $_obj.handle = $deserializer.readObject();
            $_obj.init = $deserializer.readObject();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.lang.PlaceLocalHandle.$Closure$172 $_obj = new x10.lang.PlaceLocalHandle.$Closure$172((java.lang.System[]) null, (x10.rtt.Type) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            $serializer.write(this.$T);
            $serializer.write(this.handle);
            $serializer.write(this.init);
            
        }
        
        // constructor just for allocation
        public $Closure$172(final java.lang.System[] $dummy, final x10.rtt.Type $T) {
            x10.lang.PlaceLocalHandle.$Closure$172.$initParams(this, $T);
            
        }
        
        private x10.rtt.Type $T;
        
        // initializer of type parameters
        public static void $initParams(final $Closure$172 $this, final x10.rtt.Type $T) {
            $this.$T = $T;
            
        }
        // synthetic type for parameter mangling
        public static final class __0$1x10$lang$PlaceLocalHandle$$Closure$172$$T$2__1$1x10$lang$PlaceLocalHandle$$Closure$172$$T$2 {}
        
    
        
        public void $apply() {
            
            //#line 89 "x10/lang/PlaceLocalHandle.x10"
            try {{
                
                //#line 89 "x10/lang/PlaceLocalHandle.x10"
                final $T t$135534 = (($T)(((x10.core.fun.Fun_0_0<$T>)this.init).$apply$G()));
                
                //#line 89 "x10/lang/PlaceLocalHandle.x10"
                ((x10.lang.PlaceLocalHandle<$T>)this.handle).set__0x10$lang$PlaceLocalHandle$$T((($T)(t$135534)));
            }}catch (java.lang.Error __lowerer__var__0__) {
                
                //#line 89 "x10/lang/PlaceLocalHandle.x10"
                throw __lowerer__var__0__;
            }catch (java.lang.Throwable __lowerer__var__1__) {
                
                //#line 89 "x10/lang/PlaceLocalHandle.x10"
                throw x10.rtt.Types.EXCEPTION.isInstance(__lowerer__var__1__) ? (java.lang.RuntimeException)(__lowerer__var__1__) : new x10.lang.WrappedThrowable(__lowerer__var__1__);
            }
        }
        
        public x10.core.fun.Fun_0_0<$T> init;
        public x10.lang.PlaceLocalHandle<$T> handle;
        
        public $Closure$172(final x10.rtt.Type $T, final x10.core.fun.Fun_0_0<$T> init, final x10.lang.PlaceLocalHandle<$T> handle, __0$1x10$lang$PlaceLocalHandle$$Closure$172$$T$2__1$1x10$lang$PlaceLocalHandle$$Closure$172$$T$2 $dummy) {
            x10.lang.PlaceLocalHandle.$Closure$172.$initParams(this, $T);
             {
                ((x10.lang.PlaceLocalHandle.$Closure$172<$T>)this).init = ((x10.core.fun.Fun_0_0)(init));
                ((x10.lang.PlaceLocalHandle.$Closure$172<$T>)this).handle = ((x10.lang.PlaceLocalHandle)(handle));
            }
        }
        
    }
    
    @x10.runtime.impl.java.X10Generated
    final public static class $Closure$173<$T, $U> extends x10.core.Ref implements x10.core.fun.VoidFun_0_0, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<$Closure$173> $RTT = 
            x10.rtt.StaticVoidFunType.<$Closure$173> make($Closure$173.class,
                                                          2,
                                                          new x10.rtt.Type[] {
                                                              x10.core.fun.VoidFun_0_0.$RTT
                                                          });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { if (i == 0) return $T; if (i == 1) return $U; return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static <$T, $U> x10.serialization.X10JavaSerializable $_deserialize_body(x10.lang.PlaceLocalHandle.$Closure$173<$T, $U> $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            $_obj.$T = (x10.rtt.Type) $deserializer.readObject();
            $_obj.$U = (x10.rtt.Type) $deserializer.readObject();
            $_obj.handle = $deserializer.readObject();
            $_obj.init_there = $deserializer.readObject();
            $_obj.v$135536 = $deserializer.readObject();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.lang.PlaceLocalHandle.$Closure$173 $_obj = new x10.lang.PlaceLocalHandle.$Closure$173((java.lang.System[]) null, (x10.rtt.Type) null, (x10.rtt.Type) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            $serializer.write(this.$T);
            $serializer.write(this.$U);
            $serializer.write(this.handle);
            $serializer.write(this.init_there);
            $serializer.write(this.v$135536);
            
        }
        
        // constructor just for allocation
        public $Closure$173(final java.lang.System[] $dummy, final x10.rtt.Type $T, final x10.rtt.Type $U) {
            x10.lang.PlaceLocalHandle.$Closure$173.$initParams(this, $T, $U);
            
        }
        
        private x10.rtt.Type $T;
        private x10.rtt.Type $U;
        
        // initializer of type parameters
        public static void $initParams(final $Closure$173 $this, final x10.rtt.Type $T, final x10.rtt.Type $U) {
            $this.$T = $T;
            $this.$U = $U;
            
        }
        // synthetic type for parameter mangling
        public static final class __0$1x10$lang$PlaceLocalHandle$$Closure$173$$U$3x10$lang$PlaceLocalHandle$$Closure$173$$T$2__1x10$lang$PlaceLocalHandle$$Closure$173$$U__2$1x10$lang$PlaceLocalHandle$$Closure$173$$T$2 {}
        
    
        
        public void $apply() {
            
            //#line 113 "x10/lang/PlaceLocalHandle.x10"
            try {{
                
                //#line 113 "x10/lang/PlaceLocalHandle.x10"
                final $T t$135537 = (($T)((($T)
                                            ((x10.core.fun.Fun_0_1<$U,$T>)this.init_there).$apply(this.v$135536, $U))));
                
                //#line 113 "x10/lang/PlaceLocalHandle.x10"
                ((x10.lang.PlaceLocalHandle<$T>)this.handle).set__0x10$lang$PlaceLocalHandle$$T((($T)(t$135537)));
            }}catch (java.lang.Error __lowerer__var__0__) {
                
                //#line 113 "x10/lang/PlaceLocalHandle.x10"
                throw __lowerer__var__0__;
            }catch (java.lang.Throwable __lowerer__var__1__) {
                
                //#line 113 "x10/lang/PlaceLocalHandle.x10"
                throw x10.rtt.Types.EXCEPTION.isInstance(__lowerer__var__1__) ? (java.lang.RuntimeException)(__lowerer__var__1__) : new x10.lang.WrappedThrowable(__lowerer__var__1__);
            }
        }
        
        public x10.core.fun.Fun_0_1<$U,$T> init_there;
        public $U v$135536;
        public x10.lang.PlaceLocalHandle<$T> handle;
        
        public $Closure$173(final x10.rtt.Type $T, final x10.rtt.Type $U, final x10.core.fun.Fun_0_1<$U,$T> init_there, final $U v$135536, final x10.lang.PlaceLocalHandle<$T> handle, __0$1x10$lang$PlaceLocalHandle$$Closure$173$$U$3x10$lang$PlaceLocalHandle$$Closure$173$$T$2__1x10$lang$PlaceLocalHandle$$Closure$173$$U__2$1x10$lang$PlaceLocalHandle$$Closure$173$$T$2 $dummy) {
            x10.lang.PlaceLocalHandle.$Closure$173.$initParams(this, $T, $U);
             {
                ((x10.lang.PlaceLocalHandle.$Closure$173<$T, $U>)this).init_there = ((x10.core.fun.Fun_0_1)(init_there));
                ((x10.lang.PlaceLocalHandle.$Closure$173<$T, $U>)this).v$135536 = (($U)(v$135536));
                ((x10.lang.PlaceLocalHandle.$Closure$173<$T, $U>)this).handle = ((x10.lang.PlaceLocalHandle)(handle));
            }
        }
        
    }
    
    @x10.runtime.impl.java.X10Generated
    final public static class $Closure$174<$T, $U> extends x10.core.Ref implements x10.core.fun.VoidFun_0_0, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<$Closure$174> $RTT = 
            x10.rtt.StaticVoidFunType.<$Closure$174> make($Closure$174.class,
                                                          2,
                                                          new x10.rtt.Type[] {
                                                              x10.core.fun.VoidFun_0_0.$RTT
                                                          });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { if (i == 0) return $T; if (i == 1) return $U; return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static <$T, $U> x10.serialization.X10JavaSerializable $_deserialize_body(x10.lang.PlaceLocalHandle.$Closure$174<$T, $U> $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            $_obj.$T = (x10.rtt.Type) $deserializer.readObject();
            $_obj.$U = (x10.rtt.Type) $deserializer.readObject();
            $_obj.handle = $deserializer.readObject();
            $_obj.init_there = $deserializer.readObject();
            $_obj.v$135539 = $deserializer.readObject();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.lang.PlaceLocalHandle.$Closure$174 $_obj = new x10.lang.PlaceLocalHandle.$Closure$174((java.lang.System[]) null, (x10.rtt.Type) null, (x10.rtt.Type) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            $serializer.write(this.$T);
            $serializer.write(this.$U);
            $serializer.write(this.handle);
            $serializer.write(this.init_there);
            $serializer.write(this.v$135539);
            
        }
        
        // constructor just for allocation
        public $Closure$174(final java.lang.System[] $dummy, final x10.rtt.Type $T, final x10.rtt.Type $U) {
            x10.lang.PlaceLocalHandle.$Closure$174.$initParams(this, $T, $U);
            
        }
        
        private x10.rtt.Type $T;
        private x10.rtt.Type $U;
        
        // initializer of type parameters
        public static void $initParams(final $Closure$174 $this, final x10.rtt.Type $T, final x10.rtt.Type $U) {
            $this.$T = $T;
            $this.$U = $U;
            
        }
        // synthetic type for parameter mangling
        public static final class __0$1x10$lang$PlaceLocalHandle$$Closure$174$$U$3x10$lang$PlaceLocalHandle$$Closure$174$$T$2__1x10$lang$PlaceLocalHandle$$Closure$174$$U__2$1x10$lang$PlaceLocalHandle$$Closure$174$$T$2 {}
        
    
        
        public void $apply() {
            
            //#line 140 "x10/lang/PlaceLocalHandle.x10"
            try {{
                
                //#line 140 "x10/lang/PlaceLocalHandle.x10"
                final $T t$135544 = (($T)((($T)
                                            ((x10.core.fun.Fun_0_1<$U,$T>)this.init_there).$apply(this.v$135539, $U))));
                
                //#line 140 "x10/lang/PlaceLocalHandle.x10"
                ((x10.lang.PlaceLocalHandle<$T>)this.handle).set__0x10$lang$PlaceLocalHandle$$T((($T)(t$135544)));
            }}catch (java.lang.Error __lowerer__var__0__) {
                
                //#line 140 "x10/lang/PlaceLocalHandle.x10"
                throw __lowerer__var__0__;
            }catch (java.lang.Throwable __lowerer__var__1__) {
                
                //#line 140 "x10/lang/PlaceLocalHandle.x10"
                throw x10.rtt.Types.EXCEPTION.isInstance(__lowerer__var__1__) ? (java.lang.RuntimeException)(__lowerer__var__1__) : new x10.lang.WrappedThrowable(__lowerer__var__1__);
            }
        }
        
        public x10.core.fun.Fun_0_1<$U,$T> init_there;
        public $U v$135539;
        public x10.lang.PlaceLocalHandle<$T> handle;
        
        public $Closure$174(final x10.rtt.Type $T, final x10.rtt.Type $U, final x10.core.fun.Fun_0_1<$U,$T> init_there, final $U v$135539, final x10.lang.PlaceLocalHandle<$T> handle, __0$1x10$lang$PlaceLocalHandle$$Closure$174$$U$3x10$lang$PlaceLocalHandle$$Closure$174$$T$2__1x10$lang$PlaceLocalHandle$$Closure$174$$U__2$1x10$lang$PlaceLocalHandle$$Closure$174$$T$2 $dummy) {
            x10.lang.PlaceLocalHandle.$Closure$174.$initParams(this, $T, $U);
             {
                ((x10.lang.PlaceLocalHandle.$Closure$174<$T, $U>)this).init_there = ((x10.core.fun.Fun_0_1)(init_there));
                ((x10.lang.PlaceLocalHandle.$Closure$174<$T, $U>)this).v$135539 = (($U)(v$135539));
                ((x10.lang.PlaceLocalHandle.$Closure$174<$T, $U>)this).handle = ((x10.lang.PlaceLocalHandle)(handle));
            }
        }
        
    }
    
    @x10.runtime.impl.java.X10Generated
    final public static class $Closure$175<$T> extends x10.core.Ref implements x10.core.fun.VoidFun_0_0, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<$Closure$175> $RTT = 
            x10.rtt.StaticVoidFunType.<$Closure$175> make($Closure$175.class,
                                                          1,
                                                          new x10.rtt.Type[] {
                                                              x10.core.fun.VoidFun_0_0.$RTT
                                                          });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { if (i == 0) return $T; return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static <$T> x10.serialization.X10JavaSerializable $_deserialize_body(x10.lang.PlaceLocalHandle.$Closure$175<$T> $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            $_obj.$T = (x10.rtt.Type) $deserializer.readObject();
            $_obj.handle = $deserializer.readObject();
            $_obj.init = $deserializer.readObject();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.lang.PlaceLocalHandle.$Closure$175 $_obj = new x10.lang.PlaceLocalHandle.$Closure$175((java.lang.System[]) null, (x10.rtt.Type) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            $serializer.write(this.$T);
            $serializer.write(this.handle);
            $serializer.write(this.init);
            
        }
        
        // constructor just for allocation
        public $Closure$175(final java.lang.System[] $dummy, final x10.rtt.Type $T) {
            x10.lang.PlaceLocalHandle.$Closure$175.$initParams(this, $T);
            
        }
        
        private x10.rtt.Type $T;
        
        // initializer of type parameters
        public static void $initParams(final $Closure$175 $this, final x10.rtt.Type $T) {
            $this.$T = $T;
            
        }
        // synthetic type for parameter mangling
        public static final class __0$1x10$lang$PlaceLocalHandle$$Closure$175$$T$2__1$1x10$lang$PlaceLocalHandle$$Closure$175$$T$2 {}
        
    
        
        public void $apply() {
            
            //#line 166 "x10/lang/PlaceLocalHandle.x10"
            final $T t$135496 = (($T)(((x10.core.fun.Fun_0_0<$T>)this.init).$apply$G()));
            
            //#line 166 "x10/lang/PlaceLocalHandle.x10"
            ((x10.lang.PlaceLocalHandle<$T>)this.handle).set__0x10$lang$PlaceLocalHandle$$T((($T)(t$135496)));
        }
        
        public x10.core.fun.Fun_0_0<$T> init;
        public x10.lang.PlaceLocalHandle<$T> handle;
        
        public $Closure$175(final x10.rtt.Type $T, final x10.core.fun.Fun_0_0<$T> init, final x10.lang.PlaceLocalHandle<$T> handle, __0$1x10$lang$PlaceLocalHandle$$Closure$175$$T$2__1$1x10$lang$PlaceLocalHandle$$Closure$175$$T$2 $dummy) {
            x10.lang.PlaceLocalHandle.$Closure$175.$initParams(this, $T);
             {
                ((x10.lang.PlaceLocalHandle.$Closure$175<$T>)this).init = ((x10.core.fun.Fun_0_0)(init));
                ((x10.lang.PlaceLocalHandle.$Closure$175<$T>)this).handle = ((x10.lang.PlaceLocalHandle)(handle));
            }
        }
        
    }
    
    @x10.runtime.impl.java.X10Generated
    final public static class $Closure$176<$T> extends x10.core.Ref implements x10.core.fun.VoidFun_0_0, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<$Closure$176> $RTT = 
            x10.rtt.StaticVoidFunType.<$Closure$176> make($Closure$176.class,
                                                          1,
                                                          new x10.rtt.Type[] {
                                                              x10.core.fun.VoidFun_0_0.$RTT
                                                          });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { if (i == 0) return $T; return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static <$T> x10.serialization.X10JavaSerializable $_deserialize_body(x10.lang.PlaceLocalHandle.$Closure$176<$T> $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            $_obj.$T = (x10.rtt.Type) $deserializer.readObject();
            $_obj.handle = $deserializer.readObject();
            $_obj.init = $deserializer.readObject();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.lang.PlaceLocalHandle.$Closure$176 $_obj = new x10.lang.PlaceLocalHandle.$Closure$176((java.lang.System[]) null, (x10.rtt.Type) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            $serializer.write(this.$T);
            $serializer.write(this.handle);
            $serializer.write(this.init);
            
        }
        
        // constructor just for allocation
        public $Closure$176(final java.lang.System[] $dummy, final x10.rtt.Type $T) {
            x10.lang.PlaceLocalHandle.$Closure$176.$initParams(this, $T);
            
        }
        
        private x10.rtt.Type $T;
        
        // initializer of type parameters
        public static void $initParams(final $Closure$176 $this, final x10.rtt.Type $T) {
            $this.$T = $T;
            
        }
        // synthetic type for parameter mangling
        public static final class __0$1x10$lang$PlaceLocalHandle$$Closure$176$$T$2__1$1x10$lang$PlaceLocalHandle$$Closure$176$$T$2 {}
        
    
        
        public void $apply() {
            
            //#line 189 "x10/lang/PlaceLocalHandle.x10"
            final $T t$135498 = (($T)(((x10.core.fun.Fun_0_0<$T>)this.init).$apply$G()));
            
            //#line 189 "x10/lang/PlaceLocalHandle.x10"
            ((x10.lang.PlaceLocalHandle<$T>)this.handle).set__0x10$lang$PlaceLocalHandle$$T((($T)(t$135498)));
        }
        
        public x10.core.fun.Fun_0_0<$T> init;
        public x10.lang.PlaceLocalHandle<$T> handle;
        
        public $Closure$176(final x10.rtt.Type $T, final x10.core.fun.Fun_0_0<$T> init, final x10.lang.PlaceLocalHandle<$T> handle, __0$1x10$lang$PlaceLocalHandle$$Closure$176$$T$2__1$1x10$lang$PlaceLocalHandle$$Closure$176$$T$2 $dummy) {
            x10.lang.PlaceLocalHandle.$Closure$176.$initParams(this, $T);
             {
                ((x10.lang.PlaceLocalHandle.$Closure$176<$T>)this).init = ((x10.core.fun.Fun_0_0)(init));
                ((x10.lang.PlaceLocalHandle.$Closure$176<$T>)this).handle = ((x10.lang.PlaceLocalHandle)(handle));
            }
        }
        
    }
    
    @x10.runtime.impl.java.X10Generated
    final public static class $Closure$177<$T, $U> extends x10.core.Ref implements x10.core.fun.VoidFun_0_0, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<$Closure$177> $RTT = 
            x10.rtt.StaticVoidFunType.<$Closure$177> make($Closure$177.class,
                                                          2,
                                                          new x10.rtt.Type[] {
                                                              x10.core.fun.VoidFun_0_0.$RTT
                                                          });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { if (i == 0) return $T; if (i == 1) return $U; return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static <$T, $U> x10.serialization.X10JavaSerializable $_deserialize_body(x10.lang.PlaceLocalHandle.$Closure$177<$T, $U> $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            $_obj.$T = (x10.rtt.Type) $deserializer.readObject();
            $_obj.$U = (x10.rtt.Type) $deserializer.readObject();
            $_obj.handle = $deserializer.readObject();
            $_obj.init_there = $deserializer.readObject();
            $_obj.v$135546 = $deserializer.readObject();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.lang.PlaceLocalHandle.$Closure$177 $_obj = new x10.lang.PlaceLocalHandle.$Closure$177((java.lang.System[]) null, (x10.rtt.Type) null, (x10.rtt.Type) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            $serializer.write(this.$T);
            $serializer.write(this.$U);
            $serializer.write(this.handle);
            $serializer.write(this.init_there);
            $serializer.write(this.v$135546);
            
        }
        
        // constructor just for allocation
        public $Closure$177(final java.lang.System[] $dummy, final x10.rtt.Type $T, final x10.rtt.Type $U) {
            x10.lang.PlaceLocalHandle.$Closure$177.$initParams(this, $T, $U);
            
        }
        
        private x10.rtt.Type $T;
        private x10.rtt.Type $U;
        
        // initializer of type parameters
        public static void $initParams(final $Closure$177 $this, final x10.rtt.Type $T, final x10.rtt.Type $U) {
            $this.$T = $T;
            $this.$U = $U;
            
        }
        // synthetic type for parameter mangling
        public static final class __0$1x10$lang$PlaceLocalHandle$$Closure$177$$U$3x10$lang$PlaceLocalHandle$$Closure$177$$T$2__1x10$lang$PlaceLocalHandle$$Closure$177$$U__2$1x10$lang$PlaceLocalHandle$$Closure$177$$T$2 {}
        
    
        
        public void $apply() {
            
            //#line 214 "x10/lang/PlaceLocalHandle.x10"
            try {{
                
                //#line 214 "x10/lang/PlaceLocalHandle.x10"
                final $T t$135547 = (($T)((($T)
                                            ((x10.core.fun.Fun_0_1<$U,$T>)this.init_there).$apply(this.v$135546, $U))));
                
                //#line 214 "x10/lang/PlaceLocalHandle.x10"
                ((x10.lang.PlaceLocalHandle<$T>)this.handle).set__0x10$lang$PlaceLocalHandle$$T((($T)(t$135547)));
            }}catch (java.lang.Error __lowerer__var__0__) {
                
                //#line 214 "x10/lang/PlaceLocalHandle.x10"
                throw __lowerer__var__0__;
            }catch (java.lang.Throwable __lowerer__var__1__) {
                
                //#line 214 "x10/lang/PlaceLocalHandle.x10"
                throw x10.rtt.Types.EXCEPTION.isInstance(__lowerer__var__1__) ? (java.lang.RuntimeException)(__lowerer__var__1__) : new x10.lang.WrappedThrowable(__lowerer__var__1__);
            }
        }
        
        public x10.core.fun.Fun_0_1<$U,$T> init_there;
        public $U v$135546;
        public x10.lang.PlaceLocalHandle<$T> handle;
        
        public $Closure$177(final x10.rtt.Type $T, final x10.rtt.Type $U, final x10.core.fun.Fun_0_1<$U,$T> init_there, final $U v$135546, final x10.lang.PlaceLocalHandle<$T> handle, __0$1x10$lang$PlaceLocalHandle$$Closure$177$$U$3x10$lang$PlaceLocalHandle$$Closure$177$$T$2__1x10$lang$PlaceLocalHandle$$Closure$177$$U__2$1x10$lang$PlaceLocalHandle$$Closure$177$$T$2 $dummy) {
            x10.lang.PlaceLocalHandle.$Closure$177.$initParams(this, $T, $U);
             {
                ((x10.lang.PlaceLocalHandle.$Closure$177<$T, $U>)this).init_there = ((x10.core.fun.Fun_0_1)(init_there));
                ((x10.lang.PlaceLocalHandle.$Closure$177<$T, $U>)this).v$135546 = (($U)(v$135546));
                ((x10.lang.PlaceLocalHandle.$Closure$177<$T, $U>)this).handle = ((x10.lang.PlaceLocalHandle)(handle));
            }
        }
        
    }
    
    @x10.runtime.impl.java.X10Generated
    final public static class $Closure$178<$T, $U> extends x10.core.Ref implements x10.core.fun.VoidFun_0_0, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<$Closure$178> $RTT = 
            x10.rtt.StaticVoidFunType.<$Closure$178> make($Closure$178.class,
                                                          2,
                                                          new x10.rtt.Type[] {
                                                              x10.core.fun.VoidFun_0_0.$RTT
                                                          });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { if (i == 0) return $T; if (i == 1) return $U; return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static <$T, $U> x10.serialization.X10JavaSerializable $_deserialize_body(x10.lang.PlaceLocalHandle.$Closure$178<$T, $U> $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            $_obj.$T = (x10.rtt.Type) $deserializer.readObject();
            $_obj.$U = (x10.rtt.Type) $deserializer.readObject();
            $_obj.handle = $deserializer.readObject();
            $_obj.init_there = $deserializer.readObject();
            $_obj.v$135549 = $deserializer.readObject();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.lang.PlaceLocalHandle.$Closure$178 $_obj = new x10.lang.PlaceLocalHandle.$Closure$178((java.lang.System[]) null, (x10.rtt.Type) null, (x10.rtt.Type) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            $serializer.write(this.$T);
            $serializer.write(this.$U);
            $serializer.write(this.handle);
            $serializer.write(this.init_there);
            $serializer.write(this.v$135549);
            
        }
        
        // constructor just for allocation
        public $Closure$178(final java.lang.System[] $dummy, final x10.rtt.Type $T, final x10.rtt.Type $U) {
            x10.lang.PlaceLocalHandle.$Closure$178.$initParams(this, $T, $U);
            
        }
        
        private x10.rtt.Type $T;
        private x10.rtt.Type $U;
        
        // initializer of type parameters
        public static void $initParams(final $Closure$178 $this, final x10.rtt.Type $T, final x10.rtt.Type $U) {
            $this.$T = $T;
            $this.$U = $U;
            
        }
        // synthetic type for parameter mangling
        public static final class __0$1x10$lang$PlaceLocalHandle$$Closure$178$$U$3x10$lang$PlaceLocalHandle$$Closure$178$$T$2__1x10$lang$PlaceLocalHandle$$Closure$178$$U__2$1x10$lang$PlaceLocalHandle$$Closure$178$$T$2 {}
        
    
        
        public void $apply() {
            
            //#line 244 "x10/lang/PlaceLocalHandle.x10"
            try {{
                
                //#line 244 "x10/lang/PlaceLocalHandle.x10"
                final $T t$135554 = (($T)((($T)
                                            ((x10.core.fun.Fun_0_1<$U,$T>)this.init_there).$apply(this.v$135549, $U))));
                
                //#line 244 "x10/lang/PlaceLocalHandle.x10"
                ((x10.lang.PlaceLocalHandle<$T>)this.handle).set__0x10$lang$PlaceLocalHandle$$T((($T)(t$135554)));
            }}catch (java.lang.Error __lowerer__var__0__) {
                
                //#line 244 "x10/lang/PlaceLocalHandle.x10"
                throw __lowerer__var__0__;
            }catch (java.lang.Throwable __lowerer__var__1__) {
                
                //#line 244 "x10/lang/PlaceLocalHandle.x10"
                throw x10.rtt.Types.EXCEPTION.isInstance(__lowerer__var__1__) ? (java.lang.RuntimeException)(__lowerer__var__1__) : new x10.lang.WrappedThrowable(__lowerer__var__1__);
            }
        }
        
        public x10.core.fun.Fun_0_1<$U,$T> init_there;
        public $U v$135549;
        public x10.lang.PlaceLocalHandle<$T> handle;
        
        public $Closure$178(final x10.rtt.Type $T, final x10.rtt.Type $U, final x10.core.fun.Fun_0_1<$U,$T> init_there, final $U v$135549, final x10.lang.PlaceLocalHandle<$T> handle, __0$1x10$lang$PlaceLocalHandle$$Closure$178$$U$3x10$lang$PlaceLocalHandle$$Closure$178$$T$2__1x10$lang$PlaceLocalHandle$$Closure$178$$U__2$1x10$lang$PlaceLocalHandle$$Closure$178$$T$2 $dummy) {
            x10.lang.PlaceLocalHandle.$Closure$178.$initParams(this, $T, $U);
             {
                ((x10.lang.PlaceLocalHandle.$Closure$178<$T, $U>)this).init_there = ((x10.core.fun.Fun_0_1)(init_there));
                ((x10.lang.PlaceLocalHandle.$Closure$178<$T, $U>)this).v$135549 = (($U)(v$135549));
                ((x10.lang.PlaceLocalHandle.$Closure$178<$T, $U>)this).handle = ((x10.lang.PlaceLocalHandle)(handle));
            }
        }
        
    }
    
    @x10.runtime.impl.java.X10Generated
    final public static class $Closure$179<$T> extends x10.core.Ref implements x10.core.fun.VoidFun_0_0, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<$Closure$179> $RTT = 
            x10.rtt.StaticVoidFunType.<$Closure$179> make($Closure$179.class,
                                                          1,
                                                          new x10.rtt.Type[] {
                                                              x10.core.fun.VoidFun_0_0.$RTT
                                                          });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { if (i == 0) return $T; return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static <$T> x10.serialization.X10JavaSerializable $_deserialize_body(x10.lang.PlaceLocalHandle.$Closure$179<$T> $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            $_obj.$T = (x10.rtt.Type) $deserializer.readObject();
            $_obj.init = $deserializer.readObject();
            $_obj.plh = $deserializer.readObject();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.lang.PlaceLocalHandle.$Closure$179 $_obj = new x10.lang.PlaceLocalHandle.$Closure$179((java.lang.System[]) null, (x10.rtt.Type) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            $serializer.write(this.$T);
            $serializer.write(this.init);
            $serializer.write(this.plh);
            
        }
        
        // constructor just for allocation
        public $Closure$179(final java.lang.System[] $dummy, final x10.rtt.Type $T) {
            x10.lang.PlaceLocalHandle.$Closure$179.$initParams(this, $T);
            
        }
        
        private x10.rtt.Type $T;
        
        // initializer of type parameters
        public static void $initParams(final $Closure$179 $this, final x10.rtt.Type $T) {
            $this.$T = $T;
            
        }
        // synthetic type for parameter mangling
        public static final class __0$1x10$lang$PlaceLocalHandle$$Closure$179$$T$2__1$1x10$lang$PlaceLocalHandle$$Closure$179$$T$2 {}
        
    
        
        public void $apply() {
            
            //#line 261 "x10/lang/PlaceLocalHandle.x10"
            try {{
                
                //#line 261 "x10/lang/PlaceLocalHandle.x10"
                final $T t$135510 = (($T)(((x10.core.fun.Fun_0_0<$T>)this.init).$apply$G()));
                
                //#line 261 "x10/lang/PlaceLocalHandle.x10"
                ((x10.lang.PlaceLocalHandle<$T>)this.plh).set__0x10$lang$PlaceLocalHandle$$T((($T)(t$135510)));
            }}catch (java.lang.Throwable __lowerer__var__0__) {
                
                //#line 261 "x10/lang/PlaceLocalHandle.x10"
                int __lowerer__var__1__ = (x10.core.Int.$unbox(x10.xrx.Runtime.<x10.core.Int> wrapAtChecked$G(x10.rtt.Types.INT, ((java.lang.Throwable)(__lowerer__var__0__)))));
            }
        }
        
        public x10.core.fun.Fun_0_0<$T> init;
        public x10.lang.PlaceLocalHandle<$T> plh;
        
        public $Closure$179(final x10.rtt.Type $T, final x10.core.fun.Fun_0_0<$T> init, final x10.lang.PlaceLocalHandle<$T> plh, __0$1x10$lang$PlaceLocalHandle$$Closure$179$$T$2__1$1x10$lang$PlaceLocalHandle$$Closure$179$$T$2 $dummy) {
            x10.lang.PlaceLocalHandle.$Closure$179.$initParams(this, $T);
             {
                ((x10.lang.PlaceLocalHandle.$Closure$179<$T>)this).init = ((x10.core.fun.Fun_0_0)(init));
                ((x10.lang.PlaceLocalHandle.$Closure$179<$T>)this).plh = ((x10.lang.PlaceLocalHandle)(plh));
            }
        }
        
    }
    
    @x10.runtime.impl.java.X10Generated
    final public static class $Closure$180<$T> extends x10.core.Ref implements x10.core.fun.VoidFun_0_0, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<$Closure$180> $RTT = 
            x10.rtt.StaticVoidFunType.<$Closure$180> make($Closure$180.class,
                                                          1,
                                                          new x10.rtt.Type[] {
                                                              x10.core.fun.VoidFun_0_0.$RTT
                                                          });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { if (i == 0) return $T; return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static <$T> x10.serialization.X10JavaSerializable $_deserialize_body(x10.lang.PlaceLocalHandle.$Closure$180<$T> $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            $_obj.$T = (x10.rtt.Type) $deserializer.readObject();
            $_obj.plh = $deserializer.readObject();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.lang.PlaceLocalHandle.$Closure$180 $_obj = new x10.lang.PlaceLocalHandle.$Closure$180((java.lang.System[]) null, (x10.rtt.Type) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            $serializer.write(this.$T);
            $serializer.write(this.plh);
            
        }
        
        // constructor just for allocation
        public $Closure$180(final java.lang.System[] $dummy, final x10.rtt.Type $T) {
            x10.lang.PlaceLocalHandle.$Closure$180.$initParams(this, $T);
            
        }
        
        private x10.rtt.Type $T;
        
        // initializer of type parameters
        public static void $initParams(final $Closure$180 $this, final x10.rtt.Type $T) {
            $this.$T = $T;
            
        }
        // synthetic type for parameter mangling
        public static final class __0$1x10$lang$PlaceLocalHandle$$Closure$180$$T$2 {}
        
    
        
        public void $apply() {
            
            //#line 270 "x10/lang/PlaceLocalHandle.x10"
            ((x10.lang.PlaceLocalHandle<$T>)this.plh).set__0x10$lang$PlaceLocalHandle$$T((($T)(null)));
        }
        
        public x10.lang.PlaceLocalHandle<$T> plh;
        
        public $Closure$180(final x10.rtt.Type $T, final x10.lang.PlaceLocalHandle<$T> plh, __0$1x10$lang$PlaceLocalHandle$$Closure$180$$T$2 $dummy) {
            x10.lang.PlaceLocalHandle.$Closure$180.$initParams(this, $T);
             {
                ((x10.lang.PlaceLocalHandle.$Closure$180<$T>)this).plh = ((x10.lang.PlaceLocalHandle)(plh));
            }
        }
        
    }
    
    @x10.runtime.impl.java.X10Generated
    final public static class $Closure$181<$T> extends x10.core.Ref implements x10.core.fun.VoidFun_0_0, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<$Closure$181> $RTT = 
            x10.rtt.StaticVoidFunType.<$Closure$181> make($Closure$181.class,
                                                          1,
                                                          new x10.rtt.Type[] {
                                                              x10.core.fun.VoidFun_0_0.$RTT
                                                          });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { if (i == 0) return $T; return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static <$T> x10.serialization.X10JavaSerializable $_deserialize_body(x10.lang.PlaceLocalHandle.$Closure$181<$T> $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            $_obj.$T = (x10.rtt.Type) $deserializer.readObject();
            $_obj.plh = $deserializer.readObject();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.lang.PlaceLocalHandle.$Closure$181 $_obj = new x10.lang.PlaceLocalHandle.$Closure$181((java.lang.System[]) null, (x10.rtt.Type) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            $serializer.write(this.$T);
            $serializer.write(this.plh);
            
        }
        
        // constructor just for allocation
        public $Closure$181(final java.lang.System[] $dummy, final x10.rtt.Type $T) {
            x10.lang.PlaceLocalHandle.$Closure$181.$initParams(this, $T);
            
        }
        
        private x10.rtt.Type $T;
        
        // initializer of type parameters
        public static void $initParams(final $Closure$181 $this, final x10.rtt.Type $T) {
            $this.$T = $T;
            
        }
        // synthetic type for parameter mangling
        public static final class __0$1x10$lang$PlaceLocalHandle$$Closure$181$$T$2 {}
        
    
        
        public void $apply() {
            
            //#line 280 "x10/lang/PlaceLocalHandle.x10"
            ((x10.lang.PlaceLocalHandle<$T>)this.plh).set__0x10$lang$PlaceLocalHandle$$T((($T)(null)));
        }
        
        public x10.lang.PlaceLocalHandle<$T> plh;
        
        public $Closure$181(final x10.rtt.Type $T, final x10.lang.PlaceLocalHandle<$T> plh, __0$1x10$lang$PlaceLocalHandle$$Closure$181$$T$2 $dummy) {
            x10.lang.PlaceLocalHandle.$Closure$181.$initParams(this, $T);
             {
                ((x10.lang.PlaceLocalHandle.$Closure$181<$T>)this).plh = ((x10.lang.PlaceLocalHandle)(plh));
            }
        }
        
    }
    
    }
    
    