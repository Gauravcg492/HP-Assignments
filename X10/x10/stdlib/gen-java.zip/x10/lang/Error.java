package x10.lang;


/**
 * An Error is a subclass of Throwable that indicates serious problems that a reasonable
 * application should not try to catch.  Most such errors are abnormal conditions.
 * For example, an {@link x10.lang.OutOfMemoryError} represents such an condition.
 *
 * A method is not required to declare in its throws clause any subclasses of Error that
 * might be thrown during the execution of the method but not caught, since these errors
 * are abnormal conditions that should never occur.
 */
;

