package x10.lang;


/**
 * A representation of the range of integers [min..max].
 */
@x10.runtime.impl.java.X10Generated
public class IntRange extends x10.core.Struct implements x10.lang.Iterable, x10.serialization.X10JavaSerializable
{
    public static final x10.rtt.RuntimeType<IntRange> $RTT = 
        x10.rtt.NamedStructType.<IntRange> make("x10.lang.IntRange",
                                                IntRange.class,
                                                new x10.rtt.Type[] {
                                                    x10.rtt.ParameterizedType.make(x10.lang.Iterable.$RTT, x10.rtt.Types.INT),
                                                    x10.rtt.Types.STRUCT
                                                });
    
    public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
    
    public x10.rtt.Type<?> $getParam(int i) { return null; }
    
    private Object writeReplace() throws java.io.ObjectStreamException {
        return new x10.serialization.SerializationProxy(this);
    }
    
    public static x10.serialization.X10JavaSerializable $_deserialize_body(x10.lang.IntRange $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
        $_obj.max = $deserializer.readInt();
        $_obj.min = $deserializer.readInt();
        return $_obj;
    }
    
    public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
        x10.lang.IntRange $_obj = new x10.lang.IntRange((java.lang.System[]) null);
        return $_deserialize_body($_obj, $deserializer);
    }
    
    public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
        $serializer.write(this.max);
        $serializer.write(this.min);
        
    }
    
    // zero value constructor
    public IntRange(final java.lang.System $dummy) { this.min = 0; this.max = 0; }
    
    // constructor just for allocation
    public IntRange(final java.lang.System[] $dummy) {
        
    }
    
    
    // properties
    
    //#line 23 "x10/lang/IntRange.x10"
    /**
                * The minimum value included in the range
                */
    public int min;
    
    //#line 28 "x10/lang/IntRange.x10"
    /**
                * The maximum value included in the range
                */
    public int max;
    

    
    
    //#line 36 "x10/lang/IntRange.x10"
    /**
     * Construct a IntRange from min..max
     * @param min the minimum value of the range
     * @param max the maximum value of the range
     */
    // creation method for java code (1-phase java constructor)
    public IntRange(final int min, final int max) {
        this((java.lang.System[]) null);
        x10$lang$IntRange$$init$S(min, max);
    }
    
    // constructor for non-virtual call
    final public x10.lang.IntRange x10$lang$IntRange$$init$S(final int min, final int max) {
         {
            
            //#line 37 "x10/lang/IntRange.x10"
            this.min = min;
            this.max = max;
            
        }
        return this;
    }
    
    
    
    //#line 45 "x10/lang/IntRange.x10"
    /**
     * Convert a given LongRange to an IntRange.
     * @param x the given LongRange
     * @return the given LongRange converted to an IntRange.
     */
    final public static x10.lang.IntRange $convert(final x10.lang.LongRange x) {
        
        //#line 45 "x10/lang/IntRange.x10"
        final x10.lang.IntRange alloc$133714 = ((x10.lang.IntRange)(new x10.lang.IntRange((java.lang.System[]) null)));
        
        //#line 45 "x10/lang/IntRange.x10"
        final long t$133734 = x.min;
        
        //#line 45 "x10/lang/IntRange.x10"
        final int min$133720 = ((int)(long)(((long)(t$133734))));
        
        //#line 45 "x10/lang/IntRange.x10"
        final long t$133735 = x.max;
        
        //#line 45 "x10/lang/IntRange.x10"
        final int max$133721 = ((int)(long)(((long)(t$133735))));
        
        //#line 37 . "x10/lang/IntRange.x10"
        alloc$133714.min = min$133720;
        
        //#line 37 . "x10/lang/IntRange.x10"
        alloc$133714.max = max$133721;
        
        //#line 45 "x10/lang/IntRange.x10"
        return alloc$133714;
    }
    
    
    //#line 52 "x10/lang/IntRange.x10"
    /**
     * Split the IntRange into N IntRanges that
     * collectively represent the same set of Ints as this.
     * @see x10.array.BlockUtils.partitionBlock
     */
    final public x10.core.Rail split(final int n) {
        
        //#line 53 "x10/lang/IntRange.x10"
        final int t$133736 = this.max;
        
        //#line 53 "x10/lang/IntRange.x10"
        final int t$133737 = this.min;
        
        //#line 53 "x10/lang/IntRange.x10"
        final int t$133738 = ((t$133736) - (((int)(t$133737))));
        
        //#line 53 "x10/lang/IntRange.x10"
        final int numElems = ((t$133738) + (((int)(1))));
        
        //#line 54 "x10/lang/IntRange.x10"
        final int blockSize = ((numElems) / (((int)(n))));
        
        //#line 55 "x10/lang/IntRange.x10"
        final int t$133739 = ((n) * (((int)(blockSize))));
        
        //#line 55 "x10/lang/IntRange.x10"
        final int leftOver = ((numElems) - (((int)(t$133739))));
        
        //#line 56 "x10/lang/IntRange.x10"
        final long t$133750 = ((long)(((int)(n))));
        
        //#line 56 "x10/lang/IntRange.x10"
        final x10.core.fun.Fun_0_1 t$133751 = ((x10.core.fun.Fun_0_1)(new x10.lang.IntRange.$Closure$165(this, this.min, blockSize, leftOver)));
        
        //#line 56 "x10/lang/IntRange.x10"
        final x10.core.Rail t$133752 = ((x10.core.Rail)(new x10.core.Rail<x10.lang.IntRange>(x10.lang.IntRange.$RTT, t$133750, ((x10.core.fun.Fun_0_1)(t$133751)), (x10.core.Rail.__1$1x10$lang$Long$3x10$lang$Rail$$T$2) null)));
        
        //#line 56 "x10/lang/IntRange.x10"
        return t$133752;
    }
    
    
    //#line 68 "x10/lang/IntRange.x10"
    /**
     * Define the product of two IntRanges to be a rank-2 IterationSpace
     * containing all the points defined by the cartesian product of the ranges.
     */
    final public x10.array.DenseIterationSpace_2 $times(final x10.lang.IntRange that) {
        
        //#line 69 "x10/lang/IntRange.x10"
        final x10.array.DenseIterationSpace_2 alloc$133716 = ((x10.array.DenseIterationSpace_2)(new x10.array.DenseIterationSpace_2((java.lang.System[]) null)));
        
        //#line 69 "x10/lang/IntRange.x10"
        final int t$133797 = this.min;
        
        //#line 69 "x10/lang/IntRange.x10"
        final long t$133798 = ((long)(((int)(t$133797))));
        
        //#line 69 "x10/lang/IntRange.x10"
        final int t$133799 = that.min;
        
        //#line 69 "x10/lang/IntRange.x10"
        final long t$133800 = ((long)(((int)(t$133799))));
        
        //#line 69 "x10/lang/IntRange.x10"
        final int t$133801 = this.max;
        
        //#line 69 "x10/lang/IntRange.x10"
        final long t$133802 = ((long)(((int)(t$133801))));
        
        //#line 69 "x10/lang/IntRange.x10"
        final int t$133803 = that.max;
        
        //#line 69 "x10/lang/IntRange.x10"
        final long t$133804 = ((long)(((int)(t$133803))));
        
        //#line 69 "x10/lang/IntRange.x10"
        alloc$133716.x10$array$DenseIterationSpace_2$$init$S(t$133798, t$133800, t$133802, t$133804);
        
        //#line 69 "x10/lang/IntRange.x10"
        return alloc$133716;
    }
    
    
    //#line 72 "x10/lang/IntRange.x10"
    final public java.lang.String toString() {
        
        //#line 72 "x10/lang/IntRange.x10"
        final int t$133761 = this.min;
        
        //#line 72 "x10/lang/IntRange.x10"
        final java.lang.String t$133762 = (((x10.core.Int.$box(t$133761))) + (".."));
        
        //#line 72 "x10/lang/IntRange.x10"
        final int t$133763 = this.max;
        
        //#line 72 "x10/lang/IntRange.x10"
        final java.lang.String t$133764 = ((t$133762) + ((x10.core.Int.$box(t$133763))));
        
        //#line 72 "x10/lang/IntRange.x10"
        return t$133764;
    }
    
    
    //#line 74 "x10/lang/IntRange.x10"
    final public boolean equals(final java.lang.Object that) {
        
        //#line 75 "x10/lang/IntRange.x10"
        final boolean t$133771 = x10.lang.IntRange.$RTT.isInstance(that);
        
        //#line 75 "x10/lang/IntRange.x10"
        if (t$133771) {
            
            //#line 76 "x10/lang/IntRange.x10"
            final x10.lang.IntRange other = ((x10.lang.IntRange)(((x10.lang.IntRange)x10.rtt.Types.asStruct(x10.lang.IntRange.$RTT,that))));
            
            //#line 77 "x10/lang/IntRange.x10"
            final int t$133765 = this.min;
            
            //#line 77 "x10/lang/IntRange.x10"
            final int t$133766 = other.min;
            
            //#line 77 "x10/lang/IntRange.x10"
            boolean t$133769 = ((int) t$133765) == ((int) t$133766);
            
            //#line 77 "x10/lang/IntRange.x10"
            if (t$133769) {
                
                //#line 77 "x10/lang/IntRange.x10"
                final int t$133767 = this.max;
                
                //#line 77 "x10/lang/IntRange.x10"
                final int t$133768 = other.max;
                
                //#line 77 "x10/lang/IntRange.x10"
                t$133769 = ((int) t$133767) == ((int) t$133768);
            }
            
            //#line 77 "x10/lang/IntRange.x10"
            return t$133769;
        }
        
        //#line 79 "x10/lang/IntRange.x10"
        return false;
    }
    
    
    //#line 82 "x10/lang/IntRange.x10"
    final public int hashCode() {
        
        //#line 82 "x10/lang/IntRange.x10"
        final int t$133772 = this.max;
        
        //#line 82 "x10/lang/IntRange.x10"
        final int t$133773 = this.min;
        
        //#line 82 "x10/lang/IntRange.x10"
        final int t$133774 = ((t$133772) - (((int)(t$133773))));
        
        //#line 82 "x10/lang/IntRange.x10"
        final int t$133775 = x10.rtt.Types.hashCode(t$133774);
        
        //#line 82 "x10/lang/IntRange.x10"
        return t$133775;
    }
    
    
    //#line 84 "x10/lang/IntRange.x10"
    final public x10.lang.Iterator iterator() {
        
        //#line 85 "x10/lang/IntRange.x10"
        final x10.lang.IntRange.IntRangeIt alloc$133717 = ((x10.lang.IntRange.IntRangeIt)(new x10.lang.IntRange.IntRangeIt((java.lang.System[]) null)));
        
        //#line 85 "x10/lang/IntRange.x10"
        final int min$133728 = this.min;
        
        //#line 85 "x10/lang/IntRange.x10"
        final int max$133729 = this.max;
        
        //#line 88 .. "x10/lang/IntRange.x10"
        alloc$133717.cur = 0;
        
        //#line 92 . "x10/lang/IntRange.x10"
        alloc$133717.cur = min$133728;
        
        //#line 93 . "x10/lang/IntRange.x10"
        alloc$133717.max = max$133729;
        
        //#line 85 "x10/lang/IntRange.x10"
        return alloc$133717;
    }
    
    
    //#line 88 "x10/lang/IntRange.x10"
    @x10.runtime.impl.java.X10Generated
    public static class IntRangeIt extends x10.core.Ref implements x10.lang.Iterator, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<IntRangeIt> $RTT = 
            x10.rtt.NamedType.<IntRangeIt> make("x10.lang.IntRange.IntRangeIt",
                                                IntRangeIt.class,
                                                new x10.rtt.Type[] {
                                                    x10.rtt.ParameterizedType.make(x10.lang.Iterator.$RTT, x10.rtt.Types.INT)
                                                });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static x10.serialization.X10JavaSerializable $_deserialize_body(x10.lang.IntRange.IntRangeIt $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            $_obj.cur = $deserializer.readInt();
            $_obj.max = $deserializer.readInt();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.lang.IntRange.IntRangeIt $_obj = new x10.lang.IntRange.IntRangeIt((java.lang.System[]) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            $serializer.write(this.cur);
            $serializer.write(this.max);
            
        }
        
        // constructor just for allocation
        public IntRangeIt(final java.lang.System[] $dummy) {
            
        }
        
        // bridge for method abstract public x10.lang.Iterator[T].next(){}:T
        public x10.core.Int next$G() {
            return x10.core.Int.$box(next$O());
        }
        
        
    
        
        //#line 89 "x10/lang/IntRange.x10"
        public int cur;
        
        //#line 90 "x10/lang/IntRange.x10"
        public int max;
        
        
        //#line 91 "x10/lang/IntRange.x10"
        // creation method for java code (1-phase java constructor)
        public IntRangeIt(final int min, final int max) {
            this((java.lang.System[]) null);
            x10$lang$IntRange$IntRangeIt$$init$S(min, max);
        }
        
        // constructor for non-virtual call
        final public x10.lang.IntRange.IntRangeIt x10$lang$IntRange$IntRangeIt$$init$S(final int min, final int max) {
             {
                
                //#line 91 "x10/lang/IntRange.x10"
                
                
                //#line 88 "x10/lang/IntRange.x10"
                final x10.lang.IntRange.IntRangeIt this$133805 = this;
                
                //#line 88 "x10/lang/IntRange.x10"
                this$133805.cur = 0;
                
                //#line 92 "x10/lang/IntRange.x10"
                this.cur = min;
                
                //#line 93 "x10/lang/IntRange.x10"
                this.max = max;
            }
            return this;
        }
        
        
        
        //#line 95 "x10/lang/IntRange.x10"
        public boolean hasNext$O() {
            
            //#line 95 "x10/lang/IntRange.x10"
            final int t$133776 = this.cur;
            
            //#line 95 "x10/lang/IntRange.x10"
            final int t$133777 = this.max;
            
            //#line 95 "x10/lang/IntRange.x10"
            final boolean t$133778 = ((t$133776) <= (((int)(t$133777))));
            
            //#line 95 "x10/lang/IntRange.x10"
            return t$133778;
        }
        
        
        //#line 96 "x10/lang/IntRange.x10"
        public int next$O() {
            
            //#line 96 "x10/lang/IntRange.x10"
            final int t$133779 = this.cur;
            
            //#line 96 "x10/lang/IntRange.x10"
            final int t$133780 = ((t$133779) + (((int)(1))));
            
            //#line 96 "x10/lang/IntRange.x10"
            final int t$133781 = this.cur = t$133780;
            
            //#line 96 "x10/lang/IntRange.x10"
            final int t$133782 = ((t$133781) - (((int)(1))));
            
            //#line 96 "x10/lang/IntRange.x10"
            return t$133782;
        }
        
        
        //#line 88 "x10/lang/IntRange.x10"
        final public x10.lang.IntRange.IntRangeIt x10$lang$IntRange$IntRangeIt$$this$x10$lang$IntRange$IntRangeIt() {
            
            //#line 88 "x10/lang/IntRange.x10"
            return x10.lang.IntRange.IntRangeIt.this;
        }
        
        
        //#line 88 "x10/lang/IntRange.x10"
        final public void __fieldInitializers_x10_lang_IntRange_IntRangeIt() {
            
            //#line 88 "x10/lang/IntRange.x10"
            this.cur = 0;
        }
    }
    
    
    
    //#line 29 "x10/lang/IntRange.x10"
    final public java.lang.String typeName() {
        try {
            return x10.rtt.Types.typeName(this);
        }
        catch (java.lang.Throwable exc$206368) {
            throw x10.runtime.impl.java.ThrowableUtils.ensureX10Exception(exc$206368);
        }
        
    }
    
    
    
    //#line 29 "x10/lang/IntRange.x10"
    final public boolean _struct_equals$O(java.lang.Object other) {
        
        //#line 29 "x10/lang/IntRange.x10"
        final boolean t$133784 = x10.lang.IntRange.$RTT.isInstance(other);
        
        //#line 29 "x10/lang/IntRange.x10"
        final boolean t$133785 = !(t$133784);
        
        //#line 29 "x10/lang/IntRange.x10"
        if (t$133785) {
            
            //#line 29 "x10/lang/IntRange.x10"
            return false;
        }
        
        //#line 29 "x10/lang/IntRange.x10"
        final x10.lang.IntRange t$133787 = ((x10.lang.IntRange)x10.rtt.Types.asStruct(x10.lang.IntRange.$RTT,other));
        
        //#line 29 "x10/lang/IntRange.x10"
        final boolean t$133788 = this._struct_equals$O(((x10.lang.IntRange)(t$133787)));
        
        //#line 29 "x10/lang/IntRange.x10"
        return t$133788;
    }
    
    
    //#line 29 "x10/lang/IntRange.x10"
    final public boolean _struct_equals$O(x10.lang.IntRange other) {
        
        //#line 29 "x10/lang/IntRange.x10"
        final int t$133790 = this.min;
        
        //#line 29 "x10/lang/IntRange.x10"
        final int t$133791 = other.min;
        
        //#line 29 "x10/lang/IntRange.x10"
        boolean t$133795 = ((int) t$133790) == ((int) t$133791);
        
        //#line 29 "x10/lang/IntRange.x10"
        if (t$133795) {
            
            //#line 29 "x10/lang/IntRange.x10"
            final int t$133793 = this.max;
            
            //#line 29 "x10/lang/IntRange.x10"
            final int t$133794 = other.max;
            
            //#line 29 "x10/lang/IntRange.x10"
            t$133795 = ((int) t$133793) == ((int) t$133794);
        }
        
        //#line 29 "x10/lang/IntRange.x10"
        return t$133795;
    }
    
    
    //#line 19 "x10/lang/IntRange.x10"
    final public x10.lang.IntRange x10$lang$IntRange$$this$x10$lang$IntRange() {
        
        //#line 19 "x10/lang/IntRange.x10"
        return x10.lang.IntRange.this;
    }
    
    
    //#line 19 "x10/lang/IntRange.x10"
    final public void __fieldInitializers_x10_lang_IntRange() {
        
    }
    
    @x10.runtime.impl.java.X10Generated
    final public static class $Closure$165 extends x10.core.Ref implements x10.core.fun.Fun_0_1, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<$Closure$165> $RTT = 
            x10.rtt.StaticFunType.<$Closure$165> make($Closure$165.class,
                                                      new x10.rtt.Type[] {
                                                          x10.rtt.ParameterizedType.make(x10.core.fun.Fun_0_1.$RTT, x10.rtt.Types.LONG, x10.lang.IntRange.$RTT)
                                                      });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static x10.serialization.X10JavaSerializable $_deserialize_body(x10.lang.IntRange.$Closure$165 $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            $_obj.blockSize = $deserializer.readInt();
            $_obj.leftOver = $deserializer.readInt();
            $_obj.min = $deserializer.readInt();
            $_obj.out$$ = $deserializer.readObject();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.lang.IntRange.$Closure$165 $_obj = new x10.lang.IntRange.$Closure$165((java.lang.System[]) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            $serializer.write(this.blockSize);
            $serializer.write(this.leftOver);
            $serializer.write(this.min);
            $serializer.write(this.out$$);
            
        }
        
        // constructor just for allocation
        public $Closure$165(final java.lang.System[] $dummy) {
            
        }
        
        // dispatcher for method abstract public (Z1)=>U.operator()(a1:Z1):U
        public java.lang.Object $apply(final java.lang.Object a1, final x10.rtt.Type t1) {
            return $apply(x10.core.Long.$unbox(a1));
            
        }
        
        
    
        
        public x10.lang.IntRange $apply(final long iLong) {
            
            //#line 57 "x10/lang/IntRange.x10"
            final int i = ((int)(long)(((long)(iLong))));
            
            //#line 58 "x10/lang/IntRange.x10"
            final int t$133740 = this.min;
            
            //#line 58 "x10/lang/IntRange.x10"
            final int t$133741 = ((this.blockSize) * (((int)(i))));
            
            //#line 58 "x10/lang/IntRange.x10"
            final int t$133744 = ((t$133740) + (((int)(t$133741))));
            
            //#line 58 "x10/lang/IntRange.x10"
            final boolean t$133742 = ((i) < (((int)(this.leftOver))));
            
            //#line 58 "x10/lang/IntRange.x10"
            int t$133743 =  0;
            
            //#line 58 "x10/lang/IntRange.x10"
            if (t$133742) {
                
                //#line 58 "x10/lang/IntRange.x10"
                t$133743 = i;
            } else {
                
                //#line 58 "x10/lang/IntRange.x10"
                t$133743 = this.leftOver;
            }
            
            //#line 58 "x10/lang/IntRange.x10"
            final int low = ((t$133744) + (((int)(t$133743))));
            
            //#line 59 "x10/lang/IntRange.x10"
            final int t$133748 = ((low) + (((int)(this.blockSize))));
            
            //#line 59 "x10/lang/IntRange.x10"
            final boolean t$133746 = ((i) < (((int)(this.leftOver))));
            
            //#line 59 "x10/lang/IntRange.x10"
            int t$133747 =  0;
            
            //#line 59 "x10/lang/IntRange.x10"
            if (t$133746) {
                
                //#line 59 "x10/lang/IntRange.x10"
                t$133747 = 0;
            } else {
                
                //#line 59 "x10/lang/IntRange.x10"
                t$133747 = -1;
            }
            
            //#line 59 "x10/lang/IntRange.x10"
            final int hi = ((t$133748) + (((int)(t$133747))));
            
            //#line 60 "x10/lang/IntRange.x10"
            final x10.lang.IntRange alloc$133715 = ((x10.lang.IntRange)(new x10.lang.IntRange((java.lang.System[]) null)));
            
            //#line 37 . "x10/lang/IntRange.x10"
            alloc$133715.min = low;
            
            //#line 37 . "x10/lang/IntRange.x10"
            alloc$133715.max = hi;
            
            //#line 60 "x10/lang/IntRange.x10"
            return alloc$133715;
        }
        
        public x10.lang.IntRange out$$;
        public int min;
        public int blockSize;
        public int leftOver;
        
        public $Closure$165(final x10.lang.IntRange out$$, final int min, final int blockSize, final int leftOver) {
             {
                this.out$$ = out$$;
                this.min = min;
                this.blockSize = blockSize;
                this.leftOver = leftOver;
            }
        }
        
    }
    
}

