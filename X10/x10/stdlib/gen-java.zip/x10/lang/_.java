package x10.lang;

@x10.runtime.impl.java.X10Generated
public class _ extends x10.core.Ref implements x10.serialization.X10JavaSerializable
{
    public static final x10.rtt.RuntimeType<_> $RTT = 
        x10.rtt.NamedType.<_> make("x10.lang._",
                                   _.class);
    
    public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
    
    public x10.rtt.Type<?> $getParam(int i) { return null; }
    
    private Object writeReplace() throws java.io.ObjectStreamException {
        return new x10.serialization.SerializationProxy(this);
    }
    
    public static x10.serialization.X10JavaSerializable $_deserialize_body(x10.lang._ $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
        return $_obj;
    }
    
    public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
        x10.lang._ $_obj = new x10.lang._((java.lang.System[]) null);
        $deserializer.record_reference($_obj);
        return $_deserialize_body($_obj, $deserializer);
    }
    
    public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
        
    }
    
    // constructor just for allocation
    public _(final java.lang.System[] $dummy) {
        
    }
    
    

    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    //#line 16 "x10/lang/_.x10"
    final public x10.lang._ x10$lang$_$$this$x10$lang$_() {
        
        //#line 16 "x10/lang/_.x10"
        return x10.lang._.this;
    }
    
    
    //#line 16 "x10/lang/_.x10"
    // creation method for java code (1-phase java constructor)
    public _() {
        this((java.lang.System[]) null);
        x10$lang$_$$init$S();
    }
    
    // constructor for non-virtual call
    final public x10.lang._ x10$lang$_$$init$S() {
         {
            
            //#line 16 "x10/lang/_.x10"
            
        }
        return this;
    }
    
    
    
    //#line 16 "x10/lang/_.x10"
    final public void __fieldInitializers_x10_lang__() {
        
    }
}

