package x10.lang;


/**
 * <p>An implementation of PlaceGroup that simply uses a Rail[Place] to
 * represent the Places in the group.  This implementation is only suitable
 * when the PlaceGroup contains a fairly small number of places.
 * This can happen either becase the group is very sparse, or because the total 
 * number of places being used by the program is small.  In either case, 
 * this PlaceGroup should have acceptable performance.</p>
 *
 * <p>Although the basic operations (contains, indexOf) could be asymptotically
 * improved from O(N) to O(log(N)) by using binary search over a sorted Rail,
 * the expected performance of this class would still be poor due to
 * the space overhead of explictly representing all of the Places in the group,
 * which in turn would yield O(size()) serialization costs.  Therefore, we have
 * decided to go with the lower constants and ignore the asymptotic analysis.</p>
 */
@x10.runtime.impl.java.X10Generated
final public class SparsePlaceGroup extends x10.lang.PlaceGroup implements x10.serialization.X10JavaSerializable
{
    public static final x10.rtt.RuntimeType<SparsePlaceGroup> $RTT = 
        x10.rtt.NamedType.<SparsePlaceGroup> make("x10.lang.SparsePlaceGroup",
                                                  SparsePlaceGroup.class,
                                                  new x10.rtt.Type[] {
                                                      x10.lang.PlaceGroup.$RTT
                                                  });
    
    public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
    
    public x10.rtt.Type<?> $getParam(int i) { return null; }
    
    private Object writeReplace() throws java.io.ObjectStreamException {
        return new x10.serialization.SerializationProxy(this);
    }
    
    public static x10.serialization.X10JavaSerializable $_deserialize_body(x10.lang.SparsePlaceGroup $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
        x10.lang.PlaceGroup.$_deserialize_body($_obj, $deserializer);
        $_obj.places = $deserializer.readObject();
        return $_obj;
    }
    
    public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
        x10.lang.SparsePlaceGroup $_obj = new x10.lang.SparsePlaceGroup((java.lang.System[]) null);
        $deserializer.record_reference($_obj);
        return $_deserialize_body($_obj, $deserializer);
    }
    
    public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
        super.$_serialize($serializer);
        $serializer.write(this.places);
        
    }
    
    // constructor just for allocation
    public SparsePlaceGroup(final java.lang.System[] $dummy) {
        super($dummy);
        
    }
    
    // synthetic type for parameter mangling
    public static final class __0$1x10$lang$Place$2 {}
    

    
    //#line 37 "x10/lang/SparsePlaceGroup.x10"
    /**
   * The set of places.
   * Only places that are in the group are in the array.
   */
    public x10.core.Rail<x10.lang.Place> places;
    
    
    //#line 46 "x10/lang/SparsePlaceGroup.x10"
    /**
   * Construct a SparsePlaceGroup from a Rail[Place].
   * Places may appear in any order, but must represent a 
   * set of Places (no duplicate entries).
   * If the argument rail is not a set an IllegalArgumentException 
   * will be thrown (unless the X10 standaed library was compiled with NO_CHECKS).
   */
    // creation method for java code (1-phase java constructor)
    public SparsePlaceGroup(final x10.core.Rail<x10.lang.Place> ps, __0$1x10$lang$Place$2 $dummy) {
        this((java.lang.System[]) null);
        x10$lang$SparsePlaceGroup$$init$S(ps, (x10.lang.SparsePlaceGroup.__0$1x10$lang$Place$2) null);
    }
    
    // constructor for non-virtual call
    final public x10.lang.SparsePlaceGroup x10$lang$SparsePlaceGroup$$init$S(final x10.core.Rail<x10.lang.Place> ps, __0$1x10$lang$Place$2 $dummy) {
         {
            
            //#line 46 "x10/lang/SparsePlaceGroup.x10"
            
            
            //#line 47 "x10/lang/SparsePlaceGroup.x10"
            final x10.core.Rail t$136419 = ((x10.core.Rail)(new x10.core.Rail<x10.lang.Place>(x10.lang.Place.$RTT, ((x10.core.Rail)(ps)), (x10.core.Rail.__0$1x10$lang$Rail$$T$2) null)));
            
            //#line 47 "x10/lang/SparsePlaceGroup.x10"
            this.places = ((x10.core.Rail)(t$136419));
            
            //#line 49 "x10/lang/SparsePlaceGroup.x10"
            boolean sorted$136502 = true;
            
            //#line 51 "x10/lang/SparsePlaceGroup.x10"
            final x10.core.Rail t$136498 = ((x10.core.Rail)(this.places));
            
            //#line 51 "x10/lang/SparsePlaceGroup.x10"
            final long t$136499 = ((x10.core.Rail<x10.lang.Place>)t$136498).size;
            
            //#line 51 "x10/lang/SparsePlaceGroup.x10"
            final long i$135064max$136500 = ((t$136499) - (((long)(1L))));
            
            //#line 51 "x10/lang/SparsePlaceGroup.x10"
            long i$136484 = 1L;
            
            //#line 51 "x10/lang/SparsePlaceGroup.x10"
            for (;
                 true;
                 ) {
                
                //#line 51 "x10/lang/SparsePlaceGroup.x10"
                final boolean t$136486 = ((i$136484) <= (((long)(i$135064max$136500))));
                
                //#line 51 "x10/lang/SparsePlaceGroup.x10"
                if (!(t$136486)) {
                    
                    //#line 51 "x10/lang/SparsePlaceGroup.x10"
                    break;
                }
                
                //#line 52 "x10/lang/SparsePlaceGroup.x10"
                final x10.core.Rail t$136473 = ((x10.core.Rail)(this.places));
                
                //#line 52 "x10/lang/SparsePlaceGroup.x10"
                final x10.lang.Place t$136474 = ((x10.lang.Place[])t$136473.value)[(int)i$136484];
                
                //#line 52 "x10/lang/SparsePlaceGroup.x10"
                final long t$136475 = t$136474.id;
                
                //#line 52 "x10/lang/SparsePlaceGroup.x10"
                final x10.core.Rail t$136476 = ((x10.core.Rail)(this.places));
                
                //#line 52 "x10/lang/SparsePlaceGroup.x10"
                final long t$136477 = ((i$136484) - (((long)(1L))));
                
                //#line 52 "x10/lang/SparsePlaceGroup.x10"
                final x10.lang.Place t$136478 = ((x10.lang.Place[])t$136476.value)[(int)t$136477];
                
                //#line 52 "x10/lang/SparsePlaceGroup.x10"
                final long t$136479 = t$136478.id;
                
                //#line 52 "x10/lang/SparsePlaceGroup.x10"
                final boolean t$136480 = ((t$136475) <= (((long)(t$136479))));
                
                //#line 52 "x10/lang/SparsePlaceGroup.x10"
                if (t$136480) {
                    
                    //#line 53 "x10/lang/SparsePlaceGroup.x10"
                    sorted$136502 = false;
                    
                    //#line 54 "x10/lang/SparsePlaceGroup.x10"
                    break;
                }
                
                //#line 51 "x10/lang/SparsePlaceGroup.x10"
                final long t$136483 = ((i$136484) + (((long)(1L))));
                
                //#line 51 "x10/lang/SparsePlaceGroup.x10"
                i$136484 = t$136483;
            }
            
            //#line 57 "x10/lang/SparsePlaceGroup.x10"
            final boolean t$136504 = !(sorted$136502);
            
            //#line 57 "x10/lang/SparsePlaceGroup.x10"
            if (t$136504) {
                
                //#line 58 "x10/lang/SparsePlaceGroup.x10"
                final x10.util.HashSet seen$136505 = new x10.util.HashSet<x10.lang.Place>((java.lang.System[]) null, x10.lang.Place.$RTT);
                
                //#line 58 "x10/lang/SparsePlaceGroup.x10"
                seen$136505.x10$util$HashSet$$init$S();
                
                //#line 59 "x10/lang/SparsePlaceGroup.x10"
                final x10.core.Rail rail$136496 = ((x10.core.Rail)(this.places));
                
                //#line 59 "x10/lang/SparsePlaceGroup.x10"
                final long size$136497 = ((x10.core.Rail<x10.lang.Place>)rail$136496).size;
                
                //#line 59 "x10/lang/SparsePlaceGroup.x10"
                long idx$136493 = 0L;
                {
                    
                    //#line 59 "x10/lang/SparsePlaceGroup.x10"
                    final x10.lang.Place[] rail$136496$value$136531 = ((x10.lang.Place[])rail$136496.value);
                    
                    //#line 59 "x10/lang/SparsePlaceGroup.x10"
                    for (;
                         true;
                         ) {
                        
                        //#line 59 "x10/lang/SparsePlaceGroup.x10"
                        final boolean t$136495 = ((idx$136493) < (((long)(size$136497))));
                        
                        //#line 59 "x10/lang/SparsePlaceGroup.x10"
                        if (!(t$136495)) {
                            
                            //#line 59 "x10/lang/SparsePlaceGroup.x10"
                            break;
                        }
                        
                        //#line 59 "x10/lang/SparsePlaceGroup.x10"
                        final x10.lang.Place p$136490 = ((x10.lang.Place)(((x10.lang.Place)rail$136496$value$136531[(int)idx$136493])));
                        
                        //#line 60 "x10/lang/SparsePlaceGroup.x10"
                        final boolean t$136487 = ((x10.util.MapSet<x10.lang.Place>)seen$136505).contains__0x10$util$MapSet$$T$O(((x10.lang.Place)(p$136490)));
                        
                        //#line 60 "x10/lang/SparsePlaceGroup.x10"
                        if (t$136487) {
                            
                            //#line 61 "x10/lang/SparsePlaceGroup.x10"
                            final java.lang.IllegalArgumentException t$136488 = ((java.lang.IllegalArgumentException)(new java.lang.IllegalArgumentException("Argument rail was not sorted")));
                            
                            //#line 61 "x10/lang/SparsePlaceGroup.x10"
                            throw t$136488;
                        }
                        
                        //#line 63 "x10/lang/SparsePlaceGroup.x10"
                        ((x10.util.MapSet<x10.lang.Place>)seen$136505).add__0x10$util$MapSet$$T$O(((x10.lang.Place)(p$136490)));
                        
                        //#line 59 "x10/lang/SparsePlaceGroup.x10"
                        final long t$136492 = ((idx$136493) + (((long)(1L))));
                        
                        //#line 59 "x10/lang/SparsePlaceGroup.x10"
                        idx$136493 = t$136492;
                    }
                }
            }
        }
        return this;
    }
    
    
    
    //#line 72 "x10/lang/SparsePlaceGroup.x10"
    /**
   * Construct a SparsePlaceGroup from another PlaceGroup.
   */
    // creation method for java code (1-phase java constructor)
    public SparsePlaceGroup(final x10.lang.PlaceGroup pg) {
        this((java.lang.System[]) null);
        x10$lang$SparsePlaceGroup$$init$S(pg);
    }
    
    // constructor for non-virtual call
    final public x10.lang.SparsePlaceGroup x10$lang$SparsePlaceGroup$$init$S(final x10.lang.PlaceGroup pg) {
         {
            
            //#line 72 "x10/lang/SparsePlaceGroup.x10"
            
            
            //#line 35 . "x10/lang/PlaceGroup.x10"
            final long t$136446 = pg.numPlaces$O();
            
            //#line 73 "x10/lang/SparsePlaceGroup.x10"
            final x10.core.fun.Fun_0_1 t$136447 = ((x10.core.fun.Fun_0_1)(new x10.lang.SparsePlaceGroup.$Closure$199(pg)));
            
            //#line 73 "x10/lang/SparsePlaceGroup.x10"
            final x10.core.Rail t$136448 = ((x10.core.Rail)(new x10.core.Rail<x10.lang.Place>(x10.lang.Place.$RTT, t$136446, ((x10.core.fun.Fun_0_1)(t$136447)), (x10.core.Rail.__1$1x10$lang$Long$3x10$lang$Rail$$T$2) null)));
            
            //#line 73 "x10/lang/SparsePlaceGroup.x10"
            this.places = ((x10.core.Rail)(t$136448));
        }
        return this;
    }
    
    
    
    //#line 80 "x10/lang/SparsePlaceGroup.x10"
    /**
   * Construct a SparsePlaceGroup that contains a single place, p.
   * @param p the place 
   */
    // creation method for java code (1-phase java constructor)
    public SparsePlaceGroup(final x10.lang.Place p) {
        this((java.lang.System[]) null);
        x10$lang$SparsePlaceGroup$$init$S(p);
    }
    
    // constructor for non-virtual call
    final public x10.lang.SparsePlaceGroup x10$lang$SparsePlaceGroup$$init$S(final x10.lang.Place p) {
         {
            
            //#line 80 "x10/lang/SparsePlaceGroup.x10"
            
            
            //#line 81 "x10/lang/SparsePlaceGroup.x10"
            final x10.core.Rail t$136449 = ((x10.core.Rail)(new x10.core.Rail<x10.lang.Place>(x10.lang.Place.$RTT, ((long)(1L)), ((x10.lang.Place)(p)), (x10.core.Rail.__1x10$lang$Rail$$T) null)));
            
            //#line 81 "x10/lang/SparsePlaceGroup.x10"
            this.places = ((x10.core.Rail)(t$136449));
        }
        return this;
    }
    
    
    
    //#line 84 "x10/lang/SparsePlaceGroup.x10"
    public x10.lang.Place $apply(final long i) {
        
        //#line 84 "x10/lang/SparsePlaceGroup.x10"
        final x10.core.Rail t$136450 = ((x10.core.Rail)(this.places));
        
        //#line 84 "x10/lang/SparsePlaceGroup.x10"
        final x10.lang.Place t$136451 = ((x10.lang.Place[])t$136450.value)[(int)i];
        
        //#line 84 "x10/lang/SparsePlaceGroup.x10"
        return t$136451;
    }
    
    
    //#line 86 "x10/lang/SparsePlaceGroup.x10"
    public x10.lang.Iterator iterator() {
        
        //#line 86 "x10/lang/SparsePlaceGroup.x10"
        final x10.core.Rail t$136452 = ((x10.core.Rail)(this.places));
        
        //#line 86 "x10/lang/SparsePlaceGroup.x10"
        final x10.lang.Iterator t$136453 = ((x10.lang.Iterator<x10.lang.Place>)
                                             ((x10.core.Rail<x10.lang.Place>)t$136452).iterator());
        
        //#line 86 "x10/lang/SparsePlaceGroup.x10"
        return t$136453;
    }
    
    
    //#line 88 "x10/lang/SparsePlaceGroup.x10"
    public long numPlaces$O() {
        
        //#line 88 "x10/lang/SparsePlaceGroup.x10"
        final x10.core.Rail t$136454 = ((x10.core.Rail)(this.places));
        
        //#line 88 "x10/lang/SparsePlaceGroup.x10"
        final long t$136455 = ((x10.core.Rail<x10.lang.Place>)t$136454).size;
        
        //#line 88 "x10/lang/SparsePlaceGroup.x10"
        return t$136455;
    }
    
    
    //#line 90 "x10/lang/SparsePlaceGroup.x10"
    public boolean contains$O(final long id) {
        
        //#line 91 "x10/lang/SparsePlaceGroup.x10"
        final x10.core.Rail rail$136517 = ((x10.core.Rail)(this.places));
        
        //#line 91 "x10/lang/SparsePlaceGroup.x10"
        final long size$136518 = ((x10.core.Rail<x10.lang.Place>)rail$136517).size;
        
        //#line 91 "x10/lang/SparsePlaceGroup.x10"
        long idx$136514 = 0L;
        {
            
            //#line 91 "x10/lang/SparsePlaceGroup.x10"
            final x10.lang.Place[] rail$136517$value$136532 = ((x10.lang.Place[])rail$136517.value);
            
            //#line 91 "x10/lang/SparsePlaceGroup.x10"
            for (;
                 true;
                 ) {
                
                //#line 91 "x10/lang/SparsePlaceGroup.x10"
                final boolean t$136516 = ((idx$136514) < (((long)(size$136518))));
                
                //#line 91 "x10/lang/SparsePlaceGroup.x10"
                if (!(t$136516)) {
                    
                    //#line 91 "x10/lang/SparsePlaceGroup.x10"
                    break;
                }
                
                //#line 91 "x10/lang/SparsePlaceGroup.x10"
                final x10.lang.Place p$136511 = ((x10.lang.Place)(((x10.lang.Place)rail$136517$value$136532[(int)idx$136514])));
                
                //#line 92 "x10/lang/SparsePlaceGroup.x10"
                final long t$136508 = p$136511.id;
                
                //#line 92 "x10/lang/SparsePlaceGroup.x10"
                final boolean t$136509 = ((long) t$136508) == ((long) id);
                
                //#line 92 "x10/lang/SparsePlaceGroup.x10"
                if (t$136509) {
                    
                    //#line 92 "x10/lang/SparsePlaceGroup.x10"
                    return true;
                }
                
                //#line 91 "x10/lang/SparsePlaceGroup.x10"
                final long t$136513 = ((idx$136514) + (((long)(1L))));
                
                //#line 91 "x10/lang/SparsePlaceGroup.x10"
                idx$136514 = t$136513;
            }
        }
        
        //#line 94 "x10/lang/SparsePlaceGroup.x10"
        return false;
    }
    
    
    //#line 97 "x10/lang/SparsePlaceGroup.x10"
    public long indexOf$O(final long id) {
        
        //#line 98 "x10/lang/SparsePlaceGroup.x10"
        final x10.core.Rail rail$136529 = ((x10.core.Rail)(this.places));
        
        //#line 98 "x10/lang/SparsePlaceGroup.x10"
        final long i$135132max$136530 = ((x10.core.Rail<x10.lang.Place>)rail$136529).size;
        
        //#line 98 "x10/lang/SparsePlaceGroup.x10"
        long i$136526 = 0L;
        
        //#line 98 "x10/lang/SparsePlaceGroup.x10"
        for (;
             true;
             ) {
            
            //#line 98 "x10/lang/SparsePlaceGroup.x10"
            final boolean t$136528 = ((i$136526) < (((long)(i$135132max$136530))));
            
            //#line 98 "x10/lang/SparsePlaceGroup.x10"
            if (!(t$136528)) {
                
                //#line 98 "x10/lang/SparsePlaceGroup.x10"
                break;
            }
            
            //#line 99 "x10/lang/SparsePlaceGroup.x10"
            final x10.core.Rail t$136519 = ((x10.core.Rail)(this.places));
            
            //#line 99 "x10/lang/SparsePlaceGroup.x10"
            final x10.lang.Place t$136520 = ((x10.lang.Place[])t$136519.value)[(int)i$136526];
            
            //#line 99 "x10/lang/SparsePlaceGroup.x10"
            final long t$136521 = t$136520.id;
            
            //#line 99 "x10/lang/SparsePlaceGroup.x10"
            final boolean t$136522 = ((long) t$136521) == ((long) id);
            
            //#line 99 "x10/lang/SparsePlaceGroup.x10"
            if (t$136522) {
                
                //#line 99 "x10/lang/SparsePlaceGroup.x10"
                return i$136526;
            }
            
            //#line 98 "x10/lang/SparsePlaceGroup.x10"
            final long t$136525 = ((i$136526) + (((long)(1L))));
            
            //#line 98 "x10/lang/SparsePlaceGroup.x10"
            i$136526 = t$136525;
        }
        
        //#line 101 "x10/lang/SparsePlaceGroup.x10"
        return -1L;
    }
    
    
    //#line 31 "x10/lang/SparsePlaceGroup.x10"
    final public x10.lang.SparsePlaceGroup x10$lang$SparsePlaceGroup$$this$x10$lang$SparsePlaceGroup() {
        
        //#line 31 "x10/lang/SparsePlaceGroup.x10"
        return x10.lang.SparsePlaceGroup.this;
    }
    
    
    //#line 31 "x10/lang/SparsePlaceGroup.x10"
    final public void __fieldInitializers_x10_lang_SparsePlaceGroup() {
        
    }
    
    @x10.runtime.impl.java.X10Generated
    final public static class $Closure$199 extends x10.core.Ref implements x10.core.fun.Fun_0_1, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<$Closure$199> $RTT = 
            x10.rtt.StaticFunType.<$Closure$199> make($Closure$199.class,
                                                      new x10.rtt.Type[] {
                                                          x10.rtt.ParameterizedType.make(x10.core.fun.Fun_0_1.$RTT, x10.rtt.Types.LONG, x10.lang.Place.$RTT)
                                                      });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static x10.serialization.X10JavaSerializable $_deserialize_body(x10.lang.SparsePlaceGroup.$Closure$199 $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            $_obj.pg = $deserializer.readObject();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.lang.SparsePlaceGroup.$Closure$199 $_obj = new x10.lang.SparsePlaceGroup.$Closure$199((java.lang.System[]) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            $serializer.write(this.pg);
            
        }
        
        // constructor just for allocation
        public $Closure$199(final java.lang.System[] $dummy) {
            
        }
        
        // dispatcher for method abstract public (Z1)=>U.operator()(a1:Z1):U
        public java.lang.Object $apply(final java.lang.Object a1, final x10.rtt.Type t1) {
            return $apply(x10.core.Long.$unbox(a1));
            
        }
        
        
    
        
        public x10.lang.Place $apply(final long i) {
            
            //#line 73 "x10/lang/SparsePlaceGroup.x10"
            final x10.lang.Place t$136445 = this.pg.$apply((long)(i));
            
            //#line 73 "x10/lang/SparsePlaceGroup.x10"
            return t$136445;
        }
        
        public x10.lang.PlaceGroup pg;
        
        public $Closure$199(final x10.lang.PlaceGroup pg) {
             {
                this.pg = ((x10.lang.PlaceGroup)(pg));
            }
        }
        
    }
    
}

