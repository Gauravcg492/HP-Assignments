package x10.lang;


/**
 * Thrown to indicate that the code has attempted to cast an object to a subclass of which it is
 * not an instance.
 */
;

