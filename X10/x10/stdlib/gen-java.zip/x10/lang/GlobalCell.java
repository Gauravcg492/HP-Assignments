package x10.lang;

@x10.runtime.impl.java.X10Generated
public class GlobalCell<$T> extends x10.core.Ref implements x10.serialization.X10JavaSerializable
{
    public static final x10.rtt.RuntimeType<GlobalCell> $RTT = 
        x10.rtt.NamedType.<GlobalCell> make("x10.lang.GlobalCell",
                                            GlobalCell.class,
                                            1);
    
    public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
    
    public x10.rtt.Type<?> $getParam(int i) { if (i == 0) return $T; return null; }
    
    private Object writeReplace() throws java.io.ObjectStreamException {
        return new x10.serialization.SerializationProxy(this);
    }
    
    public static <$T> x10.serialization.X10JavaSerializable $_deserialize_body(x10.lang.GlobalCell<$T> $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
        $_obj.$T = (x10.rtt.Type) $deserializer.readObject();
        $_obj.root = $deserializer.readObject();
        return $_obj;
    }
    
    public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
        x10.lang.GlobalCell $_obj = new x10.lang.GlobalCell((java.lang.System[]) null, (x10.rtt.Type) null);
        $deserializer.record_reference($_obj);
        return $_deserialize_body($_obj, $deserializer);
    }
    
    public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
        $serializer.write(this.$T);
        $serializer.write(this.root);
        
    }
    
    // constructor just for allocation
    public GlobalCell(final java.lang.System[] $dummy, final x10.rtt.Type $T) {
        x10.lang.GlobalCell.$initParams(this, $T);
        
    }
    
    private x10.rtt.Type $T;
    
    // initializer of type parameters
    public static void $initParams(final GlobalCell $this, final x10.rtt.Type $T) {
        $this.$T = $T;
        
    }
    // synthetic type for parameter mangling
    public static final class __0x10$lang$GlobalCell$$T {}
    

    
    //#line 16 "x10/lang/GlobalCell.x10"
    public x10.core.GlobalRef<x10.lang.Cell<$T>> root;
    
    
    //#line 17 "x10/lang/GlobalCell.x10"
    // creation method for java code (1-phase java constructor)
    public GlobalCell(final x10.rtt.Type $T, final $T v, __0x10$lang$GlobalCell$$T $dummy) {
        this((java.lang.System[]) null, $T);
        x10$lang$GlobalCell$$init$S(v, (x10.lang.GlobalCell.__0x10$lang$GlobalCell$$T) null);
    }
    
    // constructor for non-virtual call
    final public x10.lang.GlobalCell<$T> x10$lang$GlobalCell$$init$S(final $T v, __0x10$lang$GlobalCell$$T $dummy) {
         {
            
            //#line 17 "x10/lang/GlobalCell.x10"
            
            
            //#line 18 "x10/lang/GlobalCell.x10"
            final x10.lang.Cell alloc$133183 = ((x10.lang.Cell)(new x10.lang.Cell<$T>((java.lang.System[]) null, $T)));
            
            //#line 33 . "x10/lang/Cell.x10"
            ((x10.lang.Cell<$T>)alloc$133183).value = (($T)(v));
            
            //#line 18 "x10/lang/GlobalCell.x10"
            final x10.core.GlobalRef t$133190 = ((x10.core.GlobalRef)(new x10.core.GlobalRef<x10.lang.Cell<$T>>(x10.rtt.ParameterizedType.make(x10.lang.Cell.$RTT, $T), ((x10.lang.Cell<$T>)(alloc$133183)), (x10.core.GlobalRef.__0x10$lang$GlobalRef$$T) null)));
            
            //#line 18 "x10/lang/GlobalCell.x10"
            ((x10.lang.GlobalCell<$T>)this).root = ((x10.core.GlobalRef)(t$133190));
        }
        return this;
    }
    
    
    
    //#line 26 "x10/lang/GlobalCell.x10"
    /**
     * Return a string representation of the GlobalCell.
     * 
     */
    public java.lang.String toString() {
        
        //#line 26 "x10/lang/GlobalCell.x10"
        final x10.core.GlobalRef t$133191 = ((x10.core.GlobalRef)(this.root));
        
        //#line 26 "x10/lang/GlobalCell.x10"
        final java.lang.String t$133192 = (((x10.core.GlobalRef<x10.lang.Cell<$T>>)(t$133191))).toString();
        
        //#line 26 "x10/lang/GlobalCell.x10"
        return t$133192;
    }
    
    
    //#line 35 "x10/lang/GlobalCell.x10"
    /**
     * Return the value stored in the Cell.
     * Will work even if the Cell reference is remote.
     *
     * @return the current value stored in the Cell.
     */
    public $T $apply$G() {
        
        //#line 35 "x10/lang/GlobalCell.x10"
        final x10.core.GlobalRef t$133177 = ((x10.core.GlobalRef)(this.root));
        
        //#line 35 "x10/lang/GlobalCell.x10"
        final x10.lang.Place t$133181 = ((x10.lang.Place)((t$133177).home));
        
        //#line 35 "x10/lang/GlobalCell.x10"
        final $T t$133182 = (($T)(x10.xrx.Runtime.<$T> evalAt__1$1x10$xrx$Runtime$$T$2$G($T, ((x10.lang.Place)(t$133181)), ((x10.core.fun.Fun_0_0)(new x10.lang.GlobalCell.$Closure$152<$T>($T, ((x10.lang.GlobalCell<$T>)(this)), this.root, (x10.lang.GlobalCell.$Closure$152.__0$1x10$lang$GlobalCell$$Closure$152$$T$2__1$1x10$lang$Cell$1x10$lang$GlobalCell$$Closure$152$$T$2$2) null))), ((x10.xrx.Runtime.Profile)(null)))));
        
        //#line 35 "x10/lang/GlobalCell.x10"
        return t$133182;
    }
    
    
    //#line 43 "x10/lang/GlobalCell.x10"
    /**
     * Set the value stored in the Cell to the new value.
     * Will work even if the Cell reference is remote.
     *
     * @param x the new value
     */
    public void $apply__0x10$lang$GlobalCell$$T(final $T x) {
        
        //#line 43 "x10/lang/GlobalCell.x10"
        final x10.core.GlobalRef t$133193 = ((x10.core.GlobalRef)(this.root));
        
        //#line 43 "x10/lang/GlobalCell.x10"
        final x10.lang.Place t$133196 = ((x10.lang.Place)((t$133193).home));
        {
            
            //#line 43 "x10/lang/GlobalCell.x10"
            x10.xrx.Runtime.runAt(((x10.lang.Place)(t$133196)), ((x10.core.fun.VoidFun_0_0)(new x10.lang.GlobalCell.$Closure$153<$T>($T, ((x10.lang.GlobalCell<$T>)(this)), this.root, x, (x10.lang.GlobalCell.$Closure$153.__0$1x10$lang$GlobalCell$$Closure$153$$T$2__1$1x10$lang$Cell$1x10$lang$GlobalCell$$Closure$153$$T$2$2__2x10$lang$GlobalCell$$Closure$153$$T) null))), ((x10.xrx.Runtime.Profile)(null)));
        }
    }
    
    
    //#line 52 "x10/lang/GlobalCell.x10"
    /**
     * Set the value stored in the Cell to the new value.
     * Will work even if the Cell reference is remote.
     *
     * @param x the new value
     * @return the new value stored in the Cell.
     */
    public void $set__0x10$lang$GlobalCell$$T(final $T x) {
        
        //#line 52 "x10/lang/GlobalCell.x10"
        this.set__0x10$lang$GlobalCell$$T$G((($T)(x)));
    }
    
    
    //#line 53 "x10/lang/GlobalCell.x10"
    public $T set__0x10$lang$GlobalCell$$T$G(final $T x) {
        
        //#line 54 "x10/lang/GlobalCell.x10"
        final x10.core.GlobalRef t$133197 = ((x10.core.GlobalRef)(this.root));
        
        //#line 54 "x10/lang/GlobalCell.x10"
        final x10.lang.Place t$133200 = ((x10.lang.Place)((t$133197).home));
        {
            
            //#line 54 "x10/lang/GlobalCell.x10"
            x10.xrx.Runtime.runAt(((x10.lang.Place)(t$133200)), ((x10.core.fun.VoidFun_0_0)(new x10.lang.GlobalCell.$Closure$154<$T>($T, ((x10.lang.GlobalCell<$T>)(this)), this.root, x, (x10.lang.GlobalCell.$Closure$154.__0$1x10$lang$GlobalCell$$Closure$154$$T$2__1$1x10$lang$Cell$1x10$lang$GlobalCell$$Closure$154$$T$2$2__2x10$lang$GlobalCell$$Closure$154$$T) null))), ((x10.xrx.Runtime.Profile)(null)));
        }
        
        //#line 57 "x10/lang/GlobalCell.x10"
        return x;
    }
    
    
    //#line 67 "x10/lang/GlobalCell.x10"
    /**
     * Create a new Cell with the given value stored in it.
     *
     * @param T the value type of the Cell
     * @param x the given value
     * @return a new Cell with the given value stored in it.
     */
    public static <$T>x10.lang.GlobalCell make__0x10$lang$GlobalCell$$T(final x10.rtt.Type $T, final $T x) {
        
        //#line 67 "x10/lang/GlobalCell.x10"
        final x10.lang.GlobalCell alloc$133184 = ((x10.lang.GlobalCell)(new x10.lang.GlobalCell<$T>((java.lang.System[]) null, $T)));
        
        //#line 67 "x10/lang/GlobalCell.x10"
        alloc$133184.x10$lang$GlobalCell$$init$S((($T)(x)), (x10.lang.GlobalCell.__0x10$lang$GlobalCell$$T) null);
        
        //#line 67 "x10/lang/GlobalCell.x10"
        return alloc$133184;
    }
    
    
    //#line 14 "x10/lang/GlobalCell.x10"
    final public x10.lang.GlobalCell x10$lang$GlobalCell$$this$x10$lang$GlobalCell() {
        
        //#line 14 "x10/lang/GlobalCell.x10"
        return x10.lang.GlobalCell.this;
    }
    
    
    //#line 14 "x10/lang/GlobalCell.x10"
    final public void __fieldInitializers_x10_lang_GlobalCell() {
        
    }
    
    @x10.runtime.impl.java.X10Generated
    final public static class $Closure$152<$T> extends x10.core.Ref implements x10.core.fun.Fun_0_0, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<$Closure$152> $RTT = 
            x10.rtt.StaticFunType.<$Closure$152> make($Closure$152.class,
                                                      1,
                                                      new x10.rtt.Type[] {
                                                          x10.rtt.ParameterizedType.make(x10.core.fun.Fun_0_0.$RTT, x10.rtt.UnresolvedType.PARAM(0))
                                                      });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { if (i == 0) return $T; return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static <$T> x10.serialization.X10JavaSerializable $_deserialize_body(x10.lang.GlobalCell.$Closure$152<$T> $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            $_obj.$T = (x10.rtt.Type) $deserializer.readObject();
            $_obj.out$$ = $deserializer.readObject();
            $_obj.root = $deserializer.readObject();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.lang.GlobalCell.$Closure$152 $_obj = new x10.lang.GlobalCell.$Closure$152((java.lang.System[]) null, (x10.rtt.Type) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            $serializer.write(this.$T);
            $serializer.write(this.out$$);
            $serializer.write(this.root);
            
        }
        
        // constructor just for allocation
        public $Closure$152(final java.lang.System[] $dummy, final x10.rtt.Type $T) {
            x10.lang.GlobalCell.$Closure$152.$initParams(this, $T);
            
        }
        
        private x10.rtt.Type $T;
        
        // initializer of type parameters
        public static void $initParams(final $Closure$152 $this, final x10.rtt.Type $T) {
            $this.$T = $T;
            
        }
        // synthetic type for parameter mangling
        public static final class __0$1x10$lang$GlobalCell$$Closure$152$$T$2__1$1x10$lang$Cell$1x10$lang$GlobalCell$$Closure$152$$T$2$2 {}
        
    
        
        public $T $apply$G() {
            
            //#line 35 "x10/lang/GlobalCell.x10"
            try {{
                
                //#line 35 "x10/lang/GlobalCell.x10"
                final x10.core.GlobalRef t$133178 = ((x10.core.GlobalRef)(this.root));
                
                //#line 35 "x10/lang/GlobalCell.x10"
                final x10.lang.Cell t$133179 = (((x10.core.GlobalRef<x10.lang.Cell<$T>>)(t$133178))).$apply$G();
                
                //#line 35 "x10/lang/GlobalCell.x10"
                final $T t$133180 = (($T)(((x10.lang.Cell<$T>)t$133179).value));
                
                //#line 35 "x10/lang/GlobalCell.x10"
                return t$133180;
            }}catch (java.lang.Throwable __lowerer__var__0__) {
                
                //#line 35 "x10/lang/GlobalCell.x10"
                $T __lowerer__var__1__ = (($T)(x10.xrx.Runtime.<$T> wrapAtChecked$G($T, ((java.lang.Throwable)(__lowerer__var__0__)))));
                
                //#line 35 "x10/lang/GlobalCell.x10"
                return __lowerer__var__1__;
            }
        }
        
        public x10.lang.GlobalCell<$T> out$$;
        public x10.core.GlobalRef<x10.lang.Cell<$T>> root;
        
        public $Closure$152(final x10.rtt.Type $T, final x10.lang.GlobalCell<$T> out$$, final x10.core.GlobalRef<x10.lang.Cell<$T>> root, __0$1x10$lang$GlobalCell$$Closure$152$$T$2__1$1x10$lang$Cell$1x10$lang$GlobalCell$$Closure$152$$T$2$2 $dummy) {
            x10.lang.GlobalCell.$Closure$152.$initParams(this, $T);
             {
                ((x10.lang.GlobalCell.$Closure$152<$T>)this).out$$ = out$$;
                ((x10.lang.GlobalCell.$Closure$152<$T>)this).root = ((x10.core.GlobalRef)(root));
            }
        }
        
    }
    
    @x10.runtime.impl.java.X10Generated
    final public static class $Closure$153<$T> extends x10.core.Ref implements x10.core.fun.VoidFun_0_0, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<$Closure$153> $RTT = 
            x10.rtt.StaticVoidFunType.<$Closure$153> make($Closure$153.class,
                                                          1,
                                                          new x10.rtt.Type[] {
                                                              x10.core.fun.VoidFun_0_0.$RTT
                                                          });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { if (i == 0) return $T; return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static <$T> x10.serialization.X10JavaSerializable $_deserialize_body(x10.lang.GlobalCell.$Closure$153<$T> $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            $_obj.$T = (x10.rtt.Type) $deserializer.readObject();
            $_obj.out$$ = $deserializer.readObject();
            $_obj.root = $deserializer.readObject();
            $_obj.x = $deserializer.readObject();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.lang.GlobalCell.$Closure$153 $_obj = new x10.lang.GlobalCell.$Closure$153((java.lang.System[]) null, (x10.rtt.Type) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            $serializer.write(this.$T);
            $serializer.write(this.out$$);
            $serializer.write(this.root);
            $serializer.write(this.x);
            
        }
        
        // constructor just for allocation
        public $Closure$153(final java.lang.System[] $dummy, final x10.rtt.Type $T) {
            x10.lang.GlobalCell.$Closure$153.$initParams(this, $T);
            
        }
        
        private x10.rtt.Type $T;
        
        // initializer of type parameters
        public static void $initParams(final $Closure$153 $this, final x10.rtt.Type $T) {
            $this.$T = $T;
            
        }
        // synthetic type for parameter mangling
        public static final class __0$1x10$lang$GlobalCell$$Closure$153$$T$2__1$1x10$lang$Cell$1x10$lang$GlobalCell$$Closure$153$$T$2$2__2x10$lang$GlobalCell$$Closure$153$$T {}
        
    
        
        public void $apply() {
            
            //#line 43 "x10/lang/GlobalCell.x10"
            try {{
                
                //#line 43 "x10/lang/GlobalCell.x10"
                final x10.core.GlobalRef t$133194 = ((x10.core.GlobalRef)(this.root));
                
                //#line 43 "x10/lang/GlobalCell.x10"
                final x10.lang.Cell t$133195 = (((x10.core.GlobalRef<x10.lang.Cell<$T>>)(t$133194))).$apply$G();
                
                //#line 43 "x10/lang/GlobalCell.x10"
                ((x10.lang.Cell<$T>)t$133195).value = (($T)(this.x));
            }}catch (java.lang.Throwable __lowerer__var__0__) {
                
                //#line 43 "x10/lang/GlobalCell.x10"
                int __lowerer__var__1__ = (x10.core.Int.$unbox(x10.xrx.Runtime.<x10.core.Int> wrapAtChecked$G(x10.rtt.Types.INT, ((java.lang.Throwable)(__lowerer__var__0__)))));
            }
        }
        
        public x10.lang.GlobalCell<$T> out$$;
        public x10.core.GlobalRef<x10.lang.Cell<$T>> root;
        public $T x;
        
        public $Closure$153(final x10.rtt.Type $T, final x10.lang.GlobalCell<$T> out$$, final x10.core.GlobalRef<x10.lang.Cell<$T>> root, final $T x, __0$1x10$lang$GlobalCell$$Closure$153$$T$2__1$1x10$lang$Cell$1x10$lang$GlobalCell$$Closure$153$$T$2$2__2x10$lang$GlobalCell$$Closure$153$$T $dummy) {
            x10.lang.GlobalCell.$Closure$153.$initParams(this, $T);
             {
                ((x10.lang.GlobalCell.$Closure$153<$T>)this).out$$ = out$$;
                ((x10.lang.GlobalCell.$Closure$153<$T>)this).root = ((x10.core.GlobalRef)(root));
                ((x10.lang.GlobalCell.$Closure$153<$T>)this).x = (($T)(x));
            }
        }
        
    }
    
    @x10.runtime.impl.java.X10Generated
    final public static class $Closure$154<$T> extends x10.core.Ref implements x10.core.fun.VoidFun_0_0, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<$Closure$154> $RTT = 
            x10.rtt.StaticVoidFunType.<$Closure$154> make($Closure$154.class,
                                                          1,
                                                          new x10.rtt.Type[] {
                                                              x10.core.fun.VoidFun_0_0.$RTT
                                                          });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { if (i == 0) return $T; return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static <$T> x10.serialization.X10JavaSerializable $_deserialize_body(x10.lang.GlobalCell.$Closure$154<$T> $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            $_obj.$T = (x10.rtt.Type) $deserializer.readObject();
            $_obj.out$$ = $deserializer.readObject();
            $_obj.root = $deserializer.readObject();
            $_obj.x = $deserializer.readObject();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.lang.GlobalCell.$Closure$154 $_obj = new x10.lang.GlobalCell.$Closure$154((java.lang.System[]) null, (x10.rtt.Type) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            $serializer.write(this.$T);
            $serializer.write(this.out$$);
            $serializer.write(this.root);
            $serializer.write(this.x);
            
        }
        
        // constructor just for allocation
        public $Closure$154(final java.lang.System[] $dummy, final x10.rtt.Type $T) {
            x10.lang.GlobalCell.$Closure$154.$initParams(this, $T);
            
        }
        
        private x10.rtt.Type $T;
        
        // initializer of type parameters
        public static void $initParams(final $Closure$154 $this, final x10.rtt.Type $T) {
            $this.$T = $T;
            
        }
        // synthetic type for parameter mangling
        public static final class __0$1x10$lang$GlobalCell$$Closure$154$$T$2__1$1x10$lang$Cell$1x10$lang$GlobalCell$$Closure$154$$T$2$2__2x10$lang$GlobalCell$$Closure$154$$T {}
        
    
        
        public void $apply() {
            
            //#line 54 "x10/lang/GlobalCell.x10"
            try {{
                
                //#line 55 "x10/lang/GlobalCell.x10"
                final x10.core.GlobalRef t$133198 = ((x10.core.GlobalRef)(this.root));
                
                //#line 55 "x10/lang/GlobalCell.x10"
                final x10.lang.Cell t$133199 = (((x10.core.GlobalRef<x10.lang.Cell<$T>>)(t$133198))).$apply$G();
                
                //#line 55 "x10/lang/GlobalCell.x10"
                ((x10.lang.Cell<$T>)t$133199).value = (($T)(this.x));
            }}catch (java.lang.Throwable __lowerer__var__0__) {
                
                //#line 54 "x10/lang/GlobalCell.x10"
                int __lowerer__var__1__ = (x10.core.Int.$unbox(x10.xrx.Runtime.<x10.core.Int> wrapAtChecked$G(x10.rtt.Types.INT, ((java.lang.Throwable)(__lowerer__var__0__)))));
            }
        }
        
        public x10.lang.GlobalCell<$T> out$$;
        public x10.core.GlobalRef<x10.lang.Cell<$T>> root;
        public $T x;
        
        public $Closure$154(final x10.rtt.Type $T, final x10.lang.GlobalCell<$T> out$$, final x10.core.GlobalRef<x10.lang.Cell<$T>> root, final $T x, __0$1x10$lang$GlobalCell$$Closure$154$$T$2__1$1x10$lang$Cell$1x10$lang$GlobalCell$$Closure$154$$T$2$2__2x10$lang$GlobalCell$$Closure$154$$T $dummy) {
            x10.lang.GlobalCell.$Closure$154.$initParams(this, $T);
             {
                ((x10.lang.GlobalCell.$Closure$154<$T>)this).out$$ = out$$;
                ((x10.lang.GlobalCell.$Closure$154<$T>)this).root = ((x10.core.GlobalRef)(root));
                ((x10.lang.GlobalCell.$Closure$154<$T>)this).x = (($T)(x));
            }
        }
        
    }
    
}

