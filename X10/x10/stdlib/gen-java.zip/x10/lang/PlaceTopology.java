package x10.lang;


/**
 * <p> A runtime representation of the topology of Places
 * in a running X10 computation.  A PlaceTopology 
 * captures relationships between the set of live Places.  
 * Depending on the characteristics of the system on which the computation
 * is running, these relationships may include information
 * about the CUDA Places (GPUs) that are attached to a CPU Place
 * or more generally about network topology. </p>
 *
 * <p> A PlaceTopology contains 'primary' Places, which can execute
 * any X10 operation and have full connectivity to all other 
 * primary Places and 'child' Places, which only have connectivity
 * to their 'parent' Place and possibly to their children. A child Place
 * may not be capable of executing all X10 operations; in particular it
 * may be a GPU and only capable of executing the subset of the X10
 * language that can be compiled to CUDA.</p>
 *
 * @see Place
 */
@x10.runtime.impl.java.X10Generated
abstract public class PlaceTopology extends x10.core.Ref implements x10.serialization.X10JavaSerializable
{
    public static final x10.rtt.RuntimeType<PlaceTopology> $RTT = 
        x10.rtt.NamedType.<PlaceTopology> make("x10.lang.PlaceTopology",
                                               PlaceTopology.class);
    
    public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
    
    public x10.rtt.Type<?> $getParam(int i) { return null; }
    
    public static x10.serialization.X10JavaSerializable $_deserialize_body(x10.lang.PlaceTopology $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
        return $_obj;
    }
    
    public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
        return null;
    }
    
    public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
        
    }
    
    // constructor just for allocation
    public PlaceTopology(final java.lang.System[] $dummy) {
        
    }
    
    

    
    
    //#line 39 "x10/lang/PlaceTopology.x10"
    /**
     * Get the topology of the currently live places
     */
    public static x10.lang.PlaceTopology getTopology() {
        
        //#line 40 "x10/lang/PlaceTopology.x10"
        final long ap = ((long)x10.x10rt.X10RT.numPlaces());
        
        //#line 41 "x10/lang/PlaceTopology.x10"
        final long pp = ((long)x10.x10rt.X10RT.numPlaces());
        
        //#line 42 "x10/lang/PlaceTopology.x10"
        final boolean t$135665 = ((long) ap) == ((long) pp);
        
        //#line 42 "x10/lang/PlaceTopology.x10"
        if (t$135665) {
            
            //#line 43 "x10/lang/PlaceTopology.x10"
            final x10.lang.PlaceTopology.FlatPlaceTopology alloc$135651 = ((x10.lang.PlaceTopology.FlatPlaceTopology)(new x10.lang.PlaceTopology.FlatPlaceTopology((java.lang.System[]) null)));
            
            //#line 43 "x10/lang/PlaceTopology.x10"
            alloc$135651.x10$lang$PlaceTopology$FlatPlaceTopology$$init$S(((long)(pp)));
            
            //#line 43 "x10/lang/PlaceTopology.x10"
            return alloc$135651;
        } else {
            
            //#line 45 "x10/lang/PlaceTopology.x10"
            final long cp = ((ap) - (((long)(pp))));
            
            //#line 46 "x10/lang/PlaceTopology.x10"
            assert ((cp) > (((long)(0L))));
            
            //#line 47 "x10/lang/PlaceTopology.x10"
            final x10.lang.PlaceTopology.OneLevelPlaceTopology alloc$135652 = ((x10.lang.PlaceTopology.OneLevelPlaceTopology)(new x10.lang.PlaceTopology.OneLevelPlaceTopology((java.lang.System[]) null)));
            
            //#line 47 "x10/lang/PlaceTopology.x10"
            alloc$135652.x10$lang$PlaceTopology$OneLevelPlaceTopology$$init$S(((long)(pp)), ((long)(cp)));
            
            //#line 47 "x10/lang/PlaceTopology.x10"
            return alloc$135652;
        }
    }
    
    
    //#line 54 "x10/lang/PlaceTopology.x10"
    /**
     * How many primary Places are in the topology?
     */
    abstract public long numPrimaryPlaces$O();
    
    
    //#line 59 "x10/lang/PlaceTopology.x10"
    /**
     * How many non-primary Places are in the topology?
     */
    abstract public long numChildrenPlaces$O();
    
    
    //#line 64 "x10/lang/PlaceTopology.x10"
    /**
     * Is the argument Place a primary Place?
     */
    abstract public boolean isPrimary$O(final x10.lang.Place p);
    
    
    //#line 69 "x10/lang/PlaceTopology.x10"
    /**
     * Is the argument Place mapped to a CUDA device?
     */
    abstract public boolean isCUDA$O(final x10.lang.Place p);
    
    
    //#line 75 "x10/lang/PlaceTopology.x10"
    /**
     * What is the parent of the given Place?
     * A Primary place returns itself as its Parent.
     */
    abstract public x10.lang.Place getParent(final x10.lang.Place p);
    
    
    //#line 80 "x10/lang/PlaceTopology.x10"
    /**
     * How many children does the given Place have?
     */
    abstract public long numChildren$O(final x10.lang.Place p);
    
    
    //#line 85 "x10/lang/PlaceTopology.x10"
    /**
     * Return an Iterator over the children of the given Place.
     */
    abstract public x10.lang.Iterable children(final x10.lang.Place p);
    
    
    //#line 91 "x10/lang/PlaceTopology.x10"
    /**
     * Get the c'th child of Place p. 
     * @throws BadPlaceException if p does not have a c'th child.
     */
    abstract public x10.lang.Place getChild(final x10.lang.Place p, final long c);
    
    
    //#line 97 "x10/lang/PlaceTopology.x10"
    /**
     * Return the childIndex (dual of getChild) of the given Place. 
     * @throws BadPlaceException if given place is not a child.
     */
    abstract public long childIndex$O(final x10.lang.Place c);
    
    
    //#line 108 "x10/lang/PlaceTopology.x10"
    public static long num_all_places$O() {
        try {
            return ((long)x10.x10rt.X10RT.numPlaces());
        }
        catch (java.lang.Throwable exc$206434) {
            throw x10.runtime.impl.java.ThrowableUtils.ensureX10Exception(exc$206434);
        }
        
    }
    
    
    
    //#line 112 "x10/lang/PlaceTopology.x10"
    public static long num_primary_places$O() {
        try {
            return ((long)x10.x10rt.X10RT.numPlaces());
        }
        catch (java.lang.Throwable exc$206435) {
            throw x10.runtime.impl.java.ThrowableUtils.ensureX10Exception(exc$206435);
        }
        
    }
    
    
    
    //#line 120 "x10/lang/PlaceTopology.x10"
    /**
     * Trivial topology where there are only primary places
     * and no information about the network topology is available.
     */
    @x10.runtime.impl.java.X10Generated
    final public static class FlatPlaceTopology extends x10.lang.PlaceTopology implements x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<FlatPlaceTopology> $RTT = 
            x10.rtt.NamedType.<FlatPlaceTopology> make("x10.lang.PlaceTopology.FlatPlaceTopology",
                                                       FlatPlaceTopology.class,
                                                       new x10.rtt.Type[] {
                                                           x10.lang.PlaceTopology.$RTT
                                                       });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static x10.serialization.X10JavaSerializable $_deserialize_body(x10.lang.PlaceTopology.FlatPlaceTopology $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.lang.PlaceTopology.$_deserialize_body($_obj, $deserializer);
            $_obj.numPlaces = $deserializer.readLong();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.lang.PlaceTopology.FlatPlaceTopology $_obj = new x10.lang.PlaceTopology.FlatPlaceTopology((java.lang.System[]) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            super.$_serialize($serializer);
            $serializer.write(this.numPlaces);
            
        }
        
        // constructor just for allocation
        public FlatPlaceTopology(final java.lang.System[] $dummy) {
            super($dummy);
            
        }
        
        
    
        
        //#line 121 "x10/lang/PlaceTopology.x10"
        public long numPlaces;
        
        
        //#line 123 "x10/lang/PlaceTopology.x10"
        // creation method for java code (1-phase java constructor)
        public FlatPlaceTopology(final long np) {
            this((java.lang.System[]) null);
            x10$lang$PlaceTopology$FlatPlaceTopology$$init$S(np);
        }
        
        // constructor for non-virtual call
        final public x10.lang.PlaceTopology.FlatPlaceTopology x10$lang$PlaceTopology$FlatPlaceTopology$$init$S(final long np) {
             {
                
                //#line 123 "x10/lang/PlaceTopology.x10"
                
                
                //#line 124 "x10/lang/PlaceTopology.x10"
                this.numPlaces = np;
            }
            return this;
        }
        
        
        
        //#line 127 "x10/lang/PlaceTopology.x10"
        public long numPrimaryPlaces$O() {
            
            //#line 127 "x10/lang/PlaceTopology.x10"
            final long t$135666 = this.numPlaces;
            
            //#line 127 "x10/lang/PlaceTopology.x10"
            return t$135666;
        }
        
        
        //#line 128 "x10/lang/PlaceTopology.x10"
        public long numChildrenPlaces$O() {
            
            //#line 128 "x10/lang/PlaceTopology.x10"
            return 0L;
        }
        
        
        //#line 129 "x10/lang/PlaceTopology.x10"
        public boolean isPrimary$O(final x10.lang.Place p) {
            
            //#line 129 "x10/lang/PlaceTopology.x10"
            return true;
        }
        
        
        //#line 130 "x10/lang/PlaceTopology.x10"
        public boolean isCUDA$O(final x10.lang.Place p) {
            
            //#line 130 "x10/lang/PlaceTopology.x10"
            return false;
        }
        
        
        //#line 131 "x10/lang/PlaceTopology.x10"
        public x10.lang.Place getParent(final x10.lang.Place p) {
            
            //#line 131 "x10/lang/PlaceTopology.x10"
            return p;
        }
        
        
        //#line 132 "x10/lang/PlaceTopology.x10"
        public long numChildren$O(final x10.lang.Place p) {
            
            //#line 132 "x10/lang/PlaceTopology.x10"
            return 0L;
        }
        
        
        //#line 133 "x10/lang/PlaceTopology.x10"
        public x10.lang.Iterable children(final x10.lang.Place p) {
            
            //#line 134 "x10/lang/PlaceTopology.x10"
            final x10.core.Rail t$135667 = ((x10.core.Rail)(new x10.core.Rail<x10.lang.Place>(x10.lang.Place.$RTT, ((long)(0L)))));
            
            //#line 134 "x10/lang/PlaceTopology.x10"
            return t$135667;
        }
        
        
        //#line 136 "x10/lang/PlaceTopology.x10"
        public x10.lang.Place getChild(final x10.lang.Place p, final long c) {
            
            //#line 137 "x10/lang/PlaceTopology.x10"
            final java.lang.String t$135668 = ((p) + (" has no children"));
            
            //#line 137 "x10/lang/PlaceTopology.x10"
            final x10.lang.BadPlaceException t$135669 = ((x10.lang.BadPlaceException)(new x10.lang.BadPlaceException(t$135668)));
            
            //#line 137 "x10/lang/PlaceTopology.x10"
            throw t$135669;
        }
        
        
        //#line 139 "x10/lang/PlaceTopology.x10"
        public long childIndex$O(final x10.lang.Place c) {
            
            //#line 140 "x10/lang/PlaceTopology.x10"
            final java.lang.String t$135670 = ((c) + (" is not a child Place"));
            
            //#line 140 "x10/lang/PlaceTopology.x10"
            final x10.lang.BadPlaceException t$135671 = ((x10.lang.BadPlaceException)(new x10.lang.BadPlaceException(t$135670)));
            
            //#line 140 "x10/lang/PlaceTopology.x10"
            throw t$135671;
        }
        
        
        //#line 120 "x10/lang/PlaceTopology.x10"
        final public x10.lang.PlaceTopology.FlatPlaceTopology x10$lang$PlaceTopology$FlatPlaceTopology$$this$x10$lang$PlaceTopology$FlatPlaceTopology() {
            
            //#line 120 "x10/lang/PlaceTopology.x10"
            return x10.lang.PlaceTopology.FlatPlaceTopology.this;
        }
        
        
        //#line 120 "x10/lang/PlaceTopology.x10"
        final public void __fieldInitializers_x10_lang_PlaceTopology_FlatPlaceTopology() {
            
        }
    }
    
    
    //#line 148 "x10/lang/PlaceTopology.x10"
    /**
     * Simple topology for primary nodes with attached CUDA devices
     * and no information about the network topology is available.
     */
    @x10.runtime.impl.java.X10Generated
    public static class OneLevelPlaceTopology extends x10.lang.PlaceTopology implements x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<OneLevelPlaceTopology> $RTT = 
            x10.rtt.NamedType.<OneLevelPlaceTopology> make("x10.lang.PlaceTopology.OneLevelPlaceTopology",
                                                           OneLevelPlaceTopology.class,
                                                           new x10.rtt.Type[] {
                                                               x10.lang.PlaceTopology.$RTT
                                                           });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static x10.serialization.X10JavaSerializable $_deserialize_body(x10.lang.PlaceTopology.OneLevelPlaceTopology $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.lang.PlaceTopology.$_deserialize_body($_obj, $deserializer);
            $_obj.numChild = $deserializer.readLong();
            $_obj.numPrimary = $deserializer.readLong();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.lang.PlaceTopology.OneLevelPlaceTopology $_obj = new x10.lang.PlaceTopology.OneLevelPlaceTopology((java.lang.System[]) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            super.$_serialize($serializer);
            $serializer.write(this.numChild);
            $serializer.write(this.numPrimary);
            
        }
        
        // constructor just for allocation
        public OneLevelPlaceTopology(final java.lang.System[] $dummy) {
            super($dummy);
            
        }
        
        
    
        
        //#line 149 "x10/lang/PlaceTopology.x10"
        public long numPrimary;
        
        //#line 150 "x10/lang/PlaceTopology.x10"
        public long numChild;
        
        
        //#line 152 "x10/lang/PlaceTopology.x10"
        // creation method for java code (1-phase java constructor)
        public OneLevelPlaceTopology(final long np, final long nc) {
            this((java.lang.System[]) null);
            x10$lang$PlaceTopology$OneLevelPlaceTopology$$init$S(np, nc);
        }
        
        // constructor for non-virtual call
        final public x10.lang.PlaceTopology.OneLevelPlaceTopology x10$lang$PlaceTopology$OneLevelPlaceTopology$$init$S(final long np, final long nc) {
             {
                
                //#line 152 "x10/lang/PlaceTopology.x10"
                
                
                //#line 153 "x10/lang/PlaceTopology.x10"
                this.numPrimary = np;
                
                //#line 154 "x10/lang/PlaceTopology.x10"
                this.numChild = nc;
            }
            return this;
        }
        
        
        
        //#line 157 "x10/lang/PlaceTopology.x10"
        public long numPrimaryPlaces$O() {
            
            //#line 157 "x10/lang/PlaceTopology.x10"
            final long t$135672 = this.numPrimary;
            
            //#line 157 "x10/lang/PlaceTopology.x10"
            return t$135672;
        }
        
        
        //#line 158 "x10/lang/PlaceTopology.x10"
        public long numChildrenPlaces$O() {
            
            //#line 158 "x10/lang/PlaceTopology.x10"
            final long t$135673 = this.numChild;
            
            //#line 158 "x10/lang/PlaceTopology.x10"
            return t$135673;
        }
        
        
        //#line 160 "x10/lang/PlaceTopology.x10"
        public boolean isPrimary$O(final x10.lang.Place p) {
            
            //#line 161 "x10/lang/PlaceTopology.x10"
            return true;
        }
        
        
        //#line 163 "x10/lang/PlaceTopology.x10"
        public boolean isCUDA$O(final x10.lang.Place p) {
            
            //#line 164 "x10/lang/PlaceTopology.x10"
            return false;
        }
        
        
        //#line 166 "x10/lang/PlaceTopology.x10"
        public x10.lang.Place getParent(final x10.lang.Place p) {
            
            //#line 167 "x10/lang/PlaceTopology.x10"
            return p;
        }
        
        
        //#line 169 "x10/lang/PlaceTopology.x10"
        public long numChildren$O(final x10.lang.Place p) {
            
            //#line 170 "x10/lang/PlaceTopology.x10"
            return 0L;
        }
        
        
        //#line 172 "x10/lang/PlaceTopology.x10"
        public x10.lang.Iterable children(final x10.lang.Place p) {
            
            //#line 173 "x10/lang/PlaceTopology.x10"
            final long t$135675 = this.numChildren$O(((x10.lang.Place)(p)));
            
            //#line 173 "x10/lang/PlaceTopology.x10"
            final x10.core.fun.Fun_0_1 t$135676 = ((x10.core.fun.Fun_0_1)(new x10.lang.PlaceTopology.OneLevelPlaceTopology.$Closure$182(this, p)));
            
            //#line 173 "x10/lang/PlaceTopology.x10"
            final x10.core.Rail t$135677 = ((x10.core.Rail)(new x10.core.Rail<x10.lang.Place>(x10.lang.Place.$RTT, t$135675, ((x10.core.fun.Fun_0_1)(t$135676)), (x10.core.Rail.__1$1x10$lang$Long$3x10$lang$Rail$$T$2) null)));
            
            //#line 173 "x10/lang/PlaceTopology.x10"
            return t$135677;
        }
        
        
        //#line 176 "x10/lang/PlaceTopology.x10"
        public x10.lang.Place getChild(final x10.lang.Place p, final long c) {
            
            //#line 178 "x10/lang/PlaceTopology.x10"
            final java.lang.String t$135678 = ((p) + (" has no children"));
            
            //#line 178 "x10/lang/PlaceTopology.x10"
            final x10.lang.BadPlaceException t$135679 = ((x10.lang.BadPlaceException)(new x10.lang.BadPlaceException(t$135678)));
            
            //#line 178 "x10/lang/PlaceTopology.x10"
            throw t$135679;
        }
        
        
        //#line 181 "x10/lang/PlaceTopology.x10"
        public long childIndex$O(final x10.lang.Place c) {
            
            //#line 183 "x10/lang/PlaceTopology.x10"
            final java.lang.String t$135680 = ((c) + (" is not a child Place"));
            
            //#line 183 "x10/lang/PlaceTopology.x10"
            final x10.lang.BadPlaceException t$135681 = ((x10.lang.BadPlaceException)(new x10.lang.BadPlaceException(t$135680)));
            
            //#line 183 "x10/lang/PlaceTopology.x10"
            throw t$135681;
        }
        
        
        //#line 148 "x10/lang/PlaceTopology.x10"
        final public x10.lang.PlaceTopology.OneLevelPlaceTopology x10$lang$PlaceTopology$OneLevelPlaceTopology$$this$x10$lang$PlaceTopology$OneLevelPlaceTopology() {
            
            //#line 148 "x10/lang/PlaceTopology.x10"
            return x10.lang.PlaceTopology.OneLevelPlaceTopology.this;
        }
        
        
        //#line 148 "x10/lang/PlaceTopology.x10"
        final public void __fieldInitializers_x10_lang_PlaceTopology_OneLevelPlaceTopology() {
            
        }
        
        @x10.runtime.impl.java.X10Generated
        final public static class $Closure$182 extends x10.core.Ref implements x10.core.fun.Fun_0_1, x10.serialization.X10JavaSerializable
        {
            public static final x10.rtt.RuntimeType<$Closure$182> $RTT = 
                x10.rtt.StaticFunType.<$Closure$182> make($Closure$182.class,
                                                          new x10.rtt.Type[] {
                                                              x10.rtt.ParameterizedType.make(x10.core.fun.Fun_0_1.$RTT, x10.rtt.Types.LONG, x10.lang.Place.$RTT)
                                                          });
            
            public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
            
            public x10.rtt.Type<?> $getParam(int i) { return null; }
            
            private Object writeReplace() throws java.io.ObjectStreamException {
                return new x10.serialization.SerializationProxy(this);
            }
            
            public static x10.serialization.X10JavaSerializable $_deserialize_body(x10.lang.PlaceTopology.OneLevelPlaceTopology.$Closure$182 $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
                $_obj.out$$ = $deserializer.readObject();
                $_obj.p = $deserializer.readObject();
                return $_obj;
            }
            
            public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
                x10.lang.PlaceTopology.OneLevelPlaceTopology.$Closure$182 $_obj = new x10.lang.PlaceTopology.OneLevelPlaceTopology.$Closure$182((java.lang.System[]) null);
                $deserializer.record_reference($_obj);
                return $_deserialize_body($_obj, $deserializer);
            }
            
            public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
                $serializer.write(this.out$$);
                $serializer.write(this.p);
                
            }
            
            // constructor just for allocation
            public $Closure$182(final java.lang.System[] $dummy) {
                
            }
            
            // dispatcher for method abstract public (Z1)=>U.operator()(a1:Z1):U
            public java.lang.Object $apply(final java.lang.Object a1, final x10.rtt.Type t1) {
                return $apply(x10.core.Long.$unbox(a1));
                
            }
            
            
        
            
            public x10.lang.Place $apply(final long i) {
                
                //#line 173 "x10/lang/PlaceTopology.x10"
                final x10.lang.Place t$135674 = this.out$$.getChild(((x10.lang.Place)(this.p)), (long)(i));
                
                //#line 173 "x10/lang/PlaceTopology.x10"
                return t$135674;
            }
            
            public x10.lang.PlaceTopology.OneLevelPlaceTopology out$$;
            public x10.lang.Place p;
            
            public $Closure$182(final x10.lang.PlaceTopology.OneLevelPlaceTopology out$$, final x10.lang.Place p) {
                 {
                    this.out$$ = out$$;
                    this.p = ((x10.lang.Place)(p));
                }
            }
            
        }
        
    }
    
    
    
    //#line 35 "x10/lang/PlaceTopology.x10"
    final public x10.lang.PlaceTopology x10$lang$PlaceTopology$$this$x10$lang$PlaceTopology() {
        
        //#line 35 "x10/lang/PlaceTopology.x10"
        return x10.lang.PlaceTopology.this;
    }
    
    
    //#line 35 "x10/lang/PlaceTopology.x10"
    
    // constructor for non-virtual call
    final public x10.lang.PlaceTopology x10$lang$PlaceTopology$$init$S() {
         {
            
            //#line 35 "x10/lang/PlaceTopology.x10"
            
        }
        return this;
    }
    
    
    
    //#line 35 "x10/lang/PlaceTopology.x10"
    final public void __fieldInitializers_x10_lang_PlaceTopology() {
        
    }
}

