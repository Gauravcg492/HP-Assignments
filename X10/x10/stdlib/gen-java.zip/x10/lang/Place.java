package x10.lang;


/**
 * Representation of a Place within the APGAS model.
 */
@x10.runtime.impl.java.X10Generated
final public class Place extends x10.core.Struct implements x10.serialization.X10JavaSerializable
{
    public static final x10.rtt.RuntimeType<Place> $RTT = 
        x10.rtt.NamedStructType.<Place> make("x10.lang.Place",
                                             Place.class,
                                             new x10.rtt.Type[] {
                                                 x10.rtt.Types.STRUCT
                                             });
    
    public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
    
    public x10.rtt.Type<?> $getParam(int i) { return null; }
    
    private Object writeReplace() throws java.io.ObjectStreamException {
        return new x10.serialization.SerializationProxy(this);
    }
    
    public static x10.serialization.X10JavaSerializable $_deserialize_body(x10.lang.Place $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
        $_obj.id = $deserializer.readLong();
        return $_obj;
    }
    
    public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
        x10.lang.Place $_obj = new x10.lang.Place((java.lang.System[]) null);
        return $_deserialize_body($_obj, $deserializer);
    }
    
    public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
        $serializer.write(this.id);
        
    }
    
    // zero value constructor
    public Place(final java.lang.System $dummy) { this.id = 0L; }
    
    // constructor just for allocation
    public Place(final java.lang.System[] $dummy) {
        
    }
    
    
    // properties
    
    //#line 30 "x10/lang/Place.x10"
    public long id;
    

    
    
    //#line 31 "x10/lang/Place.x10"
    final public long id$O() {
        
        //#line 31 "x10/lang/Place.x10"
        final long t$135157 = this.id;
        
        //#line 31 "x10/lang/Place.x10"
        return t$135157;
    }
    
    
    //#line 36 "x10/lang/Place.x10"
    private static x10.lang.Place FIRST_PLACE;
    
    //#line 41 "x10/lang/Place.x10"
    private static x10.lang.Place INVALID_PLACE;
    
    
    //#line 47 "x10/lang/Place.x10"
    /**
     * The number of primary places (does not include accelerators).
     * Invariant: Place.numPlaces() == Place.places().numPlaces().
     */
    final public static long numPlaces$O() {
        try {
            return ((long)x10.x10rt.X10RT.numPlaces());
        }
        catch (java.lang.Throwable exc$206427) {
            throw x10.runtime.impl.java.ThrowableUtils.ensureX10Exception(exc$206427);
        }
        
    }
    
    
    
    //#line 54 "x10/lang/Place.x10"
    /** 
     * The total number of all kinds of places (both primary and children/accelerators).
     */
    final public static long numAllPlaces$O() {
        try {
            return ((long)x10.x10rt.X10RT.numPlaces());
        }
        catch (java.lang.Throwable exc$206428) {
            throw x10.runtime.impl.java.ThrowableUtils.ensureX10Exception(exc$206428);
        }
        
    }
    
    
    
    //#line 62 "x10/lang/Place.x10"
    /** 
     * The number of primary places known to be dead by the 
     * current place, does not include accelerators. 
     */
    final public static long numDead$O() {
        try {
            return ((long)x10.x10rt.X10RT.numDead());
        }
        catch (java.lang.Throwable exc$206429) {
            throw x10.runtime.impl.java.ThrowableUtils.ensureX10Exception(exc$206429);
        }
        
    }
    
    
    
    //#line 69 "x10/lang/Place.x10"
    /**
     * Returns whether a place is dead.
     */
    final public static boolean isDead$O(final long id) {
        try {
            return x10.x10rt.X10RT.isPlaceDead((int)id);
        }
        catch (java.lang.Throwable exc$206430) {
            throw x10.runtime.impl.java.ThrowableUtils.ensureX10Exception(exc$206430);
        }
        
    }
    
    
    
    //#line 76 "x10/lang/Place.x10"
    /**
     * A PlaceGroup the contains all the currently live primary Places.
     */
    final public static x10.lang.PlaceGroup places() {
        
        //#line 77 "x10/lang/Place.x10"
        final long nd = ((long)x10.x10rt.X10RT.numDead());
        
        //#line 78 "x10/lang/Place.x10"
        final boolean t$135185 = ((long) nd) == ((long) 0L);
        
        //#line 78 "x10/lang/Place.x10"
        if (t$135185) {
            
            //#line 79 "x10/lang/Place.x10"
            final x10.lang.PlaceGroup.SimplePlaceGroup alloc$106499 = ((x10.lang.PlaceGroup.SimplePlaceGroup)(new x10.lang.PlaceGroup.SimplePlaceGroup((java.lang.System[]) null)));
            
            //#line 79 "x10/lang/Place.x10"
            final long t$135219 = ((long)x10.x10rt.X10RT.numPlaces());
            
            //#line 79 "x10/lang/Place.x10"
            alloc$106499.x10$lang$PlaceGroup$SimplePlaceGroup$$init$S(t$135219);
            
            //#line 79 "x10/lang/Place.x10"
            return alloc$106499;
        } else {
            
            //#line 81 "x10/lang/Place.x10"
            final long np = ((long)x10.x10rt.X10RT.numPlaces());
            
            //#line 82 "x10/lang/Place.x10"
            try {{
                
                //#line 83 "x10/lang/Place.x10"
                final x10.lang.Place.PlaceGroupCache t$135159 = ((x10.lang.Place.PlaceGroupCache)(x10.lang.Place.get$CUR_WORLD()));
                
                //#line 83 "x10/lang/Place.x10"
                final x10.util.concurrent.Lock t$135160 = ((x10.util.concurrent.Lock)(t$135159.lock));
                
                //#line 83 "x10/lang/Place.x10"
                t$135160.lock();
                
                //#line 84 "x10/lang/Place.x10"
                final x10.lang.Place.PlaceGroupCache t$135161 = ((x10.lang.Place.PlaceGroupCache)(x10.lang.Place.get$CUR_WORLD()));
                
                //#line 84 "x10/lang/Place.x10"
                final long t$135162 = t$135161.numPlaces;
                
                //#line 84 "x10/lang/Place.x10"
                boolean t$135165 = ((long) t$135162) == ((long) np);
                
                //#line 84 "x10/lang/Place.x10"
                if (t$135165) {
                    
                    //#line 84 "x10/lang/Place.x10"
                    final x10.lang.Place.PlaceGroupCache t$135163 = ((x10.lang.Place.PlaceGroupCache)(x10.lang.Place.get$CUR_WORLD()));
                    
                    //#line 84 "x10/lang/Place.x10"
                    final long t$135164 = t$135163.numDead;
                    
                    //#line 84 "x10/lang/Place.x10"
                    t$135165 = ((long) t$135164) == ((long) nd);
                }
                
                //#line 84 "x10/lang/Place.x10"
                if (t$135165) {
                    
                    //#line 86 "x10/lang/Place.x10"
                    final x10.lang.Place.PlaceGroupCache t$135166 = ((x10.lang.Place.PlaceGroupCache)(x10.lang.Place.get$CUR_WORLD()));
                    
                    //#line 86 "x10/lang/Place.x10"
                    final x10.lang.PlaceGroup world = ((x10.lang.PlaceGroup)(t$135166.world));
                    
                    //#line 87 "x10/lang/Place.x10"
                    return world;
                } else {
                    
                    //#line 92 "x10/lang/Place.x10"
                    final x10.util.GrowableRail live = ((x10.util.GrowableRail)(new x10.util.GrowableRail<x10.lang.Place>((java.lang.System[]) null, x10.lang.Place.$RTT)));
                    
                    //#line 92 "x10/lang/Place.x10"
                    live.x10$util$GrowableRail$$init$S(((long)(np)));
                    
                    //#line 93 "x10/lang/Place.x10"
                    long seenDead = 0L;
                    
                    //#line 94 "x10/lang/Place.x10"
                    final long i$106501max$135231 = ((np) - (((long)(1L))));
                    
                    //#line 94 "x10/lang/Place.x10"
                    long i$135228 = 0L;
                    
                    //#line 94 "x10/lang/Place.x10"
                    for (;
                         true;
                         ) {
                        
                        //#line 94 "x10/lang/Place.x10"
                        final boolean t$135230 = ((i$135228) <= (((long)(i$106501max$135231))));
                        
                        //#line 94 "x10/lang/Place.x10"
                        if (!(t$135230)) {
                            
                            //#line 94 "x10/lang/Place.x10"
                            break;
                        }
                        
                        //#line 95 "x10/lang/Place.x10"
                        final x10.lang.Place p$135220 = ((x10.lang.Place)(new x10.lang.Place((java.lang.System[]) null)));
                        
                        //#line 95 "x10/lang/Place.x10"
                        p$135220.x10$lang$Place$$init$S(i$135228);
                        
                        //#line 128 . "x10/lang/Place.x10"
                        final long t$135221 = p$135220.id;
                        
                        //#line 128 . "x10/lang/Place.x10"
                        final boolean t$135222 = x10.x10rt.X10RT.isPlaceDead((int)((long)(t$135221)));
                        
                        //#line 96 "x10/lang/Place.x10"
                        if (t$135222) {
                            
                            //#line 97 "x10/lang/Place.x10"
                            final long t$135224 = ((seenDead) + (((long)(1L))));
                            
                            //#line 97 "x10/lang/Place.x10"
                            seenDead = t$135224;
                        } else {
                            
                            //#line 99 "x10/lang/Place.x10"
                            ((x10.util.GrowableRail<x10.lang.Place>)live).add__0x10$util$GrowableRail$$T(((x10.lang.Place)(p$135220)));
                        }
                        
                        //#line 94 "x10/lang/Place.x10"
                        final long t$135227 = ((i$135228) + (((long)(1L))));
                        
                        //#line 94 "x10/lang/Place.x10"
                        i$135228 = t$135227;
                    }
                    
                    //#line 102 "x10/lang/Place.x10"
                    final x10.lang.SparsePlaceGroup res = ((x10.lang.SparsePlaceGroup)(new x10.lang.SparsePlaceGroup((java.lang.System[]) null)));
                    
                    //#line 102 "x10/lang/Place.x10"
                    final x10.core.Rail t$135232 = ((x10.core.Rail<x10.lang.Place>)
                                                     ((x10.util.GrowableRail<x10.lang.Place>)live).toRail());
                    
                    //#line 102 "x10/lang/Place.x10"
                    res.x10$lang$SparsePlaceGroup$$init$S(t$135232, (x10.lang.SparsePlaceGroup.__0$1x10$lang$Place$2) null);
                    
                    //#line 103 "x10/lang/Place.x10"
                    final boolean t$135181 = ((long) seenDead) == ((long) nd);
                    
                    //#line 103 "x10/lang/Place.x10"
                    if (t$135181) {
                        
                        //#line 105 "x10/lang/Place.x10"
                        final x10.lang.Place.PlaceGroupCache t$135178 = ((x10.lang.Place.PlaceGroupCache)(x10.lang.Place.get$CUR_WORLD()));
                        
                        //#line 105 "x10/lang/Place.x10"
                        t$135178.numPlaces = np;
                        
                        //#line 106 "x10/lang/Place.x10"
                        final x10.lang.Place.PlaceGroupCache t$135179 = ((x10.lang.Place.PlaceGroupCache)(x10.lang.Place.get$CUR_WORLD()));
                        
                        //#line 106 "x10/lang/Place.x10"
                        t$135179.numDead = nd;
                        
                        //#line 107 "x10/lang/Place.x10"
                        final x10.lang.Place.PlaceGroupCache t$135180 = ((x10.lang.Place.PlaceGroupCache)(x10.lang.Place.get$CUR_WORLD()));
                        
                        //#line 107 "x10/lang/Place.x10"
                        t$135180.world = ((x10.lang.PlaceGroup)(res));
                    }
                    
                    //#line 109 "x10/lang/Place.x10"
                    return res;
                }
            }}finally {{
                  
                  //#line 112 "x10/lang/Place.x10"
                  final x10.lang.Place.PlaceGroupCache t$135183 = ((x10.lang.Place.PlaceGroupCache)(x10.lang.Place.get$CUR_WORLD()));
                  
                  //#line 112 "x10/lang/Place.x10"
                  final x10.util.concurrent.Lock t$135184 = ((x10.util.concurrent.Lock)(t$135183.lock));
                  
                  //#line 112 "x10/lang/Place.x10"
                  t$135184.unlock();
              }}
            }
        }
    
    
    //#line 120 "x10/lang/Place.x10"
    /**
     * Creates a Place struct from a place id.
     */
    // creation method for java code (1-phase java constructor)
    public Place(final long id) {
        this((java.lang.System[]) null);
        x10$lang$Place$$init$S(id);
    }
    
    // constructor for non-virtual call
    final public x10.lang.Place x10$lang$Place$$init$S(final long id) {
         {
            
            //#line 121 "x10/lang/Place.x10"
            this.id = id;
            
            
            //#line 122 "x10/lang/Place.x10"
            boolean t$135187 = ((id) < (((long)(-1L))));
            
            //#line 122 "x10/lang/Place.x10"
            if (!(t$135187)) {
                
                //#line 122 "x10/lang/Place.x10"
                final long t$135186 = ((long)x10.x10rt.X10RT.numPlaces());
                
                //#line 122 "x10/lang/Place.x10"
                t$135187 = ((id) >= (((long)(t$135186))));
            }
            
            //#line 122 "x10/lang/Place.x10"
            if (t$135187) {
                
                //#line 123 "x10/lang/Place.x10"
                final java.lang.String t$135188 = (((x10.core.Long.$box(id))) + (" is not a valid Place id"));
                
                //#line 123 "x10/lang/Place.x10"
                final java.lang.IllegalArgumentException t$135189 = ((java.lang.IllegalArgumentException)(new java.lang.IllegalArgumentException(t$135188)));
                
                //#line 123 "x10/lang/Place.x10"
                throw t$135189;
            }
        }
        return this;
    }
    
    
    
    //#line 128 "x10/lang/Place.x10"
    /** Is this place dead? */
    final public boolean isDead$O() {
        
        //#line 128 "x10/lang/Place.x10"
        final long t$135191 = this.id;
        
        //#line 128 "x10/lang/Place.x10"
        final boolean t$135192 = x10.x10rt.X10RT.isPlaceDead((int)((long)(t$135191)));
        
        //#line 128 "x10/lang/Place.x10"
        return t$135192;
    }
    
    
    //#line 131 "x10/lang/Place.x10"
    final public boolean isCUDA$O() {
        
        //#line 132 "x10/lang/Place.x10"
        return false;
    }
    
    
    //#line 135 "x10/lang/Place.x10"
    final public x10.lang.Place parent() {
        
        //#line 136 "x10/lang/Place.x10"
        return this;
    }
    
    
    //#line 138 "x10/lang/Place.x10"
    final public java.lang.String toString() {
        
        //#line 138 "x10/lang/Place.x10"
        final long t$135193 = this.id;
        
        //#line 138 "x10/lang/Place.x10"
        final java.lang.String t$135194 = (("Place(") + ((x10.core.Long.$box(t$135193))));
        
        //#line 138 "x10/lang/Place.x10"
        final java.lang.String t$135195 = ((t$135194) + (")"));
        
        //#line 138 "x10/lang/Place.x10"
        return t$135195;
    }
    
    
    //#line 139 "x10/lang/Place.x10"
    final public boolean equals$O(final x10.lang.Place p) {
        
        //#line 139 "x10/lang/Place.x10"
        final long t$135196 = p.id;
        
        //#line 139 "x10/lang/Place.x10"
        final long t$135197 = this.id;
        
        //#line 139 "x10/lang/Place.x10"
        final boolean t$135198 = ((long) t$135196) == ((long) t$135197);
        
        //#line 139 "x10/lang/Place.x10"
        return t$135198;
    }
    
    
    //#line 140 "x10/lang/Place.x10"
    final public boolean equals(final java.lang.Object p) {
        
        //#line 140 "x10/lang/Place.x10"
        boolean t$135202 = x10.lang.Place.$RTT.isInstance(p);
        
        //#line 140 "x10/lang/Place.x10"
        if (t$135202) {
            
            //#line 140 "x10/lang/Place.x10"
            final x10.lang.Place t$135199 = ((x10.lang.Place)(((x10.lang.Place)x10.rtt.Types.asStruct(x10.lang.Place.$RTT,p))));
            
            //#line 140 "x10/lang/Place.x10"
            final long t$135200 = t$135199.id;
            
            //#line 140 "x10/lang/Place.x10"
            final long t$135201 = this.id;
            
            //#line 140 "x10/lang/Place.x10"
            t$135202 = ((long) t$135200) == ((long) t$135201);
        }
        
        //#line 140 "x10/lang/Place.x10"
        return t$135202;
    }
    
    
    //#line 141 "x10/lang/Place.x10"
    final public int hashCode() {
        
        //#line 141 "x10/lang/Place.x10"
        final long t$135204 = this.id;
        
        //#line 141 "x10/lang/Place.x10"
        final int t$135205 = ((int)(long)(((long)(t$135204))));
        
        //#line 141 "x10/lang/Place.x10"
        return t$135205;
    }
    
    
    //#line 147 "x10/lang/Place.x10"
    /**
     * Converts a GlobalRef to its home.
     */
    final public static <$T>x10.lang.Place $implicit_convert__0$1x10$lang$Place$$T$2(final x10.rtt.Type $T, final x10.core.GlobalRef<$T> r) {
        try {
            return (r).home;
        }
        catch (java.lang.Throwable exc$206431) {
            throw x10.runtime.impl.java.ThrowableUtils.ensureX10Exception(exc$206431);
        }
        
    }
    
    
    
    //#line 152 "x10/lang/Place.x10"
    private static x10.lang.Place.PlaceGroupCache CUR_WORLD;
    
    //#line 154 "x10/lang/Place.x10"
    @x10.runtime.impl.java.X10Generated
    public static class PlaceGroupCache extends x10.core.Ref implements x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<PlaceGroupCache> $RTT = 
            x10.rtt.NamedType.<PlaceGroupCache> make("x10.lang.Place.PlaceGroupCache",
                                                     PlaceGroupCache.class);
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static x10.serialization.X10JavaSerializable $_deserialize_body(x10.lang.Place.PlaceGroupCache $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            $_obj.lock = $deserializer.readObject();
            $_obj.numDead = $deserializer.readLong();
            $_obj.numPlaces = $deserializer.readLong();
            $_obj.world = $deserializer.readObject();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.lang.Place.PlaceGroupCache $_obj = new x10.lang.Place.PlaceGroupCache((java.lang.System[]) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            $serializer.write(this.lock);
            $serializer.write(this.numDead);
            $serializer.write(this.numPlaces);
            $serializer.write(this.world);
            
        }
        
        // constructor just for allocation
        public PlaceGroupCache(final java.lang.System[] $dummy) {
            
        }
        
        
    
        
        //#line 155 "x10/lang/Place.x10"
        public long numPlaces;
        
        //#line 156 "x10/lang/Place.x10"
        public long numDead;
        
        //#line 157 "x10/lang/Place.x10"
        public x10.lang.PlaceGroup world;
        
        //#line 158 "x10/lang/Place.x10"
        public x10.util.concurrent.Lock lock;
        
        
        //#line 160 "x10/lang/Place.x10"
        // creation method for java code (1-phase java constructor)
        public PlaceGroupCache(final long np, final long nd, final x10.lang.PlaceGroup w) {
            this((java.lang.System[]) null);
            x10$lang$Place$PlaceGroupCache$$init$S(np, nd, w);
        }
        
        // constructor for non-virtual call
        final public x10.lang.Place.PlaceGroupCache x10$lang$Place$PlaceGroupCache$$init$S(final long np, final long nd, final x10.lang.PlaceGroup w) {
             {
                
                //#line 160 "x10/lang/Place.x10"
                
                
                //#line 154 "x10/lang/Place.x10"
                final x10.lang.Place.PlaceGroupCache this$135234 = this;
                
                //#line 154 "x10/lang/Place.x10"
                this$135234.numPlaces = 0L;
                
                //#line 154 "x10/lang/Place.x10"
                this$135234.numDead = 0L;
                
                //#line 161 "x10/lang/Place.x10"
                this.numPlaces = np;
                
                //#line 162 "x10/lang/Place.x10"
                this.numDead = nd;
                
                //#line 163 "x10/lang/Place.x10"
                this.world = ((x10.lang.PlaceGroup)(w));
                
                //#line 164 "x10/lang/Place.x10"
                final x10.util.concurrent.Lock t$135206 = ((x10.util.concurrent.Lock)(new x10.util.concurrent.Lock()));
                
                //#line 164 "x10/lang/Place.x10"
                this.lock = ((x10.util.concurrent.Lock)(t$135206));
            }
            return this;
        }
        
        
        
        //#line 154 "x10/lang/Place.x10"
        final public x10.lang.Place.PlaceGroupCache x10$lang$Place$PlaceGroupCache$$this$x10$lang$Place$PlaceGroupCache() {
            
            //#line 154 "x10/lang/Place.x10"
            return x10.lang.Place.PlaceGroupCache.this;
        }
        
        
        //#line 154 "x10/lang/Place.x10"
        final public void __fieldInitializers_x10_lang_Place_PlaceGroupCache() {
            
            //#line 154 "x10/lang/Place.x10"
            this.numPlaces = 0L;
            
            //#line 154 "x10/lang/Place.x10"
            this.numDead = 0L;
        }
    }
    
    
    
    //#line 30 "x10/lang/Place.x10"
    final public java.lang.String typeName() {
        try {
            return x10.rtt.Types.typeName(this);
        }
        catch (java.lang.Throwable exc$206432) {
            throw x10.runtime.impl.java.ThrowableUtils.ensureX10Exception(exc$206432);
        }
        
    }
    
    
    
    //#line 30 "x10/lang/Place.x10"
    final public boolean _struct_equals$O(java.lang.Object other) {
        
        //#line 30 "x10/lang/Place.x10"
        final boolean t$135208 = x10.lang.Place.$RTT.isInstance(other);
        
        //#line 30 "x10/lang/Place.x10"
        final boolean t$135209 = !(t$135208);
        
        //#line 30 "x10/lang/Place.x10"
        if (t$135209) {
            
            //#line 30 "x10/lang/Place.x10"
            return false;
        }
        
        //#line 30 "x10/lang/Place.x10"
        final x10.lang.Place this$135155 = ((x10.lang.Place)(this));
        
        //#line 30 "x10/lang/Place.x10"
        x10.lang.Place other$135154 = ((x10.lang.Place)(((x10.lang.Place)x10.rtt.Types.asStruct(x10.lang.Place.$RTT,other))));
        
        //#line 30 "x10/lang/Place.x10"
        final long t$135212 = this$135155.id;
        
        //#line 30 "x10/lang/Place.x10"
        final long t$135213 = other$135154.id;
        
        //#line 30 "x10/lang/Place.x10"
        final boolean t$135214 = ((long) t$135212) == ((long) t$135213);
        
        //#line 30 "x10/lang/Place.x10"
        return t$135214;
    }
    
    
    //#line 30 "x10/lang/Place.x10"
    final public boolean _struct_equals$O(x10.lang.Place other) {
        
        //#line 30 "x10/lang/Place.x10"
        final long t$135216 = this.id;
        
        //#line 30 "x10/lang/Place.x10"
        final long t$135217 = other.id;
        
        //#line 30 "x10/lang/Place.x10"
        final boolean t$135218 = ((long) t$135216) == ((long) t$135217);
        
        //#line 30 "x10/lang/Place.x10"
        return t$135218;
    }
    
    
    //#line 20 "x10/lang/Place.x10"
    final public x10.lang.Place x10$lang$Place$$this$x10$lang$Place() {
        
        //#line 20 "x10/lang/Place.x10"
        return x10.lang.Place.this;
    }
    
    
    //#line 20 "x10/lang/Place.x10"
    final public void __fieldInitializers_x10_lang_Place() {
        
    }
    
    final private static x10.core.concurrent.AtomicInteger initStatus$CUR_WORLD = new x10.core.concurrent.AtomicInteger(x10.runtime.impl.java.InitDispatcher.UNINITIALIZED);
    private static x10.lang.ExceptionInInitializer exception$CUR_WORLD;
    final private static x10.core.concurrent.AtomicInteger initStatus$INVALID_PLACE = new x10.core.concurrent.AtomicInteger(x10.runtime.impl.java.InitDispatcher.UNINITIALIZED);
    private static x10.lang.ExceptionInInitializer exception$INVALID_PLACE;
    final private static x10.core.concurrent.AtomicInteger initStatus$FIRST_PLACE = new x10.core.concurrent.AtomicInteger(x10.runtime.impl.java.InitDispatcher.UNINITIALIZED);
    private static x10.lang.ExceptionInInitializer exception$FIRST_PLACE;
    
    public static x10.lang.Place get$FIRST_PLACE() {
        if (((int) x10.lang.Place.initStatus$FIRST_PLACE.get()) == ((int) x10.runtime.impl.java.InitDispatcher.INITIALIZED)) {
            return x10.lang.Place.FIRST_PLACE;
        }
        if (((int) x10.lang.Place.initStatus$FIRST_PLACE.get()) == ((int) x10.runtime.impl.java.InitDispatcher.EXCEPTION_RAISED)) {
            throw x10.lang.Place.exception$FIRST_PLACE;
        }
        if (x10.lang.Place.initStatus$FIRST_PLACE.compareAndSet((int)(x10.runtime.impl.java.InitDispatcher.UNINITIALIZED), (int)(x10.runtime.impl.java.InitDispatcher.INITIALIZING))) {
            try {{
                x10.lang.Place.FIRST_PLACE = ((x10.lang.Place)(new x10.lang.Place((java.lang.System[]) null).x10$lang$Place$$init$S(((long)(0L)))));
            }}catch (java.lang.Throwable exc$135235) {
                x10.lang.Place.exception$FIRST_PLACE = new x10.lang.ExceptionInInitializer(exc$135235);
                x10.lang.Place.initStatus$FIRST_PLACE.set((int)(x10.runtime.impl.java.InitDispatcher.EXCEPTION_RAISED));
                x10.runtime.impl.java.InitDispatcher.lockInitialized();
                x10.runtime.impl.java.InitDispatcher.notifyInitialized();
                throw x10.lang.Place.exception$FIRST_PLACE;
            }
            x10.lang.Place.initStatus$FIRST_PLACE.set((int)(x10.runtime.impl.java.InitDispatcher.INITIALIZED));
            x10.runtime.impl.java.InitDispatcher.lockInitialized();
            x10.runtime.impl.java.InitDispatcher.notifyInitialized();
        } else {
            if (x10.lang.Place.initStatus$FIRST_PLACE.get() < x10.runtime.impl.java.InitDispatcher.INITIALIZED) {
                x10.runtime.impl.java.InitDispatcher.lockInitialized();
                while (x10.lang.Place.initStatus$FIRST_PLACE.get() < x10.runtime.impl.java.InitDispatcher.INITIALIZED) {
                    x10.runtime.impl.java.InitDispatcher.awaitInitialized();
                }
                x10.runtime.impl.java.InitDispatcher.unlockInitialized();
                if (((int) x10.lang.Place.initStatus$FIRST_PLACE.get()) == ((int) x10.runtime.impl.java.InitDispatcher.EXCEPTION_RAISED)) {
                    throw x10.lang.Place.exception$FIRST_PLACE;
                }
            }
        }
        return x10.lang.Place.FIRST_PLACE;
    }
    
    public static x10.lang.Place get$INVALID_PLACE() {
        if (((int) x10.lang.Place.initStatus$INVALID_PLACE.get()) == ((int) x10.runtime.impl.java.InitDispatcher.INITIALIZED)) {
            return x10.lang.Place.INVALID_PLACE;
        }
        if (((int) x10.lang.Place.initStatus$INVALID_PLACE.get()) == ((int) x10.runtime.impl.java.InitDispatcher.EXCEPTION_RAISED)) {
            throw x10.lang.Place.exception$INVALID_PLACE;
        }
        if (x10.lang.Place.initStatus$INVALID_PLACE.compareAndSet((int)(x10.runtime.impl.java.InitDispatcher.UNINITIALIZED), (int)(x10.runtime.impl.java.InitDispatcher.INITIALIZING))) {
            try {{
                x10.lang.Place.INVALID_PLACE = ((x10.lang.Place)(new x10.lang.Place((java.lang.System[]) null).x10$lang$Place$$init$S(((long)(-1L)))));
            }}catch (java.lang.Throwable exc$135236) {
                x10.lang.Place.exception$INVALID_PLACE = new x10.lang.ExceptionInInitializer(exc$135236);
                x10.lang.Place.initStatus$INVALID_PLACE.set((int)(x10.runtime.impl.java.InitDispatcher.EXCEPTION_RAISED));
                x10.runtime.impl.java.InitDispatcher.lockInitialized();
                x10.runtime.impl.java.InitDispatcher.notifyInitialized();
                throw x10.lang.Place.exception$INVALID_PLACE;
            }
            x10.lang.Place.initStatus$INVALID_PLACE.set((int)(x10.runtime.impl.java.InitDispatcher.INITIALIZED));
            x10.runtime.impl.java.InitDispatcher.lockInitialized();
            x10.runtime.impl.java.InitDispatcher.notifyInitialized();
        } else {
            if (x10.lang.Place.initStatus$INVALID_PLACE.get() < x10.runtime.impl.java.InitDispatcher.INITIALIZED) {
                x10.runtime.impl.java.InitDispatcher.lockInitialized();
                while (x10.lang.Place.initStatus$INVALID_PLACE.get() < x10.runtime.impl.java.InitDispatcher.INITIALIZED) {
                    x10.runtime.impl.java.InitDispatcher.awaitInitialized();
                }
                x10.runtime.impl.java.InitDispatcher.unlockInitialized();
                if (((int) x10.lang.Place.initStatus$INVALID_PLACE.get()) == ((int) x10.runtime.impl.java.InitDispatcher.EXCEPTION_RAISED)) {
                    throw x10.lang.Place.exception$INVALID_PLACE;
                }
            }
        }
        return x10.lang.Place.INVALID_PLACE;
    }
    
    public static x10.lang.Place.PlaceGroupCache get$CUR_WORLD() {
        if (((int) x10.lang.Place.initStatus$CUR_WORLD.get()) == ((int) x10.runtime.impl.java.InitDispatcher.INITIALIZED)) {
            return x10.lang.Place.CUR_WORLD;
        }
        if (((int) x10.lang.Place.initStatus$CUR_WORLD.get()) == ((int) x10.runtime.impl.java.InitDispatcher.EXCEPTION_RAISED)) {
            throw x10.lang.Place.exception$CUR_WORLD;
        }
        if (x10.lang.Place.initStatus$CUR_WORLD.compareAndSet((int)(x10.runtime.impl.java.InitDispatcher.UNINITIALIZED), (int)(x10.runtime.impl.java.InitDispatcher.INITIALIZING))) {
            try {{
                x10.lang.Place.CUR_WORLD = new x10.lang.Place.PlaceGroupCache((java.lang.System[]) null).x10$lang$Place$PlaceGroupCache$$init$S(((long)(0L)), ((long)(0L)), ((x10.lang.PlaceGroup)(new x10.lang.PlaceGroup.SimplePlaceGroup((java.lang.System[]) null).x10$lang$PlaceGroup$SimplePlaceGroup$$init$S(((long)(0L))))));
            }}catch (java.lang.Throwable exc$135237) {
                x10.lang.Place.exception$CUR_WORLD = new x10.lang.ExceptionInInitializer(exc$135237);
                x10.lang.Place.initStatus$CUR_WORLD.set((int)(x10.runtime.impl.java.InitDispatcher.EXCEPTION_RAISED));
                x10.runtime.impl.java.InitDispatcher.lockInitialized();
                x10.runtime.impl.java.InitDispatcher.notifyInitialized();
                throw x10.lang.Place.exception$CUR_WORLD;
            }
            x10.lang.Place.initStatus$CUR_WORLD.set((int)(x10.runtime.impl.java.InitDispatcher.INITIALIZED));
            x10.runtime.impl.java.InitDispatcher.lockInitialized();
            x10.runtime.impl.java.InitDispatcher.notifyInitialized();
        } else {
            if (x10.lang.Place.initStatus$CUR_WORLD.get() < x10.runtime.impl.java.InitDispatcher.INITIALIZED) {
                x10.runtime.impl.java.InitDispatcher.lockInitialized();
                while (x10.lang.Place.initStatus$CUR_WORLD.get() < x10.runtime.impl.java.InitDispatcher.INITIALIZED) {
                    x10.runtime.impl.java.InitDispatcher.awaitInitialized();
                }
                x10.runtime.impl.java.InitDispatcher.unlockInitialized();
                if (((int) x10.lang.Place.initStatus$CUR_WORLD.get()) == ((int) x10.runtime.impl.java.InitDispatcher.EXCEPTION_RAISED)) {
                    throw x10.lang.Place.exception$CUR_WORLD;
                }
            }
        }
        return x10.lang.Place.CUR_WORLD;
    }
    }
    
    
    
    