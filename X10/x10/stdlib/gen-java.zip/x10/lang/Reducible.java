package x10.lang;


/**
 * The interface that must be implemented by reduction operations.
 * 
 * Implementations of Reducible[T] must ensure that the operator(T,T) method is associative
 * and commutative and stateless, and that zero() is an identity.
 */
@x10.runtime.impl.java.X10Generated
public interface Reducible<$T> extends x10.core.Any
{
    public static final x10.rtt.RuntimeType<Reducible> $RTT = 
        x10.rtt.NamedType.<Reducible> make("x10.lang.Reducible",
                                           Reducible.class,
                                           1);
    
    

    
    
    //#line 28 "x10/lang/Reducible.x10"
    /**
    * The identity for this reducer operation. It must be the case
    * that operator(zero(),f)=f.
    */
    $T zero$G();
    
    
    //#line 30 "x10/lang/Reducible.x10"
    java.lang.Object $apply(final java.lang.Object a, x10.rtt.Type t1, final java.lang.Object b, x10.rtt.Type t2);
    
    
    //#line 32 "x10/lang/Reducible.x10"
    @x10.runtime.impl.java.X10Generated
    public static class AndReducer extends x10.core.Struct implements x10.lang.Reducible, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<AndReducer> $RTT = 
            x10.rtt.NamedStructType.<AndReducer> make("x10.lang.Reducible.AndReducer",
                                                      AndReducer.class,
                                                      new x10.rtt.Type[] {
                                                          x10.rtt.ParameterizedType.make(x10.lang.Reducible.$RTT, x10.rtt.Types.BOOLEAN),
                                                          x10.rtt.Types.STRUCT
                                                      });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static x10.serialization.X10JavaSerializable $_deserialize_body(x10.lang.Reducible.AndReducer $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.lang.Reducible.AndReducer $_obj = new x10.lang.Reducible.AndReducer((java.lang.System[]) null);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            
        }
        
        // zero value constructor
        public AndReducer(final java.lang.System $dummy) { }
        
        // constructor just for allocation
        public AndReducer(final java.lang.System[] $dummy) {
            
        }
        
        // dispatcher for method abstract public x10.lang.Reducible[T].operator()(a:T, b:T){}:T
        public java.lang.Object $apply(final java.lang.Object a1, final x10.rtt.Type t1, final java.lang.Object a2, final x10.rtt.Type t2) {
            return x10.core.Boolean.$box($apply$O(x10.core.Boolean.$unbox(a1), x10.core.Boolean.$unbox(a2)));
            
        }
        
        // dispatcher for method abstract public x10.lang.Reducible[T].operator()(a:T, b:T){}:T
        public boolean $apply$Z(final java.lang.Object a1, final x10.rtt.Type t1, final java.lang.Object a2, final x10.rtt.Type t2) {
            return $apply$O(x10.core.Boolean.$unbox(a1), x10.core.Boolean.$unbox(a2));
            
        }
        
        // bridge for method abstract public x10.lang.Reducible[T].zero(){}:T
        final public x10.core.Boolean zero$G() {
            return x10.core.Boolean.$box(zero$O());
        }
        
        
    
        
        
        //#line 33 "x10/lang/Reducible.x10"
        final public boolean zero$O() {
            
            //#line 33 "x10/lang/Reducible.x10"
            return true;
        }
        
        
        //#line 34 "x10/lang/Reducible.x10"
        final public boolean $apply$O(final boolean a, final boolean b) {
            
            //#line 34 "x10/lang/Reducible.x10"
            boolean t$136283 = a;
            
            //#line 34 "x10/lang/Reducible.x10"
            if (a) {
                
                //#line 34 "x10/lang/Reducible.x10"
                t$136283 = b;
            }
            
            //#line 34 "x10/lang/Reducible.x10"
            return t$136283;
        }
        
        
        //#line 32 "x10/lang/Reducible.x10"
        final public java.lang.String typeName() {
            try {
                return x10.rtt.Types.typeName(this);
            }
            catch (java.lang.Throwable exc$206436) {
                throw x10.runtime.impl.java.ThrowableUtils.ensureX10Exception(exc$206436);
            }
            
        }
        
        
        
        //#line 32 "x10/lang/Reducible.x10"
        final public java.lang.String toString() {
            
            //#line 32 "x10/lang/Reducible.x10"
            return "struct x10.lang.Reducible.AndReducer";
        }
        
        
        //#line 32 "x10/lang/Reducible.x10"
        final public int hashCode() {
            
            //#line 32 "x10/lang/Reducible.x10"
            int result = 1;
            
            //#line 32 "x10/lang/Reducible.x10"
            return result;
        }
        
        
        //#line 32 "x10/lang/Reducible.x10"
        final public boolean equals(java.lang.Object other) {
            
            //#line 32 "x10/lang/Reducible.x10"
            final boolean t$136287 = x10.lang.Reducible.AndReducer.$RTT.isInstance(other);
            
            //#line 32 "x10/lang/Reducible.x10"
            final boolean t$136288 = !(t$136287);
            
            //#line 32 "x10/lang/Reducible.x10"
            if (t$136288) {
                
                //#line 32 "x10/lang/Reducible.x10"
                return false;
            }
            
            //#line 32 "x10/lang/Reducible.x10"
            x10.runtime.impl.java.EvalUtils.eval(((x10.lang.Reducible.AndReducer)x10.rtt.Types.asStruct(x10.lang.Reducible.AndReducer.$RTT,other)));
            
            //#line 32 "x10/lang/Reducible.x10"
            return true;
        }
        
        
        //#line 32 "x10/lang/Reducible.x10"
        final public boolean equals$O(x10.lang.Reducible.AndReducer other) {
            
            //#line 32 "x10/lang/Reducible.x10"
            return true;
        }
        
        
        //#line 32 "x10/lang/Reducible.x10"
        final public boolean _struct_equals$O(java.lang.Object other) {
            
            //#line 32 "x10/lang/Reducible.x10"
            final boolean t$136291 = x10.lang.Reducible.AndReducer.$RTT.isInstance(other);
            
            //#line 32 "x10/lang/Reducible.x10"
            final boolean t$136292 = !(t$136291);
            
            //#line 32 "x10/lang/Reducible.x10"
            if (t$136292) {
                
                //#line 32 "x10/lang/Reducible.x10"
                return false;
            }
            
            //#line 32 "x10/lang/Reducible.x10"
            x10.runtime.impl.java.EvalUtils.eval(((x10.lang.Reducible.AndReducer)x10.rtt.Types.asStruct(x10.lang.Reducible.AndReducer.$RTT,other)));
            
            //#line 32 "x10/lang/Reducible.x10"
            return true;
        }
        
        
        //#line 32 "x10/lang/Reducible.x10"
        final public boolean _struct_equals$O(x10.lang.Reducible.AndReducer other) {
            
            //#line 32 "x10/lang/Reducible.x10"
            return true;
        }
        
        
        //#line 32 "x10/lang/Reducible.x10"
        final public x10.lang.Reducible.AndReducer x10$lang$Reducible$AndReducer$$this$x10$lang$Reducible$AndReducer() {
            
            //#line 32 "x10/lang/Reducible.x10"
            return x10.lang.Reducible.AndReducer.this;
        }
        
        
        //#line 32 "x10/lang/Reducible.x10"
        // creation method for java code (1-phase java constructor)
        public AndReducer() {
            this((java.lang.System[]) null);
            x10$lang$Reducible$AndReducer$$init$S();
        }
        
        // constructor for non-virtual call
        final public x10.lang.Reducible.AndReducer x10$lang$Reducible$AndReducer$$init$S() {
             {
                
                //#line 32 "x10/lang/Reducible.x10"
                
            }
            return this;
        }
        
        
        
        //#line 32 "x10/lang/Reducible.x10"
        final public void __fieldInitializers_x10_lang_Reducible_AndReducer() {
            
        }
    }
    
    
    //#line 37 "x10/lang/Reducible.x10"
    @x10.runtime.impl.java.X10Generated
    public static class OrReducer extends x10.core.Struct implements x10.lang.Reducible, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<OrReducer> $RTT = 
            x10.rtt.NamedStructType.<OrReducer> make("x10.lang.Reducible.OrReducer",
                                                     OrReducer.class,
                                                     new x10.rtt.Type[] {
                                                         x10.rtt.ParameterizedType.make(x10.lang.Reducible.$RTT, x10.rtt.Types.BOOLEAN),
                                                         x10.rtt.Types.STRUCT
                                                     });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static x10.serialization.X10JavaSerializable $_deserialize_body(x10.lang.Reducible.OrReducer $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.lang.Reducible.OrReducer $_obj = new x10.lang.Reducible.OrReducer((java.lang.System[]) null);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            
        }
        
        // zero value constructor
        public OrReducer(final java.lang.System $dummy) { }
        
        // constructor just for allocation
        public OrReducer(final java.lang.System[] $dummy) {
            
        }
        
        // dispatcher for method abstract public x10.lang.Reducible[T].operator()(a:T, b:T){}:T
        public java.lang.Object $apply(final java.lang.Object a1, final x10.rtt.Type t1, final java.lang.Object a2, final x10.rtt.Type t2) {
            return x10.core.Boolean.$box($apply$O(x10.core.Boolean.$unbox(a1), x10.core.Boolean.$unbox(a2)));
            
        }
        
        // dispatcher for method abstract public x10.lang.Reducible[T].operator()(a:T, b:T){}:T
        public boolean $apply$Z(final java.lang.Object a1, final x10.rtt.Type t1, final java.lang.Object a2, final x10.rtt.Type t2) {
            return $apply$O(x10.core.Boolean.$unbox(a1), x10.core.Boolean.$unbox(a2));
            
        }
        
        // bridge for method abstract public x10.lang.Reducible[T].zero(){}:T
        final public x10.core.Boolean zero$G() {
            return x10.core.Boolean.$box(zero$O());
        }
        
        
    
        
        
        //#line 38 "x10/lang/Reducible.x10"
        final public boolean zero$O() {
            
            //#line 38 "x10/lang/Reducible.x10"
            return false;
        }
        
        
        //#line 39 "x10/lang/Reducible.x10"
        final public boolean $apply$O(final boolean a, final boolean b) {
            
            //#line 39 "x10/lang/Reducible.x10"
            boolean t$136294 = a;
            
            //#line 39 "x10/lang/Reducible.x10"
            if (!(a)) {
                
                //#line 39 "x10/lang/Reducible.x10"
                t$136294 = b;
            }
            
            //#line 39 "x10/lang/Reducible.x10"
            return t$136294;
        }
        
        
        //#line 37 "x10/lang/Reducible.x10"
        final public java.lang.String typeName() {
            try {
                return x10.rtt.Types.typeName(this);
            }
            catch (java.lang.Throwable exc$206437) {
                throw x10.runtime.impl.java.ThrowableUtils.ensureX10Exception(exc$206437);
            }
            
        }
        
        
        
        //#line 37 "x10/lang/Reducible.x10"
        final public java.lang.String toString() {
            
            //#line 37 "x10/lang/Reducible.x10"
            return "struct x10.lang.Reducible.OrReducer";
        }
        
        
        //#line 37 "x10/lang/Reducible.x10"
        final public int hashCode() {
            
            //#line 37 "x10/lang/Reducible.x10"
            int result = 1;
            
            //#line 37 "x10/lang/Reducible.x10"
            return result;
        }
        
        
        //#line 37 "x10/lang/Reducible.x10"
        final public boolean equals(java.lang.Object other) {
            
            //#line 37 "x10/lang/Reducible.x10"
            final boolean t$136298 = x10.lang.Reducible.OrReducer.$RTT.isInstance(other);
            
            //#line 37 "x10/lang/Reducible.x10"
            final boolean t$136299 = !(t$136298);
            
            //#line 37 "x10/lang/Reducible.x10"
            if (t$136299) {
                
                //#line 37 "x10/lang/Reducible.x10"
                return false;
            }
            
            //#line 37 "x10/lang/Reducible.x10"
            x10.runtime.impl.java.EvalUtils.eval(((x10.lang.Reducible.OrReducer)x10.rtt.Types.asStruct(x10.lang.Reducible.OrReducer.$RTT,other)));
            
            //#line 37 "x10/lang/Reducible.x10"
            return true;
        }
        
        
        //#line 37 "x10/lang/Reducible.x10"
        final public boolean equals$O(x10.lang.Reducible.OrReducer other) {
            
            //#line 37 "x10/lang/Reducible.x10"
            return true;
        }
        
        
        //#line 37 "x10/lang/Reducible.x10"
        final public boolean _struct_equals$O(java.lang.Object other) {
            
            //#line 37 "x10/lang/Reducible.x10"
            final boolean t$136302 = x10.lang.Reducible.OrReducer.$RTT.isInstance(other);
            
            //#line 37 "x10/lang/Reducible.x10"
            final boolean t$136303 = !(t$136302);
            
            //#line 37 "x10/lang/Reducible.x10"
            if (t$136303) {
                
                //#line 37 "x10/lang/Reducible.x10"
                return false;
            }
            
            //#line 37 "x10/lang/Reducible.x10"
            x10.runtime.impl.java.EvalUtils.eval(((x10.lang.Reducible.OrReducer)x10.rtt.Types.asStruct(x10.lang.Reducible.OrReducer.$RTT,other)));
            
            //#line 37 "x10/lang/Reducible.x10"
            return true;
        }
        
        
        //#line 37 "x10/lang/Reducible.x10"
        final public boolean _struct_equals$O(x10.lang.Reducible.OrReducer other) {
            
            //#line 37 "x10/lang/Reducible.x10"
            return true;
        }
        
        
        //#line 37 "x10/lang/Reducible.x10"
        final public x10.lang.Reducible.OrReducer x10$lang$Reducible$OrReducer$$this$x10$lang$Reducible$OrReducer() {
            
            //#line 37 "x10/lang/Reducible.x10"
            return x10.lang.Reducible.OrReducer.this;
        }
        
        
        //#line 37 "x10/lang/Reducible.x10"
        // creation method for java code (1-phase java constructor)
        public OrReducer() {
            this((java.lang.System[]) null);
            x10$lang$Reducible$OrReducer$$init$S();
        }
        
        // constructor for non-virtual call
        final public x10.lang.Reducible.OrReducer x10$lang$Reducible$OrReducer$$init$S() {
             {
                
                //#line 37 "x10/lang/Reducible.x10"
                
            }
            return this;
        }
        
        
        
        //#line 37 "x10/lang/Reducible.x10"
        final public void __fieldInitializers_x10_lang_Reducible_OrReducer() {
            
        }
    }
    
    
    //#line 42 "x10/lang/Reducible.x10"
    @x10.runtime.impl.java.X10Generated
    public static class SumReducer<$T> extends x10.core.Struct implements x10.lang.Reducible, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<SumReducer> $RTT = 
            x10.rtt.NamedStructType.<SumReducer> make("x10.lang.Reducible.SumReducer",
                                                      SumReducer.class,
                                                      1,
                                                      new x10.rtt.Type[] {
                                                          x10.rtt.ParameterizedType.make(x10.lang.Reducible.$RTT, x10.rtt.UnresolvedType.PARAM(0)),
                                                          x10.rtt.Types.STRUCT
                                                      });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { if (i == 0) return $T; return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static <$T> x10.serialization.X10JavaSerializable $_deserialize_body(x10.lang.Reducible.SumReducer<$T> $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            $_obj.$T = (x10.rtt.Type) $deserializer.readObject();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.lang.Reducible.SumReducer $_obj = new x10.lang.Reducible.SumReducer((java.lang.System[]) null, (x10.rtt.Type) null);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            $serializer.write(this.$T);
            
        }
        
        // zero value constructor
        public SumReducer(final x10.rtt.Type $T, final java.lang.System $dummy) { this.$T = $T; }
        
        // constructor just for allocation
        public SumReducer(final java.lang.System[] $dummy, final x10.rtt.Type $T) {
            x10.lang.Reducible.SumReducer.$initParams(this, $T);
            
        }
        
        // dispatcher for method abstract public x10.lang.Reducible[T].operator()(a:T, b:T){}:T
        public java.lang.Object $apply(final java.lang.Object a1, final x10.rtt.Type t1, final java.lang.Object a2, final x10.rtt.Type t2) {
            return $apply__0x10$lang$Reducible$SumReducer$$T__1x10$lang$Reducible$SumReducer$$T$G(($T)a1, ($T)a2);
            
        }
        
        private x10.rtt.Type $T;
        
        // initializer of type parameters
        public static void $initParams(final SumReducer $this, final x10.rtt.Type $T) {
            $this.$T = $T;
            
        }
        
    
        
        
        //#line 43 "x10/lang/Reducible.x10"
        final public $T zero$G() {
            
            //#line 43 "x10/lang/Reducible.x10"
            final $T t$136305 = (($T)(($T) x10.rtt.Types.zeroValue($T)));
            
            //#line 43 "x10/lang/Reducible.x10"
            return t$136305;
        }
        
        
        //#line 44 "x10/lang/Reducible.x10"
        final public $T $apply__0x10$lang$Reducible$SumReducer$$T__1x10$lang$Reducible$SumReducer$$T$G(final $T a, final $T b) {
            
            //#line 44 "x10/lang/Reducible.x10"
            final $T t$136306 = (($T)((($T)
                                        ((x10.lang.Arithmetic<$T>)x10.rtt.Types.conversion(x10.rtt.ParameterizedType.make(x10.lang.Arithmetic.$RTT, $T),a)).$plus((($T)(b)), $T))));
            
            //#line 44 "x10/lang/Reducible.x10"
            return t$136306;
        }
        
        
        //#line 42 "x10/lang/Reducible.x10"
        final public java.lang.String typeName() {
            try {
                return x10.rtt.Types.typeName(this);
            }
            catch (java.lang.Throwable exc$206438) {
                throw x10.runtime.impl.java.ThrowableUtils.ensureX10Exception(exc$206438);
            }
            
        }
        
        
        
        //#line 42 "x10/lang/Reducible.x10"
        final public java.lang.String toString() {
            
            //#line 42 "x10/lang/Reducible.x10"
            return "struct x10.lang.Reducible.SumReducer";
        }
        
        
        //#line 42 "x10/lang/Reducible.x10"
        final public int hashCode() {
            
            //#line 42 "x10/lang/Reducible.x10"
            int result = 1;
            
            //#line 42 "x10/lang/Reducible.x10"
            return result;
        }
        
        
        //#line 42 "x10/lang/Reducible.x10"
        final public boolean equals(java.lang.Object other) {
            
            //#line 42 "x10/lang/Reducible.x10"
            final boolean t$136309 = x10.lang.Reducible.SumReducer.$RTT.isInstance(other, $T);
            
            //#line 42 "x10/lang/Reducible.x10"
            final boolean t$136310 = !(t$136309);
            
            //#line 42 "x10/lang/Reducible.x10"
            if (t$136310) {
                
                //#line 42 "x10/lang/Reducible.x10"
                return false;
            }
            
            //#line 42 "x10/lang/Reducible.x10"
            x10.runtime.impl.java.EvalUtils.eval(((x10.lang.Reducible.SumReducer)x10.rtt.Types.asStruct(x10.rtt.ParameterizedType.make(x10.lang.Reducible.SumReducer.$RTT, $T),other)));
            
            //#line 42 "x10/lang/Reducible.x10"
            return true;
        }
        
        
        //#line 42 "x10/lang/Reducible.x10"
        final public boolean equals__0$1x10$lang$Reducible$SumReducer$$T$2$O(x10.lang.Reducible.SumReducer other) {
            
            //#line 42 "x10/lang/Reducible.x10"
            return true;
        }
        
        
        //#line 42 "x10/lang/Reducible.x10"
        final public boolean _struct_equals$O(java.lang.Object other) {
            
            //#line 42 "x10/lang/Reducible.x10"
            final boolean t$136313 = x10.lang.Reducible.SumReducer.$RTT.isInstance(other, $T);
            
            //#line 42 "x10/lang/Reducible.x10"
            final boolean t$136314 = !(t$136313);
            
            //#line 42 "x10/lang/Reducible.x10"
            if (t$136314) {
                
                //#line 42 "x10/lang/Reducible.x10"
                return false;
            }
            
            //#line 42 "x10/lang/Reducible.x10"
            x10.runtime.impl.java.EvalUtils.eval(((x10.lang.Reducible.SumReducer)x10.rtt.Types.asStruct(x10.rtt.ParameterizedType.make(x10.lang.Reducible.SumReducer.$RTT, $T),other)));
            
            //#line 42 "x10/lang/Reducible.x10"
            return true;
        }
        
        
        //#line 42 "x10/lang/Reducible.x10"
        final public boolean _struct_equals__0$1x10$lang$Reducible$SumReducer$$T$2$O(x10.lang.Reducible.SumReducer other) {
            
            //#line 42 "x10/lang/Reducible.x10"
            return true;
        }
        
        
        //#line 42 "x10/lang/Reducible.x10"
        final public x10.lang.Reducible.SumReducer x10$lang$Reducible$SumReducer$$this$x10$lang$Reducible$SumReducer() {
            
            //#line 42 "x10/lang/Reducible.x10"
            return x10.lang.Reducible.SumReducer.this;
        }
        
        
        //#line 42 "x10/lang/Reducible.x10"
        // creation method for java code (1-phase java constructor)
        public SumReducer(final x10.rtt.Type $T) {
            this((java.lang.System[]) null, $T);
            x10$lang$Reducible$SumReducer$$init$S();
        }
        
        // constructor for non-virtual call
        final public x10.lang.Reducible.SumReducer<$T> x10$lang$Reducible$SumReducer$$init$S() {
             {
                
                //#line 42 "x10/lang/Reducible.x10"
                
            }
            return this;
        }
        
        
        
        //#line 42 "x10/lang/Reducible.x10"
        final public void __fieldInitializers_x10_lang_Reducible_SumReducer() {
            
        }
    }
    
    
    //#line 47 "x10/lang/Reducible.x10"
    @x10.runtime.impl.java.X10Generated
    public static class MinReducer<$T> extends x10.core.Struct implements x10.lang.Reducible, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<MinReducer> $RTT = 
            x10.rtt.NamedStructType.<MinReducer> make("x10.lang.Reducible.MinReducer",
                                                      MinReducer.class,
                                                      1,
                                                      new x10.rtt.Type[] {
                                                          x10.rtt.ParameterizedType.make(x10.lang.Reducible.$RTT, x10.rtt.UnresolvedType.PARAM(0)),
                                                          x10.rtt.Types.STRUCT
                                                      });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { if (i == 0) return $T; return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static <$T> x10.serialization.X10JavaSerializable $_deserialize_body(x10.lang.Reducible.MinReducer<$T> $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            $_obj.$T = (x10.rtt.Type) $deserializer.readObject();
            $_obj.zeroVal = $deserializer.readObject();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.lang.Reducible.MinReducer $_obj = new x10.lang.Reducible.MinReducer((java.lang.System[]) null, (x10.rtt.Type) null);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            $serializer.write(this.$T);
            $serializer.write(this.zeroVal);
            
        }
        
        // zero value constructor
        public MinReducer(final x10.rtt.Type $T, final java.lang.System $dummy) { this.$T = $T; this.zeroVal = ($T) x10.rtt.Types.zeroValue($T); }
        
        // constructor just for allocation
        public MinReducer(final java.lang.System[] $dummy, final x10.rtt.Type $T) {
            x10.lang.Reducible.MinReducer.$initParams(this, $T);
            
        }
        
        // dispatcher for method abstract public x10.lang.Reducible[T].operator()(a:T, b:T){}:T
        public java.lang.Object $apply(final java.lang.Object a1, final x10.rtt.Type t1, final java.lang.Object a2, final x10.rtt.Type t2) {
            return $apply__0x10$lang$Reducible$MinReducer$$T__1x10$lang$Reducible$MinReducer$$T$G(($T)a1, ($T)a2);
            
        }
        
        private x10.rtt.Type $T;
        
        // initializer of type parameters
        public static void $initParams(final MinReducer $this, final x10.rtt.Type $T) {
            $this.$T = $T;
            
        }
        // synthetic type for parameter mangling
        public static final class __0x10$lang$Reducible$MinReducer$$T {}
        
    
        
        //#line 48 "x10/lang/Reducible.x10"
        public $T zeroVal;
        
        
        //#line 49 "x10/lang/Reducible.x10"
        // creation method for java code (1-phase java constructor)
        public MinReducer(final x10.rtt.Type $T, final $T maxValue, __0x10$lang$Reducible$MinReducer$$T $dummy) {
            this((java.lang.System[]) null, $T);
            x10$lang$Reducible$MinReducer$$init$S(maxValue, (x10.lang.Reducible.MinReducer.__0x10$lang$Reducible$MinReducer$$T) null);
        }
        
        // constructor for non-virtual call
        final public x10.lang.Reducible.MinReducer<$T> x10$lang$Reducible$MinReducer$$init$S(final $T maxValue, __0x10$lang$Reducible$MinReducer$$T $dummy) {
             {
                
                //#line 49 "x10/lang/Reducible.x10"
                
                
                //#line 49 "x10/lang/Reducible.x10"
                ((x10.lang.Reducible.MinReducer<$T>)this).zeroVal = (($T)(maxValue));
            }
            return this;
        }
        
        
        
        //#line 50 "x10/lang/Reducible.x10"
        final public $T zero$G() {
            
            //#line 50 "x10/lang/Reducible.x10"
            final $T t$136316 = (($T)(this.zeroVal));
            
            //#line 50 "x10/lang/Reducible.x10"
            return t$136316;
        }
        
        
        //#line 51 "x10/lang/Reducible.x10"
        final public $T $apply__0x10$lang$Reducible$MinReducer$$T__1x10$lang$Reducible$MinReducer$$T$G(final $T a, final $T b) {
            
            //#line 51 "x10/lang/Reducible.x10"
            final boolean t$136317 = x10.core.Boolean.$unbox(((x10.util.Ordered<$T>)x10.rtt.Types.conversion(x10.rtt.ParameterizedType.make(x10.util.Ordered.$RTT, $T),a)).$lt$Z((($T)(b)), $T));
            
            //#line 51 "x10/lang/Reducible.x10"
            $T t$136318 =  null;
            
            //#line 51 "x10/lang/Reducible.x10"
            if (t$136317) {
                
                //#line 51 "x10/lang/Reducible.x10"
                t$136318 = (($T)(a));
            } else {
                
                //#line 51 "x10/lang/Reducible.x10"
                t$136318 = (($T)(b));
            }
            
            //#line 51 "x10/lang/Reducible.x10"
            return t$136318;
        }
        
        
        //#line 47 "x10/lang/Reducible.x10"
        final public java.lang.String typeName() {
            try {
                return x10.rtt.Types.typeName(this);
            }
            catch (java.lang.Throwable exc$206439) {
                throw x10.runtime.impl.java.ThrowableUtils.ensureX10Exception(exc$206439);
            }
            
        }
        
        
        
        //#line 47 "x10/lang/Reducible.x10"
        final public java.lang.String toString() {
            
            //#line 47 "x10/lang/Reducible.x10"
            final java.lang.String t$136320 = "struct x10.lang.Reducible.MinReducer: zeroVal=";
            
            //#line 47 "x10/lang/Reducible.x10"
            final $T t$136321 = (($T)(this.zeroVal));
            
            //#line 47 "x10/lang/Reducible.x10"
            final java.lang.String t$136322 = ((t$136320) + (t$136321));
            
            //#line 47 "x10/lang/Reducible.x10"
            return t$136322;
        }
        
        
        //#line 47 "x10/lang/Reducible.x10"
        final public int hashCode() {
            
            //#line 47 "x10/lang/Reducible.x10"
            int result = 1;
            
            //#line 47 "x10/lang/Reducible.x10"
            final int t$136325 = ((8191) * (((int)(result))));
            
            //#line 47 "x10/lang/Reducible.x10"
            final $T t$136324 = (($T)(this.zeroVal));
            
            //#line 47 "x10/lang/Reducible.x10"
            final int t$136326 = x10.rtt.Types.hashCode(((java.lang.Object)(t$136324)));
            
            //#line 47 "x10/lang/Reducible.x10"
            final int t$136327 = ((t$136325) + (((int)(t$136326))));
            
            //#line 47 "x10/lang/Reducible.x10"
            result = t$136327;
            
            //#line 47 "x10/lang/Reducible.x10"
            return result;
        }
        
        
        //#line 47 "x10/lang/Reducible.x10"
        final public boolean equals(java.lang.Object other) {
            
            //#line 47 "x10/lang/Reducible.x10"
            final boolean t$136330 = x10.lang.Reducible.MinReducer.$RTT.isInstance(other, $T);
            
            //#line 47 "x10/lang/Reducible.x10"
            final boolean t$136331 = !(t$136330);
            
            //#line 47 "x10/lang/Reducible.x10"
            if (t$136331) {
                
                //#line 47 "x10/lang/Reducible.x10"
                return false;
            }
            
            //#line 47 "x10/lang/Reducible.x10"
            final x10.lang.Reducible.MinReducer this$136270 = ((x10.lang.Reducible.MinReducer)(this));
            
            //#line 47 "x10/lang/Reducible.x10"
            x10.lang.Reducible.MinReducer other$136269 = ((x10.lang.Reducible.MinReducer)(((x10.lang.Reducible.MinReducer)x10.rtt.Types.asStruct(x10.rtt.ParameterizedType.make(x10.lang.Reducible.MinReducer.$RTT, $T),other))));
            
            //#line 47 "x10/lang/Reducible.x10"
            final $T t$136334 = (($T)(((x10.lang.Reducible.MinReducer<$T>)this$136270).zeroVal));
            
            //#line 47 "x10/lang/Reducible.x10"
            final $T t$136335 = (($T)(((x10.lang.Reducible.MinReducer<$T>)other$136269).zeroVal));
            
            //#line 47 "x10/lang/Reducible.x10"
            final boolean t$136336 = x10.rtt.Equality.equalsequals((t$136334),(t$136335));
            
            //#line 47 "x10/lang/Reducible.x10"
            return t$136336;
        }
        
        
        //#line 47 "x10/lang/Reducible.x10"
        final public boolean equals__0$1x10$lang$Reducible$MinReducer$$T$2$O(x10.lang.Reducible.MinReducer other) {
            
            //#line 47 "x10/lang/Reducible.x10"
            final $T t$136338 = (($T)(this.zeroVal));
            
            //#line 47 "x10/lang/Reducible.x10"
            final $T t$136339 = (($T)(((x10.lang.Reducible.MinReducer<$T>)other).zeroVal));
            
            //#line 47 "x10/lang/Reducible.x10"
            final boolean t$136340 = x10.rtt.Equality.equalsequals((t$136338),(t$136339));
            
            //#line 47 "x10/lang/Reducible.x10"
            return t$136340;
        }
        
        
        //#line 47 "x10/lang/Reducible.x10"
        final public boolean _struct_equals$O(java.lang.Object other) {
            
            //#line 47 "x10/lang/Reducible.x10"
            final boolean t$136342 = x10.lang.Reducible.MinReducer.$RTT.isInstance(other, $T);
            
            //#line 47 "x10/lang/Reducible.x10"
            final boolean t$136343 = !(t$136342);
            
            //#line 47 "x10/lang/Reducible.x10"
            if (t$136343) {
                
                //#line 47 "x10/lang/Reducible.x10"
                return false;
            }
            
            //#line 47 "x10/lang/Reducible.x10"
            final x10.lang.Reducible.MinReducer this$136273 = ((x10.lang.Reducible.MinReducer)(this));
            
            //#line 47 "x10/lang/Reducible.x10"
            x10.lang.Reducible.MinReducer other$136272 = ((x10.lang.Reducible.MinReducer)(((x10.lang.Reducible.MinReducer)x10.rtt.Types.asStruct(x10.rtt.ParameterizedType.make(x10.lang.Reducible.MinReducer.$RTT, $T),other))));
            
            //#line 47 "x10/lang/Reducible.x10"
            final $T t$136346 = (($T)(((x10.lang.Reducible.MinReducer<$T>)this$136273).zeroVal));
            
            //#line 47 "x10/lang/Reducible.x10"
            final $T t$136347 = (($T)(((x10.lang.Reducible.MinReducer<$T>)other$136272).zeroVal));
            
            //#line 47 "x10/lang/Reducible.x10"
            final boolean t$136348 = x10.rtt.Equality.equalsequals((t$136346),(t$136347));
            
            //#line 47 "x10/lang/Reducible.x10"
            return t$136348;
        }
        
        
        //#line 47 "x10/lang/Reducible.x10"
        final public boolean _struct_equals__0$1x10$lang$Reducible$MinReducer$$T$2$O(x10.lang.Reducible.MinReducer other) {
            
            //#line 47 "x10/lang/Reducible.x10"
            final $T t$136350 = (($T)(this.zeroVal));
            
            //#line 47 "x10/lang/Reducible.x10"
            final $T t$136351 = (($T)(((x10.lang.Reducible.MinReducer<$T>)other).zeroVal));
            
            //#line 47 "x10/lang/Reducible.x10"
            final boolean t$136352 = x10.rtt.Equality.equalsequals((t$136350),(t$136351));
            
            //#line 47 "x10/lang/Reducible.x10"
            return t$136352;
        }
        
        
        //#line 47 "x10/lang/Reducible.x10"
        final public x10.lang.Reducible.MinReducer x10$lang$Reducible$MinReducer$$this$x10$lang$Reducible$MinReducer() {
            
            //#line 47 "x10/lang/Reducible.x10"
            return x10.lang.Reducible.MinReducer.this;
        }
        
        
        //#line 47 "x10/lang/Reducible.x10"
        final public void __fieldInitializers_x10_lang_Reducible_MinReducer() {
            
        }
    }
    
    
    //#line 54 "x10/lang/Reducible.x10"
    @x10.runtime.impl.java.X10Generated
    public static class MaxReducer<$T> extends x10.core.Struct implements x10.lang.Reducible, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<MaxReducer> $RTT = 
            x10.rtt.NamedStructType.<MaxReducer> make("x10.lang.Reducible.MaxReducer",
                                                      MaxReducer.class,
                                                      1,
                                                      new x10.rtt.Type[] {
                                                          x10.rtt.ParameterizedType.make(x10.lang.Reducible.$RTT, x10.rtt.UnresolvedType.PARAM(0)),
                                                          x10.rtt.Types.STRUCT
                                                      });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { if (i == 0) return $T; return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static <$T> x10.serialization.X10JavaSerializable $_deserialize_body(x10.lang.Reducible.MaxReducer<$T> $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            $_obj.$T = (x10.rtt.Type) $deserializer.readObject();
            $_obj.zeroVal = $deserializer.readObject();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.lang.Reducible.MaxReducer $_obj = new x10.lang.Reducible.MaxReducer((java.lang.System[]) null, (x10.rtt.Type) null);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            $serializer.write(this.$T);
            $serializer.write(this.zeroVal);
            
        }
        
        // zero value constructor
        public MaxReducer(final x10.rtt.Type $T, final java.lang.System $dummy) { this.$T = $T; this.zeroVal = ($T) x10.rtt.Types.zeroValue($T); }
        
        // constructor just for allocation
        public MaxReducer(final java.lang.System[] $dummy, final x10.rtt.Type $T) {
            x10.lang.Reducible.MaxReducer.$initParams(this, $T);
            
        }
        
        // dispatcher for method abstract public x10.lang.Reducible[T].operator()(a:T, b:T){}:T
        public java.lang.Object $apply(final java.lang.Object a1, final x10.rtt.Type t1, final java.lang.Object a2, final x10.rtt.Type t2) {
            return $apply__0x10$lang$Reducible$MaxReducer$$T__1x10$lang$Reducible$MaxReducer$$T$G(($T)a1, ($T)a2);
            
        }
        
        private x10.rtt.Type $T;
        
        // initializer of type parameters
        public static void $initParams(final MaxReducer $this, final x10.rtt.Type $T) {
            $this.$T = $T;
            
        }
        // synthetic type for parameter mangling
        public static final class __0x10$lang$Reducible$MaxReducer$$T {}
        
    
        
        //#line 55 "x10/lang/Reducible.x10"
        public $T zeroVal;
        
        
        //#line 56 "x10/lang/Reducible.x10"
        // creation method for java code (1-phase java constructor)
        public MaxReducer(final x10.rtt.Type $T, final $T minValue, __0x10$lang$Reducible$MaxReducer$$T $dummy) {
            this((java.lang.System[]) null, $T);
            x10$lang$Reducible$MaxReducer$$init$S(minValue, (x10.lang.Reducible.MaxReducer.__0x10$lang$Reducible$MaxReducer$$T) null);
        }
        
        // constructor for non-virtual call
        final public x10.lang.Reducible.MaxReducer<$T> x10$lang$Reducible$MaxReducer$$init$S(final $T minValue, __0x10$lang$Reducible$MaxReducer$$T $dummy) {
             {
                
                //#line 56 "x10/lang/Reducible.x10"
                
                
                //#line 56 "x10/lang/Reducible.x10"
                ((x10.lang.Reducible.MaxReducer<$T>)this).zeroVal = (($T)(minValue));
            }
            return this;
        }
        
        
        
        //#line 57 "x10/lang/Reducible.x10"
        final public $T zero$G() {
            
            //#line 57 "x10/lang/Reducible.x10"
            final $T t$136353 = (($T)(this.zeroVal));
            
            //#line 57 "x10/lang/Reducible.x10"
            return t$136353;
        }
        
        
        //#line 58 "x10/lang/Reducible.x10"
        final public $T $apply__0x10$lang$Reducible$MaxReducer$$T__1x10$lang$Reducible$MaxReducer$$T$G(final $T a, final $T b) {
            
            //#line 58 "x10/lang/Reducible.x10"
            final boolean t$136354 = x10.core.Boolean.$unbox(((x10.util.Ordered<$T>)x10.rtt.Types.conversion(x10.rtt.ParameterizedType.make(x10.util.Ordered.$RTT, $T),a)).$ge$Z((($T)(b)), $T));
            
            //#line 58 "x10/lang/Reducible.x10"
            $T t$136355 =  null;
            
            //#line 58 "x10/lang/Reducible.x10"
            if (t$136354) {
                
                //#line 58 "x10/lang/Reducible.x10"
                t$136355 = (($T)(a));
            } else {
                
                //#line 58 "x10/lang/Reducible.x10"
                t$136355 = (($T)(b));
            }
            
            //#line 58 "x10/lang/Reducible.x10"
            return t$136355;
        }
        
        
        //#line 54 "x10/lang/Reducible.x10"
        final public java.lang.String typeName() {
            try {
                return x10.rtt.Types.typeName(this);
            }
            catch (java.lang.Throwable exc$206440) {
                throw x10.runtime.impl.java.ThrowableUtils.ensureX10Exception(exc$206440);
            }
            
        }
        
        
        
        //#line 54 "x10/lang/Reducible.x10"
        final public java.lang.String toString() {
            
            //#line 54 "x10/lang/Reducible.x10"
            final java.lang.String t$136357 = "struct x10.lang.Reducible.MaxReducer: zeroVal=";
            
            //#line 54 "x10/lang/Reducible.x10"
            final $T t$136358 = (($T)(this.zeroVal));
            
            //#line 54 "x10/lang/Reducible.x10"
            final java.lang.String t$136359 = ((t$136357) + (t$136358));
            
            //#line 54 "x10/lang/Reducible.x10"
            return t$136359;
        }
        
        
        //#line 54 "x10/lang/Reducible.x10"
        final public int hashCode() {
            
            //#line 54 "x10/lang/Reducible.x10"
            int result = 1;
            
            //#line 54 "x10/lang/Reducible.x10"
            final int t$136362 = ((8191) * (((int)(result))));
            
            //#line 54 "x10/lang/Reducible.x10"
            final $T t$136361 = (($T)(this.zeroVal));
            
            //#line 54 "x10/lang/Reducible.x10"
            final int t$136363 = x10.rtt.Types.hashCode(((java.lang.Object)(t$136361)));
            
            //#line 54 "x10/lang/Reducible.x10"
            final int t$136364 = ((t$136362) + (((int)(t$136363))));
            
            //#line 54 "x10/lang/Reducible.x10"
            result = t$136364;
            
            //#line 54 "x10/lang/Reducible.x10"
            return result;
        }
        
        
        //#line 54 "x10/lang/Reducible.x10"
        final public boolean equals(java.lang.Object other) {
            
            //#line 54 "x10/lang/Reducible.x10"
            final boolean t$136367 = x10.lang.Reducible.MaxReducer.$RTT.isInstance(other, $T);
            
            //#line 54 "x10/lang/Reducible.x10"
            final boolean t$136368 = !(t$136367);
            
            //#line 54 "x10/lang/Reducible.x10"
            if (t$136368) {
                
                //#line 54 "x10/lang/Reducible.x10"
                return false;
            }
            
            //#line 54 "x10/lang/Reducible.x10"
            final x10.lang.Reducible.MaxReducer this$136278 = ((x10.lang.Reducible.MaxReducer)(this));
            
            //#line 54 "x10/lang/Reducible.x10"
            x10.lang.Reducible.MaxReducer other$136277 = ((x10.lang.Reducible.MaxReducer)(((x10.lang.Reducible.MaxReducer)x10.rtt.Types.asStruct(x10.rtt.ParameterizedType.make(x10.lang.Reducible.MaxReducer.$RTT, $T),other))));
            
            //#line 54 "x10/lang/Reducible.x10"
            final $T t$136371 = (($T)(((x10.lang.Reducible.MaxReducer<$T>)this$136278).zeroVal));
            
            //#line 54 "x10/lang/Reducible.x10"
            final $T t$136372 = (($T)(((x10.lang.Reducible.MaxReducer<$T>)other$136277).zeroVal));
            
            //#line 54 "x10/lang/Reducible.x10"
            final boolean t$136373 = x10.rtt.Equality.equalsequals((t$136371),(t$136372));
            
            //#line 54 "x10/lang/Reducible.x10"
            return t$136373;
        }
        
        
        //#line 54 "x10/lang/Reducible.x10"
        final public boolean equals__0$1x10$lang$Reducible$MaxReducer$$T$2$O(x10.lang.Reducible.MaxReducer other) {
            
            //#line 54 "x10/lang/Reducible.x10"
            final $T t$136375 = (($T)(this.zeroVal));
            
            //#line 54 "x10/lang/Reducible.x10"
            final $T t$136376 = (($T)(((x10.lang.Reducible.MaxReducer<$T>)other).zeroVal));
            
            //#line 54 "x10/lang/Reducible.x10"
            final boolean t$136377 = x10.rtt.Equality.equalsequals((t$136375),(t$136376));
            
            //#line 54 "x10/lang/Reducible.x10"
            return t$136377;
        }
        
        
        //#line 54 "x10/lang/Reducible.x10"
        final public boolean _struct_equals$O(java.lang.Object other) {
            
            //#line 54 "x10/lang/Reducible.x10"
            final boolean t$136379 = x10.lang.Reducible.MaxReducer.$RTT.isInstance(other, $T);
            
            //#line 54 "x10/lang/Reducible.x10"
            final boolean t$136380 = !(t$136379);
            
            //#line 54 "x10/lang/Reducible.x10"
            if (t$136380) {
                
                //#line 54 "x10/lang/Reducible.x10"
                return false;
            }
            
            //#line 54 "x10/lang/Reducible.x10"
            final x10.lang.Reducible.MaxReducer this$136281 = ((x10.lang.Reducible.MaxReducer)(this));
            
            //#line 54 "x10/lang/Reducible.x10"
            x10.lang.Reducible.MaxReducer other$136280 = ((x10.lang.Reducible.MaxReducer)(((x10.lang.Reducible.MaxReducer)x10.rtt.Types.asStruct(x10.rtt.ParameterizedType.make(x10.lang.Reducible.MaxReducer.$RTT, $T),other))));
            
            //#line 54 "x10/lang/Reducible.x10"
            final $T t$136383 = (($T)(((x10.lang.Reducible.MaxReducer<$T>)this$136281).zeroVal));
            
            //#line 54 "x10/lang/Reducible.x10"
            final $T t$136384 = (($T)(((x10.lang.Reducible.MaxReducer<$T>)other$136280).zeroVal));
            
            //#line 54 "x10/lang/Reducible.x10"
            final boolean t$136385 = x10.rtt.Equality.equalsequals((t$136383),(t$136384));
            
            //#line 54 "x10/lang/Reducible.x10"
            return t$136385;
        }
        
        
        //#line 54 "x10/lang/Reducible.x10"
        final public boolean _struct_equals__0$1x10$lang$Reducible$MaxReducer$$T$2$O(x10.lang.Reducible.MaxReducer other) {
            
            //#line 54 "x10/lang/Reducible.x10"
            final $T t$136387 = (($T)(this.zeroVal));
            
            //#line 54 "x10/lang/Reducible.x10"
            final $T t$136388 = (($T)(((x10.lang.Reducible.MaxReducer<$T>)other).zeroVal));
            
            //#line 54 "x10/lang/Reducible.x10"
            final boolean t$136389 = x10.rtt.Equality.equalsequals((t$136387),(t$136388));
            
            //#line 54 "x10/lang/Reducible.x10"
            return t$136389;
        }
        
        
        //#line 54 "x10/lang/Reducible.x10"
        final public x10.lang.Reducible.MaxReducer x10$lang$Reducible$MaxReducer$$this$x10$lang$Reducible$MaxReducer() {
            
            //#line 54 "x10/lang/Reducible.x10"
            return x10.lang.Reducible.MaxReducer.this;
        }
        
        
        //#line 54 "x10/lang/Reducible.x10"
        final public void __fieldInitializers_x10_lang_Reducible_MaxReducer() {
            
        }
    }
    
}

