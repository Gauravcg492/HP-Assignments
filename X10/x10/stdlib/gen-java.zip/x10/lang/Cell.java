package x10.lang;

/**
 * A mutable cell containing a value.
 * Typical usages are to put a struct on the heap, or to 
 * capture a mutable location in a closure.
 *
 * @param T the type of the stored value
 */
@x10.runtime.impl.java.X10Generated
final public class Cell<$T> extends x10.core.Ref implements x10.serialization.X10JavaSerializable
{
    public static final x10.rtt.RuntimeType<Cell> $RTT = 
        x10.rtt.NamedType.<Cell> make("x10.lang.Cell",
                                      Cell.class,
                                      1);
    
    public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
    
    public x10.rtt.Type<?> $getParam(int i) { if (i == 0) return $T; return null; }
    
    private Object writeReplace() throws java.io.ObjectStreamException {
        return new x10.serialization.SerializationProxy(this);
    }
    
    public static <$T> x10.serialization.X10JavaSerializable $_deserialize_body(x10.lang.Cell<$T> $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
        $_obj.$T = (x10.rtt.Type) $deserializer.readObject();
        $_obj.value = $deserializer.readObject();
        return $_obj;
    }
    
    public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
        x10.lang.Cell $_obj = new x10.lang.Cell((java.lang.System[]) null, (x10.rtt.Type) null);
        $deserializer.record_reference($_obj);
        return $_deserialize_body($_obj, $deserializer);
    }
    
    public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
        $serializer.write(this.$T);
        $serializer.write(this.value);
        
    }
    
    // constructor just for allocation
    public Cell(final java.lang.System[] $dummy, final x10.rtt.Type $T) {
        x10.lang.Cell.$initParams(this, $T);
        
    }
    
    private x10.rtt.Type $T;
    
    // initializer of type parameters
    public static void $initParams(final Cell $this, final x10.rtt.Type $T) {
        $this.$T = $T;
        
    }
    // synthetic type for parameter mangling
    public static final class __0x10$lang$Cell$$T {}
    

    
    //#line 26 "x10/lang/Cell.x10"
    /**
     * The value stored in this cell.
     */
    public $T value;
    
    
    //#line 33 "x10/lang/Cell.x10"
    /**
     * Construct a cell with the given value.
     *
     * @param x the given value
     */
    // creation method for java code (1-phase java constructor)
    public Cell(final x10.rtt.Type $T, final $T x, __0x10$lang$Cell$$T $dummy) {
        this((java.lang.System[]) null, $T);
        x10$lang$Cell$$init$S(x, (x10.lang.Cell.__0x10$lang$Cell$$T) null);
    }
    
    // constructor for non-virtual call
    final public x10.lang.Cell<$T> x10$lang$Cell$$init$S(final $T x, __0x10$lang$Cell$$T $dummy) {
         {
            
            //#line 33 "x10/lang/Cell.x10"
            
            
            //#line 33 "x10/lang/Cell.x10"
            ((x10.lang.Cell<$T>)this).value = (($T)(x));
        }
        return this;
    }
    
    
    
    //#line 38 "x10/lang/Cell.x10"
    /**
     * Return a string representation of the Cell.
     */
    public java.lang.String toString() {
        
        //#line 39 "x10/lang/Cell.x10"
        final $T t$131666 = (($T)(this.value));
        
        //#line 39 "x10/lang/Cell.x10"
        final boolean t$131668 = ((t$131666) == (null));
        
        //#line 39 "x10/lang/Cell.x10"
        java.lang.String t$131669 =  null;
        
        //#line 39 "x10/lang/Cell.x10"
        if (t$131668) {
            
            //#line 39 "x10/lang/Cell.x10"
            t$131669 = "null";
        } else {
            
            //#line 39 "x10/lang/Cell.x10"
            final $T t$131667 = (($T)(this.value));
            
            //#line 39 "x10/lang/Cell.x10"
            t$131669 = x10.rtt.Types.toString(((java.lang.Object)(t$131667)));
        }
        
        //#line 39 "x10/lang/Cell.x10"
        final java.lang.String t$131671 = (("Cell(") + (t$131669));
        
        //#line 39 "x10/lang/Cell.x10"
        final java.lang.String t$131672 = ((t$131671) + (")"));
        
        //#line 39 "x10/lang/Cell.x10"
        return t$131672;
    }
    
    
    //#line 48 "x10/lang/Cell.x10"
    /**
     * Return the value stored in the Cell.
     *
     * @return the current value stored in the Cell.
     */
    public $T $apply$G() {
        
        //#line 48 "x10/lang/Cell.x10"
        final $T t$131673 = (($T)(this.value));
        
        //#line 48 "x10/lang/Cell.x10"
        return t$131673;
    }
    
    
    //#line 55 "x10/lang/Cell.x10"
    /**
     * Set the value stored in the Cell to the new value.
     *
     * @param x the new value
     */
    public void $apply__0x10$lang$Cell$$T(final $T x) {
        
        //#line 55 "x10/lang/Cell.x10"
        ((x10.lang.Cell<$T>)this).value = (($T)(x));
    }
    
    
    //#line 63 "x10/lang/Cell.x10"
    /**
     * Set the value stored in the Cell to the new value.
     *
     * @param x the new value
     * @return the new value stored in the Cell.
     */
    public void $set__0x10$lang$Cell$$T(final $T x) {
        
        //#line 63 "x10/lang/Cell.x10"
        final x10.lang.Cell this$131655 = ((x10.lang.Cell)(this));
        
        //#line 64 . "x10/lang/Cell.x10"
        ((x10.lang.Cell<$T>)this$131655).value = (($T)(x));
    }
    
    
    //#line 64 "x10/lang/Cell.x10"
    public $T set__0x10$lang$Cell$$T$G(final $T x) {
        
        //#line 64 "x10/lang/Cell.x10"
        ((x10.lang.Cell<$T>)this).value = (($T)(x));
        
        //#line 64 "x10/lang/Cell.x10"
        return x;
    }
    
    
    //#line 74 "x10/lang/Cell.x10"
    /**
     * Create a new Cell with the given value stored in it.
     *
     * @param T the value type of the Cell
     * @param x the given value
     * @return a new Cell with the given value stored in it.
     */
    public static <$T>x10.lang.Cell make__0x10$lang$Cell$$T(final x10.rtt.Type $T, final $T x) {
        
        //#line 74 "x10/lang/Cell.x10"
        final x10.lang.Cell alloc$131651 = ((x10.lang.Cell)(new x10.lang.Cell<$T>((java.lang.System[]) null, $T)));
        
        //#line 33 . "x10/lang/Cell.x10"
        ((x10.lang.Cell<$T>)alloc$131651).value = (($T)(x));
        
        //#line 74 "x10/lang/Cell.x10"
        return alloc$131651;
    }
    
    
    //#line 83 "x10/lang/Cell.x10"
    /**
     * Create a new Cell with the given value stored in it.
     *
     * @param T the value type of the Cell
     * @param x the given value
     * @return a new Cell with the given value stored in it.
     */
    public static <$W>x10.lang.Cell $implicit_convert__0x10$lang$Cell$$W(final x10.rtt.Type $W, final $W x) {
        
        //#line 74 . "x10/lang/Cell.x10"
        final x10.lang.Cell alloc$131661 = ((x10.lang.Cell)(new x10.lang.Cell<$W>((java.lang.System[]) null, $W)));
        
        //#line 33 .. "x10/lang/Cell.x10"
        ((x10.lang.Cell<$W>)alloc$131661).value = (($W)(x));
        
        //#line 83 "x10/lang/Cell.x10"
        return alloc$131661;
    }
    
    
    //#line 21 "x10/lang/Cell.x10"
    final public x10.lang.Cell x10$lang$Cell$$this$x10$lang$Cell() {
        
        //#line 21 "x10/lang/Cell.x10"
        return x10.lang.Cell.this;
    }
    
    
    //#line 21 "x10/lang/Cell.x10"
    final public void __fieldInitializers_x10_lang_Cell() {
        
    }
}

