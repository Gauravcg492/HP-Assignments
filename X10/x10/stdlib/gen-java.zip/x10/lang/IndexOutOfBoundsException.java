package x10.lang;


/**
 * Thrown to indicate that an index of some sort (such as to an array, or to a
 * string) is out of range.
 */
;

