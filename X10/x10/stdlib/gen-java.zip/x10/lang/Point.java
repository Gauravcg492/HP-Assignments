package x10.lang;


/**
 * The type <code>Point(rank)</code> represents a point in a
 * rank-dimensional space. The coordinates of a point <code>p</code>
 * may be accessed individually (with zero-based indexing) using
 * <code>p(i)</code> because <code>Point</code> implements
 * <code>(Long)=>Long</code>.
 * Point arithmetic is supported.
 */
@x10.runtime.impl.java.X10Generated
final public class Point extends x10.core.Ref implements x10.core.fun.Fun_0_1, x10.util.Ordered, java.lang.Comparable, x10.serialization.X10JavaSerializable
{
    public static final x10.rtt.RuntimeType<Point> $RTT = 
        x10.rtt.NamedType.<Point> make("x10.lang.Point",
                                       Point.class,
                                       new x10.rtt.Type[] {
                                           x10.rtt.ParameterizedType.make(x10.core.fun.Fun_0_1.$RTT, x10.rtt.Types.LONG, x10.rtt.Types.LONG),
                                           x10.rtt.ParameterizedType.make(x10.util.Ordered.$RTT, x10.rtt.UnresolvedType.THIS),
                                           x10.rtt.ParameterizedType.make(x10.rtt.Types.COMPARABLE, x10.rtt.UnresolvedType.THIS)
                                       });
    
    public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
    
    public x10.rtt.Type<?> $getParam(int i) { return null; }
    
    private Object writeReplace() throws java.io.ObjectStreamException {
        return new x10.serialization.SerializationProxy(this);
    }
    
    public static x10.serialization.X10JavaSerializable $_deserialize_body(x10.lang.Point $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
        $_obj.c0 = $deserializer.readLong();
        $_obj.c1 = $deserializer.readLong();
        $_obj.c2 = $deserializer.readLong();
        $_obj.c3 = $deserializer.readLong();
        $_obj.cs = $deserializer.readObject();
        $_obj.rank = $deserializer.readLong();
        return $_obj;
    }
    
    public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
        x10.lang.Point $_obj = new x10.lang.Point((java.lang.System[]) null);
        $deserializer.record_reference($_obj);
        return $_deserialize_body($_obj, $deserializer);
    }
    
    public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
        $serializer.write(this.c0);
        $serializer.write(this.c1);
        $serializer.write(this.c2);
        $serializer.write(this.c3);
        $serializer.write(this.cs);
        $serializer.write(this.rank);
        
    }
    
    // constructor just for allocation
    public Point(final java.lang.System[] $dummy) {
        
    }
    
    // dispatcher for method abstract public (Z1)=>U.operator()(a1:Z1){}:U
    public java.lang.Object $apply(final java.lang.Object a1, final x10.rtt.Type t1) {
        return x10.core.Long.$box($apply$O(x10.core.Long.$unbox(a1)));
        
    }
    
    // dispatcher for method abstract public (Z1)=>U.operator()(a1:Z1){}:U
    public long $apply$J(final java.lang.Object a1, final x10.rtt.Type t1) {
        return $apply$O(x10.core.Long.$unbox(a1));
        
    }
    
    // dispatcher for method abstract public x10.util.Ordered[T].operator<(that:T){}:x10.lang.Boolean
    public java.lang.Object $lt(final java.lang.Object a1, final x10.rtt.Type t1) {
        return x10.core.Boolean.$box($lt$O((x10.lang.Point)a1));
        
    }
    
    // dispatcher for method abstract public x10.util.Ordered[T].operator<(that:T){}:x10.lang.Boolean
    public boolean $lt$Z(final java.lang.Object a1, final x10.rtt.Type t1) {
        return $lt$O((x10.lang.Point)a1);
        
    }
    
    // dispatcher for method abstract public x10.util.Ordered[T].operator>(that:T){}:x10.lang.Boolean
    public java.lang.Object $gt(final java.lang.Object a1, final x10.rtt.Type t1) {
        return x10.core.Boolean.$box($gt$O((x10.lang.Point)a1));
        
    }
    
    // dispatcher for method abstract public x10.util.Ordered[T].operator>(that:T){}:x10.lang.Boolean
    public boolean $gt$Z(final java.lang.Object a1, final x10.rtt.Type t1) {
        return $gt$O((x10.lang.Point)a1);
        
    }
    
    // dispatcher for method abstract public x10.util.Ordered[T].operator<=(that:T){}:x10.lang.Boolean
    public java.lang.Object $le(final java.lang.Object a1, final x10.rtt.Type t1) {
        return x10.core.Boolean.$box($le$O((x10.lang.Point)a1));
        
    }
    
    // dispatcher for method abstract public x10.util.Ordered[T].operator<=(that:T){}:x10.lang.Boolean
    public boolean $le$Z(final java.lang.Object a1, final x10.rtt.Type t1) {
        return $le$O((x10.lang.Point)a1);
        
    }
    
    // dispatcher for method abstract public x10.util.Ordered[T].operator>=(that:T){}:x10.lang.Boolean
    public java.lang.Object $ge(final java.lang.Object a1, final x10.rtt.Type t1) {
        return x10.core.Boolean.$box($ge$O((x10.lang.Point)a1));
        
    }
    
    // dispatcher for method abstract public x10.util.Ordered[T].operator>=(that:T){}:x10.lang.Boolean
    public boolean $ge$Z(final java.lang.Object a1, final x10.rtt.Type t1) {
        return $ge$O((x10.lang.Point)a1);
        
    }
    
    // synthetic type for parameter mangling
    public static final class __0$1x10$lang$Long$2 {}
    
    // properties
    
    //#line 24 "x10/lang/Point.x10"
    public long rank;
    

    
    //#line 27 "x10/lang/Point.x10"
    public long c0;
    
    //#line 28 "x10/lang/Point.x10"
    public long c1;
    
    //#line 29 "x10/lang/Point.x10"
    public long c2;
    
    //#line 30 "x10/lang/Point.x10"
    public long c3;
    
    //#line 31 "x10/lang/Point.x10"
    public x10.core.Rail<x10.core.Long> cs;
    
    
    //#line 33 "x10/lang/Point.x10"
    // creation method for java code (1-phase java constructor)
    public Point(final x10.core.Rail<x10.core.Long> coords, __0$1x10$lang$Long$2 $dummy) {
        this((java.lang.System[]) null);
        x10$lang$Point$$init$S(coords, (x10.lang.Point.__0$1x10$lang$Long$2) null);
    }
    
    // constructor for non-virtual call
    final public x10.lang.Point x10$lang$Point$$init$S(final x10.core.Rail<x10.core.Long> coords, __0$1x10$lang$Long$2 $dummy) {
         {
            
            //#line 34 "x10/lang/Point.x10"
            final long t$136055 = ((x10.core.Rail<x10.core.Long>)coords).size;
            
            //#line 34 "x10/lang/Point.x10"
            this.rank = t$136055;
            
            
            //#line 36 "x10/lang/Point.x10"
            final long t$135695 = ((long[])coords.value)[(int)0L];
            
            //#line 36 "x10/lang/Point.x10"
            this.c0 = t$135695;
            
            //#line 37 "x10/lang/Point.x10"
            final long t$135696 = this.rank;
            
            //#line 37 "x10/lang/Point.x10"
            final boolean t$135697 = ((t$135696) > (((long)(1L))));
            
            //#line 37 "x10/lang/Point.x10"
            long t$135698 =  0;
            
            //#line 37 "x10/lang/Point.x10"
            if (t$135697) {
                
                //#line 37 "x10/lang/Point.x10"
                t$135698 = ((long[])coords.value)[(int)1L];
            } else {
                
                //#line 37 "x10/lang/Point.x10"
                t$135698 = 0L;
            }
            
            //#line 37 "x10/lang/Point.x10"
            this.c1 = t$135698;
            
            //#line 38 "x10/lang/Point.x10"
            final long t$135700 = this.rank;
            
            //#line 38 "x10/lang/Point.x10"
            final boolean t$135701 = ((t$135700) > (((long)(2L))));
            
            //#line 38 "x10/lang/Point.x10"
            long t$135702 =  0;
            
            //#line 38 "x10/lang/Point.x10"
            if (t$135701) {
                
                //#line 38 "x10/lang/Point.x10"
                t$135702 = ((long[])coords.value)[(int)2L];
            } else {
                
                //#line 38 "x10/lang/Point.x10"
                t$135702 = 0L;
            }
            
            //#line 38 "x10/lang/Point.x10"
            this.c2 = t$135702;
            
            //#line 39 "x10/lang/Point.x10"
            final long t$135704 = this.rank;
            
            //#line 39 "x10/lang/Point.x10"
            final boolean t$135705 = ((t$135704) > (((long)(3L))));
            
            //#line 39 "x10/lang/Point.x10"
            long t$135706 =  0;
            
            //#line 39 "x10/lang/Point.x10"
            if (t$135705) {
                
                //#line 39 "x10/lang/Point.x10"
                t$135706 = ((long[])coords.value)[(int)3L];
            } else {
                
                //#line 39 "x10/lang/Point.x10"
                t$135706 = 0L;
            }
            
            //#line 39 "x10/lang/Point.x10"
            this.c3 = t$135706;
            
            //#line 40 "x10/lang/Point.x10"
            final long t$135708 = this.rank;
            
            //#line 40 "x10/lang/Point.x10"
            final boolean t$135709 = ((t$135708) > (((long)(4L))));
            
            //#line 40 "x10/lang/Point.x10"
            x10.core.Rail t$135710 =  null;
            
            //#line 40 "x10/lang/Point.x10"
            if (t$135709) {
                
                //#line 40 "x10/lang/Point.x10"
                t$135710 = ((x10.core.Rail)(coords));
            } else {
                
                //#line 40 "x10/lang/Point.x10"
                t$135710 = null;
            }
            
            //#line 40 "x10/lang/Point.x10"
            this.cs = ((x10.core.Rail)(t$135710));
        }
        return this;
    }
    
    
    
    //#line 43 "x10/lang/Point.x10"
    // creation method for java code (1-phase java constructor)
    public Point(final long i0) {
        this((java.lang.System[]) null);
        x10$lang$Point$$init$S(i0);
    }
    
    // constructor for non-virtual call
    final public x10.lang.Point x10$lang$Point$$init$S(final long i0) {
         {
            
            //#line 44 "x10/lang/Point.x10"
            this.rank = 1L;
            
            
            //#line 45 "x10/lang/Point.x10"
            this.c0 = i0;
            
            //#line 46 "x10/lang/Point.x10"
            final long t$135712 = this.c3 = 0L;
            
            //#line 46 "x10/lang/Point.x10"
            final long t$135713 = this.c2 = t$135712;
            
            //#line 46 "x10/lang/Point.x10"
            this.c1 = t$135713;
            
            //#line 47 "x10/lang/Point.x10"
            this.cs = null;
        }
        return this;
    }
    
    
    
    //#line 50 "x10/lang/Point.x10"
    // creation method for java code (1-phase java constructor)
    public Point(final long i0, final long i1) {
        this((java.lang.System[]) null);
        x10$lang$Point$$init$S(i0, i1);
    }
    
    // constructor for non-virtual call
    final public x10.lang.Point x10$lang$Point$$init$S(final long i0, final long i1) {
         {
            
            //#line 51 "x10/lang/Point.x10"
            this.rank = 2L;
            
            
            //#line 52 "x10/lang/Point.x10"
            this.c0 = i0;
            
            //#line 53 "x10/lang/Point.x10"
            this.c1 = i1;
            
            //#line 54 "x10/lang/Point.x10"
            final long t$135714 = this.c3 = 0L;
            
            //#line 54 "x10/lang/Point.x10"
            this.c2 = t$135714;
            
            //#line 55 "x10/lang/Point.x10"
            this.cs = null;
        }
        return this;
    }
    
    
    
    //#line 58 "x10/lang/Point.x10"
    // creation method for java code (1-phase java constructor)
    public Point(final long i0, final long i1, final long i2) {
        this((java.lang.System[]) null);
        x10$lang$Point$$init$S(i0, i1, i2);
    }
    
    // constructor for non-virtual call
    final public x10.lang.Point x10$lang$Point$$init$S(final long i0, final long i1, final long i2) {
         {
            
            //#line 59 "x10/lang/Point.x10"
            this.rank = 3L;
            
            
            //#line 60 "x10/lang/Point.x10"
            this.c0 = i0;
            
            //#line 61 "x10/lang/Point.x10"
            this.c1 = i1;
            
            //#line 62 "x10/lang/Point.x10"
            this.c2 = i2;
            
            //#line 63 "x10/lang/Point.x10"
            this.c3 = 0L;
            
            //#line 64 "x10/lang/Point.x10"
            this.cs = null;
        }
        return this;
    }
    
    
    
    //#line 67 "x10/lang/Point.x10"
    // creation method for java code (1-phase java constructor)
    public Point(final long i0, final long i1, final long i2, final long i3) {
        this((java.lang.System[]) null);
        x10$lang$Point$$init$S(i0, i1, i2, i3);
    }
    
    // constructor for non-virtual call
    final public x10.lang.Point x10$lang$Point$$init$S(final long i0, final long i1, final long i2, final long i3) {
         {
            
            //#line 68 "x10/lang/Point.x10"
            this.rank = 4L;
            
            
            //#line 69 "x10/lang/Point.x10"
            this.c0 = i0;
            
            //#line 70 "x10/lang/Point.x10"
            this.c1 = i1;
            
            //#line 71 "x10/lang/Point.x10"
            this.c2 = i2;
            
            //#line 72 "x10/lang/Point.x10"
            this.c3 = i3;
            
            //#line 73 "x10/lang/Point.x10"
            this.cs = null;
        }
        return this;
    }
    
    
    
    //#line 80 "x10/lang/Point.x10"
    /**
     * Returns the value of the ith coordinate.
     */
    public long $apply$O(final long i) {
        
        //#line 81 "x10/lang/Point.x10"
        boolean t$135716 = ((i) < (((long)(0L))));
        
        //#line 81 "x10/lang/Point.x10"
        if (!(t$135716)) {
            
            //#line 81 "x10/lang/Point.x10"
            final long t$135715 = this.rank;
            
            //#line 81 "x10/lang/Point.x10"
            t$135716 = ((i) >= (((long)(t$135715))));
        }
        
        //#line 81 "x10/lang/Point.x10"
        if (t$135716) {
            
            //#line 81 "x10/lang/Point.x10"
            final java.lang.String t$135717 = (("index ") + ((x10.core.Long.$box(i))));
            
            //#line 81 "x10/lang/Point.x10"
            final java.lang.String t$135718 = ((t$135717) + (" not contained in "));
            
            //#line 81 "x10/lang/Point.x10"
            final java.lang.String t$135719 = ((t$135718) + (this));
            
            //#line 81 "x10/lang/Point.x10"
            final java.lang.ArrayIndexOutOfBoundsException t$135720 = ((java.lang.ArrayIndexOutOfBoundsException)(new java.lang.ArrayIndexOutOfBoundsException(t$135719)));
            
            //#line 81 "x10/lang/Point.x10"
            throw t$135720;
        }
        
        //#line 82 "x10/lang/Point.x10"
        final boolean t$135723 = ((long) i) == ((long) 0L);
        
        //#line 82 "x10/lang/Point.x10"
        if (t$135723) {
            
            //#line 82 "x10/lang/Point.x10"
            final long t$135722 = this.c0;
            
            //#line 82 "x10/lang/Point.x10"
            return t$135722;
        }
        
        //#line 83 "x10/lang/Point.x10"
        final boolean t$135725 = ((long) i) == ((long) 1L);
        
        //#line 83 "x10/lang/Point.x10"
        if (t$135725) {
            
            //#line 83 "x10/lang/Point.x10"
            final long t$135724 = this.c1;
            
            //#line 83 "x10/lang/Point.x10"
            return t$135724;
        }
        
        //#line 84 "x10/lang/Point.x10"
        final boolean t$135727 = ((long) i) == ((long) 2L);
        
        //#line 84 "x10/lang/Point.x10"
        if (t$135727) {
            
            //#line 84 "x10/lang/Point.x10"
            final long t$135726 = this.c2;
            
            //#line 84 "x10/lang/Point.x10"
            return t$135726;
        }
        
        //#line 85 "x10/lang/Point.x10"
        final boolean t$135729 = ((long) i) == ((long) 3L);
        
        //#line 85 "x10/lang/Point.x10"
        if (t$135729) {
            
            //#line 85 "x10/lang/Point.x10"
            final long t$135728 = this.c3;
            
            //#line 85 "x10/lang/Point.x10"
            return t$135728;
        }
        
        //#line 86 "x10/lang/Point.x10"
        final x10.core.Rail t$135730 = ((x10.core.Rail)(this.cs));
        
        //#line 86 "x10/lang/Point.x10"
        final long t$135731 = ((long[])t$135730.value)[(int)i];
        
        //#line 86 "x10/lang/Point.x10"
        return t$135731;
    }
    
    
    //#line 92 "x10/lang/Point.x10"
    /**
     * Returns the coordinates as a <code>(Long)=>Long</code>.
     */
    public x10.core.fun.Fun_0_1 coords() {
        
        //#line 92 "x10/lang/Point.x10"
        final x10.core.fun.Fun_0_1 t$135733 = ((x10.core.fun.Fun_0_1)(new x10.lang.Point.$Closure$183(this)));
        
        //#line 92 "x10/lang/Point.x10"
        return t$135733;
    }
    
    
    //#line 97 "x10/lang/Point.x10"
    /**
     * Constructs a Point from a Rail[Int]
     */
    public static x10.lang.Point make__0$1x10$lang$Int$2(final x10.core.Rail<x10.core.Int> r) {
        
        //#line 98 "x10/lang/Point.x10"
        final long t$135734 = ((x10.core.Rail<x10.core.Int>)r).size;
        
        //#line 98 "x10/lang/Point.x10"
        final boolean t$135786 = ((long) t$135734) == ((long) 1L);
        
        //#line 98 "x10/lang/Point.x10"
        if (t$135786) {
            
            //#line 99 "x10/lang/Point.x10"
            final x10.lang.Point alloc$98481 = ((x10.lang.Point)(new x10.lang.Point((java.lang.System[]) null)));
            
            //#line 99 "x10/lang/Point.x10"
            final int t$136061 = ((int[])r.value)[(int)0L];
            
            //#line 99 "x10/lang/Point.x10"
            final long t$136062 = ((long)(((int)(t$136061))));
            
            //#line 99 "x10/lang/Point.x10"
            alloc$98481.x10$lang$Point$$init$S(t$136062);
            
            //#line 99 "x10/lang/Point.x10"
            final x10.lang.Point t$98041 = ((x10.lang.Point)
                                             alloc$98481);
            
            //#line 99 "x10/lang/Point.x10"
            final long t$135737 = t$98041.rank;
            
            //#line 99 "x10/lang/Point.x10"
            final long t$135738 = ((x10.core.Rail<x10.core.Int>)r).size;
            
            //#line 99 "x10/lang/Point.x10"
            final boolean t$135739 = ((long) t$135737) == ((long) t$135738);
            
            //#line 99 "x10/lang/Point.x10"
            final boolean t$135741 = !(t$135739);
            
            //#line 99 "x10/lang/Point.x10"
            if (t$135741) {
                
                //#line 99 "x10/lang/Point.x10"
                final x10.lang.FailedDynamicCheckException t$135740 = new x10.lang.FailedDynamicCheckException("x10.lang.Point{self.rank==r.size}");
                
                //#line 99 "x10/lang/Point.x10"
                throw t$135740;
            }
            
            //#line 99 "x10/lang/Point.x10"
            return t$98041;
        } else {
            
            //#line 100 "x10/lang/Point.x10"
            final long t$135742 = ((x10.core.Rail<x10.core.Int>)r).size;
            
            //#line 100 "x10/lang/Point.x10"
            final boolean t$135785 = ((long) t$135742) == ((long) 2L);
            
            //#line 100 "x10/lang/Point.x10"
            if (t$135785) {
                
                //#line 101 "x10/lang/Point.x10"
                final x10.lang.Point alloc$98482 = ((x10.lang.Point)(new x10.lang.Point((java.lang.System[]) null)));
                
                //#line 101 "x10/lang/Point.x10"
                final int t$136063 = ((int[])r.value)[(int)0L];
                
                //#line 101 "x10/lang/Point.x10"
                final long t$136064 = ((long)(((int)(t$136063))));
                
                //#line 101 "x10/lang/Point.x10"
                final int t$136065 = ((int[])r.value)[(int)1L];
                
                //#line 101 "x10/lang/Point.x10"
                final long t$136066 = ((long)(((int)(t$136065))));
                
                //#line 101 "x10/lang/Point.x10"
                alloc$98482.x10$lang$Point$$init$S(t$136064, t$136066);
                
                //#line 101 "x10/lang/Point.x10"
                final x10.lang.Point t$98043 = ((x10.lang.Point)
                                                 alloc$98482);
                
                //#line 101 "x10/lang/Point.x10"
                final long t$135747 = t$98043.rank;
                
                //#line 101 "x10/lang/Point.x10"
                final long t$135748 = ((x10.core.Rail<x10.core.Int>)r).size;
                
                //#line 101 "x10/lang/Point.x10"
                final boolean t$135749 = ((long) t$135747) == ((long) t$135748);
                
                //#line 101 "x10/lang/Point.x10"
                final boolean t$135751 = !(t$135749);
                
                //#line 101 "x10/lang/Point.x10"
                if (t$135751) {
                    
                    //#line 101 "x10/lang/Point.x10"
                    final x10.lang.FailedDynamicCheckException t$135750 = new x10.lang.FailedDynamicCheckException("x10.lang.Point{self.rank==r.size}");
                    
                    //#line 101 "x10/lang/Point.x10"
                    throw t$135750;
                }
                
                //#line 101 "x10/lang/Point.x10"
                return t$98043;
            } else {
                
                //#line 102 "x10/lang/Point.x10"
                final long t$135752 = ((x10.core.Rail<x10.core.Int>)r).size;
                
                //#line 102 "x10/lang/Point.x10"
                final boolean t$135784 = ((long) t$135752) == ((long) 3L);
                
                //#line 102 "x10/lang/Point.x10"
                if (t$135784) {
                    
                    //#line 103 "x10/lang/Point.x10"
                    final x10.lang.Point alloc$98483 = ((x10.lang.Point)(new x10.lang.Point((java.lang.System[]) null)));
                    
                    //#line 103 "x10/lang/Point.x10"
                    final int t$136067 = ((int[])r.value)[(int)0L];
                    
                    //#line 103 "x10/lang/Point.x10"
                    final long t$136068 = ((long)(((int)(t$136067))));
                    
                    //#line 103 "x10/lang/Point.x10"
                    final int t$136069 = ((int[])r.value)[(int)1L];
                    
                    //#line 103 "x10/lang/Point.x10"
                    final long t$136070 = ((long)(((int)(t$136069))));
                    
                    //#line 103 "x10/lang/Point.x10"
                    final int t$136071 = ((int[])r.value)[(int)2L];
                    
                    //#line 103 "x10/lang/Point.x10"
                    final long t$136072 = ((long)(((int)(t$136071))));
                    
                    //#line 103 "x10/lang/Point.x10"
                    alloc$98483.x10$lang$Point$$init$S(t$136068, t$136070, t$136072);
                    
                    //#line 103 "x10/lang/Point.x10"
                    final x10.lang.Point t$98045 = ((x10.lang.Point)
                                                     alloc$98483);
                    
                    //#line 103 "x10/lang/Point.x10"
                    final long t$135759 = t$98045.rank;
                    
                    //#line 103 "x10/lang/Point.x10"
                    final long t$135760 = ((x10.core.Rail<x10.core.Int>)r).size;
                    
                    //#line 103 "x10/lang/Point.x10"
                    final boolean t$135761 = ((long) t$135759) == ((long) t$135760);
                    
                    //#line 103 "x10/lang/Point.x10"
                    final boolean t$135763 = !(t$135761);
                    
                    //#line 103 "x10/lang/Point.x10"
                    if (t$135763) {
                        
                        //#line 103 "x10/lang/Point.x10"
                        final x10.lang.FailedDynamicCheckException t$135762 = new x10.lang.FailedDynamicCheckException("x10.lang.Point{self.rank==r.size}");
                        
                        //#line 103 "x10/lang/Point.x10"
                        throw t$135762;
                    }
                    
                    //#line 103 "x10/lang/Point.x10"
                    return t$98045;
                } else {
                    
                    //#line 104 "x10/lang/Point.x10"
                    final long t$135764 = ((x10.core.Rail<x10.core.Int>)r).size;
                    
                    //#line 104 "x10/lang/Point.x10"
                    final boolean t$135783 = ((long) t$135764) == ((long) 4L);
                    
                    //#line 104 "x10/lang/Point.x10"
                    if (t$135783) {
                        
                        //#line 105 "x10/lang/Point.x10"
                        final x10.lang.Point alloc$98484 = ((x10.lang.Point)(new x10.lang.Point((java.lang.System[]) null)));
                        
                        //#line 105 "x10/lang/Point.x10"
                        final int t$136073 = ((int[])r.value)[(int)0L];
                        
                        //#line 105 "x10/lang/Point.x10"
                        final long t$136074 = ((long)(((int)(t$136073))));
                        
                        //#line 105 "x10/lang/Point.x10"
                        final int t$136075 = ((int[])r.value)[(int)1L];
                        
                        //#line 105 "x10/lang/Point.x10"
                        final long t$136076 = ((long)(((int)(t$136075))));
                        
                        //#line 105 "x10/lang/Point.x10"
                        final int t$136077 = ((int[])r.value)[(int)2L];
                        
                        //#line 105 "x10/lang/Point.x10"
                        final long t$136078 = ((long)(((int)(t$136077))));
                        
                        //#line 105 "x10/lang/Point.x10"
                        final int t$136079 = ((int[])r.value)[(int)3L];
                        
                        //#line 105 "x10/lang/Point.x10"
                        final long t$136080 = ((long)(((int)(t$136079))));
                        
                        //#line 105 "x10/lang/Point.x10"
                        alloc$98484.x10$lang$Point$$init$S(t$136074, t$136076, t$136078, t$136080);
                        
                        //#line 105 "x10/lang/Point.x10"
                        final x10.lang.Point t$98047 = ((x10.lang.Point)
                                                         alloc$98484);
                        
                        //#line 105 "x10/lang/Point.x10"
                        final long t$135773 = t$98047.rank;
                        
                        //#line 105 "x10/lang/Point.x10"
                        final long t$135774 = ((x10.core.Rail<x10.core.Int>)r).size;
                        
                        //#line 105 "x10/lang/Point.x10"
                        final boolean t$135775 = ((long) t$135773) == ((long) t$135774);
                        
                        //#line 105 "x10/lang/Point.x10"
                        final boolean t$135777 = !(t$135775);
                        
                        //#line 105 "x10/lang/Point.x10"
                        if (t$135777) {
                            
                            //#line 105 "x10/lang/Point.x10"
                            final x10.lang.FailedDynamicCheckException t$135776 = new x10.lang.FailedDynamicCheckException("x10.lang.Point{self.rank==r.size}");
                            
                            //#line 105 "x10/lang/Point.x10"
                            throw t$135776;
                        }
                        
                        //#line 105 "x10/lang/Point.x10"
                        return t$98047;
                    } else {
                        
                        //#line 107 "x10/lang/Point.x10"
                        final x10.lang.Point alloc$98485 = ((x10.lang.Point)(new x10.lang.Point((java.lang.System[]) null)));
                        
                        //#line 107 "x10/lang/Point.x10"
                        final long t$136081 = ((x10.core.Rail<x10.core.Int>)r).size;
                        
                        //#line 107 "x10/lang/Point.x10"
                        final x10.core.fun.Fun_0_1 t$136082 = ((x10.core.fun.Fun_0_1)(new x10.lang.Point.$Closure$184(r, (x10.lang.Point.$Closure$184.__0$1x10$lang$Int$2) null)));
                        
                        //#line 107 "x10/lang/Point.x10"
                        final x10.core.Rail t$136086 = ((x10.core.Rail)(new x10.core.Rail<x10.core.Long>(x10.rtt.Types.LONG, ((long)(t$136081)), ((x10.core.fun.Fun_0_1)(t$136082)), (x10.core.Rail.__1$1x10$lang$Long$3x10$lang$Rail$$T$2) null)));
                        
                        //#line 107 "x10/lang/Point.x10"
                        alloc$98485.x10$lang$Point$$init$S(((x10.core.Rail)(t$136086)), (x10.lang.Point.__0$1x10$lang$Long$2) null);
                        
                        //#line 107 "x10/lang/Point.x10"
                        return alloc$98485;
                    }
                }
            }
        }
    }
    
    
    //#line 114 "x10/lang/Point.x10"
    /**
     * Constructs a Point from a Rail[Long]
     */
    public static x10.lang.Point make__0$1x10$lang$Long$2(final x10.core.Rail<x10.core.Long> r) {
        
        //#line 115 "x10/lang/Point.x10"
        final long t$135787 = ((x10.core.Rail<x10.core.Long>)r).size;
        
        //#line 115 "x10/lang/Point.x10"
        final boolean t$135826 = ((long) t$135787) == ((long) 1L);
        
        //#line 115 "x10/lang/Point.x10"
        if (t$135826) {
            
            //#line 116 "x10/lang/Point.x10"
            final x10.lang.Point alloc$98486 = ((x10.lang.Point)(new x10.lang.Point((java.lang.System[]) null)));
            
            //#line 116 "x10/lang/Point.x10"
            final long t$136087 = ((long[])r.value)[(int)0L];
            
            //#line 116 "x10/lang/Point.x10"
            alloc$98486.x10$lang$Point$$init$S(t$136087);
            
            //#line 116 "x10/lang/Point.x10"
            final x10.lang.Point t$98049 = ((x10.lang.Point)
                                             alloc$98486);
            
            //#line 116 "x10/lang/Point.x10"
            final long t$135789 = t$98049.rank;
            
            //#line 116 "x10/lang/Point.x10"
            final long t$135790 = ((x10.core.Rail<x10.core.Long>)r).size;
            
            //#line 116 "x10/lang/Point.x10"
            final boolean t$135791 = ((long) t$135789) == ((long) t$135790);
            
            //#line 116 "x10/lang/Point.x10"
            final boolean t$135793 = !(t$135791);
            
            //#line 116 "x10/lang/Point.x10"
            if (t$135793) {
                
                //#line 116 "x10/lang/Point.x10"
                final x10.lang.FailedDynamicCheckException t$135792 = new x10.lang.FailedDynamicCheckException("x10.lang.Point{self.rank==r.size}");
                
                //#line 116 "x10/lang/Point.x10"
                throw t$135792;
            }
            
            //#line 116 "x10/lang/Point.x10"
            return t$98049;
        } else {
            
            //#line 117 "x10/lang/Point.x10"
            final long t$135794 = ((x10.core.Rail<x10.core.Long>)r).size;
            
            //#line 117 "x10/lang/Point.x10"
            final boolean t$135825 = ((long) t$135794) == ((long) 2L);
            
            //#line 117 "x10/lang/Point.x10"
            if (t$135825) {
                
                //#line 118 "x10/lang/Point.x10"
                final x10.lang.Point alloc$98487 = ((x10.lang.Point)(new x10.lang.Point((java.lang.System[]) null)));
                
                //#line 118 "x10/lang/Point.x10"
                final long t$136088 = ((long[])r.value)[(int)0L];
                
                //#line 118 "x10/lang/Point.x10"
                final long t$136089 = ((long[])r.value)[(int)1L];
                
                //#line 118 "x10/lang/Point.x10"
                alloc$98487.x10$lang$Point$$init$S(t$136088, t$136089);
                
                //#line 118 "x10/lang/Point.x10"
                final x10.lang.Point t$98051 = ((x10.lang.Point)
                                                 alloc$98487);
                
                //#line 118 "x10/lang/Point.x10"
                final long t$135797 = t$98051.rank;
                
                //#line 118 "x10/lang/Point.x10"
                final long t$135798 = ((x10.core.Rail<x10.core.Long>)r).size;
                
                //#line 118 "x10/lang/Point.x10"
                final boolean t$135799 = ((long) t$135797) == ((long) t$135798);
                
                //#line 118 "x10/lang/Point.x10"
                final boolean t$135801 = !(t$135799);
                
                //#line 118 "x10/lang/Point.x10"
                if (t$135801) {
                    
                    //#line 118 "x10/lang/Point.x10"
                    final x10.lang.FailedDynamicCheckException t$135800 = new x10.lang.FailedDynamicCheckException("x10.lang.Point{self.rank==r.size}");
                    
                    //#line 118 "x10/lang/Point.x10"
                    throw t$135800;
                }
                
                //#line 118 "x10/lang/Point.x10"
                return t$98051;
            } else {
                
                //#line 119 "x10/lang/Point.x10"
                final long t$135802 = ((x10.core.Rail<x10.core.Long>)r).size;
                
                //#line 119 "x10/lang/Point.x10"
                final boolean t$135824 = ((long) t$135802) == ((long) 3L);
                
                //#line 119 "x10/lang/Point.x10"
                if (t$135824) {
                    
                    //#line 120 "x10/lang/Point.x10"
                    final x10.lang.Point alloc$98488 = ((x10.lang.Point)(new x10.lang.Point((java.lang.System[]) null)));
                    
                    //#line 120 "x10/lang/Point.x10"
                    final long t$136090 = ((long[])r.value)[(int)0L];
                    
                    //#line 120 "x10/lang/Point.x10"
                    final long t$136091 = ((long[])r.value)[(int)1L];
                    
                    //#line 120 "x10/lang/Point.x10"
                    final long t$136092 = ((long[])r.value)[(int)2L];
                    
                    //#line 120 "x10/lang/Point.x10"
                    alloc$98488.x10$lang$Point$$init$S(t$136090, t$136091, t$136092);
                    
                    //#line 120 "x10/lang/Point.x10"
                    final x10.lang.Point t$98053 = ((x10.lang.Point)
                                                     alloc$98488);
                    
                    //#line 120 "x10/lang/Point.x10"
                    final long t$135806 = t$98053.rank;
                    
                    //#line 120 "x10/lang/Point.x10"
                    final long t$135807 = ((x10.core.Rail<x10.core.Long>)r).size;
                    
                    //#line 120 "x10/lang/Point.x10"
                    final boolean t$135808 = ((long) t$135806) == ((long) t$135807);
                    
                    //#line 120 "x10/lang/Point.x10"
                    final boolean t$135810 = !(t$135808);
                    
                    //#line 120 "x10/lang/Point.x10"
                    if (t$135810) {
                        
                        //#line 120 "x10/lang/Point.x10"
                        final x10.lang.FailedDynamicCheckException t$135809 = new x10.lang.FailedDynamicCheckException("x10.lang.Point{self.rank==r.size}");
                        
                        //#line 120 "x10/lang/Point.x10"
                        throw t$135809;
                    }
                    
                    //#line 120 "x10/lang/Point.x10"
                    return t$98053;
                } else {
                    
                    //#line 121 "x10/lang/Point.x10"
                    final long t$135811 = ((x10.core.Rail<x10.core.Long>)r).size;
                    
                    //#line 121 "x10/lang/Point.x10"
                    final boolean t$135823 = ((long) t$135811) == ((long) 4L);
                    
                    //#line 121 "x10/lang/Point.x10"
                    if (t$135823) {
                        
                        //#line 122 "x10/lang/Point.x10"
                        final x10.lang.Point alloc$98489 = ((x10.lang.Point)(new x10.lang.Point((java.lang.System[]) null)));
                        
                        //#line 122 "x10/lang/Point.x10"
                        final long t$136093 = ((long[])r.value)[(int)0L];
                        
                        //#line 122 "x10/lang/Point.x10"
                        final long t$136094 = ((long[])r.value)[(int)1L];
                        
                        //#line 122 "x10/lang/Point.x10"
                        final long t$136095 = ((long[])r.value)[(int)2L];
                        
                        //#line 122 "x10/lang/Point.x10"
                        final long t$136096 = ((long[])r.value)[(int)3L];
                        
                        //#line 122 "x10/lang/Point.x10"
                        alloc$98489.x10$lang$Point$$init$S(t$136093, t$136094, t$136095, t$136096);
                        
                        //#line 122 "x10/lang/Point.x10"
                        final x10.lang.Point t$98055 = ((x10.lang.Point)
                                                         alloc$98489);
                        
                        //#line 122 "x10/lang/Point.x10"
                        final long t$135816 = t$98055.rank;
                        
                        //#line 122 "x10/lang/Point.x10"
                        final long t$135817 = ((x10.core.Rail<x10.core.Long>)r).size;
                        
                        //#line 122 "x10/lang/Point.x10"
                        final boolean t$135818 = ((long) t$135816) == ((long) t$135817);
                        
                        //#line 122 "x10/lang/Point.x10"
                        final boolean t$135820 = !(t$135818);
                        
                        //#line 122 "x10/lang/Point.x10"
                        if (t$135820) {
                            
                            //#line 122 "x10/lang/Point.x10"
                            final x10.lang.FailedDynamicCheckException t$135819 = new x10.lang.FailedDynamicCheckException("x10.lang.Point{self.rank==r.size}");
                            
                            //#line 122 "x10/lang/Point.x10"
                            throw t$135819;
                        }
                        
                        //#line 122 "x10/lang/Point.x10"
                        return t$98055;
                    } else {
                        
                        //#line 124 "x10/lang/Point.x10"
                        final x10.lang.Point alloc$98490 = ((x10.lang.Point)(new x10.lang.Point((java.lang.System[]) null)));
                        
                        //#line 124 "x10/lang/Point.x10"
                        final long t$136097 = ((x10.core.Rail<x10.core.Long>)r).size;
                        
                        //#line 124 "x10/lang/Point.x10"
                        final x10.core.Rail t$136098 = ((x10.core.Rail)(new x10.core.Rail<x10.core.Long>(x10.rtt.Types.LONG, ((long)(t$136097)), ((x10.core.fun.Fun_0_1)(r)), (x10.core.Rail.__1$1x10$lang$Long$3x10$lang$Rail$$T$2) null)));
                        
                        //#line 124 "x10/lang/Point.x10"
                        alloc$98490.x10$lang$Point$$init$S(((x10.core.Rail)(t$136098)), (x10.lang.Point.__0$1x10$lang$Long$2) null);
                        
                        //#line 124 "x10/lang/Point.x10"
                        return alloc$98490;
                    }
                }
            }
        }
    }
    
    
    //#line 131 "x10/lang/Point.x10"
    /**
     * Returns a <code>Point p</code> of rank <code>rank</code> with <code>p(i)=init(i)</code>.
     */
    public static x10.lang.Point make__1$1x10$lang$Long$3x10$lang$Long$2(final long rank, final x10.core.fun.Fun_0_1<x10.core.Long,x10.core.Long> init) {
        
        //#line 132 "x10/lang/Point.x10"
        final boolean t$135863 = ((long) rank) == ((long) 1L);
        
        //#line 132 "x10/lang/Point.x10"
        if (t$135863) {
            
            //#line 133 "x10/lang/Point.x10"
            final x10.lang.Point alloc$98491 = ((x10.lang.Point)(new x10.lang.Point((java.lang.System[]) null)));
            
            //#line 133 "x10/lang/Point.x10"
            final long t$136099 = x10.core.Long.$unbox(((x10.core.fun.Fun_0_1<x10.core.Long,x10.core.Long>)init).$apply(x10.core.Long.$box(0L), x10.rtt.Types.LONG));
            
            //#line 133 "x10/lang/Point.x10"
            alloc$98491.x10$lang$Point$$init$S(t$136099);
            
            //#line 133 "x10/lang/Point.x10"
            final x10.lang.Point t$98057 = ((x10.lang.Point)
                                             alloc$98491);
            
            //#line 133 "x10/lang/Point.x10"
            final long t$135828 = t$98057.rank;
            
            //#line 133 "x10/lang/Point.x10"
            final boolean t$135829 = ((long) t$135828) == ((long) rank);
            
            //#line 133 "x10/lang/Point.x10"
            final boolean t$135831 = !(t$135829);
            
            //#line 133 "x10/lang/Point.x10"
            if (t$135831) {
                
                //#line 133 "x10/lang/Point.x10"
                final x10.lang.FailedDynamicCheckException t$135830 = new x10.lang.FailedDynamicCheckException("x10.lang.Point{self.rank==rank}");
                
                //#line 133 "x10/lang/Point.x10"
                throw t$135830;
            }
            
            //#line 133 "x10/lang/Point.x10"
            return t$98057;
        } else {
            
            //#line 134 "x10/lang/Point.x10"
            final boolean t$135862 = ((long) rank) == ((long) 2L);
            
            //#line 134 "x10/lang/Point.x10"
            if (t$135862) {
                
                //#line 135 "x10/lang/Point.x10"
                final x10.lang.Point alloc$98492 = ((x10.lang.Point)(new x10.lang.Point((java.lang.System[]) null)));
                
                //#line 135 "x10/lang/Point.x10"
                final long t$136100 = x10.core.Long.$unbox(((x10.core.fun.Fun_0_1<x10.core.Long,x10.core.Long>)init).$apply(x10.core.Long.$box(0L), x10.rtt.Types.LONG));
                
                //#line 135 "x10/lang/Point.x10"
                final long t$136101 = x10.core.Long.$unbox(((x10.core.fun.Fun_0_1<x10.core.Long,x10.core.Long>)init).$apply(x10.core.Long.$box(1L), x10.rtt.Types.LONG));
                
                //#line 135 "x10/lang/Point.x10"
                alloc$98492.x10$lang$Point$$init$S(t$136100, t$136101);
                
                //#line 135 "x10/lang/Point.x10"
                final x10.lang.Point t$98059 = ((x10.lang.Point)
                                                 alloc$98492);
                
                //#line 135 "x10/lang/Point.x10"
                final long t$135834 = t$98059.rank;
                
                //#line 135 "x10/lang/Point.x10"
                final boolean t$135835 = ((long) t$135834) == ((long) rank);
                
                //#line 135 "x10/lang/Point.x10"
                final boolean t$135837 = !(t$135835);
                
                //#line 135 "x10/lang/Point.x10"
                if (t$135837) {
                    
                    //#line 135 "x10/lang/Point.x10"
                    final x10.lang.FailedDynamicCheckException t$135836 = new x10.lang.FailedDynamicCheckException("x10.lang.Point{self.rank==rank}");
                    
                    //#line 135 "x10/lang/Point.x10"
                    throw t$135836;
                }
                
                //#line 135 "x10/lang/Point.x10"
                return t$98059;
            } else {
                
                //#line 136 "x10/lang/Point.x10"
                final boolean t$135861 = ((long) rank) == ((long) 3L);
                
                //#line 136 "x10/lang/Point.x10"
                if (t$135861) {
                    
                    //#line 137 "x10/lang/Point.x10"
                    final x10.lang.Point alloc$98493 = ((x10.lang.Point)(new x10.lang.Point((java.lang.System[]) null)));
                    
                    //#line 137 "x10/lang/Point.x10"
                    final long t$136102 = x10.core.Long.$unbox(((x10.core.fun.Fun_0_1<x10.core.Long,x10.core.Long>)init).$apply(x10.core.Long.$box(0L), x10.rtt.Types.LONG));
                    
                    //#line 137 "x10/lang/Point.x10"
                    final long t$136103 = x10.core.Long.$unbox(((x10.core.fun.Fun_0_1<x10.core.Long,x10.core.Long>)init).$apply(x10.core.Long.$box(1L), x10.rtt.Types.LONG));
                    
                    //#line 137 "x10/lang/Point.x10"
                    final long t$136104 = x10.core.Long.$unbox(((x10.core.fun.Fun_0_1<x10.core.Long,x10.core.Long>)init).$apply(x10.core.Long.$box(2L), x10.rtt.Types.LONG));
                    
                    //#line 137 "x10/lang/Point.x10"
                    alloc$98493.x10$lang$Point$$init$S(t$136102, t$136103, t$136104);
                    
                    //#line 137 "x10/lang/Point.x10"
                    final x10.lang.Point t$98061 = ((x10.lang.Point)
                                                     alloc$98493);
                    
                    //#line 137 "x10/lang/Point.x10"
                    final long t$135841 = t$98061.rank;
                    
                    //#line 137 "x10/lang/Point.x10"
                    final boolean t$135842 = ((long) t$135841) == ((long) rank);
                    
                    //#line 137 "x10/lang/Point.x10"
                    final boolean t$135844 = !(t$135842);
                    
                    //#line 137 "x10/lang/Point.x10"
                    if (t$135844) {
                        
                        //#line 137 "x10/lang/Point.x10"
                        final x10.lang.FailedDynamicCheckException t$135843 = new x10.lang.FailedDynamicCheckException("x10.lang.Point{self.rank==rank}");
                        
                        //#line 137 "x10/lang/Point.x10"
                        throw t$135843;
                    }
                    
                    //#line 137 "x10/lang/Point.x10"
                    return t$98061;
                } else {
                    
                    //#line 138 "x10/lang/Point.x10"
                    final boolean t$135860 = ((long) rank) == ((long) 4L);
                    
                    //#line 138 "x10/lang/Point.x10"
                    if (t$135860) {
                        
                        //#line 139 "x10/lang/Point.x10"
                        final x10.lang.Point alloc$98494 = ((x10.lang.Point)(new x10.lang.Point((java.lang.System[]) null)));
                        
                        //#line 139 "x10/lang/Point.x10"
                        final long t$136105 = x10.core.Long.$unbox(((x10.core.fun.Fun_0_1<x10.core.Long,x10.core.Long>)init).$apply(x10.core.Long.$box(0L), x10.rtt.Types.LONG));
                        
                        //#line 139 "x10/lang/Point.x10"
                        final long t$136106 = x10.core.Long.$unbox(((x10.core.fun.Fun_0_1<x10.core.Long,x10.core.Long>)init).$apply(x10.core.Long.$box(1L), x10.rtt.Types.LONG));
                        
                        //#line 139 "x10/lang/Point.x10"
                        final long t$136107 = x10.core.Long.$unbox(((x10.core.fun.Fun_0_1<x10.core.Long,x10.core.Long>)init).$apply(x10.core.Long.$box(2L), x10.rtt.Types.LONG));
                        
                        //#line 139 "x10/lang/Point.x10"
                        final long t$136108 = x10.core.Long.$unbox(((x10.core.fun.Fun_0_1<x10.core.Long,x10.core.Long>)init).$apply(x10.core.Long.$box(3L), x10.rtt.Types.LONG));
                        
                        //#line 139 "x10/lang/Point.x10"
                        alloc$98494.x10$lang$Point$$init$S(t$136105, t$136106, t$136107, t$136108);
                        
                        //#line 139 "x10/lang/Point.x10"
                        final x10.lang.Point t$98063 = ((x10.lang.Point)
                                                         alloc$98494);
                        
                        //#line 139 "x10/lang/Point.x10"
                        final long t$135849 = t$98063.rank;
                        
                        //#line 139 "x10/lang/Point.x10"
                        final boolean t$135850 = ((long) t$135849) == ((long) rank);
                        
                        //#line 139 "x10/lang/Point.x10"
                        final boolean t$135852 = !(t$135850);
                        
                        //#line 139 "x10/lang/Point.x10"
                        if (t$135852) {
                            
                            //#line 139 "x10/lang/Point.x10"
                            final x10.lang.FailedDynamicCheckException t$135851 = new x10.lang.FailedDynamicCheckException("x10.lang.Point{self.rank==rank}");
                            
                            //#line 139 "x10/lang/Point.x10"
                            throw t$135851;
                        }
                        
                        //#line 139 "x10/lang/Point.x10"
                        return t$98063;
                    } else {
                        
                        //#line 141 "x10/lang/Point.x10"
                        final x10.lang.Point alloc$98495 = ((x10.lang.Point)(new x10.lang.Point((java.lang.System[]) null)));
                        
                        //#line 141 "x10/lang/Point.x10"
                        final x10.core.fun.Fun_0_1 t$136109 = ((x10.core.fun.Fun_0_1)(new x10.lang.Point.$Closure$185(init, (x10.lang.Point.$Closure$185.__0$1x10$lang$Long$3x10$lang$Long$2) null)));
                        
                        //#line 141 "x10/lang/Point.x10"
                        final x10.core.Rail t$136112 = ((x10.core.Rail)(new x10.core.Rail<x10.core.Long>(x10.rtt.Types.LONG, ((long)(rank)), ((x10.core.fun.Fun_0_1)(t$136109)), (x10.core.Rail.__1$1x10$lang$Long$3x10$lang$Rail$$T$2) null)));
                        
                        //#line 141 "x10/lang/Point.x10"
                        alloc$98495.x10$lang$Point$$init$S(((x10.core.Rail)(t$136112)), (x10.lang.Point.__0$1x10$lang$Long$2) null);
                        
                        //#line 141 "x10/lang/Point.x10"
                        final x10.lang.Point t$98065 = ((x10.lang.Point)
                                                         alloc$98495);
                        
                        //#line 141 "x10/lang/Point.x10"
                        final long t$135856 = t$98065.rank;
                        
                        //#line 141 "x10/lang/Point.x10"
                        final boolean t$135857 = ((long) t$135856) == ((long) rank);
                        
                        //#line 141 "x10/lang/Point.x10"
                        final boolean t$135859 = !(t$135857);
                        
                        //#line 141 "x10/lang/Point.x10"
                        if (t$135859) {
                            
                            //#line 141 "x10/lang/Point.x10"
                            final x10.lang.FailedDynamicCheckException t$135858 = new x10.lang.FailedDynamicCheckException("x10.lang.Point{self.rank==rank}");
                            
                            //#line 141 "x10/lang/Point.x10"
                            throw t$135858;
                        }
                        
                        //#line 141 "x10/lang/Point.x10"
                        return t$98065;
                    }
                }
            }
        }
    }
    
    
    //#line 146 "x10/lang/Point.x10"
    public static x10.lang.Point make(final int i0) {
        
        //#line 146 "x10/lang/Point.x10"
        final x10.lang.Point alloc$98496 = ((x10.lang.Point)(new x10.lang.Point((java.lang.System[]) null)));
        
        //#line 146 "x10/lang/Point.x10"
        final long t$136113 = ((long)(((int)(i0))));
        
        //#line 146 "x10/lang/Point.x10"
        alloc$98496.x10$lang$Point$$init$S(t$136113);
        
        //#line 146 "x10/lang/Point.x10"
        return alloc$98496;
    }
    
    
    //#line 147 "x10/lang/Point.x10"
    public static x10.lang.Point make(final int i0, final int i1) {
        
        //#line 147 "x10/lang/Point.x10"
        final x10.lang.Point alloc$98497 = ((x10.lang.Point)(new x10.lang.Point((java.lang.System[]) null)));
        
        //#line 147 "x10/lang/Point.x10"
        final long t$136114 = ((long)(((int)(i0))));
        
        //#line 147 "x10/lang/Point.x10"
        final long t$136115 = ((long)(((int)(i1))));
        
        //#line 147 "x10/lang/Point.x10"
        alloc$98497.x10$lang$Point$$init$S(t$136114, t$136115);
        
        //#line 147 "x10/lang/Point.x10"
        return alloc$98497;
    }
    
    
    //#line 148 "x10/lang/Point.x10"
    public static x10.lang.Point make(final int i0, final int i1, final int i2) {
        
        //#line 148 "x10/lang/Point.x10"
        final x10.lang.Point alloc$98498 = ((x10.lang.Point)(new x10.lang.Point((java.lang.System[]) null)));
        
        //#line 148 "x10/lang/Point.x10"
        final long t$136116 = ((long)(((int)(i0))));
        
        //#line 148 "x10/lang/Point.x10"
        final long t$136117 = ((long)(((int)(i1))));
        
        //#line 148 "x10/lang/Point.x10"
        final long t$136118 = ((long)(((int)(i2))));
        
        //#line 148 "x10/lang/Point.x10"
        alloc$98498.x10$lang$Point$$init$S(t$136116, t$136117, t$136118);
        
        //#line 148 "x10/lang/Point.x10"
        return alloc$98498;
    }
    
    
    //#line 149 "x10/lang/Point.x10"
    public static x10.lang.Point make(final int i0, final int i1, final int i2, final int i3) {
        
        //#line 149 "x10/lang/Point.x10"
        final x10.lang.Point alloc$98499 = ((x10.lang.Point)(new x10.lang.Point((java.lang.System[]) null)));
        
        //#line 149 "x10/lang/Point.x10"
        final long t$136119 = ((long)(((int)(i0))));
        
        //#line 149 "x10/lang/Point.x10"
        final long t$136120 = ((long)(((int)(i1))));
        
        //#line 149 "x10/lang/Point.x10"
        final long t$136121 = ((long)(((int)(i2))));
        
        //#line 149 "x10/lang/Point.x10"
        final long t$136122 = ((long)(((int)(i3))));
        
        //#line 149 "x10/lang/Point.x10"
        alloc$98499.x10$lang$Point$$init$S(t$136119, t$136120, t$136121, t$136122);
        
        //#line 149 "x10/lang/Point.x10"
        return alloc$98499;
    }
    
    
    //#line 151 "x10/lang/Point.x10"
    public static x10.lang.Point make(final long i0) {
        
        //#line 151 "x10/lang/Point.x10"
        final x10.lang.Point alloc$98500 = ((x10.lang.Point)(new x10.lang.Point((java.lang.System[]) null)));
        
        //#line 151 "x10/lang/Point.x10"
        alloc$98500.x10$lang$Point$$init$S(((long)(i0)));
        
        //#line 151 "x10/lang/Point.x10"
        return alloc$98500;
    }
    
    
    //#line 152 "x10/lang/Point.x10"
    public static x10.lang.Point make(final long i0, final long i1) {
        
        //#line 152 "x10/lang/Point.x10"
        final x10.lang.Point alloc$98501 = ((x10.lang.Point)(new x10.lang.Point((java.lang.System[]) null)));
        
        //#line 152 "x10/lang/Point.x10"
        alloc$98501.x10$lang$Point$$init$S(((long)(i0)), ((long)(i1)));
        
        //#line 152 "x10/lang/Point.x10"
        return alloc$98501;
    }
    
    
    //#line 153 "x10/lang/Point.x10"
    public static x10.lang.Point make(final long i0, final long i1, final long i2) {
        
        //#line 153 "x10/lang/Point.x10"
        final x10.lang.Point alloc$98502 = ((x10.lang.Point)(new x10.lang.Point((java.lang.System[]) null)));
        
        //#line 153 "x10/lang/Point.x10"
        alloc$98502.x10$lang$Point$$init$S(((long)(i0)), ((long)(i1)), ((long)(i2)));
        
        //#line 153 "x10/lang/Point.x10"
        return alloc$98502;
    }
    
    
    //#line 154 "x10/lang/Point.x10"
    public static x10.lang.Point make(final long i0, final long i1, final long i2, final long i3) {
        
        //#line 154 "x10/lang/Point.x10"
        final x10.lang.Point alloc$98503 = ((x10.lang.Point)(new x10.lang.Point((java.lang.System[]) null)));
        
        //#line 154 "x10/lang/Point.x10"
        alloc$98503.x10$lang$Point$$init$S(((long)(i0)), ((long)(i1)), ((long)(i2)), ((long)(i3)));
        
        //#line 154 "x10/lang/Point.x10"
        return alloc$98503;
    }
    
    
    //#line 162 "x10/lang/Point.x10"
    /** 
     * A <code>Rail</code> <code>r</code> of length <code>k</code> can be converted to a point <code>p</code>
     * of rank <code>k</code> with <code>p(i)=r(i)</code>.
     * LONG_RAIL: unsafe int cast
     */
    public static x10.lang.Point $implicit_convert__0$1x10$lang$Long$2(final x10.core.Rail<x10.core.Long> r) {
        
        //#line 162 "x10/lang/Point.x10"
        final x10.lang.Point t$135874 = ((x10.lang.Point)(x10.lang.Point.make__0$1x10$lang$Long$2(((x10.core.Rail)(r)))));
        
        //#line 162 "x10/lang/Point.x10"
        return t$135874;
    }
    
    
    //#line 168 "x10/lang/Point.x10"
    /** 
     * A <code>Rail</code> <code>r</code> of length <code>k</code> can be converted to a point <code>p</code>
     * of rank <code>k</code> with <code>p(i)=r(i)</code>.
     */
    public static x10.lang.Point $implicit_convert__0$1x10$lang$Int$2(final x10.core.Rail<x10.core.Int> r) {
        
        //#line 168 "x10/lang/Point.x10"
        final x10.lang.Point t$135875 = ((x10.lang.Point)(x10.lang.Point.make__0$1x10$lang$Int$2(((x10.core.Rail)(r)))));
        
        //#line 168 "x10/lang/Point.x10"
        return t$135875;
    }
    
    
    //#line 173 "x10/lang/Point.x10"
    /**
     * The point <code>+p</code> is the same as <code>p</code>.
     */
    public x10.lang.Point $plus() {
        
        //#line 173 "x10/lang/Point.x10"
        return this;
    }
    
    
    //#line 178 "x10/lang/Point.x10"
    /**  
     * The point <code>-p</code> is the same as <code>p</code> with each index negated.
     */
    public x10.lang.Point $minus() {
        
        //#line 179 "x10/lang/Point.x10"
        final long t$135878 = this.rank;
        
        //#line 179 "x10/lang/Point.x10"
        final x10.core.fun.Fun_0_1 t$135879 = ((x10.core.fun.Fun_0_1)(new x10.lang.Point.$Closure$186(this)));
        
        //#line 179 "x10/lang/Point.x10"
        final x10.lang.Point t$135880 = ((x10.lang.Point)(x10.lang.Point.make__1$1x10$lang$Long$3x10$lang$Long$2((long)(t$135878), ((x10.core.fun.Fun_0_1)(t$135879)))));
        
        //#line 179 "x10/lang/Point.x10"
        return t$135880;
    }
    
    
    //#line 184 "x10/lang/Point.x10"
    /**
     * The ith coordinate of point <code>p+q</code> is <code>p(i)+q(i)</code>.
     */
    public x10.lang.Point $plus(final x10.lang.Point that) {
        
        //#line 185 "x10/lang/Point.x10"
        final long t$135884 = this.rank;
        
        //#line 185 "x10/lang/Point.x10"
        final x10.core.fun.Fun_0_1 t$135885 = ((x10.core.fun.Fun_0_1)(new x10.lang.Point.$Closure$187(this, that)));
        
        //#line 185 "x10/lang/Point.x10"
        final x10.lang.Point t$135886 = ((x10.lang.Point)(x10.lang.Point.make__1$1x10$lang$Long$3x10$lang$Long$2((long)(t$135884), ((x10.core.fun.Fun_0_1)(t$135885)))));
        
        //#line 185 "x10/lang/Point.x10"
        return t$135886;
    }
    
    
    //#line 191 "x10/lang/Point.x10"
    /**
     * The ith coordinate of point <code>p-q</code> is <code>p(i)-q(i)</code>.
     */
    public x10.lang.Point $minus(final x10.lang.Point that) {
        
        //#line 192 "x10/lang/Point.x10"
        final long t$135890 = this.rank;
        
        //#line 192 "x10/lang/Point.x10"
        final x10.core.fun.Fun_0_1 t$135891 = ((x10.core.fun.Fun_0_1)(new x10.lang.Point.$Closure$188(this, that)));
        
        //#line 192 "x10/lang/Point.x10"
        final x10.lang.Point t$135892 = ((x10.lang.Point)(x10.lang.Point.make__1$1x10$lang$Long$3x10$lang$Long$2((long)(t$135890), ((x10.core.fun.Fun_0_1)(t$135891)))));
        
        //#line 192 "x10/lang/Point.x10"
        return t$135892;
    }
    
    
    //#line 197 "x10/lang/Point.x10"
    /** 
     * The ith coordinate of point <code>p*q</code> is <code>p(i)*q(i)</code>.
     */
    public x10.lang.Point $times(final x10.lang.Point that) {
        
        //#line 198 "x10/lang/Point.x10"
        final long t$135896 = this.rank;
        
        //#line 198 "x10/lang/Point.x10"
        final x10.core.fun.Fun_0_1 t$135897 = ((x10.core.fun.Fun_0_1)(new x10.lang.Point.$Closure$189(this, that)));
        
        //#line 198 "x10/lang/Point.x10"
        final x10.lang.Point t$135898 = ((x10.lang.Point)(x10.lang.Point.make__1$1x10$lang$Long$3x10$lang$Long$2((long)(t$135896), ((x10.core.fun.Fun_0_1)(t$135897)))));
        
        //#line 198 "x10/lang/Point.x10"
        return t$135898;
    }
    
    
    //#line 203 "x10/lang/Point.x10"
    /**  
     * The ith coordinate of point <code>p/q</code> is <code>p(i)/q(i)</code>.
     */
    public x10.lang.Point $over(final x10.lang.Point that) {
        
        //#line 204 "x10/lang/Point.x10"
        final long t$135902 = this.rank;
        
        //#line 204 "x10/lang/Point.x10"
        final x10.core.fun.Fun_0_1 t$135903 = ((x10.core.fun.Fun_0_1)(new x10.lang.Point.$Closure$190(this, that)));
        
        //#line 204 "x10/lang/Point.x10"
        final x10.lang.Point t$135904 = ((x10.lang.Point)(x10.lang.Point.make__1$1x10$lang$Long$3x10$lang$Long$2((long)(t$135902), ((x10.core.fun.Fun_0_1)(t$135903)))));
        
        //#line 204 "x10/lang/Point.x10"
        return t$135904;
    }
    
    
    //#line 209 "x10/lang/Point.x10"
    /**
     * The ith coordinate of point <code>p+c</code> is <code>p(i)+c</code>.
     */
    public x10.lang.Point $plus(final long c) {
        
        //#line 210 "x10/lang/Point.x10"
        final long t$135907 = this.rank;
        
        //#line 210 "x10/lang/Point.x10"
        final x10.core.fun.Fun_0_1 t$135908 = ((x10.core.fun.Fun_0_1)(new x10.lang.Point.$Closure$191(this, c)));
        
        //#line 210 "x10/lang/Point.x10"
        final x10.lang.Point t$135909 = ((x10.lang.Point)(x10.lang.Point.make__1$1x10$lang$Long$3x10$lang$Long$2((long)(t$135907), ((x10.core.fun.Fun_0_1)(t$135908)))));
        
        //#line 210 "x10/lang/Point.x10"
        return t$135909;
    }
    
    
    //#line 215 "x10/lang/Point.x10"
    /** 
     * The ith coordinate of point <code>p-c</code> is <code>p(i)-c</code>.
     */
    public x10.lang.Point $minus(final long c) {
        
        //#line 216 "x10/lang/Point.x10"
        final long t$135912 = this.rank;
        
        //#line 216 "x10/lang/Point.x10"
        final x10.core.fun.Fun_0_1 t$135913 = ((x10.core.fun.Fun_0_1)(new x10.lang.Point.$Closure$192(this, c)));
        
        //#line 216 "x10/lang/Point.x10"
        final x10.lang.Point t$135914 = ((x10.lang.Point)(x10.lang.Point.make__1$1x10$lang$Long$3x10$lang$Long$2((long)(t$135912), ((x10.core.fun.Fun_0_1)(t$135913)))));
        
        //#line 216 "x10/lang/Point.x10"
        return t$135914;
    }
    
    
    //#line 221 "x10/lang/Point.x10"
    /**
     * The ith coordinate of point <code>p*c</code> is <code>p(i)*c</code>.
     */
    public x10.lang.Point $times(final long c) {
        
        //#line 222 "x10/lang/Point.x10"
        final long t$135917 = this.rank;
        
        //#line 222 "x10/lang/Point.x10"
        final x10.core.fun.Fun_0_1 t$135918 = ((x10.core.fun.Fun_0_1)(new x10.lang.Point.$Closure$193(this, c)));
        
        //#line 222 "x10/lang/Point.x10"
        final x10.lang.Point t$135919 = ((x10.lang.Point)(x10.lang.Point.make__1$1x10$lang$Long$3x10$lang$Long$2((long)(t$135917), ((x10.core.fun.Fun_0_1)(t$135918)))));
        
        //#line 222 "x10/lang/Point.x10"
        return t$135919;
    }
    
    
    //#line 227 "x10/lang/Point.x10"
    /**
     * The ith coordinate of point <code>p/c</code> is <code>p(i)/c</code>.
     */
    public x10.lang.Point $over(final long c) {
        
        //#line 228 "x10/lang/Point.x10"
        final long t$135922 = this.rank;
        
        //#line 228 "x10/lang/Point.x10"
        final x10.core.fun.Fun_0_1 t$135923 = ((x10.core.fun.Fun_0_1)(new x10.lang.Point.$Closure$194(this, c)));
        
        //#line 228 "x10/lang/Point.x10"
        final x10.lang.Point t$135924 = ((x10.lang.Point)(x10.lang.Point.make__1$1x10$lang$Long$3x10$lang$Long$2((long)(t$135922), ((x10.core.fun.Fun_0_1)(t$135923)))));
        
        //#line 228 "x10/lang/Point.x10"
        return t$135924;
    }
    
    
    //#line 233 "x10/lang/Point.x10"
    /**
     * The ith coordinate of point <code>c+p</code> is <code>c+p(i)</code>.
     */
    public x10.lang.Point $inv_plus(final long c) {
        
        //#line 234 "x10/lang/Point.x10"
        final long t$135927 = this.rank;
        
        //#line 234 "x10/lang/Point.x10"
        final x10.core.fun.Fun_0_1 t$135928 = ((x10.core.fun.Fun_0_1)(new x10.lang.Point.$Closure$195(this, c)));
        
        //#line 234 "x10/lang/Point.x10"
        final x10.lang.Point t$135929 = ((x10.lang.Point)(x10.lang.Point.make__1$1x10$lang$Long$3x10$lang$Long$2((long)(t$135927), ((x10.core.fun.Fun_0_1)(t$135928)))));
        
        //#line 234 "x10/lang/Point.x10"
        return t$135929;
    }
    
    
    //#line 239 "x10/lang/Point.x10"
    /**
     * The ith coordinate of point <code>c-p</code> is <code>c-p(i)</code>.
     */
    public x10.lang.Point $inv_minus(final long c) {
        
        //#line 240 "x10/lang/Point.x10"
        final long t$135932 = this.rank;
        
        //#line 240 "x10/lang/Point.x10"
        final x10.core.fun.Fun_0_1 t$135933 = ((x10.core.fun.Fun_0_1)(new x10.lang.Point.$Closure$196(this, c)));
        
        //#line 240 "x10/lang/Point.x10"
        final x10.lang.Point t$135934 = ((x10.lang.Point)(x10.lang.Point.make__1$1x10$lang$Long$3x10$lang$Long$2((long)(t$135932), ((x10.core.fun.Fun_0_1)(t$135933)))));
        
        //#line 240 "x10/lang/Point.x10"
        return t$135934;
    }
    
    
    //#line 245 "x10/lang/Point.x10"
    /**
     * The ith coordinate of point <code>c*p</code> is <code>c*p(i)</code>.
     */
    public x10.lang.Point $inv_times(final long c) {
        
        //#line 246 "x10/lang/Point.x10"
        final long t$135937 = this.rank;
        
        //#line 246 "x10/lang/Point.x10"
        final x10.core.fun.Fun_0_1 t$135938 = ((x10.core.fun.Fun_0_1)(new x10.lang.Point.$Closure$197(this, c)));
        
        //#line 246 "x10/lang/Point.x10"
        final x10.lang.Point t$135939 = ((x10.lang.Point)(x10.lang.Point.make__1$1x10$lang$Long$3x10$lang$Long$2((long)(t$135937), ((x10.core.fun.Fun_0_1)(t$135938)))));
        
        //#line 246 "x10/lang/Point.x10"
        return t$135939;
    }
    
    
    //#line 251 "x10/lang/Point.x10"
    /**
     * The ith coordinate of point <code>c/p</code> is <code>c/p(i)</code>.
     */
    public x10.lang.Point $inv_over(final long c) {
        
        //#line 252 "x10/lang/Point.x10"
        final long t$135942 = this.rank;
        
        //#line 252 "x10/lang/Point.x10"
        final x10.core.fun.Fun_0_1 t$135943 = ((x10.core.fun.Fun_0_1)(new x10.lang.Point.$Closure$198(this, c)));
        
        //#line 252 "x10/lang/Point.x10"
        final x10.lang.Point t$135944 = ((x10.lang.Point)(x10.lang.Point.make__1$1x10$lang$Long$3x10$lang$Long$2((long)(t$135942), ((x10.core.fun.Fun_0_1)(t$135943)))));
        
        //#line 252 "x10/lang/Point.x10"
        return t$135944;
    }
    
    
    //#line 257 "x10/lang/Point.x10"
    /**
     * {@link Comparable#compareTo}
     */
    public int compareTo(final java.lang.Object that) {
        
        //#line 258 "x10/lang/Point.x10"
        final boolean t$135947 = this.equals(((java.lang.Object)(that)));
        
        //#line 258 "x10/lang/Point.x10"
        int t$135948 =  0;
        
        //#line 258 "x10/lang/Point.x10"
        if (t$135947) {
            
            //#line 258 "x10/lang/Point.x10"
            t$135948 = 0;
        } else {
            
            //#line 258 "x10/lang/Point.x10"
            final boolean t$135945 = this.$lt$O(((x10.lang.Point)(that)));
            
            //#line 258 "x10/lang/Point.x10"
            int t$135946 =  0;
            
            //#line 258 "x10/lang/Point.x10"
            if (t$135945) {
                
                //#line 258 "x10/lang/Point.x10"
                t$135946 = -1;
            } else {
                
                //#line 258 "x10/lang/Point.x10"
                t$135946 = 1;
            }
            
            //#line 258 "x10/lang/Point.x10"
            t$135948 = t$135946;
        }
        
        //#line 258 "x10/lang/Point.x10"
        return t$135948;
    }
    
    
    //#line 268 "x10/lang/Point.x10"
    /**
     * Compute the hashCode of a point by combining the
     * the coordinates in a multiple/xor chain.  This
     * should increase the randomness and overcomes the
     * fact that coordinates are biased to be small
     * positive numbers.
     */
    public int hashCode() {
        
        //#line 269 "x10/lang/Point.x10"
        long hc = this.$apply$O((long)(0L));
        
        //#line 270 "x10/lang/Point.x10"
        final long t$136133 = this.rank;
        
        //#line 270 "x10/lang/Point.x10"
        final long i$98505max$136134 = ((t$136133) - (((long)(1L))));
        
        //#line 270 "x10/lang/Point.x10"
        long i$136130 = 1L;
        
        //#line 270 "x10/lang/Point.x10"
        for (;
             true;
             ) {
            
            //#line 270 "x10/lang/Point.x10"
            final boolean t$136132 = ((i$136130) <= (((long)(i$98505max$136134))));
            
            //#line 270 "x10/lang/Point.x10"
            if (!(t$136132)) {
                
                //#line 270 "x10/lang/Point.x10"
                break;
            }
            
            //#line 271 "x10/lang/Point.x10"
            final long t$136124 = ((hc) * (((long)(17L))));
            
            //#line 271 "x10/lang/Point.x10"
            final long t$136125 = this.$apply$O((long)(i$136130));
            
            //#line 271 "x10/lang/Point.x10"
            final long t$136126 = ((t$136124) ^ (((long)(t$136125))));
            
            //#line 271 "x10/lang/Point.x10"
            hc = t$136126;
            
            //#line 270 "x10/lang/Point.x10"
            final long t$136129 = ((i$136130) + (((long)(1L))));
            
            //#line 270 "x10/lang/Point.x10"
            i$136130 = t$136129;
        }
        
        //#line 273 "x10/lang/Point.x10"
        final int t$135961 = ((int)(long)(((long)(hc))));
        
        //#line 273 "x10/lang/Point.x10"
        return t$135961;
    }
    
    
    //#line 280 "x10/lang/Point.x10"
    /** 
     * Two points of the same rank are equal if and only if their
     * corresponding indices are equal.
     */
    public boolean equals(final java.lang.Object other) {
        
        //#line 281 "x10/lang/Point.x10"
        final boolean t$135962 = x10.lang.Point.$RTT.isInstance(other);
        
        //#line 281 "x10/lang/Point.x10"
        final boolean t$135963 = !(t$135962);
        
        //#line 281 "x10/lang/Point.x10"
        if (t$135963) {
            
            //#line 281 "x10/lang/Point.x10"
            return false;
        }
        
        //#line 282 "x10/lang/Point.x10"
        final x10.lang.Point otherPoint = ((x10.lang.Point)(x10.rtt.Types.<x10.lang.Point> cast(other,x10.lang.Point.$RTT)));
        
        //#line 283 "x10/lang/Point.x10"
        final long t$135964 = this.rank;
        
        //#line 283 "x10/lang/Point.x10"
        final long t$135965 = otherPoint.rank;
        
        //#line 283 "x10/lang/Point.x10"
        final boolean t$135966 = ((long) t$135964) != ((long) t$135965);
        
        //#line 283 "x10/lang/Point.x10"
        if (t$135966) {
            
            //#line 283 "x10/lang/Point.x10"
            return false;
        }
        
        //#line 284 "x10/lang/Point.x10"
        final long t$136145 = this.rank;
        
        //#line 284 "x10/lang/Point.x10"
        final long i$98523max$136146 = ((t$136145) - (((long)(1L))));
        
        //#line 284 "x10/lang/Point.x10"
        long i$136142 = 0L;
        
        //#line 284 "x10/lang/Point.x10"
        for (;
             true;
             ) {
            
            //#line 284 "x10/lang/Point.x10"
            final boolean t$136144 = ((i$136142) <= (((long)(i$98523max$136146))));
            
            //#line 284 "x10/lang/Point.x10"
            if (!(t$136144)) {
                
                //#line 284 "x10/lang/Point.x10"
                break;
            }
            
            //#line 285 "x10/lang/Point.x10"
            final long t$136135 = this.$apply$O((long)(i$136142));
            
            //#line 285 "x10/lang/Point.x10"
            final long t$136136 = otherPoint.$apply$O((long)(i$136142));
            
            //#line 285 "x10/lang/Point.x10"
            final boolean t$136137 = ((long) t$136135) == ((long) t$136136);
            
            //#line 285 "x10/lang/Point.x10"
            final boolean t$136138 = !(t$136137);
            
            //#line 285 "x10/lang/Point.x10"
            if (t$136138) {
                
                //#line 286 "x10/lang/Point.x10"
                return false;
            }
            
            //#line 284 "x10/lang/Point.x10"
            final long t$136141 = ((i$136142) + (((long)(1L))));
            
            //#line 284 "x10/lang/Point.x10"
            i$136142 = t$136141;
        }
        
        //#line 288 "x10/lang/Point.x10"
        return true;
    }
    
    
    //#line 294 "x10/lang/Point.x10"
    /**
     * For points a, b, <code> a &lt; b</code> if <code>a</code> is lexicographically smaller than <code>b</code>.
     */
    public boolean $lt$O(final x10.lang.Point that) {
        
        //#line 295 "x10/lang/Point.x10"
        final long t$136157 = this.rank;
        
        //#line 295 "x10/lang/Point.x10"
        final long i$98541max$136158 = ((t$136157) - (((long)(2L))));
        
        //#line 295 "x10/lang/Point.x10"
        long i$136154 = 0L;
        
        //#line 295 "x10/lang/Point.x10"
        for (;
             true;
             ) {
            
            //#line 295 "x10/lang/Point.x10"
            final boolean t$136156 = ((i$136154) <= (((long)(i$98541max$136158))));
            
            //#line 295 "x10/lang/Point.x10"
            if (!(t$136156)) {
                
                //#line 295 "x10/lang/Point.x10"
                break;
            }
            
            //#line 296 "x10/lang/Point.x10"
            final long a$136147 = this.$apply$O((long)(i$136154));
            
            //#line 297 "x10/lang/Point.x10"
            final long b$136148 = that.$apply$O((long)(i$136154));
            
            //#line 298 "x10/lang/Point.x10"
            final boolean t$136149 = ((a$136147) > (((long)(b$136148))));
            
            //#line 298 "x10/lang/Point.x10"
            if (t$136149) {
                
                //#line 298 "x10/lang/Point.x10"
                return false;
            }
            
            //#line 299 "x10/lang/Point.x10"
            final boolean t$136150 = ((a$136147) < (((long)(b$136148))));
            
            //#line 299 "x10/lang/Point.x10"
            if (t$136150) {
                
                //#line 299 "x10/lang/Point.x10"
                return true;
            }
            
            //#line 295 "x10/lang/Point.x10"
            final long t$136153 = ((i$136154) + (((long)(1L))));
            
            //#line 295 "x10/lang/Point.x10"
            i$136154 = t$136153;
        }
        
        //#line 301 "x10/lang/Point.x10"
        final long t$135985 = this.rank;
        
        //#line 301 "x10/lang/Point.x10"
        final long t$135986 = ((t$135985) - (((long)(1L))));
        
        //#line 301 "x10/lang/Point.x10"
        final long t$135989 = this.$apply$O((long)(t$135986));
        
        //#line 301 "x10/lang/Point.x10"
        final long t$135987 = this.rank;
        
        //#line 301 "x10/lang/Point.x10"
        final long t$135988 = ((t$135987) - (((long)(1L))));
        
        //#line 301 "x10/lang/Point.x10"
        final long t$135990 = that.$apply$O((long)(t$135988));
        
        //#line 301 "x10/lang/Point.x10"
        final boolean t$135991 = ((t$135989) < (((long)(t$135990))));
        
        //#line 301 "x10/lang/Point.x10"
        return t$135991;
    }
    
    
    //#line 308 "x10/lang/Point.x10"
    /** 
     * For points <code>a, b</code>, <code> a &gt; b</code> if <code>a</code> 
     * is lexicographically bigger than <code> b</code>.
     */
    public boolean $gt$O(final x10.lang.Point that) {
        
        //#line 309 "x10/lang/Point.x10"
        final long t$136169 = this.rank;
        
        //#line 309 "x10/lang/Point.x10"
        final long i$98559max$136170 = ((t$136169) - (((long)(2L))));
        
        //#line 309 "x10/lang/Point.x10"
        long i$136166 = 0L;
        
        //#line 309 "x10/lang/Point.x10"
        for (;
             true;
             ) {
            
            //#line 309 "x10/lang/Point.x10"
            final boolean t$136168 = ((i$136166) <= (((long)(i$98559max$136170))));
            
            //#line 309 "x10/lang/Point.x10"
            if (!(t$136168)) {
                
                //#line 309 "x10/lang/Point.x10"
                break;
            }
            
            //#line 310 "x10/lang/Point.x10"
            final long a$136159 = this.$apply$O((long)(i$136166));
            
            //#line 311 "x10/lang/Point.x10"
            final long b$136160 = that.$apply$O((long)(i$136166));
            
            //#line 312 "x10/lang/Point.x10"
            final boolean t$136161 = ((a$136159) < (((long)(b$136160))));
            
            //#line 312 "x10/lang/Point.x10"
            if (t$136161) {
                
                //#line 312 "x10/lang/Point.x10"
                return false;
            }
            
            //#line 313 "x10/lang/Point.x10"
            final boolean t$136162 = ((a$136159) > (((long)(b$136160))));
            
            //#line 313 "x10/lang/Point.x10"
            if (t$136162) {
                
                //#line 313 "x10/lang/Point.x10"
                return true;
            }
            
            //#line 309 "x10/lang/Point.x10"
            final long t$136165 = ((i$136166) + (((long)(1L))));
            
            //#line 309 "x10/lang/Point.x10"
            i$136166 = t$136165;
        }
        
        //#line 315 "x10/lang/Point.x10"
        final long t$136000 = this.rank;
        
        //#line 315 "x10/lang/Point.x10"
        final long t$136001 = ((t$136000) - (((long)(1L))));
        
        //#line 315 "x10/lang/Point.x10"
        final long t$136004 = this.$apply$O((long)(t$136001));
        
        //#line 315 "x10/lang/Point.x10"
        final long t$136002 = this.rank;
        
        //#line 315 "x10/lang/Point.x10"
        final long t$136003 = ((t$136002) - (((long)(1L))));
        
        //#line 315 "x10/lang/Point.x10"
        final long t$136005 = that.$apply$O((long)(t$136003));
        
        //#line 315 "x10/lang/Point.x10"
        final boolean t$136006 = ((t$136004) > (((long)(t$136005))));
        
        //#line 315 "x10/lang/Point.x10"
        return t$136006;
    }
    
    
    //#line 322 "x10/lang/Point.x10"
    /**
     * For points <code>a, b</code>, <code> a &le; b</code> if <code>a</code> is 
     * lexicographically less than <code> b</code> or the same as <code>b</code>.
     */
    public boolean $le$O(final x10.lang.Point that) {
        
        //#line 323 "x10/lang/Point.x10"
        final long t$136181 = this.rank;
        
        //#line 323 "x10/lang/Point.x10"
        final long i$98577max$136182 = ((t$136181) - (((long)(2L))));
        
        //#line 323 "x10/lang/Point.x10"
        long i$136178 = 0L;
        
        //#line 323 "x10/lang/Point.x10"
        for (;
             true;
             ) {
            
            //#line 323 "x10/lang/Point.x10"
            final boolean t$136180 = ((i$136178) <= (((long)(i$98577max$136182))));
            
            //#line 323 "x10/lang/Point.x10"
            if (!(t$136180)) {
                
                //#line 323 "x10/lang/Point.x10"
                break;
            }
            
            //#line 324 "x10/lang/Point.x10"
            final long a$136171 = this.$apply$O((long)(i$136178));
            
            //#line 325 "x10/lang/Point.x10"
            final long b$136172 = that.$apply$O((long)(i$136178));
            
            //#line 326 "x10/lang/Point.x10"
            final boolean t$136173 = ((a$136171) > (((long)(b$136172))));
            
            //#line 326 "x10/lang/Point.x10"
            if (t$136173) {
                
                //#line 326 "x10/lang/Point.x10"
                return false;
            }
            
            //#line 327 "x10/lang/Point.x10"
            final boolean t$136174 = ((a$136171) < (((long)(b$136172))));
            
            //#line 327 "x10/lang/Point.x10"
            if (t$136174) {
                
                //#line 327 "x10/lang/Point.x10"
                return true;
            }
            
            //#line 323 "x10/lang/Point.x10"
            final long t$136177 = ((i$136178) + (((long)(1L))));
            
            //#line 323 "x10/lang/Point.x10"
            i$136178 = t$136177;
        }
        
        //#line 329 "x10/lang/Point.x10"
        final long t$136015 = this.rank;
        
        //#line 329 "x10/lang/Point.x10"
        final long t$136016 = ((t$136015) - (((long)(1L))));
        
        //#line 329 "x10/lang/Point.x10"
        final long t$136019 = this.$apply$O((long)(t$136016));
        
        //#line 329 "x10/lang/Point.x10"
        final long t$136017 = this.rank;
        
        //#line 329 "x10/lang/Point.x10"
        final long t$136018 = ((t$136017) - (((long)(1L))));
        
        //#line 329 "x10/lang/Point.x10"
        final long t$136020 = that.$apply$O((long)(t$136018));
        
        //#line 329 "x10/lang/Point.x10"
        final boolean t$136021 = ((t$136019) <= (((long)(t$136020))));
        
        //#line 329 "x10/lang/Point.x10"
        return t$136021;
    }
    
    
    //#line 336 "x10/lang/Point.x10"
    /**
     * For points <code>a, b</code>, <code> a &ge; b</code> if <code>a</code> is 
     * lexicographically greater than <code> b</code> or the same as <code>b</code>.
     */
    public boolean $ge$O(final x10.lang.Point that) {
        
        //#line 337 "x10/lang/Point.x10"
        final long t$136193 = this.rank;
        
        //#line 337 "x10/lang/Point.x10"
        final long i$98595max$136194 = ((t$136193) - (((long)(2L))));
        
        //#line 337 "x10/lang/Point.x10"
        long i$136190 = 0L;
        
        //#line 337 "x10/lang/Point.x10"
        for (;
             true;
             ) {
            
            //#line 337 "x10/lang/Point.x10"
            final boolean t$136192 = ((i$136190) <= (((long)(i$98595max$136194))));
            
            //#line 337 "x10/lang/Point.x10"
            if (!(t$136192)) {
                
                //#line 337 "x10/lang/Point.x10"
                break;
            }
            
            //#line 338 "x10/lang/Point.x10"
            final long a$136183 = this.$apply$O((long)(i$136190));
            
            //#line 339 "x10/lang/Point.x10"
            final long b$136184 = that.$apply$O((long)(i$136190));
            
            //#line 340 "x10/lang/Point.x10"
            final boolean t$136185 = ((a$136183) < (((long)(b$136184))));
            
            //#line 340 "x10/lang/Point.x10"
            if (t$136185) {
                
                //#line 340 "x10/lang/Point.x10"
                return false;
            }
            
            //#line 341 "x10/lang/Point.x10"
            final boolean t$136186 = ((a$136183) > (((long)(b$136184))));
            
            //#line 341 "x10/lang/Point.x10"
            if (t$136186) {
                
                //#line 341 "x10/lang/Point.x10"
                return true;
            }
            
            //#line 337 "x10/lang/Point.x10"
            final long t$136189 = ((i$136190) + (((long)(1L))));
            
            //#line 337 "x10/lang/Point.x10"
            i$136190 = t$136189;
        }
        
        //#line 343 "x10/lang/Point.x10"
        final long t$136030 = this.rank;
        
        //#line 343 "x10/lang/Point.x10"
        final long t$136031 = ((t$136030) - (((long)(1L))));
        
        //#line 343 "x10/lang/Point.x10"
        final long t$136034 = this.$apply$O((long)(t$136031));
        
        //#line 343 "x10/lang/Point.x10"
        final long t$136032 = this.rank;
        
        //#line 343 "x10/lang/Point.x10"
        final long t$136033 = ((t$136032) - (((long)(1L))));
        
        //#line 343 "x10/lang/Point.x10"
        final long t$136035 = that.$apply$O((long)(t$136033));
        
        //#line 343 "x10/lang/Point.x10"
        final boolean t$136036 = ((t$136034) >= (((long)(t$136035))));
        
        //#line 343 "x10/lang/Point.x10"
        return t$136036;
    }
    
    
    //#line 349 "x10/lang/Point.x10"
    /**
     * A point with coordinates <code>i1,..., ik</code> is printed as <code>[i1,.., ik]</code>.
     */
    public java.lang.String toString() {
        
        //#line 350 "x10/lang/Point.x10"
        java.lang.String s = "[";
        
        //#line 351 "x10/lang/Point.x10"
        final long t$136037 = this.rank;
        
        //#line 351 "x10/lang/Point.x10"
        final boolean t$136041 = ((t$136037) > (((long)(0L))));
        
        //#line 351 "x10/lang/Point.x10"
        if (t$136041) {
            
            //#line 351 "x10/lang/Point.x10"
            final long t$136039 = this.$apply$O((long)(0L));
            
            //#line 351 "x10/lang/Point.x10"
            final java.lang.String t$136040 = ((s) + ((x10.core.Long.$box(t$136039))));
            
            //#line 351 "x10/lang/Point.x10"
            s = ((java.lang.String)(t$136040));
        }
        
        //#line 352 "x10/lang/Point.x10"
        final long t$136205 = this.rank;
        
        //#line 352 "x10/lang/Point.x10"
        final long i$98613max$136206 = ((t$136205) - (((long)(1L))));
        
        //#line 352 "x10/lang/Point.x10"
        long i$136202 = 1L;
        
        //#line 352 "x10/lang/Point.x10"
        for (;
             true;
             ) {
            
            //#line 352 "x10/lang/Point.x10"
            final boolean t$136204 = ((i$136202) <= (((long)(i$98613max$136206))));
            
            //#line 352 "x10/lang/Point.x10"
            if (!(t$136204)) {
                
                //#line 352 "x10/lang/Point.x10"
                break;
            }
            
            //#line 353 "x10/lang/Point.x10"
            final long t$136196 = this.$apply$O((long)(i$136202));
            
            //#line 353 "x10/lang/Point.x10"
            final java.lang.String t$136197 = ((",") + ((x10.core.Long.$box(t$136196))));
            
            //#line 353 "x10/lang/Point.x10"
            final java.lang.String t$136198 = ((s) + (t$136197));
            
            //#line 353 "x10/lang/Point.x10"
            s = ((java.lang.String)(t$136198));
            
            //#line 352 "x10/lang/Point.x10"
            final long t$136201 = ((i$136202) + (((long)(1L))));
            
            //#line 352 "x10/lang/Point.x10"
            i$136202 = t$136201;
        }
        
        //#line 355 "x10/lang/Point.x10"
        final java.lang.String t$136053 = ((s) + ("]"));
        
        //#line 355 "x10/lang/Point.x10"
        s = ((java.lang.String)(t$136053));
        
        //#line 356 "x10/lang/Point.x10"
        return s;
    }
    
    
    //#line 24 "x10/lang/Point.x10"
    final public x10.lang.Point x10$lang$Point$$this$x10$lang$Point() {
        
        //#line 24 "x10/lang/Point.x10"
        return x10.lang.Point.this;
    }
    
    
    //#line 24 "x10/lang/Point.x10"
    final public void __fieldInitializers_x10_lang_Point() {
        
    }
    
    @x10.runtime.impl.java.X10Generated
    final public static class $Closure$183 extends x10.core.Ref implements x10.core.fun.Fun_0_1, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<$Closure$183> $RTT = 
            x10.rtt.StaticFunType.<$Closure$183> make($Closure$183.class,
                                                      new x10.rtt.Type[] {
                                                          x10.rtt.ParameterizedType.make(x10.core.fun.Fun_0_1.$RTT, x10.rtt.Types.LONG, x10.rtt.Types.LONG)
                                                      });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static x10.serialization.X10JavaSerializable $_deserialize_body(x10.lang.Point.$Closure$183 $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            $_obj.out$$ = $deserializer.readObject();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.lang.Point.$Closure$183 $_obj = new x10.lang.Point.$Closure$183((java.lang.System[]) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            $serializer.write(this.out$$);
            
        }
        
        // constructor just for allocation
        public $Closure$183(final java.lang.System[] $dummy) {
            
        }
        
        // dispatcher for method abstract public (Z1)=>U.operator()(a1:Z1):U
        public java.lang.Object $apply(final java.lang.Object a1, final x10.rtt.Type t1) {
            return x10.core.Long.$box($apply$O(x10.core.Long.$unbox(a1)));
            
        }
        
        // dispatcher for method abstract public (Z1)=>U.operator()(a1:Z1):U
        public long $apply$J(final java.lang.Object a1, final x10.rtt.Type t1) {
            return $apply$O(x10.core.Long.$unbox(a1));
            
        }
        
        
    
        
        public long $apply$O(final long i) {
            
            //#line 92 "x10/lang/Point.x10"
            final long t$135732 = this.out$$.$apply$O((long)(i));
            
            //#line 92 "x10/lang/Point.x10"
            return t$135732;
        }
        
        public x10.lang.Point out$$;
        
        public $Closure$183(final x10.lang.Point out$$) {
             {
                this.out$$ = out$$;
            }
        }
        
    }
    
    @x10.runtime.impl.java.X10Generated
    final public static class $Closure$184 extends x10.core.Ref implements x10.core.fun.Fun_0_1, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<$Closure$184> $RTT = 
            x10.rtt.StaticFunType.<$Closure$184> make($Closure$184.class,
                                                      new x10.rtt.Type[] {
                                                          x10.rtt.ParameterizedType.make(x10.core.fun.Fun_0_1.$RTT, x10.rtt.Types.LONG, x10.rtt.Types.LONG)
                                                      });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static x10.serialization.X10JavaSerializable $_deserialize_body(x10.lang.Point.$Closure$184 $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            $_obj.r = $deserializer.readObject();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.lang.Point.$Closure$184 $_obj = new x10.lang.Point.$Closure$184((java.lang.System[]) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            $serializer.write(this.r);
            
        }
        
        // constructor just for allocation
        public $Closure$184(final java.lang.System[] $dummy) {
            
        }
        
        // dispatcher for method abstract public (Z1)=>U.operator()(a1:Z1):U
        public java.lang.Object $apply(final java.lang.Object a1, final x10.rtt.Type t1) {
            return x10.core.Long.$box($apply$O(x10.core.Long.$unbox(a1)));
            
        }
        
        // dispatcher for method abstract public (Z1)=>U.operator()(a1:Z1):U
        public long $apply$J(final java.lang.Object a1, final x10.rtt.Type t1) {
            return $apply$O(x10.core.Long.$unbox(a1));
            
        }
        
        // synthetic type for parameter mangling
        public static final class __0$1x10$lang$Int$2 {}
        
    
        
        public long $apply$O(final long i$136083) {
            
            //#line 107 "x10/lang/Point.x10"
            final int t$136084 = ((int[])this.r.value)[(int)i$136083];
            
            //#line 107 "x10/lang/Point.x10"
            final long t$136085 = ((long)(((int)(t$136084))));
            
            //#line 107 "x10/lang/Point.x10"
            return t$136085;
        }
        
        public x10.core.Rail<x10.core.Int> r;
        
        public $Closure$184(final x10.core.Rail<x10.core.Int> r, __0$1x10$lang$Int$2 $dummy) {
             {
                this.r = ((x10.core.Rail)(r));
            }
        }
        
    }
    
    @x10.runtime.impl.java.X10Generated
    final public static class $Closure$185 extends x10.core.Ref implements x10.core.fun.Fun_0_1, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<$Closure$185> $RTT = 
            x10.rtt.StaticFunType.<$Closure$185> make($Closure$185.class,
                                                      new x10.rtt.Type[] {
                                                          x10.rtt.ParameterizedType.make(x10.core.fun.Fun_0_1.$RTT, x10.rtt.Types.LONG, x10.rtt.Types.LONG)
                                                      });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static x10.serialization.X10JavaSerializable $_deserialize_body(x10.lang.Point.$Closure$185 $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            $_obj.init = $deserializer.readObject();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.lang.Point.$Closure$185 $_obj = new x10.lang.Point.$Closure$185((java.lang.System[]) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            $serializer.write(this.init);
            
        }
        
        // constructor just for allocation
        public $Closure$185(final java.lang.System[] $dummy) {
            
        }
        
        // dispatcher for method abstract public (Z1)=>U.operator()(a1:Z1):U
        public java.lang.Object $apply(final java.lang.Object a1, final x10.rtt.Type t1) {
            return x10.core.Long.$box($apply$O(x10.core.Long.$unbox(a1)));
            
        }
        
        // dispatcher for method abstract public (Z1)=>U.operator()(a1:Z1):U
        public long $apply$J(final java.lang.Object a1, final x10.rtt.Type t1) {
            return $apply$O(x10.core.Long.$unbox(a1));
            
        }
        
        // synthetic type for parameter mangling
        public static final class __0$1x10$lang$Long$3x10$lang$Long$2 {}
        
    
        
        public long $apply$O(final long l$136110) {
            
            //#line 141 "x10/lang/Point.x10"
            final long t$136111 = x10.core.Long.$unbox(((x10.core.fun.Fun_0_1<x10.core.Long,x10.core.Long>)this.init).$apply(x10.core.Long.$box(l$136110), x10.rtt.Types.LONG));
            
            //#line 141 "x10/lang/Point.x10"
            return t$136111;
        }
        
        public x10.core.fun.Fun_0_1<x10.core.Long,x10.core.Long> init;
        
        public $Closure$185(final x10.core.fun.Fun_0_1<x10.core.Long,x10.core.Long> init, __0$1x10$lang$Long$3x10$lang$Long$2 $dummy) {
             {
                this.init = ((x10.core.fun.Fun_0_1)(init));
            }
        }
        
    }
    
    @x10.runtime.impl.java.X10Generated
    final public static class $Closure$186 extends x10.core.Ref implements x10.core.fun.Fun_0_1, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<$Closure$186> $RTT = 
            x10.rtt.StaticFunType.<$Closure$186> make($Closure$186.class,
                                                      new x10.rtt.Type[] {
                                                          x10.rtt.ParameterizedType.make(x10.core.fun.Fun_0_1.$RTT, x10.rtt.Types.LONG, x10.rtt.Types.LONG)
                                                      });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static x10.serialization.X10JavaSerializable $_deserialize_body(x10.lang.Point.$Closure$186 $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            $_obj.out$$ = $deserializer.readObject();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.lang.Point.$Closure$186 $_obj = new x10.lang.Point.$Closure$186((java.lang.System[]) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            $serializer.write(this.out$$);
            
        }
        
        // constructor just for allocation
        public $Closure$186(final java.lang.System[] $dummy) {
            
        }
        
        // dispatcher for method abstract public (Z1)=>U.operator()(a1:Z1):U
        public java.lang.Object $apply(final java.lang.Object a1, final x10.rtt.Type t1) {
            return x10.core.Long.$box($apply$O(x10.core.Long.$unbox(a1)));
            
        }
        
        // dispatcher for method abstract public (Z1)=>U.operator()(a1:Z1):U
        public long $apply$J(final java.lang.Object a1, final x10.rtt.Type t1) {
            return $apply$O(x10.core.Long.$unbox(a1));
            
        }
        
        
    
        
        public long $apply$O(final long i) {
            
            //#line 179 "x10/lang/Point.x10"
            final long t$135876 = this.out$$.$apply$O((long)(i));
            
            //#line 179 "x10/lang/Point.x10"
            final long t$135877 = (-(t$135876));
            
            //#line 179 "x10/lang/Point.x10"
            return t$135877;
        }
        
        public x10.lang.Point out$$;
        
        public $Closure$186(final x10.lang.Point out$$) {
             {
                this.out$$ = out$$;
            }
        }
        
    }
    
    @x10.runtime.impl.java.X10Generated
    final public static class $Closure$187 extends x10.core.Ref implements x10.core.fun.Fun_0_1, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<$Closure$187> $RTT = 
            x10.rtt.StaticFunType.<$Closure$187> make($Closure$187.class,
                                                      new x10.rtt.Type[] {
                                                          x10.rtt.ParameterizedType.make(x10.core.fun.Fun_0_1.$RTT, x10.rtt.Types.LONG, x10.rtt.Types.LONG)
                                                      });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static x10.serialization.X10JavaSerializable $_deserialize_body(x10.lang.Point.$Closure$187 $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            $_obj.out$$ = $deserializer.readObject();
            $_obj.that = $deserializer.readObject();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.lang.Point.$Closure$187 $_obj = new x10.lang.Point.$Closure$187((java.lang.System[]) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            $serializer.write(this.out$$);
            $serializer.write(this.that);
            
        }
        
        // constructor just for allocation
        public $Closure$187(final java.lang.System[] $dummy) {
            
        }
        
        // dispatcher for method abstract public (Z1)=>U.operator()(a1:Z1):U
        public java.lang.Object $apply(final java.lang.Object a1, final x10.rtt.Type t1) {
            return x10.core.Long.$box($apply$O(x10.core.Long.$unbox(a1)));
            
        }
        
        // dispatcher for method abstract public (Z1)=>U.operator()(a1:Z1):U
        public long $apply$J(final java.lang.Object a1, final x10.rtt.Type t1) {
            return $apply$O(x10.core.Long.$unbox(a1));
            
        }
        
        
    
        
        public long $apply$O(final long i) {
            
            //#line 185 "x10/lang/Point.x10"
            final long t$135881 = this.out$$.$apply$O((long)(i));
            
            //#line 185 "x10/lang/Point.x10"
            final long t$135882 = this.that.$apply$O((long)(i));
            
            //#line 185 "x10/lang/Point.x10"
            final long t$135883 = ((t$135881) + (((long)(t$135882))));
            
            //#line 185 "x10/lang/Point.x10"
            return t$135883;
        }
        
        public x10.lang.Point out$$;
        public x10.lang.Point that;
        
        public $Closure$187(final x10.lang.Point out$$, final x10.lang.Point that) {
             {
                this.out$$ = out$$;
                this.that = ((x10.lang.Point)(that));
            }
        }
        
    }
    
    @x10.runtime.impl.java.X10Generated
    final public static class $Closure$188 extends x10.core.Ref implements x10.core.fun.Fun_0_1, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<$Closure$188> $RTT = 
            x10.rtt.StaticFunType.<$Closure$188> make($Closure$188.class,
                                                      new x10.rtt.Type[] {
                                                          x10.rtt.ParameterizedType.make(x10.core.fun.Fun_0_1.$RTT, x10.rtt.Types.LONG, x10.rtt.Types.LONG)
                                                      });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static x10.serialization.X10JavaSerializable $_deserialize_body(x10.lang.Point.$Closure$188 $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            $_obj.out$$ = $deserializer.readObject();
            $_obj.that = $deserializer.readObject();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.lang.Point.$Closure$188 $_obj = new x10.lang.Point.$Closure$188((java.lang.System[]) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            $serializer.write(this.out$$);
            $serializer.write(this.that);
            
        }
        
        // constructor just for allocation
        public $Closure$188(final java.lang.System[] $dummy) {
            
        }
        
        // dispatcher for method abstract public (Z1)=>U.operator()(a1:Z1):U
        public java.lang.Object $apply(final java.lang.Object a1, final x10.rtt.Type t1) {
            return x10.core.Long.$box($apply$O(x10.core.Long.$unbox(a1)));
            
        }
        
        // dispatcher for method abstract public (Z1)=>U.operator()(a1:Z1):U
        public long $apply$J(final java.lang.Object a1, final x10.rtt.Type t1) {
            return $apply$O(x10.core.Long.$unbox(a1));
            
        }
        
        
    
        
        public long $apply$O(final long i) {
            
            //#line 192 "x10/lang/Point.x10"
            final long t$135887 = this.out$$.$apply$O((long)(i));
            
            //#line 192 "x10/lang/Point.x10"
            final long t$135888 = this.that.$apply$O((long)(i));
            
            //#line 192 "x10/lang/Point.x10"
            final long t$135889 = ((t$135887) - (((long)(t$135888))));
            
            //#line 192 "x10/lang/Point.x10"
            return t$135889;
        }
        
        public x10.lang.Point out$$;
        public x10.lang.Point that;
        
        public $Closure$188(final x10.lang.Point out$$, final x10.lang.Point that) {
             {
                this.out$$ = out$$;
                this.that = ((x10.lang.Point)(that));
            }
        }
        
    }
    
    @x10.runtime.impl.java.X10Generated
    final public static class $Closure$189 extends x10.core.Ref implements x10.core.fun.Fun_0_1, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<$Closure$189> $RTT = 
            x10.rtt.StaticFunType.<$Closure$189> make($Closure$189.class,
                                                      new x10.rtt.Type[] {
                                                          x10.rtt.ParameterizedType.make(x10.core.fun.Fun_0_1.$RTT, x10.rtt.Types.LONG, x10.rtt.Types.LONG)
                                                      });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static x10.serialization.X10JavaSerializable $_deserialize_body(x10.lang.Point.$Closure$189 $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            $_obj.out$$ = $deserializer.readObject();
            $_obj.that = $deserializer.readObject();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.lang.Point.$Closure$189 $_obj = new x10.lang.Point.$Closure$189((java.lang.System[]) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            $serializer.write(this.out$$);
            $serializer.write(this.that);
            
        }
        
        // constructor just for allocation
        public $Closure$189(final java.lang.System[] $dummy) {
            
        }
        
        // dispatcher for method abstract public (Z1)=>U.operator()(a1:Z1):U
        public java.lang.Object $apply(final java.lang.Object a1, final x10.rtt.Type t1) {
            return x10.core.Long.$box($apply$O(x10.core.Long.$unbox(a1)));
            
        }
        
        // dispatcher for method abstract public (Z1)=>U.operator()(a1:Z1):U
        public long $apply$J(final java.lang.Object a1, final x10.rtt.Type t1) {
            return $apply$O(x10.core.Long.$unbox(a1));
            
        }
        
        
    
        
        public long $apply$O(final long i) {
            
            //#line 198 "x10/lang/Point.x10"
            final long t$135893 = this.out$$.$apply$O((long)(i));
            
            //#line 198 "x10/lang/Point.x10"
            final long t$135894 = this.that.$apply$O((long)(i));
            
            //#line 198 "x10/lang/Point.x10"
            final long t$135895 = ((t$135893) * (((long)(t$135894))));
            
            //#line 198 "x10/lang/Point.x10"
            return t$135895;
        }
        
        public x10.lang.Point out$$;
        public x10.lang.Point that;
        
        public $Closure$189(final x10.lang.Point out$$, final x10.lang.Point that) {
             {
                this.out$$ = out$$;
                this.that = ((x10.lang.Point)(that));
            }
        }
        
    }
    
    @x10.runtime.impl.java.X10Generated
    final public static class $Closure$190 extends x10.core.Ref implements x10.core.fun.Fun_0_1, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<$Closure$190> $RTT = 
            x10.rtt.StaticFunType.<$Closure$190> make($Closure$190.class,
                                                      new x10.rtt.Type[] {
                                                          x10.rtt.ParameterizedType.make(x10.core.fun.Fun_0_1.$RTT, x10.rtt.Types.LONG, x10.rtt.Types.LONG)
                                                      });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static x10.serialization.X10JavaSerializable $_deserialize_body(x10.lang.Point.$Closure$190 $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            $_obj.out$$ = $deserializer.readObject();
            $_obj.that = $deserializer.readObject();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.lang.Point.$Closure$190 $_obj = new x10.lang.Point.$Closure$190((java.lang.System[]) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            $serializer.write(this.out$$);
            $serializer.write(this.that);
            
        }
        
        // constructor just for allocation
        public $Closure$190(final java.lang.System[] $dummy) {
            
        }
        
        // dispatcher for method abstract public (Z1)=>U.operator()(a1:Z1):U
        public java.lang.Object $apply(final java.lang.Object a1, final x10.rtt.Type t1) {
            return x10.core.Long.$box($apply$O(x10.core.Long.$unbox(a1)));
            
        }
        
        // dispatcher for method abstract public (Z1)=>U.operator()(a1:Z1):U
        public long $apply$J(final java.lang.Object a1, final x10.rtt.Type t1) {
            return $apply$O(x10.core.Long.$unbox(a1));
            
        }
        
        
    
        
        public long $apply$O(final long i) {
            
            //#line 204 "x10/lang/Point.x10"
            final long t$135899 = this.out$$.$apply$O((long)(i));
            
            //#line 204 "x10/lang/Point.x10"
            final long t$135900 = this.that.$apply$O((long)(i));
            
            //#line 204 "x10/lang/Point.x10"
            final long t$135901 = ((t$135899) / (((long)(t$135900))));
            
            //#line 204 "x10/lang/Point.x10"
            return t$135901;
        }
        
        public x10.lang.Point out$$;
        public x10.lang.Point that;
        
        public $Closure$190(final x10.lang.Point out$$, final x10.lang.Point that) {
             {
                this.out$$ = out$$;
                this.that = ((x10.lang.Point)(that));
            }
        }
        
    }
    
    @x10.runtime.impl.java.X10Generated
    final public static class $Closure$191 extends x10.core.Ref implements x10.core.fun.Fun_0_1, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<$Closure$191> $RTT = 
            x10.rtt.StaticFunType.<$Closure$191> make($Closure$191.class,
                                                      new x10.rtt.Type[] {
                                                          x10.rtt.ParameterizedType.make(x10.core.fun.Fun_0_1.$RTT, x10.rtt.Types.LONG, x10.rtt.Types.LONG)
                                                      });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static x10.serialization.X10JavaSerializable $_deserialize_body(x10.lang.Point.$Closure$191 $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            $_obj.c = $deserializer.readLong();
            $_obj.out$$ = $deserializer.readObject();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.lang.Point.$Closure$191 $_obj = new x10.lang.Point.$Closure$191((java.lang.System[]) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            $serializer.write(this.c);
            $serializer.write(this.out$$);
            
        }
        
        // constructor just for allocation
        public $Closure$191(final java.lang.System[] $dummy) {
            
        }
        
        // dispatcher for method abstract public (Z1)=>U.operator()(a1:Z1):U
        public java.lang.Object $apply(final java.lang.Object a1, final x10.rtt.Type t1) {
            return x10.core.Long.$box($apply$O(x10.core.Long.$unbox(a1)));
            
        }
        
        // dispatcher for method abstract public (Z1)=>U.operator()(a1:Z1):U
        public long $apply$J(final java.lang.Object a1, final x10.rtt.Type t1) {
            return $apply$O(x10.core.Long.$unbox(a1));
            
        }
        
        
    
        
        public long $apply$O(final long i) {
            
            //#line 210 "x10/lang/Point.x10"
            final long t$135905 = this.out$$.$apply$O((long)(i));
            
            //#line 210 "x10/lang/Point.x10"
            final long t$135906 = ((t$135905) + (((long)(this.c))));
            
            //#line 210 "x10/lang/Point.x10"
            return t$135906;
        }
        
        public x10.lang.Point out$$;
        public long c;
        
        public $Closure$191(final x10.lang.Point out$$, final long c) {
             {
                this.out$$ = out$$;
                this.c = c;
            }
        }
        
    }
    
    @x10.runtime.impl.java.X10Generated
    final public static class $Closure$192 extends x10.core.Ref implements x10.core.fun.Fun_0_1, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<$Closure$192> $RTT = 
            x10.rtt.StaticFunType.<$Closure$192> make($Closure$192.class,
                                                      new x10.rtt.Type[] {
                                                          x10.rtt.ParameterizedType.make(x10.core.fun.Fun_0_1.$RTT, x10.rtt.Types.LONG, x10.rtt.Types.LONG)
                                                      });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static x10.serialization.X10JavaSerializable $_deserialize_body(x10.lang.Point.$Closure$192 $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            $_obj.c = $deserializer.readLong();
            $_obj.out$$ = $deserializer.readObject();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.lang.Point.$Closure$192 $_obj = new x10.lang.Point.$Closure$192((java.lang.System[]) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            $serializer.write(this.c);
            $serializer.write(this.out$$);
            
        }
        
        // constructor just for allocation
        public $Closure$192(final java.lang.System[] $dummy) {
            
        }
        
        // dispatcher for method abstract public (Z1)=>U.operator()(a1:Z1):U
        public java.lang.Object $apply(final java.lang.Object a1, final x10.rtt.Type t1) {
            return x10.core.Long.$box($apply$O(x10.core.Long.$unbox(a1)));
            
        }
        
        // dispatcher for method abstract public (Z1)=>U.operator()(a1:Z1):U
        public long $apply$J(final java.lang.Object a1, final x10.rtt.Type t1) {
            return $apply$O(x10.core.Long.$unbox(a1));
            
        }
        
        
    
        
        public long $apply$O(final long i) {
            
            //#line 216 "x10/lang/Point.x10"
            final long t$135910 = this.out$$.$apply$O((long)(i));
            
            //#line 216 "x10/lang/Point.x10"
            final long t$135911 = ((t$135910) - (((long)(this.c))));
            
            //#line 216 "x10/lang/Point.x10"
            return t$135911;
        }
        
        public x10.lang.Point out$$;
        public long c;
        
        public $Closure$192(final x10.lang.Point out$$, final long c) {
             {
                this.out$$ = out$$;
                this.c = c;
            }
        }
        
    }
    
    @x10.runtime.impl.java.X10Generated
    final public static class $Closure$193 extends x10.core.Ref implements x10.core.fun.Fun_0_1, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<$Closure$193> $RTT = 
            x10.rtt.StaticFunType.<$Closure$193> make($Closure$193.class,
                                                      new x10.rtt.Type[] {
                                                          x10.rtt.ParameterizedType.make(x10.core.fun.Fun_0_1.$RTT, x10.rtt.Types.LONG, x10.rtt.Types.LONG)
                                                      });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static x10.serialization.X10JavaSerializable $_deserialize_body(x10.lang.Point.$Closure$193 $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            $_obj.c = $deserializer.readLong();
            $_obj.out$$ = $deserializer.readObject();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.lang.Point.$Closure$193 $_obj = new x10.lang.Point.$Closure$193((java.lang.System[]) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            $serializer.write(this.c);
            $serializer.write(this.out$$);
            
        }
        
        // constructor just for allocation
        public $Closure$193(final java.lang.System[] $dummy) {
            
        }
        
        // dispatcher for method abstract public (Z1)=>U.operator()(a1:Z1):U
        public java.lang.Object $apply(final java.lang.Object a1, final x10.rtt.Type t1) {
            return x10.core.Long.$box($apply$O(x10.core.Long.$unbox(a1)));
            
        }
        
        // dispatcher for method abstract public (Z1)=>U.operator()(a1:Z1):U
        public long $apply$J(final java.lang.Object a1, final x10.rtt.Type t1) {
            return $apply$O(x10.core.Long.$unbox(a1));
            
        }
        
        
    
        
        public long $apply$O(final long i) {
            
            //#line 222 "x10/lang/Point.x10"
            final long t$135915 = this.out$$.$apply$O((long)(i));
            
            //#line 222 "x10/lang/Point.x10"
            final long t$135916 = ((t$135915) * (((long)(this.c))));
            
            //#line 222 "x10/lang/Point.x10"
            return t$135916;
        }
        
        public x10.lang.Point out$$;
        public long c;
        
        public $Closure$193(final x10.lang.Point out$$, final long c) {
             {
                this.out$$ = out$$;
                this.c = c;
            }
        }
        
    }
    
    @x10.runtime.impl.java.X10Generated
    final public static class $Closure$194 extends x10.core.Ref implements x10.core.fun.Fun_0_1, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<$Closure$194> $RTT = 
            x10.rtt.StaticFunType.<$Closure$194> make($Closure$194.class,
                                                      new x10.rtt.Type[] {
                                                          x10.rtt.ParameterizedType.make(x10.core.fun.Fun_0_1.$RTT, x10.rtt.Types.LONG, x10.rtt.Types.LONG)
                                                      });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static x10.serialization.X10JavaSerializable $_deserialize_body(x10.lang.Point.$Closure$194 $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            $_obj.c = $deserializer.readLong();
            $_obj.out$$ = $deserializer.readObject();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.lang.Point.$Closure$194 $_obj = new x10.lang.Point.$Closure$194((java.lang.System[]) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            $serializer.write(this.c);
            $serializer.write(this.out$$);
            
        }
        
        // constructor just for allocation
        public $Closure$194(final java.lang.System[] $dummy) {
            
        }
        
        // dispatcher for method abstract public (Z1)=>U.operator()(a1:Z1):U
        public java.lang.Object $apply(final java.lang.Object a1, final x10.rtt.Type t1) {
            return x10.core.Long.$box($apply$O(x10.core.Long.$unbox(a1)));
            
        }
        
        // dispatcher for method abstract public (Z1)=>U.operator()(a1:Z1):U
        public long $apply$J(final java.lang.Object a1, final x10.rtt.Type t1) {
            return $apply$O(x10.core.Long.$unbox(a1));
            
        }
        
        
    
        
        public long $apply$O(final long i) {
            
            //#line 228 "x10/lang/Point.x10"
            final long t$135920 = this.out$$.$apply$O((long)(i));
            
            //#line 228 "x10/lang/Point.x10"
            final long t$135921 = ((t$135920) / (((long)(this.c))));
            
            //#line 228 "x10/lang/Point.x10"
            return t$135921;
        }
        
        public x10.lang.Point out$$;
        public long c;
        
        public $Closure$194(final x10.lang.Point out$$, final long c) {
             {
                this.out$$ = out$$;
                this.c = c;
            }
        }
        
    }
    
    @x10.runtime.impl.java.X10Generated
    final public static class $Closure$195 extends x10.core.Ref implements x10.core.fun.Fun_0_1, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<$Closure$195> $RTT = 
            x10.rtt.StaticFunType.<$Closure$195> make($Closure$195.class,
                                                      new x10.rtt.Type[] {
                                                          x10.rtt.ParameterizedType.make(x10.core.fun.Fun_0_1.$RTT, x10.rtt.Types.LONG, x10.rtt.Types.LONG)
                                                      });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static x10.serialization.X10JavaSerializable $_deserialize_body(x10.lang.Point.$Closure$195 $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            $_obj.c = $deserializer.readLong();
            $_obj.out$$ = $deserializer.readObject();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.lang.Point.$Closure$195 $_obj = new x10.lang.Point.$Closure$195((java.lang.System[]) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            $serializer.write(this.c);
            $serializer.write(this.out$$);
            
        }
        
        // constructor just for allocation
        public $Closure$195(final java.lang.System[] $dummy) {
            
        }
        
        // dispatcher for method abstract public (Z1)=>U.operator()(a1:Z1):U
        public java.lang.Object $apply(final java.lang.Object a1, final x10.rtt.Type t1) {
            return x10.core.Long.$box($apply$O(x10.core.Long.$unbox(a1)));
            
        }
        
        // dispatcher for method abstract public (Z1)=>U.operator()(a1:Z1):U
        public long $apply$J(final java.lang.Object a1, final x10.rtt.Type t1) {
            return $apply$O(x10.core.Long.$unbox(a1));
            
        }
        
        
    
        
        public long $apply$O(final long i) {
            
            //#line 234 "x10/lang/Point.x10"
            final long t$135925 = this.out$$.$apply$O((long)(i));
            
            //#line 234 "x10/lang/Point.x10"
            final long t$135926 = ((this.c) + (((long)(t$135925))));
            
            //#line 234 "x10/lang/Point.x10"
            return t$135926;
        }
        
        public x10.lang.Point out$$;
        public long c;
        
        public $Closure$195(final x10.lang.Point out$$, final long c) {
             {
                this.out$$ = out$$;
                this.c = c;
            }
        }
        
    }
    
    @x10.runtime.impl.java.X10Generated
    final public static class $Closure$196 extends x10.core.Ref implements x10.core.fun.Fun_0_1, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<$Closure$196> $RTT = 
            x10.rtt.StaticFunType.<$Closure$196> make($Closure$196.class,
                                                      new x10.rtt.Type[] {
                                                          x10.rtt.ParameterizedType.make(x10.core.fun.Fun_0_1.$RTT, x10.rtt.Types.LONG, x10.rtt.Types.LONG)
                                                      });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static x10.serialization.X10JavaSerializable $_deserialize_body(x10.lang.Point.$Closure$196 $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            $_obj.c = $deserializer.readLong();
            $_obj.out$$ = $deserializer.readObject();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.lang.Point.$Closure$196 $_obj = new x10.lang.Point.$Closure$196((java.lang.System[]) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            $serializer.write(this.c);
            $serializer.write(this.out$$);
            
        }
        
        // constructor just for allocation
        public $Closure$196(final java.lang.System[] $dummy) {
            
        }
        
        // dispatcher for method abstract public (Z1)=>U.operator()(a1:Z1):U
        public java.lang.Object $apply(final java.lang.Object a1, final x10.rtt.Type t1) {
            return x10.core.Long.$box($apply$O(x10.core.Long.$unbox(a1)));
            
        }
        
        // dispatcher for method abstract public (Z1)=>U.operator()(a1:Z1):U
        public long $apply$J(final java.lang.Object a1, final x10.rtt.Type t1) {
            return $apply$O(x10.core.Long.$unbox(a1));
            
        }
        
        
    
        
        public long $apply$O(final long i) {
            
            //#line 240 "x10/lang/Point.x10"
            final long t$135930 = this.out$$.$apply$O((long)(i));
            
            //#line 240 "x10/lang/Point.x10"
            final long t$135931 = ((this.c) - (((long)(t$135930))));
            
            //#line 240 "x10/lang/Point.x10"
            return t$135931;
        }
        
        public x10.lang.Point out$$;
        public long c;
        
        public $Closure$196(final x10.lang.Point out$$, final long c) {
             {
                this.out$$ = out$$;
                this.c = c;
            }
        }
        
    }
    
    @x10.runtime.impl.java.X10Generated
    final public static class $Closure$197 extends x10.core.Ref implements x10.core.fun.Fun_0_1, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<$Closure$197> $RTT = 
            x10.rtt.StaticFunType.<$Closure$197> make($Closure$197.class,
                                                      new x10.rtt.Type[] {
                                                          x10.rtt.ParameterizedType.make(x10.core.fun.Fun_0_1.$RTT, x10.rtt.Types.LONG, x10.rtt.Types.LONG)
                                                      });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static x10.serialization.X10JavaSerializable $_deserialize_body(x10.lang.Point.$Closure$197 $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            $_obj.c = $deserializer.readLong();
            $_obj.out$$ = $deserializer.readObject();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.lang.Point.$Closure$197 $_obj = new x10.lang.Point.$Closure$197((java.lang.System[]) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            $serializer.write(this.c);
            $serializer.write(this.out$$);
            
        }
        
        // constructor just for allocation
        public $Closure$197(final java.lang.System[] $dummy) {
            
        }
        
        // dispatcher for method abstract public (Z1)=>U.operator()(a1:Z1):U
        public java.lang.Object $apply(final java.lang.Object a1, final x10.rtt.Type t1) {
            return x10.core.Long.$box($apply$O(x10.core.Long.$unbox(a1)));
            
        }
        
        // dispatcher for method abstract public (Z1)=>U.operator()(a1:Z1):U
        public long $apply$J(final java.lang.Object a1, final x10.rtt.Type t1) {
            return $apply$O(x10.core.Long.$unbox(a1));
            
        }
        
        
    
        
        public long $apply$O(final long i) {
            
            //#line 246 "x10/lang/Point.x10"
            final long t$135935 = this.out$$.$apply$O((long)(i));
            
            //#line 246 "x10/lang/Point.x10"
            final long t$135936 = ((this.c) * (((long)(t$135935))));
            
            //#line 246 "x10/lang/Point.x10"
            return t$135936;
        }
        
        public x10.lang.Point out$$;
        public long c;
        
        public $Closure$197(final x10.lang.Point out$$, final long c) {
             {
                this.out$$ = out$$;
                this.c = c;
            }
        }
        
    }
    
    @x10.runtime.impl.java.X10Generated
    final public static class $Closure$198 extends x10.core.Ref implements x10.core.fun.Fun_0_1, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<$Closure$198> $RTT = 
            x10.rtt.StaticFunType.<$Closure$198> make($Closure$198.class,
                                                      new x10.rtt.Type[] {
                                                          x10.rtt.ParameterizedType.make(x10.core.fun.Fun_0_1.$RTT, x10.rtt.Types.LONG, x10.rtt.Types.LONG)
                                                      });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static x10.serialization.X10JavaSerializable $_deserialize_body(x10.lang.Point.$Closure$198 $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            $_obj.c = $deserializer.readLong();
            $_obj.out$$ = $deserializer.readObject();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.lang.Point.$Closure$198 $_obj = new x10.lang.Point.$Closure$198((java.lang.System[]) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            $serializer.write(this.c);
            $serializer.write(this.out$$);
            
        }
        
        // constructor just for allocation
        public $Closure$198(final java.lang.System[] $dummy) {
            
        }
        
        // dispatcher for method abstract public (Z1)=>U.operator()(a1:Z1):U
        public java.lang.Object $apply(final java.lang.Object a1, final x10.rtt.Type t1) {
            return x10.core.Long.$box($apply$O(x10.core.Long.$unbox(a1)));
            
        }
        
        // dispatcher for method abstract public (Z1)=>U.operator()(a1:Z1):U
        public long $apply$J(final java.lang.Object a1, final x10.rtt.Type t1) {
            return $apply$O(x10.core.Long.$unbox(a1));
            
        }
        
        
    
        
        public long $apply$O(final long i) {
            
            //#line 252 "x10/lang/Point.x10"
            final long t$135940 = this.out$$.$apply$O((long)(i));
            
            //#line 252 "x10/lang/Point.x10"
            final long t$135941 = ((this.c) / (((long)(t$135940))));
            
            //#line 252 "x10/lang/Point.x10"
            return t$135941;
        }
        
        public x10.lang.Point out$$;
        public long c;
        
        public $Closure$198(final x10.lang.Point out$$, final long c) {
             {
                this.out$$ = out$$;
                this.c = c;
            }
        }
        
    }
    
}


