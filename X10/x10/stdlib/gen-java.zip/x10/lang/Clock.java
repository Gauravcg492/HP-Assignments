package x10.lang;


/**
 * Ported from 2.0 to 2.1 via naive simulation of 
 *       2.0 style global object by injecting a root field
 *       that is a GlobalRef(this) and always accessing fields 
 *       as this.root().f instead of this.f.
 * TODO: Port to Dual Class implementation of global objects.
 */
@x10.runtime.impl.java.X10Generated
final public class Clock extends x10.core.Ref implements x10.serialization.X10JavaSerializable
{
    public static final x10.rtt.RuntimeType<Clock> $RTT = 
        x10.rtt.NamedType.<Clock> make("x10.lang.Clock",
                                       Clock.class);
    
    public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
    
    public x10.rtt.Type<?> $getParam(int i) { return null; }
    
    private Object writeReplace() throws java.io.ObjectStreamException {
        return new x10.serialization.SerializationProxy(this);
    }
    
    public static x10.serialization.X10JavaSerializable $_deserialize_body(x10.lang.Clock $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
        $_obj.name = $deserializer.readObject();
        $_obj.root = $deserializer.readObject();
        return $_obj;
    }
    
    public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
        x10.lang.Clock $_obj = new x10.lang.Clock((java.lang.System[]) null);
        $deserializer.record_reference($_obj);
        return $_deserialize_body($_obj, $deserializer);
    }
    
    public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
        $serializer.write(this.name);
        $serializer.write(this.root);
        
    }
    
    // constructor just for allocation
    public Clock(final java.lang.System[] $dummy) {
        
    }
    
    
    // properties
    
    //#line 32 "x10/lang/Clock.x10"
    public java.lang.String name;
    

    
    //#line 33 "x10/lang/Clock.x10"
    public x10.core.GlobalRef<x10.lang.Clock> root;
    
    
    //#line 34 "x10/lang/Clock.x10"
    public boolean equals(final java.lang.Object a) {
        
        //#line 35 "x10/lang/Clock.x10"
        boolean t$132338 = ((a) == (null));
        
        //#line 35 "x10/lang/Clock.x10"
        if (!(t$132338)) {
            
            //#line 35 "x10/lang/Clock.x10"
            final boolean t$132337 = x10.lang.Clock.$RTT.isInstance(a);
            
            //#line 35 "x10/lang/Clock.x10"
            t$132338 = !(t$132337);
        }
        
        //#line 35 "x10/lang/Clock.x10"
        if (t$132338) {
            
            //#line 36 "x10/lang/Clock.x10"
            return false;
        }
        
        //#line 38 "x10/lang/Clock.x10"
        final x10.lang.Clock t$132340 = ((x10.lang.Clock)(x10.rtt.Types.<x10.lang.Clock> cast(a,x10.lang.Clock.$RTT)));
        
        //#line 38 "x10/lang/Clock.x10"
        final x10.core.GlobalRef t$132341 = ((x10.core.GlobalRef)(t$132340.root));
        
        //#line 38 "x10/lang/Clock.x10"
        final x10.core.GlobalRef t$132342 = ((x10.core.GlobalRef)(this.root));
        
        //#line 38 "x10/lang/Clock.x10"
        final boolean t$132343 = x10.rtt.Equality.equalsequals((t$132341),(t$132342));
        
        //#line 38 "x10/lang/Clock.x10"
        return t$132343;
    }
    
    
    //#line 40 "x10/lang/Clock.x10"
    public int hashCode() {
        
        //#line 40 "x10/lang/Clock.x10"
        final x10.core.GlobalRef t$132344 = ((x10.core.GlobalRef)(this.root));
        
        //#line 40 "x10/lang/Clock.x10"
        final int t$132345 = (((x10.core.GlobalRef<x10.lang.Clock>)(t$132344))).hashCode();
        
        //#line 40 "x10/lang/Clock.x10"
        return t$132345;
    }
    
    
    //#line 42 "x10/lang/Clock.x10"
    public static x10.lang.Clock make() {
        
        //#line 42 "x10/lang/Clock.x10"
        final x10.lang.Clock t$132346 = x10.lang.Clock.make(((java.lang.String)("")));
        
        //#line 42 "x10/lang/Clock.x10"
        return t$132346;
    }
    
    
    //#line 43 "x10/lang/Clock.x10"
    public static x10.lang.Clock make(final java.lang.String name) {
        
        //#line 44 "x10/lang/Clock.x10"
        final boolean t$132348 = x10.xrx.Runtime.get$STATIC_THREADS();
        
        //#line 44 "x10/lang/Clock.x10"
        if (t$132348) {
            
            //#line 44 "x10/lang/Clock.x10"
            final x10.lang.ClockUseException t$132347 = ((x10.lang.ClockUseException)(new x10.lang.ClockUseException(((java.lang.String)("Clocks are not compatible with static threads.")))));
            
            //#line 44 "x10/lang/Clock.x10"
            throw t$132347;
        }
        
        //#line 45 "x10/lang/Clock.x10"
        final x10.lang.Clock clock = ((x10.lang.Clock)(new x10.lang.Clock((java.lang.System[]) null)));
        
        //#line 58 . "x10/lang/Clock.x10"
        clock.name = name;
        
        //#line 32 . "x10/lang/Clock.x10"
        clock.__fieldInitializers_x10_lang_Clock();
        
        //#line 46 "x10/lang/Clock.x10"
        final x10.lang.Clock.ClockPhases t$132349 = x10.xrx.Runtime.activity().clockPhases();
        
        //#line 46 "x10/lang/Clock.x10"
        ((x10.util.HashMap<x10.lang.Clock, x10.core.Int>)t$132349).put__0x10$util$HashMap$$K__1x10$util$HashMap$$V$G(((x10.lang.Clock)(clock)), x10.core.Int.$box(1));
        
        //#line 47 "x10/lang/Clock.x10"
        return clock;
    }
    
    
    //#line 50 "x10/lang/Clock.x10"
    final public static int FIRST_PHASE = 1;
    
    //#line 53 "x10/lang/Clock.x10"
    public transient int count;
    
    //#line 54 "x10/lang/Clock.x10"
    public transient int alive;
    
    //#line 55 "x10/lang/Clock.x10"
    public transient int phase;
    
    
    //#line 57 "x10/lang/Clock.x10"
    // creation method for java code (1-phase java constructor)
    public Clock(final java.lang.String name) {
        this((java.lang.System[]) null);
        x10$lang$Clock$$init$S(name);
    }
    
    // constructor for non-virtual call
    final public x10.lang.Clock x10$lang$Clock$$init$S(final java.lang.String name) {
         {
            
            //#line 58 "x10/lang/Clock.x10"
            this.name = name;
            
            
            //#line 32 "x10/lang/Clock.x10"
            this.__fieldInitializers_x10_lang_Clock();
        }
        return this;
    }
    
    
    
    //#line 62 "x10/lang/Clock.x10"
    private void resumeLocal() {
        
        //#line 63 "x10/lang/Clock.x10"
        try {{
            
            //#line 63 "x10/lang/Clock.x10"
            x10.xrx.Runtime.enterAtomic();
            {
                
                //#line 64 "x10/lang/Clock.x10"
                final int t$132350 = this.alive;
                
                //#line 64 "x10/lang/Clock.x10"
                final int t$132351 = ((t$132350) - (((int)(1))));
                
                //#line 64 "x10/lang/Clock.x10"
                final int t$132352 = this.alive = t$132351;
                
                //#line 64 "x10/lang/Clock.x10"
                final boolean t$132356 = ((int) t$132352) == ((int) 0);
                
                //#line 64 "x10/lang/Clock.x10"
                if (t$132356) {
                    
                    //#line 65 "x10/lang/Clock.x10"
                    final int t$132353 = this.count;
                    
                    //#line 65 "x10/lang/Clock.x10"
                    this.alive = t$132353;
                    
                    //#line 66 "x10/lang/Clock.x10"
                    final int t$132354 = this.phase;
                    
                    //#line 66 "x10/lang/Clock.x10"
                    final int t$132355 = ((t$132354) + (((int)(1))));
                    
                    //#line 66 "x10/lang/Clock.x10"
                    this.phase = t$132355;
                }
            }
        }}finally {{
              
              //#line 63 "x10/lang/Clock.x10"
              x10.xrx.Runtime.exitAtomic();
          }}
        }
    
    public static void resumeLocal$P(final x10.lang.Clock Clock) {
        Clock.resumeLocal();
    }
    
    
    //#line 70 "x10/lang/Clock.x10"
    private void dropLocal(final int ph) {
        
        //#line 71 "x10/lang/Clock.x10"
        try {{
            
            //#line 71 "x10/lang/Clock.x10"
            x10.xrx.Runtime.enterAtomic();
            {
                
                //#line 72 "x10/lang/Clock.x10"
                final int t$132357 = this.count;
                
                //#line 72 "x10/lang/Clock.x10"
                final int t$132358 = ((t$132357) - (((int)(1))));
                
                //#line 72 "x10/lang/Clock.x10"
                this.count = t$132358;
                
                //#line 73 "x10/lang/Clock.x10"
                final int t$132359 = (-(ph));
                
                //#line 73 "x10/lang/Clock.x10"
                final int t$132360 = this.phase;
                
                //#line 73 "x10/lang/Clock.x10"
                final boolean t$132368 = ((int) t$132359) != ((int) t$132360);
                
                //#line 73 "x10/lang/Clock.x10"
                if (t$132368) {
                    
                    //#line 74 "x10/lang/Clock.x10"
                    final int t$132361 = this.alive;
                    
                    //#line 74 "x10/lang/Clock.x10"
                    final int t$132362 = ((t$132361) - (((int)(1))));
                    
                    //#line 74 "x10/lang/Clock.x10"
                    final int t$132363 = this.alive = t$132362;
                    
                    //#line 74 "x10/lang/Clock.x10"
                    final boolean t$132367 = ((int) t$132363) == ((int) 0);
                    
                    //#line 74 "x10/lang/Clock.x10"
                    if (t$132367) {
                        
                        //#line 75 "x10/lang/Clock.x10"
                        final int t$132364 = this.count;
                        
                        //#line 75 "x10/lang/Clock.x10"
                        this.alive = t$132364;
                        
                        //#line 76 "x10/lang/Clock.x10"
                        final int t$132365 = this.phase;
                        
                        //#line 76 "x10/lang/Clock.x10"
                        final int t$132366 = ((t$132365) + (((int)(1))));
                        
                        //#line 76 "x10/lang/Clock.x10"
                        this.phase = t$132366;
                    }
                }
            }
        }}finally {{
              
              //#line 71 "x10/lang/Clock.x10"
              x10.xrx.Runtime.exitAtomic();
          }}
        }
    
    public static void dropLocal$P(final int ph, final x10.lang.Clock Clock) {
        Clock.dropLocal((int)(ph));
    }
    
    
    //#line 82 "x10/lang/Clock.x10"
    private int get$O() {
        
        //#line 82 "x10/lang/Clock.x10"
        final x10.lang.Clock.ClockPhases t$132369 = x10.xrx.Runtime.activity().clockPhases();
        
        //#line 82 "x10/lang/Clock.x10"
        final int t$132370 = x10.core.Int.$unbox(((x10.util.HashMap<x10.lang.Clock, x10.core.Int>)t$132369).get__0x10$util$HashMap$$K$G(((x10.lang.Clock)(this))));
        
        //#line 82 "x10/lang/Clock.x10"
        return t$132370;
    }
    
    public static int get$P(final x10.lang.Clock Clock) {
        return Clock.get$O();
    }
    
    
    //#line 83 "x10/lang/Clock.x10"
    private int put$O(final int ph) {
        
        //#line 83 "x10/lang/Clock.x10"
        final x10.lang.Clock.ClockPhases t$132371 = x10.xrx.Runtime.activity().clockPhases();
        
        //#line 83 "x10/lang/Clock.x10"
        final int t$132372 = x10.core.Int.$unbox(((x10.util.HashMap<x10.lang.Clock, x10.core.Int>)t$132371).put__0x10$util$HashMap$$K__1x10$util$HashMap$$V$G(((x10.lang.Clock)(this)), x10.core.Int.$box(ph)));
        
        //#line 83 "x10/lang/Clock.x10"
        return t$132372;
    }
    
    public static int put$P$O(final int ph, final x10.lang.Clock Clock) {
        return Clock.put$O((int)(ph));
    }
    
    
    //#line 84 "x10/lang/Clock.x10"
    private int remove$O() {
        
        //#line 84 "x10/lang/Clock.x10"
        final x10.lang.Clock.ClockPhases t$132373 = x10.xrx.Runtime.activity().clockPhases();
        
        //#line 84 "x10/lang/Clock.x10"
        final int t$132374 = x10.core.Int.$unbox(((x10.util.HashMap<x10.lang.Clock, x10.core.Int>)t$132373).remove__0x10$util$HashMap$$K$G(((x10.lang.Clock)(this))));
        
        //#line 84 "x10/lang/Clock.x10"
        return t$132374;
    }
    
    public static int remove$P$O(final x10.lang.Clock Clock) {
        return Clock.remove$O();
    }
    
    
    //#line 85 "x10/lang/Clock.x10"
    public int register$O() {
        
        //#line 86 "x10/lang/Clock.x10"
        final x10.lang.Clock this$132321 = ((x10.lang.Clock)(this));
        
        //#line 134 . "x10/lang/Clock.x10"
        final boolean t$132375 = this$132321.registered$O();
        
        //#line 134 . "x10/lang/Clock.x10"
        final boolean t$132376 = !(t$132375);
        
        //#line 86 "x10/lang/Clock.x10"
        if (t$132376) {
            
            //#line 86 "x10/lang/Clock.x10"
            this.clockUseException(((java.lang.String)("async clocked")));
        }
        
        //#line 87 "x10/lang/Clock.x10"
        final int ph = this.get$O();
        
        //#line 88 "x10/lang/Clock.x10"
        final x10.core.GlobalRef t$132377 = ((x10.core.GlobalRef)(this.root));
        
        //#line 88 "x10/lang/Clock.x10"
        final x10.lang.Place t$132386 = ((x10.lang.Place)((t$132377).home));
        {
            
            //#line 88 "x10/lang/Clock.x10"
            x10.xrx.Runtime.runAt(((x10.lang.Place)(t$132386)), ((x10.core.fun.VoidFun_0_0)(new x10.lang.Clock.$Closure$147(this, this.root, ph, (x10.lang.Clock.$Closure$147.__1$1x10$lang$Clock$2) null))), ((x10.xrx.Runtime.Profile)(null)));
        }
        
        //#line 96 "x10/lang/Clock.x10"
        return ph;
    }
    
    
    //#line 98 "x10/lang/Clock.x10"
    public void resumeUnsafe() {
        
        //#line 99 "x10/lang/Clock.x10"
        x10.xrx.Runtime.ensureNotInAtomic();
        
        //#line 100 "x10/lang/Clock.x10"
        final int ph = this.get$O();
        
        //#line 101 "x10/lang/Clock.x10"
        final long t$132387 = ((long)(((int)(ph))));
        
        //#line 101 "x10/lang/Clock.x10"
        final boolean t$132388 = ((t$132387) < (((long)(0L))));
        
        //#line 101 "x10/lang/Clock.x10"
        if (t$132388) {
            
            //#line 101 "x10/lang/Clock.x10"
            return;
        }
        
        //#line 102 "x10/lang/Clock.x10"
        final x10.core.GlobalRef t$132389 = ((x10.core.GlobalRef)(this.root));
        
        //#line 102 "x10/lang/Clock.x10"
        final x10.lang.Place t$132391 = ((x10.lang.Place)((t$132389).home));
        {
            
            //#line 102 "x10/lang/Clock.x10"
            x10.xrx.Runtime.runAt(((x10.lang.Place)(t$132391)), ((x10.core.fun.VoidFun_0_0)(new x10.lang.Clock.$Closure$148(this, this.root, (x10.lang.Clock.$Closure$148.__1$1x10$lang$Clock$2) null))), ((x10.xrx.Runtime.Profile)(null)));
        }
        
        //#line 106 "x10/lang/Clock.x10"
        final int t$132392 = (-(ph));
        
        //#line 106 "x10/lang/Clock.x10"
        this.put$O((int)(t$132392));
    }
    
    
    //#line 108 "x10/lang/Clock.x10"
    public void advanceUnsafe() {
        
        //#line 109 "x10/lang/Clock.x10"
        x10.xrx.Runtime.ensureNotInAtomic();
        
        //#line 110 "x10/lang/Clock.x10"
        final int ph = this.get$O();
        
        //#line 111 "x10/lang/Clock.x10"
        final int abs = java.lang.Math.abs(((int)(ph)));
        
        //#line 112 "x10/lang/Clock.x10"
        final x10.core.GlobalRef t$132393 = ((x10.core.GlobalRef)(this.root));
        
        //#line 112 "x10/lang/Clock.x10"
        final x10.lang.Place t$132397 = ((x10.lang.Place)((t$132393).home));
        {
            
            //#line 112 "x10/lang/Clock.x10"
            x10.xrx.Runtime.runAt(((x10.lang.Place)(t$132397)), ((x10.core.fun.VoidFun_0_0)(new x10.lang.Clock.$Closure$149(this, this.root, ph, abs, (x10.lang.Clock.$Closure$149.__1$1x10$lang$Clock$2) null))), ((x10.xrx.Runtime.Profile)(null)));
        }
        
        //#line 117 "x10/lang/Clock.x10"
        final int t$132398 = ((abs) + (((int)(1))));
        
        //#line 117 "x10/lang/Clock.x10"
        this.put$O((int)(t$132398));
    }
    
    
    //#line 119 "x10/lang/Clock.x10"
    public void dropUnsafe() {
        
        //#line 120 "x10/lang/Clock.x10"
        final int ph = this.remove$O();
        
        //#line 121 "x10/lang/Clock.x10"
        final x10.core.GlobalRef t$132399 = ((x10.core.GlobalRef)(this.root));
        
        //#line 121 "x10/lang/Clock.x10"
        final x10.lang.Place t$132401 = ((x10.lang.Place)((t$132399).home));
        {
            
            //#line 121 "x10/lang/Clock.x10"
            x10.xrx.Runtime.runAt(((x10.lang.Place)(t$132401)), ((x10.core.fun.VoidFun_0_0)(new x10.lang.Clock.$Closure$150(this, this.root, ph, (x10.lang.Clock.$Closure$150.__1$1x10$lang$Clock$2) null))), ((x10.xrx.Runtime.Profile)(null)));
        }
    }
    
    
    //#line 126 "x10/lang/Clock.x10"
    public void dropInternal() {
        
        //#line 127 "x10/lang/Clock.x10"
        final int ph = this.get$O();
        
        //#line 128 "x10/lang/Clock.x10"
        final x10.core.GlobalRef t$132402 = ((x10.core.GlobalRef)(this.root));
        
        //#line 128 "x10/lang/Clock.x10"
        final x10.lang.Place t$132404 = ((x10.lang.Place)((t$132402).home));
        {
            
            //#line 128 "x10/lang/Clock.x10"
            x10.xrx.Runtime.runAt(((x10.lang.Place)(t$132404)), ((x10.core.fun.VoidFun_0_0)(new x10.lang.Clock.$Closure$151(this, this.root, ph, (x10.lang.Clock.$Closure$151.__1$1x10$lang$Clock$2) null))), ((x10.xrx.Runtime.Profile)(null)));
        }
    }
    
    
    //#line 133 "x10/lang/Clock.x10"
    public boolean registered$O() {
        
        //#line 133 "x10/lang/Clock.x10"
        final x10.lang.Clock.ClockPhases t$132405 = x10.xrx.Runtime.activity().clockPhases();
        
        //#line 133 "x10/lang/Clock.x10"
        final boolean t$132406 = ((x10.util.HashMap<x10.lang.Clock, x10.core.Int>)t$132405).containsKey__0x10$util$HashMap$$K$O(((x10.lang.Clock)(this)));
        
        //#line 133 "x10/lang/Clock.x10"
        return t$132406;
    }
    
    
    //#line 134 "x10/lang/Clock.x10"
    public boolean dropped$O() {
        
        //#line 134 "x10/lang/Clock.x10"
        final boolean t$132407 = this.registered$O();
        
        //#line 134 "x10/lang/Clock.x10"
        final boolean t$132408 = !(t$132407);
        
        //#line 134 "x10/lang/Clock.x10"
        return t$132408;
    }
    
    
    //#line 135 "x10/lang/Clock.x10"
    public int phase$O() {
        
        //#line 136 "x10/lang/Clock.x10"
        final x10.lang.Clock this$132323 = ((x10.lang.Clock)(this));
        
        //#line 134 . "x10/lang/Clock.x10"
        final boolean t$132409 = this$132323.registered$O();
        
        //#line 134 . "x10/lang/Clock.x10"
        final boolean t$132410 = !(t$132409);
        
        //#line 136 "x10/lang/Clock.x10"
        if (t$132410) {
            
            //#line 136 "x10/lang/Clock.x10"
            this.clockUseException(((java.lang.String)("phase")));
        }
        
        //#line 137 "x10/lang/Clock.x10"
        final int t$132411 = this.get$O();
        
        //#line 137 "x10/lang/Clock.x10"
        final int t$132412 = java.lang.Math.abs(((int)(t$132411)));
        
        //#line 137 "x10/lang/Clock.x10"
        return t$132412;
    }
    
    
    //#line 139 "x10/lang/Clock.x10"
    public void resume() {
        
        //#line 140 "x10/lang/Clock.x10"
        final x10.lang.Clock this$132325 = ((x10.lang.Clock)(this));
        
        //#line 134 . "x10/lang/Clock.x10"
        final boolean t$132413 = this$132325.registered$O();
        
        //#line 134 . "x10/lang/Clock.x10"
        final boolean t$132414 = !(t$132413);
        
        //#line 140 "x10/lang/Clock.x10"
        if (t$132414) {
            
            //#line 140 "x10/lang/Clock.x10"
            this.clockUseException(((java.lang.String)("resume")));
        }
        
        //#line 141 "x10/lang/Clock.x10"
        this.resumeUnsafe();
    }
    
    
    //#line 143 "x10/lang/Clock.x10"
    public void advance() {
        
        //#line 144 "x10/lang/Clock.x10"
        final x10.lang.Clock this$132327 = ((x10.lang.Clock)(this));
        
        //#line 134 . "x10/lang/Clock.x10"
        final boolean t$132415 = this$132327.registered$O();
        
        //#line 134 . "x10/lang/Clock.x10"
        final boolean t$132416 = !(t$132415);
        
        //#line 144 "x10/lang/Clock.x10"
        if (t$132416) {
            
            //#line 144 "x10/lang/Clock.x10"
            this.clockUseException(((java.lang.String)("advance")));
        }
        
        //#line 145 "x10/lang/Clock.x10"
        this.advanceUnsafe();
    }
    
    
    //#line 147 "x10/lang/Clock.x10"
    public void drop() {
        
        //#line 148 "x10/lang/Clock.x10"
        final x10.lang.Clock this$132329 = ((x10.lang.Clock)(this));
        
        //#line 134 . "x10/lang/Clock.x10"
        final boolean t$132417 = this$132329.registered$O();
        
        //#line 134 . "x10/lang/Clock.x10"
        final boolean t$132418 = !(t$132417);
        
        //#line 148 "x10/lang/Clock.x10"
        if (t$132418) {
            
            //#line 148 "x10/lang/Clock.x10"
            this.clockUseException(((java.lang.String)("drop")));
        }
        
        //#line 149 "x10/lang/Clock.x10"
        this.dropUnsafe();
    }
    
    
    //#line 152 "x10/lang/Clock.x10"
    public java.lang.String toString() {
        
        //#line 152 "x10/lang/Clock.x10"
        final java.lang.String t$132419 = ((java.lang.String)(this.name));
        
        //#line 152 "x10/lang/Clock.x10"
        final boolean t$132420 = (t$132419).equals("");
        
        //#line 152 "x10/lang/Clock.x10"
        java.lang.String t$132421 =  null;
        
        //#line 152 "x10/lang/Clock.x10"
        if (t$132420) {
            
            //#line 152 "x10/lang/Clock.x10"
            t$132421 = x10.lang.System.identityToString(((java.lang.Object)(this)));
        } else {
            
            //#line 152 "x10/lang/Clock.x10"
            t$132421 = this.name;
        }
        
        //#line 152 "x10/lang/Clock.x10"
        return t$132421;
    }
    
    
    //#line 154 "x10/lang/Clock.x10"
    private void clockUseException(final java.lang.String method) {
        
        //#line 155 "x10/lang/Clock.x10"
        final x10.lang.Clock this$132331 = ((x10.lang.Clock)(this));
        
        //#line 134 . "x10/lang/Clock.x10"
        final boolean t$132423 = this$132331.registered$O();
        
        //#line 134 . "x10/lang/Clock.x10"
        final boolean t$132430 = !(t$132423);
        
        //#line 155 "x10/lang/Clock.x10"
        if (t$132430) {
            
            //#line 155 "x10/lang/Clock.x10"
            final java.lang.String t$132424 = (("invalid invocation of ") + (method));
            
            //#line 155 "x10/lang/Clock.x10"
            final java.lang.String t$132425 = ((t$132424) + ("() on clock "));
            
            //#line 155 "x10/lang/Clock.x10"
            final java.lang.String t$132426 = this.toString();
            
            //#line 155 "x10/lang/Clock.x10"
            final java.lang.String t$132427 = ((t$132425) + (t$132426));
            
            //#line 155 "x10/lang/Clock.x10"
            final java.lang.String t$132428 = ((t$132427) + ("; calling activity is not clocked on this clock"));
            
            //#line 155 "x10/lang/Clock.x10"
            final x10.lang.ClockUseException t$132429 = ((x10.lang.ClockUseException)(new x10.lang.ClockUseException(t$132428)));
            
            //#line 155 "x10/lang/Clock.x10"
            throw t$132429;
        }
    }
    
    public static void clockUseException$P(final java.lang.String method, final x10.lang.Clock Clock) {
        Clock.clockUseException(((java.lang.String)(method)));
    }
    
    
    //#line 158 "x10/lang/Clock.x10"
    public static void advanceAll() {
        
        //#line 160 "x10/lang/Clock.x10"
        x10.xrx.Runtime.ensureNotInAtomic();
        
        //#line 161 "x10/lang/Clock.x10"
        final x10.lang.Clock.ClockPhases t$132431 = x10.xrx.Runtime.activity().clockPhases();
        
        //#line 161 "x10/lang/Clock.x10"
        t$132431.advanceAll();
    }
    
    
    //#line 164 "x10/lang/Clock.x10"
    public static void resumeAll() {
        
        //#line 164 "x10/lang/Clock.x10"
        final x10.lang.Clock.ClockPhases t$132432 = x10.xrx.Runtime.activity().clockPhases();
        
        //#line 164 "x10/lang/Clock.x10"
        t$132432.resumeAll();
    }
    
    
    //#line 166 "x10/lang/Clock.x10"
    private static x10.lang.Clock.ClockPhases getClockPhases() {
        try {
            return x10.xrx.Runtime.activity().clockPhases();
        }
        catch (java.lang.Throwable exc$206364) {
            throw x10.runtime.impl.java.ThrowableUtils.ensureX10Exception(exc$206364);
        }
        
    }
    
    
    public static x10.lang.Clock.ClockPhases getClockPhases$P() {
        return x10.xrx.Runtime.activity().clockPhases();
    }
    
    
    //#line 178 "x10/lang/Clock.x10"
    /**
     * Specialization of HashMap to maintain the set of Clocks that
     * an Activity is currently registered on.
     * This type is public and many of its methods are public so it can be 
     * manipulated from the XRX runtime, but there is intentionally no accessible 
     * API that allows user-code to actually get the active instance 
     * of a ClockPhase for an Activity
     */
    @x10.runtime.impl.java.X10Generated
    public static class ClockPhases extends x10.util.HashMap<x10.lang.Clock, x10.core.Int> implements x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<ClockPhases> $RTT = 
            x10.rtt.NamedType.<ClockPhases> make("x10.lang.Clock.ClockPhases",
                                                 ClockPhases.class,
                                                 new x10.rtt.Type[] {
                                                     x10.rtt.ParameterizedType.make(x10.util.HashMap.$RTT, x10.lang.Clock.$RTT, x10.rtt.Types.INT)
                                                 });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        // custom serialization support
        public static x10.serialization.X10JavaSerializable $_deserialize_body(x10.lang.Clock.ClockPhases $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.io.Deserializer $ds = new x10.io.Deserializer($deserializer);
            $_obj.x10$lang$Clock$ClockPhases$$init$S($ds);
            short $marker = $deserializer.readSerializationId();
            if ($marker != x10.serialization.SerializationConstants.CUSTOM_SERIALIZATION_END) { x10.serialization.X10JavaDeserializer.raiseSerializationProtocolError(); }
            return $_obj;
            
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            int $obj_id = $deserializer.record_reference(null); /* Get id eagerly so that ordering in object map is stable (needed for repeated reference mechanism) */
            ClockPhases $_obj = new ClockPhases((java.lang.System[]) null);
            $deserializer.update_reference($obj_id, $_obj); /* Update entry in object map with the actual object before deserializing body */
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
        
            serialize(new x10.io.Serializer($serializer)); 
            $serializer.writeSerializationId(x10.serialization.SerializationConstants.CUSTOM_SERIALIZATION_END);
            
        }
        
        // constructor just for allocation
        public ClockPhases(final java.lang.System[] $dummy) {
            super($dummy, x10.lang.Clock.$RTT, x10.rtt.Types.INT);
            
        }
        
        // bridge for inherited method public x10.util.HashMap[K, V].operator()(k:K){}:V
        public int $apply$O(x10.lang.Clock a1){
            return x10.core.Int.$unbox(super.$apply__0x10$util$HashMap$$K$G((a1)));
        }
        
        // bridge for inherited method public x10.util.HashMap[K, V].get(k:K){}:V
        public int get$O(x10.lang.Clock a1){
            return x10.core.Int.$unbox(super.get__0x10$util$HashMap$$K$G((a1)));
        }
        
        // bridge for inherited method public x10.util.HashMap[K, V].getOrElse(k:K, orelse:V){}:V
        public int getOrElse$O(x10.lang.Clock a1, int a2){
            return x10.core.Int.$unbox(super.getOrElse__0x10$util$HashMap$$K__1x10$util$HashMap$$V$G((a1), x10.core.Int.$box(a2)));
        }
        
        // bridge for inherited method public x10.util.HashMap[K, V].getOrThrow(k:K){}:V
        public int getOrThrow$O(x10.lang.Clock a1){
            return x10.core.Int.$unbox(super.getOrThrow__0x10$util$HashMap$$K$G((a1)));
        }
        
        // bridge for inherited method public x10.util.HashMap[K, V].operator()=(k:K, v:V){}:V
        public int $set$O(x10.lang.Clock a1, int a2){
            return x10.core.Int.$unbox(super.$set__0x10$util$HashMap$$K__1x10$util$HashMap$$V$G((a1), x10.core.Int.$box(a2)));
        }
        
        // bridge for inherited method public x10.util.HashMap[K, V].put(k:K, v:V){}:V
        public int put$O(x10.lang.Clock a1, int a2){
            return x10.core.Int.$unbox(super.put__0x10$util$HashMap$$K__1x10$util$HashMap$$V$G((a1), x10.core.Int.$box(a2)));
        }
        
        // bridge for inherited method final protected x10.util.HashMap[K, V].putInternal(k:K, v:V, mayRehash:x10.lang.Boolean){}:V
        final protected int putInternal$O(x10.lang.Clock a1, int a2, boolean a3){
            return x10.core.Int.$unbox(super.putInternal__0x10$util$HashMap$$K__1x10$util$HashMap$$V$G((a1), x10.core.Int.$box(a2), (a3)));
        }
        
        // bridge for inherited method public x10.util.HashMap[K, V].remove(k:K){}:V
        public int remove$O(x10.lang.Clock a1){
            return x10.core.Int.$unbox(super.remove__0x10$util$HashMap$$K$G((a1)));
        }
        
        
    
        
        
        //#line 181 "x10/lang/Clock.x10"
        public static x10.lang.Clock.ClockPhases make__0$1x10$lang$Clock$2(final x10.core.Rail<x10.lang.Clock> clocks) {
            
            //#line 182 "x10/lang/Clock.x10"
            final x10.lang.Clock.ClockPhases clockPhases = ((x10.lang.Clock.ClockPhases)(new x10.lang.Clock.ClockPhases((java.lang.System[]) null)));
            
            //#line 182 "x10/lang/Clock.x10"
            clockPhases.x10$lang$Clock$ClockPhases$$init$S();
            
            //#line 183 "x10/lang/Clock.x10"
            long i$132468 = 0L;
            {
                
                //#line 183 "x10/lang/Clock.x10"
                final x10.lang.Clock[] clocks$value$132511 = ((x10.lang.Clock[])clocks.value);
                
                //#line 183 "x10/lang/Clock.x10"
                for (;
                     true;
                     ) {
                    
                    //#line 183 "x10/lang/Clock.x10"
                    final long t$132470 = ((x10.core.Rail<x10.lang.Clock>)clocks).size;
                    
                    //#line 183 "x10/lang/Clock.x10"
                    final boolean t$132471 = ((i$132468) < (((long)(t$132470))));
                    
                    //#line 183 "x10/lang/Clock.x10"
                    if (!(t$132471)) {
                        
                        //#line 183 "x10/lang/Clock.x10"
                        break;
                    }
                    
                    //#line 184 "x10/lang/Clock.x10"
                    final x10.lang.Clock t$132462 = ((x10.lang.Clock)clocks$value$132511[(int)i$132468]);
                    
                    //#line 184 "x10/lang/Clock.x10"
                    final x10.lang.Clock t$132464 = ((x10.lang.Clock)clocks$value$132511[(int)i$132468]);
                    
                    //#line 184 "x10/lang/Clock.x10"
                    final int t$132465 = t$132464.register$O();
                    
                    //#line 184 "x10/lang/Clock.x10"
                    ((x10.util.HashMap<x10.lang.Clock, x10.core.Int>)clockPhases).put__0x10$util$HashMap$$K__1x10$util$HashMap$$V$G(((x10.lang.Clock)(t$132462)), x10.core.Int.$box(t$132465));
                    
                    //#line 183 "x10/lang/Clock.x10"
                    final long t$132467 = ((i$132468) + (((long)(1L))));
                    
                    //#line 183 "x10/lang/Clock.x10"
                    i$132468 = t$132467;
                }
            }
            
            //#line 185 "x10/lang/Clock.x10"
            return clockPhases;
        }
        
        
        //#line 188 "x10/lang/Clock.x10"
        public static x10.lang.Clock.ClockPhases make() {
            
            //#line 188 "x10/lang/Clock.x10"
            final x10.lang.Clock.ClockPhases alloc$131957 = ((x10.lang.Clock.ClockPhases)(new x10.lang.Clock.ClockPhases((java.lang.System[]) null)));
            
            //#line 188 "x10/lang/Clock.x10"
            alloc$131957.x10$lang$Clock$ClockPhases$$init$S();
            
            //#line 188 "x10/lang/Clock.x10"
            return alloc$131957;
        }
        
        
        //#line 191 "x10/lang/Clock.x10"
        public void advanceAll() {
            
            //#line 192 "x10/lang/Clock.x10"
            final x10.util.Set t$132476 = this.entries();
            
            //#line 192 "x10/lang/Clock.x10"
            final x10.lang.Iterator entry$132477 = ((x10.lang.Iterator<x10.util.Map.Entry<x10.lang.Clock, x10.core.Int>>)
                                                     ((x10.lang.Iterable<x10.util.Map.Entry<x10.lang.Clock, x10.core.Int>>)t$132476).iterator());
            
            //#line 192 "x10/lang/Clock.x10"
            for (;
                 true;
                 ) {
                
                //#line 192 "x10/lang/Clock.x10"
                final boolean t$132478 = ((x10.lang.Iterator<x10.util.Map.Entry<x10.lang.Clock, x10.core.Int>>)entry$132477).hasNext$O();
                
                //#line 192 "x10/lang/Clock.x10"
                if (!(t$132478)) {
                    
                    //#line 192 "x10/lang/Clock.x10"
                    break;
                }
                
                //#line 192 "x10/lang/Clock.x10"
                final x10.util.Map.Entry entry$132472 = ((x10.lang.Iterator<x10.util.Map.Entry<x10.lang.Clock, x10.core.Int>>)entry$132477).next$G();
                
                //#line 192 "x10/lang/Clock.x10"
                final x10.lang.Clock t$132473 = ((x10.util.Map.Entry<x10.lang.Clock, x10.core.Int>)entry$132472).getKey$G();
                
                //#line 192 "x10/lang/Clock.x10"
                t$132473.resumeUnsafe();
            }
            
            //#line 193 "x10/lang/Clock.x10"
            final x10.util.Set t$132479 = this.entries();
            
            //#line 193 "x10/lang/Clock.x10"
            final x10.lang.Iterator entry$132480 = ((x10.lang.Iterator<x10.util.Map.Entry<x10.lang.Clock, x10.core.Int>>)
                                                     ((x10.lang.Iterable<x10.util.Map.Entry<x10.lang.Clock, x10.core.Int>>)t$132479).iterator());
            
            //#line 193 "x10/lang/Clock.x10"
            for (;
                 true;
                 ) {
                
                //#line 193 "x10/lang/Clock.x10"
                final boolean t$132481 = ((x10.lang.Iterator<x10.util.Map.Entry<x10.lang.Clock, x10.core.Int>>)entry$132480).hasNext$O();
                
                //#line 193 "x10/lang/Clock.x10"
                if (!(t$132481)) {
                    
                    //#line 193 "x10/lang/Clock.x10"
                    break;
                }
                
                //#line 193 "x10/lang/Clock.x10"
                final x10.util.Map.Entry entry$132474 = ((x10.lang.Iterator<x10.util.Map.Entry<x10.lang.Clock, x10.core.Int>>)entry$132480).next$G();
                
                //#line 193 "x10/lang/Clock.x10"
                final x10.lang.Clock t$132475 = ((x10.util.Map.Entry<x10.lang.Clock, x10.core.Int>)entry$132474).getKey$G();
                
                //#line 193 "x10/lang/Clock.x10"
                t$132475.advanceUnsafe();
            }
        }
        
        
        //#line 197 "x10/lang/Clock.x10"
        public void resumeAll() {
            
            //#line 198 "x10/lang/Clock.x10"
            final x10.util.Set t$132453 = this.entries();
            
            //#line 198 "x10/lang/Clock.x10"
            final x10.lang.Iterator entry$131963 = ((x10.lang.Iterator<x10.util.Map.Entry<x10.lang.Clock, x10.core.Int>>)
                                                     ((x10.lang.Iterable<x10.util.Map.Entry<x10.lang.Clock, x10.core.Int>>)t$132453).iterator());
            
            //#line 198 "x10/lang/Clock.x10"
            for (;
                 true;
                 ) {
                
                //#line 198 "x10/lang/Clock.x10"
                final boolean t$132455 = ((x10.lang.Iterator<x10.util.Map.Entry<x10.lang.Clock, x10.core.Int>>)entry$131963).hasNext$O();
                
                //#line 198 "x10/lang/Clock.x10"
                if (!(t$132455)) {
                    
                    //#line 198 "x10/lang/Clock.x10"
                    break;
                }
                
                //#line 198 "x10/lang/Clock.x10"
                final x10.util.Map.Entry entry$132482 = ((x10.lang.Iterator<x10.util.Map.Entry<x10.lang.Clock, x10.core.Int>>)entry$131963).next$G();
                
                //#line 198 "x10/lang/Clock.x10"
                final x10.lang.Clock t$132483 = ((x10.util.Map.Entry<x10.lang.Clock, x10.core.Int>)entry$132482).getKey$G();
                
                //#line 198 "x10/lang/Clock.x10"
                t$132483.resumeUnsafe();
            }
        }
        
        
        //#line 202 "x10/lang/Clock.x10"
        public void drop() {
            
            //#line 203 "x10/lang/Clock.x10"
            final x10.util.Set t$132486 = this.entries();
            
            //#line 203 "x10/lang/Clock.x10"
            final x10.lang.Iterator entry$132487 = ((x10.lang.Iterator<x10.util.Map.Entry<x10.lang.Clock, x10.core.Int>>)
                                                     ((x10.lang.Iterable<x10.util.Map.Entry<x10.lang.Clock, x10.core.Int>>)t$132486).iterator());
            
            //#line 203 "x10/lang/Clock.x10"
            for (;
                 true;
                 ) {
                
                //#line 203 "x10/lang/Clock.x10"
                final boolean t$132488 = ((x10.lang.Iterator<x10.util.Map.Entry<x10.lang.Clock, x10.core.Int>>)entry$132487).hasNext$O();
                
                //#line 203 "x10/lang/Clock.x10"
                if (!(t$132488)) {
                    
                    //#line 203 "x10/lang/Clock.x10"
                    break;
                }
                
                //#line 203 "x10/lang/Clock.x10"
                final x10.util.Map.Entry entry$132484 = ((x10.lang.Iterator<x10.util.Map.Entry<x10.lang.Clock, x10.core.Int>>)entry$132487).next$G();
                
                //#line 203 "x10/lang/Clock.x10"
                final x10.lang.Clock t$132485 = ((x10.util.Map.Entry<x10.lang.Clock, x10.core.Int>)entry$132484).getKey$G();
                
                //#line 203 "x10/lang/Clock.x10"
                t$132485.dropInternal();
            }
            
            //#line 204 "x10/lang/Clock.x10"
            this.clear();
        }
        
        
        //#line 208 "x10/lang/Clock.x10"
        public void serialize(final x10.io.Serializer s) {
            
            //#line 209 "x10/lang/Clock.x10"
            super.serialize(((x10.io.Serializer)(s)));
        }
        
        
        //#line 211 "x10/lang/Clock.x10"
        // creation method for java code (1-phase java constructor)
        public ClockPhases() {
            this((java.lang.System[]) null);
            x10$lang$Clock$ClockPhases$$init$S();
        }
        
        // constructor for non-virtual call
        final public x10.lang.Clock.ClockPhases x10$lang$Clock$ClockPhases$$init$S() {
             {
                
                //#line 211 "x10/lang/Clock.x10"
                /*super.*/x10$util$HashMap$$init$S();
                
                //#line 211 "x10/lang/Clock.x10"
                
            }
            return this;
        }
        
        
        
        //#line 212 "x10/lang/Clock.x10"
        // creation method for java code (1-phase java constructor)
        public ClockPhases(final x10.io.Deserializer ds) {
            this((java.lang.System[]) null);
            x10$lang$Clock$ClockPhases$$init$S(ds);
        }
        
        // constructor for non-virtual call
        final public x10.lang.Clock.ClockPhases x10$lang$Clock$ClockPhases$$init$S(final x10.io.Deserializer ds) {
            x10$lang$Clock$ClockPhases$$initForReflection(ds);
            
            return this;
        }
        
        public void x10$lang$Clock$ClockPhases$$initForReflection(x10.io.Deserializer ds) {
             {
                
                //#line 213 "x10/lang/Clock.x10"
                /*super.*/x10$util$HashMap$$init$S(((x10.io.Deserializer)(ds)));
                
                //#line 212 "x10/lang/Clock.x10"
                
            }
        }
        
        
        
        //#line 178 "x10/lang/Clock.x10"
        final public x10.lang.Clock.ClockPhases x10$lang$Clock$ClockPhases$$this$x10$lang$Clock$ClockPhases() {
            
            //#line 178 "x10/lang/Clock.x10"
            return x10.lang.Clock.ClockPhases.this;
        }
        
        
        //#line 178 "x10/lang/Clock.x10"
        final public void __fieldInitializers_x10_lang_Clock_ClockPhases() {
            
        }
        
        public void x10$util$HashMap$serialize$S(final x10.io.Serializer a0) {
            super.serialize(((x10.io.Serializer)(a0)));
        }
    }
    
    
    
    //#line 32 "x10/lang/Clock.x10"
    final public x10.lang.Clock x10$lang$Clock$$this$x10$lang$Clock() {
        
        //#line 32 "x10/lang/Clock.x10"
        return x10.lang.Clock.this;
    }
    
    
    //#line 32 "x10/lang/Clock.x10"
    final public void __fieldInitializers_x10_lang_Clock() {
        
        //#line 33 "x10/lang/Clock.x10"
        final x10.core.GlobalRef t$132460 = ((x10.core.GlobalRef)(new x10.core.GlobalRef<x10.lang.Clock>(x10.lang.Clock.$RTT, ((x10.lang.Clock)(this)), (x10.core.GlobalRef.__0x10$lang$GlobalRef$$T) null)));
        
        //#line 32 "x10/lang/Clock.x10"
        this.root = ((x10.core.GlobalRef)(t$132460));
        
        //#line 32 "x10/lang/Clock.x10"
        this.count = 1;
        
        //#line 32 "x10/lang/Clock.x10"
        this.alive = 1;
        
        //#line 32 "x10/lang/Clock.x10"
        this.phase = 1;
    }
    
    public static int get$FIRST_PHASE() {
        return x10.lang.Clock.FIRST_PHASE;
    }
    
    @x10.runtime.impl.java.X10Generated
    final public static class $Closure$147 extends x10.core.Ref implements x10.core.fun.VoidFun_0_0, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<$Closure$147> $RTT = 
            x10.rtt.StaticVoidFunType.<$Closure$147> make($Closure$147.class,
                                                          new x10.rtt.Type[] {
                                                              x10.core.fun.VoidFun_0_0.$RTT
                                                          });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static x10.serialization.X10JavaSerializable $_deserialize_body(x10.lang.Clock.$Closure$147 $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            $_obj.out$$ = $deserializer.readObject();
            $_obj.ph = $deserializer.readInt();
            $_obj.root = $deserializer.readObject();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.lang.Clock.$Closure$147 $_obj = new x10.lang.Clock.$Closure$147((java.lang.System[]) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            $serializer.write(this.out$$);
            $serializer.write(this.ph);
            $serializer.write(this.root);
            
        }
        
        // constructor just for allocation
        public $Closure$147(final java.lang.System[] $dummy) {
            
        }
        
        // synthetic type for parameter mangling
        public static final class __1$1x10$lang$Clock$2 {}
        
    
        
        public void $apply() {
            
            //#line 88 "x10/lang/Clock.x10"
            try {{
                
                //#line 89 "x10/lang/Clock.x10"
                final x10.core.GlobalRef t$132378 = ((x10.core.GlobalRef)(this.root));
                
                //#line 89 "x10/lang/Clock.x10"
                final x10.lang.Clock me = (((x10.core.GlobalRef<x10.lang.Clock>)(t$132378))).$apply$G();
                
                //#line 90 "x10/lang/Clock.x10"
                try {{
                    
                    //#line 90 "x10/lang/Clock.x10"
                    x10.xrx.Runtime.enterAtomic();
                    {
                        
                        //#line 91 "x10/lang/Clock.x10"
                        final int t$132379 = me.count;
                        
                        //#line 91 "x10/lang/Clock.x10"
                        final int t$132380 = ((t$132379) + (((int)(1))));
                        
                        //#line 91 "x10/lang/Clock.x10"
                        me.count = t$132380;
                        
                        //#line 92 "x10/lang/Clock.x10"
                        final int t$132381 = (-(this.ph));
                        
                        //#line 92 "x10/lang/Clock.x10"
                        final int t$132382 = me.phase;
                        
                        //#line 92 "x10/lang/Clock.x10"
                        final boolean t$132385 = ((int) t$132381) != ((int) t$132382);
                        
                        //#line 92 "x10/lang/Clock.x10"
                        if (t$132385) {
                            
                            //#line 93 "x10/lang/Clock.x10"
                            final int t$132383 = me.alive;
                            
                            //#line 93 "x10/lang/Clock.x10"
                            final int t$132384 = ((t$132383) + (((int)(1))));
                            
                            //#line 93 "x10/lang/Clock.x10"
                            me.alive = t$132384;
                        }
                    }
                }}finally {{
                      
                      //#line 90 "x10/lang/Clock.x10"
                      x10.xrx.Runtime.exitAtomic();
                  }}
                }}catch (java.lang.Throwable __lowerer__var__0__) {
                    
                    //#line 88 "x10/lang/Clock.x10"
                    int __lowerer__var__1__ = (x10.core.Int.$unbox(x10.xrx.Runtime.<x10.core.Int> wrapAtChecked$G(x10.rtt.Types.INT, ((java.lang.Throwable)(__lowerer__var__0__)))));
                }
            }
        
        public x10.lang.Clock out$$;
        public x10.core.GlobalRef<x10.lang.Clock> root;
        public int ph;
        
        public $Closure$147(final x10.lang.Clock out$$, final x10.core.GlobalRef<x10.lang.Clock> root, final int ph, __1$1x10$lang$Clock$2 $dummy) {
             {
                this.out$$ = out$$;
                this.root = ((x10.core.GlobalRef)(root));
                this.ph = ph;
            }
        }
        
        }
        
    @x10.runtime.impl.java.X10Generated
    final public static class $Closure$148 extends x10.core.Ref implements x10.core.fun.VoidFun_0_0, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<$Closure$148> $RTT = 
            x10.rtt.StaticVoidFunType.<$Closure$148> make($Closure$148.class,
                                                          new x10.rtt.Type[] {
                                                              x10.core.fun.VoidFun_0_0.$RTT
                                                          });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static x10.serialization.X10JavaSerializable $_deserialize_body(x10.lang.Clock.$Closure$148 $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            $_obj.out$$ = $deserializer.readObject();
            $_obj.root = $deserializer.readObject();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.lang.Clock.$Closure$148 $_obj = new x10.lang.Clock.$Closure$148((java.lang.System[]) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            $serializer.write(this.out$$);
            $serializer.write(this.root);
            
        }
        
        // constructor just for allocation
        public $Closure$148(final java.lang.System[] $dummy) {
            
        }
        
        // synthetic type for parameter mangling
        public static final class __1$1x10$lang$Clock$2 {}
        
    
        
        public void $apply() {
            
            //#line 102 "x10/lang/Clock.x10"
            try {{
                
                //#line 103 "x10/lang/Clock.x10"
                final x10.core.GlobalRef t$132390 = ((x10.core.GlobalRef)(this.root));
                
                //#line 103 "x10/lang/Clock.x10"
                final x10.lang.Clock me = (((x10.core.GlobalRef<x10.lang.Clock>)(t$132390))).$apply$G();
                
                //#line 104 "x10/lang/Clock.x10"
                me.resumeLocal();
            }}catch (java.lang.Throwable __lowerer__var__0__) {
                
                //#line 102 "x10/lang/Clock.x10"
                int __lowerer__var__1__ = (x10.core.Int.$unbox(x10.xrx.Runtime.<x10.core.Int> wrapAtChecked$G(x10.rtt.Types.INT, ((java.lang.Throwable)(__lowerer__var__0__)))));
            }
        }
        
        public x10.lang.Clock out$$;
        public x10.core.GlobalRef<x10.lang.Clock> root;
        
        public $Closure$148(final x10.lang.Clock out$$, final x10.core.GlobalRef<x10.lang.Clock> root, __1$1x10$lang$Clock$2 $dummy) {
             {
                this.out$$ = out$$;
                this.root = ((x10.core.GlobalRef)(root));
            }
        }
        
    }
    
    @x10.runtime.impl.java.X10Generated
    final public static class $Closure$149 extends x10.core.Ref implements x10.core.fun.VoidFun_0_0, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<$Closure$149> $RTT = 
            x10.rtt.StaticVoidFunType.<$Closure$149> make($Closure$149.class,
                                                          new x10.rtt.Type[] {
                                                              x10.core.fun.VoidFun_0_0.$RTT
                                                          });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static x10.serialization.X10JavaSerializable $_deserialize_body(x10.lang.Clock.$Closure$149 $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            $_obj.abs = $deserializer.readInt();
            $_obj.out$$ = $deserializer.readObject();
            $_obj.ph = $deserializer.readInt();
            $_obj.root = $deserializer.readObject();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.lang.Clock.$Closure$149 $_obj = new x10.lang.Clock.$Closure$149((java.lang.System[]) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            $serializer.write(this.abs);
            $serializer.write(this.out$$);
            $serializer.write(this.ph);
            $serializer.write(this.root);
            
        }
        
        // constructor just for allocation
        public $Closure$149(final java.lang.System[] $dummy) {
            
        }
        
        // synthetic type for parameter mangling
        public static final class __1$1x10$lang$Clock$2 {}
        
    
        
        public void $apply() {
            
            //#line 112 "x10/lang/Clock.x10"
            try {{
                
                //#line 113 "x10/lang/Clock.x10"
                final x10.core.GlobalRef t$132394 = ((x10.core.GlobalRef)(this.root));
                
                //#line 113 "x10/lang/Clock.x10"
                final x10.lang.Clock me = (((x10.core.GlobalRef<x10.lang.Clock>)(t$132394))).$apply$G();
                
                //#line 114 "x10/lang/Clock.x10"
                final long t$132395 = ((long)(((int)(this.ph))));
                
                //#line 114 "x10/lang/Clock.x10"
                final boolean t$132396 = ((t$132395) > (((long)(0L))));
                
                //#line 114 "x10/lang/Clock.x10"
                if (t$132396) {
                    
                    //#line 114 "x10/lang/Clock.x10"
                    me.resumeLocal();
                }
                {
                    
                    //#line 115 "x10/lang/Clock.x10"
                    x10.xrx.Runtime.ensureNotInAtomic();
                    
                    //#line 115 "x10/lang/Clock.x10"
                    try {{
                        
                        //#line 115 "x10/lang/Clock.x10"
                        x10.xrx.Runtime.enterAtomic();
                        
                        //#line 115 "x10/lang/Clock.x10"
                        while (true) {
                            
                            //#line 115 "x10/lang/Clock.x10"
                            if (((this.abs) < (((int)(me.phase))))) {
                                {
                                    
                                }
                                
                                //#line 115 "x10/lang/Clock.x10"
                                break;
                            }
                            
                            //#line 115 "x10/lang/Clock.x10"
                            x10.xrx.Runtime.awaitAtomic();
                        }
                    }}finally {{
                          
                          //#line 115 "x10/lang/Clock.x10"
                          x10.xrx.Runtime.exitAtomic();
                      }}
                    }
                }}catch (java.lang.Throwable __lowerer__var__0__) {
                    
                    //#line 112 "x10/lang/Clock.x10"
                    int __lowerer__var__1__ = (x10.core.Int.$unbox(x10.xrx.Runtime.<x10.core.Int> wrapAtChecked$G(x10.rtt.Types.INT, ((java.lang.Throwable)(__lowerer__var__0__)))));
                }
            }
        
        public x10.lang.Clock out$$;
        public x10.core.GlobalRef<x10.lang.Clock> root;
        public int ph;
        public int abs;
        
        public $Closure$149(final x10.lang.Clock out$$, final x10.core.GlobalRef<x10.lang.Clock> root, final int ph, final int abs, __1$1x10$lang$Clock$2 $dummy) {
             {
                this.out$$ = out$$;
                this.root = ((x10.core.GlobalRef)(root));
                this.ph = ph;
                this.abs = abs;
            }
        }
        
        }
        
    @x10.runtime.impl.java.X10Generated
    final public static class $Closure$150 extends x10.core.Ref implements x10.core.fun.VoidFun_0_0, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<$Closure$150> $RTT = 
            x10.rtt.StaticVoidFunType.<$Closure$150> make($Closure$150.class,
                                                          new x10.rtt.Type[] {
                                                              x10.core.fun.VoidFun_0_0.$RTT
                                                          });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static x10.serialization.X10JavaSerializable $_deserialize_body(x10.lang.Clock.$Closure$150 $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            $_obj.out$$ = $deserializer.readObject();
            $_obj.ph = $deserializer.readInt();
            $_obj.root = $deserializer.readObject();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.lang.Clock.$Closure$150 $_obj = new x10.lang.Clock.$Closure$150((java.lang.System[]) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            $serializer.write(this.out$$);
            $serializer.write(this.ph);
            $serializer.write(this.root);
            
        }
        
        // constructor just for allocation
        public $Closure$150(final java.lang.System[] $dummy) {
            
        }
        
        // synthetic type for parameter mangling
        public static final class __1$1x10$lang$Clock$2 {}
        
    
        
        public void $apply() {
            
            //#line 121 "x10/lang/Clock.x10"
            try {{
                
                //#line 122 "x10/lang/Clock.x10"
                final x10.core.GlobalRef t$132400 = ((x10.core.GlobalRef)(this.root));
                
                //#line 122 "x10/lang/Clock.x10"
                final x10.lang.Clock me = (((x10.core.GlobalRef<x10.lang.Clock>)(t$132400))).$apply$G();
                
                //#line 123 "x10/lang/Clock.x10"
                me.dropLocal((int)(this.ph));
            }}catch (java.lang.Throwable __lowerer__var__0__) {
                
                //#line 121 "x10/lang/Clock.x10"
                int __lowerer__var__1__ = (x10.core.Int.$unbox(x10.xrx.Runtime.<x10.core.Int> wrapAtChecked$G(x10.rtt.Types.INT, ((java.lang.Throwable)(__lowerer__var__0__)))));
            }
        }
        
        public x10.lang.Clock out$$;
        public x10.core.GlobalRef<x10.lang.Clock> root;
        public int ph;
        
        public $Closure$150(final x10.lang.Clock out$$, final x10.core.GlobalRef<x10.lang.Clock> root, final int ph, __1$1x10$lang$Clock$2 $dummy) {
             {
                this.out$$ = out$$;
                this.root = ((x10.core.GlobalRef)(root));
                this.ph = ph;
            }
        }
        
    }
    
    @x10.runtime.impl.java.X10Generated
    final public static class $Closure$151 extends x10.core.Ref implements x10.core.fun.VoidFun_0_0, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<$Closure$151> $RTT = 
            x10.rtt.StaticVoidFunType.<$Closure$151> make($Closure$151.class,
                                                          new x10.rtt.Type[] {
                                                              x10.core.fun.VoidFun_0_0.$RTT
                                                          });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static x10.serialization.X10JavaSerializable $_deserialize_body(x10.lang.Clock.$Closure$151 $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            $_obj.out$$ = $deserializer.readObject();
            $_obj.ph = $deserializer.readInt();
            $_obj.root = $deserializer.readObject();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.lang.Clock.$Closure$151 $_obj = new x10.lang.Clock.$Closure$151((java.lang.System[]) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            $serializer.write(this.out$$);
            $serializer.write(this.ph);
            $serializer.write(this.root);
            
        }
        
        // constructor just for allocation
        public $Closure$151(final java.lang.System[] $dummy) {
            
        }
        
        // synthetic type for parameter mangling
        public static final class __1$1x10$lang$Clock$2 {}
        
    
        
        public void $apply() {
            
            //#line 128 "x10/lang/Clock.x10"
            try {{
                
                //#line 129 "x10/lang/Clock.x10"
                final x10.core.GlobalRef t$132403 = ((x10.core.GlobalRef)(this.root));
                
                //#line 129 "x10/lang/Clock.x10"
                final x10.lang.Clock me = (((x10.core.GlobalRef<x10.lang.Clock>)(t$132403))).$apply$G();
                
                //#line 130 "x10/lang/Clock.x10"
                me.dropLocal((int)(this.ph));
            }}catch (java.lang.Throwable __lowerer__var__0__) {
                
                //#line 128 "x10/lang/Clock.x10"
                int __lowerer__var__1__ = (x10.core.Int.$unbox(x10.xrx.Runtime.<x10.core.Int> wrapAtChecked$G(x10.rtt.Types.INT, ((java.lang.Throwable)(__lowerer__var__0__)))));
            }
        }
        
        public x10.lang.Clock out$$;
        public x10.core.GlobalRef<x10.lang.Clock> root;
        public int ph;
        
        public $Closure$151(final x10.lang.Clock out$$, final x10.core.GlobalRef<x10.lang.Clock> root, final int ph, __1$1x10$lang$Clock$2 $dummy) {
             {
                this.out$$ = out$$;
                this.root = ((x10.core.GlobalRef)(root));
                this.ph = ph;
            }
        }
        
    }
    
    }
    
    