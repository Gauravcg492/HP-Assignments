package x10.lang;


/**
 * Thrown to indicate that a method has been invoked at an illegal or
 * inappropriate time.
 */
;

