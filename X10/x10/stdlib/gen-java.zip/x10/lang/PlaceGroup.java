package x10.lang;


/**
 * <p> A PlaceGroup represents an ordered set of Places.
 * PlaceGroups are represented by a specialized set of classes (instead of using
 * arbitrary collection types) because it is necessary for performance/scalability
 * to have optimized representations of specific special cases.  The API is also 
 * designed to efficiently support the operations needed by Team and DistArray.
 *
 * @see Place
 * @see x10.util.Team
 */
@x10.runtime.impl.java.X10Generated
abstract public class PlaceGroup extends x10.core.Ref implements x10.lang.Iterable, x10.serialization.X10JavaSerializable
{
    public static final x10.rtt.RuntimeType<PlaceGroup> $RTT = 
        x10.rtt.NamedType.<PlaceGroup> make("x10.lang.PlaceGroup",
                                            PlaceGroup.class,
                                            new x10.rtt.Type[] {
                                                x10.rtt.ParameterizedType.make(x10.lang.Iterable.$RTT, x10.lang.Place.$RTT)
                                            });
    
    public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
    
    public x10.rtt.Type<?> $getParam(int i) { return null; }
    
    public static x10.serialization.X10JavaSerializable $_deserialize_body(x10.lang.PlaceGroup $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
        return $_obj;
    }
    
    public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
        return null;
    }
    
    public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
        
    }
    
    // constructor just for allocation
    public PlaceGroup(final java.lang.System[] $dummy) {
        
    }
    
    

    
    
    //#line 35 "x10/lang/PlaceGroup.x10"
    /**
   * The size of the PlaceGroup is equal to the value returned by numPlaces()
   */
    final public long size$O() {
        
        //#line 35 "x10/lang/PlaceGroup.x10"
        final long t$135258 = this.numPlaces$O();
        
        //#line 35 "x10/lang/PlaceGroup.x10"
        return t$135258;
    }
    
    
    //#line 40 "x10/lang/PlaceGroup.x10"
    /**
   * @return the number of Places in the PlaceGroup
   */
    abstract public long numPlaces$O();
    
    
    //#line 45 "x10/lang/PlaceGroup.x10"
    /**
   * @return true if the PlaceGroup contains place, false otherwise
   */
    public boolean contains$O(final x10.lang.Place place) {
        
        //#line 45 "x10/lang/PlaceGroup.x10"
        final long t$135259 = place.id;
        
        //#line 45 "x10/lang/PlaceGroup.x10"
        final boolean t$135260 = this.contains$O((long)(t$135259));
        
        //#line 45 "x10/lang/PlaceGroup.x10"
        return t$135260;
    }
    
    
    //#line 51 "x10/lang/PlaceGroup.x10"
    /**
   * @return true if the PlaceGroup contains the place with
   *  the given id, false otherwise
   */
    abstract public boolean contains$O(final long id);
    
    
    //#line 65 "x10/lang/PlaceGroup.x10"
    /**
   * <p>If the argument place is contained in the PlaceGroup
   * return a long between 0 and numPlaces()-1 that is the
   * ordinal number of the Place in the PlaceGroup. 
   * If the argument place is not contained in the PlaceGroup,
   * then return -1.</p>
   *
   * <p>If the PlaceGroup pg contains place, then the invariant
   * <code>pg(indexOf(place)).equals(place) == true</code> holds.</p>
   * 
   * @return the index of place
   */
    public long indexOf$O(final x10.lang.Place place) {
        
        //#line 65 "x10/lang/PlaceGroup.x10"
        final long t$135261 = place.id;
        
        //#line 65 "x10/lang/PlaceGroup.x10"
        final long t$135262 = this.indexOf$O((long)(t$135261));
        
        //#line 65 "x10/lang/PlaceGroup.x10"
        return t$135262;
    }
    
    
    //#line 80 "x10/lang/PlaceGroup.x10"
    /**
   * <p>If the Place with id equal to id is contained in the PlaceGroup
   * return a long between 0 and numPlaces()-1 that is the
   * ordinal number of said Place in the PlaceGroup. 
   * If the argument place is not contained in the PlaceGroup,
   * then return -1.</p>
   *
   * <p>If the PlaceGroup pg contains the argument Place, 
   * then the invariant
   * <code>pg(indexOf(id)).equals(Place(id)) == true</code> holds.</p>
   * 
   * @return the index of the Place encoded by id
   */
    abstract public long indexOf$O(final long id);
    
    
    //#line 88 "x10/lang/PlaceGroup.x10"
    /**
   * Return the Place with ordinal number <code>i</code> in the place group
   *
   * @param i the ordinal number of the desired place
   * @return the ith place in the place group
   */
    abstract public x10.lang.Place $apply(final long i);
    
    
    //#line 96 "x10/lang/PlaceGroup.x10"
    /**
   * Return the next Place in iteration order from
   * the argument Place, with a wrap around to the 
   * first Place in iteration order if the argument 
   * Place is the last Place in iteration order.
   */
    public x10.lang.Place next(final x10.lang.Place p) {
        
        //#line 97 "x10/lang/PlaceGroup.x10"
        final long idx = this.indexOf$O(((x10.lang.Place)(p)));
        
        //#line 98 "x10/lang/PlaceGroup.x10"
        final boolean t$135264 = ((long) idx) == ((long) -1L);
        
        //#line 98 "x10/lang/PlaceGroup.x10"
        if (t$135264) {
            
            //#line 98 "x10/lang/PlaceGroup.x10"
            final x10.lang.Place t$135263 = ((x10.lang.Place)(x10.lang.Place.get$INVALID_PLACE()));
            
            //#line 98 "x10/lang/PlaceGroup.x10"
            return t$135263;
        }
        
        //#line 99 "x10/lang/PlaceGroup.x10"
        final long t$135265 = ((idx) + (((long)(1L))));
        
        //#line 99 "x10/lang/PlaceGroup.x10"
        final long t$135266 = this.numPlaces$O();
        
        //#line 99 "x10/lang/PlaceGroup.x10"
        final boolean t$135267 = ((long) t$135265) == ((long) t$135266);
        
        //#line 99 "x10/lang/PlaceGroup.x10"
        long t$135268 =  0;
        
        //#line 99 "x10/lang/PlaceGroup.x10"
        if (t$135267) {
            
            //#line 99 "x10/lang/PlaceGroup.x10"
            t$135268 = 0L;
        } else {
            
            //#line 99 "x10/lang/PlaceGroup.x10"
            t$135268 = ((idx) + (((long)(1L))));
        }
        
        //#line 100 "x10/lang/PlaceGroup.x10"
        final x10.lang.Place t$135269 = this.$apply((long)(t$135268));
        
        //#line 100 "x10/lang/PlaceGroup.x10"
        return t$135269;
    }
    
    
    //#line 109 "x10/lang/PlaceGroup.x10"
    /**
   * Return the previous Place in iteration order from
   * the argument Place, with a wrap around to the 
   * last Place in iteration order if the argument 
   * Place is the first Place in iteration order.
   */
    public x10.lang.Place prev(final x10.lang.Place p) {
        
        //#line 110 "x10/lang/PlaceGroup.x10"
        final long idx = this.indexOf$O(((x10.lang.Place)(p)));
        
        //#line 111 "x10/lang/PlaceGroup.x10"
        final boolean t$135271 = ((long) idx) == ((long) -1L);
        
        //#line 111 "x10/lang/PlaceGroup.x10"
        if (t$135271) {
            
            //#line 111 "x10/lang/PlaceGroup.x10"
            final x10.lang.Place t$135270 = ((x10.lang.Place)(x10.lang.Place.get$INVALID_PLACE()));
            
            //#line 111 "x10/lang/PlaceGroup.x10"
            return t$135270;
        }
        
        //#line 112 "x10/lang/PlaceGroup.x10"
        final boolean t$135273 = ((long) idx) == ((long) 0L);
        
        //#line 112 "x10/lang/PlaceGroup.x10"
        long t$135274 =  0;
        
        //#line 112 "x10/lang/PlaceGroup.x10"
        if (t$135273) {
            
            //#line 112 "x10/lang/PlaceGroup.x10"
            final long t$135272 = this.numPlaces$O();
            
            //#line 112 "x10/lang/PlaceGroup.x10"
            t$135274 = ((t$135272) - (((long)(1L))));
        } else {
            
            //#line 112 "x10/lang/PlaceGroup.x10"
            t$135274 = ((idx) - (((long)(1L))));
        }
        
        //#line 113 "x10/lang/PlaceGroup.x10"
        final x10.lang.Place t$135275 = this.$apply((long)(t$135274));
        
        //#line 113 "x10/lang/PlaceGroup.x10"
        return t$135275;
    }
    
    
    //#line 119 "x10/lang/PlaceGroup.x10"
    /**
   * Two place groups are equal iff they contain the same places
   */
    public boolean equals(final java.lang.Object thatObj) {
        
        //#line 120 "x10/lang/PlaceGroup.x10"
        final boolean t$135276 = x10.rtt.Equality.equalsequals((this),(thatObj));
        
        //#line 120 "x10/lang/PlaceGroup.x10"
        if (t$135276) {
            
            //#line 120 "x10/lang/PlaceGroup.x10"
            return true;
        }
        
        //#line 121 "x10/lang/PlaceGroup.x10"
        final boolean t$135277 = x10.lang.PlaceGroup.$RTT.isInstance(thatObj);
        
        //#line 121 "x10/lang/PlaceGroup.x10"
        final boolean t$135278 = !(t$135277);
        
        //#line 121 "x10/lang/PlaceGroup.x10"
        if (t$135278) {
            
            //#line 121 "x10/lang/PlaceGroup.x10"
            return false;
        }
        
        //#line 122 "x10/lang/PlaceGroup.x10"
        final x10.lang.PlaceGroup that = ((x10.lang.PlaceGroup)(x10.rtt.Types.<x10.lang.PlaceGroup> cast(thatObj,x10.lang.PlaceGroup.$RTT)));
        
        //#line 123 "x10/lang/PlaceGroup.x10"
        final long t$135279 = this.numPlaces$O();
        
        //#line 123 "x10/lang/PlaceGroup.x10"
        final long t$135280 = that.numPlaces$O();
        
        //#line 123 "x10/lang/PlaceGroup.x10"
        final boolean t$135281 = ((long) t$135279) != ((long) t$135280);
        
        //#line 123 "x10/lang/PlaceGroup.x10"
        if (t$135281) {
            
            //#line 123 "x10/lang/PlaceGroup.x10"
            return false;
        }
        
        //#line 124 "x10/lang/PlaceGroup.x10"
        long i$135377 = 0L;
        
        //#line 124 "x10/lang/PlaceGroup.x10"
        for (;
             true;
             ) {
            
            //#line 124 "x10/lang/PlaceGroup.x10"
            final long t$135379 = this.numPlaces$O();
            
            //#line 124 "x10/lang/PlaceGroup.x10"
            final boolean t$135380 = ((i$135377) < (((long)(t$135379))));
            
            //#line 124 "x10/lang/PlaceGroup.x10"
            if (!(t$135380)) {
                
                //#line 124 "x10/lang/PlaceGroup.x10"
                break;
            }
            
            //#line 125 "x10/lang/PlaceGroup.x10"
            final x10.lang.Place this$135368 = this.$apply((long)(i$135377));
            
            //#line 125 "x10/lang/PlaceGroup.x10"
            final x10.lang.Place p$135370 = ((x10.lang.Place)(that.$apply((long)(i$135377))));
            
            //#line 139 . "x10/lang/Place.x10"
            final long t$135371 = p$135370.id;
            
            //#line 139 . "x10/lang/Place.x10"
            final long t$135372 = this$135368.id;
            
            //#line 139 . "x10/lang/Place.x10"
            final boolean t$135373 = ((long) t$135371) == ((long) t$135372);
            
            //#line 125 "x10/lang/PlaceGroup.x10"
            final boolean t$135374 = !(t$135373);
            
            //#line 125 "x10/lang/PlaceGroup.x10"
            if (t$135374) {
                
                //#line 125 "x10/lang/PlaceGroup.x10"
                return false;
            }
            
            //#line 124 "x10/lang/PlaceGroup.x10"
            final long t$135376 = ((i$135377) + (((long)(1L))));
            
            //#line 124 "x10/lang/PlaceGroup.x10"
            i$135377 = t$135376;
        }
        
        //#line 127 "x10/lang/PlaceGroup.x10"
        return true;
    }
    
    
    //#line 135 "x10/lang/PlaceGroup.x10"
    /**
   * Execute the closure cl at every place in the PlaceGroup.
   * Note: cl must not have any exposed at/async constructs
   *    (any async/at must be nested inside of a finish).
   */
    public void broadcastFlat(final x10.core.fun.VoidFun_0_0 cl) {
        
        //#line 136 "x10/lang/PlaceGroup.x10"
        final x10.io.Serializer ser = ((x10.io.Serializer)(new x10.io.Serializer()));
        
        //#line 137 "x10/lang/PlaceGroup.x10"
        ser.writeAny(((java.lang.Object)(cl)));
        
        //#line 138 "x10/lang/PlaceGroup.x10"
        final x10.lang.PlaceGroup this$135241 = ((x10.lang.PlaceGroup)(this));
        
        //#line 35 . "x10/lang/PlaceGroup.x10"
        final long t$135294 = this$135241.numPlaces$O();
        
        //#line 138 "x10/lang/PlaceGroup.x10"
        final long t$135295 = ((t$135294) - (((long)(1L))));
        
        //#line 138 "x10/lang/PlaceGroup.x10"
        ser.addDeserializeCount((long)(t$135295));
        
        //#line 139 "x10/lang/PlaceGroup.x10"
        final x10.core.Rail message = ser.toRail();
        {
            
            //#line 140 "x10/lang/PlaceGroup.x10"
            x10.xrx.Runtime.ensureNotInAtomic();
            
            //#line 140 "x10/lang/PlaceGroup.x10"
            final x10.xrx.FinishState fs$135440 = x10.xrx.Runtime.startFinish((int)(x10.compiler.Pragma.FINISH_SPMD));
            
            //#line 140 "x10/lang/PlaceGroup.x10"
            try {{
                {
                    
                    //#line 140 "x10/lang/PlaceGroup.x10"
                    final x10.lang.Iterator p$105735 = this.iterator();
                    
                    //#line 140 "x10/lang/PlaceGroup.x10"
                    for (;
                         true;
                         ) {
                        
                        //#line 140 "x10/lang/PlaceGroup.x10"
                        final boolean t$135298 = ((x10.lang.Iterator<x10.lang.Place>)p$105735).hasNext$O();
                        
                        //#line 140 "x10/lang/PlaceGroup.x10"
                        if (!(t$135298)) {
                            
                            //#line 140 "x10/lang/PlaceGroup.x10"
                            break;
                        }
                        
                        //#line 140 "x10/lang/PlaceGroup.x10"
                        final x10.lang.Place p$135381 = ((x10.lang.Place)(((x10.lang.Iterator<x10.lang.Place>)p$105735).next$G()));
                        
                        //#line 141 "x10/lang/PlaceGroup.x10"
                        x10.xrx.Runtime.runAsync(((x10.lang.Place)(p$135381)), ((x10.core.fun.VoidFun_0_0)(new x10.lang.PlaceGroup.$Closure$169(message, (x10.lang.PlaceGroup.$Closure$169.__0$1x10$lang$Byte$2) null))), ((x10.xrx.Runtime.Profile)(null)));
                    }
                }
            }}catch (java.lang.Throwable ct$135437) {
                
                //#line 140 "x10/lang/PlaceGroup.x10"
                x10.xrx.Runtime.pushException(((java.lang.Throwable)(ct$135437)));
                
                //#line 140 "x10/lang/PlaceGroup.x10"
                throw new java.lang.RuntimeException();
            }finally {{
                 
                 //#line 140 "x10/lang/PlaceGroup.x10"
                 x10.xrx.Runtime.stopFinish(((x10.xrx.FinishState)(fs$135440)));
             }}
            }
        }
    
    
    //#line 154 "x10/lang/PlaceGroup.x10"
    /**
   * Execute the closure cl at every live place in the PlaceGroup.
   * Note: cl must not have any exposed at/async constructs
   *    (any async/at must be nested inside of a finish).
   */
    public void broadcastFlat__1$1x10$lang$Place$3x10$lang$Boolean$2(final x10.core.fun.VoidFun_0_0 cl, final x10.core.fun.Fun_0_1 ignoreIfDead) {
        
        //#line 155 "x10/lang/PlaceGroup.x10"
        final x10.io.Serializer ser = ((x10.io.Serializer)(new x10.io.Serializer()));
        
        //#line 156 "x10/lang/PlaceGroup.x10"
        ser.writeAny(((java.lang.Object)(cl)));
        
        //#line 157 "x10/lang/PlaceGroup.x10"
        final x10.lang.PlaceGroup this$135243 = ((x10.lang.PlaceGroup)(this));
        
        //#line 35 . "x10/lang/PlaceGroup.x10"
        final long t$135299 = this$135243.numPlaces$O();
        
        //#line 157 "x10/lang/PlaceGroup.x10"
        final long t$135300 = ((t$135299) - (((long)(1L))));
        
        //#line 157 "x10/lang/PlaceGroup.x10"
        ser.addDeserializeCount((long)(t$135300));
        
        //#line 158 "x10/lang/PlaceGroup.x10"
        final x10.core.Rail message = ser.toRail();
        
        //#line 159 "x10/lang/PlaceGroup.x10"
        long numSkipped = 0L;
        {
            
            //#line 160 "x10/lang/PlaceGroup.x10"
            x10.xrx.Runtime.ensureNotInAtomic();
            
            //#line 160 "x10/lang/PlaceGroup.x10"
            final x10.xrx.FinishState fs$135449 = x10.xrx.Runtime.startFinish((int)(x10.compiler.Pragma.FINISH_SPMD));
            
            //#line 160 "x10/lang/PlaceGroup.x10"
            try {{
                {
                    
                    //#line 160 "x10/lang/PlaceGroup.x10"
                    final x10.lang.Iterator p$105737 = this.iterator();
                    
                    //#line 160 "x10/lang/PlaceGroup.x10"
                    for (;
                         true;
                         ) {
                        
                        //#line 160 "x10/lang/PlaceGroup.x10"
                        final boolean t$135310 = ((x10.lang.Iterator<x10.lang.Place>)p$105737).hasNext$O();
                        
                        //#line 160 "x10/lang/PlaceGroup.x10"
                        if (!(t$135310)) {
                            
                            //#line 160 "x10/lang/PlaceGroup.x10"
                            break;
                        }
                        
                        //#line 160 "x10/lang/PlaceGroup.x10"
                        final x10.lang.Place p$135385 = ((x10.lang.Place)(((x10.lang.Iterator<x10.lang.Place>)p$105737).next$G()));
                        
                        //#line 128 . "x10/lang/Place.x10"
                        final long t$135386 = p$135385.id;
                        
                        //#line 128 . "x10/lang/Place.x10"
                        final boolean t$135387 = x10.x10rt.X10RT.isPlaceDead((int)((long)(t$135386)));
                        
                        //#line 161 "x10/lang/PlaceGroup.x10"
                        boolean t$135388 = !(t$135387);
                        
                        //#line 161 "x10/lang/PlaceGroup.x10"
                        if (!(t$135388)) {
                            
                            //#line 161 "x10/lang/PlaceGroup.x10"
                            final boolean t$135389 = x10.core.Boolean.$unbox(((x10.core.fun.Fun_0_1<x10.lang.Place,x10.core.Boolean>)ignoreIfDead).$apply(p$135385, x10.lang.Place.$RTT));
                            
                            //#line 161 "x10/lang/PlaceGroup.x10"
                            t$135388 = !(t$135389);
                        }
                        
                        //#line 161 "x10/lang/PlaceGroup.x10"
                        if (t$135388) {
                            
                            //#line 162 "x10/lang/PlaceGroup.x10"
                            x10.xrx.Runtime.runAsync(((x10.lang.Place)(p$135385)), ((x10.core.fun.VoidFun_0_0)(new x10.lang.PlaceGroup.$Closure$170(message, (x10.lang.PlaceGroup.$Closure$170.__0$1x10$lang$Byte$2) null))), ((x10.xrx.Runtime.Profile)(null)));
                        } else {
                            
                            //#line 168 "x10/lang/PlaceGroup.x10"
                            final long t$135395 = ((numSkipped) + (((long)(1L))));
                            
                            //#line 168 "x10/lang/PlaceGroup.x10"
                            numSkipped = t$135395;
                        }
                    }
                }
            }}catch (java.lang.Throwable ct$135446) {
                
                //#line 160 "x10/lang/PlaceGroup.x10"
                x10.xrx.Runtime.pushException(((java.lang.Throwable)(ct$135446)));
                
                //#line 160 "x10/lang/PlaceGroup.x10"
                throw new java.lang.RuntimeException();
            }finally {{
                 
                 //#line 160 "x10/lang/PlaceGroup.x10"
                 x10.xrx.Runtime.stopFinish(((x10.xrx.FinishState)(fs$135449)));
             }}
            }
        
        //#line 171 "x10/lang/PlaceGroup.x10"
        final boolean t$135318 = ((numSkipped) > (((long)(0L))));
        
        //#line 171 "x10/lang/PlaceGroup.x10"
        if (t$135318) {
            
            //#line 172 "x10/lang/PlaceGroup.x10"
            long i$135401 = 1L;
            
            //#line 172 "x10/lang/PlaceGroup.x10"
            for (;
                 true;
                 ) {
                
                //#line 172 "x10/lang/PlaceGroup.x10"
                final boolean t$135403 = ((i$135401) <= (((long)(numSkipped))));
                
                //#line 172 "x10/lang/PlaceGroup.x10"
                if (!(t$135403)) {
                    
                    //#line 172 "x10/lang/PlaceGroup.x10"
                    break;
                }
                
                //#line 180 "x10/lang/PlaceGroup.x10"
                final x10.io.Deserializer dser$135396 = ((x10.io.Deserializer)(new x10.io.Deserializer(((x10.core.Rail)(message)), (x10.io.Deserializer.__0$1x10$lang$Byte$2) null)));
                
                //#line 181 "x10/lang/PlaceGroup.x10"
                final java.lang.Object t$135397 = dser$135396.readAny();
                
                //#line 181 "x10/lang/PlaceGroup.x10"
                x10.runtime.impl.java.EvalUtils.eval(x10.rtt.Types.<x10.core.fun.VoidFun_0_0> cast(t$135397,x10.core.fun.VoidFun_0_0.$RTT));
                
                //#line 172 "x10/lang/PlaceGroup.x10"
                final long t$135400 = ((i$135401) + (((long)(1L))));
                
                //#line 172 "x10/lang/PlaceGroup.x10"
                i$135401 = t$135400;
            }
        }
        }
    
    
    //#line 190 "x10/lang/PlaceGroup.x10"
    /** 
     * Return a new PlaceGroup which contains all places from this group
     * that are not dead places.
     */
    public x10.lang.PlaceGroup filterDeadPlaces() {
        
        //#line 191 "x10/lang/PlaceGroup.x10"
        final x10.util.ArrayList livePlaces = ((x10.util.ArrayList)(new x10.util.ArrayList<x10.lang.Place>((java.lang.System[]) null, x10.lang.Place.$RTT)));
        
        //#line 191 "x10/lang/PlaceGroup.x10"
        livePlaces.x10$util$ArrayList$$init$S();
        
        //#line 193 "x10/lang/PlaceGroup.x10"
        final x10.lang.Iterator pl$135408 = this.iterator();
        
        //#line 193 "x10/lang/PlaceGroup.x10"
        for (;
             true;
             ) {
            
            //#line 193 "x10/lang/PlaceGroup.x10"
            final boolean t$135409 = ((x10.lang.Iterator<x10.lang.Place>)pl$135408).hasNext$O();
            
            //#line 193 "x10/lang/PlaceGroup.x10"
            if (!(t$135409)) {
                
                //#line 193 "x10/lang/PlaceGroup.x10"
                break;
            }
            
            //#line 193 "x10/lang/PlaceGroup.x10"
            final x10.lang.Place pl$135404 = ((x10.lang.Place)(((x10.lang.Iterator<x10.lang.Place>)pl$135408).next$G()));
            
            //#line 128 . "x10/lang/Place.x10"
            final long t$135405 = pl$135404.id;
            
            //#line 128 . "x10/lang/Place.x10"
            final boolean t$135406 = x10.x10rt.X10RT.isPlaceDead((int)((long)(t$135405)));
            
            //#line 194 "x10/lang/PlaceGroup.x10"
            final boolean t$135407 = !(t$135406);
            
            //#line 194 "x10/lang/PlaceGroup.x10"
            if (t$135407) {
                
                //#line 194 "x10/lang/PlaceGroup.x10"
                ((x10.util.ArrayList<x10.lang.Place>)livePlaces).add__0x10$util$ArrayList$$T$O(((x10.lang.Place)(pl$135404)));
            }
        }
        
        //#line 197 "x10/lang/PlaceGroup.x10"
        final x10.lang.SparsePlaceGroup alloc$105727 = ((x10.lang.SparsePlaceGroup)(new x10.lang.SparsePlaceGroup((java.lang.System[]) null)));
        
        //#line 197 "x10/lang/PlaceGroup.x10"
        final x10.core.Rail t$135410 = ((x10.core.Rail<x10.lang.Place>)
                                         ((x10.util.ArrayList<x10.lang.Place>)livePlaces).toRail());
        
        //#line 197 "x10/lang/PlaceGroup.x10"
        alloc$105727.x10$lang$SparsePlaceGroup$$init$S(t$135410, (x10.lang.SparsePlaceGroup.__0$1x10$lang$Place$2) null);
        
        //#line 197 "x10/lang/PlaceGroup.x10"
        return alloc$105727;
    }
    
    
    //#line 200 "x10/lang/PlaceGroup.x10"
    @x10.runtime.impl.java.X10Generated
    public static class SimplePlaceGroup extends x10.lang.PlaceGroup implements x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<SimplePlaceGroup> $RTT = 
            x10.rtt.NamedType.<SimplePlaceGroup> make("x10.lang.PlaceGroup.SimplePlaceGroup",
                                                      SimplePlaceGroup.class,
                                                      new x10.rtt.Type[] {
                                                          x10.lang.PlaceGroup.$RTT
                                                      });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static x10.serialization.X10JavaSerializable $_deserialize_body(x10.lang.PlaceGroup.SimplePlaceGroup $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.lang.PlaceGroup.$_deserialize_body($_obj, $deserializer);
            $_obj.numPlaces = $deserializer.readLong();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.lang.PlaceGroup.SimplePlaceGroup $_obj = new x10.lang.PlaceGroup.SimplePlaceGroup((java.lang.System[]) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            super.$_serialize($serializer);
            $serializer.write(this.numPlaces);
            
        }
        
        // constructor just for allocation
        public SimplePlaceGroup(final java.lang.System[] $dummy) {
            super($dummy);
            
        }
        
        
    
        
        //#line 201 "x10/lang/PlaceGroup.x10"
        public long numPlaces;
        
        
        //#line 202 "x10/lang/PlaceGroup.x10"
        // creation method for java code (1-phase java constructor)
        public SimplePlaceGroup(final long numPlaces) {
            this((java.lang.System[]) null);
            x10$lang$PlaceGroup$SimplePlaceGroup$$init$S(numPlaces);
        }
        
        // constructor for non-virtual call
        final public x10.lang.PlaceGroup.SimplePlaceGroup x10$lang$PlaceGroup$SimplePlaceGroup$$init$S(final long numPlaces) {
             {
                
                //#line 202 "x10/lang/PlaceGroup.x10"
                
                
                //#line 202 "x10/lang/PlaceGroup.x10"
                this.numPlaces = numPlaces;
            }
            return this;
        }
        
        
        
        //#line 203 "x10/lang/PlaceGroup.x10"
        public x10.lang.Place $apply(final long i) {
            
            //#line 203 "x10/lang/PlaceGroup.x10"
            final x10.lang.Place alloc$105728 = ((x10.lang.Place)(new x10.lang.Place((java.lang.System[]) null)));
            
            //#line 203 "x10/lang/PlaceGroup.x10"
            alloc$105728.x10$lang$Place$$init$S(((long)(i)));
            
            //#line 203 "x10/lang/PlaceGroup.x10"
            return alloc$105728;
        }
        
        
        //#line 204 "x10/lang/PlaceGroup.x10"
        public long numPlaces$O() {
            
            //#line 204 "x10/lang/PlaceGroup.x10"
            final long t$135325 = this.numPlaces;
            
            //#line 204 "x10/lang/PlaceGroup.x10"
            return t$135325;
        }
        
        
        //#line 205 "x10/lang/PlaceGroup.x10"
        public boolean contains$O(final long id) {
            
            //#line 205 "x10/lang/PlaceGroup.x10"
            boolean t$135327 = ((id) >= (((long)(0L))));
            
            //#line 205 "x10/lang/PlaceGroup.x10"
            if (t$135327) {
                
                //#line 205 "x10/lang/PlaceGroup.x10"
                final long t$135326 = this.numPlaces;
                
                //#line 205 "x10/lang/PlaceGroup.x10"
                t$135327 = ((id) < (((long)(t$135326))));
            }
            
            //#line 205 "x10/lang/PlaceGroup.x10"
            return t$135327;
        }
        
        
        //#line 206 "x10/lang/PlaceGroup.x10"
        public long indexOf$O(final long id) {
            
            //#line 206 "x10/lang/PlaceGroup.x10"
            final boolean t$135329 = this.contains$O((long)(id));
            
            //#line 206 "x10/lang/PlaceGroup.x10"
            long t$135330 =  0;
            
            //#line 206 "x10/lang/PlaceGroup.x10"
            if (t$135329) {
                
                //#line 206 "x10/lang/PlaceGroup.x10"
                t$135330 = id;
            } else {
                
                //#line 206 "x10/lang/PlaceGroup.x10"
                t$135330 = -1L;
            }
            
            //#line 206 "x10/lang/PlaceGroup.x10"
            return t$135330;
        }
        
        
        //#line 207 "x10/lang/PlaceGroup.x10"
        public x10.lang.Iterator iterator() {
            
            //#line 207 "x10/lang/PlaceGroup.x10"
            final x10.lang.PlaceGroup.SimplePlaceGroup.Anonymous$6956 alloc$105729 = ((x10.lang.PlaceGroup.SimplePlaceGroup.Anonymous$6956)(new x10.lang.PlaceGroup.SimplePlaceGroup.Anonymous$6956((java.lang.System[]) null)));
            
            //#line 207 "x10/lang/PlaceGroup.x10"
            final x10.lang.PlaceGroup.SimplePlaceGroup out$135252 = ((x10.lang.PlaceGroup.SimplePlaceGroup)(this));
            
            //#line 200 . "x10/lang/PlaceGroup.x10"
            alloc$105729.out$ = out$135252;
            
            //#line 207 "x10/lang/PlaceGroup.x10"
            return alloc$105729;
        }
        
        
        //#line 212 "x10/lang/PlaceGroup.x10"
        public boolean equals(final java.lang.Object thatObj) {
            
            //#line 213 "x10/lang/PlaceGroup.x10"
            final boolean t$135337 = x10.lang.PlaceGroup.SimplePlaceGroup.$RTT.isInstance(thatObj);
            
            //#line 213 "x10/lang/PlaceGroup.x10"
            if (t$135337) {
                
                //#line 214 "x10/lang/PlaceGroup.x10"
                final long t$135333 = this.numPlaces$O();
                
                //#line 214 "x10/lang/PlaceGroup.x10"
                final x10.lang.PlaceGroup.SimplePlaceGroup t$135332 = ((x10.lang.PlaceGroup.SimplePlaceGroup)(x10.rtt.Types.<x10.lang.PlaceGroup.SimplePlaceGroup> cast(thatObj,x10.lang.PlaceGroup.SimplePlaceGroup.$RTT)));
                
                //#line 214 "x10/lang/PlaceGroup.x10"
                final long t$135334 = t$135332.numPlaces$O();
                
                //#line 214 "x10/lang/PlaceGroup.x10"
                final boolean t$135335 = ((long) t$135333) == ((long) t$135334);
                
                //#line 214 "x10/lang/PlaceGroup.x10"
                return t$135335;
            } else {
                
                //#line 216 "x10/lang/PlaceGroup.x10"
                final boolean t$135336 = super.equals(((java.lang.Object)(thatObj)));
                
                //#line 216 "x10/lang/PlaceGroup.x10"
                return t$135336;
            }
        }
        
        
        //#line 219 "x10/lang/PlaceGroup.x10"
        public int hashCode() {
            
            //#line 219 "x10/lang/PlaceGroup.x10"
            final long t$135338 = this.numPlaces;
            
            //#line 219 "x10/lang/PlaceGroup.x10"
            final int t$135339 = x10.rtt.Types.hashCode(t$135338);
            
            //#line 219 "x10/lang/PlaceGroup.x10"
            return t$135339;
        }
        
        
        //#line 220 "x10/lang/PlaceGroup.x10"
        public void broadcastFlat(final x10.core.fun.VoidFun_0_0 cl) {
            
            //#line 221 "x10/lang/PlaceGroup.x10"
            final long t$135340 = this.numPlaces$O();
            
            //#line 221 "x10/lang/PlaceGroup.x10"
            final boolean t$135358 = ((t$135340) >= (((long)(1024L))));
            
            //#line 221 "x10/lang/PlaceGroup.x10"
            if (t$135358) {
                
                //#line 222 "x10/lang/PlaceGroup.x10"
                final x10.io.Serializer ser = ((x10.io.Serializer)(new x10.io.Serializer()));
                
                //#line 223 "x10/lang/PlaceGroup.x10"
                ser.writeAny(((java.lang.Object)(cl)));
                
                //#line 224 "x10/lang/PlaceGroup.x10"
                final x10.lang.PlaceGroup this$135254 = ((x10.lang.PlaceGroup)
                                                          this);
                
                //#line 35 . "x10/lang/PlaceGroup.x10"
                final long t$135341 = this$135254.numPlaces$O();
                
                //#line 224 "x10/lang/PlaceGroup.x10"
                final long t$135342 = ((t$135341) - (((long)(1L))));
                
                //#line 224 "x10/lang/PlaceGroup.x10"
                ser.addDeserializeCount((long)(t$135342));
                
                //#line 225 "x10/lang/PlaceGroup.x10"
                final x10.core.Rail message = ser.toRail();
                {
                    
                    //#line 226 "x10/lang/PlaceGroup.x10"
                    x10.xrx.Runtime.ensureNotInAtomic();
                    
                    //#line 226 "x10/lang/PlaceGroup.x10"
                    final x10.xrx.FinishState fs$135467 = x10.xrx.Runtime.startFinish((int)(x10.compiler.Pragma.FINISH_SPMD));
                    
                    //#line 226 "x10/lang/PlaceGroup.x10"
                    try {{
                        {
                            
                            //#line 226 "x10/lang/PlaceGroup.x10"
                            final long t$135344 = this.numPlaces$O();
                            
                            //#line 226 "x10/lang/PlaceGroup.x10"
                            long i = ((t$135344) - (((long)(1L))));
                            
                            //#line 226 "x10/lang/PlaceGroup.x10"
                            for (;
                                 true;
                                 ) {
                                
                                //#line 226 "x10/lang/PlaceGroup.x10"
                                final boolean t$135357 = ((i) >= (((long)(0L))));
                                
                                //#line 226 "x10/lang/PlaceGroup.x10"
                                if (!(t$135357)) {
                                    
                                    //#line 226 "x10/lang/PlaceGroup.x10"
                                    break;
                                }
                                
                                //#line 227 "x10/lang/PlaceGroup.x10"
                                final x10.lang.Place alloc$135420 = ((x10.lang.Place)(new x10.lang.Place((java.lang.System[]) null)));
                                
                                //#line 227 "x10/lang/PlaceGroup.x10"
                                alloc$135420.x10$lang$Place$$init$S(i);
                                
                                //#line 227 "x10/lang/PlaceGroup.x10"
                                x10.xrx.Runtime.runAsync(((x10.lang.Place)(alloc$135420)), ((x10.core.fun.VoidFun_0_0)(new x10.lang.PlaceGroup.SimplePlaceGroup.$Closure$168(message, (x10.lang.PlaceGroup.SimplePlaceGroup.$Closure$168.__0$1x10$lang$Byte$2) null))), ((x10.xrx.Runtime.Profile)(null)));
                                
                                //#line 226 "x10/lang/PlaceGroup.x10"
                                final long t$135428 = ((i) - (((long)(32L))));
                                
                                //#line 226 "x10/lang/PlaceGroup.x10"
                                i = t$135428;
                            }
                        }
                    }}catch (java.lang.Throwable ct$135464) {
                        
                        //#line 226 "x10/lang/PlaceGroup.x10"
                        x10.xrx.Runtime.pushException(((java.lang.Throwable)(ct$135464)));
                        
                        //#line 226 "x10/lang/PlaceGroup.x10"
                        throw new java.lang.RuntimeException();
                    }finally {{
                         
                         //#line 226 "x10/lang/PlaceGroup.x10"
                         x10.xrx.Runtime.stopFinish(((x10.xrx.FinishState)(fs$135467)));
                     }}
                    }
                } else {
                    
                    //#line 240 "x10/lang/PlaceGroup.x10"
                    super.broadcastFlat(((x10.core.fun.VoidFun_0_0)(cl)));
                }
            }
        
        
        //#line 200 "x10/lang/PlaceGroup.x10"
        final public x10.lang.PlaceGroup.SimplePlaceGroup x10$lang$PlaceGroup$SimplePlaceGroup$$this$x10$lang$PlaceGroup$SimplePlaceGroup() {
            
            //#line 200 "x10/lang/PlaceGroup.x10"
            return x10.lang.PlaceGroup.SimplePlaceGroup.this;
        }
        
        
        //#line 200 "x10/lang/PlaceGroup.x10"
        final public void __fieldInitializers_x10_lang_PlaceGroup_SimplePlaceGroup() {
            
        }
        
        
        //#line 207 "x10/lang/PlaceGroup.x10"
        @x10.runtime.impl.java.X10Generated
        final public static class Anonymous$6956 extends x10.core.Ref implements x10.lang.Iterator, x10.serialization.X10JavaSerializable
        {
            public static final x10.rtt.RuntimeType<Anonymous$6956> $RTT = 
                x10.rtt.NamedType.<Anonymous$6956> make("x10.lang.PlaceGroup.SimplePlaceGroup.Anonymous$6956",
                                                        Anonymous$6956.class,
                                                        new x10.rtt.Type[] {
                                                            x10.rtt.ParameterizedType.make(x10.lang.Iterator.$RTT, x10.lang.Place.$RTT)
                                                        });
            
            public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
            
            public x10.rtt.Type<?> $getParam(int i) { return null; }
            
            private Object writeReplace() throws java.io.ObjectStreamException {
                return new x10.serialization.SerializationProxy(this);
            }
            
            public static x10.serialization.X10JavaSerializable $_deserialize_body(x10.lang.PlaceGroup.SimplePlaceGroup.Anonymous$6956 $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
                $_obj.i = $deserializer.readLong();
                $_obj.out$ = $deserializer.readObject();
                return $_obj;
            }
            
            public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
                x10.lang.PlaceGroup.SimplePlaceGroup.Anonymous$6956 $_obj = new x10.lang.PlaceGroup.SimplePlaceGroup.Anonymous$6956((java.lang.System[]) null);
                $deserializer.record_reference($_obj);
                return $_deserialize_body($_obj, $deserializer);
            }
            
            public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
                $serializer.write(this.i);
                $serializer.write(this.out$);
                
            }
            
            // constructor just for allocation
            public Anonymous$6956(final java.lang.System[] $dummy) {
                
            }
            
            // bridge for method abstract public x10.lang.Iterator[T].next(){}:T
            public x10.lang.Place next$G() {
                return next();
            }
            
            
        
            
            //#line 200 "x10/lang/PlaceGroup.x10"
            public x10.lang.PlaceGroup.SimplePlaceGroup out$;
            
            //#line 208 "x10/lang/PlaceGroup.x10"
            public long i = 0L;
            
            
            //#line 209 "x10/lang/PlaceGroup.x10"
            public boolean hasNext$O() {
                
                //#line 209 "x10/lang/PlaceGroup.x10"
                final long t$135360 = this.i;
                
                //#line 209 "x10/lang/PlaceGroup.x10"
                final x10.lang.PlaceGroup.SimplePlaceGroup t$135359 = this.out$;
                
                //#line 209 "x10/lang/PlaceGroup.x10"
                final long t$135361 = t$135359.numPlaces;
                
                //#line 209 "x10/lang/PlaceGroup.x10"
                final boolean t$135362 = ((t$135360) < (((long)(t$135361))));
                
                //#line 209 "x10/lang/PlaceGroup.x10"
                return t$135362;
            }
            
            
            //#line 210 "x10/lang/PlaceGroup.x10"
            public x10.lang.Place next() {
                
                //#line 210 "x10/lang/PlaceGroup.x10"
                final x10.lang.Place alloc$105732 = ((x10.lang.Place)(new x10.lang.Place((java.lang.System[]) null)));
                
                //#line 210 "x10/lang/PlaceGroup.x10"
                final long t$135429 = this.i;
                
                //#line 210 "x10/lang/PlaceGroup.x10"
                final long t$135430 = ((t$135429) + (((long)(1L))));
                
                //#line 210 "x10/lang/PlaceGroup.x10"
                final long t$135431 = this.i = t$135430;
                
                //#line 210 "x10/lang/PlaceGroup.x10"
                final long t$135432 = ((t$135431) - (((long)(1L))));
                
                //#line 210 "x10/lang/PlaceGroup.x10"
                alloc$105732.x10$lang$Place$$init$S(t$135432);
                
                //#line 210 "x10/lang/PlaceGroup.x10"
                return alloc$105732;
            }
            
            
            //#line 207 "x10/lang/PlaceGroup.x10"
            // creation method for java code (1-phase java constructor)
            public Anonymous$6956(final x10.lang.PlaceGroup.SimplePlaceGroup out$) {
                this((java.lang.System[]) null);
                x10$lang$PlaceGroup$SimplePlaceGroup$Anonymous$6956$$init$S(out$);
            }
            
            // constructor for non-virtual call
            final public x10.lang.PlaceGroup.SimplePlaceGroup.Anonymous$6956 x10$lang$PlaceGroup$SimplePlaceGroup$Anonymous$6956$$init$S(final x10.lang.PlaceGroup.SimplePlaceGroup out$) {
                 {
                    
                    //#line 200 "x10/lang/PlaceGroup.x10"
                    this.out$ = out$;
                }
                return this;
            }
            
        }
        
        @x10.runtime.impl.java.X10Generated
        final public static class $Closure$167 extends x10.core.Ref implements x10.core.fun.VoidFun_0_0, x10.serialization.X10JavaSerializable
        {
            public static final x10.rtt.RuntimeType<$Closure$167> $RTT = 
                x10.rtt.StaticVoidFunType.<$Closure$167> make($Closure$167.class,
                                                              new x10.rtt.Type[] {
                                                                  x10.core.fun.VoidFun_0_0.$RTT
                                                              });
            
            public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
            
            public x10.rtt.Type<?> $getParam(int i) { return null; }
            
            private Object writeReplace() throws java.io.ObjectStreamException {
                return new x10.serialization.SerializationProxy(this);
            }
            
            public static x10.serialization.X10JavaSerializable $_deserialize_body(x10.lang.PlaceGroup.SimplePlaceGroup.$Closure$167 $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
                $_obj.message = $deserializer.readObject();
                return $_obj;
            }
            
            public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
                x10.lang.PlaceGroup.SimplePlaceGroup.$Closure$167 $_obj = new x10.lang.PlaceGroup.SimplePlaceGroup.$Closure$167((java.lang.System[]) null);
                $deserializer.record_reference($_obj);
                return $_deserialize_body($_obj, $deserializer);
            }
            
            public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
                $serializer.write(this.message);
                
            }
            
            // constructor just for allocation
            public $Closure$167(final java.lang.System[] $dummy) {
                
            }
            
            // synthetic type for parameter mangling
            public static final class __0$1x10$lang$Byte$2 {}
            
        
            
            public void $apply() {
                
                //#line 231 "x10/lang/PlaceGroup.x10"
                try {{
                    
                    //#line 232 "x10/lang/PlaceGroup.x10"
                    final x10.io.Deserializer dser$135414 = ((x10.io.Deserializer)(new x10.io.Deserializer(this.message, (x10.io.Deserializer.__0$1x10$lang$Byte$2) null)));
                    
                    //#line 233 "x10/lang/PlaceGroup.x10"
                    final java.lang.Object t$135415 = dser$135414.readAny();
                    
                    //#line 233 "x10/lang/PlaceGroup.x10"
                    final x10.core.fun.VoidFun_0_0 cls$135416 = x10.rtt.Types.<x10.core.fun.VoidFun_0_0> cast(t$135415,x10.core.fun.VoidFun_0_0.$RTT);
                    
                    //#line 234 "x10/lang/PlaceGroup.x10"
                    ((x10.core.fun.VoidFun_0_0)cls$135416).$apply();
                }}catch (java.lang.Error __lowerer__var__0__) {
                    
                    //#line 231 "x10/lang/PlaceGroup.x10"
                    throw __lowerer__var__0__;
                }catch (java.lang.Throwable __lowerer__var__1__) {
                    
                    //#line 231 "x10/lang/PlaceGroup.x10"
                    throw x10.rtt.Types.EXCEPTION.isInstance(__lowerer__var__1__) ? (java.lang.RuntimeException)(__lowerer__var__1__) : new x10.lang.WrappedThrowable(__lowerer__var__1__);
                }
            }
            
            public x10.core.Rail<x10.core.Byte> message;
            
            public $Closure$167(final x10.core.Rail<x10.core.Byte> message, __0$1x10$lang$Byte$2 $dummy) {
                 {
                    this.message = ((x10.core.Rail)(message));
                }
            }
            
        }
        
        @x10.runtime.impl.java.X10Generated
        final public static class $Closure$168 extends x10.core.Ref implements x10.core.fun.VoidFun_0_0, x10.serialization.X10JavaSerializable
        {
            public static final x10.rtt.RuntimeType<$Closure$168> $RTT = 
                x10.rtt.StaticVoidFunType.<$Closure$168> make($Closure$168.class,
                                                              new x10.rtt.Type[] {
                                                                  x10.core.fun.VoidFun_0_0.$RTT
                                                              });
            
            public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
            
            public x10.rtt.Type<?> $getParam(int i) { return null; }
            
            private Object writeReplace() throws java.io.ObjectStreamException {
                return new x10.serialization.SerializationProxy(this);
            }
            
            public static x10.serialization.X10JavaSerializable $_deserialize_body(x10.lang.PlaceGroup.SimplePlaceGroup.$Closure$168 $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
                $_obj.message = $deserializer.readObject();
                return $_obj;
            }
            
            public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
                x10.lang.PlaceGroup.SimplePlaceGroup.$Closure$168 $_obj = new x10.lang.PlaceGroup.SimplePlaceGroup.$Closure$168((java.lang.System[]) null);
                $deserializer.record_reference($_obj);
                return $_deserialize_body($_obj, $deserializer);
            }
            
            public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
                $serializer.write(this.message);
                
            }
            
            // constructor just for allocation
            public $Closure$168(final java.lang.System[] $dummy) {
                
            }
            
            // synthetic type for parameter mangling
            public static final class __0$1x10$lang$Byte$2 {}
            
        
            
            public void $apply() {
                
                //#line 227 "x10/lang/PlaceGroup.x10"
                try {{
                    
                    //#line 228 "x10/lang/PlaceGroup.x10"
                    final long max$135421 = x10.x10rt.X10RT.here().id;
                    
                    //#line 229 "x10/lang/PlaceGroup.x10"
                    final long t$135422 = ((max$135421) - (((long)(31L))));
                    
                    //#line 229 "x10/lang/PlaceGroup.x10"
                    final long min$135423 = java.lang.Math.max(((long)(t$135422)),((long)(0L)));
                    {
                        
                        //#line 230 "x10/lang/PlaceGroup.x10"
                        x10.xrx.Runtime.ensureNotInAtomic();
                        
                        //#line 230 "x10/lang/PlaceGroup.x10"
                        final x10.xrx.FinishState fs$135458 = x10.xrx.Runtime.startFinish((int)(x10.compiler.Pragma.FINISH_SPMD));
                        
                        //#line 230 "x10/lang/PlaceGroup.x10"
                        try {{
                            {
                                
                                //#line 230 "x10/lang/PlaceGroup.x10"
                                long j$135424 = min$135423;
                                
                                //#line 230 "x10/lang/PlaceGroup.x10"
                                for (;
                                     true;
                                     ) {
                                    
                                    //#line 230 "x10/lang/PlaceGroup.x10"
                                    final boolean t$135426 = ((j$135424) <= (((long)(max$135421))));
                                    
                                    //#line 230 "x10/lang/PlaceGroup.x10"
                                    if (!(t$135426)) {
                                        
                                        //#line 230 "x10/lang/PlaceGroup.x10"
                                        break;
                                    }
                                    
                                    //#line 231 "x10/lang/PlaceGroup.x10"
                                    final x10.lang.Place alloc$135413 = ((x10.lang.Place)(new x10.lang.Place((java.lang.System[]) null)));
                                    
                                    //#line 231 "x10/lang/PlaceGroup.x10"
                                    alloc$135413.x10$lang$Place$$init$S(j$135424);
                                    
                                    //#line 231 "x10/lang/PlaceGroup.x10"
                                    x10.xrx.Runtime.runAsync(((x10.lang.Place)(alloc$135413)), ((x10.core.fun.VoidFun_0_0)(new x10.lang.PlaceGroup.SimplePlaceGroup.$Closure$167(((x10.core.Rail)(this.message)), (x10.lang.PlaceGroup.SimplePlaceGroup.$Closure$167.__0$1x10$lang$Byte$2) null))), ((x10.xrx.Runtime.Profile)(null)));
                                    
                                    //#line 230 "x10/lang/PlaceGroup.x10"
                                    final long t$135418 = ((j$135424) + (((long)(1L))));
                                    
                                    //#line 230 "x10/lang/PlaceGroup.x10"
                                    j$135424 = t$135418;
                                }
                            }
                        }}catch (java.lang.Throwable ct$135455) {
                            
                            //#line 230 "x10/lang/PlaceGroup.x10"
                            x10.xrx.Runtime.pushException(((java.lang.Throwable)(ct$135455)));
                            
                            //#line 230 "x10/lang/PlaceGroup.x10"
                            throw new java.lang.RuntimeException();
                        }finally {{
                             
                             //#line 230 "x10/lang/PlaceGroup.x10"
                             x10.xrx.Runtime.stopFinish(((x10.xrx.FinishState)(fs$135458)));
                         }}
                        }
                    }}catch (java.lang.Error __lowerer__var__0__) {
                        
                        //#line 227 "x10/lang/PlaceGroup.x10"
                        throw __lowerer__var__0__;
                    }catch (java.lang.Throwable __lowerer__var__1__) {
                        
                        //#line 227 "x10/lang/PlaceGroup.x10"
                        throw x10.rtt.Types.EXCEPTION.isInstance(__lowerer__var__1__) ? (java.lang.RuntimeException)(__lowerer__var__1__) : new x10.lang.WrappedThrowable(__lowerer__var__1__);
                    }
                }
            
            public x10.core.Rail<x10.core.Byte> message;
            
            public $Closure$168(final x10.core.Rail<x10.core.Byte> message, __0$1x10$lang$Byte$2 $dummy) {
                 {
                    this.message = ((x10.core.Rail)(message));
                }
            }
            
            }
            
        
        public boolean x10$lang$PlaceGroup$equals$S$O(final java.lang.Object a0) {
            return super.equals(((java.lang.Object)(a0)));
        }
        
        public void x10$lang$PlaceGroup$broadcastFlat$S(final x10.core.fun.VoidFun_0_0 a0) {
            super.broadcastFlat(((x10.core.fun.VoidFun_0_0)(a0)));
        }
        }
        
        
        
        //#line 245 "x10/lang/PlaceGroup.x10"
        public static x10.lang.PlaceGroup.SimplePlaceGroup make(final long numPlaces) {
            
            //#line 245 "x10/lang/PlaceGroup.x10"
            final x10.lang.PlaceGroup.SimplePlaceGroup alloc$105733 = ((x10.lang.PlaceGroup.SimplePlaceGroup)(new x10.lang.PlaceGroup.SimplePlaceGroup((java.lang.System[]) null)));
            
            //#line 245 "x10/lang/PlaceGroup.x10"
            alloc$105733.x10$lang$PlaceGroup$SimplePlaceGroup$$init$S(((long)(numPlaces)));
            
            //#line 245 "x10/lang/PlaceGroup.x10"
            return alloc$105733;
        }
        
        
        //#line 30 "x10/lang/PlaceGroup.x10"
        final public x10.lang.PlaceGroup x10$lang$PlaceGroup$$this$x10$lang$PlaceGroup() {
            
            //#line 30 "x10/lang/PlaceGroup.x10"
            return x10.lang.PlaceGroup.this;
        }
        
        
        //#line 30 "x10/lang/PlaceGroup.x10"
        
        // constructor for non-virtual call
        final public x10.lang.PlaceGroup x10$lang$PlaceGroup$$init$S() {
             {
                
                //#line 30 "x10/lang/PlaceGroup.x10"
                
            }
            return this;
        }
        
        
        
        //#line 30 "x10/lang/PlaceGroup.x10"
        abstract public x10.lang.Iterator iterator();
        
        
        //#line 30 "x10/lang/PlaceGroup.x10"
        final public void __fieldInitializers_x10_lang_PlaceGroup() {
            
        }
        
        @x10.runtime.impl.java.X10Generated
        final public static class $Closure$169 extends x10.core.Ref implements x10.core.fun.VoidFun_0_0, x10.serialization.X10JavaSerializable
        {
            public static final x10.rtt.RuntimeType<$Closure$169> $RTT = 
                x10.rtt.StaticVoidFunType.<$Closure$169> make($Closure$169.class,
                                                              new x10.rtt.Type[] {
                                                                  x10.core.fun.VoidFun_0_0.$RTT
                                                              });
            
            public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
            
            public x10.rtt.Type<?> $getParam(int i) { return null; }
            
            private Object writeReplace() throws java.io.ObjectStreamException {
                return new x10.serialization.SerializationProxy(this);
            }
            
            public static x10.serialization.X10JavaSerializable $_deserialize_body(x10.lang.PlaceGroup.$Closure$169 $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
                $_obj.message = $deserializer.readObject();
                return $_obj;
            }
            
            public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
                x10.lang.PlaceGroup.$Closure$169 $_obj = new x10.lang.PlaceGroup.$Closure$169((java.lang.System[]) null);
                $deserializer.record_reference($_obj);
                return $_deserialize_body($_obj, $deserializer);
            }
            
            public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
                $serializer.write(this.message);
                
            }
            
            // constructor just for allocation
            public $Closure$169(final java.lang.System[] $dummy) {
                
            }
            
            // synthetic type for parameter mangling
            public static final class __0$1x10$lang$Byte$2 {}
            
        
            
            public void $apply() {
                
                //#line 141 "x10/lang/PlaceGroup.x10"
                try {{
                    
                    //#line 142 "x10/lang/PlaceGroup.x10"
                    final x10.io.Deserializer dser$135382 = ((x10.io.Deserializer)(new x10.io.Deserializer(this.message, (x10.io.Deserializer.__0$1x10$lang$Byte$2) null)));
                    
                    //#line 143 "x10/lang/PlaceGroup.x10"
                    final java.lang.Object t$135383 = dser$135382.readAny();
                    
                    //#line 143 "x10/lang/PlaceGroup.x10"
                    final x10.core.fun.VoidFun_0_0 cls$135384 = x10.rtt.Types.<x10.core.fun.VoidFun_0_0> cast(t$135383,x10.core.fun.VoidFun_0_0.$RTT);
                    
                    //#line 144 "x10/lang/PlaceGroup.x10"
                    ((x10.core.fun.VoidFun_0_0)cls$135384).$apply();
                }}catch (java.lang.Error __lowerer__var__0__) {
                    
                    //#line 141 "x10/lang/PlaceGroup.x10"
                    throw __lowerer__var__0__;
                }catch (java.lang.Throwable __lowerer__var__1__) {
                    
                    //#line 141 "x10/lang/PlaceGroup.x10"
                    throw x10.rtt.Types.EXCEPTION.isInstance(__lowerer__var__1__) ? (java.lang.RuntimeException)(__lowerer__var__1__) : new x10.lang.WrappedThrowable(__lowerer__var__1__);
                }
            }
            
            public x10.core.Rail<x10.core.Byte> message;
            
            public $Closure$169(final x10.core.Rail<x10.core.Byte> message, __0$1x10$lang$Byte$2 $dummy) {
                 {
                    this.message = ((x10.core.Rail)(message));
                }
            }
            
        }
        
        @x10.runtime.impl.java.X10Generated
        final public static class $Closure$170 extends x10.core.Ref implements x10.core.fun.VoidFun_0_0, x10.serialization.X10JavaSerializable
        {
            public static final x10.rtt.RuntimeType<$Closure$170> $RTT = 
                x10.rtt.StaticVoidFunType.<$Closure$170> make($Closure$170.class,
                                                              new x10.rtt.Type[] {
                                                                  x10.core.fun.VoidFun_0_0.$RTT
                                                              });
            
            public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
            
            public x10.rtt.Type<?> $getParam(int i) { return null; }
            
            private Object writeReplace() throws java.io.ObjectStreamException {
                return new x10.serialization.SerializationProxy(this);
            }
            
            public static x10.serialization.X10JavaSerializable $_deserialize_body(x10.lang.PlaceGroup.$Closure$170 $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
                $_obj.message = $deserializer.readObject();
                return $_obj;
            }
            
            public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
                x10.lang.PlaceGroup.$Closure$170 $_obj = new x10.lang.PlaceGroup.$Closure$170((java.lang.System[]) null);
                $deserializer.record_reference($_obj);
                return $_deserialize_body($_obj, $deserializer);
            }
            
            public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
                $serializer.write(this.message);
                
            }
            
            // constructor just for allocation
            public $Closure$170(final java.lang.System[] $dummy) {
                
            }
            
            // synthetic type for parameter mangling
            public static final class __0$1x10$lang$Byte$2 {}
            
        
            
            public void $apply() {
                
                //#line 162 "x10/lang/PlaceGroup.x10"
                try {{
                    
                    //#line 163 "x10/lang/PlaceGroup.x10"
                    final x10.io.Deserializer dser$135391 = ((x10.io.Deserializer)(new x10.io.Deserializer(this.message, (x10.io.Deserializer.__0$1x10$lang$Byte$2) null)));
                    
                    //#line 164 "x10/lang/PlaceGroup.x10"
                    final java.lang.Object t$135392 = dser$135391.readAny();
                    
                    //#line 164 "x10/lang/PlaceGroup.x10"
                    final x10.core.fun.VoidFun_0_0 cls$135393 = x10.rtt.Types.<x10.core.fun.VoidFun_0_0> cast(t$135392,x10.core.fun.VoidFun_0_0.$RTT);
                    
                    //#line 165 "x10/lang/PlaceGroup.x10"
                    ((x10.core.fun.VoidFun_0_0)cls$135393).$apply();
                }}catch (java.lang.Error __lowerer__var__0__) {
                    
                    //#line 162 "x10/lang/PlaceGroup.x10"
                    throw __lowerer__var__0__;
                }catch (java.lang.Throwable __lowerer__var__1__) {
                    
                    //#line 162 "x10/lang/PlaceGroup.x10"
                    throw x10.rtt.Types.EXCEPTION.isInstance(__lowerer__var__1__) ? (java.lang.RuntimeException)(__lowerer__var__1__) : new x10.lang.WrappedThrowable(__lowerer__var__1__);
                }
            }
            
            public x10.core.Rail<x10.core.Byte> message;
            
            public $Closure$170(final x10.core.Rail<x10.core.Byte> message, __0$1x10$lang$Byte$2 $dummy) {
                 {
                    this.message = ((x10.core.Rail)(message));
                }
            }
            
        }
        
    }
    
    