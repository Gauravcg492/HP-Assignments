package x10.lang;


@x10.runtime.impl.java.X10Generated
public class System extends x10.core.Ref implements x10.serialization.X10JavaSerializable
{
    public static final x10.rtt.RuntimeType<System> $RTT = 
        x10.rtt.NamedType.<System> make("x10.lang.System",
                                        System.class);
    
    public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
    
    public x10.rtt.Type<?> $getParam(int i) { return null; }
    
    private Object writeReplace() throws java.io.ObjectStreamException {
        return new x10.serialization.SerializationProxy(this);
    }
    
    public static x10.serialization.X10JavaSerializable $_deserialize_body(x10.lang.System $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
        return $_obj;
    }
    
    public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
        x10.lang.System $_obj = new x10.lang.System((java.lang.System[]) null);
        $deserializer.record_reference($_obj);
        return $_deserialize_body($_obj, $deserializer);
    }
    
    public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
        
    }
    
    // constructor just for allocation
    public System(final java.lang.System[] $dummy) {
        
    }
    
    

    
    
    //#line 26 "x10/lang/System.x10"
    // creation method for java code (1-phase java constructor)
    public System() {
        this((java.lang.System[]) null);
        x10$lang$System$$init$S();
    }
    
    // constructor for non-virtual call
    final public x10.lang.System x10$lang$System$$init$S() {
         {
            
            //#line 26 "x10/lang/System.x10"
            
        }
        return this;
    }
    
    
    
    //#line 33 "x10/lang/System.x10"
    /**
     * Provides the current time in milliseconds.
     *
     * @return The current time in milliseconds.
     */
    public static long currentTimeMillis$O() {
        
        //#line 33 "x10/lang/System.x10"
        final long t$136581 = java.lang.System.currentTimeMillis();
        
        //#line 33 "x10/lang/System.x10"
        return t$136581;
    }
    
    
    //#line 40 "x10/lang/System.x10"
    /**
     * Provides the current time in nanoseconds, as precise as the system timers provide.
     *
     * @return The current time in nanoseconds.
     */
    public static long nanoTime$O() {
        
        //#line 40 "x10/lang/System.x10"
        final long t$136582 = java.lang.System.nanoTime();
        
        //#line 40 "x10/lang/System.x10"
        return t$136582;
    }
    
    
    //#line 49 "x10/lang/System.x10"
    /**
     * Kills the current place, as if due to a hardware or low level software failure.  
     * Behaviour is only well-defined if executed at a place other than Place.FIRST_PLACE 
     * and the program is executing in one of the resilient modes
     *
     * @see Configuration#resilient_mode
     */
    public static void killHere() {
        try {
            java.lang.System.exit(1);
        }
        catch (java.lang.Throwable exc$206441) {
            throw x10.runtime.impl.java.ThrowableUtils.ensureX10Exception(exc$206441);
        }
        
    }
    
    
    
    //#line 63 "x10/lang/System.x10"
    /**
     * Asynchronously kills the victim place, as if due 
     * to a hardware or low level software failure.  
     * The victim should not be Place.FIRST_PLACE.
     * The program ahould be executing in one of the resilient modes 
     * for correct operation.
     *
     * @see Configuration#resilient_mode
     */
    public static void killThere(final x10.lang.Place victim) {
        
        //#line 64 "x10/lang/System.x10"
        x10.xrx.Runtime.runImmediateAsync$P(((x10.lang.Place)(victim)), ((x10.core.fun.VoidFun_0_0)(new x10.lang.System.$Closure_killThere())), ((x10.xrx.Runtime.Profile)(null)));
    }
    
    
    //#line 78 "x10/lang/System.x10"
    /**
     * Requests the launcher to create N additional places asynchronously.
     * Please note that since this is an asynchronous operation, a return 
     * code greater than zero does not guarantee those places have actually
     * started, as they may fail for reasons outside of the launcher's control
     * 
     * @param newPlaces the number of new places to add
     * @return The number of new places that this request attempted to spawn.
     * May be less than the number requested, if resources are not available, 
     * or if the current launcher does not support adding places after startup.
     */
    public static long addPlaces$O(final long newPlaces) {
        try {
            return x10.x10rt.X10RT.addPlaces(newPlaces);
        }
        catch (java.lang.Throwable exc$206442) {
            throw x10.runtime.impl.java.ThrowableUtils.ensureX10Exception(exc$206442);
        }
        
    }
    
    
    
    //#line 95 "x10/lang/System.x10"
    /**
     * Requests the launcher to create N additional places synchronously, 
     * waiting up to 'timeout' milliseconds for the places to join before 
     * returning.
     * 
     * @param newPlaces the number of new places to add
     * @param timeout how many milliseconds to wait for the places to join
     * @return The number of new places that joined successfully.  This may be 
     * fewer than the requested number of places if we timed out, or more than 
     * the requested number of places if there were multiple overlapping calls
     * to this method
     */
    public static long addPlacesAndWait$O(final long newPlaces, final long timeout) {
        
        //#line 96 "x10/lang/System.x10"
        final long initialPlaceCount = ((long)x10.x10rt.X10RT.numPlaces());
        
        //#line 97 "x10/lang/System.x10"
        final long launcherAdded = x10.x10rt.X10RT.addPlaces(((long)(newPlaces)));
        
        //#line 98 "x10/lang/System.x10"
        final boolean t$136583 = ((long) launcherAdded) == ((long) 0L);
        
        //#line 98 "x10/lang/System.x10"
        if (t$136583) {
            
            //#line 98 "x10/lang/System.x10"
            return 0L;
        }
        
        //#line 101 "x10/lang/System.x10"
        final long timePlacesRequested = java.lang.System.currentTimeMillis();
        
        //#line 102 "x10/lang/System.x10"
        while (true) {
            
            //#line 102 "x10/lang/System.x10"
            final long t$136584 = ((long)x10.x10rt.X10RT.numPlaces());
            
            //#line 102 "x10/lang/System.x10"
            final long t$136585 = ((initialPlaceCount) + (((long)(launcherAdded))));
            
            //#line 102 "x10/lang/System.x10"
            final boolean t$136591 = ((t$136584) < (((long)(t$136585))));
            
            //#line 102 "x10/lang/System.x10"
            if (!(t$136591)) {
                
                //#line 102 "x10/lang/System.x10"
                break;
            }
            
            //#line 33 . "x10/lang/System.x10"
            final long t$136607 = java.lang.System.currentTimeMillis();
            
            //#line 103 "x10/lang/System.x10"
            final long t$136608 = ((timePlacesRequested) + (((long)(timeout))));
            
            //#line 103 "x10/lang/System.x10"
            final boolean t$136609 = ((t$136607) > (((long)(t$136608))));
            
            //#line 103 "x10/lang/System.x10"
            if (t$136609) {
                
                //#line 105 "x10/lang/System.x10"
                final long t$136610 = ((long)x10.x10rt.X10RT.numPlaces());
                
                //#line 105 "x10/lang/System.x10"
                final long t$136611 = ((t$136610) - (((long)(initialPlaceCount))));
                
                //#line 105 "x10/lang/System.x10"
                return t$136611;
            }
            
            //#line 243 . "x10/lang/System.x10"
            x10.xrx.Runtime.sleep$O((long)(100L));
        }
        
        //#line 109 "x10/lang/System.x10"
        return launcherAdded;
    }
    
    
    //#line 124 "x10/lang/System.x10"
    public static void registerPlaceAddedHandler__0$1x10$lang$Place$2(final x10.core.fun.VoidFun_0_1<x10.lang.Place> handler) {
        try {
            x10.x10rt.X10RT.registerPlaceAddedHandler(handler);
        }
        catch (java.lang.Throwable exc$206443) {
            throw x10.runtime.impl.java.ThrowableUtils.ensureX10Exception(exc$206443);
        }
        
    }
    
    
    
    //#line 141 "x10/lang/System.x10"
    public static void registerPlaceRemovedHandler__0$1x10$lang$Place$2(final x10.core.fun.VoidFun_0_1<x10.lang.Place> handler) {
        try {
            x10.x10rt.X10RT.registerPlaceRemovedHandler(handler);
        }
        catch (java.lang.Throwable exc$206444) {
            throw x10.runtime.impl.java.ThrowableUtils.ensureX10Exception(exc$206444);
        }
        
    }
    
    
    
    //#line 162 "x10/lang/System.x10"
    /**
     * Sets the exit code with which the X10 program will exit.
     * However, calling this method has no effect on the timing
     * of when the computation will exit.
     * 
     * This method is primarily intended for usage by testing 
     * frameworks that use non-zero exit codes to encode testcase 
     * failures.
     *
     * Implementation note: This method currently must internally
     *   shift execution to Place.FIRST_PLACE and set the exitCode
     *   there because exitCodes are intentionally not implicitly 
     *   propagated back to Place.FIRST_PLACE when other Places 
     *   exit.  Therefore the caller should be aware that calling this
     *   method from within an <code>atomic</code> or <code>when</code>
     *   will result in an exception being raised.
     */
    public static void setExitCode(final int exitCode) {
        
        //#line 163 "x10/lang/System.x10"
        final x10.lang.Place t$136593 = ((x10.lang.Place)(x10.lang.Place.get$FIRST_PLACE()));
        
        //#line 163 "x10/lang/System.x10"
        final boolean t$136595 = (!x10.rtt.Equality.equalsequals((x10.x10rt.X10RT.here()),(t$136593)));
        
        //#line 163 "x10/lang/System.x10"
        if (t$136595) {
            
            //#line 164 "x10/lang/System.x10"
            final x10.lang.Place t$136594 = ((x10.lang.Place)(x10.lang.Place.get$FIRST_PLACE()));
            {
                
                //#line 164 "x10/lang/System.x10"
                x10.xrx.Runtime.runAt(((x10.lang.Place)(t$136594)), ((x10.core.fun.VoidFun_0_0)(new x10.lang.System.$Closure$201(exitCode))), ((x10.xrx.Runtime.Profile)(null)));
            }
        } else {
            try {
                x10.runtime.impl.java.Runtime.setExitCode(exitCode);
            }
            catch (java.lang.Throwable exc$206445) {
                throw x10.runtime.impl.java.ThrowableUtils.ensureX10Exception(exc$206445);
            }
            
        }
    }
    
    
    //#line 183 "x10/lang/System.x10"
    /**
     * Provides an estimate in bytes of the size of the X10 heap
     * allocated to the current place. The accuracy of this estimate
     * is highly dependent on the implementation details of the
     * underlying memory management scheme being used by the X10 runtime,
     * and in some cases may simply return Long.MAX_VALUE or some other similarly
     * over conservative approximation.
     *
     * @return An upper bound in bytes on the size of the X10 heap allocated to the current place.
     */
    public static long heapSize$O() {
        try {
            return java.lang.Runtime.getRuntime().totalMemory();
        }
        catch (java.lang.Throwable exc$206446) {
            throw x10.runtime.impl.java.ThrowableUtils.ensureX10Exception(exc$206446);
        }
        
    }
    
    
    
    //#line 190 "x10/lang/System.x10"
    /**
     * Trigger a garbage collection.
     */
    public static void gc() {
        try {
            java.lang.System.gc();
        }
        catch (java.lang.Throwable exc$206447) {
            throw x10.runtime.impl.java.ThrowableUtils.ensureX10Exception(exc$206447);
        }
        
    }
    
    
    
    //#line 197 "x10/lang/System.x10"
    /**
     * Returns an immutable map from environment variables to values.
     */
    public static x10.util.Map getenv() {
        
        //#line 197 "x10/lang/System.x10"
        final x10.util.HashMap t$136596 = ((x10.util.HashMap)(x10.xrx.Runtime.get$env()));
        
        //#line 197 "x10/lang/System.x10"
        return t$136596;
    }
    
    
    //#line 202 "x10/lang/System.x10"
    /**
     * Returns the value of the specified environment variable, or null if the variable is not defined.
     */
    public static java.lang.String getenv(final java.lang.String name) {
        
        //#line 202 "x10/lang/System.x10"
        final x10.util.HashMap t$136597 = ((x10.util.HashMap)(x10.xrx.Runtime.get$env()));
        
        //#line 202 "x10/lang/System.x10"
        final java.lang.String t$136598 = ((x10.util.HashMap<java.lang.String, java.lang.String>)t$136597).getOrElse__0x10$util$HashMap$$K__1x10$util$HashMap$$V$G(((java.lang.String)(name)), ((java.lang.String)(null)));
        
        //#line 202 "x10/lang/System.x10"
        return t$136598;
    }
    
    
    //#line 212 "x10/lang/System.x10"
    /**
     * Sets the system property with the given name to the given value.
     *
     * @param p the name of the system property.
     * @param v the value for the system property.
     * TODO: @ return The previous value of the property, or null if it did not have one.
     */
    public static void setProperty(final java.lang.String p, final java.lang.String v) {
        try {
            java.lang.System.setProperty(p,v);
        }
        catch (java.lang.Throwable exc$206448) {
            throw x10.runtime.impl.java.ThrowableUtils.ensureX10Exception(exc$206448);
        }
        
    }
    
    
    
    //#line 220 "x10/lang/System.x10"
    /** Get the type name of T as a string
     * @param T a type
     * @return The name of type T 
     */
    public static <$T>java.lang.String typeName(final x10.rtt.Type $T) {
        try {
            return $T.typeName();
        }
        catch (java.lang.Throwable exc$206449) {
            throw x10.runtime.impl.java.ThrowableUtils.ensureX10Exception(exc$206449);
        }
        
    }
    
    
    
    //#line 224 "x10/lang/System.x10"
    public static java.lang.String identityTypeName(final java.lang.Object o) {
        try {
            return x10.rtt.Types.typeName(o);
        }
        catch (java.lang.Throwable exc$206450) {
            throw x10.runtime.impl.java.ThrowableUtils.ensureX10Exception(exc$206450);
        }
        
    }
    
    
    
    //#line 228 "x10/lang/System.x10"
    public static int identityHashCode$O(final java.lang.Object o) {
        try {
            return java.lang.System.identityHashCode(o);
        }
        catch (java.lang.Throwable exc$206451) {
            throw x10.runtime.impl.java.ThrowableUtils.ensureX10Exception(exc$206451);
        }
        
    }
    
    
    
    //#line 232 "x10/lang/System.x10"
    public static java.lang.String identityToString(final java.lang.Object o) {
        
        //#line 232 "x10/lang/System.x10"
        final java.lang.String t$136599 = x10.rtt.Types.typeName(o);
        
        //#line 232 "x10/lang/System.x10"
        final java.lang.String t$136601 = ((t$136599) + ("@"));
        
        //#line 232 "x10/lang/System.x10"
        final int t$136600 = java.lang.System.identityHashCode(o);
        
        //#line 232 "x10/lang/System.x10"
        final java.lang.String t$136602 = java.lang.Integer.toString(t$136600, 16);
        
        //#line 232 "x10/lang/System.x10"
        final java.lang.String t$136603 = ((t$136601) + (t$136602));
        
        //#line 232 "x10/lang/System.x10"
        return t$136603;
    }
    
    
    //#line 234 "x10/lang/System.x10"
    public static boolean identityEquals$O(final java.lang.Object o1, final java.lang.Object o2) {
        
        //#line 234 "x10/lang/System.x10"
        final boolean t$136604 = x10.rtt.Equality.equalsequals((o1),(o2));
        
        //#line 234 "x10/lang/System.x10"
        return t$136604;
    }
    
    
    //#line 242 "x10/lang/System.x10"
    /**
     * Sleep for the specified number of milliseconds.
     * [IP] NOTE: Unlike Java, x10 sleep() simply exits when interrupted.
     * @param millis the number of milliseconds to sleep
     * @return true if completed normally, false if interrupted
     */
    public static boolean sleep$O(final long millis) {
        
        //#line 243 "x10/lang/System.x10"
        final boolean t$136605 = x10.xrx.Runtime.sleep$O((long)(millis));
        
        //#line 243 "x10/lang/System.x10"
        return t$136605;
    }
    
    
    //#line 251 "x10/lang/System.x10"
    /**
     * Sleep for the specified number of milliseconds.
     * @param millis the number of milliseconds to sleep
     * @return true if completed normally, false if interrupted
     */
    public static boolean threadSleep$O(final long millis) {
        
        //#line 1565 . "x10/xrx/Runtime.x10"
        boolean ret$136579 =  false;
        
        //#line 1565 . "x10/xrx/Runtime.x10"
        __ret$136580: {
            
            //#line 1566 . "x10/xrx/Runtime.x10"
            try {{
                
                //#line 1567 . "x10/xrx/Runtime.x10"
                x10.core.Thread.sleep((long)(millis));
                
                //#line 1568 . "x10/xrx/Runtime.x10"
                ret$136579 = true;
                
                //#line 1568 . "x10/xrx/Runtime.x10"
                break __ret$136580;
            }}catch (final x10.xrx.InterruptedException e$136578) {
                
                //#line 1570 . "x10/xrx/Runtime.x10"
                ret$136579 = false;
                
                //#line 1570 . "x10/xrx/Runtime.x10"
                break __ret$136580;
            }
        }
        
        //#line 252 "x10/lang/System.x10"
        return ret$136579;
    }
    
    
    //#line 23 "x10/lang/System.x10"
    final public x10.lang.System x10$lang$System$$this$x10$lang$System() {
        
        //#line 23 "x10/lang/System.x10"
        return x10.lang.System.this;
    }
    
    
    //#line 23 "x10/lang/System.x10"
    final public void __fieldInitializers_x10_lang_System() {
        
    }
    
    @x10.runtime.impl.java.X10Generated
    final public static class $Closure_killThere extends x10.core.Ref implements x10.core.fun.VoidFun_0_0, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<$Closure_killThere> $RTT = 
            x10.rtt.StaticVoidFunType.<$Closure_killThere> make($Closure_killThere.class,
                                                                new x10.rtt.Type[] {
                                                                    x10.core.fun.VoidFun_0_0.$RTT
                                                                });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static x10.serialization.X10JavaSerializable $_deserialize_body(x10.lang.System.$Closure_killThere $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.lang.System.$Closure_killThere $_obj = new x10.lang.System.$Closure_killThere((java.lang.System[]) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            
        }
        
        // constructor just for allocation
        public $Closure_killThere(final java.lang.System[] $dummy) {
            
        }
        
        
    
        
        public void $apply() {
            
            //#line 64 "x10/lang/System.x10"
            java.lang.System.exit(1);
        }
        
        public $Closure_killThere() {
             {
                
            }
        }
        
    }
    
    @x10.runtime.impl.java.X10Generated
    final public static class $Closure$201 extends x10.core.Ref implements x10.core.fun.VoidFun_0_0, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<$Closure$201> $RTT = 
            x10.rtt.StaticVoidFunType.<$Closure$201> make($Closure$201.class,
                                                          new x10.rtt.Type[] {
                                                              x10.core.fun.VoidFun_0_0.$RTT
                                                          });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static x10.serialization.X10JavaSerializable $_deserialize_body(x10.lang.System.$Closure$201 $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            $_obj.exitCode = $deserializer.readInt();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.lang.System.$Closure$201 $_obj = new x10.lang.System.$Closure$201((java.lang.System[]) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            $serializer.write(this.exitCode);
            
        }
        
        // constructor just for allocation
        public $Closure$201(final java.lang.System[] $dummy) {
            
        }
        
        
    
        
        public void $apply() {
            
            //#line 164 "x10/lang/System.x10"
            try {{
                
                //#line 164 "x10/lang/System.x10"
                x10.lang.System.setExitCode((int)(this.exitCode));
            }}catch (java.lang.Throwable __lowerer__var__0__) {
                
                //#line 164 "x10/lang/System.x10"
                int __lowerer__var__1__ = (x10.core.Int.$unbox(x10.xrx.Runtime.<x10.core.Int> wrapAtChecked$G(x10.rtt.Types.INT, ((java.lang.Throwable)(__lowerer__var__0__)))));
            }
        }
        
        public int exitCode;
        
        public $Closure$201(final int exitCode) {
             {
                this.exitCode = exitCode;
            }
        }
        
    }
    
}

