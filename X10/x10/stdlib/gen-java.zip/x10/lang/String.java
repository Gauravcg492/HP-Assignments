package x10.lang;


/**
 * The String class represents character strings.
 * All string literals in X10 programs, such as "Hello", are instances of String.
 * Strings are immutable and cannot be changed after they are created.
 *
 * String provides a concatenation operator '+', methods for converting
 * instances of other types to strings (which invoke the
 * {@link x10.lang.Any#toString()} method), methods for examining individual
 * characters of the sequence, for searching strings, for comparing
 * strings, for extracting substrings, and for creating a copy of a string
 * with all characters translated to uppercase or to lowercase.  Case mapping
 * is defined in {@link x10.lang.Char}.
 */
;



