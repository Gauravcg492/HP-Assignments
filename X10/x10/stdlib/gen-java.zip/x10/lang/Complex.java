package x10.lang;


/**
 * Complex is a struct representing a complex number (a + b*i).
 * The real and imaginary components are represented as Doubles.
 */
@x10.runtime.impl.java.X10Generated
public class Complex extends x10.core.Struct implements x10.lang.Arithmetic, x10.serialization.X10JavaSerializable
{
    public static final x10.rtt.RuntimeType<Complex> $RTT = 
        x10.rtt.NamedStructType.<Complex> make("x10.lang.Complex",
                                               Complex.class,
                                               new x10.rtt.Type[] {
                                                   x10.rtt.ParameterizedType.make(x10.lang.Arithmetic.$RTT, x10.rtt.UnresolvedType.THIS),
                                                   x10.rtt.Types.STRUCT
                                               });
    
    public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
    
    public x10.rtt.Type<?> $getParam(int i) { return null; }
    
    private Object writeReplace() throws java.io.ObjectStreamException {
        return new x10.serialization.SerializationProxy(this);
    }
    
    public static x10.serialization.X10JavaSerializable $_deserialize_body(x10.lang.Complex $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
        $_obj.im = $deserializer.readDouble();
        $_obj.re = $deserializer.readDouble();
        return $_obj;
    }
    
    public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
        x10.lang.Complex $_obj = new x10.lang.Complex((java.lang.System[]) null);
        return $_deserialize_body($_obj, $deserializer);
    }
    
    public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
        $serializer.write(this.im);
        $serializer.write(this.re);
        
    }
    
    // zero value constructor
    public Complex(final java.lang.System $dummy) { this.re = 0.0; this.im = 0.0; }
    
    // constructor just for allocation
    public Complex(final java.lang.System[] $dummy) {
        
    }
    
    // dispatcher for method abstract public x10.lang.Arithmetic[T].operator+(that:T){}:T
    public java.lang.Object $plus(final java.lang.Object a1, final x10.rtt.Type t1) {
        return $plus((x10.lang.Complex)a1);
        
    }
    
    // dispatcher for method abstract public x10.lang.Arithmetic[T].operator-(that:T){}:T
    public java.lang.Object $minus(final java.lang.Object a1, final x10.rtt.Type t1) {
        return $minus((x10.lang.Complex)a1);
        
    }
    
    // dispatcher for method abstract public x10.lang.Arithmetic[T].operator*(that:T){}:T
    public java.lang.Object $times(final java.lang.Object a1, final x10.rtt.Type t1) {
        return $times((x10.lang.Complex)a1);
        
    }
    
    // dispatcher for method abstract public x10.lang.Arithmetic[T].operator/(that:T){}:T
    public java.lang.Object $over(final java.lang.Object a1, final x10.rtt.Type t1) {
        return $over((x10.lang.Complex)a1);
        
    }
    
    // bridge for method abstract public x10.lang.Arithmetic[T].operator+(){}:T
    final public x10.lang.Complex $plus$G() {
        return $plus();
    }
    
    // bridge for method abstract public x10.lang.Arithmetic[T].operator-(){}:T
    final public x10.lang.Complex $minus$G() {
        return $minus();
    }
    
    

    
    //#line 29 "x10/lang/Complex.x10"
    /** The real component of this complex number. */
    public double re;
    
    //#line 32 "x10/lang/Complex.x10"
    /** The imaginary component of this complex number. */
    public double im;
    
    //#line 36 "x10/lang/Complex.x10"
    private static x10.lang.Complex ZERO;
    
    //#line 39 "x10/lang/Complex.x10"
    private static x10.lang.Complex ONE;
    
    //#line 42 "x10/lang/Complex.x10"
    private static x10.lang.Complex I;
    
    //#line 45 "x10/lang/Complex.x10"
    private static x10.lang.Complex INF;
    
    //#line 48 "x10/lang/Complex.x10"
    private static x10.lang.Complex NaN;
    
    
    //#line 57 "x10/lang/Complex.x10"
    /**
     * Construct a complex number with the specified real and imaginary components.
     *
     * @real the real component of the Complex number
     * @imaginary the imaginary component of the Complex number
     * @return the Complex number representing (real + imaginary*i)
     */
    public Complex(final double real, final double imaginary) {
         {
            
            //#line 57 "x10/lang/Complex.x10"
            
            
            //#line 24 "x10/lang/Complex.x10"
            this.__fieldInitializers_x10_lang_Complex();
            
            //#line 59 "x10/lang/Complex.x10"
            this.re = real;
            
            //#line 60 "x10/lang/Complex.x10"
            this.im = imaginary;
        }
    }
    
    
    
    //#line 66 "x10/lang/Complex.x10"
    /**
     * @return the sum of this complex number and the given complex number.
     */
    final public x10.lang.Complex $plus(final x10.lang.Complex that) {
        
        //#line 68 "x10/lang/Complex.x10"
        final double t$132941 = this.re;
        
        //#line 68 "x10/lang/Complex.x10"
        final double t$132942 = that.re;
        
        //#line 68 "x10/lang/Complex.x10"
        final double t$132945 = ((t$132941) + (((double)(t$132942))));
        
        //#line 68 "x10/lang/Complex.x10"
        final double t$132943 = this.im;
        
        //#line 68 "x10/lang/Complex.x10"
        final double t$132944 = that.im;
        
        //#line 68 "x10/lang/Complex.x10"
        final double t$132946 = ((t$132943) + (((double)(t$132944))));
        
        //#line 68 "x10/lang/Complex.x10"
        final x10.lang.Complex t$132947 = new x10.lang.Complex(t$132945, t$132946);
        
        //#line 68 "x10/lang/Complex.x10"
        return t$132947;
    }
    
    
    //#line 74 "x10/lang/Complex.x10"
    /**
     * @return the sum of the given double and the given complex number.
     */
    final public static x10.lang.Complex $plus(final double x, final x10.lang.Complex y) {
        
        //#line 75 "x10/lang/Complex.x10"
        final x10.lang.Complex t$132948 = y.$plus((double)(x));
        
        //#line 75 "x10/lang/Complex.x10"
        return t$132948;
    }
    
    
    //#line 80 "x10/lang/Complex.x10"
    /**
     * @return the sum of this complex number and the given double.
     */
    final public x10.lang.Complex $plus(final double that) {
        
        //#line 82 "x10/lang/Complex.x10"
        final double t$132949 = this.re;
        
        //#line 82 "x10/lang/Complex.x10"
        final double t$132950 = ((t$132949) + (((double)(that))));
        
        //#line 82 "x10/lang/Complex.x10"
        final double t$132951 = this.im;
        
        //#line 82 "x10/lang/Complex.x10"
        final x10.lang.Complex t$132952 = new x10.lang.Complex(t$132950, ((double)(t$132951)));
        
        //#line 82 "x10/lang/Complex.x10"
        return t$132952;
    }
    
    
    //#line 88 "x10/lang/Complex.x10"
    /**
     * @return the difference between this complex number and the given complex number.
     */
    final public x10.lang.Complex $minus(final x10.lang.Complex that) {
        
        //#line 90 "x10/lang/Complex.x10"
        final double t$132953 = this.re;
        
        //#line 90 "x10/lang/Complex.x10"
        final double t$132954 = that.re;
        
        //#line 90 "x10/lang/Complex.x10"
        final double t$132957 = ((t$132953) - (((double)(t$132954))));
        
        //#line 90 "x10/lang/Complex.x10"
        final double t$132955 = this.im;
        
        //#line 90 "x10/lang/Complex.x10"
        final double t$132956 = that.im;
        
        //#line 90 "x10/lang/Complex.x10"
        final double t$132958 = ((t$132955) - (((double)(t$132956))));
        
        //#line 90 "x10/lang/Complex.x10"
        final x10.lang.Complex t$132959 = new x10.lang.Complex(t$132957, t$132958);
        
        //#line 90 "x10/lang/Complex.x10"
        return t$132959;
    }
    
    
    //#line 96 "x10/lang/Complex.x10"
    /**
     * @return the difference between the given double and this complex number.
     */
    final public static x10.lang.Complex $minus(final double x, final x10.lang.Complex y) {
        
        //#line 97 "x10/lang/Complex.x10"
        final double t$132960 = y.re;
        
        //#line 97 "x10/lang/Complex.x10"
        final double t$132962 = ((x) - (((double)(t$132960))));
        
        //#line 97 "x10/lang/Complex.x10"
        final double t$132961 = y.im;
        
        //#line 97 "x10/lang/Complex.x10"
        final double t$132963 = (-(t$132961));
        
        //#line 97 "x10/lang/Complex.x10"
        final x10.lang.Complex t$132964 = new x10.lang.Complex(t$132962, t$132963);
        
        //#line 97 "x10/lang/Complex.x10"
        return t$132964;
    }
    
    
    //#line 102 "x10/lang/Complex.x10"
    /**
     * @return the difference between this complex number and the given double.
     */
    final public x10.lang.Complex $minus(final double that) {
        
        //#line 104 "x10/lang/Complex.x10"
        final double t$132965 = this.re;
        
        //#line 104 "x10/lang/Complex.x10"
        final double t$132966 = ((t$132965) - (((double)(that))));
        
        //#line 104 "x10/lang/Complex.x10"
        final double t$132967 = this.im;
        
        //#line 104 "x10/lang/Complex.x10"
        final x10.lang.Complex t$132968 = new x10.lang.Complex(t$132966, ((double)(t$132967)));
        
        //#line 104 "x10/lang/Complex.x10"
        return t$132968;
    }
    
    
    //#line 110 "x10/lang/Complex.x10"
    /**
     * @return the product of this complex number and the given complex number.
     */
    final public x10.lang.Complex $times(final x10.lang.Complex that) {
        
        //#line 112 "x10/lang/Complex.x10"
        final double t$132969 = this.re;
        
        //#line 112 "x10/lang/Complex.x10"
        final double t$132970 = that.re;
        
        //#line 112 "x10/lang/Complex.x10"
        final double t$132973 = ((t$132969) * (((double)(t$132970))));
        
        //#line 112 "x10/lang/Complex.x10"
        final double t$132971 = this.im;
        
        //#line 112 "x10/lang/Complex.x10"
        final double t$132972 = that.im;
        
        //#line 112 "x10/lang/Complex.x10"
        final double t$132974 = ((t$132971) * (((double)(t$132972))));
        
        //#line 112 "x10/lang/Complex.x10"
        final double t$132981 = ((t$132973) - (((double)(t$132974))));
        
        //#line 113 "x10/lang/Complex.x10"
        final double t$132975 = this.re;
        
        //#line 113 "x10/lang/Complex.x10"
        final double t$132976 = that.im;
        
        //#line 113 "x10/lang/Complex.x10"
        final double t$132979 = ((t$132975) * (((double)(t$132976))));
        
        //#line 113 "x10/lang/Complex.x10"
        final double t$132977 = this.im;
        
        //#line 113 "x10/lang/Complex.x10"
        final double t$132978 = that.re;
        
        //#line 113 "x10/lang/Complex.x10"
        final double t$132980 = ((t$132977) * (((double)(t$132978))));
        
        //#line 113 "x10/lang/Complex.x10"
        final double t$132982 = ((t$132979) + (((double)(t$132980))));
        
        //#line 112 "x10/lang/Complex.x10"
        final x10.lang.Complex t$132983 = new x10.lang.Complex(t$132981, t$132982);
        
        //#line 112 "x10/lang/Complex.x10"
        return t$132983;
    }
    
    
    //#line 119 "x10/lang/Complex.x10"
    /**
     * @return the product of the given double and this complex number.
     */
    final public static x10.lang.Complex $times(final double x, final x10.lang.Complex y) {
        
        //#line 120 "x10/lang/Complex.x10"
        final x10.lang.Complex t$132984 = y.$times((double)(x));
        
        //#line 120 "x10/lang/Complex.x10"
        return t$132984;
    }
    
    
    //#line 125 "x10/lang/Complex.x10"
    /**
     * @return the product of this complex number and the given double.
     */
    final public x10.lang.Complex $times(final double that) {
        
        //#line 127 "x10/lang/Complex.x10"
        final double t$132985 = this.re;
        
        //#line 127 "x10/lang/Complex.x10"
        final double t$132987 = ((t$132985) * (((double)(that))));
        
        //#line 127 "x10/lang/Complex.x10"
        final double t$132986 = this.im;
        
        //#line 127 "x10/lang/Complex.x10"
        final double t$132988 = ((t$132986) * (((double)(that))));
        
        //#line 127 "x10/lang/Complex.x10"
        final x10.lang.Complex t$132989 = new x10.lang.Complex(t$132987, t$132988);
        
        //#line 127 "x10/lang/Complex.x10"
        return t$132989;
    }
    
    
    //#line 136 "x10/lang/Complex.x10"
    /**
     * Return the quotient of this complex number and the given complex number.
     * Uses Smith's algorithm {@link http://doi.acm.org/10.1145/368637.368661}.
     * TODO: consider using Priest's algorithm {@link http://doi.acm.org/10.1145/1039813.1039814}.
     * @return the quotient of this complex number and the given complex number.
     */
    final public x10.lang.Complex $over(final x10.lang.Complex that) {
        
        //#line 138 "x10/lang/Complex.x10"
        boolean t$132990 = this.isNaN$O();
        
        //#line 138 "x10/lang/Complex.x10"
        if (!(t$132990)) {
            
            //#line 138 "x10/lang/Complex.x10"
            t$132990 = that.isNaN$O();
        }
        
        //#line 138 "x10/lang/Complex.x10"
        if (t$132990) {
            
            //#line 139 "x10/lang/Complex.x10"
            final x10.lang.Complex t$132991 = ((x10.lang.Complex)(x10.lang.Complex.get$NaN()));
            
            //#line 139 "x10/lang/Complex.x10"
            return t$132991;
        }
        
        //#line 142 "x10/lang/Complex.x10"
        final double c = that.re;
        
        //#line 143 "x10/lang/Complex.x10"
        final double d = that.im;
        
        //#line 144 "x10/lang/Complex.x10"
        boolean t$132993 = ((double) c) == ((double) 0.0);
        
        //#line 144 "x10/lang/Complex.x10"
        if (t$132993) {
            
            //#line 144 "x10/lang/Complex.x10"
            t$132993 = ((double) d) == ((double) 0.0);
        }
        
        //#line 144 "x10/lang/Complex.x10"
        if (t$132993) {
            
            //#line 145 "x10/lang/Complex.x10"
            final double t$132994 = this.re;
            
            //#line 145 "x10/lang/Complex.x10"
            boolean t$132996 = ((double) t$132994) == ((double) 0.0);
            
            //#line 145 "x10/lang/Complex.x10"
            if (t$132996) {
                
                //#line 145 "x10/lang/Complex.x10"
                final double t$132995 = this.im;
                
                //#line 145 "x10/lang/Complex.x10"
                t$132996 = ((double) t$132995) == ((double) 0.0);
            }
            
            //#line 145 "x10/lang/Complex.x10"
            if (t$132996) {
                
                //#line 146 "x10/lang/Complex.x10"
                final x10.lang.Complex t$132997 = ((x10.lang.Complex)(x10.lang.Complex.get$NaN()));
                
                //#line 146 "x10/lang/Complex.x10"
                return t$132997;
            } else {
                
                //#line 148 "x10/lang/Complex.x10"
                final x10.lang.Complex t$132998 = ((x10.lang.Complex)(x10.lang.Complex.get$INF()));
                
                //#line 148 "x10/lang/Complex.x10"
                return t$132998;
            }
        }
        
        //#line 152 "x10/lang/Complex.x10"
        boolean t$133002 = that.isInfinite$O();
        
        //#line 152 "x10/lang/Complex.x10"
        if (t$133002) {
            
            //#line 152 "x10/lang/Complex.x10"
            final boolean t$133001 = this.isInfinite$O();
            
            //#line 152 "x10/lang/Complex.x10"
            t$133002 = !(t$133001);
        }
        
        //#line 152 "x10/lang/Complex.x10"
        if (t$133002) {
            
            //#line 153 "x10/lang/Complex.x10"
            final x10.lang.Complex t$133003 = ((x10.lang.Complex)(x10.lang.Complex.get$ZERO()));
            
            //#line 153 "x10/lang/Complex.x10"
            return t$133003;
        }
        
        //#line 156 "x10/lang/Complex.x10"
        final double t$133005 = java.lang.Math.abs(((double)(d)));
        
        //#line 156 "x10/lang/Complex.x10"
        final double t$133006 = java.lang.Math.abs(((double)(c)));
        
        //#line 156 "x10/lang/Complex.x10"
        final boolean t$133044 = ((t$133005) <= (((double)(t$133006))));
        
        //#line 156 "x10/lang/Complex.x10"
        if (t$133044) {
            
            //#line 157 "x10/lang/Complex.x10"
            final boolean t$133013 = ((double) c) == ((double) 0.0);
            
            //#line 157 "x10/lang/Complex.x10"
            if (t$133013) {
                
                //#line 158 "x10/lang/Complex.x10"
                final double t$133007 = this.im;
                
                //#line 158 "x10/lang/Complex.x10"
                final double t$133010 = ((t$133007) / (((double)(d))));
                
                //#line 158 "x10/lang/Complex.x10"
                final double t$133008 = this.re;
                
                //#line 158 "x10/lang/Complex.x10"
                final double t$133009 = (-(t$133008));
                
                //#line 158 "x10/lang/Complex.x10"
                final double t$133011 = ((t$133009) / (((double)(c))));
                
                //#line 158 "x10/lang/Complex.x10"
                final x10.lang.Complex t$133012 = new x10.lang.Complex(t$133010, t$133011);
                
                //#line 158 "x10/lang/Complex.x10"
                return t$133012;
            }
            
            //#line 160 "x10/lang/Complex.x10"
            final double r = ((d) / (((double)(c))));
            
            //#line 161 "x10/lang/Complex.x10"
            final double t$133014 = ((d) * (((double)(r))));
            
            //#line 161 "x10/lang/Complex.x10"
            final double denominator = ((c) + (((double)(t$133014))));
            
            //#line 162 "x10/lang/Complex.x10"
            final double t$133016 = this.re;
            
            //#line 162 "x10/lang/Complex.x10"
            final double t$133015 = this.im;
            
            //#line 162 "x10/lang/Complex.x10"
            final double t$133017 = ((t$133015) * (((double)(r))));
            
            //#line 162 "x10/lang/Complex.x10"
            final double t$133018 = ((t$133016) + (((double)(t$133017))));
            
            //#line 162 "x10/lang/Complex.x10"
            final double t$133023 = ((t$133018) / (((double)(denominator))));
            
            //#line 163 "x10/lang/Complex.x10"
            final double t$133020 = this.im;
            
            //#line 163 "x10/lang/Complex.x10"
            final double t$133019 = this.re;
            
            //#line 163 "x10/lang/Complex.x10"
            final double t$133021 = ((t$133019) * (((double)(r))));
            
            //#line 163 "x10/lang/Complex.x10"
            final double t$133022 = ((t$133020) - (((double)(t$133021))));
            
            //#line 163 "x10/lang/Complex.x10"
            final double t$133024 = ((t$133022) / (((double)(denominator))));
            
            //#line 162 "x10/lang/Complex.x10"
            final x10.lang.Complex t$133025 = new x10.lang.Complex(t$133023, t$133024);
            
            //#line 162 "x10/lang/Complex.x10"
            return t$133025;
        } else {
            
            //#line 165 "x10/lang/Complex.x10"
            final boolean t$133031 = ((double) d) == ((double) 0.0);
            
            //#line 165 "x10/lang/Complex.x10"
            if (t$133031) {
                
                //#line 166 "x10/lang/Complex.x10"
                final double t$133026 = this.re;
                
                //#line 166 "x10/lang/Complex.x10"
                final double t$133028 = ((t$133026) / (((double)(c))));
                
                //#line 166 "x10/lang/Complex.x10"
                final double t$133027 = this.im;
                
                //#line 166 "x10/lang/Complex.x10"
                final double t$133029 = ((t$133027) / (((double)(c))));
                
                //#line 166 "x10/lang/Complex.x10"
                final x10.lang.Complex t$133030 = new x10.lang.Complex(t$133028, t$133029);
                
                //#line 166 "x10/lang/Complex.x10"
                return t$133030;
            }
            
            //#line 168 "x10/lang/Complex.x10"
            final double r = ((c) / (((double)(d))));
            
            //#line 169 "x10/lang/Complex.x10"
            final double t$133032 = ((c) * (((double)(r))));
            
            //#line 169 "x10/lang/Complex.x10"
            final double denominator = ((t$133032) + (((double)(d))));
            
            //#line 170 "x10/lang/Complex.x10"
            final double t$133033 = this.re;
            
            //#line 170 "x10/lang/Complex.x10"
            final double t$133034 = ((t$133033) * (((double)(r))));
            
            //#line 170 "x10/lang/Complex.x10"
            final double t$133035 = this.im;
            
            //#line 170 "x10/lang/Complex.x10"
            final double t$133036 = ((t$133034) + (((double)(t$133035))));
            
            //#line 170 "x10/lang/Complex.x10"
            final double t$133041 = ((t$133036) / (((double)(denominator))));
            
            //#line 171 "x10/lang/Complex.x10"
            final double t$133037 = this.im;
            
            //#line 171 "x10/lang/Complex.x10"
            final double t$133038 = ((t$133037) * (((double)(r))));
            
            //#line 171 "x10/lang/Complex.x10"
            final double t$133039 = this.re;
            
            //#line 171 "x10/lang/Complex.x10"
            final double t$133040 = ((t$133038) - (((double)(t$133039))));
            
            //#line 171 "x10/lang/Complex.x10"
            final double t$133042 = ((t$133040) / (((double)(denominator))));
            
            //#line 170 "x10/lang/Complex.x10"
            final x10.lang.Complex t$133043 = new x10.lang.Complex(t$133041, t$133042);
            
            //#line 170 "x10/lang/Complex.x10"
            return t$133043;
        }
    }
    
    
    //#line 178 "x10/lang/Complex.x10"
    /**
     * @return the quotient of the given double and this complex number.
     */
    final public static x10.lang.Complex $over(final double x, final x10.lang.Complex y) {
        
        //#line 179 "x10/lang/Complex.x10"
        final x10.lang.Complex t$133045 = new x10.lang.Complex(((double)(x)), ((double)(0.0)));
        
        //#line 179 "x10/lang/Complex.x10"
        final x10.lang.Complex t$133046 = t$133045.$over(((x10.lang.Complex)(y)));
        
        //#line 179 "x10/lang/Complex.x10"
        return t$133046;
    }
    
    
    //#line 184 "x10/lang/Complex.x10"
    /**
     * @return the quotient of this complex number and the given double.
     */
    final public x10.lang.Complex $over(final double that) {
        
        //#line 186 "x10/lang/Complex.x10"
        final double t$133047 = this.re;
        
        //#line 186 "x10/lang/Complex.x10"
        final double t$133049 = ((t$133047) / (((double)(that))));
        
        //#line 186 "x10/lang/Complex.x10"
        final double t$133048 = this.im;
        
        //#line 186 "x10/lang/Complex.x10"
        final double t$133050 = ((t$133048) / (((double)(that))));
        
        //#line 186 "x10/lang/Complex.x10"
        final x10.lang.Complex t$133051 = new x10.lang.Complex(t$133049, t$133050);
        
        //#line 186 "x10/lang/Complex.x10"
        return t$133051;
    }
    
    
    //#line 192 "x10/lang/Complex.x10"
    /**
     * @return the conjugate of this complex number.
     */
    final public x10.lang.Complex conjugate() {
        
        //#line 193 "x10/lang/Complex.x10"
        final double t$133053 = this.re;
        
        //#line 193 "x10/lang/Complex.x10"
        final double t$133052 = this.im;
        
        //#line 193 "x10/lang/Complex.x10"
        final double t$133054 = (-(t$133052));
        
        //#line 193 "x10/lang/Complex.x10"
        final x10.lang.Complex t$133055 = new x10.lang.Complex(((double)(t$133053)), t$133054);
        
        //#line 193 "x10/lang/Complex.x10"
        return t$133055;
    }
    
    
    //#line 198 "x10/lang/Complex.x10"
    /**
     * @return this complex number.
     */
    final public x10.lang.Complex $plus() {
        
        //#line 199 "x10/lang/Complex.x10"
        return this;
    }
    
    
    //#line 204 "x10/lang/Complex.x10"
    /**
     * @return the negation of this complex number.
     */
    final public x10.lang.Complex $minus() {
        
        //#line 205 "x10/lang/Complex.x10"
        final boolean t$133060 = this.isNaN$O();
        
        //#line 205 "x10/lang/Complex.x10"
        x10.lang.Complex t$133061 =  null;
        
        //#line 205 "x10/lang/Complex.x10"
        if (t$133060) {
            
            //#line 205 "x10/lang/Complex.x10"
            t$133061 = x10.lang.Complex.get$NaN();
        } else {
            
            //#line 205 "x10/lang/Complex.x10"
            final double t$133056 = this.re;
            
            //#line 205 "x10/lang/Complex.x10"
            final double t$133058 = (-(t$133056));
            
            //#line 205 "x10/lang/Complex.x10"
            final double t$133057 = this.im;
            
            //#line 205 "x10/lang/Complex.x10"
            final double t$133059 = (-(t$133057));
            
            //#line 205 "x10/lang/Complex.x10"
            t$133061 = new x10.lang.Complex(t$133058, t$133059);
        }
        
        //#line 205 "x10/lang/Complex.x10"
        return t$133061;
    }
    
    
    //#line 217 "x10/lang/Complex.x10"
    /**
     * Return the absolute value of this complex number.
     * <p>
     * Returns <code>NaN</code> if either the real or imaginary part is
     * <code>NaN</code> and <code>Double.POSITIVE_INFINITY</code> if
     * neither part is <code>NaN</code>, but at least one part takes an infinite
     * value.
     *
     * @return the absolute value of this complex number.
     */
    final public double abs$O() {
        
        //#line 219 "x10/lang/Complex.x10"
        final boolean t$133064 = this.isNaN$O();
        
        //#line 219 "x10/lang/Complex.x10"
        if (t$133064) {
            
            //#line 220 "x10/lang/Complex.x10"
            final double t$133063 = java.lang.Double.NaN;
            
            //#line 220 "x10/lang/Complex.x10"
            return t$133063;
        }
        
        //#line 223 "x10/lang/Complex.x10"
        final boolean t$133066 = this.isInfinite$O();
        
        //#line 223 "x10/lang/Complex.x10"
        if (t$133066) {
            
            //#line 224 "x10/lang/Complex.x10"
            final double t$133065 = java.lang.Double.POSITIVE_INFINITY;
            
            //#line 224 "x10/lang/Complex.x10"
            return t$133065;
        }
        
        //#line 227 "x10/lang/Complex.x10"
        final double t$133067 = this.im;
        
        //#line 227 "x10/lang/Complex.x10"
        final boolean t$133077 = ((double) t$133067) == ((double) 0.0);
        
        //#line 227 "x10/lang/Complex.x10"
        if (t$133077) {
            
            //#line 228 "x10/lang/Complex.x10"
            final double t$133068 = this.re;
            
            //#line 228 "x10/lang/Complex.x10"
            final double t$133069 = java.lang.Math.abs(((double)(t$133068)));
            
            //#line 228 "x10/lang/Complex.x10"
            return t$133069;
        } else {
            
            //#line 229 "x10/lang/Complex.x10"
            final double t$133070 = this.re;
            
            //#line 229 "x10/lang/Complex.x10"
            final boolean t$133076 = ((double) t$133070) == ((double) 0.0);
            
            //#line 229 "x10/lang/Complex.x10"
            if (t$133076) {
                
                //#line 230 "x10/lang/Complex.x10"
                final double t$133071 = this.im;
                
                //#line 230 "x10/lang/Complex.x10"
                final double t$133072 = java.lang.Math.abs(((double)(t$133071)));
                
                //#line 230 "x10/lang/Complex.x10"
                return t$133072;
            } else {
                
                //#line 233 "x10/lang/Complex.x10"
                final double t$133073 = this.re;
                
                //#line 233 "x10/lang/Complex.x10"
                final double t$133074 = this.im;
                
                //#line 233 "x10/lang/Complex.x10"
                final double t$133075 = java.lang.Math.hypot(((double)(t$133073)),((double)(t$133074)));
                
                //#line 233 "x10/lang/Complex.x10"
                return t$133075;
            }
        }
    }
    
    
    //#line 240 "x10/lang/Complex.x10"
    /**
     * @return true if either part of this complex number is <code>NaN</code>.
     */
    final public boolean isNaN$O() {
        
        //#line 242 "x10/lang/Complex.x10"
        final double t$133078 = this.re;
        
        //#line 242 "x10/lang/Complex.x10"
        boolean t$133080 = java.lang.Double.isNaN(t$133078);
        
        //#line 242 "x10/lang/Complex.x10"
        if (!(t$133080)) {
            
            //#line 242 "x10/lang/Complex.x10"
            final double t$133079 = this.im;
            
            //#line 242 "x10/lang/Complex.x10"
            t$133080 = java.lang.Double.isNaN(t$133079);
        }
        
        //#line 242 "x10/lang/Complex.x10"
        return t$133080;
    }
    
    
    //#line 249 "x10/lang/Complex.x10"
    /**
     * @return true if either part of this complex number is infinite
     * and neither part is <code>NaN</code>.
     */
    final public boolean isInfinite$O() {
        
        //#line 251 "x10/lang/Complex.x10"
        final boolean t$133082 = this.isNaN$O();
        
        //#line 251 "x10/lang/Complex.x10"
        boolean t$133086 = !(t$133082);
        
        //#line 251 "x10/lang/Complex.x10"
        if (t$133086) {
            
            //#line 252 "x10/lang/Complex.x10"
            final double t$133083 = this.re;
            
            //#line 252 "x10/lang/Complex.x10"
            boolean t$133085 = java.lang.Double.isInfinite(t$133083);
            
            //#line 252 "x10/lang/Complex.x10"
            if (!(t$133085)) {
                
                //#line 252 "x10/lang/Complex.x10"
                final double t$133084 = this.im;
                
                //#line 252 "x10/lang/Complex.x10"
                t$133085 = java.lang.Double.isInfinite(t$133084);
            }
            
            //#line 251 "x10/lang/Complex.x10"
            t$133086 = t$133085;
        }
        
        //#line 251 "x10/lang/Complex.x10"
        return t$133086;
    }
    
    
    //#line 258 "x10/lang/Complex.x10"
    /**
     * @return the string representation of this complex number.
     */
    final public java.lang.String toString() {
        
        //#line 260 "x10/lang/Complex.x10"
        final double t$133088 = this.re;
        
        //#line 260 "x10/lang/Complex.x10"
        final java.lang.String t$133089 = (("") + ((x10.core.Double.$box(t$133088))));
        
        //#line 260 "x10/lang/Complex.x10"
        final java.lang.String t$133090 = ((t$133089) + (" + "));
        
        //#line 260 "x10/lang/Complex.x10"
        final double t$133091 = this.im;
        
        //#line 260 "x10/lang/Complex.x10"
        final java.lang.String t$133092 = ((t$133090) + ((x10.core.Double.$box(t$133091))));
        
        //#line 260 "x10/lang/Complex.x10"
        final java.lang.String t$133093 = ((t$133092) + ("i"));
        
        //#line 260 "x10/lang/Complex.x10"
        return t$133093;
    }
    
    
    //#line 263 "x10/lang/Complex.x10"
    final public int hashCode() {
        
        //#line 265 "x10/lang/Complex.x10"
        final double t$133094 = this.re;
        
        //#line 265 "x10/lang/Complex.x10"
        final int t$133096 = x10.rtt.Types.hashCode(t$133094);
        
        //#line 265 "x10/lang/Complex.x10"
        final double t$133095 = this.im;
        
        //#line 265 "x10/lang/Complex.x10"
        final int t$133097 = x10.rtt.Types.hashCode(t$133095);
        
        //#line 265 "x10/lang/Complex.x10"
        final int t$133098 = ((t$133096) * (((int)(t$133097))));
        
        //#line 265 "x10/lang/Complex.x10"
        return t$133098;
    }
    
    
    //#line 25 "x10/lang/Complex.x10"
    final public java.lang.String typeName() {
        try {
            return x10.rtt.Types.typeName(this);
        }
        catch (java.lang.Throwable exc$206365) {
            throw x10.runtime.impl.java.ThrowableUtils.ensureX10Exception(exc$206365);
        }
        
    }
    
    
    
    //#line 25 "x10/lang/Complex.x10"
    final public boolean equals(java.lang.Object other) {
        
        //#line 25 "x10/lang/Complex.x10"
        final boolean t$133100 = x10.lang.Complex.$RTT.isInstance(other);
        
        //#line 25 "x10/lang/Complex.x10"
        final boolean t$133101 = !(t$133100);
        
        //#line 25 "x10/lang/Complex.x10"
        if (t$133101) {
            
            //#line 25 "x10/lang/Complex.x10"
            return false;
        }
        
        //#line 25 "x10/lang/Complex.x10"
        final x10.lang.Complex t$133103 = ((x10.lang.Complex)x10.rtt.Types.asStruct(x10.lang.Complex.$RTT,other));
        
        //#line 25 "x10/lang/Complex.x10"
        final boolean t$133104 = this.equals$O(((x10.lang.Complex)(t$133103)));
        
        //#line 25 "x10/lang/Complex.x10"
        return t$133104;
    }
    
    
    //#line 25 "x10/lang/Complex.x10"
    final public boolean equals$O(x10.lang.Complex other) {
        
        //#line 25 "x10/lang/Complex.x10"
        final double t$133106 = this.re;
        
        //#line 25 "x10/lang/Complex.x10"
        final double t$133107 = other.re;
        
        //#line 25 "x10/lang/Complex.x10"
        boolean t$133111 = ((double) t$133106) == ((double) t$133107);
        
        //#line 25 "x10/lang/Complex.x10"
        if (t$133111) {
            
            //#line 25 "x10/lang/Complex.x10"
            final double t$133109 = this.im;
            
            //#line 25 "x10/lang/Complex.x10"
            final double t$133110 = other.im;
            
            //#line 25 "x10/lang/Complex.x10"
            t$133111 = ((double) t$133109) == ((double) t$133110);
        }
        
        //#line 25 "x10/lang/Complex.x10"
        return t$133111;
    }
    
    
    //#line 25 "x10/lang/Complex.x10"
    final public boolean _struct_equals$O(java.lang.Object other) {
        
        //#line 25 "x10/lang/Complex.x10"
        final boolean t$133114 = x10.lang.Complex.$RTT.isInstance(other);
        
        //#line 25 "x10/lang/Complex.x10"
        final boolean t$133115 = !(t$133114);
        
        //#line 25 "x10/lang/Complex.x10"
        if (t$133115) {
            
            //#line 25 "x10/lang/Complex.x10"
            return false;
        }
        
        //#line 25 "x10/lang/Complex.x10"
        final x10.lang.Complex t$133117 = ((x10.lang.Complex)x10.rtt.Types.asStruct(x10.lang.Complex.$RTT,other));
        
        //#line 25 "x10/lang/Complex.x10"
        final boolean t$133118 = this._struct_equals$O(((x10.lang.Complex)(t$133117)));
        
        //#line 25 "x10/lang/Complex.x10"
        return t$133118;
    }
    
    
    //#line 25 "x10/lang/Complex.x10"
    final public boolean _struct_equals$O(x10.lang.Complex other) {
        
        //#line 25 "x10/lang/Complex.x10"
        final double t$133120 = this.re;
        
        //#line 25 "x10/lang/Complex.x10"
        final double t$133121 = other.re;
        
        //#line 25 "x10/lang/Complex.x10"
        boolean t$133125 = ((double) t$133120) == ((double) t$133121);
        
        //#line 25 "x10/lang/Complex.x10"
        if (t$133125) {
            
            //#line 25 "x10/lang/Complex.x10"
            final double t$133123 = this.im;
            
            //#line 25 "x10/lang/Complex.x10"
            final double t$133124 = other.im;
            
            //#line 25 "x10/lang/Complex.x10"
            t$133125 = ((double) t$133123) == ((double) t$133124);
        }
        
        //#line 25 "x10/lang/Complex.x10"
        return t$133125;
    }
    
    
    //#line 24 "x10/lang/Complex.x10"
    final public x10.lang.Complex x10$lang$Complex$$this$x10$lang$Complex() {
        
        //#line 24 "x10/lang/Complex.x10"
        return x10.lang.Complex.this;
    }
    
    
    //#line 24 "x10/lang/Complex.x10"
    final public void __fieldInitializers_x10_lang_Complex() {
        
    }
    
    final private static x10.core.concurrent.AtomicInteger initStatus$NaN = new x10.core.concurrent.AtomicInteger(x10.runtime.impl.java.InitDispatcher.UNINITIALIZED);
    private static x10.lang.ExceptionInInitializer exception$NaN;
    final private static x10.core.concurrent.AtomicInteger initStatus$INF = new x10.core.concurrent.AtomicInteger(x10.runtime.impl.java.InitDispatcher.UNINITIALIZED);
    private static x10.lang.ExceptionInInitializer exception$INF;
    final private static x10.core.concurrent.AtomicInteger initStatus$I = new x10.core.concurrent.AtomicInteger(x10.runtime.impl.java.InitDispatcher.UNINITIALIZED);
    private static x10.lang.ExceptionInInitializer exception$I;
    final private static x10.core.concurrent.AtomicInteger initStatus$ONE = new x10.core.concurrent.AtomicInteger(x10.runtime.impl.java.InitDispatcher.UNINITIALIZED);
    private static x10.lang.ExceptionInInitializer exception$ONE;
    final private static x10.core.concurrent.AtomicInteger initStatus$ZERO = new x10.core.concurrent.AtomicInteger(x10.runtime.impl.java.InitDispatcher.UNINITIALIZED);
    private static x10.lang.ExceptionInInitializer exception$ZERO;
    
    public static x10.lang.Complex get$ZERO() {
        if (((int) x10.lang.Complex.initStatus$ZERO.get()) == ((int) x10.runtime.impl.java.InitDispatcher.INITIALIZED)) {
            return x10.lang.Complex.ZERO;
        }
        if (((int) x10.lang.Complex.initStatus$ZERO.get()) == ((int) x10.runtime.impl.java.InitDispatcher.EXCEPTION_RAISED)) {
            throw x10.lang.Complex.exception$ZERO;
        }
        if (x10.lang.Complex.initStatus$ZERO.compareAndSet((int)(x10.runtime.impl.java.InitDispatcher.UNINITIALIZED), (int)(x10.runtime.impl.java.InitDispatcher.INITIALIZING))) {
            try {{
                x10.lang.Complex.ZERO = new x10.lang.Complex(((double)(0.0)), ((double)(0.0)));
            }}catch (java.lang.Throwable exc$133127) {
                x10.lang.Complex.exception$ZERO = new x10.lang.ExceptionInInitializer(exc$133127);
                x10.lang.Complex.initStatus$ZERO.set((int)(x10.runtime.impl.java.InitDispatcher.EXCEPTION_RAISED));
                x10.runtime.impl.java.InitDispatcher.lockInitialized();
                x10.runtime.impl.java.InitDispatcher.notifyInitialized();
                throw x10.lang.Complex.exception$ZERO;
            }
            x10.lang.Complex.initStatus$ZERO.set((int)(x10.runtime.impl.java.InitDispatcher.INITIALIZED));
            x10.runtime.impl.java.InitDispatcher.lockInitialized();
            x10.runtime.impl.java.InitDispatcher.notifyInitialized();
        } else {
            if (x10.lang.Complex.initStatus$ZERO.get() < x10.runtime.impl.java.InitDispatcher.INITIALIZED) {
                x10.runtime.impl.java.InitDispatcher.lockInitialized();
                while (x10.lang.Complex.initStatus$ZERO.get() < x10.runtime.impl.java.InitDispatcher.INITIALIZED) {
                    x10.runtime.impl.java.InitDispatcher.awaitInitialized();
                }
                x10.runtime.impl.java.InitDispatcher.unlockInitialized();
                if (((int) x10.lang.Complex.initStatus$ZERO.get()) == ((int) x10.runtime.impl.java.InitDispatcher.EXCEPTION_RAISED)) {
                    throw x10.lang.Complex.exception$ZERO;
                }
            }
        }
        return x10.lang.Complex.ZERO;
    }
    
    public static x10.lang.Complex get$ONE() {
        if (((int) x10.lang.Complex.initStatus$ONE.get()) == ((int) x10.runtime.impl.java.InitDispatcher.INITIALIZED)) {
            return x10.lang.Complex.ONE;
        }
        if (((int) x10.lang.Complex.initStatus$ONE.get()) == ((int) x10.runtime.impl.java.InitDispatcher.EXCEPTION_RAISED)) {
            throw x10.lang.Complex.exception$ONE;
        }
        if (x10.lang.Complex.initStatus$ONE.compareAndSet((int)(x10.runtime.impl.java.InitDispatcher.UNINITIALIZED), (int)(x10.runtime.impl.java.InitDispatcher.INITIALIZING))) {
            try {{
                x10.lang.Complex.ONE = new x10.lang.Complex(((double)(1.0)), ((double)(0.0)));
            }}catch (java.lang.Throwable exc$133128) {
                x10.lang.Complex.exception$ONE = new x10.lang.ExceptionInInitializer(exc$133128);
                x10.lang.Complex.initStatus$ONE.set((int)(x10.runtime.impl.java.InitDispatcher.EXCEPTION_RAISED));
                x10.runtime.impl.java.InitDispatcher.lockInitialized();
                x10.runtime.impl.java.InitDispatcher.notifyInitialized();
                throw x10.lang.Complex.exception$ONE;
            }
            x10.lang.Complex.initStatus$ONE.set((int)(x10.runtime.impl.java.InitDispatcher.INITIALIZED));
            x10.runtime.impl.java.InitDispatcher.lockInitialized();
            x10.runtime.impl.java.InitDispatcher.notifyInitialized();
        } else {
            if (x10.lang.Complex.initStatus$ONE.get() < x10.runtime.impl.java.InitDispatcher.INITIALIZED) {
                x10.runtime.impl.java.InitDispatcher.lockInitialized();
                while (x10.lang.Complex.initStatus$ONE.get() < x10.runtime.impl.java.InitDispatcher.INITIALIZED) {
                    x10.runtime.impl.java.InitDispatcher.awaitInitialized();
                }
                x10.runtime.impl.java.InitDispatcher.unlockInitialized();
                if (((int) x10.lang.Complex.initStatus$ONE.get()) == ((int) x10.runtime.impl.java.InitDispatcher.EXCEPTION_RAISED)) {
                    throw x10.lang.Complex.exception$ONE;
                }
            }
        }
        return x10.lang.Complex.ONE;
    }
    
    public static x10.lang.Complex get$I() {
        if (((int) x10.lang.Complex.initStatus$I.get()) == ((int) x10.runtime.impl.java.InitDispatcher.INITIALIZED)) {
            return x10.lang.Complex.I;
        }
        if (((int) x10.lang.Complex.initStatus$I.get()) == ((int) x10.runtime.impl.java.InitDispatcher.EXCEPTION_RAISED)) {
            throw x10.lang.Complex.exception$I;
        }
        if (x10.lang.Complex.initStatus$I.compareAndSet((int)(x10.runtime.impl.java.InitDispatcher.UNINITIALIZED), (int)(x10.runtime.impl.java.InitDispatcher.INITIALIZING))) {
            try {{
                x10.lang.Complex.I = new x10.lang.Complex(((double)(0.0)), ((double)(1.0)));
            }}catch (java.lang.Throwable exc$133129) {
                x10.lang.Complex.exception$I = new x10.lang.ExceptionInInitializer(exc$133129);
                x10.lang.Complex.initStatus$I.set((int)(x10.runtime.impl.java.InitDispatcher.EXCEPTION_RAISED));
                x10.runtime.impl.java.InitDispatcher.lockInitialized();
                x10.runtime.impl.java.InitDispatcher.notifyInitialized();
                throw x10.lang.Complex.exception$I;
            }
            x10.lang.Complex.initStatus$I.set((int)(x10.runtime.impl.java.InitDispatcher.INITIALIZED));
            x10.runtime.impl.java.InitDispatcher.lockInitialized();
            x10.runtime.impl.java.InitDispatcher.notifyInitialized();
        } else {
            if (x10.lang.Complex.initStatus$I.get() < x10.runtime.impl.java.InitDispatcher.INITIALIZED) {
                x10.runtime.impl.java.InitDispatcher.lockInitialized();
                while (x10.lang.Complex.initStatus$I.get() < x10.runtime.impl.java.InitDispatcher.INITIALIZED) {
                    x10.runtime.impl.java.InitDispatcher.awaitInitialized();
                }
                x10.runtime.impl.java.InitDispatcher.unlockInitialized();
                if (((int) x10.lang.Complex.initStatus$I.get()) == ((int) x10.runtime.impl.java.InitDispatcher.EXCEPTION_RAISED)) {
                    throw x10.lang.Complex.exception$I;
                }
            }
        }
        return x10.lang.Complex.I;
    }
    
    public static x10.lang.Complex get$INF() {
        if (((int) x10.lang.Complex.initStatus$INF.get()) == ((int) x10.runtime.impl.java.InitDispatcher.INITIALIZED)) {
            return x10.lang.Complex.INF;
        }
        if (((int) x10.lang.Complex.initStatus$INF.get()) == ((int) x10.runtime.impl.java.InitDispatcher.EXCEPTION_RAISED)) {
            throw x10.lang.Complex.exception$INF;
        }
        if (x10.lang.Complex.initStatus$INF.compareAndSet((int)(x10.runtime.impl.java.InitDispatcher.UNINITIALIZED), (int)(x10.runtime.impl.java.InitDispatcher.INITIALIZING))) {
            try {{
                x10.lang.Complex.INF = new x10.lang.Complex(((double)(java.lang.Double.POSITIVE_INFINITY)), ((double)(java.lang.Double.POSITIVE_INFINITY)));
            }}catch (java.lang.Throwable exc$133130) {
                x10.lang.Complex.exception$INF = new x10.lang.ExceptionInInitializer(exc$133130);
                x10.lang.Complex.initStatus$INF.set((int)(x10.runtime.impl.java.InitDispatcher.EXCEPTION_RAISED));
                x10.runtime.impl.java.InitDispatcher.lockInitialized();
                x10.runtime.impl.java.InitDispatcher.notifyInitialized();
                throw x10.lang.Complex.exception$INF;
            }
            x10.lang.Complex.initStatus$INF.set((int)(x10.runtime.impl.java.InitDispatcher.INITIALIZED));
            x10.runtime.impl.java.InitDispatcher.lockInitialized();
            x10.runtime.impl.java.InitDispatcher.notifyInitialized();
        } else {
            if (x10.lang.Complex.initStatus$INF.get() < x10.runtime.impl.java.InitDispatcher.INITIALIZED) {
                x10.runtime.impl.java.InitDispatcher.lockInitialized();
                while (x10.lang.Complex.initStatus$INF.get() < x10.runtime.impl.java.InitDispatcher.INITIALIZED) {
                    x10.runtime.impl.java.InitDispatcher.awaitInitialized();
                }
                x10.runtime.impl.java.InitDispatcher.unlockInitialized();
                if (((int) x10.lang.Complex.initStatus$INF.get()) == ((int) x10.runtime.impl.java.InitDispatcher.EXCEPTION_RAISED)) {
                    throw x10.lang.Complex.exception$INF;
                }
            }
        }
        return x10.lang.Complex.INF;
    }
    
    public static x10.lang.Complex get$NaN() {
        if (((int) x10.lang.Complex.initStatus$NaN.get()) == ((int) x10.runtime.impl.java.InitDispatcher.INITIALIZED)) {
            return x10.lang.Complex.NaN;
        }
        if (((int) x10.lang.Complex.initStatus$NaN.get()) == ((int) x10.runtime.impl.java.InitDispatcher.EXCEPTION_RAISED)) {
            throw x10.lang.Complex.exception$NaN;
        }
        if (x10.lang.Complex.initStatus$NaN.compareAndSet((int)(x10.runtime.impl.java.InitDispatcher.UNINITIALIZED), (int)(x10.runtime.impl.java.InitDispatcher.INITIALIZING))) {
            try {{
                x10.lang.Complex.NaN = new x10.lang.Complex(((double)(java.lang.Double.NaN)), ((double)(java.lang.Double.NaN)));
            }}catch (java.lang.Throwable exc$133131) {
                x10.lang.Complex.exception$NaN = new x10.lang.ExceptionInInitializer(exc$133131);
                x10.lang.Complex.initStatus$NaN.set((int)(x10.runtime.impl.java.InitDispatcher.EXCEPTION_RAISED));
                x10.runtime.impl.java.InitDispatcher.lockInitialized();
                x10.runtime.impl.java.InitDispatcher.notifyInitialized();
                throw x10.lang.Complex.exception$NaN;
            }
            x10.lang.Complex.initStatus$NaN.set((int)(x10.runtime.impl.java.InitDispatcher.INITIALIZED));
            x10.runtime.impl.java.InitDispatcher.lockInitialized();
            x10.runtime.impl.java.InitDispatcher.notifyInitialized();
        } else {
            if (x10.lang.Complex.initStatus$NaN.get() < x10.runtime.impl.java.InitDispatcher.INITIALIZED) {
                x10.runtime.impl.java.InitDispatcher.lockInitialized();
                while (x10.lang.Complex.initStatus$NaN.get() < x10.runtime.impl.java.InitDispatcher.INITIALIZED) {
                    x10.runtime.impl.java.InitDispatcher.awaitInitialized();
                }
                x10.runtime.impl.java.InitDispatcher.unlockInitialized();
                if (((int) x10.lang.Complex.initStatus$NaN.get()) == ((int) x10.runtime.impl.java.InitDispatcher.EXCEPTION_RAISED)) {
                    throw x10.lang.Complex.exception$NaN;
                }
            }
        }
        return x10.lang.Complex.NaN;
    }
}

