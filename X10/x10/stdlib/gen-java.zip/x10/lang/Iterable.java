package x10.lang;


/**
 * The compiler accepts the syntax 'for (x in s)' if x is a formal
 * parameter of type T, and if s implements Iterable[T].
 */
@x10.runtime.impl.java.X10Generated
public interface Iterable<$T> extends x10.core.Any
{
    public static final x10.rtt.RuntimeType<Iterable> $RTT = 
        x10.rtt.NamedType.<Iterable> make("x10.lang.Iterable",
                                          Iterable.class,
                                          1);
    
    

    
    
    //#line 22 "x10/lang/Iterable.x10"
    x10.lang.Iterator iterator();
}

