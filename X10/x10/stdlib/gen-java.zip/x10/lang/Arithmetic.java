package x10.lang;


/**
 * A set of common arithmetic operations.
 */
@x10.runtime.impl.java.X10Generated
public interface Arithmetic<$T> extends x10.core.Any
{
    public static final x10.rtt.RuntimeType<Arithmetic> $RTT = 
        x10.rtt.NamedType.<Arithmetic> make("x10.lang.Arithmetic",
                                            Arithmetic.class,
                                            1);
    
    

    
    
    //#line 27 "x10/lang/Arithmetic.x10"
    /**
     * A unary plus operator.
     * A no-op.
     * @return the value of the current entity.
     */
    $T $plus$G();
    
    
    //#line 35 "x10/lang/Arithmetic.x10"
    /**
     * A unary minus operator.
     * Negates the operand.
     * @return the negated value of the current entity.
     */
    $T $minus$G();
    
    
    //#line 44 "x10/lang/Arithmetic.x10"
    /**
     * A binary plus operator.
     * Computes the result of the addition of the two operands.
     * @param that the other entity
     * @return the sum of the current entity and the other entity.
     */
    java.lang.Object $plus(final java.lang.Object that, x10.rtt.Type t1);
    
    
    //#line 53 "x10/lang/Arithmetic.x10"
    /**
     * A binary minus operator.
     * Computes the result of the subtraction of the two operands.
     * @param that the other entity
     * @return the difference of the current entity and the other entity.
     */
    java.lang.Object $minus(final java.lang.Object that, x10.rtt.Type t1);
    
    
    //#line 62 "x10/lang/Arithmetic.x10"
    /**
     * A binary multiply operator.
     * Computes the result of the multiplication of the two operands.
     * @param that the other entity
     * @return the product of the current entity and the other entity.
     */
    java.lang.Object $times(final java.lang.Object that, x10.rtt.Type t1);
    
    
    //#line 71 "x10/lang/Arithmetic.x10"
    /**
     * A binary divide operator.
     * Computes the result of the division of the two operands.
     * @param that the other entity
     * @return the quotient of the current entity and the other entity.
     */
    java.lang.Object $over(final java.lang.Object that, x10.rtt.Type t1);
}

