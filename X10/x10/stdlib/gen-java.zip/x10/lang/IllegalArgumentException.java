package x10.lang;


/**
 * Thrown to indicate that a method has been passed an illegal or inappropriate argument.
 */
;

