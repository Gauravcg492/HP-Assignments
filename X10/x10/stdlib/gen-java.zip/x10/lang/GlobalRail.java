package x10.lang;


/**
 * A struct that adds size information to a GlobalRef[Rail[T]]
 * in order to enable safe DMA operations via Rail.asyncCopy.
 * 
 * The following relationship will always be true, but is not expressible
 * due to limitations of the current implementations of constrained types in X10.
 * <pre>
 * this.size == this.rail().size
 * </pre>
 */
@x10.runtime.impl.java.X10Generated
final public class GlobalRail<$T> extends x10.core.Struct implements x10.serialization.X10JavaSerializable
{
    public static final x10.rtt.RuntimeType<GlobalRail> $RTT = 
        x10.rtt.NamedStructType.<GlobalRail> make("x10.lang.GlobalRail",
                                                  GlobalRail.class,
                                                  1,
                                                  new x10.rtt.Type[] {
                                                      x10.rtt.Types.STRUCT
                                                  });
    
    public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
    
    public x10.rtt.Type<?> $getParam(int i) { if (i == 0) return $T; return null; }
    
    private Object writeReplace() throws java.io.ObjectStreamException {
        return new x10.serialization.SerializationProxy(this);
    }
    
    public static <$T> x10.serialization.X10JavaSerializable $_deserialize_body(x10.lang.GlobalRail<$T> $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
        $_obj.$T = (x10.rtt.Type) $deserializer.readObject();
        $_obj.rail = $deserializer.readObject();
        $_obj.size = $deserializer.readLong();
        return $_obj;
    }
    
    public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
        x10.lang.GlobalRail $_obj = new x10.lang.GlobalRail((java.lang.System[]) null, (x10.rtt.Type) null);
        return $_deserialize_body($_obj, $deserializer);
    }
    
    public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
        $serializer.write(this.$T);
        $serializer.write(this.rail);
        $serializer.write(this.size);
        
    }
    
    // zero value constructor
    public GlobalRail(final x10.rtt.Type $T, final java.lang.System $dummy) { this.$T = $T; this.size = 0L; this.rail = new x10.core.GlobalRef<x10.core.Rail<$T>>(x10.rtt.ParameterizedType.make(x10.core.Rail.$RTT, $T), $dummy); }
    
    // constructor just for allocation
    public GlobalRail(final java.lang.System[] $dummy, final x10.rtt.Type $T) {
        x10.lang.GlobalRail.$initParams(this, $T);
        
    }
    
    private x10.rtt.Type $T;
    
    // initializer of type parameters
    public static void $initParams(final GlobalRail $this, final x10.rtt.Type $T) {
        $this.$T = $T;
        
    }
    // synthetic type for parameter mangling
    public static final class __0$1x10$lang$GlobalRail$$T$2 {}
    // synthetic type for parameter mangling
    public static final class __1$1x10$lang$Rail$1x10$lang$GlobalRail$$T$2$2 {}
    
    // properties
    
    //#line 33 "x10/lang/GlobalRail.x10"
    /**
         * The size of the remote rail.
         */
    public long size;
    
    //#line 37 "x10/lang/GlobalRail.x10"
    /**
         * The GlobalRef to the remote rail.
         */
    public x10.core.GlobalRef<x10.core.Rail<$T>> rail;
    

    
    
    //#line 43 "x10/lang/GlobalRail.x10"
    /**
     * The home location of the GlobalRail is equal to rail.home
     */
    final public x10.lang.Place home() {
        
        //#line 43 "x10/lang/GlobalRail.x10"
        final x10.core.GlobalRef t$133429 = ((x10.core.GlobalRef)(this.rail));
        
        //#line 43 "x10/lang/GlobalRail.x10"
        final x10.lang.Place t$133430 = ((x10.lang.Place)((t$133429).home));
        
        //#line 43 "x10/lang/GlobalRail.x10"
        return t$133430;
    }
    
    
    //#line 49 "x10/lang/GlobalRail.x10"
    /**
     * Create a GlobalRail wrapping the local Rail argument.
     * @param a The rail object to make accessible remotely.
     */
    // creation method for java code (1-phase java constructor)
    public GlobalRail(final x10.rtt.Type $T, final x10.core.Rail<$T> a, __0$1x10$lang$GlobalRail$$T$2 $dummy) {
        this((java.lang.System[]) null, $T);
        x10$lang$GlobalRail$$init$S(a, (x10.lang.GlobalRail.__0$1x10$lang$GlobalRail$$T$2) null);
    }
    
    // constructor for non-virtual call
    final public x10.lang.GlobalRail<$T> x10$lang$GlobalRail$$init$S(final x10.core.Rail<$T> a, __0$1x10$lang$GlobalRail$$T$2 $dummy) {
         {
            
            //#line 50 "x10/lang/GlobalRail.x10"
            final long t$133517 = ((x10.core.Rail<$T>)a).size;
            
            //#line 50 "x10/lang/GlobalRail.x10"
            final x10.core.GlobalRef t$133518 = ((x10.core.GlobalRef)(new x10.core.GlobalRef<x10.core.Rail<$T>>(x10.rtt.ParameterizedType.make(x10.core.Rail.$RTT, $T), ((x10.core.Rail)(a)), (x10.core.GlobalRef.__0x10$lang$GlobalRef$$T) null)));
            
            //#line 50 "x10/lang/GlobalRail.x10"
            this.size = t$133517;
            this.rail = t$133518;
            
            {
                
            }
        }
        return this;
    }
    
    
    
    //#line 62 "x10/lang/GlobalRail.x10"
    /** 
     * Called when the Rail referred to by the GlobalRail is no 
     * longer accesible from other places and therefore can
     * be removed from the data sturctures that keep objects
     * alive even when they are not live locally. 
     * Can only be invoked at the place at which the value was
     * created. 
     */
    final public void forget() {
        
        //#line 63 "x10/lang/GlobalRail.x10"
        final x10.core.GlobalRef t$133435 = ((x10.core.GlobalRef)(this.rail));
        
        //#line 63 "x10/lang/GlobalRail.x10"
        (((x10.core.GlobalRef<x10.core.Rail<$T>>)(t$133435))).forget();
    }
    
    
    //#line 73 "x10/lang/GlobalRail.x10"
    /**
     * Create a GlobalRail using a raw size and remote rail.  This is unsafe
     * since it may be used to violate the (unenforced) constraint that
     * self.size == self.rail().size.  However it is required internally
     * by the CUDA runtime, where it is accesed directly from C++ to
     * bypass the 'private' and is also used by Unsafe.
     */
    // creation method for java code (1-phase java constructor)
    public GlobalRail(final x10.rtt.Type $T, final long size, final x10.core.GlobalRef<x10.core.Rail<$T>> raw, __1$1x10$lang$Rail$1x10$lang$GlobalRail$$T$2$2 $dummy) {
        this((java.lang.System[]) null, $T);
        x10$lang$GlobalRail$$init$S(size, raw, (x10.lang.GlobalRail.__1$1x10$lang$Rail$1x10$lang$GlobalRail$$T$2$2) null);
    }
    
    // constructor for non-virtual call
    final public x10.lang.GlobalRail<$T> x10$lang$GlobalRail$$init$S(final long size, final x10.core.GlobalRef<x10.core.Rail<$T>> raw, __1$1x10$lang$Rail$1x10$lang$GlobalRail$$T$2$2 $dummy) {
         {
            
            //#line 74 "x10/lang/GlobalRail.x10"
            this.size = size;
            this.rail = raw;
            
            {
                
            }
        }
        return this;
    }
    
    
    
    //#line 85 "x10/lang/GlobalRail.x10"
    /**
     * Return the element of this rail corresponding to the given index.
     * Can only be called where <code>here == rail.home</code>. 
     * 
     * @param index the given index
     * @return the element of this rail corresponding to the given index.
     */
    final public $T $apply$G(final long index) {
        
        //#line 86 "x10/lang/GlobalRail.x10"
        final x10.core.Rail t$133438 = ((x10.core.Rail)(((x10.core.Rail<$T>)
                                                          this.$apply())));
        
        //#line 86 "x10/lang/GlobalRail.x10"
        final $T t$133439 = (($T)(((x10.core.Rail<$T>)t$133438).$apply$G((long)(index))));
        
        //#line 86 "x10/lang/GlobalRail.x10"
        return t$133439;
    }
    
    
    //#line 97 "x10/lang/GlobalRail.x10"
    /**
     * Set the element of this rail corresponding to the given index to the given value.
     * Return the new value of the element.
     * Can only  be called where <code>here == rail.home</code>. 
     * 
     * @param v the given value
     * @param i0 the given index in the first dimension
     * @return the new value of the element of this rail corresponding to the given index.
     */
    final public $T $set__1x10$lang$GlobalRail$$T$G(final long index, final $T v) {
        
        //#line 98 "x10/lang/GlobalRail.x10"
        final x10.core.Rail t$133442 = ((x10.core.Rail)(((x10.core.Rail<$T>)
                                                          this.$apply())));
        
        //#line 98 "x10/lang/GlobalRail.x10"
        final $T t$133443 = (($T)(((x10.core.Rail<$T>)t$133442).$set__1x10$lang$Rail$$T$G((long)(index), (($T)(v)))));
        
        //#line 98 "x10/lang/GlobalRail.x10"
        return t$133443;
    }
    
    
    //#line 104 "x10/lang/GlobalRail.x10"
    /**
     * Access the Rail that is encapsulated by this GlobalRail. 
     * Can only  be called where <code>here == rail.home</code>. 
     */
    final public x10.core.Rail $apply() {
        
        //#line 105 "x10/lang/GlobalRail.x10"
        final x10.core.GlobalRef t$133446 = ((x10.core.GlobalRef)(this.rail));
        
        //#line 105 "x10/lang/GlobalRail.x10"
        final x10.core.Rail t$133447 = ((x10.core.Rail)((((x10.core.GlobalRef<x10.core.Rail<$T>>)(t$133446))).$apply$G()));
        
        //#line 105 "x10/lang/GlobalRail.x10"
        return t$133447;
    }
    
    
    //#line 119 "x10/lang/GlobalRail.x10"
    final public static void remoteAdd__0$1x10$lang$ULong$2__2$u(final x10.lang.GlobalRail<x10.core.ULong> target, final long idx, final long v) {
        
        //#line 43 . "x10/lang/GlobalRail.x10"
        final x10.core.GlobalRef t$133448 = ((x10.core.GlobalRef)(((x10.lang.GlobalRail<x10.core.ULong>)target).rail));
        
        //#line 43 . "x10/lang/GlobalRail.x10"
        final x10.lang.Place t$133450 = ((x10.lang.Place)((t$133448).home));
        {
            
            //#line 121 "x10/lang/GlobalRail.x10"
            x10.xrx.Runtime.runAt(((x10.lang.Place)(t$133450)), ((x10.core.fun.VoidFun_0_0)(new x10.lang.GlobalRail.$Closure$155(target, idx, v, (x10.lang.GlobalRail.$Closure$155.__0$1x10$lang$ULong$2__2$u) null))), ((x10.xrx.Runtime.Profile)(null)));
        }
    }
    
    
    //#line 125 "x10/lang/GlobalRail.x10"
    final public static void remoteAdd__0$1x10$lang$Long$2(final x10.lang.GlobalRail<x10.core.Long> target, final long idx, final long v) {
        
        //#line 43 . "x10/lang/GlobalRail.x10"
        final x10.core.GlobalRef t$133451 = ((x10.core.GlobalRef)(((x10.lang.GlobalRail<x10.core.Long>)target).rail));
        
        //#line 43 . "x10/lang/GlobalRail.x10"
        final x10.lang.Place t$133453 = ((x10.lang.Place)((t$133451).home));
        {
            
            //#line 127 "x10/lang/GlobalRail.x10"
            x10.xrx.Runtime.runAt(((x10.lang.Place)(t$133453)), ((x10.core.fun.VoidFun_0_0)(new x10.lang.GlobalRail.$Closure$156(target, idx, v, (x10.lang.GlobalRail.$Closure$156.__0$1x10$lang$Long$2) null))), ((x10.xrx.Runtime.Profile)(null)));
        }
    }
    
    
    //#line 131 "x10/lang/GlobalRail.x10"
    final public static void remoteAnd__0$1x10$lang$ULong$2__2$u(final x10.lang.GlobalRail<x10.core.ULong> target, final long idx, final long v) {
        
        //#line 43 . "x10/lang/GlobalRail.x10"
        final x10.core.GlobalRef t$133454 = ((x10.core.GlobalRef)(((x10.lang.GlobalRail<x10.core.ULong>)target).rail));
        
        //#line 43 . "x10/lang/GlobalRail.x10"
        final x10.lang.Place t$133456 = ((x10.lang.Place)((t$133454).home));
        {
            
            //#line 133 "x10/lang/GlobalRail.x10"
            x10.xrx.Runtime.runAt(((x10.lang.Place)(t$133456)), ((x10.core.fun.VoidFun_0_0)(new x10.lang.GlobalRail.$Closure$157(target, idx, v, (x10.lang.GlobalRail.$Closure$157.__0$1x10$lang$ULong$2__2$u) null))), ((x10.xrx.Runtime.Profile)(null)));
        }
    }
    
    
    //#line 137 "x10/lang/GlobalRail.x10"
    final public static void remoteAnd__0$1x10$lang$Long$2(final x10.lang.GlobalRail<x10.core.Long> target, final long idx, final long v) {
        
        //#line 43 . "x10/lang/GlobalRail.x10"
        final x10.core.GlobalRef t$133457 = ((x10.core.GlobalRef)(((x10.lang.GlobalRail<x10.core.Long>)target).rail));
        
        //#line 43 . "x10/lang/GlobalRail.x10"
        final x10.lang.Place t$133459 = ((x10.lang.Place)((t$133457).home));
        {
            
            //#line 139 "x10/lang/GlobalRail.x10"
            x10.xrx.Runtime.runAt(((x10.lang.Place)(t$133459)), ((x10.core.fun.VoidFun_0_0)(new x10.lang.GlobalRail.$Closure$158(target, idx, v, (x10.lang.GlobalRail.$Closure$158.__0$1x10$lang$Long$2) null))), ((x10.xrx.Runtime.Profile)(null)));
        }
    }
    
    
    //#line 143 "x10/lang/GlobalRail.x10"
    final public static void remoteOr__0$1x10$lang$ULong$2__2$u(final x10.lang.GlobalRail<x10.core.ULong> target, final long idx, final long v) {
        
        //#line 43 . "x10/lang/GlobalRail.x10"
        final x10.core.GlobalRef t$133460 = ((x10.core.GlobalRef)(((x10.lang.GlobalRail<x10.core.ULong>)target).rail));
        
        //#line 43 . "x10/lang/GlobalRail.x10"
        final x10.lang.Place t$133462 = ((x10.lang.Place)((t$133460).home));
        {
            
            //#line 145 "x10/lang/GlobalRail.x10"
            x10.xrx.Runtime.runAt(((x10.lang.Place)(t$133462)), ((x10.core.fun.VoidFun_0_0)(new x10.lang.GlobalRail.$Closure$159(target, idx, v, (x10.lang.GlobalRail.$Closure$159.__0$1x10$lang$ULong$2__2$u) null))), ((x10.xrx.Runtime.Profile)(null)));
        }
    }
    
    
    //#line 149 "x10/lang/GlobalRail.x10"
    final public static void remoteOr__0$1x10$lang$Long$2(final x10.lang.GlobalRail<x10.core.Long> target, final long idx, final long v) {
        
        //#line 43 . "x10/lang/GlobalRail.x10"
        final x10.core.GlobalRef t$133463 = ((x10.core.GlobalRef)(((x10.lang.GlobalRail<x10.core.Long>)target).rail));
        
        //#line 43 . "x10/lang/GlobalRail.x10"
        final x10.lang.Place t$133465 = ((x10.lang.Place)((t$133463).home));
        {
            
            //#line 151 "x10/lang/GlobalRail.x10"
            x10.xrx.Runtime.runAt(((x10.lang.Place)(t$133465)), ((x10.core.fun.VoidFun_0_0)(new x10.lang.GlobalRail.$Closure$160(target, idx, v, (x10.lang.GlobalRail.$Closure$160.__0$1x10$lang$Long$2) null))), ((x10.xrx.Runtime.Profile)(null)));
        }
    }
    
    
    //#line 155 "x10/lang/GlobalRail.x10"
    final public static void remoteXor__0$1x10$lang$ULong$2__2$u(final x10.lang.GlobalRail<x10.core.ULong> target, final long idx, final long v) {
        
        //#line 43 . "x10/lang/GlobalRail.x10"
        final x10.core.GlobalRef t$133466 = ((x10.core.GlobalRef)(((x10.lang.GlobalRail<x10.core.ULong>)target).rail));
        
        //#line 43 . "x10/lang/GlobalRail.x10"
        final x10.lang.Place t$133468 = ((x10.lang.Place)((t$133466).home));
        {
            
            //#line 157 "x10/lang/GlobalRail.x10"
            x10.xrx.Runtime.runAt(((x10.lang.Place)(t$133468)), ((x10.core.fun.VoidFun_0_0)(new x10.lang.GlobalRail.$Closure$161(target, idx, v, (x10.lang.GlobalRail.$Closure$161.__0$1x10$lang$ULong$2__2$u) null))), ((x10.xrx.Runtime.Profile)(null)));
        }
    }
    
    
    //#line 161 "x10/lang/GlobalRail.x10"
    final public static void remoteXor__0$1x10$lang$Long$2(final x10.lang.GlobalRail<x10.core.Long> target, final long idx, final long v) {
        
        //#line 43 . "x10/lang/GlobalRail.x10"
        final x10.core.GlobalRef t$133469 = ((x10.core.GlobalRef)(((x10.lang.GlobalRail<x10.core.Long>)target).rail));
        
        //#line 43 . "x10/lang/GlobalRail.x10"
        final x10.lang.Place t$133471 = ((x10.lang.Place)((t$133469).home));
        {
            
            //#line 163 "x10/lang/GlobalRail.x10"
            x10.xrx.Runtime.runAt(((x10.lang.Place)(t$133471)), ((x10.core.fun.VoidFun_0_0)(new x10.lang.GlobalRail.$Closure$162(target, idx, v, (x10.lang.GlobalRail.$Closure$162.__0$1x10$lang$Long$2) null))), ((x10.xrx.Runtime.Profile)(null)));
        }
    }
    
    
    //#line 166 "x10/lang/GlobalRail.x10"
    final public static void flushRemoteOps() {
        try {
            ;
        }
        catch (java.lang.Throwable exc$206366) {
            throw x10.runtime.impl.java.ThrowableUtils.ensureX10Exception(exc$206366);
        }
        
    }
    
    
    
    //#line 38 "x10/lang/GlobalRail.x10"
    final public java.lang.String typeName() {
        try {
            return x10.rtt.Types.typeName(this);
        }
        catch (java.lang.Throwable exc$206367) {
            throw x10.runtime.impl.java.ThrowableUtils.ensureX10Exception(exc$206367);
        }
        
    }
    
    
    
    //#line 38 "x10/lang/GlobalRail.x10"
    final public java.lang.String toString() {
        
        //#line 38 "x10/lang/GlobalRail.x10"
        final java.lang.String t$133472 = "struct x10.lang.GlobalRail: size=";
        
        //#line 38 "x10/lang/GlobalRail.x10"
        final long t$133473 = this.size;
        
        //#line 38 "x10/lang/GlobalRail.x10"
        final java.lang.String t$133474 = ((t$133472) + ((x10.core.Long.$box(t$133473))));
        
        //#line 38 "x10/lang/GlobalRail.x10"
        final java.lang.String t$133475 = ((t$133474) + (" rail="));
        
        //#line 38 "x10/lang/GlobalRail.x10"
        final x10.core.GlobalRef t$133476 = ((x10.core.GlobalRef)(this.rail));
        
        //#line 38 "x10/lang/GlobalRail.x10"
        final java.lang.String t$133477 = ((t$133475) + (t$133476));
        
        //#line 38 "x10/lang/GlobalRail.x10"
        return t$133477;
    }
    
    
    //#line 38 "x10/lang/GlobalRail.x10"
    final public int hashCode() {
        
        //#line 38 "x10/lang/GlobalRail.x10"
        int result = 1;
        
        //#line 38 "x10/lang/GlobalRail.x10"
        final int t$133480 = ((8191) * (((int)(result))));
        
        //#line 38 "x10/lang/GlobalRail.x10"
        final long t$133479 = this.size;
        
        //#line 38 "x10/lang/GlobalRail.x10"
        final int t$133481 = x10.rtt.Types.hashCode(t$133479);
        
        //#line 38 "x10/lang/GlobalRail.x10"
        final int t$133482 = ((t$133480) + (((int)(t$133481))));
        
        //#line 38 "x10/lang/GlobalRail.x10"
        result = t$133482;
        
        //#line 38 "x10/lang/GlobalRail.x10"
        final int t$133485 = ((8191) * (((int)(result))));
        
        //#line 38 "x10/lang/GlobalRail.x10"
        final x10.core.GlobalRef t$133484 = ((x10.core.GlobalRef)(this.rail));
        
        //#line 38 "x10/lang/GlobalRail.x10"
        final int t$133486 = (((x10.core.GlobalRef<x10.core.Rail<$T>>)(t$133484))).hashCode();
        
        //#line 38 "x10/lang/GlobalRail.x10"
        final int t$133487 = ((t$133485) + (((int)(t$133486))));
        
        //#line 38 "x10/lang/GlobalRail.x10"
        result = t$133487;
        
        //#line 38 "x10/lang/GlobalRail.x10"
        return result;
    }
    
    
    //#line 38 "x10/lang/GlobalRail.x10"
    final public boolean equals(java.lang.Object other) {
        
        //#line 38 "x10/lang/GlobalRail.x10"
        final boolean t$133490 = x10.lang.GlobalRail.$RTT.isInstance(other, $T);
        
        //#line 38 "x10/lang/GlobalRail.x10"
        final boolean t$133491 = !(t$133490);
        
        //#line 38 "x10/lang/GlobalRail.x10"
        if (t$133491) {
            
            //#line 38 "x10/lang/GlobalRail.x10"
            return false;
        }
        
        //#line 38 "x10/lang/GlobalRail.x10"
        final x10.lang.GlobalRail t$133493 = ((x10.lang.GlobalRail)x10.rtt.Types.asStruct(x10.rtt.ParameterizedType.make(x10.lang.GlobalRail.$RTT, $T),other));
        
        //#line 38 "x10/lang/GlobalRail.x10"
        final boolean t$133494 = this.equals__0$1x10$lang$GlobalRail$$T$2$O(((x10.lang.GlobalRail)(t$133493)));
        
        //#line 38 "x10/lang/GlobalRail.x10"
        return t$133494;
    }
    
    
    //#line 38 "x10/lang/GlobalRail.x10"
    final public boolean equals__0$1x10$lang$GlobalRail$$T$2$O(x10.lang.GlobalRail other) {
        
        //#line 38 "x10/lang/GlobalRail.x10"
        final long t$133496 = this.size;
        
        //#line 38 "x10/lang/GlobalRail.x10"
        final long t$133497 = ((x10.lang.GlobalRail<$T>)other).size;
        
        //#line 38 "x10/lang/GlobalRail.x10"
        boolean t$133501 = ((long) t$133496) == ((long) t$133497);
        
        //#line 38 "x10/lang/GlobalRail.x10"
        if (t$133501) {
            
            //#line 38 "x10/lang/GlobalRail.x10"
            final x10.core.GlobalRef t$133499 = ((x10.core.GlobalRef)(this.rail));
            
            //#line 38 "x10/lang/GlobalRail.x10"
            final x10.core.GlobalRef t$133500 = ((x10.core.GlobalRef)(((x10.lang.GlobalRail<$T>)other).rail));
            
            //#line 38 "x10/lang/GlobalRail.x10"
            t$133501 = x10.rtt.Equality.equalsequals((t$133499),(t$133500));
        }
        
        //#line 38 "x10/lang/GlobalRail.x10"
        return t$133501;
    }
    
    
    //#line 38 "x10/lang/GlobalRail.x10"
    final public boolean _struct_equals$O(java.lang.Object other) {
        
        //#line 38 "x10/lang/GlobalRail.x10"
        final boolean t$133504 = x10.lang.GlobalRail.$RTT.isInstance(other, $T);
        
        //#line 38 "x10/lang/GlobalRail.x10"
        final boolean t$133505 = !(t$133504);
        
        //#line 38 "x10/lang/GlobalRail.x10"
        if (t$133505) {
            
            //#line 38 "x10/lang/GlobalRail.x10"
            return false;
        }
        
        //#line 38 "x10/lang/GlobalRail.x10"
        final x10.lang.GlobalRail t$133507 = ((x10.lang.GlobalRail)x10.rtt.Types.asStruct(x10.rtt.ParameterizedType.make(x10.lang.GlobalRail.$RTT, $T),other));
        
        //#line 38 "x10/lang/GlobalRail.x10"
        final boolean t$133508 = this._struct_equals__0$1x10$lang$GlobalRail$$T$2$O(((x10.lang.GlobalRail)(t$133507)));
        
        //#line 38 "x10/lang/GlobalRail.x10"
        return t$133508;
    }
    
    
    //#line 38 "x10/lang/GlobalRail.x10"
    final public boolean _struct_equals__0$1x10$lang$GlobalRail$$T$2$O(x10.lang.GlobalRail other) {
        
        //#line 38 "x10/lang/GlobalRail.x10"
        final long t$133510 = this.size;
        
        //#line 38 "x10/lang/GlobalRail.x10"
        final long t$133511 = ((x10.lang.GlobalRail<$T>)other).size;
        
        //#line 38 "x10/lang/GlobalRail.x10"
        boolean t$133515 = ((long) t$133510) == ((long) t$133511);
        
        //#line 38 "x10/lang/GlobalRail.x10"
        if (t$133515) {
            
            //#line 38 "x10/lang/GlobalRail.x10"
            final x10.core.GlobalRef t$133513 = ((x10.core.GlobalRef)(this.rail));
            
            //#line 38 "x10/lang/GlobalRail.x10"
            final x10.core.GlobalRef t$133514 = ((x10.core.GlobalRef)(((x10.lang.GlobalRail<$T>)other).rail));
            
            //#line 38 "x10/lang/GlobalRail.x10"
            t$133515 = x10.rtt.Equality.equalsequals((t$133513),(t$133514));
        }
        
        //#line 38 "x10/lang/GlobalRail.x10"
        return t$133515;
    }
    
    
    //#line 28 "x10/lang/GlobalRail.x10"
    final public x10.lang.GlobalRail x10$lang$GlobalRail$$this$x10$lang$GlobalRail() {
        
        //#line 28 "x10/lang/GlobalRail.x10"
        return x10.lang.GlobalRail.this;
    }
    
    
    //#line 28 "x10/lang/GlobalRail.x10"
    final public void __fieldInitializers_x10_lang_GlobalRail() {
        
    }
    
    @x10.runtime.impl.java.X10Generated
    final public static class $Closure$155 extends x10.core.Ref implements x10.core.fun.VoidFun_0_0, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<$Closure$155> $RTT = 
            x10.rtt.StaticVoidFunType.<$Closure$155> make($Closure$155.class,
                                                          new x10.rtt.Type[] {
                                                              x10.core.fun.VoidFun_0_0.$RTT
                                                          });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static x10.serialization.X10JavaSerializable $_deserialize_body(x10.lang.GlobalRail.$Closure$155 $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            $_obj.idx = $deserializer.readLong();
            $_obj.target = $deserializer.readObject();
            $_obj.v = $deserializer.readLong();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.lang.GlobalRail.$Closure$155 $_obj = new x10.lang.GlobalRail.$Closure$155((java.lang.System[]) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            $serializer.write(this.idx);
            $serializer.write(this.target);
            $serializer.write(this.v);
            
        }
        
        // constructor just for allocation
        public $Closure$155(final java.lang.System[] $dummy) {
            
        }
        
        // synthetic type for parameter mangling
        public static final class __0$1x10$lang$ULong$2__2$u {}
        
    
        
        public void $apply() {
            
            //#line 121 "x10/lang/GlobalRail.x10"
            try {{
                
                //#line 121 "x10/lang/GlobalRail.x10"
                final long t$133449 = x10.core.ULong.$unbox(((x10.lang.GlobalRail<x10.core.ULong>)this.target).$apply$G((long)(this.idx)));
                
                //#line 121 "x10/lang/GlobalRail.x10"
                final long r$133223 = ((t$133449) + (((long)(this.v))));
                
                //#line 121 "x10/lang/GlobalRail.x10"
                ((x10.lang.GlobalRail<x10.core.ULong>)this.target).$set__1x10$lang$GlobalRail$$T$G((long)(this.idx), x10.core.ULong.$box(r$133223));
            }}catch (java.lang.Throwable __lowerer__var__0__) {
                
                //#line 121 "x10/lang/GlobalRail.x10"
                int __lowerer__var__1__ = (x10.core.Int.$unbox(x10.xrx.Runtime.<x10.core.Int> wrapAtChecked$G(x10.rtt.Types.INT, ((java.lang.Throwable)(__lowerer__var__0__)))));
            }
        }
        
        public x10.lang.GlobalRail<x10.core.ULong> target;
        public long idx;
        public long v;
        
        public $Closure$155(final x10.lang.GlobalRail<x10.core.ULong> target, final long idx, final long v, __0$1x10$lang$ULong$2__2$u $dummy) {
             {
                this.target = target;
                this.idx = idx;
                this.v = v;
            }
        }
        
    }
    
    @x10.runtime.impl.java.X10Generated
    final public static class $Closure$156 extends x10.core.Ref implements x10.core.fun.VoidFun_0_0, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<$Closure$156> $RTT = 
            x10.rtt.StaticVoidFunType.<$Closure$156> make($Closure$156.class,
                                                          new x10.rtt.Type[] {
                                                              x10.core.fun.VoidFun_0_0.$RTT
                                                          });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static x10.serialization.X10JavaSerializable $_deserialize_body(x10.lang.GlobalRail.$Closure$156 $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            $_obj.idx = $deserializer.readLong();
            $_obj.target = $deserializer.readObject();
            $_obj.v = $deserializer.readLong();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.lang.GlobalRail.$Closure$156 $_obj = new x10.lang.GlobalRail.$Closure$156((java.lang.System[]) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            $serializer.write(this.idx);
            $serializer.write(this.target);
            $serializer.write(this.v);
            
        }
        
        // constructor just for allocation
        public $Closure$156(final java.lang.System[] $dummy) {
            
        }
        
        // synthetic type for parameter mangling
        public static final class __0$1x10$lang$Long$2 {}
        
    
        
        public void $apply() {
            
            //#line 127 "x10/lang/GlobalRail.x10"
            try {{
                
                //#line 127 "x10/lang/GlobalRail.x10"
                final long t$133452 = x10.core.Long.$unbox(((x10.lang.GlobalRail<x10.core.Long>)this.target).$apply$G((long)(this.idx)));
                
                //#line 127 "x10/lang/GlobalRail.x10"
                final long r$133233 = ((t$133452) + (((long)(this.v))));
                
                //#line 127 "x10/lang/GlobalRail.x10"
                ((x10.lang.GlobalRail<x10.core.Long>)this.target).$set__1x10$lang$GlobalRail$$T$G((long)(this.idx), x10.core.Long.$box(r$133233));
            }}catch (java.lang.Throwable __lowerer__var__0__) {
                
                //#line 127 "x10/lang/GlobalRail.x10"
                int __lowerer__var__1__ = (x10.core.Int.$unbox(x10.xrx.Runtime.<x10.core.Int> wrapAtChecked$G(x10.rtt.Types.INT, ((java.lang.Throwable)(__lowerer__var__0__)))));
            }
        }
        
        public x10.lang.GlobalRail<x10.core.Long> target;
        public long idx;
        public long v;
        
        public $Closure$156(final x10.lang.GlobalRail<x10.core.Long> target, final long idx, final long v, __0$1x10$lang$Long$2 $dummy) {
             {
                this.target = target;
                this.idx = idx;
                this.v = v;
            }
        }
        
    }
    
    @x10.runtime.impl.java.X10Generated
    final public static class $Closure$157 extends x10.core.Ref implements x10.core.fun.VoidFun_0_0, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<$Closure$157> $RTT = 
            x10.rtt.StaticVoidFunType.<$Closure$157> make($Closure$157.class,
                                                          new x10.rtt.Type[] {
                                                              x10.core.fun.VoidFun_0_0.$RTT
                                                          });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static x10.serialization.X10JavaSerializable $_deserialize_body(x10.lang.GlobalRail.$Closure$157 $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            $_obj.idx = $deserializer.readLong();
            $_obj.target = $deserializer.readObject();
            $_obj.v = $deserializer.readLong();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.lang.GlobalRail.$Closure$157 $_obj = new x10.lang.GlobalRail.$Closure$157((java.lang.System[]) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            $serializer.write(this.idx);
            $serializer.write(this.target);
            $serializer.write(this.v);
            
        }
        
        // constructor just for allocation
        public $Closure$157(final java.lang.System[] $dummy) {
            
        }
        
        // synthetic type for parameter mangling
        public static final class __0$1x10$lang$ULong$2__2$u {}
        
    
        
        public void $apply() {
            
            //#line 133 "x10/lang/GlobalRail.x10"
            try {{
                
                //#line 133 "x10/lang/GlobalRail.x10"
                final long t$133455 = x10.core.ULong.$unbox(((x10.lang.GlobalRail<x10.core.ULong>)this.target).$apply$G((long)(this.idx)));
                
                //#line 133 "x10/lang/GlobalRail.x10"
                final long r$133244 = ((t$133455) & (((long)(this.v))));
                
                //#line 133 "x10/lang/GlobalRail.x10"
                ((x10.lang.GlobalRail<x10.core.ULong>)this.target).$set__1x10$lang$GlobalRail$$T$G((long)(this.idx), x10.core.ULong.$box(r$133244));
            }}catch (java.lang.Throwable __lowerer__var__0__) {
                
                //#line 133 "x10/lang/GlobalRail.x10"
                int __lowerer__var__1__ = (x10.core.Int.$unbox(x10.xrx.Runtime.<x10.core.Int> wrapAtChecked$G(x10.rtt.Types.INT, ((java.lang.Throwable)(__lowerer__var__0__)))));
            }
        }
        
        public x10.lang.GlobalRail<x10.core.ULong> target;
        public long idx;
        public long v;
        
        public $Closure$157(final x10.lang.GlobalRail<x10.core.ULong> target, final long idx, final long v, __0$1x10$lang$ULong$2__2$u $dummy) {
             {
                this.target = target;
                this.idx = idx;
                this.v = v;
            }
        }
        
    }
    
    @x10.runtime.impl.java.X10Generated
    final public static class $Closure$158 extends x10.core.Ref implements x10.core.fun.VoidFun_0_0, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<$Closure$158> $RTT = 
            x10.rtt.StaticVoidFunType.<$Closure$158> make($Closure$158.class,
                                                          new x10.rtt.Type[] {
                                                              x10.core.fun.VoidFun_0_0.$RTT
                                                          });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static x10.serialization.X10JavaSerializable $_deserialize_body(x10.lang.GlobalRail.$Closure$158 $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            $_obj.idx = $deserializer.readLong();
            $_obj.target = $deserializer.readObject();
            $_obj.v = $deserializer.readLong();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.lang.GlobalRail.$Closure$158 $_obj = new x10.lang.GlobalRail.$Closure$158((java.lang.System[]) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            $serializer.write(this.idx);
            $serializer.write(this.target);
            $serializer.write(this.v);
            
        }
        
        // constructor just for allocation
        public $Closure$158(final java.lang.System[] $dummy) {
            
        }
        
        // synthetic type for parameter mangling
        public static final class __0$1x10$lang$Long$2 {}
        
    
        
        public void $apply() {
            
            //#line 139 "x10/lang/GlobalRail.x10"
            try {{
                
                //#line 139 "x10/lang/GlobalRail.x10"
                final long t$133458 = x10.core.Long.$unbox(((x10.lang.GlobalRail<x10.core.Long>)this.target).$apply$G((long)(this.idx)));
                
                //#line 139 "x10/lang/GlobalRail.x10"
                final long r$133254 = ((t$133458) & (((long)(this.v))));
                
                //#line 139 "x10/lang/GlobalRail.x10"
                ((x10.lang.GlobalRail<x10.core.Long>)this.target).$set__1x10$lang$GlobalRail$$T$G((long)(this.idx), x10.core.Long.$box(r$133254));
            }}catch (java.lang.Throwable __lowerer__var__0__) {
                
                //#line 139 "x10/lang/GlobalRail.x10"
                int __lowerer__var__1__ = (x10.core.Int.$unbox(x10.xrx.Runtime.<x10.core.Int> wrapAtChecked$G(x10.rtt.Types.INT, ((java.lang.Throwable)(__lowerer__var__0__)))));
            }
        }
        
        public x10.lang.GlobalRail<x10.core.Long> target;
        public long idx;
        public long v;
        
        public $Closure$158(final x10.lang.GlobalRail<x10.core.Long> target, final long idx, final long v, __0$1x10$lang$Long$2 $dummy) {
             {
                this.target = target;
                this.idx = idx;
                this.v = v;
            }
        }
        
    }
    
    @x10.runtime.impl.java.X10Generated
    final public static class $Closure$159 extends x10.core.Ref implements x10.core.fun.VoidFun_0_0, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<$Closure$159> $RTT = 
            x10.rtt.StaticVoidFunType.<$Closure$159> make($Closure$159.class,
                                                          new x10.rtt.Type[] {
                                                              x10.core.fun.VoidFun_0_0.$RTT
                                                          });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static x10.serialization.X10JavaSerializable $_deserialize_body(x10.lang.GlobalRail.$Closure$159 $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            $_obj.idx = $deserializer.readLong();
            $_obj.target = $deserializer.readObject();
            $_obj.v = $deserializer.readLong();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.lang.GlobalRail.$Closure$159 $_obj = new x10.lang.GlobalRail.$Closure$159((java.lang.System[]) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            $serializer.write(this.idx);
            $serializer.write(this.target);
            $serializer.write(this.v);
            
        }
        
        // constructor just for allocation
        public $Closure$159(final java.lang.System[] $dummy) {
            
        }
        
        // synthetic type for parameter mangling
        public static final class __0$1x10$lang$ULong$2__2$u {}
        
    
        
        public void $apply() {
            
            //#line 145 "x10/lang/GlobalRail.x10"
            try {{
                
                //#line 145 "x10/lang/GlobalRail.x10"
                final long t$133461 = x10.core.ULong.$unbox(((x10.lang.GlobalRail<x10.core.ULong>)this.target).$apply$G((long)(this.idx)));
                
                //#line 145 "x10/lang/GlobalRail.x10"
                final long r$133265 = ((t$133461) | (((long)(this.v))));
                
                //#line 145 "x10/lang/GlobalRail.x10"
                ((x10.lang.GlobalRail<x10.core.ULong>)this.target).$set__1x10$lang$GlobalRail$$T$G((long)(this.idx), x10.core.ULong.$box(r$133265));
            }}catch (java.lang.Throwable __lowerer__var__0__) {
                
                //#line 145 "x10/lang/GlobalRail.x10"
                int __lowerer__var__1__ = (x10.core.Int.$unbox(x10.xrx.Runtime.<x10.core.Int> wrapAtChecked$G(x10.rtt.Types.INT, ((java.lang.Throwable)(__lowerer__var__0__)))));
            }
        }
        
        public x10.lang.GlobalRail<x10.core.ULong> target;
        public long idx;
        public long v;
        
        public $Closure$159(final x10.lang.GlobalRail<x10.core.ULong> target, final long idx, final long v, __0$1x10$lang$ULong$2__2$u $dummy) {
             {
                this.target = target;
                this.idx = idx;
                this.v = v;
            }
        }
        
    }
    
    @x10.runtime.impl.java.X10Generated
    final public static class $Closure$160 extends x10.core.Ref implements x10.core.fun.VoidFun_0_0, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<$Closure$160> $RTT = 
            x10.rtt.StaticVoidFunType.<$Closure$160> make($Closure$160.class,
                                                          new x10.rtt.Type[] {
                                                              x10.core.fun.VoidFun_0_0.$RTT
                                                          });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static x10.serialization.X10JavaSerializable $_deserialize_body(x10.lang.GlobalRail.$Closure$160 $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            $_obj.idx = $deserializer.readLong();
            $_obj.target = $deserializer.readObject();
            $_obj.v = $deserializer.readLong();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.lang.GlobalRail.$Closure$160 $_obj = new x10.lang.GlobalRail.$Closure$160((java.lang.System[]) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            $serializer.write(this.idx);
            $serializer.write(this.target);
            $serializer.write(this.v);
            
        }
        
        // constructor just for allocation
        public $Closure$160(final java.lang.System[] $dummy) {
            
        }
        
        // synthetic type for parameter mangling
        public static final class __0$1x10$lang$Long$2 {}
        
    
        
        public void $apply() {
            
            //#line 151 "x10/lang/GlobalRail.x10"
            try {{
                
                //#line 151 "x10/lang/GlobalRail.x10"
                final long t$133464 = x10.core.Long.$unbox(((x10.lang.GlobalRail<x10.core.Long>)this.target).$apply$G((long)(this.idx)));
                
                //#line 151 "x10/lang/GlobalRail.x10"
                final long r$133275 = ((t$133464) | (((long)(this.v))));
                
                //#line 151 "x10/lang/GlobalRail.x10"
                ((x10.lang.GlobalRail<x10.core.Long>)this.target).$set__1x10$lang$GlobalRail$$T$G((long)(this.idx), x10.core.Long.$box(r$133275));
            }}catch (java.lang.Throwable __lowerer__var__0__) {
                
                //#line 151 "x10/lang/GlobalRail.x10"
                int __lowerer__var__1__ = (x10.core.Int.$unbox(x10.xrx.Runtime.<x10.core.Int> wrapAtChecked$G(x10.rtt.Types.INT, ((java.lang.Throwable)(__lowerer__var__0__)))));
            }
        }
        
        public x10.lang.GlobalRail<x10.core.Long> target;
        public long idx;
        public long v;
        
        public $Closure$160(final x10.lang.GlobalRail<x10.core.Long> target, final long idx, final long v, __0$1x10$lang$Long$2 $dummy) {
             {
                this.target = target;
                this.idx = idx;
                this.v = v;
            }
        }
        
    }
    
    @x10.runtime.impl.java.X10Generated
    final public static class $Closure$161 extends x10.core.Ref implements x10.core.fun.VoidFun_0_0, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<$Closure$161> $RTT = 
            x10.rtt.StaticVoidFunType.<$Closure$161> make($Closure$161.class,
                                                          new x10.rtt.Type[] {
                                                              x10.core.fun.VoidFun_0_0.$RTT
                                                          });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static x10.serialization.X10JavaSerializable $_deserialize_body(x10.lang.GlobalRail.$Closure$161 $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            $_obj.idx = $deserializer.readLong();
            $_obj.target = $deserializer.readObject();
            $_obj.v = $deserializer.readLong();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.lang.GlobalRail.$Closure$161 $_obj = new x10.lang.GlobalRail.$Closure$161((java.lang.System[]) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            $serializer.write(this.idx);
            $serializer.write(this.target);
            $serializer.write(this.v);
            
        }
        
        // constructor just for allocation
        public $Closure$161(final java.lang.System[] $dummy) {
            
        }
        
        // synthetic type for parameter mangling
        public static final class __0$1x10$lang$ULong$2__2$u {}
        
    
        
        public void $apply() {
            
            //#line 157 "x10/lang/GlobalRail.x10"
            try {{
                
                //#line 157 "x10/lang/GlobalRail.x10"
                final long t$133467 = x10.core.ULong.$unbox(((x10.lang.GlobalRail<x10.core.ULong>)this.target).$apply$G((long)(this.idx)));
                
                //#line 157 "x10/lang/GlobalRail.x10"
                final long r$133286 = ((t$133467) ^ (((long)(this.v))));
                
                //#line 157 "x10/lang/GlobalRail.x10"
                ((x10.lang.GlobalRail<x10.core.ULong>)this.target).$set__1x10$lang$GlobalRail$$T$G((long)(this.idx), x10.core.ULong.$box(r$133286));
            }}catch (java.lang.Throwable __lowerer__var__0__) {
                
                //#line 157 "x10/lang/GlobalRail.x10"
                int __lowerer__var__1__ = (x10.core.Int.$unbox(x10.xrx.Runtime.<x10.core.Int> wrapAtChecked$G(x10.rtt.Types.INT, ((java.lang.Throwable)(__lowerer__var__0__)))));
            }
        }
        
        public x10.lang.GlobalRail<x10.core.ULong> target;
        public long idx;
        public long v;
        
        public $Closure$161(final x10.lang.GlobalRail<x10.core.ULong> target, final long idx, final long v, __0$1x10$lang$ULong$2__2$u $dummy) {
             {
                this.target = target;
                this.idx = idx;
                this.v = v;
            }
        }
        
    }
    
    @x10.runtime.impl.java.X10Generated
    final public static class $Closure$162 extends x10.core.Ref implements x10.core.fun.VoidFun_0_0, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<$Closure$162> $RTT = 
            x10.rtt.StaticVoidFunType.<$Closure$162> make($Closure$162.class,
                                                          new x10.rtt.Type[] {
                                                              x10.core.fun.VoidFun_0_0.$RTT
                                                          });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static x10.serialization.X10JavaSerializable $_deserialize_body(x10.lang.GlobalRail.$Closure$162 $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            $_obj.idx = $deserializer.readLong();
            $_obj.target = $deserializer.readObject();
            $_obj.v = $deserializer.readLong();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.lang.GlobalRail.$Closure$162 $_obj = new x10.lang.GlobalRail.$Closure$162((java.lang.System[]) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            $serializer.write(this.idx);
            $serializer.write(this.target);
            $serializer.write(this.v);
            
        }
        
        // constructor just for allocation
        public $Closure$162(final java.lang.System[] $dummy) {
            
        }
        
        // synthetic type for parameter mangling
        public static final class __0$1x10$lang$Long$2 {}
        
    
        
        public void $apply() {
            
            //#line 163 "x10/lang/GlobalRail.x10"
            try {{
                
                //#line 163 "x10/lang/GlobalRail.x10"
                final long t$133470 = x10.core.Long.$unbox(((x10.lang.GlobalRail<x10.core.Long>)this.target).$apply$G((long)(this.idx)));
                
                //#line 163 "x10/lang/GlobalRail.x10"
                final long r$133296 = ((t$133470) ^ (((long)(this.v))));
                
                //#line 163 "x10/lang/GlobalRail.x10"
                ((x10.lang.GlobalRail<x10.core.Long>)this.target).$set__1x10$lang$GlobalRail$$T$G((long)(this.idx), x10.core.Long.$box(r$133296));
            }}catch (java.lang.Throwable __lowerer__var__0__) {
                
                //#line 163 "x10/lang/GlobalRail.x10"
                int __lowerer__var__1__ = (x10.core.Int.$unbox(x10.xrx.Runtime.<x10.core.Int> wrapAtChecked$G(x10.rtt.Types.INT, ((java.lang.Throwable)(__lowerer__var__0__)))));
            }
        }
        
        public x10.lang.GlobalRail<x10.core.Long> target;
        public long idx;
        public long v;
        
        public $Closure$162(final x10.lang.GlobalRail<x10.core.Long> target, final long idx, final long v, __0$1x10$lang$Long$2 $dummy) {
             {
                this.target = target;
                this.idx = idx;
                this.v = v;
            }
        }
        
    }
    
}

