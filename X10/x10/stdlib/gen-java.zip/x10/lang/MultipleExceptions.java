package x10.lang;


/**
 * MultipleExceptions is used to to summarize all uncaught exceptions
 * raised during the execution of a <code>finish</code> and rethrow
 * them as a single exception when all activities controlled by the 
 * <code>finish</code> have terminated.
 */
@x10.runtime.impl.java.X10Generated
public class MultipleExceptions extends java.lang.RuntimeException implements x10.serialization.X10JavaSerializable
{
    public static final x10.rtt.RuntimeType<MultipleExceptions> $RTT = 
        x10.rtt.NamedType.<MultipleExceptions> make("x10.lang.MultipleExceptions",
                                                    MultipleExceptions.class,
                                                    new x10.rtt.Type[] {
                                                        x10.rtt.Types.EXCEPTION
                                                    });
    
    public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
    
    public x10.rtt.Type<?> $getParam(int i) { return null; }
    
    private Object writeReplace() throws java.io.ObjectStreamException {
        return new x10.serialization.SerializationProxy(this);
    }
    
    public static x10.serialization.X10JavaSerializable $_deserialize_body(x10.lang.MultipleExceptions $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
        $deserializer.deserializeFieldsStartingFromClass(java.lang.RuntimeException.class, $_obj, 0);
        $_obj.exceptions = $deserializer.readObject();
        return $_obj;
    }
    
    public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
        x10.lang.MultipleExceptions $_obj = new x10.lang.MultipleExceptions((java.lang.System[]) null);
        $deserializer.record_reference($_obj);
        return $_deserialize_body($_obj, $deserializer);
    }
    
    public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
        $serializer.serializeFieldsStartingFromClass(this, java.lang.RuntimeException.class);
        $serializer.write(this.exceptions);
        
    }
    
    // constructor just for allocation
    public MultipleExceptions(final java.lang.System[] $dummy) {
        
    }
    
    // synthetic type for parameter mangling
    public static final class __0$1x10$lang$CheckedThrowable$2 {}
    
    // properties
    
    //#line 23 "x10/lang/MultipleExceptions.x10"
    public x10.core.Rail<java.lang.Throwable> exceptions;
    

    
    
    //#line 24 "x10/lang/MultipleExceptions.x10"
    final public x10.core.Rail exceptions() {
        
        //#line 24 "x10/lang/MultipleExceptions.x10"
        final x10.core.Rail t$134536 = ((x10.core.Rail)(this.exceptions));
        
        //#line 24 "x10/lang/MultipleExceptions.x10"
        return t$134536;
    }
    
    
    //#line 26 "x10/lang/MultipleExceptions.x10"
    public MultipleExceptions(final x10.util.GrowableRail<java.lang.Throwable> es, __0$1x10$lang$CheckedThrowable$2 $dummy) {
        super();
         {
            
            //#line 27 "x10/lang/MultipleExceptions.x10"
            this.exceptions = ((x10.core.Rail<java.lang.Throwable>)
                                ((x10.util.GrowableRail<java.lang.Throwable>)es).toRail());
            
            
            //#line 23 "x10/lang/MultipleExceptions.x10"
            this.__fieldInitializers_x10_lang_MultipleExceptions();
        }
    }
    
    
    
    //#line 30 "x10/lang/MultipleExceptions.x10"
    public MultipleExceptions() {
        super();
         {
            
            //#line 31 "x10/lang/MultipleExceptions.x10"
            this.exceptions = null;
            
            
            //#line 23 "x10/lang/MultipleExceptions.x10"
            this.__fieldInitializers_x10_lang_MultipleExceptions();
        }
    }
    
    
    
    //#line 34 "x10/lang/MultipleExceptions.x10"
    public MultipleExceptions(final java.lang.Throwable t) {
        super();
         {
            
            //#line 35 "x10/lang/MultipleExceptions.x10"
            this.exceptions = new x10.core.Rail<java.lang.Throwable>(x10.rtt.Types.CHECKED_THROWABLE, ((long)(1L)), ((java.lang.Throwable)(t)), (x10.core.Rail.__1x10$lang$Rail$$T) null);
            
            
            //#line 23 "x10/lang/MultipleExceptions.x10"
            this.__fieldInitializers_x10_lang_MultipleExceptions();
        }
    }
    
    
    
    //#line 38 "x10/lang/MultipleExceptions.x10"
    public void printStackTrace() {
        
        //#line 39 "x10/lang/MultipleExceptions.x10"
        final x10.core.Rail rail$116049 = ((x10.core.Rail)(this.exceptions));
        
        //#line 39 "x10/lang/MultipleExceptions.x10"
        final long size$116050 = ((x10.core.Rail<java.lang.Throwable>)rail$116049).size;
        
        //#line 39 "x10/lang/MultipleExceptions.x10"
        long idx$134776 = 0L;
        {
            
            //#line 39 "x10/lang/MultipleExceptions.x10"
            final java.lang.Throwable[] rail$116049$value$135034 = ((java.lang.Throwable[])rail$116049.value);
            
            //#line 39 "x10/lang/MultipleExceptions.x10"
            for (;
                 true;
                 ) {
                
                //#line 39 "x10/lang/MultipleExceptions.x10"
                final boolean t$134778 = ((idx$134776) < (((long)(size$116050))));
                
                //#line 39 "x10/lang/MultipleExceptions.x10"
                if (!(t$134778)) {
                    
                    //#line 39 "x10/lang/MultipleExceptions.x10"
                    break;
                }
                
                //#line 39 "x10/lang/MultipleExceptions.x10"
                final java.lang.Throwable t$134773 = ((java.lang.Throwable)(((java.lang.Throwable)rail$116049$value$135034[(int)idx$134776])));
                
                //#line 40 "x10/lang/MultipleExceptions.x10"
                t$134773.printStackTrace();
                
                //#line 39 "x10/lang/MultipleExceptions.x10"
                final long t$134775 = ((idx$134776) + (((long)(1L))));
                
                //#line 39 "x10/lang/MultipleExceptions.x10"
                idx$134776 = t$134775;
            }
        }
    }
    
    
    //#line 44 "x10/lang/MultipleExceptions.x10"
    public static x10.lang.MultipleExceptions make__0$1x10$lang$CheckedThrowable$2(final x10.util.GrowableRail<java.lang.Throwable> es) {
        
        //#line 45 "x10/lang/MultipleExceptions.x10"
        boolean t$134544 = ((null) == (es));
        
        //#line 45 "x10/lang/MultipleExceptions.x10"
        if (!(t$134544)) {
            
            //#line 160 . "x10/util/GrowableRail.x10"
            final long t$134543 = ((x10.util.GrowableRail<java.lang.Throwable>)es).size;
            
            //#line 45 "x10/lang/MultipleExceptions.x10"
            t$134544 = ((long) t$134543) == ((long) 0L);
        }
        
        //#line 45 "x10/lang/MultipleExceptions.x10"
        if (t$134544) {
            
            //#line 45 "x10/lang/MultipleExceptions.x10"
            return null;
        }
        
        //#line 46 "x10/lang/MultipleExceptions.x10"
        final x10.lang.MultipleExceptions t$134546 = ((x10.lang.MultipleExceptions)(new x10.lang.MultipleExceptions(((x10.util.GrowableRail<java.lang.Throwable>)(es)), (x10.lang.MultipleExceptions.__0$1x10$lang$CheckedThrowable$2) null)));
        
        //#line 46 "x10/lang/MultipleExceptions.x10"
        return t$134546;
    }
    
    
    //#line 49 "x10/lang/MultipleExceptions.x10"
    public static x10.lang.MultipleExceptions make(final java.lang.Throwable t) {
        
        //#line 50 "x10/lang/MultipleExceptions.x10"
        final boolean t$134547 = ((null) == (t));
        
        //#line 50 "x10/lang/MultipleExceptions.x10"
        if (t$134547) {
            
            //#line 50 "x10/lang/MultipleExceptions.x10"
            return null;
        }
        
        //#line 51 "x10/lang/MultipleExceptions.x10"
        final x10.lang.MultipleExceptions t$134548 = ((x10.lang.MultipleExceptions)(new x10.lang.MultipleExceptions(((java.lang.Throwable)(t)))));
        
        //#line 51 "x10/lang/MultipleExceptions.x10"
        return t$134548;
    }
    
    
    //#line 61 "x10/lang/MultipleExceptions.x10"
    /** 
     * Gets exceptions of the given type that are nested within this
     * instance of MultipleExceptions.
     * @param deep perform a deep traversal of the tree of MultipleExceptions
     *   associated with nested finish constructs
     * @return a rail containing only the exceptions of the given type 
     */
    final public <$T>x10.core.Rail getExceptionsOfType(final x10.rtt.Type $T, final boolean deep) {
        
        //#line 62 "x10/lang/MultipleExceptions.x10"
        final x10.util.GrowableRail es = ((x10.util.GrowableRail)(new x10.util.GrowableRail<$T>((java.lang.System[]) null, $T)));
        
        //#line 50 . "x10/util/GrowableRail.x10"
        es.x10$util$GrowableRail$$init$S(((long)(0L)));
        
        //#line 63 "x10/lang/MultipleExceptions.x10"
        final x10.core.Rail rail$134801 = ((x10.core.Rail)(this.exceptions));
        
        //#line 63 "x10/lang/MultipleExceptions.x10"
        final long size$134802 = ((x10.core.Rail<java.lang.Throwable>)rail$134801).size;
        
        //#line 63 "x10/lang/MultipleExceptions.x10"
        long idx$134798 = 0L;
        {
            
            //#line 63 "x10/lang/MultipleExceptions.x10"
            final java.lang.Throwable[] rail$134801$value$135035 = ((java.lang.Throwable[])rail$134801.value);
            
            //#line 63 "x10/lang/MultipleExceptions.x10"
            for (;
                 true;
                 ) {
                
                //#line 63 "x10/lang/MultipleExceptions.x10"
                final boolean t$134800 = ((idx$134798) < (((long)(size$134802))));
                
                //#line 63 "x10/lang/MultipleExceptions.x10"
                if (!(t$134800)) {
                    
                    //#line 63 "x10/lang/MultipleExceptions.x10"
                    break;
                }
                
                //#line 63 "x10/lang/MultipleExceptions.x10"
                final java.lang.Throwable e$134795 = ((java.lang.Throwable)(((java.lang.Throwable)rail$134801$value$135035[(int)idx$134798])));
                
                //#line 64 "x10/lang/MultipleExceptions.x10"
                final boolean t$134788 = $T.isInstance(e$134795);
                
                //#line 64 "x10/lang/MultipleExceptions.x10"
                if (t$134788) {
                    
                    //#line 65 "x10/lang/MultipleExceptions.x10"
                    final $T t$134789 = (($T)(x10.rtt.Types.<$T> castConversion(e$134795,$T)));
                    
                    //#line 65 "x10/lang/MultipleExceptions.x10"
                    ((x10.util.GrowableRail<$T>)es).add__0x10$util$GrowableRail$$T((($T)(t$134789)));
                } else {
                    
                    //#line 66 "x10/lang/MultipleExceptions.x10"
                    boolean t$134790 = deep;
                    
                    //#line 66 "x10/lang/MultipleExceptions.x10"
                    if (deep) {
                        
                        //#line 66 "x10/lang/MultipleExceptions.x10"
                        t$134790 = x10.lang.MultipleExceptions.$RTT.isInstance(e$134795);
                    }
                    
                    //#line 66 "x10/lang/MultipleExceptions.x10"
                    if (t$134790) {
                        
                        //#line 67 "x10/lang/MultipleExceptions.x10"
                        final x10.lang.MultipleExceptions this$134792 = ((x10.lang.MultipleExceptions)(x10.rtt.Types.<x10.lang.MultipleExceptions> cast(e$134795,x10.lang.MultipleExceptions.$RTT)));
                        
                        //#line 67 "x10/lang/MultipleExceptions.x10"
                        final x10.core.Rail es$134793 = ((x10.lang.MultipleExceptions)this$134792).<$T> getExceptionsOfType($T, (boolean)(true));
                        
                        //#line 68 "x10/lang/MultipleExceptions.x10"
                        final long size$134787 = ((x10.core.Rail<$T>)es$134793).size;
                        
                        //#line 68 "x10/lang/MultipleExceptions.x10"
                        long idx$134783 = 0L;
                        
                        //#line 68 "x10/lang/MultipleExceptions.x10"
                        for (;
                             true;
                             ) {
                            
                            //#line 68 "x10/lang/MultipleExceptions.x10"
                            final boolean t$134785 = ((idx$134783) < (((long)(size$134787))));
                            
                            //#line 68 "x10/lang/MultipleExceptions.x10"
                            if (!(t$134785)) {
                                
                                //#line 68 "x10/lang/MultipleExceptions.x10"
                                break;
                            }
                            
                            //#line 68 "x10/lang/MultipleExceptions.x10"
                            final $T e$134780 = (($T)(((x10.core.Rail<$T>)es$134793).$apply$G((long)(idx$134783))));
                            
                            //#line 68 "x10/lang/MultipleExceptions.x10"
                            ((x10.util.GrowableRail<$T>)es).add__0x10$util$GrowableRail$$T((($T)(e$134780)));
                            
                            //#line 68 "x10/lang/MultipleExceptions.x10"
                            final long t$134782 = ((idx$134783) + (((long)(1L))));
                            
                            //#line 68 "x10/lang/MultipleExceptions.x10"
                            idx$134783 = t$134782;
                        }
                    }
                }
                
                //#line 63 "x10/lang/MultipleExceptions.x10"
                final long t$134797 = ((idx$134798) + (((long)(1L))));
                
                //#line 63 "x10/lang/MultipleExceptions.x10"
                idx$134798 = t$134797;
            }
        }
        
        //#line 72 "x10/lang/MultipleExceptions.x10"
        final x10.core.Rail t$134565 = ((x10.core.Rail<$T>)
                                         ((x10.util.GrowableRail<$T>)es).toRail());
        
        //#line 72 "x10/lang/MultipleExceptions.x10"
        return t$134565;
    }
    
    
    //#line 75 "x10/lang/MultipleExceptions.x10"
    final public <$T>x10.core.Rail getExceptionsOfType(final x10.rtt.Type $T) {
        
        //#line 75 "x10/lang/MultipleExceptions.x10"
        final x10.core.Rail t$134566 = this.<$T> getExceptionsOfType($T, (boolean)(true));
        
        //#line 75 "x10/lang/MultipleExceptions.x10"
        return t$134566;
    }
    
    
    //#line 86 "x10/lang/MultipleExceptions.x10"
    /** 
     * Gets a copy of this MultipleExceptions instance, with all nested
     * exceptions of the given type removed.
     * This method may be used for example is to filter all DeadPlaceExceptions
     * so that exceptions of other types can be handled separately.
     * @param deep perform a deep traversal of the tree of MultipleExceptions
     *   associated with nested finish constructs
     * @return a new MultipleExceptions, filtering out all exceptions of the given type 
     */
    final public <$T>x10.lang.MultipleExceptions filterExceptionsOfType(final x10.rtt.Type $T, final boolean deep) {
        
        //#line 87 "x10/lang/MultipleExceptions.x10"
        final x10.util.GrowableRail es = ((x10.util.GrowableRail)(new x10.util.GrowableRail<java.lang.Throwable>((java.lang.System[]) null, x10.rtt.Types.CHECKED_THROWABLE)));
        
        //#line 50 . "x10/util/GrowableRail.x10"
        es.x10$util$GrowableRail$$init$S(((long)(0L)));
        
        //#line 88 "x10/lang/MultipleExceptions.x10"
        final x10.core.Rail rail$134817 = ((x10.core.Rail)(this.exceptions));
        
        //#line 88 "x10/lang/MultipleExceptions.x10"
        final long size$134818 = ((x10.core.Rail<java.lang.Throwable>)rail$134817).size;
        
        //#line 88 "x10/lang/MultipleExceptions.x10"
        long idx$134814 = 0L;
        {
            
            //#line 88 "x10/lang/MultipleExceptions.x10"
            final java.lang.Throwable[] rail$134817$value$135036 = ((java.lang.Throwable[])rail$134817.value);
            
            //#line 88 "x10/lang/MultipleExceptions.x10"
            for (;
                 true;
                 ) {
                
                //#line 88 "x10/lang/MultipleExceptions.x10"
                final boolean t$134816 = ((idx$134814) < (((long)(size$134818))));
                
                //#line 88 "x10/lang/MultipleExceptions.x10"
                if (!(t$134816)) {
                    
                    //#line 88 "x10/lang/MultipleExceptions.x10"
                    break;
                }
                
                //#line 88 "x10/lang/MultipleExceptions.x10"
                final java.lang.Throwable e$134811 = ((java.lang.Throwable)(((java.lang.Throwable)rail$134817$value$135036[(int)idx$134814])));
                
                //#line 89 "x10/lang/MultipleExceptions.x10"
                boolean t$134803 = deep;
                
                //#line 89 "x10/lang/MultipleExceptions.x10"
                if (deep) {
                    
                    //#line 89 "x10/lang/MultipleExceptions.x10"
                    t$134803 = x10.lang.MultipleExceptions.$RTT.isInstance(e$134811);
                }
                
                //#line 89 "x10/lang/MultipleExceptions.x10"
                if (t$134803) {
                    
                    //#line 90 "x10/lang/MultipleExceptions.x10"
                    final x10.lang.MultipleExceptions this$134805 = ((x10.lang.MultipleExceptions)(x10.rtt.Types.<x10.lang.MultipleExceptions> cast(e$134811,x10.lang.MultipleExceptions.$RTT)));
                    
                    //#line 90 "x10/lang/MultipleExceptions.x10"
                    final x10.lang.MultipleExceptions me$134806 = ((x10.lang.MultipleExceptions)this$134805).<$T> filterExceptionsOfType($T, (boolean)(true));
                    
                    //#line 91 "x10/lang/MultipleExceptions.x10"
                    final boolean t$134807 = ((me$134806) != (null));
                    
                    //#line 91 "x10/lang/MultipleExceptions.x10"
                    if (t$134807) {
                        
                        //#line 91 "x10/lang/MultipleExceptions.x10"
                        ((x10.util.GrowableRail<java.lang.Throwable>)es).add__0x10$util$GrowableRail$$T(((java.lang.Throwable)(me$134806)));
                    }
                } else {
                    
                    //#line 92 "x10/lang/MultipleExceptions.x10"
                    final boolean t$134808 = $T.isInstance(e$134811);
                    
                    //#line 92 "x10/lang/MultipleExceptions.x10"
                    final boolean t$134809 = !(t$134808);
                    
                    //#line 92 "x10/lang/MultipleExceptions.x10"
                    if (t$134809) {
                        
                        //#line 93 "x10/lang/MultipleExceptions.x10"
                        ((x10.util.GrowableRail<java.lang.Throwable>)es).add__0x10$util$GrowableRail$$T(((java.lang.Throwable)(e$134811)));
                    }
                }
                
                //#line 88 "x10/lang/MultipleExceptions.x10"
                final long t$134813 = ((idx$134814) + (((long)(1L))));
                
                //#line 88 "x10/lang/MultipleExceptions.x10"
                idx$134814 = t$134813;
            }
        }
        
        //#line 97 "x10/lang/MultipleExceptions.x10"
        final x10.lang.MultipleExceptions t$134578 = x10.lang.MultipleExceptions.make__0$1x10$lang$CheckedThrowable$2(((x10.util.GrowableRail)(es)));
        
        //#line 97 "x10/lang/MultipleExceptions.x10"
        return t$134578;
    }
    
    
    //#line 100 "x10/lang/MultipleExceptions.x10"
    final public <$T>x10.lang.MultipleExceptions filterExceptionsOfType(final x10.rtt.Type $T) {
        
        //#line 100 "x10/lang/MultipleExceptions.x10"
        final x10.lang.MultipleExceptions t$134579 = this.<$T> filterExceptionsOfType($T, (boolean)(true));
        
        //#line 100 "x10/lang/MultipleExceptions.x10"
        return t$134579;
    }
    
    
    //#line 113 "x10/lang/MultipleExceptions.x10"
    /**
     * Gets a copy of this MultipleExceptions instance where the
     * nesting of MultipleExceptions is flatten. It means that
     * exceptions that was included inside a nested MultipleExceptions
     * are now in the toplevel MultipleExceptions dans that the
     * toplevel MultipleExceptions do not contains other
     * MultipleExceptions.
     * @param me the MultipleExceptions to flatten
     * @return a new MultipleExceptions without neted MultipleExceptions
     */
    final public x10.lang.MultipleExceptions flatten() {
        
        //#line 114 "x10/lang/MultipleExceptions.x10"
        final x10.util.GrowableRail exns = ((x10.util.GrowableRail)(new x10.util.GrowableRail<java.lang.Throwable>((java.lang.System[]) null, x10.rtt.Types.CHECKED_THROWABLE)));
        
        //#line 50 . "x10/util/GrowableRail.x10"
        exns.x10$util$GrowableRail$$init$S(((long)(0L)));
        
        //#line 115 "x10/lang/MultipleExceptions.x10"
        x10.lang.MultipleExceptions.flattenAux__1$1x10$lang$CheckedThrowable$2(((x10.lang.MultipleExceptions)(this)), ((x10.util.GrowableRail)(exns)));
        
        //#line 116 "x10/lang/MultipleExceptions.x10"
        final x10.lang.MultipleExceptions t$134580 = x10.lang.MultipleExceptions.make__0$1x10$lang$CheckedThrowable$2(((x10.util.GrowableRail)(exns)));
        
        //#line 116 "x10/lang/MultipleExceptions.x10"
        return t$134580;
    }
    
    
    //#line 119 "x10/lang/MultipleExceptions.x10"
    private static void flattenAux__1$1x10$lang$CheckedThrowable$2(final x10.lang.MultipleExceptions me, final x10.util.GrowableRail<java.lang.Throwable> acc) {
        
        //#line 120 "x10/lang/MultipleExceptions.x10"
        final x10.core.Rail rail$116149 = ((x10.core.Rail)(me.exceptions));
        
        //#line 120 "x10/lang/MultipleExceptions.x10"
        final long size$116150 = ((x10.core.Rail<java.lang.Throwable>)rail$116149).size;
        
        //#line 120 "x10/lang/MultipleExceptions.x10"
        long idx$134825 = 0L;
        {
            
            //#line 120 "x10/lang/MultipleExceptions.x10"
            final java.lang.Throwable[] rail$116149$value$135037 = ((java.lang.Throwable[])rail$116149.value);
            
            //#line 120 "x10/lang/MultipleExceptions.x10"
            for (;
                 true;
                 ) {
                
                //#line 120 "x10/lang/MultipleExceptions.x10"
                final boolean t$134827 = ((idx$134825) < (((long)(size$116150))));
                
                //#line 120 "x10/lang/MultipleExceptions.x10"
                if (!(t$134827)) {
                    
                    //#line 120 "x10/lang/MultipleExceptions.x10"
                    break;
                }
                
                //#line 120 "x10/lang/MultipleExceptions.x10"
                final java.lang.Throwable e$134822 = ((java.lang.Throwable)(((java.lang.Throwable)rail$116149$value$135037[(int)idx$134825])));
                
                //#line 121 "x10/lang/MultipleExceptions.x10"
                final boolean t$134819 = x10.lang.MultipleExceptions.$RTT.isInstance(e$134822);
                
                //#line 121 "x10/lang/MultipleExceptions.x10"
                if (t$134819) {
                    
                    //#line 122 "x10/lang/MultipleExceptions.x10"
                    final x10.lang.MultipleExceptions t$134820 = ((x10.lang.MultipleExceptions)(x10.rtt.Types.<x10.lang.MultipleExceptions> cast(e$134822,x10.lang.MultipleExceptions.$RTT)));
                    
                    //#line 122 "x10/lang/MultipleExceptions.x10"
                    x10.lang.MultipleExceptions.flattenAux__1$1x10$lang$CheckedThrowable$2(((x10.lang.MultipleExceptions)(t$134820)), ((x10.util.GrowableRail)(acc)));
                } else {
                    
                    //#line 124 "x10/lang/MultipleExceptions.x10"
                    ((x10.util.GrowableRail<java.lang.Throwable>)acc).add__0x10$util$GrowableRail$$T(((java.lang.Throwable)(e$134822)));
                }
                
                //#line 120 "x10/lang/MultipleExceptions.x10"
                final long t$134824 = ((idx$134825) + (((long)(1L))));
                
                //#line 120 "x10/lang/MultipleExceptions.x10"
                idx$134825 = t$134824;
            }
        }
    }
    
    public static void flattenAux$P__1$1x10$lang$CheckedThrowable$2(final x10.lang.MultipleExceptions me, final x10.util.GrowableRail<java.lang.Throwable> acc) {
        x10.lang.MultipleExceptions.flattenAux__1$1x10$lang$CheckedThrowable$2(((x10.lang.MultipleExceptions)(me)), ((x10.util.GrowableRail)(acc)));
    }
    
    
    //#line 130 "x10/lang/MultipleExceptions.x10"
    final private <$T>void splitExceptionsOfType__1$1x10$lang$MultipleExceptions$$T$2__2$1x10$lang$CheckedThrowable$2(final x10.rtt.Type $T, final boolean deep, final x10.util.GrowableRail accT, final x10.util.GrowableRail accNotT) {
        
        //#line 132 "x10/lang/MultipleExceptions.x10"
        final x10.core.Rail rail$116174 = ((x10.core.Rail)(this.exceptions));
        
        //#line 132 "x10/lang/MultipleExceptions.x10"
        final long size$116175 = ((x10.core.Rail<java.lang.Throwable>)rail$116174).size;
        
        //#line 132 "x10/lang/MultipleExceptions.x10"
        long idx$134837 = 0L;
        {
            
            //#line 132 "x10/lang/MultipleExceptions.x10"
            final java.lang.Throwable[] rail$116174$value$135038 = ((java.lang.Throwable[])rail$116174.value);
            
            //#line 132 "x10/lang/MultipleExceptions.x10"
            for (;
                 true;
                 ) {
                
                //#line 132 "x10/lang/MultipleExceptions.x10"
                final boolean t$134839 = ((idx$134837) < (((long)(size$116175))));
                
                //#line 132 "x10/lang/MultipleExceptions.x10"
                if (!(t$134839)) {
                    
                    //#line 132 "x10/lang/MultipleExceptions.x10"
                    break;
                }
                
                //#line 132 "x10/lang/MultipleExceptions.x10"
                final java.lang.Throwable e$134834 = ((java.lang.Throwable)(((java.lang.Throwable)rail$116174$value$135038[(int)idx$134837])));
                
                //#line 133 "x10/lang/MultipleExceptions.x10"
                boolean t$134828 = deep;
                
                //#line 133 "x10/lang/MultipleExceptions.x10"
                if (deep) {
                    
                    //#line 133 "x10/lang/MultipleExceptions.x10"
                    t$134828 = x10.lang.MultipleExceptions.$RTT.isInstance(e$134834);
                }
                
                //#line 133 "x10/lang/MultipleExceptions.x10"
                if (t$134828) {
                    
                    //#line 134 "x10/lang/MultipleExceptions.x10"
                    final x10.lang.MultipleExceptions t$134830 = ((x10.lang.MultipleExceptions)(x10.rtt.Types.<x10.lang.MultipleExceptions> cast(e$134834,x10.lang.MultipleExceptions.$RTT)));
                    
                    //#line 134 "x10/lang/MultipleExceptions.x10"
                    ((x10.lang.MultipleExceptions)t$134830).<$T> splitExceptionsOfType__1$1x10$lang$MultipleExceptions$$T$2__2$1x10$lang$CheckedThrowable$2($T, (boolean)(deep), ((x10.util.GrowableRail)(accT)), ((x10.util.GrowableRail)(accNotT)));
                } else {
                    
                    //#line 135 "x10/lang/MultipleExceptions.x10"
                    final boolean t$134831 = $T.isInstance(e$134834);
                    
                    //#line 135 "x10/lang/MultipleExceptions.x10"
                    if (t$134831) {
                        
                        //#line 136 "x10/lang/MultipleExceptions.x10"
                        final $T t$134832 = (($T)(x10.rtt.Types.<$T> castConversion(e$134834,$T)));
                        
                        //#line 136 "x10/lang/MultipleExceptions.x10"
                        ((x10.util.GrowableRail<$T>)accT).add__0x10$util$GrowableRail$$T((($T)(t$134832)));
                    } else {
                        
                        //#line 138 "x10/lang/MultipleExceptions.x10"
                        ((x10.util.GrowableRail<java.lang.Throwable>)accNotT).add__0x10$util$GrowableRail$$T(((java.lang.Throwable)(e$134834)));
                    }
                }
                
                //#line 132 "x10/lang/MultipleExceptions.x10"
                final long t$134836 = ((idx$134837) + (((long)(1L))));
                
                //#line 132 "x10/lang/MultipleExceptions.x10"
                idx$134837 = t$134836;
            }
        }
    }
    
    final public static <$T>void splitExceptionsOfType$P__1$1x10$lang$MultipleExceptions$$T$2__2$1x10$lang$CheckedThrowable$2(final x10.rtt.Type $T, final boolean deep, final x10.util.GrowableRail<$T> accT, final x10.util.GrowableRail<java.lang.Throwable> accNotT, final x10.lang.MultipleExceptions MultipleExceptions) {
        ((x10.lang.MultipleExceptions)MultipleExceptions).<$T> splitExceptionsOfType__1$1x10$lang$MultipleExceptions$$T$2__2$1x10$lang$CheckedThrowable$2($T, (boolean)(deep), ((x10.util.GrowableRail)(accT)), ((x10.util.GrowableRail)(accNotT)));
    }
    
    
    //#line 220 "x10/lang/MultipleExceptions.x10"
    /**
     * try control structure that catches MultipleExceptions and
     * executes the handler on the rail containing all the exceptions
     * of type E that was in the MultipleExceptions. The remaining
     * exceptions are re-thrown in a MultipleExceptions. For example,
     * the following code prints the number of exceptions of type
     * UnsupportedOperationException. Here, the value 2 is printed and
     * the exception of type IllegalOperationException is re-thrown in
     * a MultipleExceptions.
     *
     *    MultipleExceptions.try(true) {
     *      finish {
     *        async { throw new UnsupportedOperationException(); }
     *        finish {
     *          async { throw new UnsupportedOperationException(); }
     *          async { throw new IllegalOperationException(); }
     *        }
     *      }
     *    } catch (t: Rail[UnsupportedOperationException]) {
     *        Console.OUT.println(t.size);
     *    }
     *
     * @param deep perform a deep traversal of the tree of MultipleExceptions
     * @param body the body of the try block
     * @param handler the body of the exception handler
     *
     */
    public static <$E>void kwd_try__2$1x10$lang$Rail$1x10$lang$MultipleExceptions$$E$2$2(final x10.rtt.Type $E, final boolean deep, final x10.core.fun.VoidFun_0_0 body, final x10.core.fun.VoidFun_0_1<x10.core.Rail<$E>> handler) {
        
        //#line 223 "x10/lang/MultipleExceptions.x10"
        try {{
            
            //#line 223 "x10/lang/MultipleExceptions.x10"
            ((x10.core.fun.VoidFun_0_0)body).$apply();
        }}catch (final x10.lang.MultipleExceptions me) {
            
            //#line 225 "x10/lang/MultipleExceptions.x10"
            final x10.util.GrowableRail exns = ((x10.util.GrowableRail)(new x10.util.GrowableRail<$E>((java.lang.System[]) null, $E)));
            
            //#line 50 . "x10/util/GrowableRail.x10"
            exns.x10$util$GrowableRail$$init$S(((long)(0L)));
            
            //#line 226 "x10/lang/MultipleExceptions.x10"
            final x10.util.GrowableRail others = ((x10.util.GrowableRail)(new x10.util.GrowableRail<java.lang.Throwable>((java.lang.System[]) null, x10.rtt.Types.CHECKED_THROWABLE)));
            
            //#line 50 . "x10/util/GrowableRail.x10"
            others.x10$util$GrowableRail$$init$S(((long)(0L)));
            
            //#line 227 "x10/lang/MultipleExceptions.x10"
            ((x10.lang.MultipleExceptions)me).<$E> splitExceptionsOfType__1$1x10$lang$MultipleExceptions$$T$2__2$1x10$lang$CheckedThrowable$2($E, (boolean)(deep), ((x10.util.GrowableRail)(exns)), ((x10.util.GrowableRail)(others)));
            
            //#line 166 . "x10/util/GrowableRail.x10"
            final long t$134600 = ((x10.util.GrowableRail<$E>)exns).size;
            
            //#line 228 "x10/lang/MultipleExceptions.x10"
            final boolean t$134602 = ((t$134600) > (((long)(0L))));
            
            //#line 228 "x10/lang/MultipleExceptions.x10"
            if (t$134602) {
                
                //#line 228 "x10/lang/MultipleExceptions.x10"
                final x10.core.Rail t$134601 = ((x10.core.Rail<$E>)
                                                 ((x10.util.GrowableRail<$E>)exns).toRail());
                
                //#line 228 "x10/lang/MultipleExceptions.x10"
                ((x10.core.fun.VoidFun_0_1<x10.core.Rail<$E>>)handler).$apply(t$134601, x10.rtt.ParameterizedType.make(x10.core.Rail.$RTT, $E));
            }
            
            //#line 166 . "x10/util/GrowableRail.x10"
            final long t$134603 = ((x10.util.GrowableRail<java.lang.Throwable>)others).size;
            
            //#line 229 "x10/lang/MultipleExceptions.x10"
            final boolean t$134605 = ((t$134603) > (((long)(0L))));
            
            //#line 229 "x10/lang/MultipleExceptions.x10"
            if (t$134605) {
                
                //#line 229 "x10/lang/MultipleExceptions.x10"
                final x10.lang.MultipleExceptions t$134604 = ((x10.lang.MultipleExceptions)(new x10.lang.MultipleExceptions(((x10.util.GrowableRail<java.lang.Throwable>)(others)), (x10.lang.MultipleExceptions.__0$1x10$lang$CheckedThrowable$2) null)));
                
                //#line 229 "x10/lang/MultipleExceptions.x10"
                throw t$134604;
            }
        }
    }
    
    
    //#line 246 "x10/lang/MultipleExceptions.x10"
    /**
     * try control structure with a finally block that catches
     * MultipleExceptions and executes the handler on the rail
     * containing all the exceptions of type E that was in the
     * MultipleExceptions. The remaining exceptions are re-thrown
     * in a MultipleExceptions.
     *
     * @param deep perform a deep traversal of the tree of MultipleExceptions
     * @param body the body of the try block
     * @param handler the body of the exception handler
     * @param finallyBlock the body of finally block
     *
     */
    public static <$E>void kwd_try__2$1x10$lang$Rail$1x10$lang$MultipleExceptions$$E$2$2(final x10.rtt.Type $E, final boolean deep, final x10.core.fun.VoidFun_0_0 body, final x10.core.fun.VoidFun_0_1<x10.core.Rail<$E>> handler, final x10.core.fun.VoidFun_0_0 finallyBlock) {
        
        //#line 250 "x10/lang/MultipleExceptions.x10"
        try {{
            
            //#line 250 "x10/lang/MultipleExceptions.x10"
            ((x10.core.fun.VoidFun_0_0)body).$apply();
        }}catch (final x10.lang.MultipleExceptions me) {
            
            //#line 252 "x10/lang/MultipleExceptions.x10"
            final x10.util.GrowableRail exns = ((x10.util.GrowableRail)(new x10.util.GrowableRail<$E>((java.lang.System[]) null, $E)));
            
            //#line 50 . "x10/util/GrowableRail.x10"
            exns.x10$util$GrowableRail$$init$S(((long)(0L)));
            
            //#line 253 "x10/lang/MultipleExceptions.x10"
            final x10.util.GrowableRail others = ((x10.util.GrowableRail)(new x10.util.GrowableRail<java.lang.Throwable>((java.lang.System[]) null, x10.rtt.Types.CHECKED_THROWABLE)));
            
            //#line 50 . "x10/util/GrowableRail.x10"
            others.x10$util$GrowableRail$$init$S(((long)(0L)));
            
            //#line 254 "x10/lang/MultipleExceptions.x10"
            ((x10.lang.MultipleExceptions)me).<$E> splitExceptionsOfType__1$1x10$lang$MultipleExceptions$$T$2__2$1x10$lang$CheckedThrowable$2($E, (boolean)(deep), ((x10.util.GrowableRail)(exns)), ((x10.util.GrowableRail)(others)));
            
            //#line 166 . "x10/util/GrowableRail.x10"
            final long t$134606 = ((x10.util.GrowableRail<$E>)exns).size;
            
            //#line 255 "x10/lang/MultipleExceptions.x10"
            final boolean t$134608 = ((t$134606) > (((long)(0L))));
            
            //#line 255 "x10/lang/MultipleExceptions.x10"
            if (t$134608) {
                
                //#line 255 "x10/lang/MultipleExceptions.x10"
                final x10.core.Rail t$134607 = ((x10.core.Rail<$E>)
                                                 ((x10.util.GrowableRail<$E>)exns).toRail());
                
                //#line 255 "x10/lang/MultipleExceptions.x10"
                ((x10.core.fun.VoidFun_0_1<x10.core.Rail<$E>>)handler).$apply(t$134607, x10.rtt.ParameterizedType.make(x10.core.Rail.$RTT, $E));
            }
            
            //#line 166 . "x10/util/GrowableRail.x10"
            final long t$134609 = ((x10.util.GrowableRail<java.lang.Throwable>)others).size;
            
            //#line 256 "x10/lang/MultipleExceptions.x10"
            final boolean t$134611 = ((t$134609) > (((long)(0L))));
            
            //#line 256 "x10/lang/MultipleExceptions.x10"
            if (t$134611) {
                
                //#line 256 "x10/lang/MultipleExceptions.x10"
                final x10.lang.MultipleExceptions t$134610 = ((x10.lang.MultipleExceptions)(new x10.lang.MultipleExceptions(((x10.util.GrowableRail<java.lang.Throwable>)(others)), (x10.lang.MultipleExceptions.__0$1x10$lang$CheckedThrowable$2) null)));
                
                //#line 256 "x10/lang/MultipleExceptions.x10"
                throw t$134610;
            }
        }finally {{
             
             //#line 258 "x10/lang/MultipleExceptions.x10"
             ((x10.core.fun.VoidFun_0_0)finallyBlock).$apply();
         }}
        }
    
    
    //#line 272 "x10/lang/MultipleExceptions.x10"
    /**
     * try control structure that catches MultipleExceptions and
     * executes the handler on the rail containing all the exceptions
     * of type E that was in the MultipleExceptions and the nested
     * nested ones. The remaining exceptions are re-thrown in a
     * MultipleExceptions.
     *
     * @param body the body of the try block
     * @param handler the body of the exception handler
     *
     */
    public static <$E>void kwd_try__1$1x10$lang$Rail$1x10$lang$MultipleExceptions$$E$2$2(final x10.rtt.Type $E, final x10.core.fun.VoidFun_0_0 body, final x10.core.fun.VoidFun_0_1<x10.core.Rail<$E>> handler) {
        
        //#line 223 . "x10/lang/MultipleExceptions.x10"
        try {{
            
            //#line 223 . "x10/lang/MultipleExceptions.x10"
            ((x10.core.fun.VoidFun_0_0)body).$apply();
        }}catch (final x10.lang.MultipleExceptions me$134840) {
            
            //#line 225 . "x10/lang/MultipleExceptions.x10"
            final x10.util.GrowableRail exns$134841 = ((x10.util.GrowableRail)(new x10.util.GrowableRail<$E>((java.lang.System[]) null, $E)));
            
            //#line 50 .. "x10/util/GrowableRail.x10"
            exns$134841.x10$util$GrowableRail$$init$S(((long)(0L)));
            
            //#line 226 . "x10/lang/MultipleExceptions.x10"
            final x10.util.GrowableRail others$134842 = ((x10.util.GrowableRail)(new x10.util.GrowableRail<java.lang.Throwable>((java.lang.System[]) null, x10.rtt.Types.CHECKED_THROWABLE)));
            
            //#line 50 .. "x10/util/GrowableRail.x10"
            others$134842.x10$util$GrowableRail$$init$S(((long)(0L)));
            
            //#line 227 . "x10/lang/MultipleExceptions.x10"
            ((x10.lang.MultipleExceptions)me$134840).<$E> splitExceptionsOfType__1$1x10$lang$MultipleExceptions$$T$2__2$1x10$lang$CheckedThrowable$2($E, (boolean)(true), ((x10.util.GrowableRail)(exns$134841)), ((x10.util.GrowableRail)(others$134842)));
            
            //#line 166 .. "x10/util/GrowableRail.x10"
            final long t$134843 = ((x10.util.GrowableRail<$E>)exns$134841).size;
            
            //#line 228 . "x10/lang/MultipleExceptions.x10"
            final boolean t$134844 = ((t$134843) > (((long)(0L))));
            
            //#line 228 . "x10/lang/MultipleExceptions.x10"
            if (t$134844) {
                
                //#line 228 . "x10/lang/MultipleExceptions.x10"
                final x10.core.Rail t$134845 = ((x10.core.Rail<$E>)
                                                 ((x10.util.GrowableRail<$E>)exns$134841).toRail());
                
                //#line 228 . "x10/lang/MultipleExceptions.x10"
                ((x10.core.fun.VoidFun_0_1<x10.core.Rail<$E>>)handler).$apply(t$134845, x10.rtt.ParameterizedType.make(x10.core.Rail.$RTT, $E));
            }
            
            //#line 166 .. "x10/util/GrowableRail.x10"
            final long t$134846 = ((x10.util.GrowableRail<java.lang.Throwable>)others$134842).size;
            
            //#line 229 . "x10/lang/MultipleExceptions.x10"
            final boolean t$134847 = ((t$134846) > (((long)(0L))));
            
            //#line 229 . "x10/lang/MultipleExceptions.x10"
            if (t$134847) {
                
                //#line 229 . "x10/lang/MultipleExceptions.x10"
                final boolean t$134848 = true;
                
                //#line 229 . "x10/lang/MultipleExceptions.x10"
                if (t$134848) {
                    
                    //#line 229 . "x10/lang/MultipleExceptions.x10"
                    final x10.lang.MultipleExceptions t$134849 = ((x10.lang.MultipleExceptions)(new x10.lang.MultipleExceptions(((x10.util.GrowableRail<java.lang.Throwable>)(others$134842)), (x10.lang.MultipleExceptions.__0$1x10$lang$CheckedThrowable$2) null)));
                    
                    //#line 229 . "x10/lang/MultipleExceptions.x10"
                    throw t$134849;
                }
            }
        }
    }
    
    
    //#line 289 "x10/lang/MultipleExceptions.x10"
    /**
     * try control structure with a finally block that catches
     * MultipleExceptions and executes the handler on the rail
     * containing all the exceptions of type E that was in the
     * MultipleExceptions and the nested nested ones. The remaining
     * exceptions are re-thrown in a MultipleExceptions.
     *
     * @param body the body of the try block
     * @param handler the body of the exception handler
     * @param finallyBlock the body of finally block
     *
     */
    public static <$E>void kwd_try__1$1x10$lang$Rail$1x10$lang$MultipleExceptions$$E$2$2(final x10.rtt.Type $E, final x10.core.fun.VoidFun_0_0 body, final x10.core.fun.VoidFun_0_1<x10.core.Rail<$E>> handler, final x10.core.fun.VoidFun_0_0 finallyBlock) {
        
        //#line 250 . "x10/lang/MultipleExceptions.x10"
        try {{
            
            //#line 250 . "x10/lang/MultipleExceptions.x10"
            ((x10.core.fun.VoidFun_0_0)body).$apply();
        }}catch (final x10.lang.MultipleExceptions me$134850) {
            
            //#line 252 . "x10/lang/MultipleExceptions.x10"
            final x10.util.GrowableRail exns$134851 = ((x10.util.GrowableRail)(new x10.util.GrowableRail<$E>((java.lang.System[]) null, $E)));
            
            //#line 50 .. "x10/util/GrowableRail.x10"
            exns$134851.x10$util$GrowableRail$$init$S(((long)(0L)));
            
            //#line 253 . "x10/lang/MultipleExceptions.x10"
            final x10.util.GrowableRail others$134852 = ((x10.util.GrowableRail)(new x10.util.GrowableRail<java.lang.Throwable>((java.lang.System[]) null, x10.rtt.Types.CHECKED_THROWABLE)));
            
            //#line 50 .. "x10/util/GrowableRail.x10"
            others$134852.x10$util$GrowableRail$$init$S(((long)(0L)));
            
            //#line 254 . "x10/lang/MultipleExceptions.x10"
            ((x10.lang.MultipleExceptions)me$134850).<$E> splitExceptionsOfType__1$1x10$lang$MultipleExceptions$$T$2__2$1x10$lang$CheckedThrowable$2($E, (boolean)(true), ((x10.util.GrowableRail)(exns$134851)), ((x10.util.GrowableRail)(others$134852)));
            
            //#line 166 .. "x10/util/GrowableRail.x10"
            final long t$134853 = ((x10.util.GrowableRail<$E>)exns$134851).size;
            
            //#line 255 . "x10/lang/MultipleExceptions.x10"
            final boolean t$134854 = ((t$134853) > (((long)(0L))));
            
            //#line 255 . "x10/lang/MultipleExceptions.x10"
            if (t$134854) {
                
                //#line 255 . "x10/lang/MultipleExceptions.x10"
                final x10.core.Rail t$134855 = ((x10.core.Rail<$E>)
                                                 ((x10.util.GrowableRail<$E>)exns$134851).toRail());
                
                //#line 255 . "x10/lang/MultipleExceptions.x10"
                ((x10.core.fun.VoidFun_0_1<x10.core.Rail<$E>>)handler).$apply(t$134855, x10.rtt.ParameterizedType.make(x10.core.Rail.$RTT, $E));
            }
            
            //#line 166 .. "x10/util/GrowableRail.x10"
            final long t$134856 = ((x10.util.GrowableRail<java.lang.Throwable>)others$134852).size;
            
            //#line 256 . "x10/lang/MultipleExceptions.x10"
            final boolean t$134857 = ((t$134856) > (((long)(0L))));
            
            //#line 256 . "x10/lang/MultipleExceptions.x10"
            if (t$134857) {
                
                //#line 256 . "x10/lang/MultipleExceptions.x10"
                final boolean t$134858 = true;
                
                //#line 256 . "x10/lang/MultipleExceptions.x10"
                if (t$134858) {
                    
                    //#line 256 . "x10/lang/MultipleExceptions.x10"
                    final x10.lang.MultipleExceptions t$134859 = ((x10.lang.MultipleExceptions)(new x10.lang.MultipleExceptions(((x10.util.GrowableRail<java.lang.Throwable>)(others$134852)), (x10.lang.MultipleExceptions.__0$1x10$lang$CheckedThrowable$2) null)));
                    
                    //#line 256 . "x10/lang/MultipleExceptions.x10"
                    throw t$134859;
                }
            }
        }finally {{
             
             //#line 258 . "x10/lang/MultipleExceptions.x10"
             ((x10.core.fun.VoidFun_0_0)finallyBlock).$apply();
         }}
        }
    
    
    //#line 310 "x10/lang/MultipleExceptions.x10"
    /**
     * try control structure that catches MultipleExceptions and
     * executes the first handler on the rail containing all the
     * exceptions of type E1 and the second handler on the rail
     * containing all the exceptions of type E2 that was in the
     * MultipleExceptions. The remaining exceptions are re-thrown in a
     * MultipleExceptions.
     *
     * @param deep perform a deep traversal of the tree of MultipleExceptions
     * @param body the body of the try block
     * @param handler1 the body of the exception handler
     * @param handler2 the body of the exception handler
     *
     */
    public static <$E1, $E2>void kwd_try__2$1x10$lang$Rail$1x10$lang$MultipleExceptions$$E1$2$2__3$1x10$lang$Rail$1x10$lang$MultipleExceptions$$E2$2$2(final x10.rtt.Type $E1, final x10.rtt.Type $E2, final boolean deep, final x10.core.fun.VoidFun_0_0 body, final x10.core.fun.VoidFun_0_1<x10.core.Rail<$E1>> handler1, final x10.core.fun.VoidFun_0_1<x10.core.Rail<$E2>> handler2) {
        
        //#line 314 "x10/lang/MultipleExceptions.x10"
        try {{
            
            //#line 314 "x10/lang/MultipleExceptions.x10"
            ((x10.core.fun.VoidFun_0_0)body).$apply();
        }}catch (final x10.lang.MultipleExceptions me) {
            
            //#line 316 "x10/lang/MultipleExceptions.x10"
            final x10.util.GrowableRail exns1 = ((x10.util.GrowableRail)(new x10.util.GrowableRail<$E1>((java.lang.System[]) null, $E1)));
            
            //#line 50 . "x10/util/GrowableRail.x10"
            exns1.x10$util$GrowableRail$$init$S(((long)(0L)));
            
            //#line 317 "x10/lang/MultipleExceptions.x10"
            final x10.util.GrowableRail others1 = ((x10.util.GrowableRail)(new x10.util.GrowableRail<java.lang.Throwable>((java.lang.System[]) null, x10.rtt.Types.CHECKED_THROWABLE)));
            
            //#line 50 . "x10/util/GrowableRail.x10"
            others1.x10$util$GrowableRail$$init$S(((long)(0L)));
            
            //#line 318 "x10/lang/MultipleExceptions.x10"
            ((x10.lang.MultipleExceptions)me).<$E1> splitExceptionsOfType__1$1x10$lang$MultipleExceptions$$T$2__2$1x10$lang$CheckedThrowable$2($E1, (boolean)(deep), ((x10.util.GrowableRail)(exns1)), ((x10.util.GrowableRail)(others1)));
            
            //#line 166 . "x10/util/GrowableRail.x10"
            final long t$134626 = ((x10.util.GrowableRail<$E1>)exns1).size;
            
            //#line 319 "x10/lang/MultipleExceptions.x10"
            final boolean t$134628 = ((t$134626) > (((long)(0L))));
            
            //#line 319 "x10/lang/MultipleExceptions.x10"
            if (t$134628) {
                
                //#line 319 "x10/lang/MultipleExceptions.x10"
                final x10.core.Rail t$134627 = ((x10.core.Rail<$E1>)
                                                 ((x10.util.GrowableRail<$E1>)exns1).toRail());
                
                //#line 319 "x10/lang/MultipleExceptions.x10"
                ((x10.core.fun.VoidFun_0_1<x10.core.Rail<$E1>>)handler1).$apply(t$134627, x10.rtt.ParameterizedType.make(x10.core.Rail.$RTT, $E1));
            }
            
            //#line 320 "x10/lang/MultipleExceptions.x10"
            final x10.util.GrowableRail exns2 = ((x10.util.GrowableRail)(new x10.util.GrowableRail<$E2>((java.lang.System[]) null, $E2)));
            
            //#line 50 . "x10/util/GrowableRail.x10"
            exns2.x10$util$GrowableRail$$init$S(((long)(0L)));
            
            //#line 321 "x10/lang/MultipleExceptions.x10"
            final x10.util.GrowableRail others2 = ((x10.util.GrowableRail)(new x10.util.GrowableRail<java.lang.Throwable>((java.lang.System[]) null, x10.rtt.Types.CHECKED_THROWABLE)));
            
            //#line 50 . "x10/util/GrowableRail.x10"
            others2.x10$util$GrowableRail$$init$S(((long)(0L)));
            
            //#line 322 "x10/lang/MultipleExceptions.x10"
            final x10.lang.MultipleExceptions t$134629 = ((x10.lang.MultipleExceptions)(new x10.lang.MultipleExceptions(((x10.util.GrowableRail<java.lang.Throwable>)(others1)), (x10.lang.MultipleExceptions.__0$1x10$lang$CheckedThrowable$2) null)));
            
            //#line 322 "x10/lang/MultipleExceptions.x10"
            ((x10.lang.MultipleExceptions)t$134629).<$E2> splitExceptionsOfType__1$1x10$lang$MultipleExceptions$$T$2__2$1x10$lang$CheckedThrowable$2($E2, (boolean)(deep), ((x10.util.GrowableRail)(exns2)), ((x10.util.GrowableRail)(others2)));
            
            //#line 166 . "x10/util/GrowableRail.x10"
            final long t$134630 = ((x10.util.GrowableRail<$E2>)exns2).size;
            
            //#line 323 "x10/lang/MultipleExceptions.x10"
            final boolean t$134632 = ((t$134630) > (((long)(0L))));
            
            //#line 323 "x10/lang/MultipleExceptions.x10"
            if (t$134632) {
                
                //#line 323 "x10/lang/MultipleExceptions.x10"
                final x10.core.Rail t$134631 = ((x10.core.Rail<$E2>)
                                                 ((x10.util.GrowableRail<$E2>)exns2).toRail());
                
                //#line 323 "x10/lang/MultipleExceptions.x10"
                ((x10.core.fun.VoidFun_0_1<x10.core.Rail<$E2>>)handler2).$apply(t$134631, x10.rtt.ParameterizedType.make(x10.core.Rail.$RTT, $E2));
            }
            
            //#line 166 . "x10/util/GrowableRail.x10"
            final long t$134633 = ((x10.util.GrowableRail<java.lang.Throwable>)others2).size;
            
            //#line 324 "x10/lang/MultipleExceptions.x10"
            final boolean t$134635 = ((t$134633) > (((long)(0L))));
            
            //#line 324 "x10/lang/MultipleExceptions.x10"
            if (t$134635) {
                
                //#line 324 "x10/lang/MultipleExceptions.x10"
                final x10.lang.MultipleExceptions t$134634 = ((x10.lang.MultipleExceptions)(new x10.lang.MultipleExceptions(((x10.util.GrowableRail<java.lang.Throwable>)(others2)), (x10.lang.MultipleExceptions.__0$1x10$lang$CheckedThrowable$2) null)));
                
                //#line 324 "x10/lang/MultipleExceptions.x10"
                throw t$134634;
            }
        }
    }
    
    
    //#line 343 "x10/lang/MultipleExceptions.x10"
    /**
     * try control structure with a finally block that catches
     * MultipleExceptions and executes the first handler on the rail
     * containing all the exceptions of type E1 and the second handler
     * on the rail containing all the exceptions of type E2 that was
     * in the MultipleExceptions. The remaining exceptions are
     * re-thrown in a MultipleExceptions.
     *
     * @param deep perform a deep traversal of the tree of MultipleExceptions
     * @param body the body of the try block
     * @param handler1 the body of the exception handler
     * @param handler2 the body of the exception handler
     *
     */
    public static <$E1, $E2>void kwd_try__2$1x10$lang$Rail$1x10$lang$MultipleExceptions$$E1$2$2__3$1x10$lang$Rail$1x10$lang$MultipleExceptions$$E2$2$2(final x10.rtt.Type $E1, final x10.rtt.Type $E2, final boolean deep, final x10.core.fun.VoidFun_0_0 body, final x10.core.fun.VoidFun_0_1<x10.core.Rail<$E1>> handler1, final x10.core.fun.VoidFun_0_1<x10.core.Rail<$E2>> handler2, final x10.core.fun.VoidFun_0_0 finallyBlock) {
        
        //#line 348 "x10/lang/MultipleExceptions.x10"
        try {{
            
            //#line 348 "x10/lang/MultipleExceptions.x10"
            ((x10.core.fun.VoidFun_0_0)body).$apply();
        }}catch (final x10.lang.MultipleExceptions me) {
            
            //#line 350 "x10/lang/MultipleExceptions.x10"
            final x10.util.GrowableRail exns1 = ((x10.util.GrowableRail)(new x10.util.GrowableRail<$E1>((java.lang.System[]) null, $E1)));
            
            //#line 50 . "x10/util/GrowableRail.x10"
            exns1.x10$util$GrowableRail$$init$S(((long)(0L)));
            
            //#line 351 "x10/lang/MultipleExceptions.x10"
            final x10.util.GrowableRail others1 = ((x10.util.GrowableRail)(new x10.util.GrowableRail<java.lang.Throwable>((java.lang.System[]) null, x10.rtt.Types.CHECKED_THROWABLE)));
            
            //#line 50 . "x10/util/GrowableRail.x10"
            others1.x10$util$GrowableRail$$init$S(((long)(0L)));
            
            //#line 352 "x10/lang/MultipleExceptions.x10"
            ((x10.lang.MultipleExceptions)me).<$E1> splitExceptionsOfType__1$1x10$lang$MultipleExceptions$$T$2__2$1x10$lang$CheckedThrowable$2($E1, (boolean)(deep), ((x10.util.GrowableRail)(exns1)), ((x10.util.GrowableRail)(others1)));
            
            //#line 166 . "x10/util/GrowableRail.x10"
            final long t$134636 = ((x10.util.GrowableRail<$E1>)exns1).size;
            
            //#line 353 "x10/lang/MultipleExceptions.x10"
            final boolean t$134638 = ((t$134636) > (((long)(0L))));
            
            //#line 353 "x10/lang/MultipleExceptions.x10"
            if (t$134638) {
                
                //#line 353 "x10/lang/MultipleExceptions.x10"
                final x10.core.Rail t$134637 = ((x10.core.Rail<$E1>)
                                                 ((x10.util.GrowableRail<$E1>)exns1).toRail());
                
                //#line 353 "x10/lang/MultipleExceptions.x10"
                ((x10.core.fun.VoidFun_0_1<x10.core.Rail<$E1>>)handler1).$apply(t$134637, x10.rtt.ParameterizedType.make(x10.core.Rail.$RTT, $E1));
            }
            
            //#line 354 "x10/lang/MultipleExceptions.x10"
            final x10.util.GrowableRail exns2 = ((x10.util.GrowableRail)(new x10.util.GrowableRail<$E2>((java.lang.System[]) null, $E2)));
            
            //#line 50 . "x10/util/GrowableRail.x10"
            exns2.x10$util$GrowableRail$$init$S(((long)(0L)));
            
            //#line 355 "x10/lang/MultipleExceptions.x10"
            final x10.util.GrowableRail others2 = ((x10.util.GrowableRail)(new x10.util.GrowableRail<java.lang.Throwable>((java.lang.System[]) null, x10.rtt.Types.CHECKED_THROWABLE)));
            
            //#line 50 . "x10/util/GrowableRail.x10"
            others2.x10$util$GrowableRail$$init$S(((long)(0L)));
            
            //#line 356 "x10/lang/MultipleExceptions.x10"
            final x10.lang.MultipleExceptions t$134639 = ((x10.lang.MultipleExceptions)(new x10.lang.MultipleExceptions(((x10.util.GrowableRail<java.lang.Throwable>)(others1)), (x10.lang.MultipleExceptions.__0$1x10$lang$CheckedThrowable$2) null)));
            
            //#line 356 "x10/lang/MultipleExceptions.x10"
            ((x10.lang.MultipleExceptions)t$134639).<$E2> splitExceptionsOfType__1$1x10$lang$MultipleExceptions$$T$2__2$1x10$lang$CheckedThrowable$2($E2, (boolean)(deep), ((x10.util.GrowableRail)(exns2)), ((x10.util.GrowableRail)(others2)));
            
            //#line 166 . "x10/util/GrowableRail.x10"
            final long t$134640 = ((x10.util.GrowableRail<$E2>)exns2).size;
            
            //#line 357 "x10/lang/MultipleExceptions.x10"
            final boolean t$134642 = ((t$134640) > (((long)(0L))));
            
            //#line 357 "x10/lang/MultipleExceptions.x10"
            if (t$134642) {
                
                //#line 357 "x10/lang/MultipleExceptions.x10"
                final x10.core.Rail t$134641 = ((x10.core.Rail<$E2>)
                                                 ((x10.util.GrowableRail<$E2>)exns2).toRail());
                
                //#line 357 "x10/lang/MultipleExceptions.x10"
                ((x10.core.fun.VoidFun_0_1<x10.core.Rail<$E2>>)handler2).$apply(t$134641, x10.rtt.ParameterizedType.make(x10.core.Rail.$RTT, $E2));
            }
            
            //#line 166 . "x10/util/GrowableRail.x10"
            final long t$134643 = ((x10.util.GrowableRail<java.lang.Throwable>)others2).size;
            
            //#line 358 "x10/lang/MultipleExceptions.x10"
            final boolean t$134645 = ((t$134643) > (((long)(0L))));
            
            //#line 358 "x10/lang/MultipleExceptions.x10"
            if (t$134645) {
                
                //#line 358 "x10/lang/MultipleExceptions.x10"
                final x10.lang.MultipleExceptions t$134644 = ((x10.lang.MultipleExceptions)(new x10.lang.MultipleExceptions(((x10.util.GrowableRail<java.lang.Throwable>)(others2)), (x10.lang.MultipleExceptions.__0$1x10$lang$CheckedThrowable$2) null)));
                
                //#line 358 "x10/lang/MultipleExceptions.x10"
                throw t$134644;
            }
        }finally {{
             
             //#line 359 "x10/lang/MultipleExceptions.x10"
             ((x10.core.fun.VoidFun_0_0)finallyBlock).$apply();
         }}
        }
    
    
    //#line 375 "x10/lang/MultipleExceptions.x10"
    /**
     * try control structure that catches MultipleExceptions and
     * executes the first handler on the rail containing all the
     * exceptions of type E1 and the second handler on the rail
     * containing all the exceptions of type E2 that was in the
     * MultipleExceptions and the nested nested ones. The remaining
     * exceptions are re-thrown in a MultipleExceptions.
     *
     * @param body the body of the try block
     * @param handler1 the body of the exception handler
     * @param handler2 the body of the exception handler
     *
     */
    public static <$E1, $E2>void kwd_try__1$1x10$lang$Rail$1x10$lang$MultipleExceptions$$E1$2$2__2$1x10$lang$Rail$1x10$lang$MultipleExceptions$$E2$2$2(final x10.rtt.Type $E1, final x10.rtt.Type $E2, final x10.core.fun.VoidFun_0_0 body, final x10.core.fun.VoidFun_0_1<x10.core.Rail<$E1>> handler1, final x10.core.fun.VoidFun_0_1<x10.core.Rail<$E2>> handler2) {
        
        //#line 314 . "x10/lang/MultipleExceptions.x10"
        try {{
            
            //#line 314 . "x10/lang/MultipleExceptions.x10"
            ((x10.core.fun.VoidFun_0_0)body).$apply();
        }}catch (final x10.lang.MultipleExceptions me$134860) {
            
            //#line 316 . "x10/lang/MultipleExceptions.x10"
            final x10.util.GrowableRail exns$134861 = ((x10.util.GrowableRail)(new x10.util.GrowableRail<$E1>((java.lang.System[]) null, $E1)));
            
            //#line 50 .. "x10/util/GrowableRail.x10"
            exns$134861.x10$util$GrowableRail$$init$S(((long)(0L)));
            
            //#line 317 . "x10/lang/MultipleExceptions.x10"
            final x10.util.GrowableRail others$134862 = ((x10.util.GrowableRail)(new x10.util.GrowableRail<java.lang.Throwable>((java.lang.System[]) null, x10.rtt.Types.CHECKED_THROWABLE)));
            
            //#line 50 .. "x10/util/GrowableRail.x10"
            others$134862.x10$util$GrowableRail$$init$S(((long)(0L)));
            
            //#line 318 . "x10/lang/MultipleExceptions.x10"
            ((x10.lang.MultipleExceptions)me$134860).<$E1> splitExceptionsOfType__1$1x10$lang$MultipleExceptions$$T$2__2$1x10$lang$CheckedThrowable$2($E1, (boolean)(true), ((x10.util.GrowableRail)(exns$134861)), ((x10.util.GrowableRail)(others$134862)));
            
            //#line 166 .. "x10/util/GrowableRail.x10"
            final long t$134863 = ((x10.util.GrowableRail<$E1>)exns$134861).size;
            
            //#line 319 . "x10/lang/MultipleExceptions.x10"
            final boolean t$134864 = ((t$134863) > (((long)(0L))));
            
            //#line 319 . "x10/lang/MultipleExceptions.x10"
            if (t$134864) {
                
                //#line 319 . "x10/lang/MultipleExceptions.x10"
                final x10.core.Rail t$134865 = ((x10.core.Rail<$E1>)
                                                 ((x10.util.GrowableRail<$E1>)exns$134861).toRail());
                
                //#line 319 . "x10/lang/MultipleExceptions.x10"
                ((x10.core.fun.VoidFun_0_1<x10.core.Rail<$E1>>)handler1).$apply(t$134865, x10.rtt.ParameterizedType.make(x10.core.Rail.$RTT, $E1));
            }
            
            //#line 320 . "x10/lang/MultipleExceptions.x10"
            final x10.util.GrowableRail exns$134866 = ((x10.util.GrowableRail)(new x10.util.GrowableRail<$E2>((java.lang.System[]) null, $E2)));
            
            //#line 50 .. "x10/util/GrowableRail.x10"
            exns$134866.x10$util$GrowableRail$$init$S(((long)(0L)));
            
            //#line 321 . "x10/lang/MultipleExceptions.x10"
            final x10.util.GrowableRail others$134867 = ((x10.util.GrowableRail)(new x10.util.GrowableRail<java.lang.Throwable>((java.lang.System[]) null, x10.rtt.Types.CHECKED_THROWABLE)));
            
            //#line 50 .. "x10/util/GrowableRail.x10"
            others$134867.x10$util$GrowableRail$$init$S(((long)(0L)));
            
            //#line 322 . "x10/lang/MultipleExceptions.x10"
            final x10.lang.MultipleExceptions t$134868 = ((x10.lang.MultipleExceptions)(new x10.lang.MultipleExceptions(((x10.util.GrowableRail<java.lang.Throwable>)(others$134862)), (x10.lang.MultipleExceptions.__0$1x10$lang$CheckedThrowable$2) null)));
            
            //#line 322 . "x10/lang/MultipleExceptions.x10"
            ((x10.lang.MultipleExceptions)t$134868).<$E2> splitExceptionsOfType__1$1x10$lang$MultipleExceptions$$T$2__2$1x10$lang$CheckedThrowable$2($E2, (boolean)(true), ((x10.util.GrowableRail)(exns$134866)), ((x10.util.GrowableRail)(others$134867)));
            
            //#line 166 .. "x10/util/GrowableRail.x10"
            final long t$134869 = ((x10.util.GrowableRail<$E2>)exns$134866).size;
            
            //#line 323 . "x10/lang/MultipleExceptions.x10"
            final boolean t$134870 = ((t$134869) > (((long)(0L))));
            
            //#line 323 . "x10/lang/MultipleExceptions.x10"
            if (t$134870) {
                
                //#line 323 . "x10/lang/MultipleExceptions.x10"
                final x10.core.Rail t$134871 = ((x10.core.Rail<$E2>)
                                                 ((x10.util.GrowableRail<$E2>)exns$134866).toRail());
                
                //#line 323 . "x10/lang/MultipleExceptions.x10"
                ((x10.core.fun.VoidFun_0_1<x10.core.Rail<$E2>>)handler2).$apply(t$134871, x10.rtt.ParameterizedType.make(x10.core.Rail.$RTT, $E2));
            }
            
            //#line 166 .. "x10/util/GrowableRail.x10"
            final long t$134872 = ((x10.util.GrowableRail<java.lang.Throwable>)others$134867).size;
            
            //#line 324 . "x10/lang/MultipleExceptions.x10"
            final boolean t$134873 = ((t$134872) > (((long)(0L))));
            
            //#line 324 . "x10/lang/MultipleExceptions.x10"
            if (t$134873) {
                
                //#line 324 . "x10/lang/MultipleExceptions.x10"
                final boolean t$134874 = true;
                
                //#line 324 . "x10/lang/MultipleExceptions.x10"
                if (t$134874) {
                    
                    //#line 324 . "x10/lang/MultipleExceptions.x10"
                    final x10.lang.MultipleExceptions t$134875 = ((x10.lang.MultipleExceptions)(new x10.lang.MultipleExceptions(((x10.util.GrowableRail<java.lang.Throwable>)(others$134867)), (x10.lang.MultipleExceptions.__0$1x10$lang$CheckedThrowable$2) null)));
                    
                    //#line 324 . "x10/lang/MultipleExceptions.x10"
                    throw t$134875;
                }
            }
        }
    }
    
    
    //#line 394 "x10/lang/MultipleExceptions.x10"
    /**
     * try control structure with a finally block that catches
     * MultipleExceptions and executes the first handler on the rail
     * containing all the exceptions of type E1 and the second handler
     * on the rail containing all the exceptions of type E2 that was
     * in the MultipleExceptions and the nested nested ones. The
     * remaining exceptions are re-thrown in a MultipleExceptions.
     *
     * @param body the body of the try block
     * @param handler1 the body of the exception handler
     * @param handler2 the body of the exception handler
     *
     */
    public static <$E1, $E2>void kwd_try__1$1x10$lang$Rail$1x10$lang$MultipleExceptions$$E1$2$2__2$1x10$lang$Rail$1x10$lang$MultipleExceptions$$E2$2$2(final x10.rtt.Type $E1, final x10.rtt.Type $E2, final x10.core.fun.VoidFun_0_0 body, final x10.core.fun.VoidFun_0_1<x10.core.Rail<$E1>> handler1, final x10.core.fun.VoidFun_0_1<x10.core.Rail<$E2>> handler2, final x10.core.fun.VoidFun_0_0 finallyBlock) {
        
        //#line 348 . "x10/lang/MultipleExceptions.x10"
        try {{
            
            //#line 348 . "x10/lang/MultipleExceptions.x10"
            ((x10.core.fun.VoidFun_0_0)body).$apply();
        }}catch (final x10.lang.MultipleExceptions me$134876) {
            
            //#line 350 . "x10/lang/MultipleExceptions.x10"
            final x10.util.GrowableRail exns$134877 = ((x10.util.GrowableRail)(new x10.util.GrowableRail<$E1>((java.lang.System[]) null, $E1)));
            
            //#line 50 .. "x10/util/GrowableRail.x10"
            exns$134877.x10$util$GrowableRail$$init$S(((long)(0L)));
            
            //#line 351 . "x10/lang/MultipleExceptions.x10"
            final x10.util.GrowableRail others$134878 = ((x10.util.GrowableRail)(new x10.util.GrowableRail<java.lang.Throwable>((java.lang.System[]) null, x10.rtt.Types.CHECKED_THROWABLE)));
            
            //#line 50 .. "x10/util/GrowableRail.x10"
            others$134878.x10$util$GrowableRail$$init$S(((long)(0L)));
            
            //#line 352 . "x10/lang/MultipleExceptions.x10"
            ((x10.lang.MultipleExceptions)me$134876).<$E1> splitExceptionsOfType__1$1x10$lang$MultipleExceptions$$T$2__2$1x10$lang$CheckedThrowable$2($E1, (boolean)(true), ((x10.util.GrowableRail)(exns$134877)), ((x10.util.GrowableRail)(others$134878)));
            
            //#line 166 .. "x10/util/GrowableRail.x10"
            final long t$134879 = ((x10.util.GrowableRail<$E1>)exns$134877).size;
            
            //#line 353 . "x10/lang/MultipleExceptions.x10"
            final boolean t$134880 = ((t$134879) > (((long)(0L))));
            
            //#line 353 . "x10/lang/MultipleExceptions.x10"
            if (t$134880) {
                
                //#line 353 . "x10/lang/MultipleExceptions.x10"
                final x10.core.Rail t$134881 = ((x10.core.Rail<$E1>)
                                                 ((x10.util.GrowableRail<$E1>)exns$134877).toRail());
                
                //#line 353 . "x10/lang/MultipleExceptions.x10"
                ((x10.core.fun.VoidFun_0_1<x10.core.Rail<$E1>>)handler1).$apply(t$134881, x10.rtt.ParameterizedType.make(x10.core.Rail.$RTT, $E1));
            }
            
            //#line 354 . "x10/lang/MultipleExceptions.x10"
            final x10.util.GrowableRail exns$134882 = ((x10.util.GrowableRail)(new x10.util.GrowableRail<$E2>((java.lang.System[]) null, $E2)));
            
            //#line 50 .. "x10/util/GrowableRail.x10"
            exns$134882.x10$util$GrowableRail$$init$S(((long)(0L)));
            
            //#line 355 . "x10/lang/MultipleExceptions.x10"
            final x10.util.GrowableRail others$134883 = ((x10.util.GrowableRail)(new x10.util.GrowableRail<java.lang.Throwable>((java.lang.System[]) null, x10.rtt.Types.CHECKED_THROWABLE)));
            
            //#line 50 .. "x10/util/GrowableRail.x10"
            others$134883.x10$util$GrowableRail$$init$S(((long)(0L)));
            
            //#line 356 . "x10/lang/MultipleExceptions.x10"
            final x10.lang.MultipleExceptions t$134884 = ((x10.lang.MultipleExceptions)(new x10.lang.MultipleExceptions(((x10.util.GrowableRail<java.lang.Throwable>)(others$134878)), (x10.lang.MultipleExceptions.__0$1x10$lang$CheckedThrowable$2) null)));
            
            //#line 356 . "x10/lang/MultipleExceptions.x10"
            ((x10.lang.MultipleExceptions)t$134884).<$E2> splitExceptionsOfType__1$1x10$lang$MultipleExceptions$$T$2__2$1x10$lang$CheckedThrowable$2($E2, (boolean)(true), ((x10.util.GrowableRail)(exns$134882)), ((x10.util.GrowableRail)(others$134883)));
            
            //#line 166 .. "x10/util/GrowableRail.x10"
            final long t$134885 = ((x10.util.GrowableRail<$E2>)exns$134882).size;
            
            //#line 357 . "x10/lang/MultipleExceptions.x10"
            final boolean t$134886 = ((t$134885) > (((long)(0L))));
            
            //#line 357 . "x10/lang/MultipleExceptions.x10"
            if (t$134886) {
                
                //#line 357 . "x10/lang/MultipleExceptions.x10"
                final x10.core.Rail t$134887 = ((x10.core.Rail<$E2>)
                                                 ((x10.util.GrowableRail<$E2>)exns$134882).toRail());
                
                //#line 357 . "x10/lang/MultipleExceptions.x10"
                ((x10.core.fun.VoidFun_0_1<x10.core.Rail<$E2>>)handler2).$apply(t$134887, x10.rtt.ParameterizedType.make(x10.core.Rail.$RTT, $E2));
            }
            
            //#line 166 .. "x10/util/GrowableRail.x10"
            final long t$134888 = ((x10.util.GrowableRail<java.lang.Throwable>)others$134883).size;
            
            //#line 358 . "x10/lang/MultipleExceptions.x10"
            final boolean t$134889 = ((t$134888) > (((long)(0L))));
            
            //#line 358 . "x10/lang/MultipleExceptions.x10"
            if (t$134889) {
                
                //#line 358 . "x10/lang/MultipleExceptions.x10"
                final boolean t$134890 = true;
                
                //#line 358 . "x10/lang/MultipleExceptions.x10"
                if (t$134890) {
                    
                    //#line 358 . "x10/lang/MultipleExceptions.x10"
                    final x10.lang.MultipleExceptions t$134891 = ((x10.lang.MultipleExceptions)(new x10.lang.MultipleExceptions(((x10.util.GrowableRail<java.lang.Throwable>)(others$134883)), (x10.lang.MultipleExceptions.__0$1x10$lang$CheckedThrowable$2) null)));
                    
                    //#line 358 . "x10/lang/MultipleExceptions.x10"
                    throw t$134891;
                }
            }
        }finally {{
             
             //#line 359 . "x10/lang/MultipleExceptions.x10"
             ((x10.core.fun.VoidFun_0_0)finallyBlock).$apply();
         }}
        }
    
    
    //#line 428 "x10/lang/MultipleExceptions.x10"
    /**
     * try control structure that catches MultipleExceptions and
     * executes the handler on each exception of type E that was in
     * the MultipleExceptions. The remaining exceptions are re-thrown
     * in a MultipleExceptions. For example, the following code prints
     * twice the message "UnsupportedOperationException catched" and
     * the exception of type IllegalOperationException is re-thrown in
     * a MultipleExceptions.
     *
     *    MultipleExceptions.try(true) {
     *      finish {
     *        async { throw new UnsupportedOperationException(); }
     *        finish {
     *          async { throw new UnsupportedOperationException(); }
     *          async { throw new IllegalOperationException(); }
     *        }
     *      }
     *    } catch (UnsupportedOperationException) {
     *        Console.OUT.println("UnsupportedOperationException catched");
     *    }
     *
     * @param deep perform a deep traversal of the tree of MultipleExceptions
     * @param body the body of the try block
     * @param handler the body of the exception handler
     *
     */
    public static <$E>void kwd_try__2$1x10$lang$MultipleExceptions$$E$2(final x10.rtt.Type $E, final boolean deep, final x10.core.fun.VoidFun_0_0 body, final x10.core.fun.VoidFun_0_1<$E> handler) {
        
        //#line 431 "x10/lang/MultipleExceptions.x10"
        try {{
            
            //#line 431 "x10/lang/MultipleExceptions.x10"
            ((x10.core.fun.VoidFun_0_0)body).$apply();
        }}catch (final x10.lang.MultipleExceptions me) {
            
            //#line 433 "x10/lang/MultipleExceptions.x10"
            final x10.util.GrowableRail exns = ((x10.util.GrowableRail)(new x10.util.GrowableRail<$E>((java.lang.System[]) null, $E)));
            
            //#line 50 . "x10/util/GrowableRail.x10"
            exns.x10$util$GrowableRail$$init$S(((long)(0L)));
            
            //#line 434 "x10/lang/MultipleExceptions.x10"
            final x10.util.GrowableRail others = ((x10.util.GrowableRail)(new x10.util.GrowableRail<java.lang.Throwable>((java.lang.System[]) null, x10.rtt.Types.CHECKED_THROWABLE)));
            
            //#line 50 . "x10/util/GrowableRail.x10"
            others.x10$util$GrowableRail$$init$S(((long)(0L)));
            
            //#line 435 "x10/lang/MultipleExceptions.x10"
            ((x10.lang.MultipleExceptions)me).<$E> splitExceptionsOfType__1$1x10$lang$MultipleExceptions$$T$2__2$1x10$lang$CheckedThrowable$2($E, (boolean)(deep), ((x10.util.GrowableRail)(exns)), ((x10.util.GrowableRail)(others)));
            
            //#line 436 "x10/lang/MultipleExceptions.x10"
            final x10.core.Rail rail$134899 = ((x10.core.Rail<$E>)
                                                ((x10.util.GrowableRail<$E>)exns).toRail());
            
            //#line 436 "x10/lang/MultipleExceptions.x10"
            final long size$134900 = ((x10.core.Rail<$E>)rail$134899).size;
            
            //#line 436 "x10/lang/MultipleExceptions.x10"
            long idx$134896 = 0L;
            
            //#line 436 "x10/lang/MultipleExceptions.x10"
            for (;
                 true;
                 ) {
                
                //#line 436 "x10/lang/MultipleExceptions.x10"
                final boolean t$134898 = ((idx$134896) < (((long)(size$134900))));
                
                //#line 436 "x10/lang/MultipleExceptions.x10"
                if (!(t$134898)) {
                    
                    //#line 436 "x10/lang/MultipleExceptions.x10"
                    break;
                }
                
                //#line 436 "x10/lang/MultipleExceptions.x10"
                final $E e$134893 = (($E)(((x10.core.Rail<$E>)rail$134899).$apply$G((long)(idx$134896))));
                
                //#line 437 "x10/lang/MultipleExceptions.x10"
                ((x10.core.fun.VoidFun_0_1<$E>)handler).$apply(e$134893, $E);
                
                //#line 436 "x10/lang/MultipleExceptions.x10"
                final long t$134895 = ((idx$134896) + (((long)(1L))));
                
                //#line 436 "x10/lang/MultipleExceptions.x10"
                idx$134896 = t$134895;
            }
            
            //#line 166 . "x10/util/GrowableRail.x10"
            final long t$134674 = ((x10.util.GrowableRail<java.lang.Throwable>)others).size;
            
            //#line 439 "x10/lang/MultipleExceptions.x10"
            final boolean t$134676 = ((t$134674) > (((long)(0L))));
            
            //#line 439 "x10/lang/MultipleExceptions.x10"
            if (t$134676) {
                
                //#line 439 "x10/lang/MultipleExceptions.x10"
                final x10.lang.MultipleExceptions t$134675 = ((x10.lang.MultipleExceptions)(new x10.lang.MultipleExceptions(((x10.util.GrowableRail<java.lang.Throwable>)(others)), (x10.lang.MultipleExceptions.__0$1x10$lang$CheckedThrowable$2) null)));
                
                //#line 439 "x10/lang/MultipleExceptions.x10"
                throw t$134675;
            }
        }
    }
    
    
    //#line 455 "x10/lang/MultipleExceptions.x10"
    /**
     * try control structure with a finally block that catches
     * MultipleExceptions and executes the handler on each exception
     * of type E that was in the MultipleExceptions. The remaining
     * exceptions are re-thrown in a MultipleExceptions.
     *
     * @param deep perform a deep traversal of the tree of MultipleExceptions
     * @param body the body of the try block
     * @param handler the body of the exception handler
     * @param finallyBlock the body of finally block
     *
     */
    public static <$E>void kwd_try__2$1x10$lang$MultipleExceptions$$E$2(final x10.rtt.Type $E, final boolean deep, final x10.core.fun.VoidFun_0_0 body, final x10.core.fun.VoidFun_0_1<$E> handler, final x10.core.fun.VoidFun_0_0 finallyBlock) {
        
        //#line 459 "x10/lang/MultipleExceptions.x10"
        try {{
            
            //#line 459 "x10/lang/MultipleExceptions.x10"
            ((x10.core.fun.VoidFun_0_0)body).$apply();
        }}catch (final x10.lang.MultipleExceptions me) {
            
            //#line 461 "x10/lang/MultipleExceptions.x10"
            final x10.util.GrowableRail exns = ((x10.util.GrowableRail)(new x10.util.GrowableRail<$E>((java.lang.System[]) null, $E)));
            
            //#line 50 . "x10/util/GrowableRail.x10"
            exns.x10$util$GrowableRail$$init$S(((long)(0L)));
            
            //#line 462 "x10/lang/MultipleExceptions.x10"
            final x10.util.GrowableRail others = ((x10.util.GrowableRail)(new x10.util.GrowableRail<java.lang.Throwable>((java.lang.System[]) null, x10.rtt.Types.CHECKED_THROWABLE)));
            
            //#line 50 . "x10/util/GrowableRail.x10"
            others.x10$util$GrowableRail$$init$S(((long)(0L)));
            
            //#line 463 "x10/lang/MultipleExceptions.x10"
            ((x10.lang.MultipleExceptions)me).<$E> splitExceptionsOfType__1$1x10$lang$MultipleExceptions$$T$2__2$1x10$lang$CheckedThrowable$2($E, (boolean)(deep), ((x10.util.GrowableRail)(exns)), ((x10.util.GrowableRail)(others)));
            
            //#line 464 "x10/lang/MultipleExceptions.x10"
            final x10.core.Rail rail$134908 = ((x10.core.Rail<$E>)
                                                ((x10.util.GrowableRail<$E>)exns).toRail());
            
            //#line 464 "x10/lang/MultipleExceptions.x10"
            final long size$134909 = ((x10.core.Rail<$E>)rail$134908).size;
            
            //#line 464 "x10/lang/MultipleExceptions.x10"
            long idx$134905 = 0L;
            
            //#line 464 "x10/lang/MultipleExceptions.x10"
            for (;
                 true;
                 ) {
                
                //#line 464 "x10/lang/MultipleExceptions.x10"
                final boolean t$134907 = ((idx$134905) < (((long)(size$134909))));
                
                //#line 464 "x10/lang/MultipleExceptions.x10"
                if (!(t$134907)) {
                    
                    //#line 464 "x10/lang/MultipleExceptions.x10"
                    break;
                }
                
                //#line 464 "x10/lang/MultipleExceptions.x10"
                final $E e$134902 = (($E)(((x10.core.Rail<$E>)rail$134908).$apply$G((long)(idx$134905))));
                
                //#line 465 "x10/lang/MultipleExceptions.x10"
                ((x10.core.fun.VoidFun_0_1<$E>)handler).$apply(e$134902, $E);
                
                //#line 464 "x10/lang/MultipleExceptions.x10"
                final long t$134904 = ((idx$134905) + (((long)(1L))));
                
                //#line 464 "x10/lang/MultipleExceptions.x10"
                idx$134905 = t$134904;
            }
            
            //#line 166 . "x10/util/GrowableRail.x10"
            final long t$134683 = ((x10.util.GrowableRail<java.lang.Throwable>)others).size;
            
            //#line 467 "x10/lang/MultipleExceptions.x10"
            final boolean t$134685 = ((t$134683) > (((long)(0L))));
            
            //#line 467 "x10/lang/MultipleExceptions.x10"
            if (t$134685) {
                
                //#line 467 "x10/lang/MultipleExceptions.x10"
                final x10.lang.MultipleExceptions t$134684 = ((x10.lang.MultipleExceptions)(new x10.lang.MultipleExceptions(((x10.util.GrowableRail<java.lang.Throwable>)(others)), (x10.lang.MultipleExceptions.__0$1x10$lang$CheckedThrowable$2) null)));
                
                //#line 467 "x10/lang/MultipleExceptions.x10"
                throw t$134684;
            }
        }finally {{
             
             //#line 469 "x10/lang/MultipleExceptions.x10"
             ((x10.core.fun.VoidFun_0_0)finallyBlock).$apply();
         }}
        }
    
    
    //#line 483 "x10/lang/MultipleExceptions.x10"
    /**
     * try control structure that catches MultipleExceptions and
     * executes the handler on each exception of type E that was in
     * the MultipleExceptions and the nested nested ones. The
     * remaining exceptions are re-thrown in a MultipleExceptions.
     *
     * @param body the body of the try block
     * @param handler the body of the exception handler
     *
     */
    public static <$E>void kwd_try__1$1x10$lang$MultipleExceptions$$E$2(final x10.rtt.Type $E, final x10.core.fun.VoidFun_0_0 body, final x10.core.fun.VoidFun_0_1<$E> handler) {
        
        //#line 431 . "x10/lang/MultipleExceptions.x10"
        try {{
            
            //#line 431 . "x10/lang/MultipleExceptions.x10"
            ((x10.core.fun.VoidFun_0_0)body).$apply();
        }}catch (final x10.lang.MultipleExceptions me$134919) {
            
            //#line 433 . "x10/lang/MultipleExceptions.x10"
            final x10.util.GrowableRail exns$134920 = ((x10.util.GrowableRail)(new x10.util.GrowableRail<$E>((java.lang.System[]) null, $E)));
            
            //#line 50 .. "x10/util/GrowableRail.x10"
            exns$134920.x10$util$GrowableRail$$init$S(((long)(0L)));
            
            //#line 434 . "x10/lang/MultipleExceptions.x10"
            final x10.util.GrowableRail others$134921 = ((x10.util.GrowableRail)(new x10.util.GrowableRail<java.lang.Throwable>((java.lang.System[]) null, x10.rtt.Types.CHECKED_THROWABLE)));
            
            //#line 50 .. "x10/util/GrowableRail.x10"
            others$134921.x10$util$GrowableRail$$init$S(((long)(0L)));
            
            //#line 435 . "x10/lang/MultipleExceptions.x10"
            ((x10.lang.MultipleExceptions)me$134919).<$E> splitExceptionsOfType__1$1x10$lang$MultipleExceptions$$T$2__2$1x10$lang$CheckedThrowable$2($E, (boolean)(true), ((x10.util.GrowableRail)(exns$134920)), ((x10.util.GrowableRail)(others$134921)));
            
            //#line 436 . "x10/lang/MultipleExceptions.x10"
            final x10.core.Rail rail$134917 = ((x10.core.Rail<$E>)
                                                ((x10.util.GrowableRail<$E>)exns$134920).toRail());
            
            //#line 436 . "x10/lang/MultipleExceptions.x10"
            final long size$134918 = ((x10.core.Rail<$E>)rail$134917).size;
            
            //#line 436 . "x10/lang/MultipleExceptions.x10"
            long idx$134914 = 0L;
            
            //#line 436 . "x10/lang/MultipleExceptions.x10"
            for (;
                 true;
                 ) {
                
                //#line 436 . "x10/lang/MultipleExceptions.x10"
                final boolean t$134916 = ((idx$134914) < (((long)(size$134918))));
                
                //#line 436 . "x10/lang/MultipleExceptions.x10"
                if (!(t$134916)) {
                    
                    //#line 436 . "x10/lang/MultipleExceptions.x10"
                    break;
                }
                
                //#line 436 . "x10/lang/MultipleExceptions.x10"
                final $E e$134911 = (($E)(((x10.core.Rail<$E>)rail$134917).$apply$G((long)(idx$134914))));
                
                //#line 437 . "x10/lang/MultipleExceptions.x10"
                ((x10.core.fun.VoidFun_0_1<$E>)handler).$apply(e$134911, $E);
                
                //#line 436 . "x10/lang/MultipleExceptions.x10"
                final long t$134913 = ((idx$134914) + (((long)(1L))));
                
                //#line 436 . "x10/lang/MultipleExceptions.x10"
                idx$134914 = t$134913;
            }
            
            //#line 166 .. "x10/util/GrowableRail.x10"
            final long t$134922 = ((x10.util.GrowableRail<java.lang.Throwable>)others$134921).size;
            
            //#line 439 . "x10/lang/MultipleExceptions.x10"
            final boolean t$134923 = ((t$134922) > (((long)(0L))));
            
            //#line 439 . "x10/lang/MultipleExceptions.x10"
            if (t$134923) {
                
                //#line 439 . "x10/lang/MultipleExceptions.x10"
                final boolean t$134924 = true;
                
                //#line 439 . "x10/lang/MultipleExceptions.x10"
                if (t$134924) {
                    
                    //#line 439 . "x10/lang/MultipleExceptions.x10"
                    final x10.lang.MultipleExceptions t$134925 = ((x10.lang.MultipleExceptions)(new x10.lang.MultipleExceptions(((x10.util.GrowableRail<java.lang.Throwable>)(others$134921)), (x10.lang.MultipleExceptions.__0$1x10$lang$CheckedThrowable$2) null)));
                    
                    //#line 439 . "x10/lang/MultipleExceptions.x10"
                    throw t$134925;
                }
            }
        }
    }
    
    
    //#line 500 "x10/lang/MultipleExceptions.x10"
    /**
     * try control structure with a finally block that catches
     * MultipleExceptions and executes the handler on each exception
     * of type E that was in the MultipleExceptions and the nested
     * nested ones. The remaining exceptions are re-thrown in a
     * MultipleExceptions.
     *
     * @param body the body of the try block
     * @param handler the body of the exception handler
     * @param finallyBlock the body of finally block
     *
     */
    public static <$E>void kwd_try__1$1x10$lang$MultipleExceptions$$E$2(final x10.rtt.Type $E, final x10.core.fun.VoidFun_0_0 body, final x10.core.fun.VoidFun_0_1<$E> handler, final x10.core.fun.VoidFun_0_0 finallyBlock) {
        
        //#line 459 . "x10/lang/MultipleExceptions.x10"
        try {{
            
            //#line 459 . "x10/lang/MultipleExceptions.x10"
            ((x10.core.fun.VoidFun_0_0)body).$apply();
        }}catch (final x10.lang.MultipleExceptions me$134935) {
            
            //#line 461 . "x10/lang/MultipleExceptions.x10"
            final x10.util.GrowableRail exns$134936 = ((x10.util.GrowableRail)(new x10.util.GrowableRail<$E>((java.lang.System[]) null, $E)));
            
            //#line 50 .. "x10/util/GrowableRail.x10"
            exns$134936.x10$util$GrowableRail$$init$S(((long)(0L)));
            
            //#line 462 . "x10/lang/MultipleExceptions.x10"
            final x10.util.GrowableRail others$134937 = ((x10.util.GrowableRail)(new x10.util.GrowableRail<java.lang.Throwable>((java.lang.System[]) null, x10.rtt.Types.CHECKED_THROWABLE)));
            
            //#line 50 .. "x10/util/GrowableRail.x10"
            others$134937.x10$util$GrowableRail$$init$S(((long)(0L)));
            
            //#line 463 . "x10/lang/MultipleExceptions.x10"
            ((x10.lang.MultipleExceptions)me$134935).<$E> splitExceptionsOfType__1$1x10$lang$MultipleExceptions$$T$2__2$1x10$lang$CheckedThrowable$2($E, (boolean)(true), ((x10.util.GrowableRail)(exns$134936)), ((x10.util.GrowableRail)(others$134937)));
            
            //#line 464 . "x10/lang/MultipleExceptions.x10"
            final x10.core.Rail rail$134933 = ((x10.core.Rail<$E>)
                                                ((x10.util.GrowableRail<$E>)exns$134936).toRail());
            
            //#line 464 . "x10/lang/MultipleExceptions.x10"
            final long size$134934 = ((x10.core.Rail<$E>)rail$134933).size;
            
            //#line 464 . "x10/lang/MultipleExceptions.x10"
            long idx$134930 = 0L;
            
            //#line 464 . "x10/lang/MultipleExceptions.x10"
            for (;
                 true;
                 ) {
                
                //#line 464 . "x10/lang/MultipleExceptions.x10"
                final boolean t$134932 = ((idx$134930) < (((long)(size$134934))));
                
                //#line 464 . "x10/lang/MultipleExceptions.x10"
                if (!(t$134932)) {
                    
                    //#line 464 . "x10/lang/MultipleExceptions.x10"
                    break;
                }
                
                //#line 464 . "x10/lang/MultipleExceptions.x10"
                final $E e$134927 = (($E)(((x10.core.Rail<$E>)rail$134933).$apply$G((long)(idx$134930))));
                
                //#line 465 . "x10/lang/MultipleExceptions.x10"
                ((x10.core.fun.VoidFun_0_1<$E>)handler).$apply(e$134927, $E);
                
                //#line 464 . "x10/lang/MultipleExceptions.x10"
                final long t$134929 = ((idx$134930) + (((long)(1L))));
                
                //#line 464 . "x10/lang/MultipleExceptions.x10"
                idx$134930 = t$134929;
            }
            
            //#line 166 .. "x10/util/GrowableRail.x10"
            final long t$134938 = ((x10.util.GrowableRail<java.lang.Throwable>)others$134937).size;
            
            //#line 467 . "x10/lang/MultipleExceptions.x10"
            final boolean t$134939 = ((t$134938) > (((long)(0L))));
            
            //#line 467 . "x10/lang/MultipleExceptions.x10"
            if (t$134939) {
                
                //#line 467 . "x10/lang/MultipleExceptions.x10"
                final boolean t$134940 = true;
                
                //#line 467 . "x10/lang/MultipleExceptions.x10"
                if (t$134940) {
                    
                    //#line 467 . "x10/lang/MultipleExceptions.x10"
                    final x10.lang.MultipleExceptions t$134941 = ((x10.lang.MultipleExceptions)(new x10.lang.MultipleExceptions(((x10.util.GrowableRail<java.lang.Throwable>)(others$134937)), (x10.lang.MultipleExceptions.__0$1x10$lang$CheckedThrowable$2) null)));
                    
                    //#line 467 . "x10/lang/MultipleExceptions.x10"
                    throw t$134941;
                }
            }
        }finally {{
             
             //#line 469 . "x10/lang/MultipleExceptions.x10"
             ((x10.core.fun.VoidFun_0_0)finallyBlock).$apply();
         }}
        }
    
    
    //#line 520 "x10/lang/MultipleExceptions.x10"
    /**
     * try control structure that catches MultipleExceptions and
     * executes the first handler on each exception of type E1 and the
     * second handler on on each exception of type E2 that was in the
     * MultipleExceptions. The remaining exceptions are re-thrown in a
     * MultipleExceptions.
     *
     * @param deep perform a deep traversal of the tree of MultipleExceptions
     * @param body the body of the try block
     * @param handler1 the body of the exception handler
     * @param handler2 the body of the exception handler
     *
     */
    public static <$E1, $E2>void kwd_try__2$1x10$lang$MultipleExceptions$$E1$2__3$1x10$lang$MultipleExceptions$$E2$2(final x10.rtt.Type $E1, final x10.rtt.Type $E2, final boolean deep, final x10.core.fun.VoidFun_0_0 body, final x10.core.fun.VoidFun_0_1<$E1> handler1, final x10.core.fun.VoidFun_0_1<$E2> handler2) {
        
        //#line 524 "x10/lang/MultipleExceptions.x10"
        try {{
            
            //#line 524 "x10/lang/MultipleExceptions.x10"
            ((x10.core.fun.VoidFun_0_0)body).$apply();
        }}catch (final x10.lang.MultipleExceptions me) {
            
            //#line 526 "x10/lang/MultipleExceptions.x10"
            final x10.util.GrowableRail exns1 = ((x10.util.GrowableRail)(new x10.util.GrowableRail<$E1>((java.lang.System[]) null, $E1)));
            
            //#line 50 . "x10/util/GrowableRail.x10"
            exns1.x10$util$GrowableRail$$init$S(((long)(0L)));
            
            //#line 527 "x10/lang/MultipleExceptions.x10"
            final x10.util.GrowableRail others1 = ((x10.util.GrowableRail)(new x10.util.GrowableRail<java.lang.Throwable>((java.lang.System[]) null, x10.rtt.Types.CHECKED_THROWABLE)));
            
            //#line 50 . "x10/util/GrowableRail.x10"
            others1.x10$util$GrowableRail$$init$S(((long)(0L)));
            
            //#line 528 "x10/lang/MultipleExceptions.x10"
            ((x10.lang.MultipleExceptions)me).<$E1> splitExceptionsOfType__1$1x10$lang$MultipleExceptions$$T$2__2$1x10$lang$CheckedThrowable$2($E1, (boolean)(deep), ((x10.util.GrowableRail)(exns1)), ((x10.util.GrowableRail)(others1)));
            
            //#line 529 "x10/lang/MultipleExceptions.x10"
            final x10.core.Rail rail$134956 = ((x10.core.Rail<$E1>)
                                                ((x10.util.GrowableRail<$E1>)exns1).toRail());
            
            //#line 529 "x10/lang/MultipleExceptions.x10"
            final long size$134957 = ((x10.core.Rail<$E1>)rail$134956).size;
            
            //#line 529 "x10/lang/MultipleExceptions.x10"
            long idx$134946 = 0L;
            
            //#line 529 "x10/lang/MultipleExceptions.x10"
            for (;
                 true;
                 ) {
                
                //#line 529 "x10/lang/MultipleExceptions.x10"
                final boolean t$134948 = ((idx$134946) < (((long)(size$134957))));
                
                //#line 529 "x10/lang/MultipleExceptions.x10"
                if (!(t$134948)) {
                    
                    //#line 529 "x10/lang/MultipleExceptions.x10"
                    break;
                }
                
                //#line 529 "x10/lang/MultipleExceptions.x10"
                final $E1 e$134943 = (($E1)(((x10.core.Rail<$E1>)rail$134956).$apply$G((long)(idx$134946))));
                
                //#line 530 "x10/lang/MultipleExceptions.x10"
                ((x10.core.fun.VoidFun_0_1<$E1>)handler1).$apply(e$134943, $E1);
                
                //#line 529 "x10/lang/MultipleExceptions.x10"
                final long t$134945 = ((idx$134946) + (((long)(1L))));
                
                //#line 529 "x10/lang/MultipleExceptions.x10"
                idx$134946 = t$134945;
            }
            
            //#line 532 "x10/lang/MultipleExceptions.x10"
            final x10.util.GrowableRail exns2 = ((x10.util.GrowableRail)(new x10.util.GrowableRail<$E2>((java.lang.System[]) null, $E2)));
            
            //#line 50 . "x10/util/GrowableRail.x10"
            exns2.x10$util$GrowableRail$$init$S(((long)(0L)));
            
            //#line 533 "x10/lang/MultipleExceptions.x10"
            final x10.util.GrowableRail others2 = ((x10.util.GrowableRail)(new x10.util.GrowableRail<java.lang.Throwable>((java.lang.System[]) null, x10.rtt.Types.CHECKED_THROWABLE)));
            
            //#line 50 . "x10/util/GrowableRail.x10"
            others2.x10$util$GrowableRail$$init$S(((long)(0L)));
            
            //#line 534 "x10/lang/MultipleExceptions.x10"
            final x10.lang.MultipleExceptions t$134712 = ((x10.lang.MultipleExceptions)(new x10.lang.MultipleExceptions(((x10.util.GrowableRail<java.lang.Throwable>)(others1)), (x10.lang.MultipleExceptions.__0$1x10$lang$CheckedThrowable$2) null)));
            
            //#line 534 "x10/lang/MultipleExceptions.x10"
            ((x10.lang.MultipleExceptions)t$134712).<$E2> splitExceptionsOfType__1$1x10$lang$MultipleExceptions$$T$2__2$1x10$lang$CheckedThrowable$2($E2, (boolean)(deep), ((x10.util.GrowableRail)(exns2)), ((x10.util.GrowableRail)(others2)));
            
            //#line 535 "x10/lang/MultipleExceptions.x10"
            final x10.core.Rail rail$134958 = ((x10.core.Rail<$E2>)
                                                ((x10.util.GrowableRail<$E2>)exns2).toRail());
            
            //#line 535 "x10/lang/MultipleExceptions.x10"
            final long size$134959 = ((x10.core.Rail<$E2>)rail$134958).size;
            
            //#line 535 "x10/lang/MultipleExceptions.x10"
            long idx$134953 = 0L;
            
            //#line 535 "x10/lang/MultipleExceptions.x10"
            for (;
                 true;
                 ) {
                
                //#line 535 "x10/lang/MultipleExceptions.x10"
                final boolean t$134955 = ((idx$134953) < (((long)(size$134959))));
                
                //#line 535 "x10/lang/MultipleExceptions.x10"
                if (!(t$134955)) {
                    
                    //#line 535 "x10/lang/MultipleExceptions.x10"
                    break;
                }
                
                //#line 535 "x10/lang/MultipleExceptions.x10"
                final $E2 e$134950 = (($E2)(((x10.core.Rail<$E2>)rail$134958).$apply$G((long)(idx$134953))));
                
                //#line 536 "x10/lang/MultipleExceptions.x10"
                ((x10.core.fun.VoidFun_0_1<$E2>)handler2).$apply(e$134950, $E2);
                
                //#line 535 "x10/lang/MultipleExceptions.x10"
                final long t$134952 = ((idx$134953) + (((long)(1L))));
                
                //#line 535 "x10/lang/MultipleExceptions.x10"
                idx$134953 = t$134952;
            }
            
            //#line 166 . "x10/util/GrowableRail.x10"
            final long t$134719 = ((x10.util.GrowableRail<java.lang.Throwable>)others2).size;
            
            //#line 538 "x10/lang/MultipleExceptions.x10"
            final boolean t$134721 = ((t$134719) > (((long)(0L))));
            
            //#line 538 "x10/lang/MultipleExceptions.x10"
            if (t$134721) {
                
                //#line 538 "x10/lang/MultipleExceptions.x10"
                final x10.lang.MultipleExceptions t$134720 = ((x10.lang.MultipleExceptions)(new x10.lang.MultipleExceptions(((x10.util.GrowableRail<java.lang.Throwable>)(others2)), (x10.lang.MultipleExceptions.__0$1x10$lang$CheckedThrowable$2) null)));
                
                //#line 538 "x10/lang/MultipleExceptions.x10"
                throw t$134720;
            }
        }
    }
    
    
    //#line 556 "x10/lang/MultipleExceptions.x10"
    /**
     * try control structure with a finally block that catches
     * MultipleExceptions and executes the first handler on each
     * exception of type E1 and the second handler on each exception
     * of type E2 that was in the MultipleExceptions. The remaining
     * exceptions are re-thrown in a MultipleExceptions.
     *
     * @param deep perform a deep traversal of the tree of MultipleExceptions
     * @param body the body of the try block
     * @param handler1 the body of the exception handler
     * @param handler2 the body of the exception handler
     *
     */
    public static <$E1, $E2>void kwd_try__2$1x10$lang$MultipleExceptions$$E1$2__3$1x10$lang$MultipleExceptions$$E2$2(final x10.rtt.Type $E1, final x10.rtt.Type $E2, final boolean deep, final x10.core.fun.VoidFun_0_0 body, final x10.core.fun.VoidFun_0_1<$E1> handler1, final x10.core.fun.VoidFun_0_1<$E2> handler2, final x10.core.fun.VoidFun_0_0 finallyBlock) {
        
        //#line 561 "x10/lang/MultipleExceptions.x10"
        try {{
            
            //#line 561 "x10/lang/MultipleExceptions.x10"
            ((x10.core.fun.VoidFun_0_0)body).$apply();
        }}catch (final x10.lang.MultipleExceptions me) {
            
            //#line 563 "x10/lang/MultipleExceptions.x10"
            final x10.util.GrowableRail exns1 = ((x10.util.GrowableRail)(new x10.util.GrowableRail<$E1>((java.lang.System[]) null, $E1)));
            
            //#line 50 . "x10/util/GrowableRail.x10"
            exns1.x10$util$GrowableRail$$init$S(((long)(0L)));
            
            //#line 564 "x10/lang/MultipleExceptions.x10"
            final x10.util.GrowableRail others1 = ((x10.util.GrowableRail)(new x10.util.GrowableRail<java.lang.Throwable>((java.lang.System[]) null, x10.rtt.Types.CHECKED_THROWABLE)));
            
            //#line 50 . "x10/util/GrowableRail.x10"
            others1.x10$util$GrowableRail$$init$S(((long)(0L)));
            
            //#line 565 "x10/lang/MultipleExceptions.x10"
            ((x10.lang.MultipleExceptions)me).<$E1> splitExceptionsOfType__1$1x10$lang$MultipleExceptions$$T$2__2$1x10$lang$CheckedThrowable$2($E1, (boolean)(deep), ((x10.util.GrowableRail)(exns1)), ((x10.util.GrowableRail)(others1)));
            
            //#line 566 "x10/lang/MultipleExceptions.x10"
            final x10.core.Rail rail$134974 = ((x10.core.Rail<$E1>)
                                                ((x10.util.GrowableRail<$E1>)exns1).toRail());
            
            //#line 566 "x10/lang/MultipleExceptions.x10"
            final long size$134975 = ((x10.core.Rail<$E1>)rail$134974).size;
            
            //#line 566 "x10/lang/MultipleExceptions.x10"
            long idx$134964 = 0L;
            
            //#line 566 "x10/lang/MultipleExceptions.x10"
            for (;
                 true;
                 ) {
                
                //#line 566 "x10/lang/MultipleExceptions.x10"
                final boolean t$134966 = ((idx$134964) < (((long)(size$134975))));
                
                //#line 566 "x10/lang/MultipleExceptions.x10"
                if (!(t$134966)) {
                    
                    //#line 566 "x10/lang/MultipleExceptions.x10"
                    break;
                }
                
                //#line 566 "x10/lang/MultipleExceptions.x10"
                final $E1 e$134961 = (($E1)(((x10.core.Rail<$E1>)rail$134974).$apply$G((long)(idx$134964))));
                
                //#line 567 "x10/lang/MultipleExceptions.x10"
                ((x10.core.fun.VoidFun_0_1<$E1>)handler1).$apply(e$134961, $E1);
                
                //#line 566 "x10/lang/MultipleExceptions.x10"
                final long t$134963 = ((idx$134964) + (((long)(1L))));
                
                //#line 566 "x10/lang/MultipleExceptions.x10"
                idx$134964 = t$134963;
            }
            
            //#line 569 "x10/lang/MultipleExceptions.x10"
            final x10.util.GrowableRail exns2 = ((x10.util.GrowableRail)(new x10.util.GrowableRail<$E2>((java.lang.System[]) null, $E2)));
            
            //#line 50 . "x10/util/GrowableRail.x10"
            exns2.x10$util$GrowableRail$$init$S(((long)(0L)));
            
            //#line 570 "x10/lang/MultipleExceptions.x10"
            final x10.util.GrowableRail others2 = ((x10.util.GrowableRail)(new x10.util.GrowableRail<java.lang.Throwable>((java.lang.System[]) null, x10.rtt.Types.CHECKED_THROWABLE)));
            
            //#line 50 . "x10/util/GrowableRail.x10"
            others2.x10$util$GrowableRail$$init$S(((long)(0L)));
            
            //#line 571 "x10/lang/MultipleExceptions.x10"
            final x10.lang.MultipleExceptions t$134728 = ((x10.lang.MultipleExceptions)(new x10.lang.MultipleExceptions(((x10.util.GrowableRail<java.lang.Throwable>)(others1)), (x10.lang.MultipleExceptions.__0$1x10$lang$CheckedThrowable$2) null)));
            
            //#line 571 "x10/lang/MultipleExceptions.x10"
            ((x10.lang.MultipleExceptions)t$134728).<$E2> splitExceptionsOfType__1$1x10$lang$MultipleExceptions$$T$2__2$1x10$lang$CheckedThrowable$2($E2, (boolean)(deep), ((x10.util.GrowableRail)(exns2)), ((x10.util.GrowableRail)(others2)));
            
            //#line 572 "x10/lang/MultipleExceptions.x10"
            final x10.core.Rail rail$134976 = ((x10.core.Rail<$E2>)
                                                ((x10.util.GrowableRail<$E2>)exns2).toRail());
            
            //#line 572 "x10/lang/MultipleExceptions.x10"
            final long size$134977 = ((x10.core.Rail<$E2>)rail$134976).size;
            
            //#line 572 "x10/lang/MultipleExceptions.x10"
            long idx$134971 = 0L;
            
            //#line 572 "x10/lang/MultipleExceptions.x10"
            for (;
                 true;
                 ) {
                
                //#line 572 "x10/lang/MultipleExceptions.x10"
                final boolean t$134973 = ((idx$134971) < (((long)(size$134977))));
                
                //#line 572 "x10/lang/MultipleExceptions.x10"
                if (!(t$134973)) {
                    
                    //#line 572 "x10/lang/MultipleExceptions.x10"
                    break;
                }
                
                //#line 572 "x10/lang/MultipleExceptions.x10"
                final $E2 e$134968 = (($E2)(((x10.core.Rail<$E2>)rail$134976).$apply$G((long)(idx$134971))));
                
                //#line 573 "x10/lang/MultipleExceptions.x10"
                ((x10.core.fun.VoidFun_0_1<$E2>)handler2).$apply(e$134968, $E2);
                
                //#line 572 "x10/lang/MultipleExceptions.x10"
                final long t$134970 = ((idx$134971) + (((long)(1L))));
                
                //#line 572 "x10/lang/MultipleExceptions.x10"
                idx$134971 = t$134970;
            }
            
            //#line 166 . "x10/util/GrowableRail.x10"
            final long t$134735 = ((x10.util.GrowableRail<java.lang.Throwable>)others2).size;
            
            //#line 575 "x10/lang/MultipleExceptions.x10"
            final boolean t$134737 = ((t$134735) > (((long)(0L))));
            
            //#line 575 "x10/lang/MultipleExceptions.x10"
            if (t$134737) {
                
                //#line 575 "x10/lang/MultipleExceptions.x10"
                final x10.lang.MultipleExceptions t$134736 = ((x10.lang.MultipleExceptions)(new x10.lang.MultipleExceptions(((x10.util.GrowableRail<java.lang.Throwable>)(others2)), (x10.lang.MultipleExceptions.__0$1x10$lang$CheckedThrowable$2) null)));
                
                //#line 575 "x10/lang/MultipleExceptions.x10"
                throw t$134736;
            }
        }finally {{
             
             //#line 576 "x10/lang/MultipleExceptions.x10"
             ((x10.core.fun.VoidFun_0_0)finallyBlock).$apply();
         }}
        }
    
    
    //#line 591 "x10/lang/MultipleExceptions.x10"
    /**
     * try control structure that catches MultipleExceptions and
     * executes the first handler on each exception of type E1 and the
     * second handler on each exception of type E2 that was in the
     * MultipleExceptions and the nested nested ones. The remaining
     * exceptions are re-thrown in a MultipleExceptions.
     *
     * @param body the body of the try block
     * @param handler1 the body of the exception handler
     * @param handler2 the body of the exception handler
     *
     */
    public static <$E1, $E2>void kwd_try__1$1x10$lang$MultipleExceptions$$E1$2__2$1x10$lang$MultipleExceptions$$E2$2(final x10.rtt.Type $E1, final x10.rtt.Type $E2, final x10.core.fun.VoidFun_0_0 body, final x10.core.fun.VoidFun_0_1<$E1> handler1, final x10.core.fun.VoidFun_0_1<$E2> handler2) {
        
        //#line 524 . "x10/lang/MultipleExceptions.x10"
        try {{
            
            //#line 524 . "x10/lang/MultipleExceptions.x10"
            ((x10.core.fun.VoidFun_0_0)body).$apply();
        }}catch (final x10.lang.MultipleExceptions me$134996) {
            
            //#line 526 . "x10/lang/MultipleExceptions.x10"
            final x10.util.GrowableRail exns$134997 = ((x10.util.GrowableRail)(new x10.util.GrowableRail<$E1>((java.lang.System[]) null, $E1)));
            
            //#line 50 .. "x10/util/GrowableRail.x10"
            exns$134997.x10$util$GrowableRail$$init$S(((long)(0L)));
            
            //#line 527 . "x10/lang/MultipleExceptions.x10"
            final x10.util.GrowableRail others$134998 = ((x10.util.GrowableRail)(new x10.util.GrowableRail<java.lang.Throwable>((java.lang.System[]) null, x10.rtt.Types.CHECKED_THROWABLE)));
            
            //#line 50 .. "x10/util/GrowableRail.x10"
            others$134998.x10$util$GrowableRail$$init$S(((long)(0L)));
            
            //#line 528 . "x10/lang/MultipleExceptions.x10"
            ((x10.lang.MultipleExceptions)me$134996).<$E1> splitExceptionsOfType__1$1x10$lang$MultipleExceptions$$T$2__2$1x10$lang$CheckedThrowable$2($E1, (boolean)(true), ((x10.util.GrowableRail)(exns$134997)), ((x10.util.GrowableRail)(others$134998)));
            
            //#line 529 . "x10/lang/MultipleExceptions.x10"
            final x10.core.Rail rail$134992 = ((x10.core.Rail<$E1>)
                                                ((x10.util.GrowableRail<$E1>)exns$134997).toRail());
            
            //#line 529 . "x10/lang/MultipleExceptions.x10"
            final long size$134993 = ((x10.core.Rail<$E1>)rail$134992).size;
            
            //#line 529 . "x10/lang/MultipleExceptions.x10"
            long idx$134982 = 0L;
            
            //#line 529 . "x10/lang/MultipleExceptions.x10"
            for (;
                 true;
                 ) {
                
                //#line 529 . "x10/lang/MultipleExceptions.x10"
                final boolean t$134984 = ((idx$134982) < (((long)(size$134993))));
                
                //#line 529 . "x10/lang/MultipleExceptions.x10"
                if (!(t$134984)) {
                    
                    //#line 529 . "x10/lang/MultipleExceptions.x10"
                    break;
                }
                
                //#line 529 . "x10/lang/MultipleExceptions.x10"
                final $E1 e$134979 = (($E1)(((x10.core.Rail<$E1>)rail$134992).$apply$G((long)(idx$134982))));
                
                //#line 530 . "x10/lang/MultipleExceptions.x10"
                ((x10.core.fun.VoidFun_0_1<$E1>)handler1).$apply(e$134979, $E1);
                
                //#line 529 . "x10/lang/MultipleExceptions.x10"
                final long t$134981 = ((idx$134982) + (((long)(1L))));
                
                //#line 529 . "x10/lang/MultipleExceptions.x10"
                idx$134982 = t$134981;
            }
            
            //#line 532 . "x10/lang/MultipleExceptions.x10"
            final x10.util.GrowableRail exns$134999 = ((x10.util.GrowableRail)(new x10.util.GrowableRail<$E2>((java.lang.System[]) null, $E2)));
            
            //#line 50 .. "x10/util/GrowableRail.x10"
            exns$134999.x10$util$GrowableRail$$init$S(((long)(0L)));
            
            //#line 533 . "x10/lang/MultipleExceptions.x10"
            final x10.util.GrowableRail others$135000 = ((x10.util.GrowableRail)(new x10.util.GrowableRail<java.lang.Throwable>((java.lang.System[]) null, x10.rtt.Types.CHECKED_THROWABLE)));
            
            //#line 50 .. "x10/util/GrowableRail.x10"
            others$135000.x10$util$GrowableRail$$init$S(((long)(0L)));
            
            //#line 534 . "x10/lang/MultipleExceptions.x10"
            final x10.lang.MultipleExceptions t$135001 = ((x10.lang.MultipleExceptions)(new x10.lang.MultipleExceptions(((x10.util.GrowableRail<java.lang.Throwable>)(others$134998)), (x10.lang.MultipleExceptions.__0$1x10$lang$CheckedThrowable$2) null)));
            
            //#line 534 . "x10/lang/MultipleExceptions.x10"
            ((x10.lang.MultipleExceptions)t$135001).<$E2> splitExceptionsOfType__1$1x10$lang$MultipleExceptions$$T$2__2$1x10$lang$CheckedThrowable$2($E2, (boolean)(true), ((x10.util.GrowableRail)(exns$134999)), ((x10.util.GrowableRail)(others$135000)));
            
            //#line 535 . "x10/lang/MultipleExceptions.x10"
            final x10.core.Rail rail$134994 = ((x10.core.Rail<$E2>)
                                                ((x10.util.GrowableRail<$E2>)exns$134999).toRail());
            
            //#line 535 . "x10/lang/MultipleExceptions.x10"
            final long size$134995 = ((x10.core.Rail<$E2>)rail$134994).size;
            
            //#line 535 . "x10/lang/MultipleExceptions.x10"
            long idx$134989 = 0L;
            
            //#line 535 . "x10/lang/MultipleExceptions.x10"
            for (;
                 true;
                 ) {
                
                //#line 535 . "x10/lang/MultipleExceptions.x10"
                final boolean t$134991 = ((idx$134989) < (((long)(size$134995))));
                
                //#line 535 . "x10/lang/MultipleExceptions.x10"
                if (!(t$134991)) {
                    
                    //#line 535 . "x10/lang/MultipleExceptions.x10"
                    break;
                }
                
                //#line 535 . "x10/lang/MultipleExceptions.x10"
                final $E2 e$134986 = (($E2)(((x10.core.Rail<$E2>)rail$134994).$apply$G((long)(idx$134989))));
                
                //#line 536 . "x10/lang/MultipleExceptions.x10"
                ((x10.core.fun.VoidFun_0_1<$E2>)handler2).$apply(e$134986, $E2);
                
                //#line 535 . "x10/lang/MultipleExceptions.x10"
                final long t$134988 = ((idx$134989) + (((long)(1L))));
                
                //#line 535 . "x10/lang/MultipleExceptions.x10"
                idx$134989 = t$134988;
            }
            
            //#line 166 .. "x10/util/GrowableRail.x10"
            final long t$135002 = ((x10.util.GrowableRail<java.lang.Throwable>)others$135000).size;
            
            //#line 538 . "x10/lang/MultipleExceptions.x10"
            final boolean t$135003 = ((t$135002) > (((long)(0L))));
            
            //#line 538 . "x10/lang/MultipleExceptions.x10"
            if (t$135003) {
                
                //#line 538 . "x10/lang/MultipleExceptions.x10"
                final boolean t$135004 = true;
                
                //#line 538 . "x10/lang/MultipleExceptions.x10"
                if (t$135004) {
                    
                    //#line 538 . "x10/lang/MultipleExceptions.x10"
                    final x10.lang.MultipleExceptions t$135005 = ((x10.lang.MultipleExceptions)(new x10.lang.MultipleExceptions(((x10.util.GrowableRail<java.lang.Throwable>)(others$135000)), (x10.lang.MultipleExceptions.__0$1x10$lang$CheckedThrowable$2) null)));
                    
                    //#line 538 . "x10/lang/MultipleExceptions.x10"
                    throw t$135005;
                }
            }
        }
    }
    
    
    //#line 610 "x10/lang/MultipleExceptions.x10"
    /**
     * try control structure with a finally block that catches
     * MultipleExceptions and executes the first handler on each
     * exception of type E1 and the second handler on each exception
     * of type E2 that was in the MultipleExceptions and the nested
     * nested ones. The remaining exceptions are re-thrown in a
     * MultipleExceptions.
     *
     * @param body the body of the try block
     * @param handler1 the body of the exception handler
     * @param handler2 the body of the exception handler
     *
     */
    public static <$E1, $E2>void kwd_try__1$1x10$lang$MultipleExceptions$$E1$2__2$1x10$lang$MultipleExceptions$$E2$2(final x10.rtt.Type $E1, final x10.rtt.Type $E2, final x10.core.fun.VoidFun_0_0 body, final x10.core.fun.VoidFun_0_1<$E1> handler1, final x10.core.fun.VoidFun_0_1<$E2> handler2, final x10.core.fun.VoidFun_0_0 finallyBlock) {
        
        //#line 561 . "x10/lang/MultipleExceptions.x10"
        try {{
            
            //#line 561 . "x10/lang/MultipleExceptions.x10"
            ((x10.core.fun.VoidFun_0_0)body).$apply();
        }}catch (final x10.lang.MultipleExceptions me$135024) {
            
            //#line 563 . "x10/lang/MultipleExceptions.x10"
            final x10.util.GrowableRail exns$135025 = ((x10.util.GrowableRail)(new x10.util.GrowableRail<$E1>((java.lang.System[]) null, $E1)));
            
            //#line 50 .. "x10/util/GrowableRail.x10"
            exns$135025.x10$util$GrowableRail$$init$S(((long)(0L)));
            
            //#line 564 . "x10/lang/MultipleExceptions.x10"
            final x10.util.GrowableRail others$135026 = ((x10.util.GrowableRail)(new x10.util.GrowableRail<java.lang.Throwable>((java.lang.System[]) null, x10.rtt.Types.CHECKED_THROWABLE)));
            
            //#line 50 .. "x10/util/GrowableRail.x10"
            others$135026.x10$util$GrowableRail$$init$S(((long)(0L)));
            
            //#line 565 . "x10/lang/MultipleExceptions.x10"
            ((x10.lang.MultipleExceptions)me$135024).<$E1> splitExceptionsOfType__1$1x10$lang$MultipleExceptions$$T$2__2$1x10$lang$CheckedThrowable$2($E1, (boolean)(true), ((x10.util.GrowableRail)(exns$135025)), ((x10.util.GrowableRail)(others$135026)));
            
            //#line 566 . "x10/lang/MultipleExceptions.x10"
            final x10.core.Rail rail$135020 = ((x10.core.Rail<$E1>)
                                                ((x10.util.GrowableRail<$E1>)exns$135025).toRail());
            
            //#line 566 . "x10/lang/MultipleExceptions.x10"
            final long size$135021 = ((x10.core.Rail<$E1>)rail$135020).size;
            
            //#line 566 . "x10/lang/MultipleExceptions.x10"
            long idx$135010 = 0L;
            
            //#line 566 . "x10/lang/MultipleExceptions.x10"
            for (;
                 true;
                 ) {
                
                //#line 566 . "x10/lang/MultipleExceptions.x10"
                final boolean t$135012 = ((idx$135010) < (((long)(size$135021))));
                
                //#line 566 . "x10/lang/MultipleExceptions.x10"
                if (!(t$135012)) {
                    
                    //#line 566 . "x10/lang/MultipleExceptions.x10"
                    break;
                }
                
                //#line 566 . "x10/lang/MultipleExceptions.x10"
                final $E1 e$135007 = (($E1)(((x10.core.Rail<$E1>)rail$135020).$apply$G((long)(idx$135010))));
                
                //#line 567 . "x10/lang/MultipleExceptions.x10"
                ((x10.core.fun.VoidFun_0_1<$E1>)handler1).$apply(e$135007, $E1);
                
                //#line 566 . "x10/lang/MultipleExceptions.x10"
                final long t$135009 = ((idx$135010) + (((long)(1L))));
                
                //#line 566 . "x10/lang/MultipleExceptions.x10"
                idx$135010 = t$135009;
            }
            
            //#line 569 . "x10/lang/MultipleExceptions.x10"
            final x10.util.GrowableRail exns$135027 = ((x10.util.GrowableRail)(new x10.util.GrowableRail<$E2>((java.lang.System[]) null, $E2)));
            
            //#line 50 .. "x10/util/GrowableRail.x10"
            exns$135027.x10$util$GrowableRail$$init$S(((long)(0L)));
            
            //#line 570 . "x10/lang/MultipleExceptions.x10"
            final x10.util.GrowableRail others$135028 = ((x10.util.GrowableRail)(new x10.util.GrowableRail<java.lang.Throwable>((java.lang.System[]) null, x10.rtt.Types.CHECKED_THROWABLE)));
            
            //#line 50 .. "x10/util/GrowableRail.x10"
            others$135028.x10$util$GrowableRail$$init$S(((long)(0L)));
            
            //#line 571 . "x10/lang/MultipleExceptions.x10"
            final x10.lang.MultipleExceptions t$135029 = ((x10.lang.MultipleExceptions)(new x10.lang.MultipleExceptions(((x10.util.GrowableRail<java.lang.Throwable>)(others$135026)), (x10.lang.MultipleExceptions.__0$1x10$lang$CheckedThrowable$2) null)));
            
            //#line 571 . "x10/lang/MultipleExceptions.x10"
            ((x10.lang.MultipleExceptions)t$135029).<$E2> splitExceptionsOfType__1$1x10$lang$MultipleExceptions$$T$2__2$1x10$lang$CheckedThrowable$2($E2, (boolean)(true), ((x10.util.GrowableRail)(exns$135027)), ((x10.util.GrowableRail)(others$135028)));
            
            //#line 572 . "x10/lang/MultipleExceptions.x10"
            final x10.core.Rail rail$135022 = ((x10.core.Rail<$E2>)
                                                ((x10.util.GrowableRail<$E2>)exns$135027).toRail());
            
            //#line 572 . "x10/lang/MultipleExceptions.x10"
            final long size$135023 = ((x10.core.Rail<$E2>)rail$135022).size;
            
            //#line 572 . "x10/lang/MultipleExceptions.x10"
            long idx$135017 = 0L;
            
            //#line 572 . "x10/lang/MultipleExceptions.x10"
            for (;
                 true;
                 ) {
                
                //#line 572 . "x10/lang/MultipleExceptions.x10"
                final boolean t$135019 = ((idx$135017) < (((long)(size$135023))));
                
                //#line 572 . "x10/lang/MultipleExceptions.x10"
                if (!(t$135019)) {
                    
                    //#line 572 . "x10/lang/MultipleExceptions.x10"
                    break;
                }
                
                //#line 572 . "x10/lang/MultipleExceptions.x10"
                final $E2 e$135014 = (($E2)(((x10.core.Rail<$E2>)rail$135022).$apply$G((long)(idx$135017))));
                
                //#line 573 . "x10/lang/MultipleExceptions.x10"
                ((x10.core.fun.VoidFun_0_1<$E2>)handler2).$apply(e$135014, $E2);
                
                //#line 572 . "x10/lang/MultipleExceptions.x10"
                final long t$135016 = ((idx$135017) + (((long)(1L))));
                
                //#line 572 . "x10/lang/MultipleExceptions.x10"
                idx$135017 = t$135016;
            }
            
            //#line 166 .. "x10/util/GrowableRail.x10"
            final long t$135030 = ((x10.util.GrowableRail<java.lang.Throwable>)others$135028).size;
            
            //#line 575 . "x10/lang/MultipleExceptions.x10"
            final boolean t$135031 = ((t$135030) > (((long)(0L))));
            
            //#line 575 . "x10/lang/MultipleExceptions.x10"
            if (t$135031) {
                
                //#line 575 . "x10/lang/MultipleExceptions.x10"
                final boolean t$135032 = true;
                
                //#line 575 . "x10/lang/MultipleExceptions.x10"
                if (t$135032) {
                    
                    //#line 575 . "x10/lang/MultipleExceptions.x10"
                    final x10.lang.MultipleExceptions t$135033 = ((x10.lang.MultipleExceptions)(new x10.lang.MultipleExceptions(((x10.util.GrowableRail<java.lang.Throwable>)(others$135028)), (x10.lang.MultipleExceptions.__0$1x10$lang$CheckedThrowable$2) null)));
                    
                    //#line 575 . "x10/lang/MultipleExceptions.x10"
                    throw t$135033;
                }
            }
        }finally {{
             
             //#line 576 . "x10/lang/MultipleExceptions.x10"
             ((x10.core.fun.VoidFun_0_0)finallyBlock).$apply();
         }}
        }
    
    
    //#line 23 "x10/lang/MultipleExceptions.x10"
    final public x10.lang.MultipleExceptions x10$lang$MultipleExceptions$$this$x10$lang$MultipleExceptions() {
        
        //#line 23 "x10/lang/MultipleExceptions.x10"
        return x10.lang.MultipleExceptions.this;
    }
    
    
    //#line 23 "x10/lang/MultipleExceptions.x10"
    final public void __fieldInitializers_x10_lang_MultipleExceptions() {
        
    }
    }
    
    