package x10.lang;


/**
 * Float is a 32-bit single-precision IEEE 754 floating point data type.
 * Unlike Java, X10 does not restrict the precision of floating
 * point values, so they may be represented by an extended-exponent
 * variant at runtime.  All of the normal
 * arithmetic and bitwise operations are defined on Float, and Float
 * is closed under those operations.  There are also static methods
 * that define conversions from other data types, including String,
 * as well as some Float constants.
 */
;


