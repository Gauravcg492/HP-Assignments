package x10.lang;


/**
 * Int is a 32-bit signed two's complement integral data type, with
 * values ranging from -2147483648 to 2147483647, inclusive.  All of the normal
 * arithmetic and bitwise operations are defined on Int, and Int
 * is closed under those operations.  There are also static methods
 * that define conversions from other data types, including String,
 * as well as some Int constants.
 */
;


