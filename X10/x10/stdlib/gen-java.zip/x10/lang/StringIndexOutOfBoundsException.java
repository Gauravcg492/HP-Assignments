package x10.lang;


/**
 * Thrown to indicate that a string has been accessed with an illegal index.
 * For example, the point is outside of the string's region.
 */
;

