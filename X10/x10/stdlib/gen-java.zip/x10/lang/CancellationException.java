package x10.lang;

/**
 * Thrown to indicate that all activties running in 
 * a Place have been cancelled. 
 *
 * @see x10.xrx.Runtime.cancelAll
 * @see x10.xrx.Runtime.terminateAll
 */
@x10.runtime.impl.java.X10Generated
public class CancellationException extends x10.lang.DeadPlaceException implements x10.serialization.X10JavaSerializable
{
    public static final x10.rtt.RuntimeType<CancellationException> $RTT = 
        x10.rtt.NamedType.<CancellationException> make("x10.lang.CancellationException",
                                                       CancellationException.class,
                                                       new x10.rtt.Type[] {
                                                           x10.lang.DeadPlaceException.$RTT
                                                       });
    
    public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
    
    public x10.rtt.Type<?> $getParam(int i) { return null; }
    
    private Object writeReplace() throws java.io.ObjectStreamException {
        return new x10.serialization.SerializationProxy(this);
    }
    
    public static x10.serialization.X10JavaSerializable $_deserialize_body(x10.lang.CancellationException $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
        x10.lang.DeadPlaceException.$_deserialize_body($_obj, $deserializer);
        return $_obj;
    }
    
    public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
        x10.lang.CancellationException $_obj = new x10.lang.CancellationException((java.lang.System[]) null);
        $deserializer.record_reference($_obj);
        return $_deserialize_body($_obj, $deserializer);
    }
    
    public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
        super.$_serialize($serializer);
        
    }
    
    // constructor just for allocation
    public CancellationException(final java.lang.System[] $dummy) {
        super($dummy);
        
    }
    
    

    
    
    //#line 26 "x10/lang/CancellationException.x10"
    /**
     * Construct a CancellationException with the default detail message.
     */
    public CancellationException() {
        super((("Cancelled at ") + (x10.x10rt.X10RT.here())));
         {
            
            //#line 26 "x10/lang/CancellationException.x10"
            
            
            //#line 21 "x10/lang/CancellationException.x10"
            this.__fieldInitializers_x10_lang_CancellationException();
        }
    }
    
    
    
    //#line 35 "x10/lang/CancellationException.x10"
    /**
     * Construct a CancellationException with the specified detail message.
     *
     * @param message the detail message
     */
    public CancellationException(final java.lang.String message) {
        super(((java.lang.String)(message)));
         {
            
            //#line 35 "x10/lang/CancellationException.x10"
            
            
            //#line 21 "x10/lang/CancellationException.x10"
            this.__fieldInitializers_x10_lang_CancellationException();
        }
    }
    
    
    
    //#line 21 "x10/lang/CancellationException.x10"
    final public x10.lang.CancellationException x10$lang$CancellationException$$this$x10$lang$CancellationException() {
        
        //#line 21 "x10/lang/CancellationException.x10"
        return x10.lang.CancellationException.this;
    }
    
    
    //#line 21 "x10/lang/CancellationException.x10"
    final public void __fieldInitializers_x10_lang_CancellationException() {
        
    }
}

