package x10.lang;


/**
 * Byte is an 8-bit signed two's complement integral data type, with
 * values ranging from -128 to 127, inclusive.  All of the normal
 * arithmetic and bitwise operations are defined on Byte, and Byte
 * is closed under those operations.  There are also static methods
 * that define conversions from other data types, including String,
 * as well as some Byte constants.
 */
;


