package x10.lang;


/**
 * A representation of the range of longs [min..max].
 */
@x10.runtime.impl.java.X10Generated
public class LongRange extends x10.core.Struct implements x10.lang.Iterable, x10.serialization.X10JavaSerializable
{
    public static final x10.rtt.RuntimeType<LongRange> $RTT = 
        x10.rtt.NamedStructType.<LongRange> make("x10.lang.LongRange",
                                                 LongRange.class,
                                                 new x10.rtt.Type[] {
                                                     x10.rtt.ParameterizedType.make(x10.lang.Iterable.$RTT, x10.rtt.Types.LONG),
                                                     x10.rtt.Types.STRUCT
                                                 });
    
    public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
    
    public x10.rtt.Type<?> $getParam(int i) { return null; }
    
    private Object writeReplace() throws java.io.ObjectStreamException {
        return new x10.serialization.SerializationProxy(this);
    }
    
    public static x10.serialization.X10JavaSerializable $_deserialize_body(x10.lang.LongRange $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
        $_obj.max = $deserializer.readLong();
        $_obj.min = $deserializer.readLong();
        return $_obj;
    }
    
    public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
        x10.lang.LongRange $_obj = new x10.lang.LongRange((java.lang.System[]) null);
        return $_deserialize_body($_obj, $deserializer);
    }
    
    public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
        $serializer.write(this.max);
        $serializer.write(this.min);
        
    }
    
    // zero value constructor
    public LongRange(final java.lang.System $dummy) { this.min = 0L; this.max = 0L; }
    
    // constructor just for allocation
    public LongRange(final java.lang.System[] $dummy) {
        
    }
    
    
    // properties
    
    //#line 23 "x10/lang/LongRange.x10"
    /**
                * The minimum value included in the range
                */
    public long min;
    
    //#line 28 "x10/lang/LongRange.x10"
    /**
                * The maximum value included in the range
                */
    public long max;
    

    
    
    //#line 36 "x10/lang/LongRange.x10"
    /**
     * Construct a LongRange from min..max
     * @param min the minimum value of the range
     * @param max the maximum value of the range
     */
    // creation method for java code (1-phase java constructor)
    public LongRange(final long min, final long max) {
        this((java.lang.System[]) null);
        x10$lang$LongRange$$init$S(min, max);
    }
    
    // constructor for non-virtual call
    final public x10.lang.LongRange x10$lang$LongRange$$init$S(final long min, final long max) {
         {
            
            //#line 37 "x10/lang/LongRange.x10"
            this.min = min;
            this.max = max;
            
        }
        return this;
    }
    
    
    
    //#line 45 "x10/lang/LongRange.x10"
    /**
     * Coerce a given IntRange to a LongRange.
     * @param x the given IntRange
     * @return the given IntRange converted to a LongRange.
     */
    final public static x10.lang.LongRange $implicit_convert(final x10.lang.IntRange x) {
        
        //#line 45 "x10/lang/LongRange.x10"
        final x10.lang.LongRange alloc$133936 = ((x10.lang.LongRange)(new x10.lang.LongRange((java.lang.System[]) null)));
        
        //#line 45 "x10/lang/LongRange.x10"
        final int t$133956 = x.min;
        
        //#line 45 "x10/lang/LongRange.x10"
        final long min$133942 = ((long)(((int)(t$133956))));
        
        //#line 45 "x10/lang/LongRange.x10"
        final int t$133957 = x.max;
        
        //#line 45 "x10/lang/LongRange.x10"
        final long max$133943 = ((long)(((int)(t$133957))));
        
        //#line 37 . "x10/lang/LongRange.x10"
        alloc$133936.min = min$133942;
        
        //#line 37 . "x10/lang/LongRange.x10"
        alloc$133936.max = max$133943;
        
        //#line 45 "x10/lang/LongRange.x10"
        return alloc$133936;
    }
    
    
    //#line 52 "x10/lang/LongRange.x10"
    /**
     * Split the LongRange into N LongRanges that
     * collectively represent the same set of Longs as this.
     * @see x10.array.BlockUtils.partitionBlock
     */
    final public x10.core.Rail split(final long n) {
        
        //#line 53 "x10/lang/LongRange.x10"
        final long t$133958 = this.max;
        
        //#line 53 "x10/lang/LongRange.x10"
        final long t$133959 = this.min;
        
        //#line 53 "x10/lang/LongRange.x10"
        final long t$133960 = ((t$133958) - (((long)(t$133959))));
        
        //#line 53 "x10/lang/LongRange.x10"
        final long numElems = ((t$133960) + (((long)(1L))));
        
        //#line 54 "x10/lang/LongRange.x10"
        final long blockSize = ((numElems) / (((long)(n))));
        
        //#line 55 "x10/lang/LongRange.x10"
        final long t$133961 = ((n) * (((long)(blockSize))));
        
        //#line 55 "x10/lang/LongRange.x10"
        final long leftOver = ((numElems) - (((long)(t$133961))));
        
        //#line 56 "x10/lang/LongRange.x10"
        final x10.core.fun.Fun_0_1 t$133972 = ((x10.core.fun.Fun_0_1)(new x10.lang.LongRange.$Closure$166(this, this.min, blockSize, leftOver)));
        
        //#line 56 "x10/lang/LongRange.x10"
        final x10.core.Rail t$133973 = ((x10.core.Rail)(new x10.core.Rail<x10.lang.LongRange>(x10.lang.LongRange.$RTT, ((long)(n)), ((x10.core.fun.Fun_0_1)(t$133972)), (x10.core.Rail.__1$1x10$lang$Long$3x10$lang$Rail$$T$2) null)));
        
        //#line 56 "x10/lang/LongRange.x10"
        return t$133973;
    }
    
    
    //#line 67 "x10/lang/LongRange.x10"
    /**
     * Define the product of two LongRanges to be a rank-2 IterationSpace
     * containing all the points defined by the cartesian product of the ranges.
     */
    final public x10.array.DenseIterationSpace_2 $times(final x10.lang.LongRange that) {
        
        //#line 68 "x10/lang/LongRange.x10"
        final x10.array.DenseIterationSpace_2 alloc$133938 = ((x10.array.DenseIterationSpace_2)(new x10.array.DenseIterationSpace_2((java.lang.System[]) null)));
        
        //#line 68 "x10/lang/LongRange.x10"
        final long t$134014 = this.min;
        
        //#line 68 "x10/lang/LongRange.x10"
        final long t$134015 = that.min;
        
        //#line 68 "x10/lang/LongRange.x10"
        final long t$134016 = this.max;
        
        //#line 68 "x10/lang/LongRange.x10"
        final long t$134017 = that.max;
        
        //#line 68 "x10/lang/LongRange.x10"
        alloc$133938.x10$array$DenseIterationSpace_2$$init$S(((long)(t$134014)), ((long)(t$134015)), ((long)(t$134016)), ((long)(t$134017)));
        
        //#line 68 "x10/lang/LongRange.x10"
        return alloc$133938;
    }
    
    
    //#line 71 "x10/lang/LongRange.x10"
    final public java.lang.String toString() {
        
        //#line 71 "x10/lang/LongRange.x10"
        final long t$133978 = this.min;
        
        //#line 71 "x10/lang/LongRange.x10"
        final java.lang.String t$133979 = (((x10.core.Long.$box(t$133978))) + (".."));
        
        //#line 71 "x10/lang/LongRange.x10"
        final long t$133980 = this.max;
        
        //#line 71 "x10/lang/LongRange.x10"
        final java.lang.String t$133981 = ((t$133979) + ((x10.core.Long.$box(t$133980))));
        
        //#line 71 "x10/lang/LongRange.x10"
        return t$133981;
    }
    
    
    //#line 73 "x10/lang/LongRange.x10"
    final public boolean equals(final java.lang.Object that) {
        
        //#line 74 "x10/lang/LongRange.x10"
        final boolean t$133988 = x10.lang.LongRange.$RTT.isInstance(that);
        
        //#line 74 "x10/lang/LongRange.x10"
        if (t$133988) {
            
            //#line 75 "x10/lang/LongRange.x10"
            final x10.lang.LongRange other = ((x10.lang.LongRange)(((x10.lang.LongRange)x10.rtt.Types.asStruct(x10.lang.LongRange.$RTT,that))));
            
            //#line 76 "x10/lang/LongRange.x10"
            final long t$133982 = this.min;
            
            //#line 76 "x10/lang/LongRange.x10"
            final long t$133983 = other.min;
            
            //#line 76 "x10/lang/LongRange.x10"
            boolean t$133986 = ((long) t$133982) == ((long) t$133983);
            
            //#line 76 "x10/lang/LongRange.x10"
            if (t$133986) {
                
                //#line 76 "x10/lang/LongRange.x10"
                final long t$133984 = this.max;
                
                //#line 76 "x10/lang/LongRange.x10"
                final long t$133985 = other.max;
                
                //#line 76 "x10/lang/LongRange.x10"
                t$133986 = ((long) t$133984) == ((long) t$133985);
            }
            
            //#line 76 "x10/lang/LongRange.x10"
            return t$133986;
        }
        
        //#line 78 "x10/lang/LongRange.x10"
        return false;
    }
    
    
    //#line 81 "x10/lang/LongRange.x10"
    final public int hashCode() {
        
        //#line 81 "x10/lang/LongRange.x10"
        final long t$133989 = this.max;
        
        //#line 81 "x10/lang/LongRange.x10"
        final long t$133990 = this.min;
        
        //#line 81 "x10/lang/LongRange.x10"
        final long t$133991 = ((t$133989) - (((long)(t$133990))));
        
        //#line 81 "x10/lang/LongRange.x10"
        final int t$133992 = x10.rtt.Types.hashCode(t$133991);
        
        //#line 81 "x10/lang/LongRange.x10"
        return t$133992;
    }
    
    
    //#line 83 "x10/lang/LongRange.x10"
    final public x10.lang.Iterator iterator() {
        
        //#line 84 "x10/lang/LongRange.x10"
        final x10.lang.LongRange.LongRangeIt alloc$133939 = ((x10.lang.LongRange.LongRangeIt)(new x10.lang.LongRange.LongRangeIt((java.lang.System[]) null)));
        
        //#line 84 "x10/lang/LongRange.x10"
        final long min$133950 = this.min;
        
        //#line 84 "x10/lang/LongRange.x10"
        final long max$133951 = this.max;
        
        //#line 87 .. "x10/lang/LongRange.x10"
        alloc$133939.cur = 0L;
        
        //#line 91 . "x10/lang/LongRange.x10"
        alloc$133939.cur = min$133950;
        
        //#line 92 . "x10/lang/LongRange.x10"
        alloc$133939.max = max$133951;
        
        //#line 84 "x10/lang/LongRange.x10"
        return alloc$133939;
    }
    
    
    //#line 87 "x10/lang/LongRange.x10"
    @x10.runtime.impl.java.X10Generated
    public static class LongRangeIt extends x10.core.Ref implements x10.lang.Iterator, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<LongRangeIt> $RTT = 
            x10.rtt.NamedType.<LongRangeIt> make("x10.lang.LongRange.LongRangeIt",
                                                 LongRangeIt.class,
                                                 new x10.rtt.Type[] {
                                                     x10.rtt.ParameterizedType.make(x10.lang.Iterator.$RTT, x10.rtt.Types.LONG)
                                                 });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static x10.serialization.X10JavaSerializable $_deserialize_body(x10.lang.LongRange.LongRangeIt $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            $_obj.cur = $deserializer.readLong();
            $_obj.max = $deserializer.readLong();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.lang.LongRange.LongRangeIt $_obj = new x10.lang.LongRange.LongRangeIt((java.lang.System[]) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            $serializer.write(this.cur);
            $serializer.write(this.max);
            
        }
        
        // constructor just for allocation
        public LongRangeIt(final java.lang.System[] $dummy) {
            
        }
        
        // bridge for method abstract public x10.lang.Iterator[T].next(){}:T
        public x10.core.Long next$G() {
            return x10.core.Long.$box(next$O());
        }
        
        
    
        
        //#line 88 "x10/lang/LongRange.x10"
        public long cur;
        
        //#line 89 "x10/lang/LongRange.x10"
        public long max;
        
        
        //#line 90 "x10/lang/LongRange.x10"
        // creation method for java code (1-phase java constructor)
        public LongRangeIt(final long min, final long max) {
            this((java.lang.System[]) null);
            x10$lang$LongRange$LongRangeIt$$init$S(min, max);
        }
        
        // constructor for non-virtual call
        final public x10.lang.LongRange.LongRangeIt x10$lang$LongRange$LongRangeIt$$init$S(final long min, final long max) {
             {
                
                //#line 90 "x10/lang/LongRange.x10"
                
                
                //#line 87 "x10/lang/LongRange.x10"
                final x10.lang.LongRange.LongRangeIt this$134018 = this;
                
                //#line 87 "x10/lang/LongRange.x10"
                this$134018.cur = 0L;
                
                //#line 91 "x10/lang/LongRange.x10"
                this.cur = min;
                
                //#line 92 "x10/lang/LongRange.x10"
                this.max = max;
            }
            return this;
        }
        
        
        
        //#line 94 "x10/lang/LongRange.x10"
        public boolean hasNext$O() {
            
            //#line 94 "x10/lang/LongRange.x10"
            final long t$133993 = this.cur;
            
            //#line 94 "x10/lang/LongRange.x10"
            final long t$133994 = this.max;
            
            //#line 94 "x10/lang/LongRange.x10"
            final boolean t$133995 = ((t$133993) <= (((long)(t$133994))));
            
            //#line 94 "x10/lang/LongRange.x10"
            return t$133995;
        }
        
        
        //#line 95 "x10/lang/LongRange.x10"
        public long next$O() {
            
            //#line 95 "x10/lang/LongRange.x10"
            final long t$133996 = this.cur;
            
            //#line 95 "x10/lang/LongRange.x10"
            final long t$133997 = ((t$133996) + (((long)(1L))));
            
            //#line 95 "x10/lang/LongRange.x10"
            final long t$133998 = this.cur = t$133997;
            
            //#line 95 "x10/lang/LongRange.x10"
            final long t$133999 = ((t$133998) - (((long)(1L))));
            
            //#line 95 "x10/lang/LongRange.x10"
            return t$133999;
        }
        
        
        //#line 87 "x10/lang/LongRange.x10"
        final public x10.lang.LongRange.LongRangeIt x10$lang$LongRange$LongRangeIt$$this$x10$lang$LongRange$LongRangeIt() {
            
            //#line 87 "x10/lang/LongRange.x10"
            return x10.lang.LongRange.LongRangeIt.this;
        }
        
        
        //#line 87 "x10/lang/LongRange.x10"
        final public void __fieldInitializers_x10_lang_LongRange_LongRangeIt() {
            
            //#line 87 "x10/lang/LongRange.x10"
            this.cur = 0L;
        }
    }
    
    
    
    //#line 29 "x10/lang/LongRange.x10"
    final public java.lang.String typeName() {
        try {
            return x10.rtt.Types.typeName(this);
        }
        catch (java.lang.Throwable exc$206369) {
            throw x10.runtime.impl.java.ThrowableUtils.ensureX10Exception(exc$206369);
        }
        
    }
    
    
    
    //#line 29 "x10/lang/LongRange.x10"
    final public boolean _struct_equals$O(java.lang.Object other) {
        
        //#line 29 "x10/lang/LongRange.x10"
        final boolean t$134001 = x10.lang.LongRange.$RTT.isInstance(other);
        
        //#line 29 "x10/lang/LongRange.x10"
        final boolean t$134002 = !(t$134001);
        
        //#line 29 "x10/lang/LongRange.x10"
        if (t$134002) {
            
            //#line 29 "x10/lang/LongRange.x10"
            return false;
        }
        
        //#line 29 "x10/lang/LongRange.x10"
        final x10.lang.LongRange t$134004 = ((x10.lang.LongRange)x10.rtt.Types.asStruct(x10.lang.LongRange.$RTT,other));
        
        //#line 29 "x10/lang/LongRange.x10"
        final boolean t$134005 = this._struct_equals$O(((x10.lang.LongRange)(t$134004)));
        
        //#line 29 "x10/lang/LongRange.x10"
        return t$134005;
    }
    
    
    //#line 29 "x10/lang/LongRange.x10"
    final public boolean _struct_equals$O(x10.lang.LongRange other) {
        
        //#line 29 "x10/lang/LongRange.x10"
        final long t$134007 = this.min;
        
        //#line 29 "x10/lang/LongRange.x10"
        final long t$134008 = other.min;
        
        //#line 29 "x10/lang/LongRange.x10"
        boolean t$134012 = ((long) t$134007) == ((long) t$134008);
        
        //#line 29 "x10/lang/LongRange.x10"
        if (t$134012) {
            
            //#line 29 "x10/lang/LongRange.x10"
            final long t$134010 = this.max;
            
            //#line 29 "x10/lang/LongRange.x10"
            final long t$134011 = other.max;
            
            //#line 29 "x10/lang/LongRange.x10"
            t$134012 = ((long) t$134010) == ((long) t$134011);
        }
        
        //#line 29 "x10/lang/LongRange.x10"
        return t$134012;
    }
    
    
    //#line 19 "x10/lang/LongRange.x10"
    final public x10.lang.LongRange x10$lang$LongRange$$this$x10$lang$LongRange() {
        
        //#line 19 "x10/lang/LongRange.x10"
        return x10.lang.LongRange.this;
    }
    
    
    //#line 19 "x10/lang/LongRange.x10"
    final public void __fieldInitializers_x10_lang_LongRange() {
        
    }
    
    @x10.runtime.impl.java.X10Generated
    final public static class $Closure$166 extends x10.core.Ref implements x10.core.fun.Fun_0_1, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<$Closure$166> $RTT = 
            x10.rtt.StaticFunType.<$Closure$166> make($Closure$166.class,
                                                      new x10.rtt.Type[] {
                                                          x10.rtt.ParameterizedType.make(x10.core.fun.Fun_0_1.$RTT, x10.rtt.Types.LONG, x10.lang.LongRange.$RTT)
                                                      });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static x10.serialization.X10JavaSerializable $_deserialize_body(x10.lang.LongRange.$Closure$166 $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            $_obj.blockSize = $deserializer.readLong();
            $_obj.leftOver = $deserializer.readLong();
            $_obj.min = $deserializer.readLong();
            $_obj.out$$ = $deserializer.readObject();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.lang.LongRange.$Closure$166 $_obj = new x10.lang.LongRange.$Closure$166((java.lang.System[]) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            $serializer.write(this.blockSize);
            $serializer.write(this.leftOver);
            $serializer.write(this.min);
            $serializer.write(this.out$$);
            
        }
        
        // constructor just for allocation
        public $Closure$166(final java.lang.System[] $dummy) {
            
        }
        
        // dispatcher for method abstract public (Z1)=>U.operator()(a1:Z1):U
        public java.lang.Object $apply(final java.lang.Object a1, final x10.rtt.Type t1) {
            return $apply(x10.core.Long.$unbox(a1));
            
        }
        
        
    
        
        public x10.lang.LongRange $apply(final long i) {
            
            //#line 57 "x10/lang/LongRange.x10"
            final long t$133962 = this.min;
            
            //#line 57 "x10/lang/LongRange.x10"
            final long t$133963 = ((this.blockSize) * (((long)(i))));
            
            //#line 57 "x10/lang/LongRange.x10"
            final long t$133966 = ((t$133962) + (((long)(t$133963))));
            
            //#line 57 "x10/lang/LongRange.x10"
            final boolean t$133964 = ((i) < (((long)(this.leftOver))));
            
            //#line 57 "x10/lang/LongRange.x10"
            long t$133965 =  0;
            
            //#line 57 "x10/lang/LongRange.x10"
            if (t$133964) {
                
                //#line 57 "x10/lang/LongRange.x10"
                t$133965 = i;
            } else {
                
                //#line 57 "x10/lang/LongRange.x10"
                t$133965 = this.leftOver;
            }
            
            //#line 57 "x10/lang/LongRange.x10"
            final long low = ((t$133966) + (((long)(t$133965))));
            
            //#line 58 "x10/lang/LongRange.x10"
            final long t$133970 = ((low) + (((long)(this.blockSize))));
            
            //#line 58 "x10/lang/LongRange.x10"
            final boolean t$133968 = ((i) < (((long)(this.leftOver))));
            
            //#line 58 "x10/lang/LongRange.x10"
            long t$133969 =  0;
            
            //#line 58 "x10/lang/LongRange.x10"
            if (t$133968) {
                
                //#line 58 "x10/lang/LongRange.x10"
                t$133969 = 0L;
            } else {
                
                //#line 58 "x10/lang/LongRange.x10"
                t$133969 = -1L;
            }
            
            //#line 58 "x10/lang/LongRange.x10"
            final long hi = ((t$133970) + (((long)(t$133969))));
            
            //#line 59 "x10/lang/LongRange.x10"
            final x10.lang.LongRange alloc$133937 = ((x10.lang.LongRange)(new x10.lang.LongRange((java.lang.System[]) null)));
            
            //#line 37 . "x10/lang/LongRange.x10"
            alloc$133937.min = low;
            
            //#line 37 . "x10/lang/LongRange.x10"
            alloc$133937.max = hi;
            
            //#line 59 "x10/lang/LongRange.x10"
            return alloc$133937;
        }
        
        public x10.lang.LongRange out$$;
        public long min;
        public long blockSize;
        public long leftOver;
        
        public $Closure$166(final x10.lang.LongRange out$$, final long min, final long blockSize, final long leftOver) {
             {
                this.out$$ = out$$;
                this.min = min;
                this.blockSize = blockSize;
                this.leftOver = leftOver;
            }
        }
        
    }
    
}

