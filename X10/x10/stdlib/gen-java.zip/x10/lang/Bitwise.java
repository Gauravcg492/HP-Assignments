package x10.lang;


/**
 * A set of common bitwise operations.
 */
@x10.runtime.impl.java.X10Generated
public interface Bitwise<$T> extends x10.core.Any
{
    public static final x10.rtt.RuntimeType<Bitwise> $RTT = 
        x10.rtt.NamedType.<Bitwise> make("x10.lang.Bitwise",
                                         Bitwise.class,
                                         1);
    
    

    
    
    //#line 27 "x10/lang/Bitwise.x10"
    /**
     * A bitwise complement operator.
     * Computes a bitwise complement (NOT) of the operand.
     * @return the bitwise complement of the current entity.
     */
    $T $tilde$G();
    
    
    //#line 36 "x10/lang/Bitwise.x10"
    /**
     * A bitwise and operator.
     * Computes a bitwise AND of the two operands.
     * @param that the other entity
     * @return the bitwise AND of the current entity and the other entity.
     */
    java.lang.Object $ampersand(final java.lang.Object that, x10.rtt.Type t1);
    
    
    //#line 45 "x10/lang/Bitwise.x10"
    /**
     * A bitwise or operator.
     * Computes a bitwise OR of the two operands.
     * @param that the other entity
     * @return the bitwise OR of the current entity and the other entity.
     */
    java.lang.Object $bar(final java.lang.Object that, x10.rtt.Type t1);
    
    
    //#line 54 "x10/lang/Bitwise.x10"
    /**
     * A bitwise xor operator.
     * Computes a bitwise XOR of the two operands.
     * @param that the other entity
     * @return the bitwise XOR of the current entity and the other entity.
     */
    java.lang.Object $caret(final java.lang.Object that, x10.rtt.Type t1);
    
    
    //#line 65 "x10/lang/Bitwise.x10"
    /**
     * A bitwise left shift operator.
     * Computes the value of the left-hand operand shifted left by the value of the right-hand operand.
     * The shift count will be masked based on the size of the receiver so that only the bottom
     * k bits will be considered.
     * @param count the shift count
     * @return the current entity shifted left by count.
     */
    $T $left$G(final long count);
    
    
    //#line 76 "x10/lang/Bitwise.x10"
    /**
     * A bitwise right shift operator.
     * Computes the value of the left-hand operand shifted right by the value of the right-hand operand.
     * The shift count will be masked based on the size of the receiver so that only the bottom
     * k bits will be considered.
     * @param count the shift count
     * @return the current entity shifted right by count.
     */
    $T $right$G(final long count);
    
    
    //#line 89 "x10/lang/Bitwise.x10"
    /**
     * A bitwise logical right shift operator (zero-fill).
     * Computes the value of the left-hand operand shifted right by the value of the right-hand operand,
     * filling the high bits with zeros.
     * The shift count will be masked based on the size of the receiver so that only the bottom
     * k bits will be considered.
     * @deprecated use the right-shift operator and unsigned conversions instead.
     * @param count the shift count
     * @return the current entity shifted right by count with high bits zero-filled.
     */
    $T $unsigned_right$G(final long count);
}

