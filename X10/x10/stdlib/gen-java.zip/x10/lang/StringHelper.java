package x10.lang;

@x10.runtime.impl.java.X10Generated
public class StringHelper extends x10.core.Ref implements x10.serialization.X10JavaSerializable
{
    public static final x10.rtt.RuntimeType<StringHelper> $RTT = 
        x10.rtt.NamedType.<StringHelper> make("x10.lang.StringHelper",
                                              StringHelper.class);
    
    public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
    
    public x10.rtt.Type<?> $getParam(int i) { return null; }
    
    private Object writeReplace() throws java.io.ObjectStreamException {
        return new x10.serialization.SerializationProxy(this);
    }
    
    public static x10.serialization.X10JavaSerializable $_deserialize_body(x10.lang.StringHelper $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
        return $_obj;
    }
    
    public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
        x10.lang.StringHelper $_obj = new x10.lang.StringHelper((java.lang.System[]) null);
        $deserializer.record_reference($_obj);
        return $_deserialize_body($_obj, $deserializer);
    }
    
    public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
        
    }
    
    // constructor just for allocation
    public StringHelper(final java.lang.System[] $dummy) {
        
    }
    
    

    
    
    //#line 579 "x10/lang/String.x10"
    public static x10.core.Rail split(final java.lang.String delim, final java.lang.String str) {
        
        //#line 580 "x10/lang/String.x10"
        final boolean t$136544 = (delim).equals("");
        
        //#line 580 "x10/lang/String.x10"
        if (t$136544) {
            
            //#line 581 "x10/lang/String.x10"
            final int t$136536 = (str).length();
            
            //#line 581 "x10/lang/String.x10"
            final long t$136541 = ((long)(((int)(t$136536))));
            
            //#line 581 "x10/lang/String.x10"
            final x10.core.fun.Fun_0_1 t$136542 = ((x10.core.fun.Fun_0_1)(new x10.lang.StringHelper.$Closure$200(str)));
            
            //#line 581 "x10/lang/String.x10"
            final x10.core.Rail t$136543 = ((x10.core.Rail)(new x10.core.Rail<java.lang.String>(x10.rtt.Types.STRING, t$136541, ((x10.core.fun.Fun_0_1)(t$136542)), (x10.core.Rail.__1$1x10$lang$Long$3x10$lang$Rail$$T$2) null)));
            
            //#line 581 "x10/lang/String.x10"
            return t$136543;
        }
        
        //#line 583 "x10/lang/String.x10"
        final x10.util.GrowableRail ans = ((x10.util.GrowableRail)(new x10.util.GrowableRail<java.lang.String>((java.lang.System[]) null, x10.rtt.Types.STRING)));
        
        //#line 50 . "x10/util/GrowableRail.x10"
        ans.x10$util$GrowableRail$$init$S(((long)(0L)));
        
        //#line 584 "x10/lang/String.x10"
        int pos = 0;
        
        //#line 585 "x10/lang/String.x10"
        int nextMatch = (str).indexOf(delim, ((int)(pos)));
        
        //#line 586 "x10/lang/String.x10"
        while (true) {
            
            //#line 586 "x10/lang/String.x10"
            final boolean t$136555 = ((int) nextMatch) != ((int) -1);
            
            //#line 586 "x10/lang/String.x10"
            if (!(t$136555)) {
                
                //#line 586 "x10/lang/String.x10"
                break;
            }
            
            //#line 587 "x10/lang/String.x10"
            final java.lang.String t$136565 = (str).substring(((int)(pos)), ((int)(nextMatch)));
            
            //#line 587 "x10/lang/String.x10"
            ((x10.util.GrowableRail<java.lang.String>)ans).add__0x10$util$GrowableRail$$T(((java.lang.String)(t$136565)));
            
            //#line 588 "x10/lang/String.x10"
            final int t$136567 = (delim).length();
            
            //#line 588 "x10/lang/String.x10"
            final int t$136568 = ((nextMatch) + (((int)(t$136567))));
            
            //#line 588 "x10/lang/String.x10"
            pos = t$136568;
            
            //#line 589 "x10/lang/String.x10"
            final int t$136570 = (str).indexOf(delim, ((int)(pos)));
            
            //#line 589 "x10/lang/String.x10"
            nextMatch = t$136570;
        }
        
        //#line 591 "x10/lang/String.x10"
        final int t$136557 = (str).length();
        
        //#line 591 "x10/lang/String.x10"
        final boolean t$136561 = ((pos) < (((int)(t$136557))));
        
        //#line 591 "x10/lang/String.x10"
        if (t$136561) {
            
            //#line 592 "x10/lang/String.x10"
            final int t$136559 = (str).length();
            
            //#line 592 "x10/lang/String.x10"
            final java.lang.String t$136560 = (str).substring(((int)(pos)), ((int)(t$136559)));
            
            //#line 592 "x10/lang/String.x10"
            ((x10.util.GrowableRail<java.lang.String>)ans).add__0x10$util$GrowableRail$$T(((java.lang.String)(t$136560)));
        }
        
        //#line 594 "x10/lang/String.x10"
        final x10.core.Rail t$136562 = ((x10.core.Rail<java.lang.String>)
                                         ((x10.util.GrowableRail<java.lang.String>)ans).toRail());
        
        //#line 594 "x10/lang/String.x10"
        return t$136562;
    }
    
    
    //#line 578 "x10/lang/String.x10"
    final public x10.lang.StringHelper x10$lang$StringHelper$$this$x10$lang$StringHelper() {
        
        //#line 578 "x10/lang/String.x10"
        return x10.lang.StringHelper.this;
    }
    
    
    //#line 578 "x10/lang/String.x10"
    // creation method for java code (1-phase java constructor)
    public StringHelper() {
        this((java.lang.System[]) null);
        x10$lang$StringHelper$$init$S();
    }
    
    // constructor for non-virtual call
    final public x10.lang.StringHelper x10$lang$StringHelper$$init$S() {
         {
            
            //#line 578 "x10/lang/String.x10"
            
        }
        return this;
    }
    
    
    
    //#line 578 "x10/lang/String.x10"
    final public void __fieldInitializers_x10_lang_StringHelper() {
        
    }
    
    @x10.runtime.impl.java.X10Generated
    final public static class $Closure$200 extends x10.core.Ref implements x10.core.fun.Fun_0_1, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<$Closure$200> $RTT = 
            x10.rtt.StaticFunType.<$Closure$200> make($Closure$200.class,
                                                      new x10.rtt.Type[] {
                                                          x10.rtt.ParameterizedType.make(x10.core.fun.Fun_0_1.$RTT, x10.rtt.Types.LONG, x10.rtt.Types.STRING)
                                                      });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static x10.serialization.X10JavaSerializable $_deserialize_body(x10.lang.StringHelper.$Closure$200 $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            $_obj.str = $deserializer.readObject();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.lang.StringHelper.$Closure$200 $_obj = new x10.lang.StringHelper.$Closure$200((java.lang.System[]) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            $serializer.write(this.str);
            
        }
        
        // constructor just for allocation
        public $Closure$200(final java.lang.System[] $dummy) {
            
        }
        
        // dispatcher for method abstract public (Z1)=>U.operator()(a1:Z1):U
        public java.lang.Object $apply(final java.lang.Object a1, final x10.rtt.Type t1) {
            return $apply(x10.core.Long.$unbox(a1));
            
        }
        
        
    
        
        public java.lang.String $apply(final long i) {
            
            //#line 581 "x10/lang/String.x10"
            final int t$136538 = ((int)(long)(((long)(i))));
            
            //#line 581 "x10/lang/String.x10"
            final long t$136537 = ((i) + (((long)(1L))));
            
            //#line 581 "x10/lang/String.x10"
            final int t$136539 = ((int)(long)(((long)(t$136537))));
            
            //#line 581 "x10/lang/String.x10"
            final java.lang.String t$136540 = (this.str).substring(((int)(t$136538)), ((int)(t$136539)));
            
            //#line 581 "x10/lang/String.x10"
            return t$136540;
        }
        
        public java.lang.String str;
        
        public $Closure$200(final java.lang.String str) {
             {
                this.str = ((java.lang.String)(str));
            }
        }
        
    }
    
}

