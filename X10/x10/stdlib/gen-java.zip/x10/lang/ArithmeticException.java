package x10.lang;


/**
 * Thrown when an exceptional arithmetic condition has occurred.
 * For example, an integer "divide by zero" throws an instance of this class.
 */
;

