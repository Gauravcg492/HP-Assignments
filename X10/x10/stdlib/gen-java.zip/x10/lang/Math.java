package x10.lang;


@x10.runtime.impl.java.X10Generated
final public class Math extends x10.core.Ref implements x10.serialization.X10JavaSerializable
{
    public static final x10.rtt.RuntimeType<Math> $RTT = 
        x10.rtt.NamedType.<Math> make("x10.lang.Math",
                                      Math.class);
    
    public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
    
    public x10.rtt.Type<?> $getParam(int i) { return null; }
    
    private Object writeReplace() throws java.io.ObjectStreamException {
        return new x10.serialization.SerializationProxy(this);
    }
    
    public static x10.serialization.X10JavaSerializable $_deserialize_body(x10.lang.Math $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
        return $_obj;
    }
    
    public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
        x10.lang.Math $_obj = new x10.lang.Math((java.lang.System[]) null);
        $deserializer.record_reference($_obj);
        return $_deserialize_body($_obj, $deserializer);
    }
    
    public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
        
    }
    
    // constructor just for allocation
    public Math(final java.lang.System[] $dummy) {
        
    }
    
    

    
    //#line 20 "x10/lang/Math.x10"
    final public static double E = 2.718281828459045;
    
    //#line 21 "x10/lang/Math.x10"
    final public static double PI = 3.141592653589793;
    
    
    //#line 23 "x10/lang/Math.x10"
    public static int abs$O(final int a) {
        try {
            return java.lang.Math.abs(a);
        }
        catch (java.lang.Throwable exc$206370) {
            throw x10.runtime.impl.java.ThrowableUtils.ensureX10Exception(exc$206370);
        }
        
    }
    
    
    
    //#line 27 "x10/lang/Math.x10"
    public static long abs$O(final long a) {
        try {
            return java.lang.Math.abs(a);
        }
        catch (java.lang.Throwable exc$206371) {
            throw x10.runtime.impl.java.ThrowableUtils.ensureX10Exception(exc$206371);
        }
        
    }
    
    
    
    //#line 31 "x10/lang/Math.x10"
    public static float abs$O(final float a) {
        try {
            return java.lang.Math.abs(a);
        }
        catch (java.lang.Throwable exc$206372) {
            throw x10.runtime.impl.java.ThrowableUtils.ensureX10Exception(exc$206372);
        }
        
    }
    
    
    
    //#line 36 "x10/lang/Math.x10"
    public static double abs$O(final double a) {
        try {
            return java.lang.Math.abs(a);
        }
        catch (java.lang.Throwable exc$206373) {
            throw x10.runtime.impl.java.ThrowableUtils.ensureX10Exception(exc$206373);
        }
        
    }
    
    
    
    //#line 41 "x10/lang/Math.x10"
    public static double ceil$O(final double a) {
        try {
            return java.lang.Math.ceil(a);
        }
        catch (java.lang.Throwable exc$206374) {
            throw x10.runtime.impl.java.ThrowableUtils.ensureX10Exception(exc$206374);
        }
        
    }
    
    
    
    //#line 46 "x10/lang/Math.x10"
    public static double floor$O(final double a) {
        try {
            return java.lang.Math.floor(a);
        }
        catch (java.lang.Throwable exc$206375) {
            throw x10.runtime.impl.java.ThrowableUtils.ensureX10Exception(exc$206375);
        }
        
    }
    
    
    
    //#line 51 "x10/lang/Math.x10"
    public static double rint$O(final double a) {
        try {
            return java.lang.Math.rint(a);
        }
        catch (java.lang.Throwable exc$206376) {
            throw x10.runtime.impl.java.ThrowableUtils.ensureX10Exception(exc$206376);
        }
        
    }
    
    
    
    //#line 56 "x10/lang/Math.x10"
    public static double round$O(final double a) {
        try {
            return (double)java.lang.Math.round(a);
        }
        catch (java.lang.Throwable exc$206377) {
            throw x10.runtime.impl.java.ThrowableUtils.ensureX10Exception(exc$206377);
        }
        
    }
    
    
    
    //#line 61 "x10/lang/Math.x10"
    public static float round$O(final float a) {
        try {
            return (float)java.lang.Math.round(a);
        }
        catch (java.lang.Throwable exc$206378) {
            throw x10.runtime.impl.java.ThrowableUtils.ensureX10Exception(exc$206378);
        }
        
    }
    
    
    
    //#line 66 "x10/lang/Math.x10"
    public static int getExponent$O(final float a) {
        try {
            return java.lang.Math.getExponent(a);
        }
        catch (java.lang.Throwable exc$206379) {
            throw x10.runtime.impl.java.ThrowableUtils.ensureX10Exception(exc$206379);
        }
        
    }
    
    
    
    //#line 71 "x10/lang/Math.x10"
    public static int getExponent$O(final double a) {
        try {
            return java.lang.Math.getExponent(a);
        }
        catch (java.lang.Throwable exc$206380) {
            throw x10.runtime.impl.java.ThrowableUtils.ensureX10Exception(exc$206380);
        }
        
    }
    
    
    
    //#line 76 "x10/lang/Math.x10"
    public static double scalb$O(final double a, final int b) {
        try {
            return java.lang.Math.scalb(a,b);
        }
        catch (java.lang.Throwable exc$206381) {
            throw x10.runtime.impl.java.ThrowableUtils.ensureX10Exception(exc$206381);
        }
        
    }
    
    
    
    //#line 81 "x10/lang/Math.x10"
    public static float scalb$O(final float a, final int b) {
        try {
            return java.lang.Math.scalb(a,b);
        }
        catch (java.lang.Throwable exc$206382) {
            throw x10.runtime.impl.java.ThrowableUtils.ensureX10Exception(exc$206382);
        }
        
    }
    
    
    
    //#line 86 "x10/lang/Math.x10"
    public static double pow$O(final double a, final double b) {
        try {
            return java.lang.Math.pow(a,b);
        }
        catch (java.lang.Throwable exc$206383) {
            throw x10.runtime.impl.java.ThrowableUtils.ensureX10Exception(exc$206383);
        }
        
    }
    
    
    
    //#line 91 "x10/lang/Math.x10"
    public static float pow$O(final float a, final float b) {
        try {
            return (float)java.lang.Math.pow(a,b);
        }
        catch (java.lang.Throwable exc$206384) {
            throw x10.runtime.impl.java.ThrowableUtils.ensureX10Exception(exc$206384);
        }
        
    }
    
    
    
    //#line 96 "x10/lang/Math.x10"
    public static double pow$O(final int a, final double b) {
        
        //#line 96 "x10/lang/Math.x10"
        final double t$134027 = ((double)(int)(((int)(a))));
        
        //#line 96 "x10/lang/Math.x10"
        final double t$134028 = java.lang.Math.pow(((double)(t$134027)),((double)(b)));
        
        //#line 96 "x10/lang/Math.x10"
        return t$134028;
    }
    
    
    //#line 97 "x10/lang/Math.x10"
    public static double pow$O(final double a, final int b) {
        
        //#line 97 "x10/lang/Math.x10"
        final double t$134029 = ((double)(int)(((int)(b))));
        
        //#line 97 "x10/lang/Math.x10"
        final double t$134030 = java.lang.Math.pow(((double)(a)),((double)(t$134029)));
        
        //#line 97 "x10/lang/Math.x10"
        return t$134030;
    }
    
    
    //#line 98 "x10/lang/Math.x10"
    public static double pow$O(final int a, final int b) {
        
        //#line 98 "x10/lang/Math.x10"
        final double t$134031 = ((double)(int)(((int)(a))));
        
        //#line 98 "x10/lang/Math.x10"
        final double t$134032 = ((double)(int)(((int)(b))));
        
        //#line 98 "x10/lang/Math.x10"
        final double t$134033 = java.lang.Math.pow(((double)(t$134031)),((double)(t$134032)));
        
        //#line 98 "x10/lang/Math.x10"
        return t$134033;
    }
    
    
    //#line 99 "x10/lang/Math.x10"
    public static double pow$O(final long a, final double b) {
        
        //#line 99 "x10/lang/Math.x10"
        final double t$134034 = ((double)(long)(((long)(a))));
        
        //#line 99 "x10/lang/Math.x10"
        final double t$134035 = java.lang.Math.pow(((double)(t$134034)),((double)(b)));
        
        //#line 99 "x10/lang/Math.x10"
        return t$134035;
    }
    
    
    //#line 100 "x10/lang/Math.x10"
    public static double pow$O(final double a, final long b) {
        
        //#line 100 "x10/lang/Math.x10"
        final double t$134036 = ((double)(long)(((long)(b))));
        
        //#line 100 "x10/lang/Math.x10"
        final double t$134037 = java.lang.Math.pow(((double)(a)),((double)(t$134036)));
        
        //#line 100 "x10/lang/Math.x10"
        return t$134037;
    }
    
    
    //#line 101 "x10/lang/Math.x10"
    public static double pow$O(final long a, final long b) {
        
        //#line 101 "x10/lang/Math.x10"
        final double t$134038 = ((double)(long)(((long)(a))));
        
        //#line 101 "x10/lang/Math.x10"
        final double t$134039 = ((double)(long)(((long)(b))));
        
        //#line 101 "x10/lang/Math.x10"
        final double t$134040 = java.lang.Math.pow(((double)(t$134038)),((double)(t$134039)));
        
        //#line 101 "x10/lang/Math.x10"
        return t$134040;
    }
    
    
    //#line 106 "x10/lang/Math.x10"
    /**
     * @deprecated use {@link #pow(Float,Float)} instead
     */
    public static float powf$O(final float a, final float b) {
        try {
            return (float)java.lang.Math.pow(a,b);
        }
        catch (java.lang.Throwable exc$206385) {
            throw x10.runtime.impl.java.ThrowableUtils.ensureX10Exception(exc$206385);
        }
        
    }
    
    
    
    //#line 118 "x10/lang/Math.x10"
    /**
     * Returns the principal value of the complex power <code>a^b</code>.
     * The branch cuts are on the real line at (-inf, 0) for real(b) <= 0,
     * and (-inf, 0] for real(b) > 0.   pow(0,0) is not defined.
     * @return a raised to the power <code>b</code>
     * @see http://mathworld.wolfram.com/Power.html
     */
    public static x10.lang.Complex pow(final x10.lang.Complex a, final x10.lang.Complex b) {
        
        //#line 119 "x10/lang/Math.x10"
        final x10.lang.Complex t$134041 = x10.lang.Math.log(((x10.lang.Complex)(a)));
        
        //#line 119 "x10/lang/Math.x10"
        final x10.lang.Complex t$134042 = t$134041.$times(((x10.lang.Complex)(b)));
        
        //#line 119 "x10/lang/Math.x10"
        final x10.lang.Complex t$134043 = x10.lang.Math.exp(((x10.lang.Complex)(t$134042)));
        
        //#line 119 "x10/lang/Math.x10"
        return t$134043;
    }
    
    
    //#line 121 "x10/lang/Math.x10"
    public static double exp$O(final double a) {
        try {
            return java.lang.Math.exp(a);
        }
        catch (java.lang.Throwable exc$206386) {
            throw x10.runtime.impl.java.ThrowableUtils.ensureX10Exception(exc$206386);
        }
        
    }
    
    
    
    //#line 126 "x10/lang/Math.x10"
    public static float exp$O(final float a) {
        try {
            return (float)java.lang.Math.exp(a);
        }
        catch (java.lang.Throwable exc$206387) {
            throw x10.runtime.impl.java.ThrowableUtils.ensureX10Exception(exc$206387);
        }
        
    }
    
    
    
    //#line 131 "x10/lang/Math.x10"
    public static double exp$O(final int a) {
        
        //#line 131 "x10/lang/Math.x10"
        final double t$134044 = ((double)(int)(((int)(a))));
        
        //#line 131 "x10/lang/Math.x10"
        final double t$134045 = java.lang.Math.exp(((double)(t$134044)));
        
        //#line 131 "x10/lang/Math.x10"
        return t$134045;
    }
    
    
    //#line 132 "x10/lang/Math.x10"
    public static double exp$O(final long a) {
        
        //#line 132 "x10/lang/Math.x10"
        final double t$134046 = ((double)(long)(((long)(a))));
        
        //#line 132 "x10/lang/Math.x10"
        final double t$134047 = java.lang.Math.exp(((double)(t$134046)));
        
        //#line 132 "x10/lang/Math.x10"
        return t$134047;
    }
    
    
    //#line 137 "x10/lang/Math.x10"
    /**
     * @deprecated use {@link #exp(Float)} instead
     */
    public static float expf$O(final float a) {
        try {
            return (float)java.lang.Math.exp(a);
        }
        catch (java.lang.Throwable exc$206388) {
            throw x10.runtime.impl.java.ThrowableUtils.ensureX10Exception(exc$206388);
        }
        
    }
    
    
    
    //#line 146 "x10/lang/Math.x10"
    /**
     * @return the exponential function <code>e^a</code>
     * @see http://mathworld.wolfram.com/ExponentialFunction.html
     */
    public static x10.lang.Complex exp(final x10.lang.Complex a) {
        
        //#line 148 "x10/lang/Math.x10"
        final boolean t$134049 = a.isNaN$O();
        
        //#line 148 "x10/lang/Math.x10"
        if (t$134049) {
            
            //#line 149 "x10/lang/Math.x10"
            final x10.lang.Complex t$134048 = ((x10.lang.Complex)(x10.lang.Complex.get$NaN()));
            
            //#line 149 "x10/lang/Math.x10"
            return t$134048;
        }
        
        //#line 151 "x10/lang/Math.x10"
        final double t$134050 = a.re;
        
        //#line 151 "x10/lang/Math.x10"
        final double expRe = java.lang.Math.exp(((double)(t$134050)));
        
        //#line 152 "x10/lang/Math.x10"
        final double t$134051 = a.im;
        
        //#line 152 "x10/lang/Math.x10"
        final double t$134052 = java.lang.Math.cos(((double)(t$134051)));
        
        //#line 152 "x10/lang/Math.x10"
        final double t$134055 = ((expRe) * (((double)(t$134052))));
        
        //#line 152 "x10/lang/Math.x10"
        final double t$134053 = a.im;
        
        //#line 152 "x10/lang/Math.x10"
        final double t$134054 = java.lang.Math.sin(((double)(t$134053)));
        
        //#line 152 "x10/lang/Math.x10"
        final double t$134056 = ((expRe) * (((double)(t$134054))));
        
        //#line 152 "x10/lang/Math.x10"
        final x10.lang.Complex t$134057 = new x10.lang.Complex(t$134055, t$134056);
        
        //#line 152 "x10/lang/Math.x10"
        return t$134057;
    }
    
    
    //#line 155 "x10/lang/Math.x10"
    public static double expm1$O(final double a) {
        try {
            return java.lang.Math.expm1(a);
        }
        catch (java.lang.Throwable exc$206389) {
            throw x10.runtime.impl.java.ThrowableUtils.ensureX10Exception(exc$206389);
        }
        
    }
    
    
    
    //#line 160 "x10/lang/Math.x10"
    public static double cos$O(final double a) {
        try {
            return java.lang.Math.cos(a);
        }
        catch (java.lang.Throwable exc$206390) {
            throw x10.runtime.impl.java.ThrowableUtils.ensureX10Exception(exc$206390);
        }
        
    }
    
    
    
    //#line 169 "x10/lang/Math.x10"
    /**
     * @return the cosine of <code>z</code>
     * @see http://mathworld.wolfram.com/Cosine.html
     */
    public static x10.lang.Complex cos(final x10.lang.Complex z) {
        
        //#line 171 "x10/lang/Math.x10"
        final double t$134058 = z.im;
        
        //#line 171 "x10/lang/Math.x10"
        final boolean t$134074 = ((double) t$134058) == ((double) 0.0);
        
        //#line 171 "x10/lang/Math.x10"
        if (t$134074) {
            
            //#line 172 "x10/lang/Math.x10"
            final double t$134059 = z.re;
            
            //#line 172 "x10/lang/Math.x10"
            final double t$134060 = java.lang.Math.cos(((double)(t$134059)));
            
            //#line 172 "x10/lang/Math.x10"
            final x10.lang.Complex t$134061 = new x10.lang.Complex(t$134060, ((double)(0.0)));
            
            //#line 172 "x10/lang/Math.x10"
            return t$134061;
        } else {
            
            //#line 174 "x10/lang/Math.x10"
            final double t$134062 = z.re;
            
            //#line 174 "x10/lang/Math.x10"
            final double t$134064 = java.lang.Math.cos(((double)(t$134062)));
            
            //#line 174 "x10/lang/Math.x10"
            final double t$134063 = z.im;
            
            //#line 174 "x10/lang/Math.x10"
            final double t$134065 = java.lang.Math.cosh(((double)(t$134063)));
            
            //#line 174 "x10/lang/Math.x10"
            final double t$134071 = ((t$134064) * (((double)(t$134065))));
            
            //#line 174 "x10/lang/Math.x10"
            final double t$134066 = z.re;
            
            //#line 174 "x10/lang/Math.x10"
            final double t$134069 = java.lang.Math.sin(((double)(t$134066)));
            
            //#line 174 "x10/lang/Math.x10"
            final double t$134067 = z.im;
            
            //#line 174 "x10/lang/Math.x10"
            final double t$134068 = (-(t$134067));
            
            //#line 174 "x10/lang/Math.x10"
            final double t$134070 = java.lang.Math.sinh(((double)(t$134068)));
            
            //#line 174 "x10/lang/Math.x10"
            final double t$134072 = ((t$134069) * (((double)(t$134070))));
            
            //#line 174 "x10/lang/Math.x10"
            final x10.lang.Complex t$134073 = new x10.lang.Complex(t$134071, t$134072);
            
            //#line 174 "x10/lang/Math.x10"
            return t$134073;
        }
    }
    
    
    //#line 178 "x10/lang/Math.x10"
    public static double sin$O(final double a) {
        try {
            return java.lang.Math.sin(a);
        }
        catch (java.lang.Throwable exc$206391) {
            throw x10.runtime.impl.java.ThrowableUtils.ensureX10Exception(exc$206391);
        }
        
    }
    
    
    
    //#line 187 "x10/lang/Math.x10"
    /**
     * @return the sine of <code>z</code>
     * @see http://mathworld.wolfram.com/Sine.html
     */
    public static x10.lang.Complex sin(final x10.lang.Complex z) {
        
        //#line 189 "x10/lang/Math.x10"
        final double t$134075 = z.im;
        
        //#line 189 "x10/lang/Math.x10"
        final boolean t$134090 = ((double) t$134075) == ((double) 0.0);
        
        //#line 189 "x10/lang/Math.x10"
        if (t$134090) {
            
            //#line 190 "x10/lang/Math.x10"
            final double t$134076 = z.re;
            
            //#line 190 "x10/lang/Math.x10"
            final double t$134077 = java.lang.Math.sin(((double)(t$134076)));
            
            //#line 190 "x10/lang/Math.x10"
            final x10.lang.Complex t$134078 = new x10.lang.Complex(t$134077, ((double)(0.0)));
            
            //#line 190 "x10/lang/Math.x10"
            return t$134078;
        } else {
            
            //#line 192 "x10/lang/Math.x10"
            final double t$134079 = z.re;
            
            //#line 192 "x10/lang/Math.x10"
            final double t$134081 = java.lang.Math.sin(((double)(t$134079)));
            
            //#line 192 "x10/lang/Math.x10"
            final double t$134080 = z.im;
            
            //#line 192 "x10/lang/Math.x10"
            final double t$134082 = java.lang.Math.cosh(((double)(t$134080)));
            
            //#line 192 "x10/lang/Math.x10"
            final double t$134087 = ((t$134081) * (((double)(t$134082))));
            
            //#line 192 "x10/lang/Math.x10"
            final double t$134083 = z.re;
            
            //#line 192 "x10/lang/Math.x10"
            final double t$134085 = java.lang.Math.cos(((double)(t$134083)));
            
            //#line 192 "x10/lang/Math.x10"
            final double t$134084 = z.im;
            
            //#line 192 "x10/lang/Math.x10"
            final double t$134086 = java.lang.Math.sinh(((double)(t$134084)));
            
            //#line 192 "x10/lang/Math.x10"
            final double t$134088 = ((t$134085) * (((double)(t$134086))));
            
            //#line 192 "x10/lang/Math.x10"
            final x10.lang.Complex t$134089 = new x10.lang.Complex(t$134087, t$134088);
            
            //#line 192 "x10/lang/Math.x10"
            return t$134089;
        }
    }
    
    
    //#line 196 "x10/lang/Math.x10"
    public static double tan$O(final double a) {
        try {
            return java.lang.Math.tan(a);
        }
        catch (java.lang.Throwable exc$206392) {
            throw x10.runtime.impl.java.ThrowableUtils.ensureX10Exception(exc$206392);
        }
        
    }
    
    
    
    //#line 205 "x10/lang/Math.x10"
    /**
     * @return the tangent of <code>z</code>
     * @see http://mathworld.wolfram.com/Tangent.html
     */
    public static x10.lang.Complex tan(final x10.lang.Complex z) {
        
        //#line 207 "x10/lang/Math.x10"
        final double t$134091 = z.im;
        
        //#line 207 "x10/lang/Math.x10"
        final boolean t$134103 = ((double) t$134091) == ((double) 0.0);
        
        //#line 207 "x10/lang/Math.x10"
        if (t$134103) {
            
            //#line 208 "x10/lang/Math.x10"
            final double t$134092 = z.re;
            
            //#line 208 "x10/lang/Math.x10"
            final double t$134093 = java.lang.Math.tan(((double)(t$134092)));
            
            //#line 208 "x10/lang/Math.x10"
            final x10.lang.Complex t$134094 = new x10.lang.Complex(t$134093, ((double)(0.0)));
            
            //#line 208 "x10/lang/Math.x10"
            return t$134094;
        } else {
            
            //#line 211 "x10/lang/Math.x10"
            final x10.lang.Complex t$134095 = ((x10.lang.Complex)(x10.lang.Complex.get$I()));
            
            //#line 211 "x10/lang/Math.x10"
            final x10.lang.Complex t$134096 = x10.lang.Complex.$times((double)(2.0), ((x10.lang.Complex)(t$134095)));
            
            //#line 211 "x10/lang/Math.x10"
            final x10.lang.Complex t$134097 = t$134096.$times(((x10.lang.Complex)(z)));
            
            //#line 211 "x10/lang/Math.x10"
            final x10.lang.Complex e2IZ = x10.lang.Math.exp(((x10.lang.Complex)(t$134097)));
            
            //#line 212 "x10/lang/Math.x10"
            final x10.lang.Complex t$134100 = e2IZ.$minus((double)(1.0));
            
            //#line 212 "x10/lang/Math.x10"
            final x10.lang.Complex t$134098 = ((x10.lang.Complex)(x10.lang.Complex.get$I()));
            
            //#line 212 "x10/lang/Math.x10"
            final x10.lang.Complex t$134099 = e2IZ.$plus((double)(1.0));
            
            //#line 212 "x10/lang/Math.x10"
            final x10.lang.Complex t$134101 = t$134098.$times(((x10.lang.Complex)(t$134099)));
            
            //#line 212 "x10/lang/Math.x10"
            final x10.lang.Complex t$134102 = t$134100.$over(((x10.lang.Complex)(t$134101)));
            
            //#line 212 "x10/lang/Math.x10"
            return t$134102;
        }
    }
    
    
    //#line 216 "x10/lang/Math.x10"
    public static double acos$O(final double a) {
        try {
            return java.lang.Math.acos(a);
        }
        catch (java.lang.Throwable exc$206393) {
            throw x10.runtime.impl.java.ThrowableUtils.ensureX10Exception(exc$206393);
        }
        
    }
    
    
    
    //#line 229 "x10/lang/Math.x10"
    /**
     * Returns the principal value of the inverse cosine of <code>z</code>.
     * The branch cuts are on the real line at (-inf, -1) and (1, +inf)
     * The real part of the inverse cosine ranges from 0 to PI.
     * @return the inverse cosine of <code>z</code>
     * @see http://mathworld.wolfram.com/InverseCosine.html
     */
    public static x10.lang.Complex acos(final x10.lang.Complex z) {
        
        //#line 230 "x10/lang/Math.x10"
        final double t$134104 = z.im;
        
        //#line 230 "x10/lang/Math.x10"
        boolean t$134107 = ((double) t$134104) == ((double) 0.0);
        
        //#line 230 "x10/lang/Math.x10"
        if (t$134107) {
            
            //#line 230 "x10/lang/Math.x10"
            final double t$134105 = z.re;
            
            //#line 230 "x10/lang/Math.x10"
            final double t$134106 = java.lang.Math.abs(((double)(t$134105)));
            
            //#line 230 "x10/lang/Math.x10"
            t$134107 = ((t$134106) <= (((double)(1.0))));
        }
        
        //#line 230 "x10/lang/Math.x10"
        if (t$134107) {
            
            //#line 231 "x10/lang/Math.x10"
            final double t$134108 = z.re;
            
            //#line 231 "x10/lang/Math.x10"
            final double t$134109 = java.lang.Math.acos(((double)(t$134108)));
            
            //#line 231 "x10/lang/Math.x10"
            final x10.lang.Complex t$134110 = new x10.lang.Complex(t$134109, ((double)(0.0)));
            
            //#line 231 "x10/lang/Math.x10"
            return t$134110;
        } else {
            
            //#line 234 "x10/lang/Math.x10"
            final double t$134119 = ((3.141592653589793) / (((double)(2.0))));
            
            //#line 234 "x10/lang/Math.x10"
            final x10.lang.Complex t$134117 = ((x10.lang.Complex)(x10.lang.Complex.get$I()));
            
            //#line 234 "x10/lang/Math.x10"
            final x10.lang.Complex t$134111 = ((x10.lang.Complex)(x10.lang.Complex.get$I()));
            
            //#line 234 "x10/lang/Math.x10"
            final x10.lang.Complex t$134114 = t$134111.$times(((x10.lang.Complex)(z)));
            
            //#line 234 "x10/lang/Math.x10"
            final x10.lang.Complex t$134112 = z.$times(((x10.lang.Complex)(z)));
            
            //#line 234 "x10/lang/Math.x10"
            final x10.lang.Complex t$134113 = x10.lang.Complex.$minus((double)(1.0), ((x10.lang.Complex)(t$134112)));
            
            //#line 234 "x10/lang/Math.x10"
            final x10.lang.Complex t$134115 = x10.lang.Math.sqrt(((x10.lang.Complex)(t$134113)));
            
            //#line 234 "x10/lang/Math.x10"
            final x10.lang.Complex t$134116 = t$134114.$plus(((x10.lang.Complex)(t$134115)));
            
            //#line 234 "x10/lang/Math.x10"
            final x10.lang.Complex t$134118 = x10.lang.Math.log(((x10.lang.Complex)(t$134116)));
            
            //#line 234 "x10/lang/Math.x10"
            final x10.lang.Complex t$134120 = t$134117.$times(((x10.lang.Complex)(t$134118)));
            
            //#line 234 "x10/lang/Math.x10"
            final x10.lang.Complex t$134121 = x10.lang.Complex.$plus((double)(t$134119), ((x10.lang.Complex)(t$134120)));
            
            //#line 234 "x10/lang/Math.x10"
            return t$134121;
        }
    }
    
    
    //#line 238 "x10/lang/Math.x10"
    public static double asin$O(final double a) {
        try {
            return java.lang.Math.asin(a);
        }
        catch (java.lang.Throwable exc$206394) {
            throw x10.runtime.impl.java.ThrowableUtils.ensureX10Exception(exc$206394);
        }
        
    }
    
    
    
    //#line 251 "x10/lang/Math.x10"
    /**
     * Returns the principal value of the inverse sine of <code>z</code>.
     * The branch cuts are on the real line at (-inf, -1) and (1, +inf)
     * The real part of the inverse sine ranges from -PI/2 to +PI/2.
     * @return the inverse sine of <code>z</code>
     * @see http://mathworld.wolfram.com/InverseSine.html
     */
    public static x10.lang.Complex asin(final x10.lang.Complex z) {
        
        //#line 252 "x10/lang/Math.x10"
        final double t$134123 = z.im;
        
        //#line 252 "x10/lang/Math.x10"
        boolean t$134126 = ((double) t$134123) == ((double) 0.0);
        
        //#line 252 "x10/lang/Math.x10"
        if (t$134126) {
            
            //#line 252 "x10/lang/Math.x10"
            final double t$134124 = z.re;
            
            //#line 252 "x10/lang/Math.x10"
            final double t$134125 = java.lang.Math.abs(((double)(t$134124)));
            
            //#line 252 "x10/lang/Math.x10"
            t$134126 = ((t$134125) <= (((double)(1.0))));
        }
        
        //#line 252 "x10/lang/Math.x10"
        if (t$134126) {
            
            //#line 253 "x10/lang/Math.x10"
            final double t$134127 = z.re;
            
            //#line 253 "x10/lang/Math.x10"
            final double t$134128 = java.lang.Math.asin(((double)(t$134127)));
            
            //#line 253 "x10/lang/Math.x10"
            final x10.lang.Complex t$134129 = new x10.lang.Complex(t$134128, ((double)(0.0)));
            
            //#line 253 "x10/lang/Math.x10"
            return t$134129;
        } else {
            
            //#line 256 "x10/lang/Math.x10"
            final x10.lang.Complex t$134130 = ((x10.lang.Complex)(x10.lang.Complex.get$I()));
            
            //#line 256 "x10/lang/Math.x10"
            final x10.lang.Complex t$134137 = t$134130.$minus();
            
            //#line 256 "x10/lang/Math.x10"
            final x10.lang.Complex t$134131 = ((x10.lang.Complex)(x10.lang.Complex.get$I()));
            
            //#line 256 "x10/lang/Math.x10"
            final x10.lang.Complex t$134134 = t$134131.$times(((x10.lang.Complex)(z)));
            
            //#line 256 "x10/lang/Math.x10"
            final x10.lang.Complex t$134132 = z.$times(((x10.lang.Complex)(z)));
            
            //#line 256 "x10/lang/Math.x10"
            final x10.lang.Complex t$134133 = x10.lang.Complex.$minus((double)(1.0), ((x10.lang.Complex)(t$134132)));
            
            //#line 256 "x10/lang/Math.x10"
            final x10.lang.Complex t$134135 = x10.lang.Math.sqrt(((x10.lang.Complex)(t$134133)));
            
            //#line 256 "x10/lang/Math.x10"
            final x10.lang.Complex t$134136 = t$134134.$plus(((x10.lang.Complex)(t$134135)));
            
            //#line 256 "x10/lang/Math.x10"
            final x10.lang.Complex t$134138 = x10.lang.Math.log(((x10.lang.Complex)(t$134136)));
            
            //#line 256 "x10/lang/Math.x10"
            final x10.lang.Complex t$134139 = t$134137.$times(((x10.lang.Complex)(t$134138)));
            
            //#line 256 "x10/lang/Math.x10"
            return t$134139;
        }
    }
    
    
    //#line 260 "x10/lang/Math.x10"
    public static double atan$O(final double a) {
        try {
            return java.lang.Math.atan(a);
        }
        catch (java.lang.Throwable exc$206395) {
            throw x10.runtime.impl.java.ThrowableUtils.ensureX10Exception(exc$206395);
        }
        
    }
    
    
    
    //#line 273 "x10/lang/Math.x10"
    /**
     * Returns the principal value of the inverse tangent of <code>z</code>.
     * The branch cuts are on the imaginary line at (-i*inf, -i] and [i, i*inf)
     * The real part of the inverse tangent ranges from -PI/2 to +PI/2.
     * @return the principal value of the inverse tangent of <code>z</code>
     * @see http://mathworld.wolfram.com/InverseTangent.html
     */
    public static x10.lang.Complex atan(final x10.lang.Complex z) {
        
        //#line 274 "x10/lang/Math.x10"
        final double t$134141 = z.im;
        
        //#line 274 "x10/lang/Math.x10"
        final boolean t$134166 = ((double) t$134141) == ((double) 0.0);
        
        //#line 274 "x10/lang/Math.x10"
        if (t$134166) {
            
            //#line 275 "x10/lang/Math.x10"
            final double t$134142 = z.re;
            
            //#line 275 "x10/lang/Math.x10"
            final double t$134143 = java.lang.Math.atan(((double)(t$134142)));
            
            //#line 275 "x10/lang/Math.x10"
            final x10.lang.Complex t$134144 = new x10.lang.Complex(t$134143, ((double)(0.0)));
            
            //#line 275 "x10/lang/Math.x10"
            return t$134144;
        } else {
            
            //#line 276 "x10/lang/Math.x10"
            final x10.lang.Complex t$134145 = ((x10.lang.Complex)(x10.lang.Complex.get$I()));
            
            //#line 276 "x10/lang/Math.x10"
            final boolean t$134165 = x10.rtt.Equality.equalsequals((z),(t$134145));
            
            //#line 276 "x10/lang/Math.x10"
            if (t$134165) {
                
                //#line 277 "x10/lang/Math.x10"
                final double t$134146 = java.lang.Double.POSITIVE_INFINITY;
                
                //#line 277 "x10/lang/Math.x10"
                final x10.lang.Complex t$134147 = new x10.lang.Complex(((double)(0.0)), ((double)(t$134146)));
                
                //#line 277 "x10/lang/Math.x10"
                return t$134147;
            } else {
                
                //#line 278 "x10/lang/Math.x10"
                final x10.lang.Complex t$134148 = ((x10.lang.Complex)(x10.lang.Complex.get$I()));
                
                //#line 278 "x10/lang/Math.x10"
                final x10.lang.Complex t$134149 = t$134148.$minus();
                
                //#line 278 "x10/lang/Math.x10"
                final boolean t$134164 = x10.rtt.Equality.equalsequals((z),(t$134149));
                
                //#line 278 "x10/lang/Math.x10"
                if (t$134164) {
                    
                    //#line 279 "x10/lang/Math.x10"
                    final double t$134150 = java.lang.Double.NEGATIVE_INFINITY;
                    
                    //#line 279 "x10/lang/Math.x10"
                    final x10.lang.Complex t$134151 = new x10.lang.Complex(((double)(0.0)), ((double)(t$134150)));
                    
                    //#line 279 "x10/lang/Math.x10"
                    return t$134151;
                } else {
                    
                    //#line 282 "x10/lang/Math.x10"
                    final x10.lang.Complex t$134152 = ((x10.lang.Complex)(x10.lang.Complex.get$I()));
                    
                    //#line 282 "x10/lang/Math.x10"
                    final x10.lang.Complex t$134161 = t$134152.$over((double)(2.0));
                    
                    //#line 282 "x10/lang/Math.x10"
                    final x10.lang.Complex t$134153 = ((x10.lang.Complex)(x10.lang.Complex.get$I()));
                    
                    //#line 282 "x10/lang/Math.x10"
                    final x10.lang.Complex t$134154 = t$134153.$times(((x10.lang.Complex)(z)));
                    
                    //#line 282 "x10/lang/Math.x10"
                    final x10.lang.Complex t$134155 = x10.lang.Complex.$minus((double)(1.0), ((x10.lang.Complex)(t$134154)));
                    
                    //#line 282 "x10/lang/Math.x10"
                    final x10.lang.Complex t$134159 = x10.lang.Math.log(((x10.lang.Complex)(t$134155)));
                    
                    //#line 282 "x10/lang/Math.x10"
                    final x10.lang.Complex t$134156 = ((x10.lang.Complex)(x10.lang.Complex.get$I()));
                    
                    //#line 282 "x10/lang/Math.x10"
                    final x10.lang.Complex t$134157 = t$134156.$times(((x10.lang.Complex)(z)));
                    
                    //#line 282 "x10/lang/Math.x10"
                    final x10.lang.Complex t$134158 = x10.lang.Complex.$plus((double)(1.0), ((x10.lang.Complex)(t$134157)));
                    
                    //#line 282 "x10/lang/Math.x10"
                    final x10.lang.Complex t$134160 = x10.lang.Math.log(((x10.lang.Complex)(t$134158)));
                    
                    //#line 282 "x10/lang/Math.x10"
                    final x10.lang.Complex t$134162 = t$134159.$minus(((x10.lang.Complex)(t$134160)));
                    
                    //#line 282 "x10/lang/Math.x10"
                    final x10.lang.Complex t$134163 = t$134161.$times(((x10.lang.Complex)(t$134162)));
                    
                    //#line 282 "x10/lang/Math.x10"
                    return t$134163;
                }
            }
        }
    }
    
    
    //#line 286 "x10/lang/Math.x10"
    public static double atan2$O(final double a, final double b) {
        try {
            return java.lang.Math.atan2(a,b);
        }
        catch (java.lang.Throwable exc$206396) {
            throw x10.runtime.impl.java.ThrowableUtils.ensureX10Exception(exc$206396);
        }
        
    }
    
    
    
    //#line 291 "x10/lang/Math.x10"
    public static double cosh$O(final double a) {
        try {
            return java.lang.Math.cosh(a);
        }
        catch (java.lang.Throwable exc$206397) {
            throw x10.runtime.impl.java.ThrowableUtils.ensureX10Exception(exc$206397);
        }
        
    }
    
    
    
    //#line 300 "x10/lang/Math.x10"
    /**
     * @return the hyperbolic cosine of <code>z</code>
     * @see http://mathworld.wolfram.com/HyperbolicCosine.html
     */
    public static x10.lang.Complex cosh(final x10.lang.Complex z) {
        
        //#line 302 "x10/lang/Math.x10"
        final boolean t$134184 = z.isNaN$O();
        
        //#line 302 "x10/lang/Math.x10"
        if (t$134184) {
            
            //#line 303 "x10/lang/Math.x10"
            final x10.lang.Complex t$134167 = ((x10.lang.Complex)(x10.lang.Complex.get$NaN()));
            
            //#line 303 "x10/lang/Math.x10"
            return t$134167;
        } else {
            
            //#line 304 "x10/lang/Math.x10"
            final double t$134168 = z.im;
            
            //#line 304 "x10/lang/Math.x10"
            final boolean t$134183 = ((double) t$134168) == ((double) 0.0);
            
            //#line 304 "x10/lang/Math.x10"
            if (t$134183) {
                
                //#line 305 "x10/lang/Math.x10"
                final double t$134169 = z.re;
                
                //#line 305 "x10/lang/Math.x10"
                final double t$134170 = java.lang.Math.cosh(((double)(t$134169)));
                
                //#line 305 "x10/lang/Math.x10"
                final x10.lang.Complex t$134171 = new x10.lang.Complex(t$134170, ((double)(0.0)));
                
                //#line 305 "x10/lang/Math.x10"
                return t$134171;
            } else {
                
                //#line 307 "x10/lang/Math.x10"
                final double t$134172 = z.re;
                
                //#line 307 "x10/lang/Math.x10"
                final double t$134174 = java.lang.Math.cosh(((double)(t$134172)));
                
                //#line 307 "x10/lang/Math.x10"
                final double t$134173 = z.im;
                
                //#line 307 "x10/lang/Math.x10"
                final double t$134175 = java.lang.Math.cos(((double)(t$134173)));
                
                //#line 307 "x10/lang/Math.x10"
                final double t$134180 = ((t$134174) * (((double)(t$134175))));
                
                //#line 307 "x10/lang/Math.x10"
                final double t$134176 = z.re;
                
                //#line 307 "x10/lang/Math.x10"
                final double t$134178 = java.lang.Math.sinh(((double)(t$134176)));
                
                //#line 307 "x10/lang/Math.x10"
                final double t$134177 = z.im;
                
                //#line 307 "x10/lang/Math.x10"
                final double t$134179 = java.lang.Math.sin(((double)(t$134177)));
                
                //#line 307 "x10/lang/Math.x10"
                final double t$134181 = ((t$134178) * (((double)(t$134179))));
                
                //#line 307 "x10/lang/Math.x10"
                final x10.lang.Complex t$134182 = new x10.lang.Complex(t$134180, t$134181);
                
                //#line 307 "x10/lang/Math.x10"
                return t$134182;
            }
        }
    }
    
    
    //#line 311 "x10/lang/Math.x10"
    public static double sinh$O(final double a) {
        try {
            return java.lang.Math.sinh(a);
        }
        catch (java.lang.Throwable exc$206398) {
            throw x10.runtime.impl.java.ThrowableUtils.ensureX10Exception(exc$206398);
        }
        
    }
    
    
    
    //#line 320 "x10/lang/Math.x10"
    /**
     * @return the hyperbolic sine of <code>z</code>
     * @see http://mathworld.wolfram.com/HyperbolicSine.html
     */
    public static x10.lang.Complex sinh(final x10.lang.Complex z) {
        
        //#line 322 "x10/lang/Math.x10"
        final boolean t$134202 = z.isNaN$O();
        
        //#line 322 "x10/lang/Math.x10"
        if (t$134202) {
            
            //#line 323 "x10/lang/Math.x10"
            final x10.lang.Complex t$134185 = ((x10.lang.Complex)(x10.lang.Complex.get$NaN()));
            
            //#line 323 "x10/lang/Math.x10"
            return t$134185;
        } else {
            
            //#line 324 "x10/lang/Math.x10"
            final double t$134186 = z.im;
            
            //#line 324 "x10/lang/Math.x10"
            final boolean t$134201 = ((double) t$134186) == ((double) 0.0);
            
            //#line 324 "x10/lang/Math.x10"
            if (t$134201) {
                
                //#line 325 "x10/lang/Math.x10"
                final double t$134187 = z.re;
                
                //#line 325 "x10/lang/Math.x10"
                final double t$134188 = java.lang.Math.sinh(((double)(t$134187)));
                
                //#line 325 "x10/lang/Math.x10"
                final x10.lang.Complex t$134189 = new x10.lang.Complex(t$134188, ((double)(0.0)));
                
                //#line 325 "x10/lang/Math.x10"
                return t$134189;
            } else {
                
                //#line 327 "x10/lang/Math.x10"
                final double t$134190 = z.re;
                
                //#line 327 "x10/lang/Math.x10"
                final double t$134192 = java.lang.Math.sinh(((double)(t$134190)));
                
                //#line 327 "x10/lang/Math.x10"
                final double t$134191 = z.im;
                
                //#line 327 "x10/lang/Math.x10"
                final double t$134193 = java.lang.Math.cos(((double)(t$134191)));
                
                //#line 327 "x10/lang/Math.x10"
                final double t$134198 = ((t$134192) * (((double)(t$134193))));
                
                //#line 327 "x10/lang/Math.x10"
                final double t$134194 = z.re;
                
                //#line 327 "x10/lang/Math.x10"
                final double t$134196 = java.lang.Math.cosh(((double)(t$134194)));
                
                //#line 327 "x10/lang/Math.x10"
                final double t$134195 = z.im;
                
                //#line 327 "x10/lang/Math.x10"
                final double t$134197 = java.lang.Math.sin(((double)(t$134195)));
                
                //#line 327 "x10/lang/Math.x10"
                final double t$134199 = ((t$134196) * (((double)(t$134197))));
                
                //#line 327 "x10/lang/Math.x10"
                final x10.lang.Complex t$134200 = new x10.lang.Complex(t$134198, t$134199);
                
                //#line 327 "x10/lang/Math.x10"
                return t$134200;
            }
        }
    }
    
    
    //#line 331 "x10/lang/Math.x10"
    public static double tanh$O(final double a) {
        try {
            return java.lang.Math.tanh(a);
        }
        catch (java.lang.Throwable exc$206399) {
            throw x10.runtime.impl.java.ThrowableUtils.ensureX10Exception(exc$206399);
        }
        
    }
    
    
    
    //#line 340 "x10/lang/Math.x10"
    /**
     * @return the hyperbolic tangent of <code>z</code>
     * @see http://mathworld.wolfram.com/HyperbolicTangent.html
     */
    public static x10.lang.Complex tanh(final x10.lang.Complex z) {
        
        //#line 342 "x10/lang/Math.x10"
        final boolean t$134204 = z.isNaN$O();
        
        //#line 342 "x10/lang/Math.x10"
        if (t$134204) {
            
            //#line 343 "x10/lang/Math.x10"
            final x10.lang.Complex t$134203 = ((x10.lang.Complex)(x10.lang.Complex.get$NaN()));
            
            //#line 343 "x10/lang/Math.x10"
            return t$134203;
        }
        
        //#line 345 "x10/lang/Math.x10"
        final double t$134205 = z.re;
        
        //#line 345 "x10/lang/Math.x10"
        final double t$134206 = ((2.0) * (((double)(t$134205))));
        
        //#line 345 "x10/lang/Math.x10"
        final double t$134209 = java.lang.Math.cosh(((double)(t$134206)));
        
        //#line 345 "x10/lang/Math.x10"
        final double t$134207 = z.im;
        
        //#line 345 "x10/lang/Math.x10"
        final double t$134208 = ((2.0) * (((double)(t$134207))));
        
        //#line 345 "x10/lang/Math.x10"
        final double t$134210 = java.lang.Math.cos(((double)(t$134208)));
        
        //#line 345 "x10/lang/Math.x10"
        final double d = ((t$134209) + (((double)(t$134210))));
        
        //#line 346 "x10/lang/Math.x10"
        final double t$134211 = z.re;
        
        //#line 346 "x10/lang/Math.x10"
        final double t$134212 = ((2.0) * (((double)(t$134211))));
        
        //#line 346 "x10/lang/Math.x10"
        final double t$134213 = java.lang.Math.sinh(((double)(t$134212)));
        
        //#line 346 "x10/lang/Math.x10"
        final double t$134217 = ((t$134213) / (((double)(d))));
        
        //#line 346 "x10/lang/Math.x10"
        final double t$134214 = z.im;
        
        //#line 346 "x10/lang/Math.x10"
        final double t$134215 = ((2.0) * (((double)(t$134214))));
        
        //#line 346 "x10/lang/Math.x10"
        final double t$134216 = java.lang.Math.sin(((double)(t$134215)));
        
        //#line 346 "x10/lang/Math.x10"
        final double t$134218 = ((t$134216) / (((double)(d))));
        
        //#line 346 "x10/lang/Math.x10"
        final x10.lang.Complex t$134219 = new x10.lang.Complex(t$134217, t$134218);
        
        //#line 346 "x10/lang/Math.x10"
        return t$134219;
    }
    
    
    //#line 349 "x10/lang/Math.x10"
    public static double sqrt$O(final double a) {
        try {
            return java.lang.Math.sqrt(a);
        }
        catch (java.lang.Throwable exc$206400) {
            throw x10.runtime.impl.java.ThrowableUtils.ensureX10Exception(exc$206400);
        }
        
    }
    
    
    
    //#line 354 "x10/lang/Math.x10"
    public static float sqrt$O(final float a) {
        try {
            return (float)java.lang.Math.sqrt(a);
        }
        catch (java.lang.Throwable exc$206401) {
            throw x10.runtime.impl.java.ThrowableUtils.ensureX10Exception(exc$206401);
        }
        
    }
    
    
    
    //#line 359 "x10/lang/Math.x10"
    public static double sqrt$O(final int a) {
        
        //#line 359 "x10/lang/Math.x10"
        final double t$134220 = ((double)(int)(((int)(a))));
        
        //#line 359 "x10/lang/Math.x10"
        final double t$134221 = java.lang.Math.sqrt(((double)(t$134220)));
        
        //#line 359 "x10/lang/Math.x10"
        return t$134221;
    }
    
    
    //#line 360 "x10/lang/Math.x10"
    public static double sqrt$O(final long a) {
        
        //#line 360 "x10/lang/Math.x10"
        final double t$134222 = ((double)(long)(((long)(a))));
        
        //#line 360 "x10/lang/Math.x10"
        final double t$134223 = java.lang.Math.sqrt(((double)(t$134222)));
        
        //#line 360 "x10/lang/Math.x10"
        return t$134223;
    }
    
    
    //#line 365 "x10/lang/Math.x10"
    /**
     * @deprecated use {@link #sqrt(Float)} instead
     */
    public static float sqrtf$O(final float a) {
        try {
            return (float)java.lang.Math.sqrt(a);
        }
        catch (java.lang.Throwable exc$206402) {
            throw x10.runtime.impl.java.ThrowableUtils.ensureX10Exception(exc$206402);
        }
        
    }
    
    
    
    //#line 376 "x10/lang/Math.x10"
    /**
     * Returns the principal value of the square root of <code>z</code>.
     * The branch cut is on the real line at (-inf, 0)
     * @return the principal square root of <code>z</code>
     * @see http://mathworld.wolfram.com/SquareRoot.html
     */
    public static x10.lang.Complex sqrt(final x10.lang.Complex z) {
        
        //#line 377 "x10/lang/Math.x10"
        final boolean t$134246 = z.isNaN$O();
        
        //#line 377 "x10/lang/Math.x10"
        if (t$134246) {
            
            //#line 378 "x10/lang/Math.x10"
            final x10.lang.Complex t$134224 = ((x10.lang.Complex)(x10.lang.Complex.get$NaN()));
            
            //#line 378 "x10/lang/Math.x10"
            return t$134224;
        } else {
            
            //#line 379 "x10/lang/Math.x10"
            final x10.lang.Complex t$134225 = ((x10.lang.Complex)(x10.lang.Complex.get$ZERO()));
            
            //#line 379 "x10/lang/Math.x10"
            final boolean t$134245 = x10.rtt.Equality.equalsequals((z),(t$134225));
            
            //#line 379 "x10/lang/Math.x10"
            if (t$134245) {
                
                //#line 380 "x10/lang/Math.x10"
                final x10.lang.Complex t$134226 = ((x10.lang.Complex)(x10.lang.Complex.get$ZERO()));
                
                //#line 380 "x10/lang/Math.x10"
                return t$134226;
            } else {
                
                //#line 382 "x10/lang/Math.x10"
                final double t$134227 = z.re;
                
                //#line 382 "x10/lang/Math.x10"
                final double t$134228 = java.lang.Math.abs(((double)(t$134227)));
                
                //#line 382 "x10/lang/Math.x10"
                final double t$134229 = z.abs$O();
                
                //#line 382 "x10/lang/Math.x10"
                final double t$134230 = ((t$134228) + (((double)(t$134229))));
                
                //#line 382 "x10/lang/Math.x10"
                final double t$134231 = ((t$134230) / (((double)(2.0))));
                
                //#line 382 "x10/lang/Math.x10"
                final double t = java.lang.Math.sqrt(((double)(t$134231)));
                
                //#line 383 "x10/lang/Math.x10"
                final double t$134232 = z.re;
                
                //#line 383 "x10/lang/Math.x10"
                final boolean t$134244 = ((t$134232) >= (((double)(0.0))));
                
                //#line 383 "x10/lang/Math.x10"
                if (t$134244) {
                    
                    //#line 384 "x10/lang/Math.x10"
                    final double t$134233 = z.im;
                    
                    //#line 384 "x10/lang/Math.x10"
                    final double t$134234 = ((2.0) * (((double)(t))));
                    
                    //#line 384 "x10/lang/Math.x10"
                    final double t$134235 = ((t$134233) / (((double)(t$134234))));
                    
                    //#line 384 "x10/lang/Math.x10"
                    final x10.lang.Complex t$134236 = new x10.lang.Complex(((double)(t)), t$134235);
                    
                    //#line 384 "x10/lang/Math.x10"
                    return t$134236;
                } else {
                    
                    //#line 386 "x10/lang/Math.x10"
                    final double t$134237 = z.im;
                    
                    //#line 386 "x10/lang/Math.x10"
                    final double t$134238 = java.lang.Math.abs(((double)(t$134237)));
                    
                    //#line 386 "x10/lang/Math.x10"
                    final double t$134239 = ((2.0) * (((double)(t))));
                    
                    //#line 386 "x10/lang/Math.x10"
                    final double t$134241 = ((t$134238) / (((double)(t$134239))));
                    
                    //#line 386 "x10/lang/Math.x10"
                    final double t$134240 = z.im;
                    
                    //#line 386 "x10/lang/Math.x10"
                    final double t$134242 = java.lang.Math.copySign(((double)(t)),((double)(t$134240)));
                    
                    //#line 386 "x10/lang/Math.x10"
                    final x10.lang.Complex t$134243 = new x10.lang.Complex(t$134241, t$134242);
                    
                    //#line 386 "x10/lang/Math.x10"
                    return t$134243;
                }
            }
        }
    }
    
    
    //#line 391 "x10/lang/Math.x10"
    public static double cbrt$O(final double a) {
        try {
            return java.lang.Math.cbrt(a);
        }
        catch (java.lang.Throwable exc$206403) {
            throw x10.runtime.impl.java.ThrowableUtils.ensureX10Exception(exc$206403);
        }
        
    }
    
    
    
    //#line 396 "x10/lang/Math.x10"
    public static double erf$O(final double a) {
        try {
            return org.apache.commons.math3.special.Erf.erf(a);
        }
        catch (java.lang.Throwable exc$206404) {
            throw x10.runtime.impl.java.ThrowableUtils.ensureX10Exception(exc$206404);
        }
        
    }
    
    
    
    //#line 401 "x10/lang/Math.x10"
    public static double erfc$O(final double a) {
        try {
            return org.apache.commons.math3.special.Erf.erfc(a);
        }
        catch (java.lang.Throwable exc$206405) {
            throw x10.runtime.impl.java.ThrowableUtils.ensureX10Exception(exc$206405);
        }
        
    }
    
    
    
    //#line 406 "x10/lang/Math.x10"
    public static double hypot$O(final double a, final double b) {
        try {
            return java.lang.Math.hypot(a,b);
        }
        catch (java.lang.Throwable exc$206406) {
            throw x10.runtime.impl.java.ThrowableUtils.ensureX10Exception(exc$206406);
        }
        
    }
    
    
    
    //#line 411 "x10/lang/Math.x10"
    public static double IEEEremainder$O(final double a, final double b) {
        try {
            return java.lang.Math.IEEEremainder(a,b);
        }
        catch (java.lang.Throwable exc$206407) {
            throw x10.runtime.impl.java.ThrowableUtils.ensureX10Exception(exc$206407);
        }
        
    }
    
    
    
    //#line 416 "x10/lang/Math.x10"
    public static double log$O(final double a) {
        try {
            return java.lang.Math.log(a);
        }
        catch (java.lang.Throwable exc$206408) {
            throw x10.runtime.impl.java.ThrowableUtils.ensureX10Exception(exc$206408);
        }
        
    }
    
    
    
    //#line 421 "x10/lang/Math.x10"
    public static float log$O(final float a) {
        try {
            return (float)java.lang.Math.log(a);
        }
        catch (java.lang.Throwable exc$206409) {
            throw x10.runtime.impl.java.ThrowableUtils.ensureX10Exception(exc$206409);
        }
        
    }
    
    
    
    //#line 426 "x10/lang/Math.x10"
    public static double log$O(final int a) {
        
        //#line 426 "x10/lang/Math.x10"
        final double t$134247 = ((double)(int)(((int)(a))));
        
        //#line 426 "x10/lang/Math.x10"
        final double t$134248 = java.lang.Math.log(((double)(t$134247)));
        
        //#line 426 "x10/lang/Math.x10"
        return t$134248;
    }
    
    
    //#line 427 "x10/lang/Math.x10"
    public static double log$O(final long a) {
        
        //#line 427 "x10/lang/Math.x10"
        final double t$134249 = ((double)(long)(((long)(a))));
        
        //#line 427 "x10/lang/Math.x10"
        final double t$134250 = java.lang.Math.log(((double)(t$134249)));
        
        //#line 427 "x10/lang/Math.x10"
        return t$134250;
    }
    
    
    //#line 432 "x10/lang/Math.x10"
    /**
     * @deprecated use {@link #log(Float)} instead
     */
    public static float logf$O(final float a) {
        try {
            return (float)java.lang.Math.log(a);
        }
        catch (java.lang.Throwable exc$206410) {
            throw x10.runtime.impl.java.ThrowableUtils.ensureX10Exception(exc$206410);
        }
        
    }
    
    
    
    //#line 443 "x10/lang/Math.x10"
    /**
     * Returns the principal value of the natural logarithm of <code>z</code>.
     * The branch cut is on the real line at (-inf, 0]
     * @return the natural logarithm of <code>a</code>
     * @see http://mathworld.wolfram.com/NaturalLogarithm.html
     */
    public static x10.lang.Complex log(final x10.lang.Complex a) {
        
        //#line 445 "x10/lang/Math.x10"
        final boolean t$134252 = a.isNaN$O();
        
        //#line 445 "x10/lang/Math.x10"
        if (t$134252) {
            
            //#line 446 "x10/lang/Math.x10"
            final x10.lang.Complex t$134251 = ((x10.lang.Complex)(x10.lang.Complex.get$NaN()));
            
            //#line 446 "x10/lang/Math.x10"
            return t$134251;
        }
        
        //#line 448 "x10/lang/Math.x10"
        final double t$134253 = a.abs$O();
        
        //#line 448 "x10/lang/Math.x10"
        final double t$134256 = java.lang.Math.log(((double)(t$134253)));
        
        //#line 448 "x10/lang/Math.x10"
        final double t$134254 = a.im;
        
        //#line 448 "x10/lang/Math.x10"
        final double t$134255 = a.re;
        
        //#line 448 "x10/lang/Math.x10"
        final double t$134257 = java.lang.Math.atan2(((double)(t$134254)),((double)(t$134255)));
        
        //#line 448 "x10/lang/Math.x10"
        final x10.lang.Complex t$134258 = new x10.lang.Complex(t$134256, t$134257);
        
        //#line 448 "x10/lang/Math.x10"
        return t$134258;
    }
    
    
    //#line 451 "x10/lang/Math.x10"
    public static double log10$O(final double a) {
        try {
            return java.lang.Math.log10(a);
        }
        catch (java.lang.Throwable exc$206411) {
            throw x10.runtime.impl.java.ThrowableUtils.ensureX10Exception(exc$206411);
        }
        
    }
    
    
    
    //#line 456 "x10/lang/Math.x10"
    public static double log1p$O(final double a) {
        try {
            return java.lang.Math.log1p(a);
        }
        catch (java.lang.Throwable exc$206412) {
            throw x10.runtime.impl.java.ThrowableUtils.ensureX10Exception(exc$206412);
        }
        
    }
    
    
    
    //#line 461 "x10/lang/Math.x10"
    public static int max$O(final int a, final int b) {
        try {
            return java.lang.Math.max(a,b);
        }
        catch (java.lang.Throwable exc$206413) {
            throw x10.runtime.impl.java.ThrowableUtils.ensureX10Exception(exc$206413);
        }
        
    }
    
    
    
    //#line 465 "x10/lang/Math.x10"
    public static int min$O(final int a, final int b) {
        try {
            return java.lang.Math.min(a,b);
        }
        catch (java.lang.Throwable exc$206414) {
            throw x10.runtime.impl.java.ThrowableUtils.ensureX10Exception(exc$206414);
        }
        
    }
    
    
    
    //#line 469 "x10/lang/Math.x10"
    public static int max__0$u__1$u$O(final int a, final int b) {
        
        //#line 470 "x10/lang/Math.x10"
        final boolean t$134265 = x10.runtime.impl.java.UIntUtils.lt(a, ((int)(b)));
        
        //#line 470 "x10/lang/Math.x10"
        int t$134266 =  0;
        
        //#line 470 "x10/lang/Math.x10"
        if (t$134265) {
            
            //#line 470 "x10/lang/Math.x10"
            t$134266 = b;
        } else {
            
            //#line 470 "x10/lang/Math.x10"
            t$134266 = a;
        }
        
        //#line 470 "x10/lang/Math.x10"
        return t$134266;
    }
    
    
    //#line 472 "x10/lang/Math.x10"
    public static int min__0$u__1$u$O(final int a, final int b) {
        
        //#line 473 "x10/lang/Math.x10"
        final boolean t$134268 = x10.runtime.impl.java.UIntUtils.lt(a, ((int)(b)));
        
        //#line 473 "x10/lang/Math.x10"
        int t$134269 =  0;
        
        //#line 473 "x10/lang/Math.x10"
        if (t$134268) {
            
            //#line 473 "x10/lang/Math.x10"
            t$134269 = a;
        } else {
            
            //#line 473 "x10/lang/Math.x10"
            t$134269 = b;
        }
        
        //#line 473 "x10/lang/Math.x10"
        return t$134269;
    }
    
    
    //#line 475 "x10/lang/Math.x10"
    public static long max$O(final long a, final long b) {
        try {
            return java.lang.Math.max(a,b);
        }
        catch (java.lang.Throwable exc$206415) {
            throw x10.runtime.impl.java.ThrowableUtils.ensureX10Exception(exc$206415);
        }
        
    }
    
    
    
    //#line 479 "x10/lang/Math.x10"
    public static long min$O(final long a, final long b) {
        try {
            return java.lang.Math.min(a,b);
        }
        catch (java.lang.Throwable exc$206416) {
            throw x10.runtime.impl.java.ThrowableUtils.ensureX10Exception(exc$206416);
        }
        
    }
    
    
    
    //#line 483 "x10/lang/Math.x10"
    public static long max__0$u__1$u$O(final long a, final long b) {
        
        //#line 484 "x10/lang/Math.x10"
        final boolean t$134277 = x10.runtime.impl.java.ULongUtils.lt(a, ((long)(b)));
        
        //#line 484 "x10/lang/Math.x10"
        long t$134278 =  0;
        
        //#line 484 "x10/lang/Math.x10"
        if (t$134277) {
            
            //#line 484 "x10/lang/Math.x10"
            t$134278 = b;
        } else {
            
            //#line 484 "x10/lang/Math.x10"
            t$134278 = a;
        }
        
        //#line 484 "x10/lang/Math.x10"
        return t$134278;
    }
    
    
    //#line 486 "x10/lang/Math.x10"
    public static long min__0$u__1$u$O(final long a, final long b) {
        
        //#line 487 "x10/lang/Math.x10"
        final boolean t$134280 = x10.runtime.impl.java.ULongUtils.lt(a, ((long)(b)));
        
        //#line 487 "x10/lang/Math.x10"
        long t$134281 =  0;
        
        //#line 487 "x10/lang/Math.x10"
        if (t$134280) {
            
            //#line 487 "x10/lang/Math.x10"
            t$134281 = a;
        } else {
            
            //#line 487 "x10/lang/Math.x10"
            t$134281 = b;
        }
        
        //#line 487 "x10/lang/Math.x10"
        return t$134281;
    }
    
    
    //#line 489 "x10/lang/Math.x10"
    public static float max$O(final float a, final float b) {
        try {
            return java.lang.Math.max(a,b);
        }
        catch (java.lang.Throwable exc$206417) {
            throw x10.runtime.impl.java.ThrowableUtils.ensureX10Exception(exc$206417);
        }
        
    }
    
    
    
    //#line 494 "x10/lang/Math.x10"
    public static float min$O(final float a, final float b) {
        try {
            return java.lang.Math.min(a,b);
        }
        catch (java.lang.Throwable exc$206418) {
            throw x10.runtime.impl.java.ThrowableUtils.ensureX10Exception(exc$206418);
        }
        
    }
    
    
    
    //#line 499 "x10/lang/Math.x10"
    public static double max$O(final double a, final double b) {
        try {
            return java.lang.Math.max(a,b);
        }
        catch (java.lang.Throwable exc$206419) {
            throw x10.runtime.impl.java.ThrowableUtils.ensureX10Exception(exc$206419);
        }
        
    }
    
    
    
    //#line 504 "x10/lang/Math.x10"
    public static double min$O(final double a, final double b) {
        try {
            return java.lang.Math.min(a,b);
        }
        catch (java.lang.Throwable exc$206420) {
            throw x10.runtime.impl.java.ThrowableUtils.ensureX10Exception(exc$206420);
        }
        
    }
    
    
    
    //#line 509 "x10/lang/Math.x10"
    public static int signum$O(final int a) {
        
        //#line 509 "x10/lang/Math.x10"
        final boolean t$134285 = ((int) a) == ((int) 0);
        
        //#line 509 "x10/lang/Math.x10"
        int t$134286 =  0;
        
        //#line 509 "x10/lang/Math.x10"
        if (t$134285) {
            
            //#line 509 "x10/lang/Math.x10"
            t$134286 = 0;
        } else {
            
            //#line 509 "x10/lang/Math.x10"
            final boolean t$134283 = ((a) > (((int)(0))));
            
            //#line 509 "x10/lang/Math.x10"
            int t$134284 =  0;
            
            //#line 509 "x10/lang/Math.x10"
            if (t$134283) {
                
                //#line 509 "x10/lang/Math.x10"
                t$134284 = 1;
            } else {
                
                //#line 509 "x10/lang/Math.x10"
                t$134284 = -1;
            }
            
            //#line 509 "x10/lang/Math.x10"
            t$134286 = t$134284;
        }
        
        //#line 509 "x10/lang/Math.x10"
        return t$134286;
    }
    
    
    //#line 510 "x10/lang/Math.x10"
    public static long signum$O(final long a) {
        
        //#line 510 "x10/lang/Math.x10"
        final boolean t$134290 = ((long) a) == ((long) 0L);
        
        //#line 510 "x10/lang/Math.x10"
        long t$134291 =  0;
        
        //#line 510 "x10/lang/Math.x10"
        if (t$134290) {
            
            //#line 510 "x10/lang/Math.x10"
            t$134291 = 0L;
        } else {
            
            //#line 510 "x10/lang/Math.x10"
            final boolean t$134288 = ((a) > (((long)(0L))));
            
            //#line 510 "x10/lang/Math.x10"
            long t$134289 =  0;
            
            //#line 510 "x10/lang/Math.x10"
            if (t$134288) {
                
                //#line 510 "x10/lang/Math.x10"
                t$134289 = 1L;
            } else {
                
                //#line 510 "x10/lang/Math.x10"
                t$134289 = -1L;
            }
            
            //#line 510 "x10/lang/Math.x10"
            t$134291 = t$134289;
        }
        
        //#line 510 "x10/lang/Math.x10"
        return t$134291;
    }
    
    
    //#line 512 "x10/lang/Math.x10"
    public static float signum$O(final float a) {
        try {
            return java.lang.Math.signum(a);
        }
        catch (java.lang.Throwable exc$206421) {
            throw x10.runtime.impl.java.ThrowableUtils.ensureX10Exception(exc$206421);
        }
        
    }
    
    
    
    //#line 515 "x10/lang/Math.x10"
    public static double signum$O(final double a) {
        try {
            return java.lang.Math.signum(a);
        }
        catch (java.lang.Throwable exc$206422) {
            throw x10.runtime.impl.java.ThrowableUtils.ensureX10Exception(exc$206422);
        }
        
    }
    
    
    
    //#line 521 "x10/lang/Math.x10"
    /**
     * @return the value of a with the sign of b
     */
    public static double copySign$O(final double a, final double b) {
        try {
            return java.lang.Math.copySign(a,b);
        }
        catch (java.lang.Throwable exc$206423) {
            throw x10.runtime.impl.java.ThrowableUtils.ensureX10Exception(exc$206423);
        }
        
    }
    
    
    
    //#line 529 "x10/lang/Math.x10"
    /**
     * @return the value of a with the sign of b
     */
    public static float copySign$O(final float a, final float b) {
        try {
            return java.lang.Math.copySign(a,b);
        }
        catch (java.lang.Throwable exc$206424) {
            throw x10.runtime.impl.java.ThrowableUtils.ensureX10Exception(exc$206424);
        }
        
    }
    
    
    
    //#line 534 "x10/lang/Math.x10"
    public static double nextAfter$O(final double a, final double b) {
        try {
            return java.lang.Math.nextAfter(a,b);
        }
        catch (java.lang.Throwable exc$206425) {
            throw x10.runtime.impl.java.ThrowableUtils.ensureX10Exception(exc$206425);
        }
        
    }
    
    
    
    //#line 539 "x10/lang/Math.x10"
    public static float nextAfter$O(final float a, final float b) {
        try {
            return java.lang.Math.nextAfter(a,b);
        }
        catch (java.lang.Throwable exc$206426) {
            throw x10.runtime.impl.java.ThrowableUtils.ensureX10Exception(exc$206426);
        }
        
    }
    
    
    
    //#line 544 "x10/lang/Math.x10"
    public static int nextPowerOf2$O(final int p) {
        
        //#line 545 "x10/lang/Math.x10"
        final boolean t$134303 = ((int) p) == ((int) 0);
        
        //#line 545 "x10/lang/Math.x10"
        if (t$134303) {
            
            //#line 545 "x10/lang/Math.x10"
            return 0;
        }
        
        //#line 546 "x10/lang/Math.x10"
        int pow2 = 1;
        
        //#line 547 "x10/lang/Math.x10"
        while (true) {
            
            //#line 547 "x10/lang/Math.x10"
            final boolean t$134308 = ((pow2) < (((int)(p))));
            
            //#line 547 "x10/lang/Math.x10"
            if (!(t$134308)) {
                
                //#line 547 "x10/lang/Math.x10"
                break;
            }
            
            //#line 548 "x10/lang/Math.x10"
            final long t$134343 = ((long)(((int)(1))));
            
            //#line 548 "x10/lang/Math.x10"
            final int t$134344 = ((pow2) << (int)(((long)(t$134343))));
            
            //#line 548 "x10/lang/Math.x10"
            pow2 = t$134344;
        }
        
        //#line 549 "x10/lang/Math.x10"
        return pow2;
    }
    
    
    //#line 552 "x10/lang/Math.x10"
    public static long nextPowerOf2$O(final long p) {
        
        //#line 553 "x10/lang/Math.x10"
        final boolean t$134310 = ((long) p) == ((long) 0L);
        
        //#line 553 "x10/lang/Math.x10"
        if (t$134310) {
            
            //#line 553 "x10/lang/Math.x10"
            return 0L;
        }
        
        //#line 554 "x10/lang/Math.x10"
        long pow2 = 1L;
        
        //#line 555 "x10/lang/Math.x10"
        while (true) {
            
            //#line 555 "x10/lang/Math.x10"
            final boolean t$134315 = ((pow2) < (((long)(p))));
            
            //#line 555 "x10/lang/Math.x10"
            if (!(t$134315)) {
                
                //#line 555 "x10/lang/Math.x10"
                break;
            }
            
            //#line 556 "x10/lang/Math.x10"
            final long t$134346 = ((long)(((int)(1))));
            
            //#line 556 "x10/lang/Math.x10"
            final long t$134347 = ((pow2) << (int)(((long)(t$134346))));
            
            //#line 556 "x10/lang/Math.x10"
            pow2 = t$134347;
        }
        
        //#line 557 "x10/lang/Math.x10"
        return pow2;
    }
    
    
    //#line 560 "x10/lang/Math.x10"
    public static boolean powerOf2$O(final int p) {
        
        //#line 560 "x10/lang/Math.x10"
        final int t$134317 = (-(p));
        
        //#line 560 "x10/lang/Math.x10"
        final int t$134318 = ((p) & (((int)(t$134317))));
        
        //#line 560 "x10/lang/Math.x10"
        final boolean t$134319 = ((int) t$134318) == ((int) p);
        
        //#line 560 "x10/lang/Math.x10"
        return t$134319;
    }
    
    
    //#line 561 "x10/lang/Math.x10"
    public static boolean powerOf2$O(final long p) {
        
        //#line 561 "x10/lang/Math.x10"
        final long t$134320 = (-(p));
        
        //#line 561 "x10/lang/Math.x10"
        final long t$134321 = ((p) & (((long)(t$134320))));
        
        //#line 561 "x10/lang/Math.x10"
        final boolean t$134322 = ((long) t$134321) == ((long) p);
        
        //#line 561 "x10/lang/Math.x10"
        return t$134322;
    }
    
    
    //#line 563 "x10/lang/Math.x10"
    public static int log2$O(int p) {
        
        //#line 564 "x10/lang/Math.x10"
        assert x10.lang.Math.powerOf2$O((int)(p));
        
        //#line 565 "x10/lang/Math.x10"
        int i = 0;
        
        //#line 566 "x10/lang/Math.x10"
        while (true) {
            
            //#line 566 "x10/lang/Math.x10"
            final boolean t$134328 = ((p) > (((int)(1))));
            
            //#line 566 "x10/lang/Math.x10"
            if (!(t$134328)) {
                
                //#line 566 "x10/lang/Math.x10"
                break;
            }
            
            //#line 566 "x10/lang/Math.x10"
            final int t$134349 = ((p) / (((int)(2))));
            
            //#line 566 "x10/lang/Math.x10"
            p = t$134349;
            
            //#line 566 "x10/lang/Math.x10"
            final int t$134351 = ((i) + (((int)(1))));
            
            //#line 566 "x10/lang/Math.x10"
            i = t$134351;
        }
        
        //#line 567 "x10/lang/Math.x10"
        return i;
    }
    
    
    //#line 570 "x10/lang/Math.x10"
    public static long log2$O(long p) {
        
        //#line 571 "x10/lang/Math.x10"
        assert x10.lang.Math.powerOf2$O((long)(p));
        
        //#line 572 "x10/lang/Math.x10"
        long i = 0L;
        
        //#line 573 "x10/lang/Math.x10"
        while (true) {
            
            //#line 573 "x10/lang/Math.x10"
            final boolean t$134335 = ((p) > (((long)(1L))));
            
            //#line 573 "x10/lang/Math.x10"
            if (!(t$134335)) {
                
                //#line 573 "x10/lang/Math.x10"
                break;
            }
            
            //#line 573 "x10/lang/Math.x10"
            final long t$134353 = ((p) / (((long)(2L))));
            
            //#line 573 "x10/lang/Math.x10"
            p = t$134353;
            
            //#line 573 "x10/lang/Math.x10"
            final long t$134355 = ((i) + (((long)(1L))));
            
            //#line 573 "x10/lang/Math.x10"
            i = t$134355;
        }
        
        //#line 574 "x10/lang/Math.x10"
        return i;
    }
    
    
    //#line 578 "x10/lang/Math.x10"
    public static int pow2$O(final int i) {
        
        //#line 579 "x10/lang/Math.x10"
        final long t$134337 = ((long)(((int)(i))));
        
        //#line 579 "x10/lang/Math.x10"
        final int t$134338 = ((1) << (int)(((long)(t$134337))));
        
        //#line 579 "x10/lang/Math.x10"
        return t$134338;
    }
    
    
    //#line 583 "x10/lang/Math.x10"
    public static long pow2$O(final long i) {
        
        //#line 584 "x10/lang/Math.x10"
        final int t$134339 = ((int)(long)(((long)(i))));
        
        //#line 584 "x10/lang/Math.x10"
        final long t$134340 = ((long)(((int)(t$134339))));
        
        //#line 584 "x10/lang/Math.x10"
        final long t$134341 = ((1L) << (int)(((long)(t$134340))));
        
        //#line 584 "x10/lang/Math.x10"
        return t$134341;
    }
    
    
    //#line 18 "x10/lang/Math.x10"
    final public x10.lang.Math x10$lang$Math$$this$x10$lang$Math() {
        
        //#line 18 "x10/lang/Math.x10"
        return x10.lang.Math.this;
    }
    
    
    //#line 19 "x10/lang/Math.x10"
    // creation method for java code (1-phase java constructor)
    public Math() {
        this((java.lang.System[]) null);
        x10$lang$Math$$init$S();
    }
    
    // constructor for non-virtual call
    final public x10.lang.Math x10$lang$Math$$init$S() {
         {
            
            //#line 19 "x10/lang/Math.x10"
            
        }
        return this;
    }
    
    
    
    //#line 18 "x10/lang/Math.x10"
    final public void __fieldInitializers_x10_lang_Math() {
        
    }
    
    public static double get$E() {
        return x10.lang.Math.E;
    }
    
    public static double get$PI() {
        return x10.lang.Math.PI;
    }
}

