package x10.lang;


/**
 * An AssertionError is a subclass of Error that indicates a failure of assertion.
 */
;

