package x10.lang;


@x10.runtime.impl.java.X10Generated
public interface Indexable<$I, $V> extends x10.core.fun.Fun_0_1, x10.serialization.X10JavaSerializable
{
    public static final x10.rtt.RuntimeType<Indexable> $RTT = 
        x10.rtt.NamedType.<Indexable> make("x10.lang.Indexable",
                                           Indexable.class,
                                           2,
                                           new x10.rtt.Type[] {
                                               x10.rtt.ParameterizedType.make(x10.core.fun.Fun_0_1.$RTT, x10.rtt.UnresolvedType.PARAM(0), x10.rtt.UnresolvedType.PARAM(1))
                                           });
    
    
}

