package x10.lang;

/**
 * Thrown to indicate that a clock was used incorrectly.  For example, attempting to operate
 * on a dropped clock throws an instance of this class.
 */
@x10.runtime.impl.java.X10Generated
public class ClockUseException extends java.lang.RuntimeException implements x10.serialization.X10JavaSerializable
{
    public static final x10.rtt.RuntimeType<ClockUseException> $RTT = 
        x10.rtt.NamedType.<ClockUseException> make("x10.lang.ClockUseException",
                                                   ClockUseException.class,
                                                   new x10.rtt.Type[] {
                                                       x10.rtt.Types.EXCEPTION
                                                   });
    
    public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
    
    public x10.rtt.Type<?> $getParam(int i) { return null; }
    
    private Object writeReplace() throws java.io.ObjectStreamException {
        return new x10.serialization.SerializationProxy(this);
    }
    
    public static x10.serialization.X10JavaSerializable $_deserialize_body(x10.lang.ClockUseException $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
        $deserializer.deserializeFieldsStartingFromClass(java.lang.RuntimeException.class, $_obj, 0);
        return $_obj;
    }
    
    public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
        x10.lang.ClockUseException $_obj = new x10.lang.ClockUseException((java.lang.System[]) null);
        $deserializer.record_reference($_obj);
        return $_deserialize_body($_obj, $deserializer);
    }
    
    public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
        $serializer.serializeFieldsStartingFromClass(this, java.lang.RuntimeException.class);
        
    }
    
    // constructor just for allocation
    public ClockUseException(final java.lang.System[] $dummy) {
        
    }
    
    

    
    
    //#line 23 "x10/lang/ClockUseException.x10"
    /**
     * Construct a ClockUseException with the default detail message.
     */
    public ClockUseException() {
        super(((java.lang.String)("clock use exception")));
         {
            
            //#line 23 "x10/lang/ClockUseException.x10"
            
            
            //#line 18 "x10/lang/ClockUseException.x10"
            this.__fieldInitializers_x10_lang_ClockUseException();
        }
    }
    
    
    
    //#line 30 "x10/lang/ClockUseException.x10"
    /**
     * Construct a ClockUseException with the specified detail message.
     *
     * @param message the detail message
     */
    public ClockUseException(final java.lang.String message) {
        super(((java.lang.String)(message)));
         {
            
            //#line 30 "x10/lang/ClockUseException.x10"
            
            
            //#line 18 "x10/lang/ClockUseException.x10"
            this.__fieldInitializers_x10_lang_ClockUseException();
        }
    }
    
    
    
    //#line 18 "x10/lang/ClockUseException.x10"
    final public x10.lang.ClockUseException x10$lang$ClockUseException$$this$x10$lang$ClockUseException() {
        
        //#line 18 "x10/lang/ClockUseException.x10"
        return x10.lang.ClockUseException.this;
    }
    
    
    //#line 18 "x10/lang/ClockUseException.x10"
    final public void __fieldInitializers_x10_lang_ClockUseException() {
        
    }
}

