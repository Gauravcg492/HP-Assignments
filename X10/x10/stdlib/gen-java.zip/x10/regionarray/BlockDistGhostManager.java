package x10.regionarray;

/**
 * A BlockDistGhostManager manages the local ghost region for a Ghostable
 * array that is distributed using a BlockDist.
 */
@x10.runtime.impl.java.X10Generated
final public class BlockDistGhostManager extends x10.regionarray.GhostManager implements x10.serialization.X10JavaSerializable
{
    public static final x10.rtt.RuntimeType<BlockDistGhostManager> $RTT = 
        x10.rtt.NamedType.<BlockDistGhostManager> make("x10.regionarray.BlockDistGhostManager",
                                                       BlockDistGhostManager.class,
                                                       new x10.rtt.Type[] {
                                                           x10.regionarray.GhostManager.$RTT
                                                       });
    
    public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
    
    public x10.rtt.Type<?> $getParam(int i) { return null; }
    
    private Object writeReplace() throws java.io.ObjectStreamException {
        return new x10.serialization.SerializationProxy(this);
    }
    
    public static x10.serialization.X10JavaSerializable $_deserialize_body(x10.regionarray.BlockDistGhostManager $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
        x10.regionarray.GhostManager.$_deserialize_body($_obj, $deserializer);
        $_obj.bd = $deserializer.readObject();
        $_obj.leftNeighbor = $deserializer.readObject();
        $_obj.periodic = $deserializer.readBoolean();
        $_obj.rightNeighbor = $deserializer.readObject();
        return $_obj;
    }
    
    public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
        x10.regionarray.BlockDistGhostManager $_obj = new x10.regionarray.BlockDistGhostManager((java.lang.System[]) null);
        $deserializer.record_reference($_obj);
        return $_deserialize_body($_obj, $deserializer);
    }
    
    public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
        super.$_serialize($serializer);
        $serializer.write(this.bd);
        $serializer.write(this.leftNeighbor);
        $serializer.write(this.periodic);
        $serializer.write(this.rightNeighbor);
        
    }
    
    // constructor just for allocation
    public BlockDistGhostManager(final java.lang.System[] $dummy) {
        super($dummy);
        
    }
    
    

    
    //#line 19 "x10/regionarray/BlockDistGhostManager.x10"
    public x10.regionarray.BlockDist bd;
    
    //#line 20 "x10/regionarray/BlockDistGhostManager.x10"
    public x10.regionarray.GhostManager.GhostNeighborFlag leftNeighbor;
    
    //#line 21 "x10/regionarray/BlockDistGhostManager.x10"
    public x10.regionarray.GhostManager.GhostNeighborFlag rightNeighbor;
    
    //#line 22 "x10/regionarray/BlockDistGhostManager.x10"
    public boolean periodic;
    
    
    //#line 24 "x10/regionarray/BlockDistGhostManager.x10"
    // creation method for java code (1-phase java constructor)
    public BlockDistGhostManager(final long ghostWidth, final x10.regionarray.BlockDist bd, final boolean periodic) {
        this((java.lang.System[]) null);
        x10$regionarray$BlockDistGhostManager$$init$S(ghostWidth, bd, periodic);
    }
    
    // constructor for non-virtual call
    final public x10.regionarray.BlockDistGhostManager x10$regionarray$BlockDistGhostManager$$init$S(final long ghostWidth, final x10.regionarray.BlockDist bd, final boolean periodic) {
         {
            
            //#line 25 "x10/regionarray/BlockDistGhostManager.x10"
            final x10.regionarray.GhostManager this$148925 = this;
            
            //#line 22 .. "x10/regionarray/GhostManager.x10"
            this$148925.currentPhase = ((byte) 0);
            
            //#line 38 . "x10/regionarray/GhostManager.x10"
            this$148925.ghostWidth = ghostWidth;
            
            //#line 39 . "x10/regionarray/GhostManager.x10"
            this$148925.currentPhase = ((byte) 0);
            
            //#line 24 "x10/regionarray/BlockDistGhostManager.x10"
            
            
            //#line 26 "x10/regionarray/BlockDistGhostManager.x10"
            this.bd = ((x10.regionarray.BlockDist)(bd));
            
            //#line 28 "x10/regionarray/BlockDistGhostManager.x10"
            final x10.lang.PlaceGroup pg = bd.pg;
            
            //#line 30 "x10/regionarray/BlockDistGhostManager.x10"
            final long i = pg.indexOf$O(((x10.lang.Place)(x10.x10rt.X10RT.here())));
            
            //#line 31 "x10/regionarray/BlockDistGhostManager.x10"
            final x10.lang.Place left;
            
            //#line 32 "x10/regionarray/BlockDistGhostManager.x10"
            x10.lang.Point leftShift =  null;
            
            //#line 33 "x10/regionarray/BlockDistGhostManager.x10"
            final boolean t$148986 = ((i) > (((long)(0L))));
            
            //#line 33 "x10/regionarray/BlockDistGhostManager.x10"
            if (t$148986) {
                
                //#line 34 "x10/regionarray/BlockDistGhostManager.x10"
                final long t$148957 = ((i) - (((long)(1L))));
                
                //#line 34 "x10/regionarray/BlockDistGhostManager.x10"
                final x10.lang.Place t$148958 = pg.$apply((long)(t$148957));
                
                //#line 34 "x10/regionarray/BlockDistGhostManager.x10"
                left = ((x10.lang.Place)(t$148958));
                
                //#line 38 . "x10/regionarray/Dist.x10"
                final x10.regionarray.Region t$148959 = ((x10.regionarray.Region)(bd.region));
                
                //#line 38 . "x10/regionarray/Dist.x10"
                final long t$148960 = t$148959.rank;
                
                //#line 35 "x10/regionarray/BlockDistGhostManager.x10"
                final x10.core.fun.Fun_0_1 t$148961 = ((x10.core.fun.Fun_0_1)(new x10.regionarray.BlockDistGhostManager.$Closure$211()));
                
                //#line 35 "x10/regionarray/BlockDistGhostManager.x10"
                final x10.lang.Point t$148962 = ((x10.lang.Point)(x10.lang.Point.make__1$1x10$lang$Long$3x10$lang$Long$2((long)(t$148960), ((x10.core.fun.Fun_0_1)(t$148961)))));
                
                //#line 35 "x10/regionarray/BlockDistGhostManager.x10"
                leftShift = ((x10.lang.Point)(t$148962));
            } else {
                
                //#line 36 "x10/regionarray/BlockDistGhostManager.x10"
                if (periodic) {
                    
                    //#line 35 . "x10/lang/PlaceGroup.x10"
                    final long t$148963 = pg.numPlaces$O();
                    
                    //#line 37 "x10/regionarray/BlockDistGhostManager.x10"
                    final long t$148964 = ((t$148963) - (((long)(1L))));
                    
                    //#line 37 "x10/regionarray/BlockDistGhostManager.x10"
                    final x10.lang.Place t$148965 = pg.$apply((long)(t$148964));
                    
                    //#line 37 "x10/regionarray/BlockDistGhostManager.x10"
                    left = ((x10.lang.Place)(t$148965));
                    
                    //#line 38 . "x10/regionarray/Dist.x10"
                    final x10.regionarray.Region t$148966 = ((x10.regionarray.Region)(bd.region));
                    
                    //#line 38 . "x10/regionarray/Dist.x10"
                    final long t$148979 = t$148966.rank;
                    
                    //#line 38 "x10/regionarray/BlockDistGhostManager.x10"
                    final x10.core.fun.Fun_0_1 t$148980 = ((x10.core.fun.Fun_0_1)(new x10.regionarray.BlockDistGhostManager.$Closure$212(bd)));
                    
                    //#line 38 "x10/regionarray/BlockDistGhostManager.x10"
                    final x10.lang.Point t$148981 = ((x10.lang.Point)(x10.lang.Point.make__1$1x10$lang$Long$3x10$lang$Long$2((long)(t$148979), ((x10.core.fun.Fun_0_1)(t$148980)))));
                    
                    //#line 38 "x10/regionarray/BlockDistGhostManager.x10"
                    leftShift = ((x10.lang.Point)(t$148981));
                } else {
                    
                    //#line 40 "x10/regionarray/BlockDistGhostManager.x10"
                    left = ((x10.lang.Place)(x10.x10rt.X10RT.here()));
                    
                    //#line 38 . "x10/regionarray/Dist.x10"
                    final x10.regionarray.Region t$148982 = ((x10.regionarray.Region)(bd.region));
                    
                    //#line 38 . "x10/regionarray/Dist.x10"
                    final long t$148983 = t$148982.rank;
                    
                    //#line 41 "x10/regionarray/BlockDistGhostManager.x10"
                    final x10.core.fun.Fun_0_1 t$148984 = ((x10.core.fun.Fun_0_1)(new x10.regionarray.BlockDistGhostManager.$Closure$213()));
                    
                    //#line 41 "x10/regionarray/BlockDistGhostManager.x10"
                    final x10.lang.Point t$148985 = ((x10.lang.Point)(x10.lang.Point.make__1$1x10$lang$Long$3x10$lang$Long$2((long)(t$148983), ((x10.core.fun.Fun_0_1)(t$148984)))));
                    
                    //#line 41 "x10/regionarray/BlockDistGhostManager.x10"
                    leftShift = ((x10.lang.Point)(t$148985));
                }
            }
            
            //#line 43 "x10/regionarray/BlockDistGhostManager.x10"
            final x10.regionarray.GhostManager.GhostNeighborFlag alloc$148749 = ((x10.regionarray.GhostManager.GhostNeighborFlag)(new x10.regionarray.GhostManager.GhostNeighborFlag((java.lang.System[]) null)));
            
            //#line 79 . "x10/regionarray/GhostManager.x10"
            alloc$148749.place = left;
            
            //#line 79 . "x10/regionarray/GhostManager.x10"
            alloc$148749.shift = leftShift;
            
            //#line 79 .. "x10/regionarray/GhostManager.x10"
            alloc$148749.received = false;
            
            //#line 43 "x10/regionarray/BlockDistGhostManager.x10"
            this.leftNeighbor = ((x10.regionarray.GhostManager.GhostNeighborFlag)(alloc$148749));
            
            //#line 45 "x10/regionarray/BlockDistGhostManager.x10"
            final x10.lang.Place right;
            
            //#line 46 "x10/regionarray/BlockDistGhostManager.x10"
            x10.lang.Point rightShift =  null;
            
            //#line 35 . "x10/lang/PlaceGroup.x10"
            final long t$148987 = pg.numPlaces$O();
            
            //#line 47 "x10/regionarray/BlockDistGhostManager.x10"
            final long t$148988 = ((t$148987) - (((long)(1L))));
            
            //#line 47 "x10/regionarray/BlockDistGhostManager.x10"
            final boolean t$149015 = ((i) < (((long)(t$148988))));
            
            //#line 47 "x10/regionarray/BlockDistGhostManager.x10"
            if (t$149015) {
                
                //#line 48 "x10/regionarray/BlockDistGhostManager.x10"
                final long t$148989 = ((i) + (((long)(1L))));
                
                //#line 48 "x10/regionarray/BlockDistGhostManager.x10"
                final x10.lang.Place t$148990 = pg.$apply((long)(t$148989));
                
                //#line 48 "x10/regionarray/BlockDistGhostManager.x10"
                right = ((x10.lang.Place)(t$148990));
                
                //#line 38 . "x10/regionarray/Dist.x10"
                final x10.regionarray.Region t$148991 = ((x10.regionarray.Region)(bd.region));
                
                //#line 38 . "x10/regionarray/Dist.x10"
                final long t$148992 = t$148991.rank;
                
                //#line 49 "x10/regionarray/BlockDistGhostManager.x10"
                final x10.core.fun.Fun_0_1 t$148993 = ((x10.core.fun.Fun_0_1)(new x10.regionarray.BlockDistGhostManager.$Closure$214()));
                
                //#line 49 "x10/regionarray/BlockDistGhostManager.x10"
                final x10.lang.Point t$148994 = ((x10.lang.Point)(x10.lang.Point.make__1$1x10$lang$Long$3x10$lang$Long$2((long)(t$148992), ((x10.core.fun.Fun_0_1)(t$148993)))));
                
                //#line 49 "x10/regionarray/BlockDistGhostManager.x10"
                rightShift = ((x10.lang.Point)(t$148994));
            } else {
                
                //#line 50 "x10/regionarray/BlockDistGhostManager.x10"
                if (periodic) {
                    
                    //#line 51 "x10/regionarray/BlockDistGhostManager.x10"
                    final x10.lang.Place t$148995 = pg.$apply((long)(0L));
                    
                    //#line 51 "x10/regionarray/BlockDistGhostManager.x10"
                    right = ((x10.lang.Place)(t$148995));
                    
                    //#line 38 . "x10/regionarray/Dist.x10"
                    final x10.regionarray.Region t$148996 = ((x10.regionarray.Region)(bd.region));
                    
                    //#line 38 . "x10/regionarray/Dist.x10"
                    final long t$149008 = t$148996.rank;
                    
                    //#line 52 "x10/regionarray/BlockDistGhostManager.x10"
                    final x10.core.fun.Fun_0_1 t$149009 = ((x10.core.fun.Fun_0_1)(new x10.regionarray.BlockDistGhostManager.$Closure$215(bd)));
                    
                    //#line 52 "x10/regionarray/BlockDistGhostManager.x10"
                    final x10.lang.Point t$149010 = ((x10.lang.Point)(x10.lang.Point.make__1$1x10$lang$Long$3x10$lang$Long$2((long)(t$149008), ((x10.core.fun.Fun_0_1)(t$149009)))));
                    
                    //#line 52 "x10/regionarray/BlockDistGhostManager.x10"
                    rightShift = ((x10.lang.Point)(t$149010));
                } else {
                    
                    //#line 54 "x10/regionarray/BlockDistGhostManager.x10"
                    right = ((x10.lang.Place)(x10.x10rt.X10RT.here()));
                    
                    //#line 38 . "x10/regionarray/Dist.x10"
                    final x10.regionarray.Region t$149011 = ((x10.regionarray.Region)(bd.region));
                    
                    //#line 38 . "x10/regionarray/Dist.x10"
                    final long t$149012 = t$149011.rank;
                    
                    //#line 55 "x10/regionarray/BlockDistGhostManager.x10"
                    final x10.core.fun.Fun_0_1 t$149013 = ((x10.core.fun.Fun_0_1)(new x10.regionarray.BlockDistGhostManager.$Closure$216()));
                    
                    //#line 55 "x10/regionarray/BlockDistGhostManager.x10"
                    final x10.lang.Point t$149014 = ((x10.lang.Point)(x10.lang.Point.make__1$1x10$lang$Long$3x10$lang$Long$2((long)(t$149012), ((x10.core.fun.Fun_0_1)(t$149013)))));
                    
                    //#line 55 "x10/regionarray/BlockDistGhostManager.x10"
                    rightShift = ((x10.lang.Point)(t$149014));
                }
            }
            
            //#line 57 "x10/regionarray/BlockDistGhostManager.x10"
            final x10.regionarray.GhostManager.GhostNeighborFlag alloc$148750 = ((x10.regionarray.GhostManager.GhostNeighborFlag)(new x10.regionarray.GhostManager.GhostNeighborFlag((java.lang.System[]) null)));
            
            //#line 79 . "x10/regionarray/GhostManager.x10"
            alloc$148750.place = right;
            
            //#line 79 . "x10/regionarray/GhostManager.x10"
            alloc$148750.shift = rightShift;
            
            //#line 79 .. "x10/regionarray/GhostManager.x10"
            alloc$148750.received = false;
            
            //#line 57 "x10/regionarray/BlockDistGhostManager.x10"
            this.rightNeighbor = ((x10.regionarray.GhostManager.GhostNeighborFlag)(alloc$148750));
            
            //#line 58 "x10/regionarray/BlockDistGhostManager.x10"
            this.periodic = periodic;
        }
        return this;
    }
    
    
    
    //#line 61 "x10/regionarray/BlockDistGhostManager.x10"
    public x10.core.Rail getNeighbors() {
        
        //#line 61 "x10/regionarray/BlockDistGhostManager.x10"
        final x10.regionarray.GhostManager.GhostNeighborFlag t$149016 = ((x10.regionarray.GhostManager.GhostNeighborFlag)(this.leftNeighbor));
        
        //#line 61 "x10/regionarray/BlockDistGhostManager.x10"
        final x10.lang.Place t$149018 = ((x10.lang.Place)(t$149016.place));
        
        //#line 61 "x10/regionarray/BlockDistGhostManager.x10"
        final x10.regionarray.GhostManager.GhostNeighborFlag t$149017 = ((x10.regionarray.GhostManager.GhostNeighborFlag)(this.rightNeighbor));
        
        //#line 61 "x10/regionarray/BlockDistGhostManager.x10"
        final x10.lang.Place t$149019 = ((x10.lang.Place)(t$149017.place));
        
        //#line 61 "x10/regionarray/BlockDistGhostManager.x10"
        final x10.core.Rail t$149020 = ((x10.core.Rail)(x10.runtime.impl.java.ArrayUtils.<x10.lang.Place> makeRailFromJavaArray(x10.lang.Place.$RTT, new x10.lang.Place[] {t$149018, t$149019})));
        
        //#line 61 "x10/regionarray/BlockDistGhostManager.x10"
        return t$149020;
    }
    
    
    //#line 72 "x10/regionarray/BlockDistGhostManager.x10"
    /**
     * Gets the ghost region for a given place, which is the bounding box 
     * for the region held at that place, expanded in each dimension by
     * <code>ghostWidth</code>.  For a periodic distribution, the ghost
     * region may extend beyond the limits of the entire region. For a 
     * non-periodic dist, the ghost region does not extend beyond the min/max
     * of the region in any dimension.
     * @return the ghost region for the given place
     */
    public x10.regionarray.Region getGhostRegion(final x10.lang.Place place) {
        
        //#line 73 "x10/regionarray/BlockDistGhostManager.x10"
        final x10.regionarray.BlockDist this$148948 = ((x10.regionarray.BlockDist)(this.bd));
        
        //#line 73 "x10/regionarray/BlockDistGhostManager.x10"
        final x10.regionarray.Region region = ((x10.regionarray.Region)(this$148948.get(((x10.lang.Place)(place)))));
        
        //#line 74 "x10/regionarray/BlockDistGhostManager.x10"
        final boolean t$149021 = region.isEmpty$O();
        
        //#line 74 "x10/regionarray/BlockDistGhostManager.x10"
        if (t$149021) {
            
            //#line 74 "x10/regionarray/BlockDistGhostManager.x10"
            return region;
        }
        
        //#line 76 "x10/regionarray/BlockDistGhostManager.x10"
        final x10.regionarray.Region r = ((x10.regionarray.Region)(region.boundingBox()));
        
        //#line 77 "x10/regionarray/BlockDistGhostManager.x10"
        final long t$149022 = r.rank;
        
        //#line 77 "x10/regionarray/BlockDistGhostManager.x10"
        final x10.core.Rail min = ((x10.core.Rail)(new x10.core.Rail<x10.core.Long>(x10.rtt.Types.LONG, ((long)(t$149022)))));
        
        //#line 78 "x10/regionarray/BlockDistGhostManager.x10"
        final long t$149023 = r.rank;
        
        //#line 78 "x10/regionarray/BlockDistGhostManager.x10"
        final x10.core.Rail max = ((x10.core.Rail)(new x10.core.Rail<x10.core.Long>(x10.rtt.Types.LONG, ((long)(t$149023)))));
        
        //#line 79 "x10/regionarray/BlockDistGhostManager.x10"
        final long t$149220 = r.rank;
        
        //#line 79 "x10/regionarray/BlockDistGhostManager.x10"
        final long i$148752max$149221 = ((t$149220) - (((long)(1L))));
        
        //#line 79 "x10/regionarray/BlockDistGhostManager.x10"
        long i$149217 = 0L;
        {
            
            //#line 79 "x10/regionarray/BlockDistGhostManager.x10"
            final long[] min$value$149222 = ((long[])min.value);
            
            //#line 79 "x10/regionarray/BlockDistGhostManager.x10"
            final long[] max$value$149223 = ((long[])max.value);
            
            //#line 79 "x10/regionarray/BlockDistGhostManager.x10"
            for (;
                 true;
                 ) {
                
                //#line 79 "x10/regionarray/BlockDistGhostManager.x10"
                final boolean t$149219 = ((i$149217) <= (((long)(i$148752max$149221))));
                
                //#line 79 "x10/regionarray/BlockDistGhostManager.x10"
                if (!(t$149219)) {
                    
                    //#line 79 "x10/regionarray/BlockDistGhostManager.x10"
                    break;
                }
                
                //#line 80 "x10/regionarray/BlockDistGhostManager.x10"
                final x10.regionarray.BlockDist t$149188 = ((x10.regionarray.BlockDist)(this.bd));
                
                //#line 80 "x10/regionarray/BlockDistGhostManager.x10"
                final long t$149189 = t$149188.axis;
                
                //#line 80 "x10/regionarray/BlockDistGhostManager.x10"
                final boolean t$149190 = ((long) i$149217) == ((long) t$149189);
                
                //#line 80 "x10/regionarray/BlockDistGhostManager.x10"
                if (t$149190) {
                    
                    //#line 81 "x10/regionarray/BlockDistGhostManager.x10"
                    final boolean t$149191 = this.periodic;
                    
                    //#line 81 "x10/regionarray/BlockDistGhostManager.x10"
                    if (t$149191) {
                        
                        //#line 82 "x10/regionarray/BlockDistGhostManager.x10"
                        final long t$149192 = r.min$O((long)(i$149217));
                        
                        //#line 82 "x10/regionarray/BlockDistGhostManager.x10"
                        final long t$149193 = this.ghostWidth;
                        
                        //#line 82 "x10/regionarray/BlockDistGhostManager.x10"
                        final long t$149194 = ((t$149192) - (((long)(t$149193))));
                        
                        //#line 82 "x10/regionarray/BlockDistGhostManager.x10"
                        min$value$149222[(int)i$149217]=t$149194;
                        
                        //#line 83 "x10/regionarray/BlockDistGhostManager.x10"
                        final long t$149195 = r.max$O((long)(i$149217));
                        
                        //#line 83 "x10/regionarray/BlockDistGhostManager.x10"
                        final long t$149196 = this.ghostWidth;
                        
                        //#line 83 "x10/regionarray/BlockDistGhostManager.x10"
                        final long t$149197 = ((t$149195) + (((long)(t$149196))));
                        
                        //#line 83 "x10/regionarray/BlockDistGhostManager.x10"
                        max$value$149223[(int)i$149217]=t$149197;
                    } else {
                        
                        //#line 85 "x10/regionarray/BlockDistGhostManager.x10"
                        final x10.regionarray.BlockDist t$149198 = ((x10.regionarray.BlockDist)(this.bd));
                        
                        //#line 85 "x10/regionarray/BlockDistGhostManager.x10"
                        final x10.regionarray.Region t$149199 = ((x10.regionarray.Region)(t$149198.region));
                        
                        //#line 85 "x10/regionarray/BlockDistGhostManager.x10"
                        final long t$149200 = t$149199.min$O((long)(i$149217));
                        
                        //#line 85 "x10/regionarray/BlockDistGhostManager.x10"
                        final long t$149201 = r.min$O((long)(i$149217));
                        
                        //#line 85 "x10/regionarray/BlockDistGhostManager.x10"
                        final long t$149202 = this.ghostWidth;
                        
                        //#line 85 "x10/regionarray/BlockDistGhostManager.x10"
                        final long t$149203 = ((t$149201) - (((long)(t$149202))));
                        
                        //#line 85 "x10/regionarray/BlockDistGhostManager.x10"
                        final long t$149204 = java.lang.Math.max(((long)(t$149200)),((long)(t$149203)));
                        
                        //#line 85 "x10/regionarray/BlockDistGhostManager.x10"
                        min$value$149222[(int)i$149217]=t$149204;
                        
                        //#line 86 "x10/regionarray/BlockDistGhostManager.x10"
                        final x10.regionarray.BlockDist t$149205 = ((x10.regionarray.BlockDist)(this.bd));
                        
                        //#line 86 "x10/regionarray/BlockDistGhostManager.x10"
                        final x10.regionarray.Region t$149206 = ((x10.regionarray.Region)(t$149205.region));
                        
                        //#line 86 "x10/regionarray/BlockDistGhostManager.x10"
                        final long t$149207 = t$149206.max$O((long)(i$149217));
                        
                        //#line 86 "x10/regionarray/BlockDistGhostManager.x10"
                        final long t$149208 = r.max$O((long)(i$149217));
                        
                        //#line 86 "x10/regionarray/BlockDistGhostManager.x10"
                        final long t$149209 = this.ghostWidth;
                        
                        //#line 86 "x10/regionarray/BlockDistGhostManager.x10"
                        final long t$149210 = ((t$149208) + (((long)(t$149209))));
                        
                        //#line 86 "x10/regionarray/BlockDistGhostManager.x10"
                        final long t$149211 = java.lang.Math.min(((long)(t$149207)),((long)(t$149210)));
                        
                        //#line 86 "x10/regionarray/BlockDistGhostManager.x10"
                        max$value$149223[(int)i$149217]=t$149211;
                    }
                } else {
                    
                    //#line 89 "x10/regionarray/BlockDistGhostManager.x10"
                    final long t$149212 = r.min$O((long)(i$149217));
                    
                    //#line 89 "x10/regionarray/BlockDistGhostManager.x10"
                    min$value$149222[(int)i$149217]=t$149212;
                    
                    //#line 90 "x10/regionarray/BlockDistGhostManager.x10"
                    final long t$149213 = r.max$O((long)(i$149217));
                    
                    //#line 90 "x10/regionarray/BlockDistGhostManager.x10"
                    max$value$149223[(int)i$149217]=t$149213;
                }
                
                //#line 79 "x10/regionarray/BlockDistGhostManager.x10"
                final long t$149216 = ((i$149217) + (((long)(1L))));
                
                //#line 79 "x10/regionarray/BlockDistGhostManager.x10"
                i$149217 = t$149216;
            }
        }
        
        //#line 93 "x10/regionarray/BlockDistGhostManager.x10"
        final x10.regionarray.Region t$149056 = ((x10.regionarray.Region)(x10.regionarray.Region.makeRectangular__0$1x10$lang$Long$2__1$1x10$lang$Long$2(((x10.core.Rail)(min)), ((x10.core.Rail)(max)))));
        
        //#line 93 "x10/regionarray/BlockDistGhostManager.x10"
        return t$149056;
    }
    
    
    //#line 96 "x10/regionarray/BlockDistGhostManager.x10"
    public long getInverseNeighborIndex$O(final long neighborIndex) {
        
        //#line 97 "x10/regionarray/BlockDistGhostManager.x10"
        final boolean t$149060 = ((long) neighborIndex) == ((long) 0L);
        
        //#line 97 "x10/regionarray/BlockDistGhostManager.x10"
        if (t$149060) {
            
            //#line 97 "x10/regionarray/BlockDistGhostManager.x10"
            return 1L;
        } else {
            
            //#line 98 "x10/regionarray/BlockDistGhostManager.x10"
            final boolean t$149059 = ((long) neighborIndex) == ((long) 1L);
            
            //#line 98 "x10/regionarray/BlockDistGhostManager.x10"
            if (t$149059) {
                
                //#line 98 "x10/regionarray/BlockDistGhostManager.x10"
                return 0L;
            } else {
                
                //#line 99 "x10/regionarray/BlockDistGhostManager.x10"
                final java.lang.String t$149057 = (("no inverse neighbor found for neighborIndex ") + ((x10.core.Long.$box(neighborIndex))));
                
                //#line 99 "x10/regionarray/BlockDistGhostManager.x10"
                final java.lang.UnsupportedOperationException t$149058 = ((java.lang.UnsupportedOperationException)(new java.lang.UnsupportedOperationException(t$149057)));
                
                //#line 99 "x10/regionarray/BlockDistGhostManager.x10"
                throw t$149058;
            }
        }
    }
    
    
    //#line 102 "x10/regionarray/BlockDistGhostManager.x10"
    public void setNeighborReceived(final x10.lang.Place place, final x10.lang.Point shift) {
        
        //#line 102 "x10/regionarray/BlockDistGhostManager.x10"
        try {{
            
            //#line 102 "x10/regionarray/BlockDistGhostManager.x10"
            x10.xrx.Runtime.enterAtomic();
            {
                
                //#line 103 "x10/regionarray/BlockDistGhostManager.x10"
                final x10.regionarray.GhostManager.GhostNeighborFlag t$149061 = ((x10.regionarray.GhostManager.GhostNeighborFlag)(this.leftNeighbor));
                
                //#line 103 "x10/regionarray/BlockDistGhostManager.x10"
                final x10.lang.Place t$149062 = ((x10.lang.Place)(t$149061.place));
                
                //#line 103 "x10/regionarray/BlockDistGhostManager.x10"
                boolean t$149065 = x10.rtt.Equality.equalsequals((t$149062),(place));
                
                //#line 103 "x10/regionarray/BlockDistGhostManager.x10"
                if (t$149065) {
                    
                    //#line 103 "x10/regionarray/BlockDistGhostManager.x10"
                    final x10.regionarray.GhostManager.GhostNeighborFlag t$149063 = ((x10.regionarray.GhostManager.GhostNeighborFlag)(this.leftNeighbor));
                    
                    //#line 103 "x10/regionarray/BlockDistGhostManager.x10"
                    final boolean t$149064 = t$149063.received;
                    
                    //#line 103 "x10/regionarray/BlockDistGhostManager.x10"
                    t$149065 = ((boolean) t$149064) == ((boolean) false);
                }
                
                //#line 103 "x10/regionarray/BlockDistGhostManager.x10"
                if (t$149065) {
                    
                    //#line 104 "x10/regionarray/BlockDistGhostManager.x10"
                    final x10.regionarray.GhostManager.GhostNeighborFlag t$149066 = ((x10.regionarray.GhostManager.GhostNeighborFlag)(this.leftNeighbor));
                    
                    //#line 104 "x10/regionarray/BlockDistGhostManager.x10"
                    t$149066.received = true;
                } else {
                    
                    //#line 105 "x10/regionarray/BlockDistGhostManager.x10"
                    final x10.regionarray.GhostManager.GhostNeighborFlag t$149067 = ((x10.regionarray.GhostManager.GhostNeighborFlag)(this.rightNeighbor));
                    
                    //#line 105 "x10/regionarray/BlockDistGhostManager.x10"
                    final x10.lang.Place t$149068 = ((x10.lang.Place)(t$149067.place));
                    
                    //#line 105 "x10/regionarray/BlockDistGhostManager.x10"
                    boolean t$149071 = x10.rtt.Equality.equalsequals((t$149068),(place));
                    
                    //#line 105 "x10/regionarray/BlockDistGhostManager.x10"
                    if (t$149071) {
                        
                        //#line 105 "x10/regionarray/BlockDistGhostManager.x10"
                        final x10.regionarray.GhostManager.GhostNeighborFlag t$149069 = ((x10.regionarray.GhostManager.GhostNeighborFlag)(this.rightNeighbor));
                        
                        //#line 105 "x10/regionarray/BlockDistGhostManager.x10"
                        final boolean t$149070 = t$149069.received;
                        
                        //#line 105 "x10/regionarray/BlockDistGhostManager.x10"
                        t$149071 = ((boolean) t$149070) == ((boolean) false);
                    }
                    
                    //#line 105 "x10/regionarray/BlockDistGhostManager.x10"
                    if (t$149071) {
                        
                        //#line 106 "x10/regionarray/BlockDistGhostManager.x10"
                        final x10.regionarray.GhostManager.GhostNeighborFlag t$149072 = ((x10.regionarray.GhostManager.GhostNeighborFlag)(this.rightNeighbor));
                        
                        //#line 106 "x10/regionarray/BlockDistGhostManager.x10"
                        t$149072.received = true;
                    } else {
                        
                        //#line 108 "x10/regionarray/BlockDistGhostManager.x10"
                        final java.lang.String t$149073 = ((x10.x10rt.X10RT.here()) + (" trying to notify received from neighbor "));
                        
                        //#line 108 "x10/regionarray/BlockDistGhostManager.x10"
                        final java.lang.String t$149074 = ((t$149073) + (place));
                        
                        //#line 108 "x10/regionarray/BlockDistGhostManager.x10"
                        final java.lang.String t$149075 = ((t$149074) + (" - not a neighbor or already received!"));
                        
                        //#line 108 "x10/regionarray/BlockDistGhostManager.x10"
                        final x10.lang.BadPlaceException t$149076 = ((x10.lang.BadPlaceException)(new x10.lang.BadPlaceException(t$149075)));
                        
                        //#line 108 "x10/regionarray/BlockDistGhostManager.x10"
                        throw t$149076;
                    }
                }
            }
        }}finally {{
              
              //#line 102 "x10/regionarray/BlockDistGhostManager.x10"
              x10.xrx.Runtime.exitAtomic();
          }}
        }
    
    
    //#line 113 "x10/regionarray/BlockDistGhostManager.x10"
    public boolean allNeighborsReceived$O() {
        
        //#line 113 "x10/regionarray/BlockDistGhostManager.x10"
        try {{
            
            //#line 113 "x10/regionarray/BlockDistGhostManager.x10"
            x10.xrx.Runtime.enterAtomic();
            {
                
                //#line 114 "x10/regionarray/BlockDistGhostManager.x10"
                final x10.regionarray.GhostManager.GhostNeighborFlag t$149079 = ((x10.regionarray.GhostManager.GhostNeighborFlag)(this.leftNeighbor));
                
                //#line 114 "x10/regionarray/BlockDistGhostManager.x10"
                boolean t$149081 = t$149079.received;
                
                //#line 114 "x10/regionarray/BlockDistGhostManager.x10"
                if (t$149081) {
                    
                    //#line 114 "x10/regionarray/BlockDistGhostManager.x10"
                    final x10.regionarray.GhostManager.GhostNeighborFlag t$149080 = ((x10.regionarray.GhostManager.GhostNeighborFlag)(this.rightNeighbor));
                    
                    //#line 114 "x10/regionarray/BlockDistGhostManager.x10"
                    t$149081 = t$149080.received;
                }
                
                //#line 114 "x10/regionarray/BlockDistGhostManager.x10"
                return t$149081;
            }
        }}finally {{
              
              //#line 113 "x10/regionarray/BlockDistGhostManager.x10"
              x10.xrx.Runtime.exitAtomic();
          }}
        }
    
    
    //#line 117 "x10/regionarray/BlockDistGhostManager.x10"
    public void resetNeighborsReceived() {
        
        //#line 117 "x10/regionarray/BlockDistGhostManager.x10"
        try {{
            
            //#line 117 "x10/regionarray/BlockDistGhostManager.x10"
            x10.xrx.Runtime.enterAtomic();
            {
                
                //#line 118 "x10/regionarray/BlockDistGhostManager.x10"
                final x10.regionarray.GhostManager.GhostNeighborFlag t$149083 = ((x10.regionarray.GhostManager.GhostNeighborFlag)(this.leftNeighbor));
                
                //#line 118 "x10/regionarray/BlockDistGhostManager.x10"
                t$149083.received = false;
                
                //#line 119 "x10/regionarray/BlockDistGhostManager.x10"
                final x10.regionarray.GhostManager.GhostNeighborFlag t$149084 = ((x10.regionarray.GhostManager.GhostNeighborFlag)(this.rightNeighbor));
                
                //#line 119 "x10/regionarray/BlockDistGhostManager.x10"
                t$149084.received = false;
            }
        }}finally {{
              
              //#line 117 "x10/regionarray/BlockDistGhostManager.x10"
              x10.xrx.Runtime.exitAtomic();
          }}
        }
    
    
    //#line 122 "x10/regionarray/BlockDistGhostManager.x10"
    private void setAllNeighborsReceived() {
        
        //#line 122 "x10/regionarray/BlockDistGhostManager.x10"
        try {{
            
            //#line 122 "x10/regionarray/BlockDistGhostManager.x10"
            x10.xrx.Runtime.enterAtomic();
            {
                
                //#line 123 "x10/regionarray/BlockDistGhostManager.x10"
                final x10.regionarray.GhostManager.GhostNeighborFlag t$149085 = ((x10.regionarray.GhostManager.GhostNeighborFlag)(this.leftNeighbor));
                
                //#line 123 "x10/regionarray/BlockDistGhostManager.x10"
                t$149085.received = true;
                
                //#line 124 "x10/regionarray/BlockDistGhostManager.x10"
                final x10.regionarray.GhostManager.GhostNeighborFlag t$149086 = ((x10.regionarray.GhostManager.GhostNeighborFlag)(this.rightNeighbor));
                
                //#line 124 "x10/regionarray/BlockDistGhostManager.x10"
                t$149086.received = true;
            }
        }}finally {{
              
              //#line 122 "x10/regionarray/BlockDistGhostManager.x10"
              x10.xrx.Runtime.exitAtomic();
          }}
        }
    
    public static void setAllNeighborsReceived$P(final x10.regionarray.BlockDistGhostManager BlockDistGhostManager) {
        BlockDistGhostManager.setAllNeighborsReceived();
    }
    
    
    //#line 132 "x10/regionarray/BlockDistGhostManager.x10"
    /**
     * Send ghost data for this place to neighboring places in a BlockDist.
     * As this DistArray is only divided along one axis, data only need
     * to be sent along that axis.
     */
    public void sendGhosts(final x10.regionarray.Ghostable array) {
        
        //#line 133 "x10/regionarray/BlockDistGhostManager.x10"
        this.prepareToSendGhosts();
        
        //#line 135 "x10/regionarray/BlockDistGhostManager.x10"
        final x10.regionarray.BlockDist this$148951 = ((x10.regionarray.BlockDist)(this.bd));
        
        //#line 135 "x10/regionarray/BlockDistGhostManager.x10"
        final x10.lang.Place p$148950 = ((x10.lang.Place)(x10.x10rt.X10RT.here()));
        
        //#line 135 "x10/regionarray/BlockDistGhostManager.x10"
        final x10.regionarray.Region r = ((x10.regionarray.Region)(this$148951.get(((x10.lang.Place)(p$148950)))));
        
        //#line 136 "x10/regionarray/BlockDistGhostManager.x10"
        final boolean t$149087 = r.isEmpty$O();
        
        //#line 136 "x10/regionarray/BlockDistGhostManager.x10"
        if (t$149087) {
            
            //#line 137 "x10/regionarray/BlockDistGhostManager.x10"
            this.setAllNeighborsReceived();
            
            //#line 138 "x10/regionarray/BlockDistGhostManager.x10"
            return;
        }
        
        //#line 141 "x10/regionarray/BlockDistGhostManager.x10"
        boolean t$149090 = this.periodic;
        
        //#line 141 "x10/regionarray/BlockDistGhostManager.x10"
        if (!(t$149090)) {
            
            //#line 141 "x10/regionarray/BlockDistGhostManager.x10"
            final x10.regionarray.GhostManager.GhostNeighborFlag t$149088 = ((x10.regionarray.GhostManager.GhostNeighborFlag)(this.leftNeighbor));
            
            //#line 141 "x10/regionarray/BlockDistGhostManager.x10"
            final x10.lang.Place t$149089 = ((x10.lang.Place)(t$149088.place));
            
            //#line 141 "x10/regionarray/BlockDistGhostManager.x10"
            t$149090 = (!x10.rtt.Equality.equalsequals((t$149089),(x10.x10rt.X10RT.here())));
        }
        
        //#line 141 "x10/regionarray/BlockDistGhostManager.x10"
        if (t$149090) {
            
            //#line 142 "x10/regionarray/BlockDistGhostManager.x10"
            final long t$149092 = r.rank;
            
            //#line 142 "x10/regionarray/BlockDistGhostManager.x10"
            final x10.core.fun.Fun_0_1 t$149093 = ((x10.core.fun.Fun_0_1)(new x10.regionarray.BlockDistGhostManager.$Closure$217(r)));
            
            //#line 142 "x10/regionarray/BlockDistGhostManager.x10"
            final x10.core.Rail leftMin = ((x10.core.Rail)(new x10.core.Rail<x10.core.Long>(x10.rtt.Types.LONG, ((long)(t$149092)), ((x10.core.fun.Fun_0_1)(t$149093)), (x10.core.Rail.__1$1x10$lang$Long$3x10$lang$Rail$$T$2) null)));
            
            //#line 143 "x10/regionarray/BlockDistGhostManager.x10"
            final long t$149102 = r.rank;
            
            //#line 143 "x10/regionarray/BlockDistGhostManager.x10"
            final x10.core.fun.Fun_0_1 t$149103 = ((x10.core.fun.Fun_0_1)(new x10.regionarray.BlockDistGhostManager.$Closure$218(this, this.bd, r, this.ghostWidth)));
            
            //#line 143 "x10/regionarray/BlockDistGhostManager.x10"
            final x10.core.Rail leftMax = ((x10.core.Rail)(new x10.core.Rail<x10.core.Long>(x10.rtt.Types.LONG, ((long)(t$149102)), ((x10.core.fun.Fun_0_1)(t$149103)), (x10.core.Rail.__1$1x10$lang$Long$3x10$lang$Rail$$T$2) null)));
            
            //#line 144 "x10/regionarray/BlockDistGhostManager.x10"
            final x10.regionarray.Region leftReg = ((x10.regionarray.Region)(x10.regionarray.Region.makeRectangular__0$1x10$lang$Long$2__1$1x10$lang$Long$2(((x10.core.Rail)(leftMin)), ((x10.core.Rail)(leftMax)))));
            
            //#line 145 "x10/regionarray/BlockDistGhostManager.x10"
            final long t$149130 = r.rank;
            
            //#line 145 "x10/regionarray/BlockDistGhostManager.x10"
            final x10.core.fun.Fun_0_1 t$149131 = ((x10.core.fun.Fun_0_1)(new x10.regionarray.BlockDistGhostManager.$Closure$219(this, this.bd, r)));
            
            //#line 145 "x10/regionarray/BlockDistGhostManager.x10"
            final x10.core.Rail shiftCoords = ((x10.core.Rail)(new x10.core.Rail<x10.core.Long>(x10.rtt.Types.LONG, ((long)(t$149130)), ((x10.core.fun.Fun_0_1)(t$149131)), (x10.core.Rail.__1$1x10$lang$Long$3x10$lang$Rail$$T$2) null)));
            
            //#line 150 "x10/regionarray/BlockDistGhostManager.x10"
            final x10.lang.Point shift = ((x10.lang.Point)(x10.lang.Point.make__0$1x10$lang$Long$2(((x10.core.Rail)(shiftCoords)))));
            
            //#line 152 "x10/regionarray/BlockDistGhostManager.x10"
            final x10.regionarray.GhostManager.GhostNeighborFlag t$149132 = ((x10.regionarray.GhostManager.GhostNeighborFlag)(this.leftNeighbor));
            
            //#line 152 "x10/regionarray/BlockDistGhostManager.x10"
            final x10.lang.Place t$149133 = ((x10.lang.Place)(t$149132.place));
            
            //#line 152 "x10/regionarray/BlockDistGhostManager.x10"
            final x10.regionarray.GhostManager this$148953 = ((x10.regionarray.GhostManager)
                                                               this);
            
            //#line 43 . "x10/regionarray/GhostManager.x10"
            final byte t$149134 = this$148953.currentPhase;
            
            //#line 152 "x10/regionarray/BlockDistGhostManager.x10"
            array.putOverlap(((x10.regionarray.Region)(leftReg)), ((x10.lang.Place)(t$149133)), ((x10.lang.Point)(shift)), (byte)(t$149134));
        } else {
            
            //#line 154 "x10/regionarray/BlockDistGhostManager.x10"
            final x10.regionarray.GhostManager.GhostNeighborFlag t$149135 = ((x10.regionarray.GhostManager.GhostNeighborFlag)(this.leftNeighbor));
            
            //#line 154 "x10/regionarray/BlockDistGhostManager.x10"
            t$149135.received = true;
        }
        
        //#line 157 "x10/regionarray/BlockDistGhostManager.x10"
        boolean t$149139 = this.periodic;
        
        //#line 157 "x10/regionarray/BlockDistGhostManager.x10"
        if (!(t$149139)) {
            
            //#line 157 "x10/regionarray/BlockDistGhostManager.x10"
            final x10.regionarray.GhostManager.GhostNeighborFlag t$149137 = ((x10.regionarray.GhostManager.GhostNeighborFlag)(this.rightNeighbor));
            
            //#line 157 "x10/regionarray/BlockDistGhostManager.x10"
            final x10.lang.Place t$149138 = ((x10.lang.Place)(t$149137.place));
            
            //#line 157 "x10/regionarray/BlockDistGhostManager.x10"
            t$149139 = (!x10.rtt.Equality.equalsequals((t$149138),(x10.x10rt.X10RT.here())));
        }
        
        //#line 157 "x10/regionarray/BlockDistGhostManager.x10"
        if (t$149139) {
            
            //#line 158 "x10/regionarray/BlockDistGhostManager.x10"
            final long t$149148 = r.rank;
            
            //#line 158 "x10/regionarray/BlockDistGhostManager.x10"
            final x10.core.fun.Fun_0_1 t$149149 = ((x10.core.fun.Fun_0_1)(new x10.regionarray.BlockDistGhostManager.$Closure$220(this, this.bd, r, this.ghostWidth)));
            
            //#line 158 "x10/regionarray/BlockDistGhostManager.x10"
            final x10.core.Rail rightMin = ((x10.core.Rail)(new x10.core.Rail<x10.core.Long>(x10.rtt.Types.LONG, ((long)(t$149148)), ((x10.core.fun.Fun_0_1)(t$149149)), (x10.core.Rail.__1$1x10$lang$Long$3x10$lang$Rail$$T$2) null)));
            
            //#line 159 "x10/regionarray/BlockDistGhostManager.x10"
            final long t$149151 = r.rank;
            
            //#line 159 "x10/regionarray/BlockDistGhostManager.x10"
            final x10.core.fun.Fun_0_1 t$149152 = ((x10.core.fun.Fun_0_1)(new x10.regionarray.BlockDistGhostManager.$Closure$221(r)));
            
            //#line 159 "x10/regionarray/BlockDistGhostManager.x10"
            final x10.core.Rail rightMax = ((x10.core.Rail)(new x10.core.Rail<x10.core.Long>(x10.rtt.Types.LONG, ((long)(t$149151)), ((x10.core.fun.Fun_0_1)(t$149152)), (x10.core.Rail.__1$1x10$lang$Long$3x10$lang$Rail$$T$2) null)));
            
            //#line 160 "x10/regionarray/BlockDistGhostManager.x10"
            final x10.regionarray.Region rightReg = ((x10.regionarray.Region)(x10.regionarray.Region.makeRectangular__0$1x10$lang$Long$2__1$1x10$lang$Long$2(((x10.core.Rail)(rightMin)), ((x10.core.Rail)(rightMax)))));
            
            //#line 161 "x10/regionarray/BlockDistGhostManager.x10"
            final long t$149180 = r.rank;
            
            //#line 161 "x10/regionarray/BlockDistGhostManager.x10"
            final x10.core.fun.Fun_0_1 t$149181 = ((x10.core.fun.Fun_0_1)(new x10.regionarray.BlockDistGhostManager.$Closure$222(this, this.bd, r)));
            
            //#line 161 "x10/regionarray/BlockDistGhostManager.x10"
            final x10.core.Rail shiftCoords = ((x10.core.Rail)(new x10.core.Rail<x10.core.Long>(x10.rtt.Types.LONG, ((long)(t$149180)), ((x10.core.fun.Fun_0_1)(t$149181)), (x10.core.Rail.__1$1x10$lang$Long$3x10$lang$Rail$$T$2) null)));
            
            //#line 166 "x10/regionarray/BlockDistGhostManager.x10"
            final x10.lang.Point shift = ((x10.lang.Point)(x10.lang.Point.make__0$1x10$lang$Long$2(((x10.core.Rail)(shiftCoords)))));
            
            //#line 168 "x10/regionarray/BlockDistGhostManager.x10"
            final x10.regionarray.GhostManager.GhostNeighborFlag t$149182 = ((x10.regionarray.GhostManager.GhostNeighborFlag)(this.rightNeighbor));
            
            //#line 168 "x10/regionarray/BlockDistGhostManager.x10"
            final x10.lang.Place t$149183 = ((x10.lang.Place)(t$149182.place));
            
            //#line 168 "x10/regionarray/BlockDistGhostManager.x10"
            final x10.regionarray.GhostManager this$148955 = ((x10.regionarray.GhostManager)
                                                               this);
            
            //#line 43 . "x10/regionarray/GhostManager.x10"
            final byte t$149184 = this$148955.currentPhase;
            
            //#line 168 "x10/regionarray/BlockDistGhostManager.x10"
            array.putOverlap(((x10.regionarray.Region)(rightReg)), ((x10.lang.Place)(t$149183)), ((x10.lang.Point)(shift)), (byte)(t$149184));
        } else {
            
            //#line 170 "x10/regionarray/BlockDistGhostManager.x10"
            final x10.regionarray.GhostManager.GhostNeighborFlag t$149185 = ((x10.regionarray.GhostManager.GhostNeighborFlag)(this.rightNeighbor));
            
            //#line 170 "x10/regionarray/BlockDistGhostManager.x10"
            t$149185.received = true;
        }
    }
    
    
    //#line 18 "x10/regionarray/BlockDistGhostManager.x10"
    final public x10.regionarray.BlockDistGhostManager x10$regionarray$BlockDistGhostManager$$this$x10$regionarray$BlockDistGhostManager() {
        
        //#line 18 "x10/regionarray/BlockDistGhostManager.x10"
        return x10.regionarray.BlockDistGhostManager.this;
    }
    
    
    //#line 18 "x10/regionarray/BlockDistGhostManager.x10"
    final public void __fieldInitializers_x10_regionarray_BlockDistGhostManager() {
        
    }
    
    @x10.runtime.impl.java.X10Generated
    final public static class $Closure$211 extends x10.core.Ref implements x10.core.fun.Fun_0_1, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<$Closure$211> $RTT = 
            x10.rtt.StaticFunType.<$Closure$211> make($Closure$211.class,
                                                      new x10.rtt.Type[] {
                                                          x10.rtt.ParameterizedType.make(x10.core.fun.Fun_0_1.$RTT, x10.rtt.Types.LONG, x10.rtt.Types.LONG)
                                                      });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static x10.serialization.X10JavaSerializable $_deserialize_body(x10.regionarray.BlockDistGhostManager.$Closure$211 $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.regionarray.BlockDistGhostManager.$Closure$211 $_obj = new x10.regionarray.BlockDistGhostManager.$Closure$211((java.lang.System[]) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            
        }
        
        // constructor just for allocation
        public $Closure$211(final java.lang.System[] $dummy) {
            
        }
        
        // dispatcher for method abstract public (Z1)=>U.operator()(a1:Z1):U
        public java.lang.Object $apply(final java.lang.Object a1, final x10.rtt.Type t1) {
            return x10.core.Long.$box($apply$O(x10.core.Long.$unbox(a1)));
            
        }
        
        // dispatcher for method abstract public (Z1)=>U.operator()(a1:Z1):U
        public long $apply$J(final java.lang.Object a1, final x10.rtt.Type t1) {
            return $apply$O(x10.core.Long.$unbox(a1));
            
        }
        
        
    
        
        public long $apply$O(final long i) {
            
            //#line 35 "x10/regionarray/BlockDistGhostManager.x10"
            return 0L;
        }
        
        public $Closure$211() {
             {
                
            }
        }
        
    }
    
    @x10.runtime.impl.java.X10Generated
    final public static class $Closure$212 extends x10.core.Ref implements x10.core.fun.Fun_0_1, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<$Closure$212> $RTT = 
            x10.rtt.StaticFunType.<$Closure$212> make($Closure$212.class,
                                                      new x10.rtt.Type[] {
                                                          x10.rtt.ParameterizedType.make(x10.core.fun.Fun_0_1.$RTT, x10.rtt.Types.LONG, x10.rtt.Types.LONG)
                                                      });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static x10.serialization.X10JavaSerializable $_deserialize_body(x10.regionarray.BlockDistGhostManager.$Closure$212 $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            $_obj.bd = $deserializer.readObject();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.regionarray.BlockDistGhostManager.$Closure$212 $_obj = new x10.regionarray.BlockDistGhostManager.$Closure$212((java.lang.System[]) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            $serializer.write(this.bd);
            
        }
        
        // constructor just for allocation
        public $Closure$212(final java.lang.System[] $dummy) {
            
        }
        
        // dispatcher for method abstract public (Z1)=>U.operator()(a1:Z1):U
        public java.lang.Object $apply(final java.lang.Object a1, final x10.rtt.Type t1) {
            return x10.core.Long.$box($apply$O(x10.core.Long.$unbox(a1)));
            
        }
        
        // dispatcher for method abstract public (Z1)=>U.operator()(a1:Z1):U
        public long $apply$J(final java.lang.Object a1, final x10.rtt.Type t1) {
            return $apply$O(x10.core.Long.$unbox(a1));
            
        }
        
        
    
        
        public long $apply$O(final long i) {
            
            //#line 38 "x10/regionarray/BlockDistGhostManager.x10"
            final long t$148967 = this.bd.axis;
            
            //#line 38 "x10/regionarray/BlockDistGhostManager.x10"
            final boolean t$148976 = ((long) i) == ((long) t$148967);
            
            //#line 38 "x10/regionarray/BlockDistGhostManager.x10"
            long t$148977 =  0;
            
            //#line 38 "x10/regionarray/BlockDistGhostManager.x10"
            if (t$148976) {
                
                //#line 38 "x10/regionarray/BlockDistGhostManager.x10"
                final x10.regionarray.Region t$148968 = ((x10.regionarray.Region)(this.bd.region));
                
                //#line 38 "x10/regionarray/BlockDistGhostManager.x10"
                final long t$148969 = this.bd.axis;
                
                //#line 38 "x10/regionarray/BlockDistGhostManager.x10"
                final long t$148972 = t$148968.max$O((long)(t$148969));
                
                //#line 38 "x10/regionarray/BlockDistGhostManager.x10"
                final x10.regionarray.Region t$148970 = ((x10.regionarray.Region)(this.bd.region));
                
                //#line 38 "x10/regionarray/BlockDistGhostManager.x10"
                final long t$148971 = this.bd.axis;
                
                //#line 38 "x10/regionarray/BlockDistGhostManager.x10"
                final long t$148973 = t$148970.min$O((long)(t$148971));
                
                //#line 38 "x10/regionarray/BlockDistGhostManager.x10"
                final long t$148974 = ((t$148972) - (((long)(t$148973))));
                
                //#line 38 "x10/regionarray/BlockDistGhostManager.x10"
                final long t$148975 = ((t$148974) + (((long)(1L))));
                
                //#line 38 "x10/regionarray/BlockDistGhostManager.x10"
                t$148977 = (-(t$148975));
            } else {
                
                //#line 38 "x10/regionarray/BlockDistGhostManager.x10"
                t$148977 = 0L;
            }
            
            //#line 38 "x10/regionarray/BlockDistGhostManager.x10"
            return t$148977;
        }
        
        public x10.regionarray.BlockDist bd;
        
        public $Closure$212(final x10.regionarray.BlockDist bd) {
             {
                this.bd = ((x10.regionarray.BlockDist)(bd));
            }
        }
        
    }
    
    @x10.runtime.impl.java.X10Generated
    final public static class $Closure$213 extends x10.core.Ref implements x10.core.fun.Fun_0_1, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<$Closure$213> $RTT = 
            x10.rtt.StaticFunType.<$Closure$213> make($Closure$213.class,
                                                      new x10.rtt.Type[] {
                                                          x10.rtt.ParameterizedType.make(x10.core.fun.Fun_0_1.$RTT, x10.rtt.Types.LONG, x10.rtt.Types.LONG)
                                                      });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static x10.serialization.X10JavaSerializable $_deserialize_body(x10.regionarray.BlockDistGhostManager.$Closure$213 $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.regionarray.BlockDistGhostManager.$Closure$213 $_obj = new x10.regionarray.BlockDistGhostManager.$Closure$213((java.lang.System[]) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            
        }
        
        // constructor just for allocation
        public $Closure$213(final java.lang.System[] $dummy) {
            
        }
        
        // dispatcher for method abstract public (Z1)=>U.operator()(a1:Z1):U
        public java.lang.Object $apply(final java.lang.Object a1, final x10.rtt.Type t1) {
            return x10.core.Long.$box($apply$O(x10.core.Long.$unbox(a1)));
            
        }
        
        // dispatcher for method abstract public (Z1)=>U.operator()(a1:Z1):U
        public long $apply$J(final java.lang.Object a1, final x10.rtt.Type t1) {
            return $apply$O(x10.core.Long.$unbox(a1));
            
        }
        
        
    
        
        public long $apply$O(final long i) {
            
            //#line 41 "x10/regionarray/BlockDistGhostManager.x10"
            return 0L;
        }
        
        public $Closure$213() {
             {
                
            }
        }
        
    }
    
    @x10.runtime.impl.java.X10Generated
    final public static class $Closure$214 extends x10.core.Ref implements x10.core.fun.Fun_0_1, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<$Closure$214> $RTT = 
            x10.rtt.StaticFunType.<$Closure$214> make($Closure$214.class,
                                                      new x10.rtt.Type[] {
                                                          x10.rtt.ParameterizedType.make(x10.core.fun.Fun_0_1.$RTT, x10.rtt.Types.LONG, x10.rtt.Types.LONG)
                                                      });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static x10.serialization.X10JavaSerializable $_deserialize_body(x10.regionarray.BlockDistGhostManager.$Closure$214 $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.regionarray.BlockDistGhostManager.$Closure$214 $_obj = new x10.regionarray.BlockDistGhostManager.$Closure$214((java.lang.System[]) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            
        }
        
        // constructor just for allocation
        public $Closure$214(final java.lang.System[] $dummy) {
            
        }
        
        // dispatcher for method abstract public (Z1)=>U.operator()(a1:Z1):U
        public java.lang.Object $apply(final java.lang.Object a1, final x10.rtt.Type t1) {
            return x10.core.Long.$box($apply$O(x10.core.Long.$unbox(a1)));
            
        }
        
        // dispatcher for method abstract public (Z1)=>U.operator()(a1:Z1):U
        public long $apply$J(final java.lang.Object a1, final x10.rtt.Type t1) {
            return $apply$O(x10.core.Long.$unbox(a1));
            
        }
        
        
    
        
        public long $apply$O(final long i) {
            
            //#line 49 "x10/regionarray/BlockDistGhostManager.x10"
            return 0L;
        }
        
        public $Closure$214() {
             {
                
            }
        }
        
    }
    
    @x10.runtime.impl.java.X10Generated
    final public static class $Closure$215 extends x10.core.Ref implements x10.core.fun.Fun_0_1, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<$Closure$215> $RTT = 
            x10.rtt.StaticFunType.<$Closure$215> make($Closure$215.class,
                                                      new x10.rtt.Type[] {
                                                          x10.rtt.ParameterizedType.make(x10.core.fun.Fun_0_1.$RTT, x10.rtt.Types.LONG, x10.rtt.Types.LONG)
                                                      });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static x10.serialization.X10JavaSerializable $_deserialize_body(x10.regionarray.BlockDistGhostManager.$Closure$215 $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            $_obj.bd = $deserializer.readObject();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.regionarray.BlockDistGhostManager.$Closure$215 $_obj = new x10.regionarray.BlockDistGhostManager.$Closure$215((java.lang.System[]) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            $serializer.write(this.bd);
            
        }
        
        // constructor just for allocation
        public $Closure$215(final java.lang.System[] $dummy) {
            
        }
        
        // dispatcher for method abstract public (Z1)=>U.operator()(a1:Z1):U
        public java.lang.Object $apply(final java.lang.Object a1, final x10.rtt.Type t1) {
            return x10.core.Long.$box($apply$O(x10.core.Long.$unbox(a1)));
            
        }
        
        // dispatcher for method abstract public (Z1)=>U.operator()(a1:Z1):U
        public long $apply$J(final java.lang.Object a1, final x10.rtt.Type t1) {
            return $apply$O(x10.core.Long.$unbox(a1));
            
        }
        
        
    
        
        public long $apply$O(final long i) {
            
            //#line 52 "x10/regionarray/BlockDistGhostManager.x10"
            final long t$148997 = this.bd.axis;
            
            //#line 52 "x10/regionarray/BlockDistGhostManager.x10"
            final boolean t$149005 = ((long) i) == ((long) t$148997);
            
            //#line 52 "x10/regionarray/BlockDistGhostManager.x10"
            long t$149006 =  0;
            
            //#line 52 "x10/regionarray/BlockDistGhostManager.x10"
            if (t$149005) {
                
                //#line 52 "x10/regionarray/BlockDistGhostManager.x10"
                final x10.regionarray.Region t$148998 = ((x10.regionarray.Region)(this.bd.region));
                
                //#line 52 "x10/regionarray/BlockDistGhostManager.x10"
                final long t$148999 = this.bd.axis;
                
                //#line 52 "x10/regionarray/BlockDistGhostManager.x10"
                final long t$149002 = t$148998.max$O((long)(t$148999));
                
                //#line 52 "x10/regionarray/BlockDistGhostManager.x10"
                final x10.regionarray.Region t$149000 = ((x10.regionarray.Region)(this.bd.region));
                
                //#line 52 "x10/regionarray/BlockDistGhostManager.x10"
                final long t$149001 = this.bd.axis;
                
                //#line 52 "x10/regionarray/BlockDistGhostManager.x10"
                final long t$149003 = t$149000.min$O((long)(t$149001));
                
                //#line 52 "x10/regionarray/BlockDistGhostManager.x10"
                final long t$149004 = ((t$149002) - (((long)(t$149003))));
                
                //#line 52 "x10/regionarray/BlockDistGhostManager.x10"
                t$149006 = ((t$149004) + (((long)(1L))));
            } else {
                
                //#line 52 "x10/regionarray/BlockDistGhostManager.x10"
                t$149006 = 0L;
            }
            
            //#line 52 "x10/regionarray/BlockDistGhostManager.x10"
            return t$149006;
        }
        
        public x10.regionarray.BlockDist bd;
        
        public $Closure$215(final x10.regionarray.BlockDist bd) {
             {
                this.bd = ((x10.regionarray.BlockDist)(bd));
            }
        }
        
    }
    
    @x10.runtime.impl.java.X10Generated
    final public static class $Closure$216 extends x10.core.Ref implements x10.core.fun.Fun_0_1, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<$Closure$216> $RTT = 
            x10.rtt.StaticFunType.<$Closure$216> make($Closure$216.class,
                                                      new x10.rtt.Type[] {
                                                          x10.rtt.ParameterizedType.make(x10.core.fun.Fun_0_1.$RTT, x10.rtt.Types.LONG, x10.rtt.Types.LONG)
                                                      });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static x10.serialization.X10JavaSerializable $_deserialize_body(x10.regionarray.BlockDistGhostManager.$Closure$216 $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.regionarray.BlockDistGhostManager.$Closure$216 $_obj = new x10.regionarray.BlockDistGhostManager.$Closure$216((java.lang.System[]) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            
        }
        
        // constructor just for allocation
        public $Closure$216(final java.lang.System[] $dummy) {
            
        }
        
        // dispatcher for method abstract public (Z1)=>U.operator()(a1:Z1):U
        public java.lang.Object $apply(final java.lang.Object a1, final x10.rtt.Type t1) {
            return x10.core.Long.$box($apply$O(x10.core.Long.$unbox(a1)));
            
        }
        
        // dispatcher for method abstract public (Z1)=>U.operator()(a1:Z1):U
        public long $apply$J(final java.lang.Object a1, final x10.rtt.Type t1) {
            return $apply$O(x10.core.Long.$unbox(a1));
            
        }
        
        
    
        
        public long $apply$O(final long i) {
            
            //#line 55 "x10/regionarray/BlockDistGhostManager.x10"
            return 0L;
        }
        
        public $Closure$216() {
             {
                
            }
        }
        
    }
    
    @x10.runtime.impl.java.X10Generated
    final public static class $Closure$217 extends x10.core.Ref implements x10.core.fun.Fun_0_1, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<$Closure$217> $RTT = 
            x10.rtt.StaticFunType.<$Closure$217> make($Closure$217.class,
                                                      new x10.rtt.Type[] {
                                                          x10.rtt.ParameterizedType.make(x10.core.fun.Fun_0_1.$RTT, x10.rtt.Types.LONG, x10.rtt.Types.LONG)
                                                      });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static x10.serialization.X10JavaSerializable $_deserialize_body(x10.regionarray.BlockDistGhostManager.$Closure$217 $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            $_obj.r = $deserializer.readObject();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.regionarray.BlockDistGhostManager.$Closure$217 $_obj = new x10.regionarray.BlockDistGhostManager.$Closure$217((java.lang.System[]) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            $serializer.write(this.r);
            
        }
        
        // constructor just for allocation
        public $Closure$217(final java.lang.System[] $dummy) {
            
        }
        
        // dispatcher for method abstract public (Z1)=>U.operator()(a1:Z1):U
        public java.lang.Object $apply(final java.lang.Object a1, final x10.rtt.Type t1) {
            return x10.core.Long.$box($apply$O(x10.core.Long.$unbox(a1)));
            
        }
        
        // dispatcher for method abstract public (Z1)=>U.operator()(a1:Z1):U
        public long $apply$J(final java.lang.Object a1, final x10.rtt.Type t1) {
            return $apply$O(x10.core.Long.$unbox(a1));
            
        }
        
        
    
        
        public long $apply$O(final long i) {
            
            //#line 142 "x10/regionarray/BlockDistGhostManager.x10"
            final long t$149091 = this.r.min$O((long)(i));
            
            //#line 142 "x10/regionarray/BlockDistGhostManager.x10"
            return t$149091;
        }
        
        public x10.regionarray.Region r;
        
        public $Closure$217(final x10.regionarray.Region r) {
             {
                this.r = ((x10.regionarray.Region)(r));
            }
        }
        
    }
    
    @x10.runtime.impl.java.X10Generated
    final public static class $Closure$218 extends x10.core.Ref implements x10.core.fun.Fun_0_1, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<$Closure$218> $RTT = 
            x10.rtt.StaticFunType.<$Closure$218> make($Closure$218.class,
                                                      new x10.rtt.Type[] {
                                                          x10.rtt.ParameterizedType.make(x10.core.fun.Fun_0_1.$RTT, x10.rtt.Types.LONG, x10.rtt.Types.LONG)
                                                      });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static x10.serialization.X10JavaSerializable $_deserialize_body(x10.regionarray.BlockDistGhostManager.$Closure$218 $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            $_obj.bd = $deserializer.readObject();
            $_obj.ghostWidth = $deserializer.readLong();
            $_obj.out$$ = $deserializer.readObject();
            $_obj.r = $deserializer.readObject();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.regionarray.BlockDistGhostManager.$Closure$218 $_obj = new x10.regionarray.BlockDistGhostManager.$Closure$218((java.lang.System[]) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            $serializer.write(this.bd);
            $serializer.write(this.ghostWidth);
            $serializer.write(this.out$$);
            $serializer.write(this.r);
            
        }
        
        // constructor just for allocation
        public $Closure$218(final java.lang.System[] $dummy) {
            
        }
        
        // dispatcher for method abstract public (Z1)=>U.operator()(a1:Z1):U
        public java.lang.Object $apply(final java.lang.Object a1, final x10.rtt.Type t1) {
            return x10.core.Long.$box($apply$O(x10.core.Long.$unbox(a1)));
            
        }
        
        // dispatcher for method abstract public (Z1)=>U.operator()(a1:Z1):U
        public long $apply$J(final java.lang.Object a1, final x10.rtt.Type t1) {
            return $apply$O(x10.core.Long.$unbox(a1));
            
        }
        
        
    
        
        public long $apply$O(final long i) {
            
            //#line 143 "x10/regionarray/BlockDistGhostManager.x10"
            final x10.regionarray.BlockDist t$149094 = ((x10.regionarray.BlockDist)(this.bd));
            
            //#line 143 "x10/regionarray/BlockDistGhostManager.x10"
            final long t$149095 = t$149094.axis;
            
            //#line 143 "x10/regionarray/BlockDistGhostManager.x10"
            final boolean t$149099 = ((long) i) == ((long) t$149095);
            
            //#line 143 "x10/regionarray/BlockDistGhostManager.x10"
            long t$149100 =  0;
            
            //#line 143 "x10/regionarray/BlockDistGhostManager.x10"
            if (t$149099) {
                
                //#line 143 "x10/regionarray/BlockDistGhostManager.x10"
                final long t$149096 = this.r.min$O((long)(i));
                
                //#line 143 "x10/regionarray/BlockDistGhostManager.x10"
                final long t$149097 = this.ghostWidth;
                
                //#line 143 "x10/regionarray/BlockDistGhostManager.x10"
                final long t$149098 = ((t$149096) + (((long)(t$149097))));
                
                //#line 143 "x10/regionarray/BlockDistGhostManager.x10"
                t$149100 = ((t$149098) - (((long)(1L))));
            } else {
                
                //#line 143 "x10/regionarray/BlockDistGhostManager.x10"
                t$149100 = this.r.max$O((long)(i));
            }
            
            //#line 143 "x10/regionarray/BlockDistGhostManager.x10"
            return t$149100;
        }
        
        public x10.regionarray.BlockDistGhostManager out$$;
        public x10.regionarray.BlockDist bd;
        public x10.regionarray.Region r;
        public long ghostWidth;
        
        public $Closure$218(final x10.regionarray.BlockDistGhostManager out$$, final x10.regionarray.BlockDist bd, final x10.regionarray.Region r, final long ghostWidth) {
             {
                this.out$$ = out$$;
                this.bd = ((x10.regionarray.BlockDist)(bd));
                this.r = ((x10.regionarray.Region)(r));
                this.ghostWidth = ghostWidth;
            }
        }
        
    }
    
    @x10.runtime.impl.java.X10Generated
    final public static class $Closure$219 extends x10.core.Ref implements x10.core.fun.Fun_0_1, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<$Closure$219> $RTT = 
            x10.rtt.StaticFunType.<$Closure$219> make($Closure$219.class,
                                                      new x10.rtt.Type[] {
                                                          x10.rtt.ParameterizedType.make(x10.core.fun.Fun_0_1.$RTT, x10.rtt.Types.LONG, x10.rtt.Types.LONG)
                                                      });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static x10.serialization.X10JavaSerializable $_deserialize_body(x10.regionarray.BlockDistGhostManager.$Closure$219 $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            $_obj.bd = $deserializer.readObject();
            $_obj.out$$ = $deserializer.readObject();
            $_obj.r = $deserializer.readObject();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.regionarray.BlockDistGhostManager.$Closure$219 $_obj = new x10.regionarray.BlockDistGhostManager.$Closure$219((java.lang.System[]) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            $serializer.write(this.bd);
            $serializer.write(this.out$$);
            $serializer.write(this.r);
            
        }
        
        // constructor just for allocation
        public $Closure$219(final java.lang.System[] $dummy) {
            
        }
        
        // dispatcher for method abstract public (Z1)=>U.operator()(a1:Z1):U
        public java.lang.Object $apply(final java.lang.Object a1, final x10.rtt.Type t1) {
            return x10.core.Long.$box($apply$O(x10.core.Long.$unbox(a1)));
            
        }
        
        // dispatcher for method abstract public (Z1)=>U.operator()(a1:Z1):U
        public long $apply$J(final java.lang.Object a1, final x10.rtt.Type t1) {
            return $apply$O(x10.core.Long.$unbox(a1));
            
        }
        
        
    
        
        public long $apply$O(final long i) {
            
            //#line 145 "x10/regionarray/BlockDistGhostManager.x10"
            final x10.regionarray.BlockDist t$149104 = ((x10.regionarray.BlockDist)(this.bd));
            
            //#line 145 "x10/regionarray/BlockDistGhostManager.x10"
            final long t$149105 = t$149104.axis;
            
            //#line 145 "x10/regionarray/BlockDistGhostManager.x10"
            final boolean t$149127 = ((long) i) == ((long) t$149105);
            
            //#line 145 "x10/regionarray/BlockDistGhostManager.x10"
            long t$149128 =  0;
            
            //#line 145 "x10/regionarray/BlockDistGhostManager.x10"
            if (t$149127) {
                
                //#line 146 "x10/regionarray/BlockDistGhostManager.x10"
                final x10.regionarray.BlockDist t$149106 = ((x10.regionarray.BlockDist)(this.bd));
                
                //#line 146 "x10/regionarray/BlockDistGhostManager.x10"
                final long t$149107 = t$149106.axis;
                
                //#line 146 "x10/regionarray/BlockDistGhostManager.x10"
                final long t$149112 = this.r.min$O((long)(t$149107));
                
                //#line 146 "x10/regionarray/BlockDistGhostManager.x10"
                final x10.regionarray.BlockDist t$149108 = ((x10.regionarray.BlockDist)(this.bd));
                
                //#line 146 "x10/regionarray/BlockDistGhostManager.x10"
                final x10.regionarray.Region t$149110 = ((x10.regionarray.Region)(t$149108.region));
                
                //#line 146 "x10/regionarray/BlockDistGhostManager.x10"
                final x10.regionarray.BlockDist t$149109 = ((x10.regionarray.BlockDist)(this.bd));
                
                //#line 146 "x10/regionarray/BlockDistGhostManager.x10"
                final long t$149111 = t$149109.axis;
                
                //#line 146 "x10/regionarray/BlockDistGhostManager.x10"
                final long t$149113 = t$149110.min$O((long)(t$149111));
                
                //#line 146 "x10/regionarray/BlockDistGhostManager.x10"
                final boolean t$149125 = ((long) t$149112) == ((long) t$149113);
                
                //#line 146 "x10/regionarray/BlockDistGhostManager.x10"
                long t$149126 =  0;
                
                //#line 146 "x10/regionarray/BlockDistGhostManager.x10"
                if (t$149125) {
                    
                    //#line 147 "x10/regionarray/BlockDistGhostManager.x10"
                    final x10.regionarray.BlockDist t$149114 = ((x10.regionarray.BlockDist)(this.bd));
                    
                    //#line 147 "x10/regionarray/BlockDistGhostManager.x10"
                    final x10.regionarray.Region t$149116 = ((x10.regionarray.Region)(t$149114.region));
                    
                    //#line 147 "x10/regionarray/BlockDistGhostManager.x10"
                    final x10.regionarray.BlockDist t$149115 = ((x10.regionarray.BlockDist)(this.bd));
                    
                    //#line 147 "x10/regionarray/BlockDistGhostManager.x10"
                    final long t$149117 = t$149115.axis;
                    
                    //#line 147 "x10/regionarray/BlockDistGhostManager.x10"
                    final long t$149122 = t$149116.max$O((long)(t$149117));
                    
                    //#line 147 "x10/regionarray/BlockDistGhostManager.x10"
                    final x10.regionarray.BlockDist t$149118 = ((x10.regionarray.BlockDist)(this.bd));
                    
                    //#line 147 "x10/regionarray/BlockDistGhostManager.x10"
                    final x10.regionarray.Region t$149120 = ((x10.regionarray.Region)(t$149118.region));
                    
                    //#line 147 "x10/regionarray/BlockDistGhostManager.x10"
                    final x10.regionarray.BlockDist t$149119 = ((x10.regionarray.BlockDist)(this.bd));
                    
                    //#line 147 "x10/regionarray/BlockDistGhostManager.x10"
                    final long t$149121 = t$149119.axis;
                    
                    //#line 147 "x10/regionarray/BlockDistGhostManager.x10"
                    final long t$149123 = t$149120.min$O((long)(t$149121));
                    
                    //#line 147 "x10/regionarray/BlockDistGhostManager.x10"
                    final long t$149124 = ((t$149122) - (((long)(t$149123))));
                    
                    //#line 146 "x10/regionarray/BlockDistGhostManager.x10"
                    t$149126 = ((t$149124) + (((long)(1L))));
                } else {
                    
                    //#line 146 "x10/regionarray/BlockDistGhostManager.x10"
                    t$149126 = 0L;
                }
                
                //#line 145 "x10/regionarray/BlockDistGhostManager.x10"
                t$149128 = t$149126;
            } else {
                
                //#line 145 "x10/regionarray/BlockDistGhostManager.x10"
                t$149128 = 0L;
            }
            
            //#line 145 "x10/regionarray/BlockDistGhostManager.x10"
            return t$149128;
        }
        
        public x10.regionarray.BlockDistGhostManager out$$;
        public x10.regionarray.BlockDist bd;
        public x10.regionarray.Region r;
        
        public $Closure$219(final x10.regionarray.BlockDistGhostManager out$$, final x10.regionarray.BlockDist bd, final x10.regionarray.Region r) {
             {
                this.out$$ = out$$;
                this.bd = ((x10.regionarray.BlockDist)(bd));
                this.r = ((x10.regionarray.Region)(r));
            }
        }
        
    }
    
    @x10.runtime.impl.java.X10Generated
    final public static class $Closure$220 extends x10.core.Ref implements x10.core.fun.Fun_0_1, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<$Closure$220> $RTT = 
            x10.rtt.StaticFunType.<$Closure$220> make($Closure$220.class,
                                                      new x10.rtt.Type[] {
                                                          x10.rtt.ParameterizedType.make(x10.core.fun.Fun_0_1.$RTT, x10.rtt.Types.LONG, x10.rtt.Types.LONG)
                                                      });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static x10.serialization.X10JavaSerializable $_deserialize_body(x10.regionarray.BlockDistGhostManager.$Closure$220 $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            $_obj.bd = $deserializer.readObject();
            $_obj.ghostWidth = $deserializer.readLong();
            $_obj.out$$ = $deserializer.readObject();
            $_obj.r = $deserializer.readObject();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.regionarray.BlockDistGhostManager.$Closure$220 $_obj = new x10.regionarray.BlockDistGhostManager.$Closure$220((java.lang.System[]) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            $serializer.write(this.bd);
            $serializer.write(this.ghostWidth);
            $serializer.write(this.out$$);
            $serializer.write(this.r);
            
        }
        
        // constructor just for allocation
        public $Closure$220(final java.lang.System[] $dummy) {
            
        }
        
        // dispatcher for method abstract public (Z1)=>U.operator()(a1:Z1):U
        public java.lang.Object $apply(final java.lang.Object a1, final x10.rtt.Type t1) {
            return x10.core.Long.$box($apply$O(x10.core.Long.$unbox(a1)));
            
        }
        
        // dispatcher for method abstract public (Z1)=>U.operator()(a1:Z1):U
        public long $apply$J(final java.lang.Object a1, final x10.rtt.Type t1) {
            return $apply$O(x10.core.Long.$unbox(a1));
            
        }
        
        
    
        
        public long $apply$O(final long i) {
            
            //#line 158 "x10/regionarray/BlockDistGhostManager.x10"
            final x10.regionarray.BlockDist t$149140 = ((x10.regionarray.BlockDist)(this.bd));
            
            //#line 158 "x10/regionarray/BlockDistGhostManager.x10"
            final long t$149141 = t$149140.axis;
            
            //#line 158 "x10/regionarray/BlockDistGhostManager.x10"
            final boolean t$149145 = ((long) i) == ((long) t$149141);
            
            //#line 158 "x10/regionarray/BlockDistGhostManager.x10"
            long t$149146 =  0;
            
            //#line 158 "x10/regionarray/BlockDistGhostManager.x10"
            if (t$149145) {
                
                //#line 158 "x10/regionarray/BlockDistGhostManager.x10"
                final long t$149142 = this.r.max$O((long)(i));
                
                //#line 158 "x10/regionarray/BlockDistGhostManager.x10"
                final long t$149143 = this.ghostWidth;
                
                //#line 158 "x10/regionarray/BlockDistGhostManager.x10"
                final long t$149144 = ((t$149142) - (((long)(t$149143))));
                
                //#line 158 "x10/regionarray/BlockDistGhostManager.x10"
                t$149146 = ((t$149144) + (((long)(1L))));
            } else {
                
                //#line 158 "x10/regionarray/BlockDistGhostManager.x10"
                t$149146 = this.r.min$O((long)(i));
            }
            
            //#line 158 "x10/regionarray/BlockDistGhostManager.x10"
            return t$149146;
        }
        
        public x10.regionarray.BlockDistGhostManager out$$;
        public x10.regionarray.BlockDist bd;
        public x10.regionarray.Region r;
        public long ghostWidth;
        
        public $Closure$220(final x10.regionarray.BlockDistGhostManager out$$, final x10.regionarray.BlockDist bd, final x10.regionarray.Region r, final long ghostWidth) {
             {
                this.out$$ = out$$;
                this.bd = ((x10.regionarray.BlockDist)(bd));
                this.r = ((x10.regionarray.Region)(r));
                this.ghostWidth = ghostWidth;
            }
        }
        
    }
    
    @x10.runtime.impl.java.X10Generated
    final public static class $Closure$221 extends x10.core.Ref implements x10.core.fun.Fun_0_1, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<$Closure$221> $RTT = 
            x10.rtt.StaticFunType.<$Closure$221> make($Closure$221.class,
                                                      new x10.rtt.Type[] {
                                                          x10.rtt.ParameterizedType.make(x10.core.fun.Fun_0_1.$RTT, x10.rtt.Types.LONG, x10.rtt.Types.LONG)
                                                      });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static x10.serialization.X10JavaSerializable $_deserialize_body(x10.regionarray.BlockDistGhostManager.$Closure$221 $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            $_obj.r = $deserializer.readObject();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.regionarray.BlockDistGhostManager.$Closure$221 $_obj = new x10.regionarray.BlockDistGhostManager.$Closure$221((java.lang.System[]) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            $serializer.write(this.r);
            
        }
        
        // constructor just for allocation
        public $Closure$221(final java.lang.System[] $dummy) {
            
        }
        
        // dispatcher for method abstract public (Z1)=>U.operator()(a1:Z1):U
        public java.lang.Object $apply(final java.lang.Object a1, final x10.rtt.Type t1) {
            return x10.core.Long.$box($apply$O(x10.core.Long.$unbox(a1)));
            
        }
        
        // dispatcher for method abstract public (Z1)=>U.operator()(a1:Z1):U
        public long $apply$J(final java.lang.Object a1, final x10.rtt.Type t1) {
            return $apply$O(x10.core.Long.$unbox(a1));
            
        }
        
        
    
        
        public long $apply$O(final long i) {
            
            //#line 159 "x10/regionarray/BlockDistGhostManager.x10"
            final long t$149150 = this.r.max$O((long)(i));
            
            //#line 159 "x10/regionarray/BlockDistGhostManager.x10"
            return t$149150;
        }
        
        public x10.regionarray.Region r;
        
        public $Closure$221(final x10.regionarray.Region r) {
             {
                this.r = ((x10.regionarray.Region)(r));
            }
        }
        
    }
    
    @x10.runtime.impl.java.X10Generated
    final public static class $Closure$222 extends x10.core.Ref implements x10.core.fun.Fun_0_1, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<$Closure$222> $RTT = 
            x10.rtt.StaticFunType.<$Closure$222> make($Closure$222.class,
                                                      new x10.rtt.Type[] {
                                                          x10.rtt.ParameterizedType.make(x10.core.fun.Fun_0_1.$RTT, x10.rtt.Types.LONG, x10.rtt.Types.LONG)
                                                      });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static x10.serialization.X10JavaSerializable $_deserialize_body(x10.regionarray.BlockDistGhostManager.$Closure$222 $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            $_obj.bd = $deserializer.readObject();
            $_obj.out$$ = $deserializer.readObject();
            $_obj.r = $deserializer.readObject();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.regionarray.BlockDistGhostManager.$Closure$222 $_obj = new x10.regionarray.BlockDistGhostManager.$Closure$222((java.lang.System[]) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            $serializer.write(this.bd);
            $serializer.write(this.out$$);
            $serializer.write(this.r);
            
        }
        
        // constructor just for allocation
        public $Closure$222(final java.lang.System[] $dummy) {
            
        }
        
        // dispatcher for method abstract public (Z1)=>U.operator()(a1:Z1):U
        public java.lang.Object $apply(final java.lang.Object a1, final x10.rtt.Type t1) {
            return x10.core.Long.$box($apply$O(x10.core.Long.$unbox(a1)));
            
        }
        
        // dispatcher for method abstract public (Z1)=>U.operator()(a1:Z1):U
        public long $apply$J(final java.lang.Object a1, final x10.rtt.Type t1) {
            return $apply$O(x10.core.Long.$unbox(a1));
            
        }
        
        
    
        
        public long $apply$O(final long i) {
            
            //#line 161 "x10/regionarray/BlockDistGhostManager.x10"
            final x10.regionarray.BlockDist t$149153 = ((x10.regionarray.BlockDist)(this.bd));
            
            //#line 161 "x10/regionarray/BlockDistGhostManager.x10"
            final long t$149154 = t$149153.axis;
            
            //#line 161 "x10/regionarray/BlockDistGhostManager.x10"
            final boolean t$149177 = ((long) i) == ((long) t$149154);
            
            //#line 161 "x10/regionarray/BlockDistGhostManager.x10"
            long t$149178 =  0;
            
            //#line 161 "x10/regionarray/BlockDistGhostManager.x10"
            if (t$149177) {
                
                //#line 162 "x10/regionarray/BlockDistGhostManager.x10"
                final x10.regionarray.BlockDist t$149155 = ((x10.regionarray.BlockDist)(this.bd));
                
                //#line 162 "x10/regionarray/BlockDistGhostManager.x10"
                final long t$149156 = t$149155.axis;
                
                //#line 162 "x10/regionarray/BlockDistGhostManager.x10"
                final long t$149161 = this.r.max$O((long)(t$149156));
                
                //#line 162 "x10/regionarray/BlockDistGhostManager.x10"
                final x10.regionarray.BlockDist t$149157 = ((x10.regionarray.BlockDist)(this.bd));
                
                //#line 162 "x10/regionarray/BlockDistGhostManager.x10"
                final x10.regionarray.Region t$149159 = ((x10.regionarray.Region)(t$149157.region));
                
                //#line 162 "x10/regionarray/BlockDistGhostManager.x10"
                final x10.regionarray.BlockDist t$149158 = ((x10.regionarray.BlockDist)(this.bd));
                
                //#line 162 "x10/regionarray/BlockDistGhostManager.x10"
                final long t$149160 = t$149158.axis;
                
                //#line 162 "x10/regionarray/BlockDistGhostManager.x10"
                final long t$149162 = t$149159.max$O((long)(t$149160));
                
                //#line 162 "x10/regionarray/BlockDistGhostManager.x10"
                final boolean t$149175 = ((long) t$149161) == ((long) t$149162);
                
                //#line 162 "x10/regionarray/BlockDistGhostManager.x10"
                long t$149176 =  0;
                
                //#line 162 "x10/regionarray/BlockDistGhostManager.x10"
                if (t$149175) {
                    
                    //#line 163 "x10/regionarray/BlockDistGhostManager.x10"
                    final x10.regionarray.BlockDist t$149163 = ((x10.regionarray.BlockDist)(this.bd));
                    
                    //#line 163 "x10/regionarray/BlockDistGhostManager.x10"
                    final x10.regionarray.Region t$149165 = ((x10.regionarray.Region)(t$149163.region));
                    
                    //#line 163 "x10/regionarray/BlockDistGhostManager.x10"
                    final x10.regionarray.BlockDist t$149164 = ((x10.regionarray.BlockDist)(this.bd));
                    
                    //#line 163 "x10/regionarray/BlockDistGhostManager.x10"
                    final long t$149166 = t$149164.axis;
                    
                    //#line 163 "x10/regionarray/BlockDistGhostManager.x10"
                    final long t$149171 = t$149165.max$O((long)(t$149166));
                    
                    //#line 163 "x10/regionarray/BlockDistGhostManager.x10"
                    final x10.regionarray.BlockDist t$149167 = ((x10.regionarray.BlockDist)(this.bd));
                    
                    //#line 163 "x10/regionarray/BlockDistGhostManager.x10"
                    final x10.regionarray.Region t$149169 = ((x10.regionarray.Region)(t$149167.region));
                    
                    //#line 163 "x10/regionarray/BlockDistGhostManager.x10"
                    final x10.regionarray.BlockDist t$149168 = ((x10.regionarray.BlockDist)(this.bd));
                    
                    //#line 163 "x10/regionarray/BlockDistGhostManager.x10"
                    final long t$149170 = t$149168.axis;
                    
                    //#line 163 "x10/regionarray/BlockDistGhostManager.x10"
                    final long t$149172 = t$149169.min$O((long)(t$149170));
                    
                    //#line 163 "x10/regionarray/BlockDistGhostManager.x10"
                    final long t$149173 = ((t$149171) - (((long)(t$149172))));
                    
                    //#line 163 "x10/regionarray/BlockDistGhostManager.x10"
                    final long t$149174 = ((t$149173) + (((long)(1L))));
                    
                    //#line 162 "x10/regionarray/BlockDistGhostManager.x10"
                    t$149176 = (-(t$149174));
                } else {
                    
                    //#line 162 "x10/regionarray/BlockDistGhostManager.x10"
                    t$149176 = 0L;
                }
                
                //#line 161 "x10/regionarray/BlockDistGhostManager.x10"
                t$149178 = t$149176;
            } else {
                
                //#line 161 "x10/regionarray/BlockDistGhostManager.x10"
                t$149178 = 0L;
            }
            
            //#line 161 "x10/regionarray/BlockDistGhostManager.x10"
            return t$149178;
        }
        
        public x10.regionarray.BlockDistGhostManager out$$;
        public x10.regionarray.BlockDist bd;
        public x10.regionarray.Region r;
        
        public $Closure$222(final x10.regionarray.BlockDistGhostManager out$$, final x10.regionarray.BlockDist bd, final x10.regionarray.Region r) {
             {
                this.out$$ = out$$;
                this.bd = ((x10.regionarray.BlockDist)(bd));
                this.r = ((x10.regionarray.Region)(r));
            }
        }
        
    }
    
    }
    
    