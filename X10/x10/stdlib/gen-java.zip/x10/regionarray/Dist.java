package x10.regionarray;


/**
 * A distributution supports distributed arrays by providing a mapping
 * from Points to Places.  Equivalently, a distribution may be defined
 * as a mapping from Places to Regions.  The Dist class provides a set
 * of factory methods for constructing various distributions.  There
 * are a set of methods supporting algebraic operations on
 * distributions, such as union, intersection, difference, and so on.
 */
@x10.runtime.impl.java.X10Generated
abstract public class Dist extends x10.core.Ref implements x10.core.fun.Fun_0_1, x10.lang.Iterable, x10.serialization.X10JavaSerializable
{
    public static final x10.rtt.RuntimeType<Dist> $RTT = 
        x10.rtt.NamedType.<Dist> make("x10.regionarray.Dist",
                                      Dist.class,
                                      new x10.rtt.Type[] {
                                          x10.rtt.ParameterizedType.make(x10.core.fun.Fun_0_1.$RTT, x10.lang.Point.$RTT, x10.lang.Place.$RTT),
                                          x10.rtt.ParameterizedType.make(x10.lang.Iterable.$RTT, x10.lang.Point.$RTT)
                                      });
    
    public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
    
    public x10.rtt.Type<?> $getParam(int i) { return null; }
    
    public static x10.serialization.X10JavaSerializable $_deserialize_body(x10.regionarray.Dist $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
        $_obj.region = $deserializer.readObject();
        return $_obj;
    }
    
    public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
        return null;
    }
    
    public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
        $serializer.write(this.region);
        
    }
    
    // constructor just for allocation
    public Dist(final java.lang.System[] $dummy) {
        
    }
    
    // dispatcher for method abstract public (Z1)=>U.operator()(a1:Z1){}:U
    public java.lang.Object $apply(final java.lang.Object a1, final x10.rtt.Type t1) {
        return $apply((x10.lang.Point)a1);
        
    }
    
    
    // properties
    
    //#line 29 "x10/regionarray/Dist.x10"
    /**
     * The region this distribution is defined over.
     */
    public x10.regionarray.Region region;
    

    
    
    //#line 38 "x10/regionarray/Dist.x10"
    /**
     * The rank of this distribution.
     */
    final public long rank$O() {
        
        //#line 38 "x10/regionarray/Dist.x10"
        final x10.regionarray.Region t$149358 = ((x10.regionarray.Region)(this.region));
        
        //#line 38 "x10/regionarray/Dist.x10"
        final long t$149359 = t$149358.rank;
        
        //#line 38 "x10/regionarray/Dist.x10"
        return t$149359;
    }
    
    
    //#line 51 "x10/regionarray/Dist.x10"
    /**
     * Create a distribution over a rank-1 region that maps every
     * point in the region to a distinct place, and which maps some
     * point in the region to every place.
     *
     * @return a "unique" distribution over all places.
     */
    public static x10.regionarray.Dist makeUnique() {
        
        //#line 52 "x10/regionarray/Dist.x10"
        final x10.regionarray.UniqueDist alloc$144494 = ((x10.regionarray.UniqueDist)(new x10.regionarray.UniqueDist((java.lang.System[]) null)));
        
        //#line 51 . "x10/regionarray/UniqueDist.x10"
        final x10.lang.PlaceGroup t$149477 = ((x10.lang.PlaceGroup)(x10.lang.Place.places()));
        
        //#line 51 . "x10/regionarray/UniqueDist.x10"
        alloc$144494.x10$regionarray$UniqueDist$$init$S(((x10.lang.PlaceGroup)(t$149477)));
        
        //#line 52 "x10/regionarray/Dist.x10"
        final x10.regionarray.Dist t$143726 = ((x10.regionarray.Dist)
                                                alloc$144494);
        
        //#line 52 "x10/regionarray/Dist.x10"
        final x10.regionarray.Region t$149361 = ((x10.regionarray.Region)(t$143726.region));
        
        //#line 52 "x10/regionarray/Dist.x10"
        final long t$149362 = t$149361.rank;
        
        //#line 52 "x10/regionarray/Dist.x10"
        final boolean t$149363 = ((long) t$149362) == ((long) 1L);
        
        //#line 52 "x10/regionarray/Dist.x10"
        final boolean t$149365 = !(t$149363);
        
        //#line 52 "x10/regionarray/Dist.x10"
        if (t$149365) {
            
            //#line 52 "x10/regionarray/Dist.x10"
            final x10.lang.FailedDynamicCheckException t$149364 = new x10.lang.FailedDynamicCheckException("x10.regionarray.Dist{self.region.rank==1L}");
            
            //#line 52 "x10/regionarray/Dist.x10"
            throw t$149364;
        }
        
        //#line 52 "x10/regionarray/Dist.x10"
        return t$143726;
    }
    
    
    //#line 62 "x10/regionarray/Dist.x10"
    /**
     * Create a distribution over the specified region that maps
     * every point in the region to here.
     *
     * @param r the given region
     * @return a "constant" distribution over r.
     */
    public static x10.regionarray.Dist makeConstant(final x10.regionarray.Region r) {
        
        //#line 63 "x10/regionarray/Dist.x10"
        final x10.regionarray.ConstantDist alloc$144495 = ((x10.regionarray.ConstantDist)(new x10.regionarray.ConstantDist((java.lang.System[]) null)));
        
        //#line 63 "x10/regionarray/Dist.x10"
        alloc$144495.x10$regionarray$ConstantDist$$init$S(((x10.regionarray.Region)(r)), x10.x10rt.X10RT.here());
        
        //#line 63 "x10/regionarray/Dist.x10"
        return alloc$144495;
    }
    
    
    //#line 74 "x10/regionarray/Dist.x10"
    /**
     * Create a distribution over the specified region that maps
     * every point in the region to here.
     *
     * @param r the given region
     * @return a "constant" distribution over r.
     * @see #makeConstant(Region)
     */
    public static x10.regionarray.Dist make(final x10.regionarray.Region r) {
        
        //#line 63 . "x10/regionarray/Dist.x10"
        final x10.regionarray.ConstantDist alloc$149315 = ((x10.regionarray.ConstantDist)(new x10.regionarray.ConstantDist((java.lang.System[]) null)));
        
        //#line 63 . "x10/regionarray/Dist.x10"
        alloc$149315.x10$regionarray$ConstantDist$$init$S(r, x10.x10rt.X10RT.here());
        
        //#line 63 . "x10/regionarray/Dist.x10"
        final x10.regionarray.Dist t$149366 = ((x10.regionarray.Dist)(((x10.regionarray.Dist)
                                                                        alloc$149315)));
        
        //#line 74 "x10/regionarray/Dist.x10"
        return t$149366;
    }
    
    
    //#line 89 "x10/regionarray/Dist.x10"
    /**
     * Create a distribution of the specified region over all 
     * Places that varies in place only along the specified axis.
     * It divides the coordinates along that axis into Place.numPlaces() blocks, 
     * and assigns successive blocks to successive places.  If the number of coordinates
     * in the axis does not divide evenly into the number of blocks, then 
     * the first (max(axis)-min(axis)+1)%Place.numPlaces() blocks will be assigned 
     * one more coordinate than the remaining blocks.
     *
     * @param r the given region
     * @param axis the dimension to block over
     * @return a "block" distribution over r.
     */
    public static x10.regionarray.Dist makeBlock(final x10.regionarray.Region r, final long axis) {
        
        //#line 89 "x10/regionarray/Dist.x10"
        final x10.lang.PlaceGroup pg$149319 = ((x10.lang.PlaceGroup)(x10.lang.Place.places()));
        
        //#line 189 . "x10/regionarray/Dist.x10"
        final x10.regionarray.BlockDist alloc$149320 = ((x10.regionarray.BlockDist)(new x10.regionarray.BlockDist((java.lang.System[]) null)));
        
        //#line 189 . "x10/regionarray/Dist.x10"
        alloc$149320.x10$regionarray$BlockDist$$init$S(r, axis, ((x10.lang.PlaceGroup)(pg$149319)));
        
        //#line 189 . "x10/regionarray/Dist.x10"
        final x10.regionarray.Dist t$149367 = ((x10.regionarray.Dist)(((x10.regionarray.Dist)
                                                                        alloc$149320)));
        
        //#line 89 "x10/regionarray/Dist.x10"
        return t$149367;
    }
    
    
    //#line 109 "x10/regionarray/Dist.x10"
    /**
     * Creates a block, block distribution across the specified PlaceGroup pg.
     * The coordinates are split along axis0 into M divisions such that M is the minimum of:
     *   - 2^q where q is the next integer above log2(P) / 2
     *   - the length of axis0
     * and split along axis1 into N divisions such that M*(N-1) <= pg.size() <= M*N.
     * Thus there are M*N blocks of size (axis0/M, axis1/N).
     * The blocks are not necessarily of integer size in either dimension.
     * Places 0..(M*N-pg.size()) are each assigned two such blocks, contiguous in axis0.
     * The remaining places are assigned a single block.
     * Block min and max coordinates are rounded to create subregions for each place,
     * e.g. a block [1.0..1.5,2.25..2.75] is rounded to a subregion [1..2,2..2].
     * @param r the given region
     * @param axis0 the first dimension to block over
     * @param axis1 the second dimension to block over
     * @param pg the set of places
     * @return a "block,block" distribution of region r over the places in pg
     */
    public static x10.regionarray.Dist makeBlockBlock(final x10.regionarray.Region r, final long axis0, final long axis1, final x10.lang.PlaceGroup pg) {
        
        //#line 110 "x10/regionarray/Dist.x10"
        final x10.regionarray.BlockBlockDist alloc$144496 = ((x10.regionarray.BlockBlockDist)(new x10.regionarray.BlockBlockDist((java.lang.System[]) null)));
        
        //#line 110 "x10/regionarray/Dist.x10"
        final x10.lang.PlaceGroup t$149478 = ((x10.lang.PlaceGroup)(x10.lang.Place.places()));
        
        //#line 110 "x10/regionarray/Dist.x10"
        alloc$144496.x10$regionarray$BlockBlockDist$$init$S(((x10.regionarray.Region)(r)), ((long)(axis0)), ((long)(axis1)), ((x10.lang.PlaceGroup)(t$149478)));
        
        //#line 110 "x10/regionarray/Dist.x10"
        return alloc$144496;
    }
    
    
    //#line 120 "x10/regionarray/Dist.x10"
    /**
     * Creates a block, block distribution across all places.
     * @param r the given region
     * @param axis0 the first dimension to block over
     * @param axis1 the second dimension to block over
     * @see makeBlockBlock(Region, Long, Long, PlaceGroup)
     */
    public static x10.regionarray.Dist makeBlockBlock(final x10.regionarray.Region r, final long axis0, final long axis1) {
        
        //#line 121 "x10/regionarray/Dist.x10"
        final x10.lang.PlaceGroup t$149369 = ((x10.lang.PlaceGroup)(x10.lang.Place.places()));
        
        //#line 121 "x10/regionarray/Dist.x10"
        final x10.regionarray.Dist t$149370 = ((x10.regionarray.Dist)(x10.regionarray.Dist.makeBlockBlock(((x10.regionarray.Region)(r)), (long)(axis0), (long)(axis1), ((x10.lang.PlaceGroup)(t$149369)))));
        
        //#line 121 "x10/regionarray/Dist.x10"
        return t$149370;
    }
    
    
    //#line 129 "x10/regionarray/Dist.x10"
    /**
     * Creates a block, block distribution across all places that varies in
     * place along the 0-th and 1st axes.
     * @param r the given region
     * @see makeBlockBlock(Region, Long, Long, PlaceGroup)
     */
    public static x10.regionarray.Dist makeBlockBlock(final x10.regionarray.Region r) {
        
        //#line 130 "x10/regionarray/Dist.x10"
        final x10.lang.PlaceGroup t$149371 = ((x10.lang.PlaceGroup)(x10.lang.Place.places()));
        
        //#line 130 "x10/regionarray/Dist.x10"
        final x10.regionarray.Dist t$149372 = ((x10.regionarray.Dist)(x10.regionarray.Dist.makeBlockBlock(((x10.regionarray.Region)(r)), (long)(0L), (long)(1L), ((x10.lang.PlaceGroup)(t$149371)))));
        
        //#line 130 "x10/regionarray/Dist.x10"
        return t$149372;
    }
    
    
    //#line 144 "x10/regionarray/Dist.x10"
    /**
     * Create a distribution of the specified region over all places that varies in
     * place only along the 0-th axis. It divides the coordinates
     * along the 0-th axis into Place.numPlaces() blocks, and assigns
     * successive blocks to successive places.  If the number of coordinates
     * in the axis does not divide evenly into the number of blocks, then 
     * the first (max(axis)-min(axis)+1)%Place.numPlaces() blocks will be assigned 
     * one more coordinate than the remaining blocks.
     *
     * @param r the given region
     * @return a "block" distribution over r.
     */
    public static x10.regionarray.Dist makeBlock(final x10.regionarray.Region r) {
        
        //#line 144 "x10/regionarray/Dist.x10"
        final x10.lang.PlaceGroup pg$149324 = ((x10.lang.PlaceGroup)(x10.lang.Place.places()));
        
        //#line 189 . "x10/regionarray/Dist.x10"
        final x10.regionarray.BlockDist alloc$149325 = ((x10.regionarray.BlockDist)(new x10.regionarray.BlockDist((java.lang.System[]) null)));
        
        //#line 189 . "x10/regionarray/Dist.x10"
        alloc$149325.x10$regionarray$BlockDist$$init$S(r, ((long)(0L)), ((x10.lang.PlaceGroup)(pg$149324)));
        
        //#line 189 . "x10/regionarray/Dist.x10"
        final x10.regionarray.Dist t$149373 = ((x10.regionarray.Dist)(((x10.regionarray.Dist)
                                                                        alloc$149325)));
        
        //#line 144 "x10/regionarray/Dist.x10"
        return t$149373;
    }
    
    
    //#line 154 "x10/regionarray/Dist.x10"
    /**
     * Create a distribution over a rank-1 region that maps every
     * point in the region to a place in pg, and which maps some
     * point in the region to every place in ps.
     *
     * @param pg the set of places
     * @return a "unique" distribution over the places in ps
     */
    public static x10.regionarray.Dist makeUnique(final x10.lang.PlaceGroup pg) {
        
        //#line 155 "x10/regionarray/Dist.x10"
        final x10.lang.PlaceGroup t$149374 = ((x10.lang.PlaceGroup)(x10.lang.Place.places()));
        
        //#line 155 "x10/regionarray/Dist.x10"
        final boolean t$149381 = pg.equals(((java.lang.Object)(t$149374)));
        
        //#line 155 "x10/regionarray/Dist.x10"
        if (t$149381) {
            
            //#line 156 "x10/regionarray/Dist.x10"
            final x10.regionarray.Dist t$149375 = ((x10.regionarray.Dist)(x10.regionarray.Dist.makeUnique()));
            
            //#line 156 "x10/regionarray/Dist.x10"
            return t$149375;
        } else {
            
            //#line 158 "x10/regionarray/Dist.x10"
            final x10.regionarray.UniqueDist alloc$144497 = ((x10.regionarray.UniqueDist)(new x10.regionarray.UniqueDist((java.lang.System[]) null)));
            
            //#line 158 "x10/regionarray/Dist.x10"
            alloc$144497.x10$regionarray$UniqueDist$$init$S(((x10.lang.PlaceGroup)(pg)));
            
            //#line 158 "x10/regionarray/Dist.x10"
            final x10.regionarray.Dist t$143728 = ((x10.regionarray.Dist)
                                                    alloc$144497);
            
            //#line 158 "x10/regionarray/Dist.x10"
            final x10.regionarray.Region t$149376 = ((x10.regionarray.Region)(t$143728.region));
            
            //#line 158 "x10/regionarray/Dist.x10"
            final long t$149377 = t$149376.rank;
            
            //#line 158 "x10/regionarray/Dist.x10"
            final boolean t$149378 = ((long) t$149377) == ((long) 1L);
            
            //#line 158 "x10/regionarray/Dist.x10"
            final boolean t$149380 = !(t$149378);
            
            //#line 158 "x10/regionarray/Dist.x10"
            if (t$149380) {
                
                //#line 158 "x10/regionarray/Dist.x10"
                final x10.lang.FailedDynamicCheckException t$149379 = new x10.lang.FailedDynamicCheckException("x10.regionarray.Dist{self.region.rank==1L}");
                
                //#line 158 "x10/regionarray/Dist.x10"
                throw t$149379;
            }
            
            //#line 158 "x10/regionarray/Dist.x10"
            return t$143728;
        }
    }
    
    
    //#line 170 "x10/regionarray/Dist.x10"
    /**
     * Create a distribution over the specified region that maps
     * every point in the region to the specified place.
     *
     * @param r the given region
     * @param p the given place
     * @return a "constant" distribution over r that maps to p.
     */
    public static x10.regionarray.Dist makeConstant(final x10.regionarray.Region r, final x10.lang.Place p) {
        
        //#line 171 "x10/regionarray/Dist.x10"
        final x10.regionarray.ConstantDist alloc$144498 = ((x10.regionarray.ConstantDist)(new x10.regionarray.ConstantDist((java.lang.System[]) null)));
        
        //#line 171 "x10/regionarray/Dist.x10"
        alloc$144498.x10$regionarray$ConstantDist$$init$S(((x10.regionarray.Region)(r)), ((x10.lang.Place)(p)));
        
        //#line 171 "x10/regionarray/Dist.x10"
        return alloc$144498;
    }
    
    
    //#line 188 "x10/regionarray/Dist.x10"
    /**
     * Create a distribution over the specified region that varies in
     * place only along the specified axis. It divides the coordinates
     * along that axis into pg.numPlaces() blocks, and assigns successive
     * blocks to successive places in pg. If the number of coordinates
     * in the axis does not divide evenly into the number of places in pg, then 
     * the first (max(axis)-min(axis)+1)%pg.numPlaces() blocks will be assigned 
     * one more coordinate than the remaining blocks.
     *
     * @param r the given region
     * @param axis the dimension to block over
     * @param pg the PlaceGroup over which to distribute the region
     * @return a "block" distribution over r, blocking over the places in ps.
     */
    public static x10.regionarray.Dist makeBlock(final x10.regionarray.Region r, final long axis, final x10.lang.PlaceGroup pg) {
        
        //#line 189 "x10/regionarray/Dist.x10"
        final x10.regionarray.BlockDist alloc$144499 = ((x10.regionarray.BlockDist)(new x10.regionarray.BlockDist((java.lang.System[]) null)));
        
        //#line 189 "x10/regionarray/Dist.x10"
        alloc$144499.x10$regionarray$BlockDist$$init$S(((x10.regionarray.Region)(r)), ((long)(axis)), ((x10.lang.PlaceGroup)(pg)));
        
        //#line 189 "x10/regionarray/Dist.x10"
        return alloc$144499;
    }
    
    
    //#line 199 "x10/regionarray/Dist.x10"
    /**
     * The PlaceGroup over which the distribuiton is defined
     */
    abstract public x10.lang.PlaceGroup places();
    
    
    //#line 204 "x10/regionarray/Dist.x10"
    /**
     * How many places are included in the distribution?
     */
    abstract public long numPlaces$O();
    
    
    //#line 210 "x10/regionarray/Dist.x10"
    /**
     * @return an object that implements Iterable[Region] that can be used to
     *         iterate over the set of Regions that this distribution maps some point to.
     */
    abstract public x10.lang.Iterable regions();
    
    
    //#line 219 "x10/regionarray/Dist.x10"
    /**
     * Return the region consisting of points which this distribution
     * maps to the specified place.
     *
     * @param p the given place
     * @return the region that this distribution maps to p.
     */
    abstract public x10.regionarray.Region get(final x10.lang.Place p);
    
    
    //#line 228 "x10/regionarray/Dist.x10"
    /**
     * Return the region consisting of points which this distribution
     * maps to the specified place.  This is a shorthave for get(p).
     *
     * @param p the given place
     * @return the region that this distribution maps to p.
     */
    public x10.regionarray.Region $apply(final x10.lang.Place p) {
        
        //#line 228 "x10/regionarray/Dist.x10"
        final x10.regionarray.Region t$149382 = ((x10.regionarray.Region)(this.get(((x10.lang.Place)(p)))));
        
        //#line 228 "x10/regionarray/Dist.x10"
        return t$149382;
    }
    
    
    //#line 242 "x10/regionarray/Dist.x10"
    /**
     * Return the place which this distribution maps the specified point to.
     *
     * @param pt the given point
     * @return the place that this distribution maps pt to.
     */
    abstract public x10.lang.Place $apply(final x10.lang.Point pt);
    
    
    //#line 253 "x10/regionarray/Dist.x10"
    /**
     * Return the place which this distribution maps the specified index to.
     * Only applies to one-dimensional distributions.
     * Functionally equivalent to indexing the distribution via a one-dimensional point.
     *
     * @param i0 the given index in the first dimension
     * @return the place that this distribution maps the given index to.
     * @see #operator(Point)
     */
    public x10.lang.Place $apply(final long i0) {
        
        //#line 151 . "x10/lang/Point.x10"
        final x10.lang.Point alloc$149330 = ((x10.lang.Point)(new x10.lang.Point((java.lang.System[]) null)));
        
        //#line 151 . "x10/lang/Point.x10"
        alloc$149330.x10$lang$Point$$init$S(i0);
        
        //#line 253 "x10/regionarray/Dist.x10"
        final x10.lang.Place t$149385 = this.$apply(((x10.lang.Point)(alloc$149330)));
        
        //#line 253 "x10/regionarray/Dist.x10"
        return t$149385;
    }
    
    
    //#line 265 "x10/regionarray/Dist.x10"
    /**
     * Return the place which this distribution maps the specified pair of indices to.
     * Only applies to two-dimensional distributions.
     * Functionally equivalent to indexing the distribution via a two-dimensional point.
     *
     * @param i0 the given index in the first dimension
     * @param i1 the given index in the second dimension
     * @return the place that this distribution maps the given pair of indices to.
     * @see #operator(Point)
     */
    public x10.lang.Place $apply(final long i0, final long i1) {
        
        //#line 152 . "x10/lang/Point.x10"
        final x10.lang.Point alloc$149336 = ((x10.lang.Point)(new x10.lang.Point((java.lang.System[]) null)));
        
        //#line 152 . "x10/lang/Point.x10"
        alloc$149336.x10$lang$Point$$init$S(i0, i1);
        
        //#line 265 "x10/regionarray/Dist.x10"
        final x10.lang.Place t$149388 = this.$apply(((x10.lang.Point)(alloc$149336)));
        
        //#line 265 "x10/regionarray/Dist.x10"
        return t$149388;
    }
    
    
    //#line 278 "x10/regionarray/Dist.x10"
    /**
     * Return the place which this distribution maps the specified triple of indices to.
     * Only applies to three-dimensional distributions.
     * Functionally equivalent to indexing the distribution via a three-dimensional point.
     *
     * @param i0 the given index in the first dimension
     * @param i1 the given index in the second dimension
     * @param i2 the given index in the third dimension
     * @return the place that this distribution maps the given triple of indices to.
     * @see #operator(Point)
     */
    public x10.lang.Place $apply(final long i0, final long i1, final long i2) {
        
        //#line 153 . "x10/lang/Point.x10"
        final x10.lang.Point alloc$149343 = ((x10.lang.Point)(new x10.lang.Point((java.lang.System[]) null)));
        
        //#line 153 . "x10/lang/Point.x10"
        alloc$149343.x10$lang$Point$$init$S(i0, i1, i2);
        
        //#line 278 "x10/regionarray/Dist.x10"
        final x10.lang.Place t$149391 = this.$apply(((x10.lang.Point)(alloc$149343)));
        
        //#line 278 "x10/regionarray/Dist.x10"
        return t$149391;
    }
    
    
    //#line 292 "x10/regionarray/Dist.x10"
    /**
     * Return the place which this distribution maps the specified quartet of indices to.
     * Only applies to four-dimensional distributions.
     * Functionally equivalent to indexing the distribution via a four-dimensional point.
     *
     * @param i0 the given index in the first dimension
     * @param i1 the given index in the second dimension
     * @param i2 the given index in the third dimension
     * @param i3 the given index in the fourth dimension
     * @return the place that this distribution maps the given quartet of indices to.
     * @see #operator(Point)
     */
    public x10.lang.Place $apply(final long i0, final long i1, final long i2, final long i3) {
        
        //#line 154 . "x10/lang/Point.x10"
        final x10.lang.Point alloc$149351 = ((x10.lang.Point)(new x10.lang.Point((java.lang.System[]) null)));
        
        //#line 154 . "x10/lang/Point.x10"
        alloc$149351.x10$lang$Point$$init$S(i0, i1, i2, i3);
        
        //#line 292 "x10/regionarray/Dist.x10"
        final x10.lang.Place t$149394 = this.$apply(((x10.lang.Point)(alloc$149351)));
        
        //#line 292 "x10/regionarray/Dist.x10"
        return t$149394;
    }
    
    
    //#line 308 "x10/regionarray/Dist.x10"
    /**
     * Return an iterator for the underlying region of this distribution.
     * Supports the syntax
     *
     *   (for p:Point in d)
     *       ... p ...
     *
     * @return an iterator over the points in the region of this distribution.
     * @see x10.lang.Iterable[T]#iterator()
     */
    public x10.lang.Iterator iterator() {
        
        //#line 308 "x10/regionarray/Dist.x10"
        final x10.regionarray.Region t$149395 = ((x10.regionarray.Region)(this.region));
        
        //#line 308 "x10/regionarray/Dist.x10"
        final x10.lang.Iterator t$149396 = t$149395.iterator();
        
        //#line 308 "x10/regionarray/Dist.x10"
        return t$149396;
    }
    
    
    //#line 345 "x10/regionarray/Dist.x10"
    /**
     * Return the distribution defined over r, which must be
     * contained in this.region, and which maps every point in its
     * region to the same place as this distribution.
     * Functionally equivalent to {@link #intersection(Region)}.
     *
     * @param r the given region
     * @return the restriction of this distribution to r.
     */
    abstract public x10.regionarray.Dist restriction(final x10.regionarray.Region r);
    
    
    //#line 360 "x10/regionarray/Dist.x10"
    /**
     * Return true iff that.region is contained in this.region, and
     * that distribution maps every point to the same place as this
     * distribution.
     *
     * @param that the given distribution
     * @return true if that is a sub-distribution of this distribution.
     */
    public boolean isSubdistribution$O(final x10.regionarray.Dist that) {
        
        //#line 361 "x10/regionarray/Dist.x10"
        final x10.lang.PlaceGroup t$149484 = ((x10.lang.PlaceGroup)(x10.lang.Place.places()));
        
        //#line 361 "x10/regionarray/Dist.x10"
        final x10.lang.Iterator p$149485 = t$149484.iterator();
        
        //#line 361 "x10/regionarray/Dist.x10"
        for (;
             true;
             ) {
            
            //#line 361 "x10/regionarray/Dist.x10"
            final boolean t$149486 = ((x10.lang.Iterator<x10.lang.Place>)p$149485).hasNext$O();
            
            //#line 361 "x10/regionarray/Dist.x10"
            if (!(t$149486)) {
                
                //#line 361 "x10/regionarray/Dist.x10"
                break;
            }
            
            //#line 361 "x10/regionarray/Dist.x10"
            final x10.lang.Place p$149479 = ((x10.lang.Iterator<x10.lang.Place>)p$149485).next$G();
            
            //#line 362 "x10/regionarray/Dist.x10"
            final x10.regionarray.Region t$149480 = ((x10.regionarray.Region)(that.get(((x10.lang.Place)(p$149479)))));
            
            //#line 362 "x10/regionarray/Dist.x10"
            final x10.regionarray.Region t$149481 = ((x10.regionarray.Region)(this.get(((x10.lang.Place)(p$149479)))));
            
            //#line 362 "x10/regionarray/Dist.x10"
            final boolean t$149482 = t$149480.contains$O(((x10.regionarray.Region)(t$149481)));
            
            //#line 362 "x10/regionarray/Dist.x10"
            final boolean t$149483 = !(t$149482);
            
            //#line 362 "x10/regionarray/Dist.x10"
            if (t$149483) {
                
                //#line 363 "x10/regionarray/Dist.x10"
                return false;
            }
        }
        
        //#line 364 "x10/regionarray/Dist.x10"
        return true;
    }
    
    
    //#line 419 "x10/regionarray/Dist.x10"
    /**
     * Return true iff that is a distribution and both distributions are defined
     * over equal regions and place groups, and map every point in said region to 
     * the same place.
     *
     * @param that the given distribution
     * @return true if that is equal to this distribution.
     */
    public boolean equals(final java.lang.Object thatObj) {
        
        //#line 420 "x10/regionarray/Dist.x10"
        final boolean t$149404 = x10.rtt.Equality.equalsequals((this),(thatObj));
        
        //#line 420 "x10/regionarray/Dist.x10"
        if (t$149404) {
            
            //#line 420 "x10/regionarray/Dist.x10"
            return true;
        }
        
        //#line 421 "x10/regionarray/Dist.x10"
        final boolean t$149405 = x10.regionarray.Dist.$RTT.isInstance(thatObj);
        
        //#line 421 "x10/regionarray/Dist.x10"
        final boolean t$149406 = !(t$149405);
        
        //#line 421 "x10/regionarray/Dist.x10"
        if (t$149406) {
            
            //#line 421 "x10/regionarray/Dist.x10"
            return false;
        }
        
        //#line 422 "x10/regionarray/Dist.x10"
        final x10.regionarray.Dist that = ((x10.regionarray.Dist)(x10.rtt.Types.<x10.regionarray.Dist> cast(thatObj,x10.regionarray.Dist.$RTT)));
        
        //#line 423 "x10/regionarray/Dist.x10"
        final x10.regionarray.Dist this$149353 = ((x10.regionarray.Dist)(this));
        
        //#line 38 . "x10/regionarray/Dist.x10"
        final x10.regionarray.Region t$149407 = ((x10.regionarray.Region)(this$149353.region));
        
        //#line 38 . "x10/regionarray/Dist.x10"
        final long t$149409 = t$149407.rank;
        
        //#line 38 . "x10/regionarray/Dist.x10"
        final x10.regionarray.Region t$149408 = ((x10.regionarray.Region)(that.region));
        
        //#line 38 . "x10/regionarray/Dist.x10"
        final long t$149410 = t$149408.rank;
        
        //#line 423 "x10/regionarray/Dist.x10"
        final boolean t$149411 = ((long) t$149409) != ((long) t$149410);
        
        //#line 423 "x10/regionarray/Dist.x10"
        if (t$149411) {
            
            //#line 423 "x10/regionarray/Dist.x10"
            return false;
        }
        
        //#line 424 "x10/regionarray/Dist.x10"
        final x10.regionarray.Region t$149412 = ((x10.regionarray.Region)(this.region));
        
        //#line 424 "x10/regionarray/Dist.x10"
        final x10.regionarray.Region t$149413 = ((x10.regionarray.Region)(that.region));
        
        //#line 424 "x10/regionarray/Dist.x10"
        final boolean t$149414 = t$149412.equals(((java.lang.Object)(t$149413)));
        
        //#line 424 "x10/regionarray/Dist.x10"
        final boolean t$149415 = !(t$149414);
        
        //#line 424 "x10/regionarray/Dist.x10"
        if (t$149415) {
            
            //#line 424 "x10/regionarray/Dist.x10"
            return false;
        }
        
        //#line 425 "x10/regionarray/Dist.x10"
        final x10.lang.PlaceGroup pg = this.places();
        
        //#line 426 "x10/regionarray/Dist.x10"
        final x10.lang.Iterator p$149492 = pg.iterator();
        
        //#line 426 "x10/regionarray/Dist.x10"
        for (;
             true;
             ) {
            
            //#line 426 "x10/regionarray/Dist.x10"
            final boolean t$149493 = ((x10.lang.Iterator<x10.lang.Place>)p$149492).hasNext$O();
            
            //#line 426 "x10/regionarray/Dist.x10"
            if (!(t$149493)) {
                
                //#line 426 "x10/regionarray/Dist.x10"
                break;
            }
            
            //#line 426 "x10/regionarray/Dist.x10"
            final x10.lang.Place p$149487 = ((x10.lang.Place)(((x10.lang.Iterator<x10.lang.Place>)p$149492).next$G()));
            
            //#line 427 "x10/regionarray/Dist.x10"
            final x10.regionarray.Region t$149488 = ((x10.regionarray.Region)(this.get(((x10.lang.Place)(p$149487)))));
            
            //#line 427 "x10/regionarray/Dist.x10"
            final x10.regionarray.Region t$149489 = ((x10.regionarray.Region)(that.get(((x10.lang.Place)(p$149487)))));
            
            //#line 427 "x10/regionarray/Dist.x10"
            final boolean t$149490 = t$149488.equals(((java.lang.Object)(t$149489)));
            
            //#line 427 "x10/regionarray/Dist.x10"
            final boolean t$149491 = !(t$149490);
            
            //#line 427 "x10/regionarray/Dist.x10"
            if (t$149491) {
                
                //#line 427 "x10/regionarray/Dist.x10"
                return false;
            }
        }
        
        //#line 429 "x10/regionarray/Dist.x10"
        return true;
    }
    
    
    //#line 443 "x10/regionarray/Dist.x10"
    /**
     * Return the distribution restricted to those points which it
     * maps to the specified place.
     *
     * @param p the given place
     * @return the portion of this distribution that maps to p.
     */
    abstract public x10.regionarray.Dist restriction(final x10.lang.Place p);
    
    
    //#line 451 "x10/regionarray/Dist.x10"
    /**
     * Return true iff this.region contains p.
     *
     * @param p the given point
     * @return true if this distribution contains p.
     */
    public boolean contains$O(final x10.lang.Point p) {
        
        //#line 451 "x10/regionarray/Dist.x10"
        final x10.regionarray.Region t$149422 = ((x10.regionarray.Region)(this.region));
        
        //#line 451 "x10/regionarray/Dist.x10"
        final boolean t$149423 = t$149422.contains$O(((x10.lang.Point)(p)));
        
        //#line 451 "x10/regionarray/Dist.x10"
        return t$149423;
    }
    
    
    //#line 459 "x10/regionarray/Dist.x10"
    /**
     * Returns true iff this.region contains p and
     * the distribution maps p to here.
     * This method is intended to be overriden in subclasses
     * that can provide more efficient implementations of this operation.
     */
    public boolean containsLocally$O(final x10.lang.Point p) {
        
        //#line 459 "x10/regionarray/Dist.x10"
        boolean t$149425 = this.contains$O(((x10.lang.Point)(p)));
        
        //#line 459 "x10/regionarray/Dist.x10"
        if (t$149425) {
            
            //#line 459 "x10/regionarray/Dist.x10"
            final x10.regionarray.Region t$149424 = ((x10.regionarray.Region)(this.$apply(((x10.lang.Place)(x10.x10rt.X10RT.here())))));
            
            //#line 459 "x10/regionarray/Dist.x10"
            t$149425 = t$149424.contains$O(((x10.lang.Point)(p)));
        }
        
        //#line 459 "x10/regionarray/Dist.x10"
        return t$149425;
    }
    
    
    //#line 471 "x10/regionarray/Dist.x10"
    /**
     * Restrict this distribution to the specified region.
     *
     * @param r the given region
     * @return the restriction of this distribution to r.
     */
    public x10.regionarray.Dist $bar(final x10.regionarray.Region r) {
        
        //#line 472 "x10/regionarray/Dist.x10"
        final x10.regionarray.Dist t$149427 = ((x10.regionarray.Dist)(this.restriction(((x10.regionarray.Region)(r)))));
        
        //#line 472 "x10/regionarray/Dist.x10"
        return t$149427;
    }
    
    
    //#line 480 "x10/regionarray/Dist.x10"
    /**
     * Restrict this distribution to the specified place.
     *
     * @param p the given place
     * @return the region that this distribution maps to p.
     */
    public x10.regionarray.Dist $bar(final x10.lang.Place p) {
        
        //#line 480 "x10/regionarray/Dist.x10"
        final x10.regionarray.Dist t$149428 = ((x10.regionarray.Dist)(this.restriction(((x10.lang.Place)(p)))));
        
        //#line 480 "x10/regionarray/Dist.x10"
        return t$149428;
    }
    
    
    //#line 522 "x10/regionarray/Dist.x10"
    /** 
     * @param ghostWidth the width of the ghost region in all dimensions
     * @param periodic whether periodic boundary conditions apply
     * @return a ghost manager for this distribution at the current place 
     */
    public x10.regionarray.GhostManager getLocalGhostManager(final long ghostWidth, final boolean periodic) {
        
        //#line 523 "x10/regionarray/Dist.x10"
        final java.lang.String t$149429 = x10.rtt.Types.typeName(this);
        
        //#line 523 "x10/regionarray/Dist.x10"
        final java.lang.String t$149430 = (("") + (t$149429));
        
        //#line 523 "x10/regionarray/Dist.x10"
        final java.lang.String t$149431 = ((t$149430) + (".getLocalGhostManager()"));
        
        //#line 523 "x10/regionarray/Dist.x10"
        final java.lang.UnsupportedOperationException t$149432 = ((java.lang.UnsupportedOperationException)(new java.lang.UnsupportedOperationException(t$149431)));
        
        //#line 523 "x10/regionarray/Dist.x10"
        throw t$149432;
    }
    
    
    //#line 526 "x10/regionarray/Dist.x10"
    public java.lang.String toString() {
        
        //#line 527 "x10/regionarray/Dist.x10"
        java.lang.String s = "Dist(";
        
        //#line 528 "x10/regionarray/Dist.x10"
        boolean first = true;
        
        //#line 529 "x10/regionarray/Dist.x10"
        final x10.lang.PlaceGroup t$149506 = this.places();
        
        //#line 529 "x10/regionarray/Dist.x10"
        final x10.lang.Iterator p$149507 = t$149506.iterator();
        
        //#line 529 "x10/regionarray/Dist.x10"
        for (;
             true;
             ) {
            
            //#line 529 "x10/regionarray/Dist.x10"
            final boolean t$149508 = ((x10.lang.Iterator<x10.lang.Place>)p$149507).hasNext$O();
            
            //#line 529 "x10/regionarray/Dist.x10"
            if (!(t$149508)) {
                
                //#line 529 "x10/regionarray/Dist.x10"
                break;
            }
            
            //#line 529 "x10/regionarray/Dist.x10"
            final x10.lang.Place p$149494 = ((x10.lang.Iterator<x10.lang.Place>)p$149507).next$G();
            
            //#line 530 "x10/regionarray/Dist.x10"
            final boolean t$149496 = !(first);
            
            //#line 530 "x10/regionarray/Dist.x10"
            if (t$149496) {
                
                //#line 530 "x10/regionarray/Dist.x10"
                final java.lang.String t$149498 = ((s) + (","));
                
                //#line 530 "x10/regionarray/Dist.x10"
                s = ((java.lang.String)(t$149498));
            }
            
            //#line 531 "x10/regionarray/Dist.x10"
            final x10.regionarray.Region t$149500 = ((x10.regionarray.Region)(this.get(((x10.lang.Place)(p$149494)))));
            
            //#line 531 "x10/regionarray/Dist.x10"
            final java.lang.String t$149501 = (("") + (t$149500));
            
            //#line 531 "x10/regionarray/Dist.x10"
            final java.lang.String t$149502 = ((t$149501) + ("->"));
            
            //#line 531 "x10/regionarray/Dist.x10"
            final long t$149503 = p$149494.id;
            
            //#line 531 "x10/regionarray/Dist.x10"
            final java.lang.String t$149504 = ((t$149502) + ((x10.core.Long.$box(t$149503))));
            
            //#line 531 "x10/regionarray/Dist.x10"
            final java.lang.String t$149505 = ((s) + (t$149504));
            
            //#line 531 "x10/regionarray/Dist.x10"
            s = ((java.lang.String)(t$149505));
            
            //#line 532 "x10/regionarray/Dist.x10"
            first = false;
        }
        
        //#line 534 "x10/regionarray/Dist.x10"
        final java.lang.String t$149448 = ((s) + (")"));
        
        //#line 534 "x10/regionarray/Dist.x10"
        s = ((java.lang.String)(t$149448));
        
        //#line 535 "x10/regionarray/Dist.x10"
        return s;
    }
    
    
    //#line 547 "x10/regionarray/Dist.x10"
    /**
     * Construct a distribution over the specified region.
     *
     * @param region the given region
     */
    
    // constructor for non-virtual call
    final public x10.regionarray.Dist x10$regionarray$Dist$$init$S(final x10.regionarray.Region region) {
         {
            
            //#line 548 "x10/regionarray/Dist.x10"
            this.region = region;
            
        }
        return this;
    }
    
    
    
    //#line 551 "x10/regionarray/Dist.x10"
    public static void raiseBoundsError(final long i0) {
        
        //#line 552 "x10/regionarray/Dist.x10"
        final java.lang.String t$149450 = (("point (") + ((x10.core.Long.$box(i0))));
        
        //#line 552 "x10/regionarray/Dist.x10"
        final java.lang.String t$149451 = ((t$149450) + (") not contained in distribution"));
        
        //#line 552 "x10/regionarray/Dist.x10"
        final java.lang.ArrayIndexOutOfBoundsException t$149452 = ((java.lang.ArrayIndexOutOfBoundsException)(new java.lang.ArrayIndexOutOfBoundsException(t$149451)));
        
        //#line 552 "x10/regionarray/Dist.x10"
        throw t$149452;
    }
    
    
    //#line 554 "x10/regionarray/Dist.x10"
    public static void raiseBoundsError(final long i0, final long i1) {
        
        //#line 555 "x10/regionarray/Dist.x10"
        final java.lang.String t$149453 = (("point (") + ((x10.core.Long.$box(i0))));
        
        //#line 555 "x10/regionarray/Dist.x10"
        final java.lang.String t$149454 = ((t$149453) + (", "));
        
        //#line 555 "x10/regionarray/Dist.x10"
        final java.lang.String t$149455 = ((t$149454) + ((x10.core.Long.$box(i1))));
        
        //#line 555 "x10/regionarray/Dist.x10"
        final java.lang.String t$149456 = ((t$149455) + (") not contained in distribution"));
        
        //#line 555 "x10/regionarray/Dist.x10"
        final java.lang.ArrayIndexOutOfBoundsException t$149457 = ((java.lang.ArrayIndexOutOfBoundsException)(new java.lang.ArrayIndexOutOfBoundsException(t$149456)));
        
        //#line 555 "x10/regionarray/Dist.x10"
        throw t$149457;
    }
    
    
    //#line 557 "x10/regionarray/Dist.x10"
    public static void raiseBoundsError(final long i0, final long i1, final long i2) {
        
        //#line 558 "x10/regionarray/Dist.x10"
        final java.lang.String t$149458 = (("point (") + ((x10.core.Long.$box(i0))));
        
        //#line 558 "x10/regionarray/Dist.x10"
        final java.lang.String t$149459 = ((t$149458) + (", "));
        
        //#line 558 "x10/regionarray/Dist.x10"
        final java.lang.String t$149460 = ((t$149459) + ((x10.core.Long.$box(i1))));
        
        //#line 558 "x10/regionarray/Dist.x10"
        final java.lang.String t$149461 = ((t$149460) + (", "));
        
        //#line 558 "x10/regionarray/Dist.x10"
        final java.lang.String t$149462 = ((t$149461) + ((x10.core.Long.$box(i2))));
        
        //#line 558 "x10/regionarray/Dist.x10"
        final java.lang.String t$149463 = ((t$149462) + (") not contained in distribution"));
        
        //#line 558 "x10/regionarray/Dist.x10"
        final java.lang.ArrayIndexOutOfBoundsException t$149464 = ((java.lang.ArrayIndexOutOfBoundsException)(new java.lang.ArrayIndexOutOfBoundsException(t$149463)));
        
        //#line 558 "x10/regionarray/Dist.x10"
        throw t$149464;
    }
    
    
    //#line 560 "x10/regionarray/Dist.x10"
    public static void raiseBoundsError(final long i0, final long i1, final long i2, final long i3) {
        
        //#line 561 "x10/regionarray/Dist.x10"
        final java.lang.String t$149465 = (("point (") + ((x10.core.Long.$box(i0))));
        
        //#line 561 "x10/regionarray/Dist.x10"
        final java.lang.String t$149466 = ((t$149465) + (", "));
        
        //#line 561 "x10/regionarray/Dist.x10"
        final java.lang.String t$149467 = ((t$149466) + ((x10.core.Long.$box(i1))));
        
        //#line 561 "x10/regionarray/Dist.x10"
        final java.lang.String t$149468 = ((t$149467) + (", "));
        
        //#line 561 "x10/regionarray/Dist.x10"
        final java.lang.String t$149469 = ((t$149468) + ((x10.core.Long.$box(i2))));
        
        //#line 561 "x10/regionarray/Dist.x10"
        final java.lang.String t$149470 = ((t$149469) + (", "));
        
        //#line 561 "x10/regionarray/Dist.x10"
        final java.lang.String t$149471 = ((t$149470) + ((x10.core.Long.$box(i3))));
        
        //#line 561 "x10/regionarray/Dist.x10"
        final java.lang.String t$149472 = ((t$149471) + (") not contained in distribution"));
        
        //#line 561 "x10/regionarray/Dist.x10"
        final java.lang.ArrayIndexOutOfBoundsException t$149473 = ((java.lang.ArrayIndexOutOfBoundsException)(new java.lang.ArrayIndexOutOfBoundsException(t$149472)));
        
        //#line 561 "x10/regionarray/Dist.x10"
        throw t$149473;
    }
    
    
    //#line 563 "x10/regionarray/Dist.x10"
    public static void raiseBoundsError(final x10.lang.Point pt) {
        
        //#line 564 "x10/regionarray/Dist.x10"
        final java.lang.String t$149474 = (("point ") + (pt));
        
        //#line 564 "x10/regionarray/Dist.x10"
        final java.lang.String t$149475 = ((t$149474) + (" not contained in distribution"));
        
        //#line 564 "x10/regionarray/Dist.x10"
        final java.lang.ArrayIndexOutOfBoundsException t$149476 = ((java.lang.ArrayIndexOutOfBoundsException)(new java.lang.ArrayIndexOutOfBoundsException(t$149475)));
        
        //#line 564 "x10/regionarray/Dist.x10"
        throw t$149476;
    }
    
    
    //#line 25 "x10/regionarray/Dist.x10"
    final public x10.regionarray.Dist x10$regionarray$Dist$$this$x10$regionarray$Dist() {
        
        //#line 25 "x10/regionarray/Dist.x10"
        return x10.regionarray.Dist.this;
    }
    
    
    //#line 25 "x10/regionarray/Dist.x10"
    final public void __fieldInitializers_x10_regionarray_Dist() {
        
    }
}




