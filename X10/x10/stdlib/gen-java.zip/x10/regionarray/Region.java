package x10.regionarray;


/**
 * A Region(rank) represents a set of points of class Point(rank). The
 * Region class defines a set of static factory methods for
 * constructing regions. There are properties and methods for
 * accessing basic information about of a region, such as its bounding
 * box, its size, whether or not it is convex, whether or not it is
 * empty. There are a set of methods for supporting algebraic
 * operations on regions, such as intersection, union, difference, and
 * so on. The set of points in a region may be iterated over.
 */
@x10.runtime.impl.java.X10Generated
abstract public class Region extends x10.core.Ref implements x10.lang.Iterable, x10.serialization.X10JavaSerializable
{
    public static final x10.rtt.RuntimeType<Region> $RTT = 
        x10.rtt.NamedType.<Region> make("x10.regionarray.Region",
                                        Region.class,
                                        new x10.rtt.Type[] {
                                            x10.rtt.ParameterizedType.make(x10.lang.Iterable.$RTT, x10.lang.Point.$RTT)
                                        });
    
    public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
    
    public x10.rtt.Type<?> $getParam(int i) { return null; }
    
    public static x10.serialization.X10JavaSerializable $_deserialize_body(x10.regionarray.Region $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
        $_obj.rail = $deserializer.readBoolean();
        $_obj.rank = $deserializer.readLong();
        $_obj.rect = $deserializer.readBoolean();
        $_obj.zeroBased = $deserializer.readBoolean();
        return $_obj;
    }
    
    public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
        return null;
    }
    
    public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
        $serializer.write(this.rail);
        $serializer.write(this.rank);
        $serializer.write(this.rect);
        $serializer.write(this.zeroBased);
        
    }
    
    // constructor just for allocation
    public Region(final java.lang.System[] $dummy) {
        
    }
    
    
    // properties
    
    //#line 30 "x10/regionarray/Region.x10"
    /**
     * The rank of this region.
     */
    public long rank;
    
    //#line 36 "x10/regionarray/Region.x10"
    /**
     * Is the region rectangular?
     * A rectangular region is defined to be region such that every point contained
     * in the bounding box of the region is a point in the region.
     */
    public boolean rect;
    
    //#line 41 "x10/regionarray/Region.x10"
    /**
     * Is the region zero-based?
     * A region is zero based if for each dimension the min value is 0.
     */
    public boolean zeroBased;
    
    //#line 45 "x10/regionarray/Region.x10"
    /**
     * Is the region rank 1, rectangular, and zero-based?
     */
    public boolean rail;
    

    
    
    //#line 47 "x10/regionarray/Region.x10"
    final public long rank$O() {
        
        //#line 47 "x10/regionarray/Region.x10"
        final long t$158399 = this.rank;
        
        //#line 47 "x10/regionarray/Region.x10"
        return t$158399;
    }
    
    
    //#line 48 "x10/regionarray/Region.x10"
    final public boolean rect$O() {
        
        //#line 48 "x10/regionarray/Region.x10"
        final boolean t$158400 = this.rect;
        
        //#line 48 "x10/regionarray/Region.x10"
        return t$158400;
    }
    
    
    //#line 49 "x10/regionarray/Region.x10"
    final public boolean zeroBased$O() {
        
        //#line 49 "x10/regionarray/Region.x10"
        final boolean t$158401 = this.zeroBased;
        
        //#line 49 "x10/regionarray/Region.x10"
        return t$158401;
    }
    
    
    //#line 50 "x10/regionarray/Region.x10"
    final public boolean rail$O() {
        
        //#line 50 "x10/regionarray/Region.x10"
        final boolean t$158402 = this.rail;
        
        //#line 50 "x10/regionarray/Region.x10"
        return t$158402;
    }
    
    
    //#line 60 "x10/regionarray/Region.x10"
    /**
     * Construct an empty region of the specified rank.
     */
    public static x10.regionarray.Region makeEmpty(final long rank) {
        
        //#line 60 "x10/regionarray/Region.x10"
        final x10.regionarray.EmptyRegion alloc$138951 = ((x10.regionarray.EmptyRegion)(new x10.regionarray.EmptyRegion((java.lang.System[]) null)));
        
        //#line 60 "x10/regionarray/Region.x10"
        alloc$138951.x10$regionarray$EmptyRegion$$init$S(((long)(rank)));
        
        //#line 60 "x10/regionarray/Region.x10"
        return alloc$138951;
    }
    
    
    //#line 66 "x10/regionarray/Region.x10"
    /**
     * Construct an unbounded region of a given rank that contains all
     * points of that rank.
     */
    public static x10.regionarray.Region makeFull(final long rank) {
        
        //#line 66 "x10/regionarray/Region.x10"
        final x10.regionarray.FullRegion alloc$138952 = ((x10.regionarray.FullRegion)(new x10.regionarray.FullRegion((java.lang.System[]) null)));
        
        //#line 66 "x10/regionarray/Region.x10"
        alloc$138952.x10$regionarray$FullRegion$$init$S(((long)(rank)));
        
        //#line 66 "x10/regionarray/Region.x10"
        return alloc$138952;
    }
    
    
    //#line 72 "x10/regionarray/Region.x10"
    /**
     * Construct a region of rank 0 that contains the single point of
     * rank 0. Useful as the identity region under Cartesian product.
     */
    public static x10.regionarray.Region makeUnit() {
        
        //#line 72 "x10/regionarray/Region.x10"
        final x10.regionarray.FullRegion alloc$138953 = ((x10.regionarray.FullRegion)(new x10.regionarray.FullRegion((java.lang.System[]) null)));
        
        //#line 72 "x10/regionarray/Region.x10"
        alloc$138953.x10$regionarray$FullRegion$$init$S(((long)(0L)));
        
        //#line 72 "x10/regionarray/Region.x10"
        return alloc$138953;
    }
    
    
    //#line 79 "x10/regionarray/Region.x10"
    /**
     * Construct an unbounded halfspace region of rank normal.rank
     * that consists of all points p satisfying dot(p,normal) + k <= 0.
     */
    public static x10.regionarray.Region makeHalfspace(final x10.lang.Point normal, final long k) {
        
        //#line 80 "x10/regionarray/Region.x10"
        final long rank = normal.rank;
        
        //#line 81 "x10/regionarray/Region.x10"
        final x10.regionarray.PolyMatBuilder pmb = ((x10.regionarray.PolyMatBuilder)(new x10.regionarray.PolyMatBuilder((java.lang.System[]) null)));
        
        //#line 81 "x10/regionarray/Region.x10"
        pmb.x10$regionarray$PolyMatBuilder$$init$S(((long)(rank)));
        
        //#line 82 "x10/regionarray/Region.x10"
        final x10.regionarray.PolyRow r = ((x10.regionarray.PolyRow)(new x10.regionarray.PolyRow((java.lang.System[]) null)));
        
        //#line 82 "x10/regionarray/Region.x10"
        final int t$158688 = ((int)(long)(((long)(k))));
        
        //#line 82 "x10/regionarray/Region.x10"
        r.x10$regionarray$PolyRow$$init$S(((x10.lang.Point)(normal)), t$158688);
        
        //#line 83 "x10/regionarray/Region.x10"
        pmb.add(((x10.regionarray.Row)(r)));
        
        //#line 84 "x10/regionarray/Region.x10"
        final x10.regionarray.PolyMat pm = ((x10.regionarray.PolyMat)(pmb.toSortedPolyMat((boolean)(false))));
        
        //#line 85 "x10/regionarray/Region.x10"
        final x10.regionarray.Region t$158404 = ((x10.regionarray.Region)(x10.regionarray.PolyRegion.make(((x10.regionarray.PolyMat)(pm)))));
        
        //#line 85 "x10/regionarray/Region.x10"
        return t$158404;
    }
    
    
    //#line 103 "x10/regionarray/Region.x10"
    /**
     * Returns a PolyRegion that represents the rectangular region with smallest point minArg and largest point
     * maxArg. 
     * <p> Most users of the Region API should call makeRectangular which will return a 
     * RectRegion. Methods on RectRegion automatically construct a PolyRegion (by calling makeRectangularPoly) 
     * if they need to implement operations (such as intersection, product etc) that are difficult to define
     * on a RectRegion's representation.
     * @param minArg:Rail[Long] -- specifies the smallest point in the region
     * @param maxArg:Rail[Long] -- specifies the largest point in the region (must have the same rank as minArg
     * @return A Region of rank minarg.length 
     */
    public static x10.regionarray.Region makeRectangularPoly__0$1x10$lang$Long$2__1$1x10$lang$Long$2(final x10.core.Rail<x10.core.Long> minArg, final x10.core.Rail<x10.core.Long> maxArg) {
        
        //#line 104 "x10/regionarray/Region.x10"
        final long t$158405 = ((x10.core.Rail<x10.core.Long>)minArg).size;
        
        //#line 104 "x10/regionarray/Region.x10"
        final long t$158406 = ((x10.core.Rail<x10.core.Long>)maxArg).size;
        
        //#line 104 "x10/regionarray/Region.x10"
        final boolean t$158414 = ((long) t$158405) != ((long) t$158406);
        
        //#line 104 "x10/regionarray/Region.x10"
        if (t$158414) {
            
            //#line 104 "x10/regionarray/Region.x10"
            final long t$158407 = ((x10.core.Rail<x10.core.Long>)minArg).size;
            
            //#line 104 "x10/regionarray/Region.x10"
            final java.lang.String t$158408 = (("min and max not equal size (") + ((x10.core.Long.$box(t$158407))));
            
            //#line 104 "x10/regionarray/Region.x10"
            final java.lang.String t$158409 = ((t$158408) + (" != "));
            
            //#line 104 "x10/regionarray/Region.x10"
            final long t$158410 = ((x10.core.Rail<x10.core.Long>)maxArg).size;
            
            //#line 104 "x10/regionarray/Region.x10"
            final java.lang.String t$158411 = ((t$158409) + ((x10.core.Long.$box(t$158410))));
            
            //#line 104 "x10/regionarray/Region.x10"
            final java.lang.String t$158412 = ((t$158411) + (")"));
            
            //#line 104 "x10/regionarray/Region.x10"
            final java.lang.IllegalArgumentException t$158413 = ((java.lang.IllegalArgumentException)(new java.lang.IllegalArgumentException(t$158412)));
            
            //#line 104 "x10/regionarray/Region.x10"
            throw t$158413;
        }
        
        //#line 105 "x10/regionarray/Region.x10"
        final long rank = ((x10.core.Rail<x10.core.Long>)minArg).size;
        
        //#line 106 "x10/regionarray/Region.x10"
        final x10.regionarray.PolyMatBuilder pmb = ((x10.regionarray.PolyMatBuilder)(new x10.regionarray.PolyMatBuilder((java.lang.System[]) null)));
        
        //#line 106 "x10/regionarray/Region.x10"
        pmb.x10$regionarray$PolyMatBuilder$$init$S(((long)(rank)));
        
        //#line 107 "x10/regionarray/Region.x10"
        final long i$138973max$158720 = ((rank) - (((long)(1L))));
        
        //#line 107 "x10/regionarray/Region.x10"
        long i$158717 = 0L;
        {
            
            //#line 107 "x10/regionarray/Region.x10"
            final long[] minArg$value$158816 = ((long[])minArg.value);
            
            //#line 107 "x10/regionarray/Region.x10"
            final long[] maxArg$value$158817 = ((long[])maxArg.value);
            
            //#line 107 "x10/regionarray/Region.x10"
            for (;
                 true;
                 ) {
                
                //#line 107 "x10/regionarray/Region.x10"
                final boolean t$158719 = ((i$158717) <= (((long)(i$138973max$158720))));
                
                //#line 107 "x10/regionarray/Region.x10"
                if (!(t$158719)) {
                    
                    //#line 107 "x10/regionarray/Region.x10"
                    break;
                }
                
                //#line 107 "x10/regionarray/Region.x10"
                final long i$158714 = i$158717;
                
                //#line 108 "x10/regionarray/Region.x10"
                final long t$158706 = ((long)minArg$value$158816[(int)i$158717]);
                
                //#line 108 "x10/regionarray/Region.x10"
                final long t$158707 = java.lang.Long.MIN_VALUE;
                
                //#line 108 "x10/regionarray/Region.x10"
                final boolean t$158708 = ((t$158706) > (((long)(t$158707))));
                
                //#line 108 "x10/regionarray/Region.x10"
                if (t$158708) {
                    
                    //#line 110 "x10/regionarray/Region.x10"
                    final x10.regionarray.PolyRow r$158709 = ((x10.regionarray.PolyRow)(new x10.regionarray.PolyRow((java.lang.System[]) null)));
                    
                    //#line 110 "x10/regionarray/Region.x10"
                    final x10.core.fun.Fun_0_1 t$158689 = ((x10.core.fun.Fun_0_1)(new x10.regionarray.Region.$Closure$294(i$158714)));
                    
                    //#line 110 "x10/regionarray/Region.x10"
                    final x10.lang.Point t$158694 = ((x10.lang.Point)(x10.lang.Point.make__1$1x10$lang$Long$3x10$lang$Long$2((long)(rank), ((x10.core.fun.Fun_0_1)(t$158689)))));
                    
                    //#line 110 "x10/regionarray/Region.x10"
                    final long t$158695 = ((long)minArg$value$158816[(int)i$158714]);
                    
                    //#line 110 "x10/regionarray/Region.x10"
                    final int t$158696 = ((int)(long)(((long)(t$158695))));
                    
                    //#line 110 "x10/regionarray/Region.x10"
                    r$158709.x10$regionarray$PolyRow$$init$S(((x10.lang.Point)(t$158694)), t$158696);
                    
                    //#line 111 "x10/regionarray/Region.x10"
                    pmb.add(((x10.regionarray.Row)(r$158709)));
                }
                
                //#line 113 "x10/regionarray/Region.x10"
                final long t$158710 = ((long)maxArg$value$158817[(int)i$158714]);
                
                //#line 113 "x10/regionarray/Region.x10"
                final long t$158711 = java.lang.Long.MAX_VALUE;
                
                //#line 113 "x10/regionarray/Region.x10"
                final boolean t$158712 = ((t$158710) < (((long)(t$158711))));
                
                //#line 113 "x10/regionarray/Region.x10"
                if (t$158712) {
                    
                    //#line 115 "x10/regionarray/Region.x10"
                    final x10.regionarray.PolyRow s$158713 = ((x10.regionarray.PolyRow)(new x10.regionarray.PolyRow((java.lang.System[]) null)));
                    
                    //#line 115 "x10/regionarray/Region.x10"
                    final x10.core.fun.Fun_0_1 t$158697 = ((x10.core.fun.Fun_0_1)(new x10.regionarray.Region.$Closure$295(i$158714)));
                    
                    //#line 115 "x10/regionarray/Region.x10"
                    final x10.lang.Point t$158702 = ((x10.lang.Point)(x10.lang.Point.make__1$1x10$lang$Long$3x10$lang$Long$2((long)(rank), ((x10.core.fun.Fun_0_1)(t$158697)))));
                    
                    //#line 115 "x10/regionarray/Region.x10"
                    final long t$158703 = ((long)maxArg$value$158817[(int)i$158714]);
                    
                    //#line 115 "x10/regionarray/Region.x10"
                    final int t$158704 = ((int)(long)(((long)(t$158703))));
                    
                    //#line 115 "x10/regionarray/Region.x10"
                    final int t$158705 = (-(t$158704));
                    
                    //#line 115 "x10/regionarray/Region.x10"
                    s$158713.x10$regionarray$PolyRow$$init$S(((x10.lang.Point)(t$158702)), t$158705);
                    
                    //#line 116 "x10/regionarray/Region.x10"
                    pmb.add(((x10.regionarray.Row)(s$158713)));
                }
                
                //#line 107 "x10/regionarray/Region.x10"
                final long t$158716 = ((i$158717) + (((long)(1L))));
                
                //#line 107 "x10/regionarray/Region.x10"
                i$158717 = t$158716;
            }
        }
        
        //#line 119 "x10/regionarray/Region.x10"
        final x10.regionarray.PolyMat pm = ((x10.regionarray.PolyMat)(pmb.toSortedPolyMat((boolean)(false))));
        
        //#line 120 "x10/regionarray/Region.x10"
        final x10.regionarray.Region t$158441 = ((x10.regionarray.Region)(x10.regionarray.PolyRegion.make(((x10.regionarray.PolyMat)(pm)))));
        
        //#line 120 "x10/regionarray/Region.x10"
        return t$158441;
    }
    
    
    //#line 127 "x10/regionarray/Region.x10"
    /**
     * Construct a rectangular region whose bounds are specified as
     * rails of longs.
     */
    public static x10.regionarray.Region makeRectangular__0$1x10$lang$Long$2__1$1x10$lang$Long$2(final x10.core.Rail<x10.core.Long> minArg, final x10.core.Rail<x10.core.Long> maxArg) {
        
        //#line 128 "x10/regionarray/Region.x10"
        final long t$158442 = ((x10.core.Rail<x10.core.Long>)minArg).size;
        
        //#line 128 "x10/regionarray/Region.x10"
        final boolean t$158456 = ((long) t$158442) == ((long) 1L);
        
        //#line 128 "x10/regionarray/Region.x10"
        if (t$158456) {
            
            //#line 130 "x10/regionarray/Region.x10"
            final x10.regionarray.RectRegion1D alloc$138954 = ((x10.regionarray.RectRegion1D)(new x10.regionarray.RectRegion1D((java.lang.System[]) null)));
            
            //#line 130 "x10/regionarray/Region.x10"
            final long t$158721 = ((long[])minArg.value)[(int)0L];
            
            //#line 130 "x10/regionarray/Region.x10"
            final long t$158722 = ((long[])maxArg.value)[(int)0L];
            
            //#line 130 "x10/regionarray/Region.x10"
            alloc$138954.x10$regionarray$RectRegion1D$$init$S(t$158721, t$158722);
            
            //#line 130 "x10/regionarray/Region.x10"
            final x10.regionarray.Region t$138930 = ((x10.regionarray.Region)
                                                      alloc$138954);
            
            //#line 130 "x10/regionarray/Region.x10"
            final boolean t$158445 = t$138930.rect;
            
            //#line 130 "x10/regionarray/Region.x10"
            boolean t$158448 = ((boolean) t$158445) == ((boolean) true);
            
            //#line 130 "x10/regionarray/Region.x10"
            if (t$158448) {
                
                //#line 130 "x10/regionarray/Region.x10"
                final long t$158446 = t$138930.rank;
                
                //#line 130 "x10/regionarray/Region.x10"
                final long t$158447 = ((x10.core.Rail<x10.core.Long>)minArg).size;
                
                //#line 130 "x10/regionarray/Region.x10"
                t$158448 = ((long) t$158446) == ((long) t$158447);
            }
            
            //#line 130 "x10/regionarray/Region.x10"
            final boolean t$158451 = !(t$158448);
            
            //#line 130 "x10/regionarray/Region.x10"
            if (t$158451) {
                
                //#line 130 "x10/regionarray/Region.x10"
                final x10.lang.FailedDynamicCheckException t$158450 = new x10.lang.FailedDynamicCheckException("x10.regionarray.Region{self.rect==true, self.rank==minArg.size}");
                
                //#line 130 "x10/regionarray/Region.x10"
                throw t$158450;
            }
            
            //#line 130 "x10/regionarray/Region.x10"
            return t$138930;
        } else {
            
            //#line 132 "x10/regionarray/Region.x10"
            final x10.regionarray.RectRegion alloc$138955 = ((x10.regionarray.RectRegion)(new x10.regionarray.RectRegion((java.lang.System[]) null)));
            
            //#line 132 "x10/regionarray/Region.x10"
            final long t$158723 = ((x10.core.Rail<x10.core.Long>)minArg).size;
            
            //#line 132 "x10/regionarray/Region.x10"
            final x10.core.Rail t$158724 = ((x10.core.Rail)(new x10.core.Rail<x10.core.Long>(x10.rtt.Types.LONG, ((long)(t$158723)), ((x10.core.fun.Fun_0_1)(minArg)), (x10.core.Rail.__1$1x10$lang$Long$3x10$lang$Rail$$T$2) null)));
            
            //#line 132 "x10/regionarray/Region.x10"
            final long t$158725 = ((x10.core.Rail<x10.core.Long>)maxArg).size;
            
            //#line 132 "x10/regionarray/Region.x10"
            final x10.core.Rail t$158726 = ((x10.core.Rail)(new x10.core.Rail<x10.core.Long>(x10.rtt.Types.LONG, ((long)(t$158725)), ((x10.core.fun.Fun_0_1)(maxArg)), (x10.core.Rail.__1$1x10$lang$Long$3x10$lang$Rail$$T$2) null)));
            
            //#line 132 "x10/regionarray/Region.x10"
            alloc$138955.x10$regionarray$RectRegion$$init$S(((x10.core.Rail)(t$158724)), ((x10.core.Rail)(t$158726)), (x10.regionarray.RectRegion.__0$1x10$lang$Long$2__1$1x10$lang$Long$2) null);
            
            //#line 132 "x10/regionarray/Region.x10"
            return alloc$138955;
        }
    }
    
    
    //#line 139 "x10/regionarray/Region.x10"
    /**
     * Construct a rectangular region from a Rail of IntRange that represent the min/max of each dimension.
     */
    public static x10.regionarray.Region makeRectangular__0$1x10$lang$IntRange$2(final x10.core.Rail<x10.lang.IntRange> ranges) {
        
        //#line 140 "x10/regionarray/Region.x10"
        final long t$158457 = ((x10.core.Rail<x10.lang.IntRange>)ranges).size;
        
        //#line 140 "x10/regionarray/Region.x10"
        final boolean t$158481 = ((long) t$158457) == ((long) 1L);
        
        //#line 140 "x10/regionarray/Region.x10"
        if (t$158481) {
            
            //#line 142 "x10/regionarray/Region.x10"
            final x10.regionarray.RectRegion1D alloc$138956 = ((x10.regionarray.RectRegion1D)(new x10.regionarray.RectRegion1D((java.lang.System[]) null)));
            
            //#line 142 "x10/regionarray/Region.x10"
            final x10.lang.IntRange t$158727 = ((x10.lang.IntRange[])ranges.value)[(int)0L];
            
            //#line 142 "x10/regionarray/Region.x10"
            final int t$158728 = t$158727.min;
            
            //#line 142 "x10/regionarray/Region.x10"
            final long t$158729 = ((long)(((int)(t$158728))));
            
            //#line 142 "x10/regionarray/Region.x10"
            final x10.lang.IntRange t$158730 = ((x10.lang.IntRange[])ranges.value)[(int)0L];
            
            //#line 142 "x10/regionarray/Region.x10"
            final int t$158731 = t$158730.max;
            
            //#line 142 "x10/regionarray/Region.x10"
            final long t$158732 = ((long)(((int)(t$158731))));
            
            //#line 142 "x10/regionarray/Region.x10"
            alloc$138956.x10$regionarray$RectRegion1D$$init$S(t$158729, t$158732);
            
            //#line 142 "x10/regionarray/Region.x10"
            final x10.regionarray.Region t$138932 = ((x10.regionarray.Region)
                                                      alloc$138956);
            
            //#line 142 "x10/regionarray/Region.x10"
            final boolean t$158464 = t$138932.rect;
            
            //#line 142 "x10/regionarray/Region.x10"
            boolean t$158467 = ((boolean) t$158464) == ((boolean) true);
            
            //#line 142 "x10/regionarray/Region.x10"
            if (t$158467) {
                
                //#line 142 "x10/regionarray/Region.x10"
                final long t$158465 = t$138932.rank;
                
                //#line 142 "x10/regionarray/Region.x10"
                final long t$158466 = ((x10.core.Rail<x10.lang.IntRange>)ranges).size;
                
                //#line 142 "x10/regionarray/Region.x10"
                t$158467 = ((long) t$158465) == ((long) t$158466);
            }
            
            //#line 142 "x10/regionarray/Region.x10"
            final boolean t$158470 = !(t$158467);
            
            //#line 142 "x10/regionarray/Region.x10"
            if (t$158470) {
                
                //#line 142 "x10/regionarray/Region.x10"
                final x10.lang.FailedDynamicCheckException t$158469 = new x10.lang.FailedDynamicCheckException("x10.regionarray.Region{self.rect==true, self.rank==ranges.size}");
                
                //#line 142 "x10/regionarray/Region.x10"
                throw t$158469;
            }
            
            //#line 142 "x10/regionarray/Region.x10"
            return t$138932;
        } else {
            
            //#line 144 "x10/regionarray/Region.x10"
            final long t$158474 = ((x10.core.Rail<x10.lang.IntRange>)ranges).size;
            
            //#line 144 "x10/regionarray/Region.x10"
            final x10.core.fun.Fun_0_1 t$158475 = ((x10.core.fun.Fun_0_1)(new x10.regionarray.Region.$Closure$296(ranges, (x10.regionarray.Region.$Closure$296.__0$1x10$lang$IntRange$2) null)));
            
            //#line 144 "x10/regionarray/Region.x10"
            final x10.core.Rail mins = ((x10.core.Rail)(new x10.core.Rail<x10.core.Long>(x10.rtt.Types.LONG, ((long)(t$158474)), ((x10.core.fun.Fun_0_1)(t$158475)), (x10.core.Rail.__1$1x10$lang$Long$3x10$lang$Rail$$T$2) null)));
            
            //#line 145 "x10/regionarray/Region.x10"
            final long t$158479 = ((x10.core.Rail<x10.lang.IntRange>)ranges).size;
            
            //#line 145 "x10/regionarray/Region.x10"
            final x10.core.fun.Fun_0_1 t$158480 = ((x10.core.fun.Fun_0_1)(new x10.regionarray.Region.$Closure$297(ranges, (x10.regionarray.Region.$Closure$297.__0$1x10$lang$IntRange$2) null)));
            
            //#line 145 "x10/regionarray/Region.x10"
            final x10.core.Rail maxs = ((x10.core.Rail)(new x10.core.Rail<x10.core.Long>(x10.rtt.Types.LONG, ((long)(t$158479)), ((x10.core.fun.Fun_0_1)(t$158480)), (x10.core.Rail.__1$1x10$lang$Long$3x10$lang$Rail$$T$2) null)));
            
            //#line 146 "x10/regionarray/Region.x10"
            final x10.regionarray.RectRegion alloc$138957 = ((x10.regionarray.RectRegion)(new x10.regionarray.RectRegion((java.lang.System[]) null)));
            
            //#line 146 "x10/regionarray/Region.x10"
            alloc$138957.x10$regionarray$RectRegion$$init$S(((x10.core.Rail)(mins)), ((x10.core.Rail)(maxs)), (x10.regionarray.RectRegion.__0$1x10$lang$Long$2__1$1x10$lang$Long$2) null);
            
            //#line 146 "x10/regionarray/Region.x10"
            return alloc$138957;
        }
    }
    
    
    //#line 152 "x10/regionarray/Region.x10"
    /**
     * Construct a rectangular region from a Rail of IntRange that represent the min/max of each dimension.
     */
    public static x10.regionarray.Region make__0$1x10$lang$IntRange$2(final x10.core.Rail<x10.lang.IntRange> ranges) {
        
        //#line 152 "x10/regionarray/Region.x10"
        final x10.regionarray.Region t$158482 = ((x10.regionarray.Region)(x10.regionarray.Region.makeRectangular__0$1x10$lang$IntRange$2(((x10.core.Rail)(ranges)))));
        
        //#line 152 "x10/regionarray/Region.x10"
        return t$158482;
    }
    
    
    //#line 157 "x10/regionarray/Region.x10"
    /**
     * Construct a rectangular region from a Rail of LongRange that represent the min/max of each dimension.
     */
    public static x10.regionarray.Region makeRectangular__0$1x10$lang$LongRange$2(final x10.core.Rail<x10.lang.LongRange> ranges) {
        
        //#line 158 "x10/regionarray/Region.x10"
        final long t$158483 = ((x10.core.Rail<x10.lang.LongRange>)ranges).size;
        
        //#line 158 "x10/regionarray/Region.x10"
        final boolean t$158503 = ((long) t$158483) == ((long) 1L);
        
        //#line 158 "x10/regionarray/Region.x10"
        if (t$158503) {
            
            //#line 160 "x10/regionarray/Region.x10"
            final x10.regionarray.RectRegion1D alloc$138958 = ((x10.regionarray.RectRegion1D)(new x10.regionarray.RectRegion1D((java.lang.System[]) null)));
            
            //#line 160 "x10/regionarray/Region.x10"
            final x10.lang.LongRange t$158733 = ((x10.lang.LongRange[])ranges.value)[(int)0L];
            
            //#line 160 "x10/regionarray/Region.x10"
            final long t$158734 = t$158733.min;
            
            //#line 160 "x10/regionarray/Region.x10"
            final x10.lang.LongRange t$158735 = ((x10.lang.LongRange[])ranges.value)[(int)0L];
            
            //#line 160 "x10/regionarray/Region.x10"
            final long t$158736 = t$158735.max;
            
            //#line 160 "x10/regionarray/Region.x10"
            alloc$138958.x10$regionarray$RectRegion1D$$init$S(t$158734, t$158736);
            
            //#line 160 "x10/regionarray/Region.x10"
            final x10.regionarray.Region t$138934 = ((x10.regionarray.Region)
                                                      alloc$138958);
            
            //#line 160 "x10/regionarray/Region.x10"
            final boolean t$158488 = t$138934.rect;
            
            //#line 160 "x10/regionarray/Region.x10"
            boolean t$158491 = ((boolean) t$158488) == ((boolean) true);
            
            //#line 160 "x10/regionarray/Region.x10"
            if (t$158491) {
                
                //#line 160 "x10/regionarray/Region.x10"
                final long t$158489 = t$138934.rank;
                
                //#line 160 "x10/regionarray/Region.x10"
                final long t$158490 = ((x10.core.Rail<x10.lang.LongRange>)ranges).size;
                
                //#line 160 "x10/regionarray/Region.x10"
                t$158491 = ((long) t$158489) == ((long) t$158490);
            }
            
            //#line 160 "x10/regionarray/Region.x10"
            final boolean t$158494 = !(t$158491);
            
            //#line 160 "x10/regionarray/Region.x10"
            if (t$158494) {
                
                //#line 160 "x10/regionarray/Region.x10"
                final x10.lang.FailedDynamicCheckException t$158493 = new x10.lang.FailedDynamicCheckException("x10.regionarray.Region{self.rect==true, self.rank==ranges.size}");
                
                //#line 160 "x10/regionarray/Region.x10"
                throw t$158493;
            }
            
            //#line 160 "x10/regionarray/Region.x10"
            return t$138934;
        } else {
            
            //#line 162 "x10/regionarray/Region.x10"
            final long t$158497 = ((x10.core.Rail<x10.lang.LongRange>)ranges).size;
            
            //#line 162 "x10/regionarray/Region.x10"
            final x10.core.fun.Fun_0_1 t$158498 = ((x10.core.fun.Fun_0_1)(new x10.regionarray.Region.$Closure$298(ranges, (x10.regionarray.Region.$Closure$298.__0$1x10$lang$LongRange$2) null)));
            
            //#line 162 "x10/regionarray/Region.x10"
            final x10.core.Rail mins = ((x10.core.Rail)(new x10.core.Rail<x10.core.Long>(x10.rtt.Types.LONG, ((long)(t$158497)), ((x10.core.fun.Fun_0_1)(t$158498)), (x10.core.Rail.__1$1x10$lang$Long$3x10$lang$Rail$$T$2) null)));
            
            //#line 163 "x10/regionarray/Region.x10"
            final long t$158501 = ((x10.core.Rail<x10.lang.LongRange>)ranges).size;
            
            //#line 163 "x10/regionarray/Region.x10"
            final x10.core.fun.Fun_0_1 t$158502 = ((x10.core.fun.Fun_0_1)(new x10.regionarray.Region.$Closure$299(ranges, (x10.regionarray.Region.$Closure$299.__0$1x10$lang$LongRange$2) null)));
            
            //#line 163 "x10/regionarray/Region.x10"
            final x10.core.Rail maxs = ((x10.core.Rail)(new x10.core.Rail<x10.core.Long>(x10.rtt.Types.LONG, ((long)(t$158501)), ((x10.core.fun.Fun_0_1)(t$158502)), (x10.core.Rail.__1$1x10$lang$Long$3x10$lang$Rail$$T$2) null)));
            
            //#line 164 "x10/regionarray/Region.x10"
            final x10.regionarray.RectRegion alloc$138959 = ((x10.regionarray.RectRegion)(new x10.regionarray.RectRegion((java.lang.System[]) null)));
            
            //#line 164 "x10/regionarray/Region.x10"
            alloc$138959.x10$regionarray$RectRegion$$init$S(((x10.core.Rail)(mins)), ((x10.core.Rail)(maxs)), (x10.regionarray.RectRegion.__0$1x10$lang$Long$2__1$1x10$lang$Long$2) null);
            
            //#line 164 "x10/regionarray/Region.x10"
            return alloc$138959;
        }
    }
    
    
    //#line 170 "x10/regionarray/Region.x10"
    /**
     * Construct a rectangular region from a Rail of LongRange that represent the min/max of each dimension.
     */
    public static x10.regionarray.Region make__0$1x10$lang$LongRange$2(final x10.core.Rail<x10.lang.LongRange> ranges) {
        
        //#line 170 "x10/regionarray/Region.x10"
        final x10.regionarray.Region t$158504 = ((x10.regionarray.Region)(x10.regionarray.Region.makeRectangular__0$1x10$lang$LongRange$2(((x10.core.Rail)(ranges)))));
        
        //#line 170 "x10/regionarray/Region.x10"
        return t$158504;
    }
    
    
    //#line 175 "x10/regionarray/Region.x10"
    /**
     * Construct a rectangular rank 1 region from an IntRange
     */
    public static x10.regionarray.Region make(final x10.lang.IntRange r) {
        
        //#line 175 "x10/regionarray/Region.x10"
        final x10.regionarray.RectRegion1D alloc$138960 = ((x10.regionarray.RectRegion1D)(new x10.regionarray.RectRegion1D((java.lang.System[]) null)));
        
        //#line 175 "x10/regionarray/Region.x10"
        final int t$158737 = r.min;
        
        //#line 175 "x10/regionarray/Region.x10"
        final long t$158738 = ((long)(((int)(t$158737))));
        
        //#line 175 "x10/regionarray/Region.x10"
        final int t$158739 = r.max;
        
        //#line 175 "x10/regionarray/Region.x10"
        final long t$158740 = ((long)(((int)(t$158739))));
        
        //#line 175 "x10/regionarray/Region.x10"
        alloc$138960.x10$regionarray$RectRegion1D$$init$S(t$158738, t$158740);
        
        //#line 175 "x10/regionarray/Region.x10"
        return alloc$138960;
    }
    
    
    //#line 179 "x10/regionarray/Region.x10"
    /**
     * Construct a rectangular rank 1 region from an IntRange
     */
    public static x10.regionarray.Region makeRectangular(final x10.lang.IntRange r) {
        
        //#line 179 "x10/regionarray/Region.x10"
        final x10.regionarray.RectRegion1D alloc$138961 = ((x10.regionarray.RectRegion1D)(new x10.regionarray.RectRegion1D((java.lang.System[]) null)));
        
        //#line 179 "x10/regionarray/Region.x10"
        final int t$158741 = r.min;
        
        //#line 179 "x10/regionarray/Region.x10"
        final long t$158742 = ((long)(((int)(t$158741))));
        
        //#line 179 "x10/regionarray/Region.x10"
        final int t$158743 = r.max;
        
        //#line 179 "x10/regionarray/Region.x10"
        final long t$158744 = ((long)(((int)(t$158743))));
        
        //#line 179 "x10/regionarray/Region.x10"
        alloc$138961.x10$regionarray$RectRegion1D$$init$S(t$158742, t$158744);
        
        //#line 179 "x10/regionarray/Region.x10"
        return alloc$138961;
    }
    
    
    //#line 184 "x10/regionarray/Region.x10"
    /**
     * Construct a rectangular rank 1 region from a LongRange
     */
    public static x10.regionarray.Region make(final x10.lang.LongRange r) {
        
        //#line 184 "x10/regionarray/Region.x10"
        final x10.regionarray.RectRegion1D alloc$138962 = ((x10.regionarray.RectRegion1D)(new x10.regionarray.RectRegion1D((java.lang.System[]) null)));
        
        //#line 184 "x10/regionarray/Region.x10"
        final long t$158745 = r.min;
        
        //#line 184 "x10/regionarray/Region.x10"
        final long t$158746 = r.max;
        
        //#line 184 "x10/regionarray/Region.x10"
        alloc$138962.x10$regionarray$RectRegion1D$$init$S(((long)(t$158745)), ((long)(t$158746)));
        
        //#line 184 "x10/regionarray/Region.x10"
        return alloc$138962;
    }
    
    
    //#line 188 "x10/regionarray/Region.x10"
    /**
     * Construct a rectangular rank 1 region from a LongRange
     */
    public static x10.regionarray.Region makeRectangular(final x10.lang.LongRange r) {
        
        //#line 188 "x10/regionarray/Region.x10"
        final x10.regionarray.RectRegion1D alloc$138963 = ((x10.regionarray.RectRegion1D)(new x10.regionarray.RectRegion1D((java.lang.System[]) null)));
        
        //#line 188 "x10/regionarray/Region.x10"
        final long t$158747 = r.min;
        
        //#line 188 "x10/regionarray/Region.x10"
        final long t$158748 = r.max;
        
        //#line 188 "x10/regionarray/Region.x10"
        alloc$138963.x10$regionarray$RectRegion1D$$init$S(((long)(t$158747)), ((long)(t$158748)));
        
        //#line 188 "x10/regionarray/Region.x10"
        return alloc$138963;
    }
    
    
    //#line 193 "x10/regionarray/Region.x10"
    /**
     * Construct a rectangular rank 2 region from a pair of IntRanges
     */
    public static x10.regionarray.Region makeRectangular(final x10.lang.IntRange r1, final x10.lang.IntRange r2) {
        
        //#line 194 "x10/regionarray/Region.x10"
        final x10.regionarray.RectRegion alloc$138964 = ((x10.regionarray.RectRegion)(new x10.regionarray.RectRegion((java.lang.System[]) null)));
        
        //#line 194 "x10/regionarray/Region.x10"
        final int t$158749 = r1.min;
        
        //#line 194 "x10/regionarray/Region.x10"
        final long t$158750 = ((long)(((int)(t$158749))));
        
        //#line 194 "x10/regionarray/Region.x10"
        final int t$158751 = r2.min;
        
        //#line 194 "x10/regionarray/Region.x10"
        final long t$158752 = ((long)(((int)(t$158751))));
        
        //#line 194 "x10/regionarray/Region.x10"
        final x10.core.Rail t$158753 = ((x10.core.Rail)(x10.runtime.impl.java.ArrayUtils.<x10.core.Long> makeRailFromJavaArray(x10.rtt.Types.LONG, new long[] {t$158750, t$158752})));
        
        //#line 195 "x10/regionarray/Region.x10"
        final int t$158754 = r1.max;
        
        //#line 195 "x10/regionarray/Region.x10"
        final long t$158755 = ((long)(((int)(t$158754))));
        
        //#line 195 "x10/regionarray/Region.x10"
        final int t$158756 = r2.max;
        
        //#line 195 "x10/regionarray/Region.x10"
        final long t$158757 = ((long)(((int)(t$158756))));
        
        //#line 195 "x10/regionarray/Region.x10"
        final x10.core.Rail t$158758 = ((x10.core.Rail)(x10.runtime.impl.java.ArrayUtils.<x10.core.Long> makeRailFromJavaArray(x10.rtt.Types.LONG, new long[] {t$158755, t$158757})));
        
        //#line 194 "x10/regionarray/Region.x10"
        alloc$138964.x10$regionarray$RectRegion$$init$S(((x10.core.Rail)(t$158753)), ((x10.core.Rail)(t$158758)), (x10.regionarray.RectRegion.__0$1x10$lang$Long$2__1$1x10$lang$Long$2) null);
        
        //#line 194 "x10/regionarray/Region.x10"
        final x10.regionarray.Region t$138936 = ((x10.regionarray.Region)
                                                  alloc$138964);
        
        //#line 195 "x10/regionarray/Region.x10"
        final boolean t$158527 = t$138936.rect;
        
        //#line 195 "x10/regionarray/Region.x10"
        boolean t$158529 = ((boolean) t$158527) == ((boolean) true);
        
        //#line 195 "x10/regionarray/Region.x10"
        if (t$158529) {
            
            //#line 195 "x10/regionarray/Region.x10"
            final long t$158528 = t$138936.rank;
            
            //#line 195 "x10/regionarray/Region.x10"
            t$158529 = ((long) t$158528) == ((long) 2L);
        }
        
        //#line 194 "x10/regionarray/Region.x10"
        final boolean t$158532 = !(t$158529);
        
        //#line 194 "x10/regionarray/Region.x10"
        if (t$158532) {
            
            //#line 194 "x10/regionarray/Region.x10"
            final x10.lang.FailedDynamicCheckException t$158531 = new x10.lang.FailedDynamicCheckException("x10.regionarray.Region{self.rect==true, self.rank==2L}");
            
            //#line 194 "x10/regionarray/Region.x10"
            throw t$158531;
        }
        
        //#line 194 "x10/regionarray/Region.x10"
        return t$138936;
    }
    
    
    //#line 200 "x10/regionarray/Region.x10"
    /**
     * Construct a rectangular rank 2 region from a pair of IntRanges
     */
    public static x10.regionarray.Region make(final x10.lang.IntRange r1, final x10.lang.IntRange r2) {
        
        //#line 200 "x10/regionarray/Region.x10"
        final x10.regionarray.Region t$158533 = ((x10.regionarray.Region)(x10.regionarray.Region.makeRectangular(((x10.lang.IntRange)(r1)), ((x10.lang.IntRange)(r2)))));
        
        //#line 200 "x10/regionarray/Region.x10"
        return t$158533;
    }
    
    
    //#line 205 "x10/regionarray/Region.x10"
    /**
     * Construct a rectangular rank 2 region from a pair of LongRanges
     */
    public static x10.regionarray.Region makeRectangular(final x10.lang.LongRange r1, final x10.lang.LongRange r2) {
        
        //#line 206 "x10/regionarray/Region.x10"
        final x10.regionarray.RectRegion alloc$138965 = ((x10.regionarray.RectRegion)(new x10.regionarray.RectRegion((java.lang.System[]) null)));
        
        //#line 206 "x10/regionarray/Region.x10"
        final long t$158759 = r1.min;
        
        //#line 206 "x10/regionarray/Region.x10"
        final long t$158760 = r2.min;
        
        //#line 206 "x10/regionarray/Region.x10"
        final x10.core.Rail t$158761 = ((x10.core.Rail)(x10.runtime.impl.java.ArrayUtils.<x10.core.Long> makeRailFromJavaArray(x10.rtt.Types.LONG, new long[] {t$158759, t$158760})));
        
        //#line 206 "x10/regionarray/Region.x10"
        final long t$158762 = r1.max;
        
        //#line 206 "x10/regionarray/Region.x10"
        final long t$158763 = r2.max;
        
        //#line 206 "x10/regionarray/Region.x10"
        final x10.core.Rail t$158764 = ((x10.core.Rail)(x10.runtime.impl.java.ArrayUtils.<x10.core.Long> makeRailFromJavaArray(x10.rtt.Types.LONG, new long[] {t$158762, t$158763})));
        
        //#line 206 "x10/regionarray/Region.x10"
        alloc$138965.x10$regionarray$RectRegion$$init$S(((x10.core.Rail)(t$158761)), ((x10.core.Rail)(t$158764)), (x10.regionarray.RectRegion.__0$1x10$lang$Long$2__1$1x10$lang$Long$2) null);
        
        //#line 206 "x10/regionarray/Region.x10"
        final x10.regionarray.Region t$138938 = ((x10.regionarray.Region)
                                                  alloc$138965);
        
        //#line 206 "x10/regionarray/Region.x10"
        final boolean t$158540 = t$138938.rect;
        
        //#line 206 "x10/regionarray/Region.x10"
        boolean t$158542 = ((boolean) t$158540) == ((boolean) true);
        
        //#line 206 "x10/regionarray/Region.x10"
        if (t$158542) {
            
            //#line 206 "x10/regionarray/Region.x10"
            final long t$158541 = t$138938.rank;
            
            //#line 206 "x10/regionarray/Region.x10"
            t$158542 = ((long) t$158541) == ((long) 2L);
        }
        
        //#line 206 "x10/regionarray/Region.x10"
        final boolean t$158545 = !(t$158542);
        
        //#line 206 "x10/regionarray/Region.x10"
        if (t$158545) {
            
            //#line 206 "x10/regionarray/Region.x10"
            final x10.lang.FailedDynamicCheckException t$158544 = new x10.lang.FailedDynamicCheckException("x10.regionarray.Region{self.rect==true, self.rank==2L}");
            
            //#line 206 "x10/regionarray/Region.x10"
            throw t$158544;
        }
        
        //#line 206 "x10/regionarray/Region.x10"
        return t$138938;
    }
    
    
    //#line 211 "x10/regionarray/Region.x10"
    /**
     * Construct a rectangular rank 2 region from a pair of LongRanges
     */
    public static x10.regionarray.Region make(final x10.lang.LongRange r1, final x10.lang.LongRange r2) {
        
        //#line 211 "x10/regionarray/Region.x10"
        final x10.regionarray.Region t$158546 = ((x10.regionarray.Region)(x10.regionarray.Region.makeRectangular(((x10.lang.LongRange)(r1)), ((x10.lang.LongRange)(r2)))));
        
        //#line 211 "x10/regionarray/Region.x10"
        return t$158546;
    }
    
    
    //#line 216 "x10/regionarray/Region.x10"
    /**
     * Construct a rectangular rank 3 region from a triple of IntRanges
     */
    public static x10.regionarray.Region makeRectangular(final x10.lang.IntRange r1, final x10.lang.IntRange r2, final x10.lang.IntRange r3) {
        
        //#line 217 "x10/regionarray/Region.x10"
        final x10.regionarray.RectRegion alloc$138966 = ((x10.regionarray.RectRegion)(new x10.regionarray.RectRegion((java.lang.System[]) null)));
        
        //#line 217 "x10/regionarray/Region.x10"
        final int t$158765 = r1.min;
        
        //#line 217 "x10/regionarray/Region.x10"
        final long t$158766 = ((long)(((int)(t$158765))));
        
        //#line 217 "x10/regionarray/Region.x10"
        final int t$158767 = r2.min;
        
        //#line 217 "x10/regionarray/Region.x10"
        final long t$158768 = ((long)(((int)(t$158767))));
        
        //#line 217 "x10/regionarray/Region.x10"
        final int t$158769 = r3.min;
        
        //#line 217 "x10/regionarray/Region.x10"
        final long t$158770 = ((long)(((int)(t$158769))));
        
        //#line 217 "x10/regionarray/Region.x10"
        final x10.core.Rail t$158771 = ((x10.core.Rail)(x10.runtime.impl.java.ArrayUtils.<x10.core.Long> makeRailFromJavaArray(x10.rtt.Types.LONG, new long[] {t$158766, t$158768, t$158770})));
        
        //#line 218 "x10/regionarray/Region.x10"
        final int t$158772 = r1.max;
        
        //#line 218 "x10/regionarray/Region.x10"
        final long t$158773 = ((long)(((int)(t$158772))));
        
        //#line 218 "x10/regionarray/Region.x10"
        final int t$158774 = r2.max;
        
        //#line 218 "x10/regionarray/Region.x10"
        final long t$158775 = ((long)(((int)(t$158774))));
        
        //#line 218 "x10/regionarray/Region.x10"
        final int t$158776 = r3.max;
        
        //#line 218 "x10/regionarray/Region.x10"
        final long t$158777 = ((long)(((int)(t$158776))));
        
        //#line 218 "x10/regionarray/Region.x10"
        final x10.core.Rail t$158778 = ((x10.core.Rail)(x10.runtime.impl.java.ArrayUtils.<x10.core.Long> makeRailFromJavaArray(x10.rtt.Types.LONG, new long[] {t$158773, t$158775, t$158777})));
        
        //#line 217 "x10/regionarray/Region.x10"
        alloc$138966.x10$regionarray$RectRegion$$init$S(((x10.core.Rail)(t$158771)), ((x10.core.Rail)(t$158778)), (x10.regionarray.RectRegion.__0$1x10$lang$Long$2__1$1x10$lang$Long$2) null);
        
        //#line 217 "x10/regionarray/Region.x10"
        final x10.regionarray.Region t$138940 = ((x10.regionarray.Region)
                                                  alloc$138966);
        
        //#line 218 "x10/regionarray/Region.x10"
        final boolean t$158561 = t$138940.rect;
        
        //#line 218 "x10/regionarray/Region.x10"
        boolean t$158563 = ((boolean) t$158561) == ((boolean) true);
        
        //#line 218 "x10/regionarray/Region.x10"
        if (t$158563) {
            
            //#line 218 "x10/regionarray/Region.x10"
            final long t$158562 = t$138940.rank;
            
            //#line 218 "x10/regionarray/Region.x10"
            t$158563 = ((long) t$158562) == ((long) 3L);
        }
        
        //#line 217 "x10/regionarray/Region.x10"
        final boolean t$158566 = !(t$158563);
        
        //#line 217 "x10/regionarray/Region.x10"
        if (t$158566) {
            
            //#line 217 "x10/regionarray/Region.x10"
            final x10.lang.FailedDynamicCheckException t$158565 = new x10.lang.FailedDynamicCheckException("x10.regionarray.Region{self.rect==true, self.rank==3L}");
            
            //#line 217 "x10/regionarray/Region.x10"
            throw t$158565;
        }
        
        //#line 217 "x10/regionarray/Region.x10"
        return t$138940;
    }
    
    
    //#line 223 "x10/regionarray/Region.x10"
    /**
     * Construct a rectangular rank 3 region from a triple of IntRanges
     */
    public static x10.regionarray.Region make(final x10.lang.IntRange r1, final x10.lang.IntRange r2, final x10.lang.IntRange r3) {
        
        //#line 224 "x10/regionarray/Region.x10"
        final x10.regionarray.Region t$158567 = ((x10.regionarray.Region)(x10.regionarray.Region.makeRectangular(((x10.lang.IntRange)(r1)), ((x10.lang.IntRange)(r2)), ((x10.lang.IntRange)(r3)))));
        
        //#line 224 "x10/regionarray/Region.x10"
        return t$158567;
    }
    
    
    //#line 230 "x10/regionarray/Region.x10"
    /**
     * Construct a rectangular rank 3 region from a triple of LongRanges
     */
    public static x10.regionarray.Region makeRectangular(final x10.lang.LongRange r1, final x10.lang.LongRange r2, final x10.lang.LongRange r3) {
        
        //#line 231 "x10/regionarray/Region.x10"
        final x10.regionarray.RectRegion alloc$138967 = ((x10.regionarray.RectRegion)(new x10.regionarray.RectRegion((java.lang.System[]) null)));
        
        //#line 231 "x10/regionarray/Region.x10"
        final long t$158779 = r1.min;
        
        //#line 231 "x10/regionarray/Region.x10"
        final long t$158780 = r2.min;
        
        //#line 231 "x10/regionarray/Region.x10"
        final long t$158781 = r3.min;
        
        //#line 231 "x10/regionarray/Region.x10"
        final x10.core.Rail t$158782 = ((x10.core.Rail)(x10.runtime.impl.java.ArrayUtils.<x10.core.Long> makeRailFromJavaArray(x10.rtt.Types.LONG, new long[] {t$158779, t$158780, t$158781})));
        
        //#line 231 "x10/regionarray/Region.x10"
        final long t$158783 = r1.max;
        
        //#line 231 "x10/regionarray/Region.x10"
        final long t$158784 = r2.max;
        
        //#line 231 "x10/regionarray/Region.x10"
        final long t$158785 = r3.max;
        
        //#line 231 "x10/regionarray/Region.x10"
        final x10.core.Rail t$158786 = ((x10.core.Rail)(x10.runtime.impl.java.ArrayUtils.<x10.core.Long> makeRailFromJavaArray(x10.rtt.Types.LONG, new long[] {t$158783, t$158784, t$158785})));
        
        //#line 231 "x10/regionarray/Region.x10"
        alloc$138967.x10$regionarray$RectRegion$$init$S(((x10.core.Rail)(t$158782)), ((x10.core.Rail)(t$158786)), (x10.regionarray.RectRegion.__0$1x10$lang$Long$2__1$1x10$lang$Long$2) null);
        
        //#line 231 "x10/regionarray/Region.x10"
        final x10.regionarray.Region t$138942 = ((x10.regionarray.Region)
                                                  alloc$138967);
        
        //#line 231 "x10/regionarray/Region.x10"
        final boolean t$158576 = t$138942.rect;
        
        //#line 231 "x10/regionarray/Region.x10"
        boolean t$158578 = ((boolean) t$158576) == ((boolean) true);
        
        //#line 231 "x10/regionarray/Region.x10"
        if (t$158578) {
            
            //#line 231 "x10/regionarray/Region.x10"
            final long t$158577 = t$138942.rank;
            
            //#line 231 "x10/regionarray/Region.x10"
            t$158578 = ((long) t$158577) == ((long) 3L);
        }
        
        //#line 231 "x10/regionarray/Region.x10"
        final boolean t$158581 = !(t$158578);
        
        //#line 231 "x10/regionarray/Region.x10"
        if (t$158581) {
            
            //#line 231 "x10/regionarray/Region.x10"
            final x10.lang.FailedDynamicCheckException t$158580 = new x10.lang.FailedDynamicCheckException("x10.regionarray.Region{self.rect==true, self.rank==3L}");
            
            //#line 231 "x10/regionarray/Region.x10"
            throw t$158580;
        }
        
        //#line 231 "x10/regionarray/Region.x10"
        return t$138942;
    }
    
    
    //#line 236 "x10/regionarray/Region.x10"
    /**
     * Construct a rectangular rank 3 region from a triple of LongRanges
     */
    public static x10.regionarray.Region make(final x10.lang.LongRange r1, final x10.lang.LongRange r2, final x10.lang.LongRange r3) {
        
        //#line 237 "x10/regionarray/Region.x10"
        final x10.regionarray.Region t$158582 = ((x10.regionarray.Region)(x10.regionarray.Region.makeRectangular(((x10.lang.LongRange)(r1)), ((x10.lang.LongRange)(r2)), ((x10.lang.LongRange)(r3)))));
        
        //#line 237 "x10/regionarray/Region.x10"
        return t$158582;
    }
    
    
    //#line 243 "x10/regionarray/Region.x10"
    /**
     * Construct a rectangular rank 4 region from four IntRanges
     */
    public static x10.regionarray.Region makeRectangular(final x10.lang.IntRange r1, final x10.lang.IntRange r2, final x10.lang.IntRange r3, final x10.lang.IntRange r4) {
        
        //#line 244 "x10/regionarray/Region.x10"
        final x10.regionarray.RectRegion alloc$138968 = ((x10.regionarray.RectRegion)(new x10.regionarray.RectRegion((java.lang.System[]) null)));
        
        //#line 244 "x10/regionarray/Region.x10"
        final int t$158787 = r1.min;
        
        //#line 244 "x10/regionarray/Region.x10"
        final long t$158788 = ((long)(((int)(t$158787))));
        
        //#line 244 "x10/regionarray/Region.x10"
        final int t$158789 = r2.min;
        
        //#line 244 "x10/regionarray/Region.x10"
        final long t$158790 = ((long)(((int)(t$158789))));
        
        //#line 244 "x10/regionarray/Region.x10"
        final int t$158791 = r3.min;
        
        //#line 244 "x10/regionarray/Region.x10"
        final long t$158792 = ((long)(((int)(t$158791))));
        
        //#line 244 "x10/regionarray/Region.x10"
        final int t$158793 = r4.min;
        
        //#line 244 "x10/regionarray/Region.x10"
        final long t$158794 = ((long)(((int)(t$158793))));
        
        //#line 244 "x10/regionarray/Region.x10"
        final x10.core.Rail t$158795 = ((x10.core.Rail)(x10.runtime.impl.java.ArrayUtils.<x10.core.Long> makeRailFromJavaArray(x10.rtt.Types.LONG, new long[] {t$158788, t$158790, t$158792, t$158794})));
        
        //#line 245 "x10/regionarray/Region.x10"
        final int t$158796 = r1.max;
        
        //#line 245 "x10/regionarray/Region.x10"
        final long t$158797 = ((long)(((int)(t$158796))));
        
        //#line 245 "x10/regionarray/Region.x10"
        final int t$158798 = r2.max;
        
        //#line 245 "x10/regionarray/Region.x10"
        final long t$158799 = ((long)(((int)(t$158798))));
        
        //#line 245 "x10/regionarray/Region.x10"
        final int t$158800 = r3.max;
        
        //#line 245 "x10/regionarray/Region.x10"
        final long t$158801 = ((long)(((int)(t$158800))));
        
        //#line 245 "x10/regionarray/Region.x10"
        final int t$158802 = r4.max;
        
        //#line 245 "x10/regionarray/Region.x10"
        final long t$158803 = ((long)(((int)(t$158802))));
        
        //#line 245 "x10/regionarray/Region.x10"
        final x10.core.Rail t$158804 = ((x10.core.Rail)(x10.runtime.impl.java.ArrayUtils.<x10.core.Long> makeRailFromJavaArray(x10.rtt.Types.LONG, new long[] {t$158797, t$158799, t$158801, t$158803})));
        
        //#line 244 "x10/regionarray/Region.x10"
        alloc$138968.x10$regionarray$RectRegion$$init$S(((x10.core.Rail)(t$158795)), ((x10.core.Rail)(t$158804)), (x10.regionarray.RectRegion.__0$1x10$lang$Long$2__1$1x10$lang$Long$2) null);
        
        //#line 244 "x10/regionarray/Region.x10"
        final x10.regionarray.Region t$138944 = ((x10.regionarray.Region)
                                                  alloc$138968);
        
        //#line 245 "x10/regionarray/Region.x10"
        final boolean t$158601 = t$138944.rect;
        
        //#line 245 "x10/regionarray/Region.x10"
        boolean t$158603 = ((boolean) t$158601) == ((boolean) true);
        
        //#line 245 "x10/regionarray/Region.x10"
        if (t$158603) {
            
            //#line 245 "x10/regionarray/Region.x10"
            final long t$158602 = t$138944.rank;
            
            //#line 245 "x10/regionarray/Region.x10"
            t$158603 = ((long) t$158602) == ((long) 4L);
        }
        
        //#line 244 "x10/regionarray/Region.x10"
        final boolean t$158606 = !(t$158603);
        
        //#line 244 "x10/regionarray/Region.x10"
        if (t$158606) {
            
            //#line 244 "x10/regionarray/Region.x10"
            final x10.lang.FailedDynamicCheckException t$158605 = new x10.lang.FailedDynamicCheckException("x10.regionarray.Region{self.rect==true, self.rank==4L}");
            
            //#line 244 "x10/regionarray/Region.x10"
            throw t$158605;
        }
        
        //#line 244 "x10/regionarray/Region.x10"
        return t$138944;
    }
    
    
    //#line 250 "x10/regionarray/Region.x10"
    /**
     * Construct a rectangular rank 4 region from four IntRanges
     */
    public static x10.regionarray.Region make(final x10.lang.IntRange r1, final x10.lang.IntRange r2, final x10.lang.IntRange r3, final x10.lang.IntRange r4) {
        
        //#line 251 "x10/regionarray/Region.x10"
        final x10.regionarray.Region t$158607 = ((x10.regionarray.Region)(x10.regionarray.Region.makeRectangular(((x10.lang.IntRange)(r1)), ((x10.lang.IntRange)(r2)), ((x10.lang.IntRange)(r3)), ((x10.lang.IntRange)(r4)))));
        
        //#line 251 "x10/regionarray/Region.x10"
        return t$158607;
    }
    
    
    //#line 257 "x10/regionarray/Region.x10"
    /**
     * Construct a rectangular rank 4 region from four LongRanges
     */
    public static x10.regionarray.Region makeRectangular(final x10.lang.LongRange r1, final x10.lang.LongRange r2, final x10.lang.LongRange r3, final x10.lang.LongRange r4) {
        
        //#line 258 "x10/regionarray/Region.x10"
        final x10.regionarray.RectRegion alloc$138969 = ((x10.regionarray.RectRegion)(new x10.regionarray.RectRegion((java.lang.System[]) null)));
        
        //#line 258 "x10/regionarray/Region.x10"
        final long t$158805 = r1.min;
        
        //#line 258 "x10/regionarray/Region.x10"
        final long t$158806 = r2.min;
        
        //#line 258 "x10/regionarray/Region.x10"
        final long t$158807 = r3.min;
        
        //#line 258 "x10/regionarray/Region.x10"
        final long t$158808 = r4.min;
        
        //#line 258 "x10/regionarray/Region.x10"
        final x10.core.Rail t$158809 = ((x10.core.Rail)(x10.runtime.impl.java.ArrayUtils.<x10.core.Long> makeRailFromJavaArray(x10.rtt.Types.LONG, new long[] {t$158805, t$158806, t$158807, t$158808})));
        
        //#line 258 "x10/regionarray/Region.x10"
        final long t$158810 = r1.max;
        
        //#line 258 "x10/regionarray/Region.x10"
        final long t$158811 = r2.max;
        
        //#line 258 "x10/regionarray/Region.x10"
        final long t$158812 = r3.max;
        
        //#line 258 "x10/regionarray/Region.x10"
        final long t$158813 = r4.max;
        
        //#line 258 "x10/regionarray/Region.x10"
        final x10.core.Rail t$158814 = ((x10.core.Rail)(x10.runtime.impl.java.ArrayUtils.<x10.core.Long> makeRailFromJavaArray(x10.rtt.Types.LONG, new long[] {t$158810, t$158811, t$158812, t$158813})));
        
        //#line 258 "x10/regionarray/Region.x10"
        alloc$138969.x10$regionarray$RectRegion$$init$S(((x10.core.Rail)(t$158809)), ((x10.core.Rail)(t$158814)), (x10.regionarray.RectRegion.__0$1x10$lang$Long$2__1$1x10$lang$Long$2) null);
        
        //#line 258 "x10/regionarray/Region.x10"
        final x10.regionarray.Region t$138946 = ((x10.regionarray.Region)
                                                  alloc$138969);
        
        //#line 258 "x10/regionarray/Region.x10"
        final boolean t$158618 = t$138946.rect;
        
        //#line 258 "x10/regionarray/Region.x10"
        boolean t$158620 = ((boolean) t$158618) == ((boolean) true);
        
        //#line 258 "x10/regionarray/Region.x10"
        if (t$158620) {
            
            //#line 258 "x10/regionarray/Region.x10"
            final long t$158619 = t$138946.rank;
            
            //#line 258 "x10/regionarray/Region.x10"
            t$158620 = ((long) t$158619) == ((long) 4L);
        }
        
        //#line 258 "x10/regionarray/Region.x10"
        final boolean t$158623 = !(t$158620);
        
        //#line 258 "x10/regionarray/Region.x10"
        if (t$158623) {
            
            //#line 258 "x10/regionarray/Region.x10"
            final x10.lang.FailedDynamicCheckException t$158622 = new x10.lang.FailedDynamicCheckException("x10.regionarray.Region{self.rect==true, self.rank==4L}");
            
            //#line 258 "x10/regionarray/Region.x10"
            throw t$158622;
        }
        
        //#line 258 "x10/regionarray/Region.x10"
        return t$138946;
    }
    
    
    //#line 263 "x10/regionarray/Region.x10"
    /**
     * Construct a rectangular rank 4 region from four LongRanges
     */
    public static x10.regionarray.Region make(final x10.lang.LongRange r1, final x10.lang.LongRange r2, final x10.lang.LongRange r3, final x10.lang.LongRange r4) {
        
        //#line 264 "x10/regionarray/Region.x10"
        final x10.regionarray.Region t$158624 = ((x10.regionarray.Region)(x10.regionarray.Region.makeRectangular(((x10.lang.LongRange)(r1)), ((x10.lang.LongRange)(r2)), ((x10.lang.LongRange)(r3)), ((x10.lang.LongRange)(r4)))));
        
        //#line 264 "x10/regionarray/Region.x10"
        return t$158624;
    }
    
    
    //#line 273 "x10/regionarray/Region.x10"
    /**
     * Construct a rank-1 rectangular region with the specified bounds.
     */
    public static x10.regionarray.Region makeRectangular(final long min, final long max) {
        
        //#line 274 "x10/regionarray/Region.x10"
        final x10.regionarray.RectRegion1D alloc$138970 = ((x10.regionarray.RectRegion1D)(new x10.regionarray.RectRegion1D((java.lang.System[]) null)));
        
        //#line 274 "x10/regionarray/Region.x10"
        alloc$138970.x10$regionarray$RectRegion1D$$init$S(((long)(min)), ((long)(max)));
        
        //#line 274 "x10/regionarray/Region.x10"
        return alloc$138970;
    }
    
    
    //#line 279 "x10/regionarray/Region.x10"
    /**
     * Construct a rank-1 rectangular region with the specified bounds.
     */
    public static x10.regionarray.Region make(final long min, final long max) {
        
        //#line 279 "x10/regionarray/Region.x10"
        final x10.regionarray.RectRegion1D alloc$138971 = ((x10.regionarray.RectRegion1D)(new x10.regionarray.RectRegion1D((java.lang.System[]) null)));
        
        //#line 279 "x10/regionarray/Region.x10"
        alloc$138971.x10$regionarray$RectRegion1D$$init$S(((long)(min)), ((long)(max)));
        
        //#line 279 "x10/regionarray/Region.x10"
        return alloc$138971;
    }
    
    
    //#line 293 "x10/regionarray/Region.x10"
    /**
     * Construct a banded region of the given size, with the specified
     * number of diagonals above and below the main diagonal
     * (inclusive of the main diagonal).
     * @param size -- number of elements in the banded region
     * @param upper -- the number of diagonals in the band, above the main diagonal
     * @param lower -- the number of diagonals in the band, below the main diagonal
     */
    public static x10.regionarray.Region makeBanded(final long size, final long upper, final long lower) {
        
        //#line 294 "x10/regionarray/Region.x10"
        final int size$158351 = ((int)(long)(((long)(size))));
        
        //#line 294 "x10/regionarray/Region.x10"
        final int upper$158352 = ((int)(long)(((long)(upper))));
        
        //#line 294 "x10/regionarray/Region.x10"
        final int lower$158353 = ((int)(long)(((long)(lower))));
        
        //#line 260 . "x10/regionarray/PolyRegion.x10"
        final int t$158625 = ((size$158351) - (((int)(1))));
        
        //#line 260 . "x10/regionarray/PolyRegion.x10"
        final int t$158626 = ((size$158351) - (((int)(1))));
        
        //#line 260 . "x10/regionarray/PolyRegion.x10"
        final x10.regionarray.Region t$158627 = ((x10.regionarray.Region)(x10.regionarray.PolyRegion.makeBanded((int)(0), (int)(0), (int)(t$158625), (int)(t$158626), (int)(upper$158352), (int)(lower$158353))));
        
        //#line 294 "x10/regionarray/Region.x10"
        return t$158627;
    }
    
    
    //#line 300 "x10/regionarray/Region.x10"
    /**
     * Construct a banded region of the given size that includes only
     * the main diagonal.
     */
    public static x10.regionarray.Region makeBanded(final long size) {
        
        //#line 300 "x10/regionarray/Region.x10"
        final int t$158628 = ((int)(long)(((long)(size))));
        
        //#line 300 "x10/regionarray/Region.x10"
        final long t$158629 = ((long)(((int)(t$158628))));
        
        //#line 300 "x10/regionarray/Region.x10"
        final x10.regionarray.Region t$158630 = ((x10.regionarray.Region)(x10.regionarray.PolyRegion.makeBanded((long)(t$158629), (long)(1L), (long)(1L))));
        
        //#line 300 "x10/regionarray/Region.x10"
        return t$158630;
    }
    
    
    //#line 306 "x10/regionarray/Region.x10"
    /**
     * Construct an upper triangular region of the given size.
     */
    public static x10.regionarray.Region makeUpperTriangular(final long size) {
        
        //#line 306 "x10/regionarray/Region.x10"
        final x10.regionarray.Region t$158631 = ((x10.regionarray.Region)(x10.regionarray.Region.makeUpperTriangular((long)(0L), (long)(0L), (long)(size))));
        
        //#line 306 "x10/regionarray/Region.x10"
        return t$158631;
    }
    
    
    //#line 312 "x10/regionarray/Region.x10"
    /**
     * Construct an upper triangular region of the given size with the
     * given lower bounds.
     */
    public static x10.regionarray.Region makeUpperTriangular(final long rowMin, final long colMin, final long size) {
        
        //#line 313 "x10/regionarray/Region.x10"
        final int t$158632 = ((int)(long)(((long)(rowMin))));
        
        //#line 313 "x10/regionarray/Region.x10"
        final int t$158633 = ((int)(long)(((long)(colMin))));
        
        //#line 313 "x10/regionarray/Region.x10"
        final int t$158634 = ((int)(long)(((long)(size))));
        
        //#line 313 "x10/regionarray/Region.x10"
        final x10.regionarray.Region t$158635 = ((x10.regionarray.Region)(x10.regionarray.PolyRegion.makeUpperTriangular2((int)(t$158632), (int)(t$158633), (int)(t$158634))));
        
        //#line 313 "x10/regionarray/Region.x10"
        return t$158635;
    }
    
    
    //#line 318 "x10/regionarray/Region.x10"
    /**
     * Construct a lower triangular region of the given size.
     */
    public static x10.regionarray.Region makeLowerTriangular(final long size) {
        
        //#line 318 "x10/regionarray/Region.x10"
        final x10.regionarray.Region t$158636 = ((x10.regionarray.Region)(x10.regionarray.Region.makeLowerTriangular((long)(0L), (long)(0L), (long)(size))));
        
        //#line 318 "x10/regionarray/Region.x10"
        return t$158636;
    }
    
    
    //#line 324 "x10/regionarray/Region.x10"
    /**
     * Construct an lower triangular region of the given size with the
     * given lower bounds.
     */
    public static x10.regionarray.Region makeLowerTriangular(final long rowMin, final long colMin, final long size) {
        
        //#line 325 "x10/regionarray/Region.x10"
        final int t$158637 = ((int)(long)(((long)(rowMin))));
        
        //#line 325 "x10/regionarray/Region.x10"
        final int t$158638 = ((int)(long)(((long)(colMin))));
        
        //#line 325 "x10/regionarray/Region.x10"
        final int t$158639 = ((int)(long)(((long)(size))));
        
        //#line 325 "x10/regionarray/Region.x10"
        final x10.regionarray.Region t$158640 = ((x10.regionarray.Region)(x10.regionarray.PolyRegion.makeLowerTriangular2((int)(t$158637), (int)(t$158638), (int)(t$158639))));
        
        //#line 325 "x10/regionarray/Region.x10"
        return t$158640;
    }
    
    
    //#line 335 "x10/regionarray/Region.x10"
    /**
     * Returns the number of points in this region.
     */
    abstract public long size$O();
    
    
    //#line 340 "x10/regionarray/Region.x10"
    /**
     * Returns true iff this region is convex.
     */
    abstract public boolean isConvex$O();
    
    
    //#line 345 "x10/regionarray/Region.x10"
    /**
     * Returns true iff this region is empty.
     */
    abstract public boolean isEmpty$O();
    
    
    //#line 360 "x10/regionarray/Region.x10"
    /**
     * Returns the index of the argument point in the lexograpically ordered
     * enumeration of all Points in this region.  Will return -1 to indicate 
     * that the argument point is not included in this region.  If the argument
     * point is contained in this region, then a value between 0 and size-1
     * will be returned.  The primary usage of indexOf is in the context of 
     * Arrays, where it enables the conversion from "logical" indicies 
     * specified in Points into lower level indices specified by Ints that
     * can be used in primitive operations such as copyTo and in interfacing
     * to native code.  Often indexOf will be used in conjuntion with the 
     * raw() method of Array or DistArray.
     */
    abstract public long indexOf$O(final x10.lang.Point p);
    
    
    //#line 362 "x10/regionarray/Region.x10"
    public long indexOf$O(final long i0) {
        
        //#line 151 . "x10/lang/Point.x10"
        final x10.lang.Point alloc$158356 = ((x10.lang.Point)(new x10.lang.Point((java.lang.System[]) null)));
        
        //#line 151 . "x10/lang/Point.x10"
        alloc$158356.x10$lang$Point$$init$S(i0);
        
        //#line 362 "x10/regionarray/Region.x10"
        final long t$158641 = this.indexOf$O(((x10.lang.Point)(alloc$158356)));
        
        //#line 362 "x10/regionarray/Region.x10"
        return t$158641;
    }
    
    
    //#line 363 "x10/regionarray/Region.x10"
    public long indexOf$O(final long i0, final long i1) {
        
        //#line 152 . "x10/lang/Point.x10"
        final x10.lang.Point alloc$158360 = ((x10.lang.Point)(new x10.lang.Point((java.lang.System[]) null)));
        
        //#line 152 . "x10/lang/Point.x10"
        alloc$158360.x10$lang$Point$$init$S(i0, i1);
        
        //#line 363 "x10/regionarray/Region.x10"
        final long t$158642 = this.indexOf$O(((x10.lang.Point)(alloc$158360)));
        
        //#line 363 "x10/regionarray/Region.x10"
        return t$158642;
    }
    
    
    //#line 364 "x10/regionarray/Region.x10"
    public long indexOf$O(final long i0, final long i1, final long i2) {
        
        //#line 153 . "x10/lang/Point.x10"
        final x10.lang.Point alloc$158365 = ((x10.lang.Point)(new x10.lang.Point((java.lang.System[]) null)));
        
        //#line 153 . "x10/lang/Point.x10"
        alloc$158365.x10$lang$Point$$init$S(i0, i1, i2);
        
        //#line 364 "x10/regionarray/Region.x10"
        final long t$158643 = this.indexOf$O(((x10.lang.Point)(alloc$158365)));
        
        //#line 364 "x10/regionarray/Region.x10"
        return t$158643;
    }
    
    
    //#line 365 "x10/regionarray/Region.x10"
    public long indexOf$O(final long i0, final long i1, final long i2, final long i3) {
        
        //#line 154 . "x10/lang/Point.x10"
        final x10.lang.Point alloc$158371 = ((x10.lang.Point)(new x10.lang.Point((java.lang.System[]) null)));
        
        //#line 154 . "x10/lang/Point.x10"
        alloc$158371.x10$lang$Point$$init$S(i0, i1, i2, i3);
        
        //#line 365 "x10/regionarray/Region.x10"
        final long t$158644 = this.indexOf$O(((x10.lang.Point)(alloc$158371)));
        
        //#line 365 "x10/regionarray/Region.x10"
        return t$158644;
    }
    
    
    //#line 376 "x10/regionarray/Region.x10"
    /**
     * The bounding box of a region r is the smallest rectangular region
     * that contains all the points of r.
     */
    public x10.regionarray.Region boundingBox() {
        
        //#line 376 "x10/regionarray/Region.x10"
        final x10.regionarray.Region t$158645 = ((x10.regionarray.Region)(this.computeBoundingBox()));
        
        //#line 376 "x10/regionarray/Region.x10"
        return t$158645;
    }
    
    
    //#line 379 "x10/regionarray/Region.x10"
    abstract public x10.regionarray.Region computeBoundingBox();
    
    
    //#line 385 "x10/regionarray/Region.x10"
    /**
     * Returns a function that can be used to access the lower bounds 
     * of the bounding box of the region. 
     */
    abstract public x10.core.fun.Fun_0_1 min();
    
    
    //#line 391 "x10/regionarray/Region.x10"
    /**
     * Returns a function that can be used to access the upper bounds 
     * of the bounding box of the region. 
     */
    abstract public x10.core.fun.Fun_0_1 max();
    
    
    //#line 397 "x10/regionarray/Region.x10"
    /**
     * Returns the lower bound of the bounding box of the region along
     * the ith axis.
     */
    public long min$O(final long i) {
        
        //#line 397 "x10/regionarray/Region.x10"
        final x10.core.fun.Fun_0_1 t$158646 = this.min();
        
        //#line 397 "x10/regionarray/Region.x10"
        final long t$158647 = x10.core.Long.$unbox(((x10.core.fun.Fun_0_1<x10.core.Long,x10.core.Long>)t$158646).$apply(x10.core.Long.$box(i), x10.rtt.Types.LONG));
        
        //#line 397 "x10/regionarray/Region.x10"
        return t$158647;
    }
    
    
    //#line 403 "x10/regionarray/Region.x10"
    /**
     * Returns the upper bound of the bounding box of the region along
     * the ith axis.
     */
    public long max$O(final long i) {
        
        //#line 403 "x10/regionarray/Region.x10"
        final x10.core.fun.Fun_0_1 t$158648 = this.max();
        
        //#line 403 "x10/regionarray/Region.x10"
        final long t$158649 = x10.core.Long.$unbox(((x10.core.fun.Fun_0_1<x10.core.Long,x10.core.Long>)t$158648).$apply(x10.core.Long.$box(i), x10.rtt.Types.LONG));
        
        //#line 403 "x10/regionarray/Region.x10"
        return t$158649;
    }
    
    
    //#line 408 "x10/regionarray/Region.x10"
    /**
     * Returns the smallest point in the bounding box of the region
     */
    public x10.lang.Point minPoint() {
        
        //#line 408 "x10/regionarray/Region.x10"
        final long t$158650 = this.rank;
        
        //#line 408 "x10/regionarray/Region.x10"
        final x10.core.fun.Fun_0_1 t$158651 = this.min();
        
        //#line 408 "x10/regionarray/Region.x10"
        final x10.lang.Point t$158652 = ((x10.lang.Point)(x10.lang.Point.make__1$1x10$lang$Long$3x10$lang$Long$2((long)(t$158650), ((x10.core.fun.Fun_0_1)(t$158651)))));
        
        //#line 408 "x10/regionarray/Region.x10"
        return t$158652;
    }
    
    
    //#line 413 "x10/regionarray/Region.x10"
    /**
     * Returns the largest point in the bounding box of the region
     */
    public x10.lang.Point maxPoint() {
        
        //#line 413 "x10/regionarray/Region.x10"
        final long t$158653 = this.rank;
        
        //#line 413 "x10/regionarray/Region.x10"
        final x10.core.fun.Fun_0_1 t$158654 = this.max();
        
        //#line 413 "x10/regionarray/Region.x10"
        final x10.lang.Point t$158655 = ((x10.lang.Point)(x10.lang.Point.make__1$1x10$lang$Long$3x10$lang$Long$2((long)(t$158653), ((x10.core.fun.Fun_0_1)(t$158654)))));
        
        //#line 413 "x10/regionarray/Region.x10"
        return t$158655;
    }
    
    
    //#line 450 "x10/regionarray/Region.x10"
    /**
     * Returns the intersection of two regions: a region that contains all
     * points that are in both this region and that region.
     * 
     */
    abstract public x10.regionarray.Region intersection(final x10.regionarray.Region that);
    
    
    //#line 464 "x10/regionarray/Region.x10"
    /**
     * Returns true iff this region has no points in common with that
     * region.
     */
    public boolean disjoint$O(final x10.regionarray.Region that) {
        
        //#line 464 "x10/regionarray/Region.x10"
        final x10.regionarray.Region t$158656 = ((x10.regionarray.Region)(this.intersection(((x10.regionarray.Region)(that)))));
        
        //#line 464 "x10/regionarray/Region.x10"
        final boolean t$158657 = t$158656.isEmpty$O();
        
        //#line 464 "x10/regionarray/Region.x10"
        return t$158657;
    }
    
    
    //#line 475 "x10/regionarray/Region.x10"
    /**
     * Returns the Cartesian product of two regions. The Cartesian
     * product has rank <code>this.rank+that.rank</code>. For every point <code>p</code> in the
     * Cartesian product, the first <code>this.rank</code> coordinates of <code>p</code> are a
     * point in this region, while the last <code>that.rank</code> coordinates of p
     * are a point in that region.
     */
    abstract public x10.regionarray.Region product(final x10.regionarray.Region that);
    
    
    //#line 483 "x10/regionarray/Region.x10"
    /**
     * Returns the region shifted by a Point (vector). The Point has
     * to have the same rank as the region. A point p+v is in 
     * <code>translate(v)</code> iff <code>p</code> is in <code>this</code>. 
     */
    abstract public x10.regionarray.Region translate(final x10.lang.Point v);
    
    
    //#line 492 "x10/regionarray/Region.x10"
    /**
     * Returns the projection of a region onto the specified axis. The
     * projection is a rank-1 region such that for every point <code>[i]</code> in
     * the projection, there is some point <code>p</code> in this region such that
     * <code>p(axis)==i</code>.
     */
    abstract public x10.regionarray.Region projection(final long axis);
    
    
    //#line 500 "x10/regionarray/Region.x10"
    /**
     * Returns the projection of a region onto all axes but the
     * specified axis.
     */
    abstract public x10.regionarray.Region eliminate(final long axis);
    
    
    //#line 511 "x10/regionarray/Region.x10"
    /**
     * Return an iterator for this region. Normally accessed using the
     * syntax
     *
     *    for (p:Point in r)
     *        ... p ...
     */
    abstract public x10.lang.Iterator iterator();
    
    
    //#line 519 "x10/regionarray/Region.x10"
    public x10.regionarray.Region $and(final x10.regionarray.Region that) {
        
        //#line 519 "x10/regionarray/Region.x10"
        final x10.regionarray.Region t$158658 = ((x10.regionarray.Region)(this.intersection(((x10.regionarray.Region)(that)))));
        
        //#line 519 "x10/regionarray/Region.x10"
        return t$158658;
    }
    
    
    //#line 523 "x10/regionarray/Region.x10"
    public x10.regionarray.Region $times(final x10.regionarray.Region that) {
        
        //#line 523 "x10/regionarray/Region.x10"
        final x10.regionarray.Region t$158659 = ((x10.regionarray.Region)(this.product(((x10.regionarray.Region)(that)))));
        
        //#line 523 "x10/regionarray/Region.x10"
        return t$158659;
    }
    
    
    //#line 525 "x10/regionarray/Region.x10"
    public x10.regionarray.Region $plus(final x10.lang.Point v) {
        
        //#line 525 "x10/regionarray/Region.x10"
        final x10.regionarray.Region t$158660 = ((x10.regionarray.Region)(this.translate(((x10.lang.Point)(v)))));
        
        //#line 525 "x10/regionarray/Region.x10"
        return t$158660;
    }
    
    
    //#line 526 "x10/regionarray/Region.x10"
    public x10.regionarray.Region $inv_plus(final x10.lang.Point v) {
        
        //#line 526 "x10/regionarray/Region.x10"
        final x10.regionarray.Region t$158661 = ((x10.regionarray.Region)(this.translate(((x10.lang.Point)(v)))));
        
        //#line 526 "x10/regionarray/Region.x10"
        return t$158661;
    }
    
    
    //#line 527 "x10/regionarray/Region.x10"
    public x10.regionarray.Region $minus(final x10.lang.Point v) {
        
        //#line 527 "x10/regionarray/Region.x10"
        final x10.lang.Point t$158662 = ((x10.lang.Point)(v.$minus()));
        
        //#line 527 "x10/regionarray/Region.x10"
        final x10.regionarray.Region t$158663 = ((x10.regionarray.Region)(this.translate(((x10.lang.Point)(t$158662)))));
        
        //#line 527 "x10/regionarray/Region.x10"
        return t$158663;
    }
    
    
    //#line 534 "x10/regionarray/Region.x10"
    public boolean equals(final java.lang.Object that) {
        
        //#line 535 "x10/regionarray/Region.x10"
        final boolean t$158664 = x10.rtt.Equality.equalsequals((this),(that));
        
        //#line 535 "x10/regionarray/Region.x10"
        if (t$158664) {
            
            //#line 535 "x10/regionarray/Region.x10"
            return true;
        }
        
        //#line 536 "x10/regionarray/Region.x10"
        final boolean t$158665 = x10.regionarray.Region.$RTT.isInstance(that);
        
        //#line 536 "x10/regionarray/Region.x10"
        final boolean t$158666 = !(t$158665);
        
        //#line 536 "x10/regionarray/Region.x10"
        if (t$158666) {
            
            //#line 536 "x10/regionarray/Region.x10"
            return false;
        }
        
        //#line 537 "x10/regionarray/Region.x10"
        final x10.regionarray.Region t1 = ((x10.regionarray.Region)(x10.rtt.Types.<x10.regionarray.Region> cast(that,x10.regionarray.Region.$RTT)));
        
        //#line 538 "x10/regionarray/Region.x10"
        final long t$158667 = this.rank;
        
        //#line 538 "x10/regionarray/Region.x10"
        final long t$158668 = t1.rank;
        
        //#line 538 "x10/regionarray/Region.x10"
        final boolean t$158669 = ((long) t$158667) != ((long) t$158668);
        
        //#line 538 "x10/regionarray/Region.x10"
        if (t$158669) {
            
            //#line 538 "x10/regionarray/Region.x10"
            return false;
        }
        
        //#line 539 "x10/regionarray/Region.x10"
        final x10.regionarray.Region t$138949 = ((x10.regionarray.Region)
                                                  t1);
        
        //#line 539 "x10/regionarray/Region.x10"
        final long t$158670 = t$138949.rank;
        
        //#line 539 "x10/regionarray/Region.x10"
        final long t$158671 = x10.regionarray.Region.this.rank;
        
        //#line 539 "x10/regionarray/Region.x10"
        final boolean t$158672 = ((long) t$158670) == ((long) t$158671);
        
        //#line 539 "x10/regionarray/Region.x10"
        final boolean t$158674 = !(t$158672);
        
        //#line 539 "x10/regionarray/Region.x10"
        if (t$158674) {
            
            //#line 539 "x10/regionarray/Region.x10"
            final x10.lang.FailedDynamicCheckException t$158673 = new x10.lang.FailedDynamicCheckException("x10.regionarray.Region{self.rank==this(:x10.regionarray.Region).rank}");
            
            //#line 539 "x10/regionarray/Region.x10"
            throw t$158673;
        }
        
        //#line 540 "x10/regionarray/Region.x10"
        boolean t$158675 = this.contains$O(((x10.regionarray.Region)(t$138949)));
        
        //#line 540 "x10/regionarray/Region.x10"
        if (t$158675) {
            
            //#line 540 "x10/regionarray/Region.x10"
            t$158675 = t$138949.contains$O(((x10.regionarray.Region)(this)));
        }
        
        //#line 540 "x10/regionarray/Region.x10"
        return t$158675;
    }
    
    
    //#line 543 "x10/regionarray/Region.x10"
    abstract public boolean contains$O(final x10.regionarray.Region that);
    
    
    //#line 546 "x10/regionarray/Region.x10"
    abstract public boolean contains$O(final x10.lang.Point p);
    
    
    //#line 548 "x10/regionarray/Region.x10"
    public boolean contains$O(final long i) {
        
        //#line 151 . "x10/lang/Point.x10"
        final x10.lang.Point alloc$158374 = ((x10.lang.Point)(new x10.lang.Point((java.lang.System[]) null)));
        
        //#line 151 . "x10/lang/Point.x10"
        alloc$158374.x10$lang$Point$$init$S(i);
        
        //#line 548 "x10/regionarray/Region.x10"
        final boolean t$158678 = this.contains$O(((x10.lang.Point)(alloc$158374)));
        
        //#line 548 "x10/regionarray/Region.x10"
        return t$158678;
    }
    
    
    //#line 550 "x10/regionarray/Region.x10"
    public boolean contains$O(final long i0, final long i1) {
        
        //#line 152 . "x10/lang/Point.x10"
        final x10.lang.Point alloc$158378 = ((x10.lang.Point)(new x10.lang.Point((java.lang.System[]) null)));
        
        //#line 152 . "x10/lang/Point.x10"
        alloc$158378.x10$lang$Point$$init$S(i0, i1);
        
        //#line 550 "x10/regionarray/Region.x10"
        final boolean t$158680 = this.contains$O(((x10.lang.Point)(alloc$158378)));
        
        //#line 550 "x10/regionarray/Region.x10"
        return t$158680;
    }
    
    
    //#line 552 "x10/regionarray/Region.x10"
    public boolean contains$O(final long i0, final long i1, final long i2) {
        
        //#line 153 . "x10/lang/Point.x10"
        final x10.lang.Point alloc$158383 = ((x10.lang.Point)(new x10.lang.Point((java.lang.System[]) null)));
        
        //#line 153 . "x10/lang/Point.x10"
        alloc$158383.x10$lang$Point$$init$S(i0, i1, i2);
        
        //#line 552 "x10/regionarray/Region.x10"
        final boolean t$158682 = this.contains$O(((x10.lang.Point)(alloc$158383)));
        
        //#line 552 "x10/regionarray/Region.x10"
        return t$158682;
    }
    
    
    //#line 554 "x10/regionarray/Region.x10"
    public boolean contains$O(final long i0, final long i1, final long i2, final long i3) {
        
        //#line 154 . "x10/lang/Point.x10"
        final x10.lang.Point alloc$158389 = ((x10.lang.Point)(new x10.lang.Point((java.lang.System[]) null)));
        
        //#line 154 . "x10/lang/Point.x10"
        alloc$158389.x10$lang$Point$$init$S(i0, i1, i2, i3);
        
        //#line 554 "x10/regionarray/Region.x10"
        final boolean t$158684 = this.contains$O(((x10.lang.Point)(alloc$158389)));
        
        //#line 554 "x10/regionarray/Region.x10"
        return t$158684;
    }
    
    
    //#line 556 "x10/regionarray/Region.x10"
    
    // constructor for non-virtual call
    final public x10.regionarray.Region x10$regionarray$Region$$init$S(final long r, final boolean t, final boolean z) {
         {
            
            //#line 557 "x10/regionarray/Region.x10"
            boolean t$158685 = ((long) r) == ((long) 1L);
            
            //#line 557 "x10/regionarray/Region.x10"
            if (t$158685) {
                
                //#line 557 "x10/regionarray/Region.x10"
                t$158685 = t;
            }
            
            //#line 557 "x10/regionarray/Region.x10"
            boolean t$158686 = t$158685;
            
            //#line 557 "x10/regionarray/Region.x10"
            if (t$158685) {
                
                //#line 557 "x10/regionarray/Region.x10"
                t$158686 = z;
            }
            
            //#line 558 "x10/regionarray/Region.x10"
            this.rank = r;
            this.rect = t;
            this.zeroBased = z;
            this.rail = t$158686;
            
        }
        return this;
    }
    
    
    
    //#line 565 "x10/regionarray/Region.x10"
    
    // constructor for non-virtual call
    final public x10.regionarray.Region x10$regionarray$Region$$init$S(final long r) {
         {
            
            //#line 566 "x10/regionarray/Region.x10"
            this.rank = r;
            this.rect = true;
            this.zeroBased = true;
            this.rail = true;
            
        }
        return this;
    }
    
    
    
    //#line 575 "x10/regionarray/Region.x10"
    /**
     * Constructs a distribution over this region that maps
     * every point in the region to the specified place.
     * @param p the given place
     * @return a "constant" distribution over this region that maps to p.
     */
    public x10.regionarray.Dist $arrow(final x10.lang.Place p) {
        
        //#line 575 "x10/regionarray/Region.x10"
        final x10.regionarray.Region r$158395 = ((x10.regionarray.Region)(this));
        
        //#line 171 . "x10/regionarray/Dist.x10"
        final x10.regionarray.ConstantDist alloc$158397 = ((x10.regionarray.ConstantDist)(new x10.regionarray.ConstantDist((java.lang.System[]) null)));
        
        //#line 171 . "x10/regionarray/Dist.x10"
        alloc$158397.x10$regionarray$ConstantDist$$init$S(((x10.regionarray.Region)(r$158395)), p);
        
        //#line 171 . "x10/regionarray/Dist.x10"
        final x10.regionarray.Dist t$158687 = ((x10.regionarray.Dist)(((x10.regionarray.Dist)
                                                                        alloc$158397)));
        
        //#line 575 "x10/regionarray/Region.x10"
        return t$158687;
    }
    
    
    //#line 26 "x10/regionarray/Region.x10"
    final public x10.regionarray.Region x10$regionarray$Region$$this$x10$regionarray$Region() {
        
        //#line 26 "x10/regionarray/Region.x10"
        return x10.regionarray.Region.this;
    }
    
    
    //#line 26 "x10/regionarray/Region.x10"
    final public void __fieldInitializers_x10_regionarray_Region() {
        
    }
    
    @x10.runtime.impl.java.X10Generated
    final public static class $Closure$294 extends x10.core.Ref implements x10.core.fun.Fun_0_1, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<$Closure$294> $RTT = 
            x10.rtt.StaticFunType.<$Closure$294> make($Closure$294.class,
                                                      new x10.rtt.Type[] {
                                                          x10.rtt.ParameterizedType.make(x10.core.fun.Fun_0_1.$RTT, x10.rtt.Types.LONG, x10.rtt.Types.LONG)
                                                      });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static x10.serialization.X10JavaSerializable $_deserialize_body(x10.regionarray.Region.$Closure$294 $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            $_obj.i$158714 = $deserializer.readLong();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.regionarray.Region.$Closure$294 $_obj = new x10.regionarray.Region.$Closure$294((java.lang.System[]) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            $serializer.write(this.i$158714);
            
        }
        
        // constructor just for allocation
        public $Closure$294(final java.lang.System[] $dummy) {
            
        }
        
        // dispatcher for method abstract public (Z1)=>U.operator()(a1:Z1):U
        public java.lang.Object $apply(final java.lang.Object a1, final x10.rtt.Type t1) {
            return x10.core.Long.$box($apply$O(x10.core.Long.$unbox(a1)));
            
        }
        
        // dispatcher for method abstract public (Z1)=>U.operator()(a1:Z1):U
        public long $apply$J(final java.lang.Object a1, final x10.rtt.Type t1) {
            return $apply$O(x10.core.Long.$unbox(a1));
            
        }
        
        
    
        
        public long $apply$O(final long j$158690) {
            
            //#line 110 "x10/regionarray/Region.x10"
            final boolean t$158691 = ((long) this.i$158714) == ((long) j$158690);
            
            //#line 110 "x10/regionarray/Region.x10"
            long t$158692 =  0;
            
            //#line 110 "x10/regionarray/Region.x10"
            if (t$158691) {
                
                //#line 110 "x10/regionarray/Region.x10"
                t$158692 = -1L;
            } else {
                
                //#line 110 "x10/regionarray/Region.x10"
                t$158692 = 0L;
            }
            
            //#line 110 "x10/regionarray/Region.x10"
            return t$158692;
        }
        
        public long i$158714;
        
        public $Closure$294(final long i$158714) {
             {
                this.i$158714 = i$158714;
            }
        }
        
    }
    
    @x10.runtime.impl.java.X10Generated
    final public static class $Closure$295 extends x10.core.Ref implements x10.core.fun.Fun_0_1, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<$Closure$295> $RTT = 
            x10.rtt.StaticFunType.<$Closure$295> make($Closure$295.class,
                                                      new x10.rtt.Type[] {
                                                          x10.rtt.ParameterizedType.make(x10.core.fun.Fun_0_1.$RTT, x10.rtt.Types.LONG, x10.rtt.Types.LONG)
                                                      });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static x10.serialization.X10JavaSerializable $_deserialize_body(x10.regionarray.Region.$Closure$295 $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            $_obj.i$158714 = $deserializer.readLong();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.regionarray.Region.$Closure$295 $_obj = new x10.regionarray.Region.$Closure$295((java.lang.System[]) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            $serializer.write(this.i$158714);
            
        }
        
        // constructor just for allocation
        public $Closure$295(final java.lang.System[] $dummy) {
            
        }
        
        // dispatcher for method abstract public (Z1)=>U.operator()(a1:Z1):U
        public java.lang.Object $apply(final java.lang.Object a1, final x10.rtt.Type t1) {
            return x10.core.Long.$box($apply$O(x10.core.Long.$unbox(a1)));
            
        }
        
        // dispatcher for method abstract public (Z1)=>U.operator()(a1:Z1):U
        public long $apply$J(final java.lang.Object a1, final x10.rtt.Type t1) {
            return $apply$O(x10.core.Long.$unbox(a1));
            
        }
        
        
    
        
        public long $apply$O(final long j$158698) {
            
            //#line 115 "x10/regionarray/Region.x10"
            final boolean t$158699 = ((long) this.i$158714) == ((long) j$158698);
            
            //#line 115 "x10/regionarray/Region.x10"
            long t$158700 =  0;
            
            //#line 115 "x10/regionarray/Region.x10"
            if (t$158699) {
                
                //#line 115 "x10/regionarray/Region.x10"
                t$158700 = 1L;
            } else {
                
                //#line 115 "x10/regionarray/Region.x10"
                t$158700 = 0L;
            }
            
            //#line 115 "x10/regionarray/Region.x10"
            return t$158700;
        }
        
        public long i$158714;
        
        public $Closure$295(final long i$158714) {
             {
                this.i$158714 = i$158714;
            }
        }
        
    }
    
    @x10.runtime.impl.java.X10Generated
    final public static class $Closure$296 extends x10.core.Ref implements x10.core.fun.Fun_0_1, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<$Closure$296> $RTT = 
            x10.rtt.StaticFunType.<$Closure$296> make($Closure$296.class,
                                                      new x10.rtt.Type[] {
                                                          x10.rtt.ParameterizedType.make(x10.core.fun.Fun_0_1.$RTT, x10.rtt.Types.LONG, x10.rtt.Types.LONG)
                                                      });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static x10.serialization.X10JavaSerializable $_deserialize_body(x10.regionarray.Region.$Closure$296 $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            $_obj.ranges = $deserializer.readObject();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.regionarray.Region.$Closure$296 $_obj = new x10.regionarray.Region.$Closure$296((java.lang.System[]) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            $serializer.write(this.ranges);
            
        }
        
        // constructor just for allocation
        public $Closure$296(final java.lang.System[] $dummy) {
            
        }
        
        // dispatcher for method abstract public (Z1)=>U.operator()(a1:Z1):U
        public java.lang.Object $apply(final java.lang.Object a1, final x10.rtt.Type t1) {
            return x10.core.Long.$box($apply$O(x10.core.Long.$unbox(a1)));
            
        }
        
        // dispatcher for method abstract public (Z1)=>U.operator()(a1:Z1):U
        public long $apply$J(final java.lang.Object a1, final x10.rtt.Type t1) {
            return $apply$O(x10.core.Long.$unbox(a1));
            
        }
        
        // synthetic type for parameter mangling
        public static final class __0$1x10$lang$IntRange$2 {}
        
    
        
        public long $apply$O(final long i) {
            
            //#line 144 "x10/regionarray/Region.x10"
            final x10.lang.IntRange t$158471 = ((x10.lang.IntRange[])this.ranges.value)[(int)i];
            
            //#line 144 "x10/regionarray/Region.x10"
            final int t$158472 = t$158471.min;
            
            //#line 144 "x10/regionarray/Region.x10"
            final long t$158473 = ((long)(((int)(t$158472))));
            
            //#line 144 "x10/regionarray/Region.x10"
            return t$158473;
        }
        
        public x10.core.Rail<x10.lang.IntRange> ranges;
        
        public $Closure$296(final x10.core.Rail<x10.lang.IntRange> ranges, __0$1x10$lang$IntRange$2 $dummy) {
             {
                this.ranges = ((x10.core.Rail)(ranges));
            }
        }
        
    }
    
    @x10.runtime.impl.java.X10Generated
    final public static class $Closure$297 extends x10.core.Ref implements x10.core.fun.Fun_0_1, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<$Closure$297> $RTT = 
            x10.rtt.StaticFunType.<$Closure$297> make($Closure$297.class,
                                                      new x10.rtt.Type[] {
                                                          x10.rtt.ParameterizedType.make(x10.core.fun.Fun_0_1.$RTT, x10.rtt.Types.LONG, x10.rtt.Types.LONG)
                                                      });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static x10.serialization.X10JavaSerializable $_deserialize_body(x10.regionarray.Region.$Closure$297 $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            $_obj.ranges = $deserializer.readObject();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.regionarray.Region.$Closure$297 $_obj = new x10.regionarray.Region.$Closure$297((java.lang.System[]) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            $serializer.write(this.ranges);
            
        }
        
        // constructor just for allocation
        public $Closure$297(final java.lang.System[] $dummy) {
            
        }
        
        // dispatcher for method abstract public (Z1)=>U.operator()(a1:Z1):U
        public java.lang.Object $apply(final java.lang.Object a1, final x10.rtt.Type t1) {
            return x10.core.Long.$box($apply$O(x10.core.Long.$unbox(a1)));
            
        }
        
        // dispatcher for method abstract public (Z1)=>U.operator()(a1:Z1):U
        public long $apply$J(final java.lang.Object a1, final x10.rtt.Type t1) {
            return $apply$O(x10.core.Long.$unbox(a1));
            
        }
        
        // synthetic type for parameter mangling
        public static final class __0$1x10$lang$IntRange$2 {}
        
    
        
        public long $apply$O(final long i) {
            
            //#line 145 "x10/regionarray/Region.x10"
            final x10.lang.IntRange t$158476 = ((x10.lang.IntRange[])this.ranges.value)[(int)i];
            
            //#line 145 "x10/regionarray/Region.x10"
            final int t$158477 = t$158476.max;
            
            //#line 145 "x10/regionarray/Region.x10"
            final long t$158478 = ((long)(((int)(t$158477))));
            
            //#line 145 "x10/regionarray/Region.x10"
            return t$158478;
        }
        
        public x10.core.Rail<x10.lang.IntRange> ranges;
        
        public $Closure$297(final x10.core.Rail<x10.lang.IntRange> ranges, __0$1x10$lang$IntRange$2 $dummy) {
             {
                this.ranges = ((x10.core.Rail)(ranges));
            }
        }
        
    }
    
    @x10.runtime.impl.java.X10Generated
    final public static class $Closure$298 extends x10.core.Ref implements x10.core.fun.Fun_0_1, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<$Closure$298> $RTT = 
            x10.rtt.StaticFunType.<$Closure$298> make($Closure$298.class,
                                                      new x10.rtt.Type[] {
                                                          x10.rtt.ParameterizedType.make(x10.core.fun.Fun_0_1.$RTT, x10.rtt.Types.LONG, x10.rtt.Types.LONG)
                                                      });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static x10.serialization.X10JavaSerializable $_deserialize_body(x10.regionarray.Region.$Closure$298 $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            $_obj.ranges = $deserializer.readObject();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.regionarray.Region.$Closure$298 $_obj = new x10.regionarray.Region.$Closure$298((java.lang.System[]) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            $serializer.write(this.ranges);
            
        }
        
        // constructor just for allocation
        public $Closure$298(final java.lang.System[] $dummy) {
            
        }
        
        // dispatcher for method abstract public (Z1)=>U.operator()(a1:Z1):U
        public java.lang.Object $apply(final java.lang.Object a1, final x10.rtt.Type t1) {
            return x10.core.Long.$box($apply$O(x10.core.Long.$unbox(a1)));
            
        }
        
        // dispatcher for method abstract public (Z1)=>U.operator()(a1:Z1):U
        public long $apply$J(final java.lang.Object a1, final x10.rtt.Type t1) {
            return $apply$O(x10.core.Long.$unbox(a1));
            
        }
        
        // synthetic type for parameter mangling
        public static final class __0$1x10$lang$LongRange$2 {}
        
    
        
        public long $apply$O(final long i) {
            
            //#line 162 "x10/regionarray/Region.x10"
            final x10.lang.LongRange t$158495 = ((x10.lang.LongRange[])this.ranges.value)[(int)i];
            
            //#line 162 "x10/regionarray/Region.x10"
            final long t$158496 = t$158495.min;
            
            //#line 162 "x10/regionarray/Region.x10"
            return t$158496;
        }
        
        public x10.core.Rail<x10.lang.LongRange> ranges;
        
        public $Closure$298(final x10.core.Rail<x10.lang.LongRange> ranges, __0$1x10$lang$LongRange$2 $dummy) {
             {
                this.ranges = ((x10.core.Rail)(ranges));
            }
        }
        
    }
    
    @x10.runtime.impl.java.X10Generated
    final public static class $Closure$299 extends x10.core.Ref implements x10.core.fun.Fun_0_1, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<$Closure$299> $RTT = 
            x10.rtt.StaticFunType.<$Closure$299> make($Closure$299.class,
                                                      new x10.rtt.Type[] {
                                                          x10.rtt.ParameterizedType.make(x10.core.fun.Fun_0_1.$RTT, x10.rtt.Types.LONG, x10.rtt.Types.LONG)
                                                      });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static x10.serialization.X10JavaSerializable $_deserialize_body(x10.regionarray.Region.$Closure$299 $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            $_obj.ranges = $deserializer.readObject();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.regionarray.Region.$Closure$299 $_obj = new x10.regionarray.Region.$Closure$299((java.lang.System[]) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            $serializer.write(this.ranges);
            
        }
        
        // constructor just for allocation
        public $Closure$299(final java.lang.System[] $dummy) {
            
        }
        
        // dispatcher for method abstract public (Z1)=>U.operator()(a1:Z1):U
        public java.lang.Object $apply(final java.lang.Object a1, final x10.rtt.Type t1) {
            return x10.core.Long.$box($apply$O(x10.core.Long.$unbox(a1)));
            
        }
        
        // dispatcher for method abstract public (Z1)=>U.operator()(a1:Z1):U
        public long $apply$J(final java.lang.Object a1, final x10.rtt.Type t1) {
            return $apply$O(x10.core.Long.$unbox(a1));
            
        }
        
        // synthetic type for parameter mangling
        public static final class __0$1x10$lang$LongRange$2 {}
        
    
        
        public long $apply$O(final long i) {
            
            //#line 163 "x10/regionarray/Region.x10"
            final x10.lang.LongRange t$158499 = ((x10.lang.LongRange[])this.ranges.value)[(int)i];
            
            //#line 163 "x10/regionarray/Region.x10"
            final long t$158500 = t$158499.max;
            
            //#line 163 "x10/regionarray/Region.x10"
            return t$158500;
        }
        
        public x10.core.Rail<x10.lang.LongRange> ranges;
        
        public $Closure$299(final x10.core.Rail<x10.lang.LongRange> ranges, __0$1x10$lang$LongRange$2 $dummy) {
             {
                this.ranges = ((x10.core.Rail)(ranges));
            }
        }
        
    }
    
}



