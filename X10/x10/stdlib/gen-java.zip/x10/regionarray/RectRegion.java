package x10.regionarray;


/**
 * A RectRegion is a finite dense rectangular region with a specified rank.
 * This class implements a specialization of PolyRegion.
 */
@x10.runtime.impl.java.X10Generated
final public class RectRegion extends x10.regionarray.Region implements x10.serialization.X10JavaSerializable
{
    public static final x10.rtt.RuntimeType<RectRegion> $RTT = 
        x10.rtt.NamedType.<RectRegion> make("x10.regionarray.RectRegion",
                                            RectRegion.class,
                                            new x10.rtt.Type[] {
                                                x10.regionarray.Region.$RTT
                                            });
    
    public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
    
    public x10.rtt.Type<?> $getParam(int i) { return null; }
    
    private Object writeReplace() throws java.io.ObjectStreamException {
        return new x10.serialization.SerializationProxy(this);
    }
    
    public static x10.serialization.X10JavaSerializable $_deserialize_body(x10.regionarray.RectRegion $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
        x10.regionarray.Region.$_deserialize_body($_obj, $deserializer);
        $_obj.max0 = $deserializer.readLong();
        $_obj.max1 = $deserializer.readLong();
        $_obj.max2 = $deserializer.readLong();
        $_obj.max3 = $deserializer.readLong();
        $_obj.maxs = $deserializer.readObject();
        $_obj.min0 = $deserializer.readLong();
        $_obj.min1 = $deserializer.readLong();
        $_obj.min2 = $deserializer.readLong();
        $_obj.min3 = $deserializer.readLong();
        $_obj.mins = $deserializer.readObject();
        $_obj.size = $deserializer.readLong();
        return $_obj;
    }
    
    public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
        x10.regionarray.RectRegion $_obj = new x10.regionarray.RectRegion((java.lang.System[]) null);
        $deserializer.record_reference($_obj);
        return $_deserialize_body($_obj, $deserializer);
    }
    
    public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
        super.$_serialize($serializer);
        $serializer.write(this.max0);
        $serializer.write(this.max1);
        $serializer.write(this.max2);
        $serializer.write(this.max3);
        $serializer.write(this.maxs);
        $serializer.write(this.min0);
        $serializer.write(this.min1);
        $serializer.write(this.min2);
        $serializer.write(this.min3);
        $serializer.write(this.mins);
        $serializer.write(this.size);
        
    }
    
    // constructor just for allocation
    public RectRegion(final java.lang.System[] $dummy) {
        super($dummy);
        
    }
    
    // synthetic type for parameter mangling
    public static final class __0$1x10$lang$Long$2__1$1x10$lang$Long$2 {}
    

    
    //#line 23 "x10/regionarray/RectRegion.x10"
    public long size;
    
    //#line 24 "x10/regionarray/RectRegion.x10"
    public x10.core.Rail<x10.core.Long> mins;
    
    //#line 25 "x10/regionarray/RectRegion.x10"
    public x10.core.Rail<x10.core.Long> maxs;
    
    //#line 27 "x10/regionarray/RectRegion.x10"
    public long min0;
    
    //#line 28 "x10/regionarray/RectRegion.x10"
    public long min1;
    
    //#line 29 "x10/regionarray/RectRegion.x10"
    public long min2;
    
    //#line 30 "x10/regionarray/RectRegion.x10"
    public long min3;
    
    //#line 31 "x10/regionarray/RectRegion.x10"
    public long max0;
    
    //#line 32 "x10/regionarray/RectRegion.x10"
    public long max1;
    
    //#line 33 "x10/regionarray/RectRegion.x10"
    public long max2;
    
    //#line 34 "x10/regionarray/RectRegion.x10"
    public long max3;
    
    //#line 37 "x10/regionarray/RectRegion.x10"
    public transient x10.regionarray.Region polyRep;
    
    
    //#line 39 "x10/regionarray/RectRegion.x10"
    private static boolean allZeros__0$1x10$lang$Long$2$O(final x10.core.Rail<x10.core.Long> a) {
        
        //#line 40 "x10/regionarray/RectRegion.x10"
        final long i$146103max$157983 = ((x10.core.Rail<x10.core.Long>)a).size;
        
        //#line 40 "x10/regionarray/RectRegion.x10"
        long i$157979 = 0L;
        {
            
            //#line 40 "x10/regionarray/RectRegion.x10"
            final long[] a$value$158174 = ((long[])a.value);
            
            //#line 40 "x10/regionarray/RectRegion.x10"
            for (;
                 true;
                 ) {
                
                //#line 40 "x10/regionarray/RectRegion.x10"
                final boolean t$157981 = ((i$157979) < (((long)(i$146103max$157983))));
                
                //#line 40 "x10/regionarray/RectRegion.x10"
                if (!(t$157981)) {
                    
                    //#line 40 "x10/regionarray/RectRegion.x10"
                    break;
                }
                
                //#line 40 "x10/regionarray/RectRegion.x10"
                final long t$157974 = ((long)a$value$158174[(int)i$157979]);
                
                //#line 40 "x10/regionarray/RectRegion.x10"
                final boolean t$157975 = ((long) t$157974) != ((long) 0L);
                
                //#line 40 "x10/regionarray/RectRegion.x10"
                if (t$157975) {
                    
                    //#line 40 "x10/regionarray/RectRegion.x10"
                    return false;
                }
                
                //#line 40 "x10/regionarray/RectRegion.x10"
                final long t$157978 = ((i$157979) + (((long)(1L))));
                
                //#line 40 "x10/regionarray/RectRegion.x10"
                i$157979 = t$157978;
            }
        }
        
        //#line 41 "x10/regionarray/RectRegion.x10"
        return true;
    }
    
    public static boolean allZeros$P__0$1x10$lang$Long$2$O(final x10.core.Rail<x10.core.Long> a) {
        return x10.regionarray.RectRegion.allZeros__0$1x10$lang$Long$2$O(((x10.core.Rail)(a)));
    }
    
    
    //#line 47 "x10/regionarray/RectRegion.x10"
    /**
     * Create a rectangular region containing all points p such that min <= p and p <= max.
     */
    // creation method for java code (1-phase java constructor)
    public RectRegion(final x10.core.Rail<x10.core.Long> minArg, final x10.core.Rail<x10.core.Long> maxArg, __0$1x10$lang$Long$2__1$1x10$lang$Long$2 $dummy) {
        this((java.lang.System[]) null);
        x10$regionarray$RectRegion$$init$S(minArg, maxArg, (x10.regionarray.RectRegion.__0$1x10$lang$Long$2__1$1x10$lang$Long$2) null);
    }
    
    // constructor for non-virtual call
    final public x10.regionarray.RectRegion x10$regionarray$RectRegion$$init$S(final x10.core.Rail<x10.core.Long> minArg, final x10.core.Rail<x10.core.Long> maxArg, __0$1x10$lang$Long$2__1$1x10$lang$Long$2 $dummy) {
         {
            
            //#line 48 "x10/regionarray/RectRegion.x10"
            final x10.regionarray.Region this$157170 = ((x10.regionarray.Region)(this));
            
            //#line 48 "x10/regionarray/RectRegion.x10"
            final long r$157166 = ((x10.core.Rail<x10.core.Long>)minArg).size;
            
            //#line 48 "x10/regionarray/RectRegion.x10"
            final boolean z$157168 = x10.regionarray.RectRegion.allZeros__0$1x10$lang$Long$2$O(((x10.core.Rail)(minArg)));
            
            //#line 557 . "x10/regionarray/Region.x10"
            boolean t$158005 = ((long) r$157166) == ((long) 1L);
            
            //#line 557 . "x10/regionarray/Region.x10"
            if (t$158005) {
                
                //#line 557 . "x10/regionarray/Region.x10"
                t$158005 = true;
            }
            
            //#line 557 . "x10/regionarray/Region.x10"
            boolean t$158006 = t$158005;
            
            //#line 557 . "x10/regionarray/Region.x10"
            if (t$158005) {
                
                //#line 557 . "x10/regionarray/Region.x10"
                t$158006 = z$157168;
            }
            
            //#line 558 . "x10/regionarray/Region.x10"
            this$157170.rank = r$157166;
            
            //#line 558 . "x10/regionarray/Region.x10"
            this$157170.rect = true;
            
            //#line 558 . "x10/regionarray/Region.x10"
            this$157170.zeroBased = z$157168;
            
            //#line 558 . "x10/regionarray/Region.x10"
            this$157170.rail = t$158006;
            
            //#line 47 "x10/regionarray/RectRegion.x10"
            
            
            //#line 21 "x10/regionarray/RectRegion.x10"
            final x10.regionarray.RectRegion this$158008 = this;
            
            //#line 21 "x10/regionarray/RectRegion.x10"
            this$158008.polyRep = null;
            
            //#line 50 "x10/regionarray/RectRegion.x10"
            final long t$157277 = ((x10.core.Rail<x10.core.Long>)minArg).size;
            
            //#line 50 "x10/regionarray/RectRegion.x10"
            final long t$157278 = ((x10.core.Rail<x10.core.Long>)maxArg).size;
            
            //#line 50 "x10/regionarray/RectRegion.x10"
            final boolean t$157280 = ((long) t$157277) != ((long) t$157278);
            
            //#line 50 "x10/regionarray/RectRegion.x10"
            if (t$157280) {
                
                //#line 50 "x10/regionarray/RectRegion.x10"
                final java.lang.IllegalArgumentException t$157279 = ((java.lang.IllegalArgumentException)(new java.lang.IllegalArgumentException("size of min and max args are not equal")));
                
                //#line 50 "x10/regionarray/RectRegion.x10"
                throw t$157279;
            }
            
            //#line 52 "x10/regionarray/RectRegion.x10"
            long s = 1L;
            
            //#line 53 "x10/regionarray/RectRegion.x10"
            final long i$146122max$158010 = ((x10.core.Rail<x10.core.Long>)minArg).size;
            
            //#line 53 "x10/regionarray/RectRegion.x10"
            long i$158002 = 0L;
            {
                
                //#line 53 "x10/regionarray/RectRegion.x10"
                final long[] maxArg$value$158175 = ((long[])maxArg.value);
                
                //#line 53 "x10/regionarray/RectRegion.x10"
                final long[] minArg$value$158176 = ((long[])minArg.value);
                
                //#line 53 "x10/regionarray/RectRegion.x10"
                for (;
                     true;
                     ) {
                    
                    //#line 53 "x10/regionarray/RectRegion.x10"
                    final boolean t$158004 = ((i$158002) < (((long)(i$146122max$158010))));
                    
                    //#line 53 "x10/regionarray/RectRegion.x10"
                    if (!(t$158004)) {
                        
                        //#line 53 "x10/regionarray/RectRegion.x10"
                        break;
                    }
                    
                    //#line 54 "x10/regionarray/RectRegion.x10"
                    final long t$157984 = ((long)maxArg$value$158175[(int)i$158002]);
                    
                    //#line 54 "x10/regionarray/RectRegion.x10"
                    final long t$157985 = ((long)minArg$value$158176[(int)i$158002]);
                    
                    //#line 54 "x10/regionarray/RectRegion.x10"
                    final long t$157986 = ((t$157984) - (((long)(t$157985))));
                    
                    //#line 54 "x10/regionarray/RectRegion.x10"
                    long rs$157987 = ((t$157986) + (((long)(1L))));
                    
                    //#line 55 "x10/regionarray/RectRegion.x10"
                    final boolean t$157989 = ((rs$157987) < (((long)(0L))));
                    
                    //#line 55 "x10/regionarray/RectRegion.x10"
                    if (t$157989) {
                        
                        //#line 55 "x10/regionarray/RectRegion.x10"
                        rs$157987 = 0L;
                    }
                    
                    //#line 56 "x10/regionarray/RectRegion.x10"
                    final long t$157990 = ((long)maxArg$value$158175[(int)i$158002]);
                    
                    //#line 56 "x10/regionarray/RectRegion.x10"
                    final long t$157991 = java.lang.Long.MAX_VALUE;
                    
                    //#line 56 "x10/regionarray/RectRegion.x10"
                    boolean t$157992 = ((long) t$157990) == ((long) t$157991);
                    
                    //#line 56 "x10/regionarray/RectRegion.x10"
                    if (t$157992) {
                        
                        //#line 56 "x10/regionarray/RectRegion.x10"
                        final long t$157993 = ((long)minArg$value$158176[(int)i$158002]);
                        
                        //#line 56 "x10/regionarray/RectRegion.x10"
                        final long t$157994 = java.lang.Long.MIN_VALUE;
                        
                        //#line 56 "x10/regionarray/RectRegion.x10"
                        t$157992 = ((long) t$157993) == ((long) t$157994);
                    }
                    
                    //#line 56 "x10/regionarray/RectRegion.x10"
                    if (t$157992) {
                        
                        //#line 57 "x10/regionarray/RectRegion.x10"
                        s = -1L;
                        
                        //#line 58 "x10/regionarray/RectRegion.x10"
                        break;
                    }
                    
                    //#line 60 "x10/regionarray/RectRegion.x10"
                    final long t$157998 = ((s) * (((long)(rs$157987))));
                    
                    //#line 60 "x10/regionarray/RectRegion.x10"
                    s = t$157998;
                    
                    //#line 53 "x10/regionarray/RectRegion.x10"
                    final long t$158001 = ((i$158002) + (((long)(1L))));
                    
                    //#line 53 "x10/regionarray/RectRegion.x10"
                    i$158002 = t$158001;
                }
            }
            
            //#line 62 "x10/regionarray/RectRegion.x10"
            this.size = s;
            
            //#line 64 "x10/regionarray/RectRegion.x10"
            final long t$157301 = ((x10.core.Rail<x10.core.Long>)minArg).size;
            
            //#line 64 "x10/regionarray/RectRegion.x10"
            final boolean t$157305 = ((t$157301) > (((long)(0L))));
            
            //#line 64 "x10/regionarray/RectRegion.x10"
            if (t$157305) {
                
                //#line 65 "x10/regionarray/RectRegion.x10"
                final long t$157302 = ((long[])minArg.value)[(int)0L];
                
                //#line 65 "x10/regionarray/RectRegion.x10"
                this.min0 = t$157302;
                
                //#line 66 "x10/regionarray/RectRegion.x10"
                final long t$157303 = ((long[])maxArg.value)[(int)0L];
                
                //#line 66 "x10/regionarray/RectRegion.x10"
                this.max0 = t$157303;
            } else {
                
                //#line 68 "x10/regionarray/RectRegion.x10"
                final long t$157304 = this.max0 = 0L;
                
                //#line 68 "x10/regionarray/RectRegion.x10"
                this.min0 = t$157304;
            }
            
            //#line 71 "x10/regionarray/RectRegion.x10"
            final long t$157306 = ((x10.core.Rail<x10.core.Long>)minArg).size;
            
            //#line 71 "x10/regionarray/RectRegion.x10"
            final boolean t$157310 = ((t$157306) > (((long)(1L))));
            
            //#line 71 "x10/regionarray/RectRegion.x10"
            if (t$157310) {
                
                //#line 72 "x10/regionarray/RectRegion.x10"
                final long t$157307 = ((long[])minArg.value)[(int)1L];
                
                //#line 72 "x10/regionarray/RectRegion.x10"
                this.min1 = t$157307;
                
                //#line 73 "x10/regionarray/RectRegion.x10"
                final long t$157308 = ((long[])maxArg.value)[(int)1L];
                
                //#line 73 "x10/regionarray/RectRegion.x10"
                this.max1 = t$157308;
            } else {
                
                //#line 75 "x10/regionarray/RectRegion.x10"
                final long t$157309 = this.max1 = 0L;
                
                //#line 75 "x10/regionarray/RectRegion.x10"
                this.min1 = t$157309;
            }
            
            //#line 78 "x10/regionarray/RectRegion.x10"
            final long t$157311 = ((x10.core.Rail<x10.core.Long>)minArg).size;
            
            //#line 78 "x10/regionarray/RectRegion.x10"
            final boolean t$157315 = ((t$157311) > (((long)(2L))));
            
            //#line 78 "x10/regionarray/RectRegion.x10"
            if (t$157315) {
                
                //#line 79 "x10/regionarray/RectRegion.x10"
                final long t$157312 = ((long[])minArg.value)[(int)2L];
                
                //#line 79 "x10/regionarray/RectRegion.x10"
                this.min2 = t$157312;
                
                //#line 80 "x10/regionarray/RectRegion.x10"
                final long t$157313 = ((long[])maxArg.value)[(int)2L];
                
                //#line 80 "x10/regionarray/RectRegion.x10"
                this.max2 = t$157313;
            } else {
                
                //#line 82 "x10/regionarray/RectRegion.x10"
                final long t$157314 = this.max2 = 0L;
                
                //#line 82 "x10/regionarray/RectRegion.x10"
                this.min2 = t$157314;
            }
            
            //#line 85 "x10/regionarray/RectRegion.x10"
            final long t$157316 = ((x10.core.Rail<x10.core.Long>)minArg).size;
            
            //#line 85 "x10/regionarray/RectRegion.x10"
            final boolean t$157320 = ((t$157316) > (((long)(3L))));
            
            //#line 85 "x10/regionarray/RectRegion.x10"
            if (t$157320) {
                
                //#line 86 "x10/regionarray/RectRegion.x10"
                final long t$157317 = ((long[])minArg.value)[(int)3L];
                
                //#line 86 "x10/regionarray/RectRegion.x10"
                this.min3 = t$157317;
                
                //#line 87 "x10/regionarray/RectRegion.x10"
                final long t$157318 = ((long[])maxArg.value)[(int)3L];
                
                //#line 87 "x10/regionarray/RectRegion.x10"
                this.max3 = t$157318;
            } else {
                
                //#line 89 "x10/regionarray/RectRegion.x10"
                final long t$157319 = this.max3 = 0L;
                
                //#line 89 "x10/regionarray/RectRegion.x10"
                this.min3 = t$157319;
            }
            
            //#line 92 "x10/regionarray/RectRegion.x10"
            final long t$157321 = ((x10.core.Rail<x10.core.Long>)minArg).size;
            
            //#line 92 "x10/regionarray/RectRegion.x10"
            final boolean t$157322 = ((t$157321) > (((long)(4L))));
            
            //#line 92 "x10/regionarray/RectRegion.x10"
            if (t$157322) {
                
                //#line 93 "x10/regionarray/RectRegion.x10"
                this.mins = ((x10.core.Rail)(minArg));
                
                //#line 94 "x10/regionarray/RectRegion.x10"
                this.maxs = ((x10.core.Rail)(maxArg));
            } else {
                
                //#line 96 "x10/regionarray/RectRegion.x10"
                this.mins = null;
                
                //#line 97 "x10/regionarray/RectRegion.x10"
                this.maxs = null;
            }
        }
        return this;
    }
    
    
    
    //#line 104 "x10/regionarray/RectRegion.x10"
    /**
     * Create a 1-dim region min..max.
     */
    // creation method for java code (1-phase java constructor)
    public RectRegion(final long min, final long max) {
        this((java.lang.System[]) null);
        x10$regionarray$RectRegion$$init$S(min, max);
    }
    
    // constructor for non-virtual call
    final public x10.regionarray.RectRegion x10$regionarray$RectRegion$$init$S(final long min, final long max) {
         {
            
            //#line 105 "x10/regionarray/RectRegion.x10"
            final x10.regionarray.Region this$157179 = ((x10.regionarray.Region)(this));
            
            //#line 105 "x10/regionarray/RectRegion.x10"
            final boolean z$157177 = ((long) min) == ((long) 0L);
            
            //#line 558 . "x10/regionarray/Region.x10"
            this$157179.rank = 1L;
            
            //#line 558 . "x10/regionarray/Region.x10"
            this$157179.rect = true;
            
            //#line 558 . "x10/regionarray/Region.x10"
            this$157179.zeroBased = z$157177;
            
            //#line 558 . "x10/regionarray/Region.x10"
            this$157179.rail = z$157177;
            
            //#line 104 "x10/regionarray/RectRegion.x10"
            
            
            //#line 21 "x10/regionarray/RectRegion.x10"
            final x10.regionarray.RectRegion this$158012 = this;
            
            //#line 21 "x10/regionarray/RectRegion.x10"
            this$158012.polyRep = null;
            
            //#line 107 "x10/regionarray/RectRegion.x10"
            final long t$157323 = java.lang.Long.MIN_VALUE;
            
            //#line 107 "x10/regionarray/RectRegion.x10"
            boolean t$157325 = ((long) min) == ((long) t$157323);
            
            //#line 107 "x10/regionarray/RectRegion.x10"
            if (t$157325) {
                
                //#line 107 "x10/regionarray/RectRegion.x10"
                final long t$157324 = java.lang.Long.MAX_VALUE;
                
                //#line 107 "x10/regionarray/RectRegion.x10"
                t$157325 = ((long) max) == ((long) t$157324);
            }
            
            //#line 107 "x10/regionarray/RectRegion.x10"
            long t$157328 =  0;
            
            //#line 107 "x10/regionarray/RectRegion.x10"
            if (t$157325) {
                
                //#line 107 "x10/regionarray/RectRegion.x10"
                t$157328 = -1L;
            } else {
                
                //#line 107 "x10/regionarray/RectRegion.x10"
                final long t$157326 = ((max) - (((long)(min))));
                
                //#line 107 "x10/regionarray/RectRegion.x10"
                t$157328 = ((t$157326) + (((long)(1L))));
            }
            
            //#line 107 "x10/regionarray/RectRegion.x10"
            this.size = t$157328;
            
            //#line 108 "x10/regionarray/RectRegion.x10"
            this.min0 = min;
            
            //#line 109 "x10/regionarray/RectRegion.x10"
            this.max0 = max;
            
            //#line 111 "x10/regionarray/RectRegion.x10"
            final long t$157330 = this.min3 = 0L;
            
            //#line 111 "x10/regionarray/RectRegion.x10"
            final long t$157331 = this.min2 = t$157330;
            
            //#line 111 "x10/regionarray/RectRegion.x10"
            this.min1 = t$157331;
            
            //#line 112 "x10/regionarray/RectRegion.x10"
            final long t$157332 = this.max3 = 0L;
            
            //#line 112 "x10/regionarray/RectRegion.x10"
            final long t$157333 = this.max2 = t$157332;
            
            //#line 112 "x10/regionarray/RectRegion.x10"
            this.max1 = t$157333;
            
            //#line 113 "x10/regionarray/RectRegion.x10"
            this.mins = null;
            
            //#line 114 "x10/regionarray/RectRegion.x10"
            this.maxs = null;
        }
        return this;
    }
    
    
    
    //#line 117 "x10/regionarray/RectRegion.x10"
    public long size$O() {
        
        //#line 118 "x10/regionarray/RectRegion.x10"
        final long t$157334 = this.size;
        
        //#line 118 "x10/regionarray/RectRegion.x10"
        final boolean t$157336 = ((t$157334) < (((long)(0L))));
        
        //#line 118 "x10/regionarray/RectRegion.x10"
        if (t$157336) {
            
            //#line 118 "x10/regionarray/RectRegion.x10"
            final x10.regionarray.UnboundedRegionException t$157335 = ((x10.regionarray.UnboundedRegionException)(new x10.regionarray.UnboundedRegionException(((java.lang.String)("size exceeds capacity of long")))));
            
            //#line 118 "x10/regionarray/RectRegion.x10"
            throw t$157335;
        }
        
        //#line 119 "x10/regionarray/RectRegion.x10"
        final long t$157337 = this.size;
        
        //#line 119 "x10/regionarray/RectRegion.x10"
        return t$157337;
    }
    
    
    //#line 122 "x10/regionarray/RectRegion.x10"
    public boolean isConvex$O() {
        
        //#line 122 "x10/regionarray/RectRegion.x10"
        return true;
    }
    
    
    //#line 124 "x10/regionarray/RectRegion.x10"
    public boolean isEmpty$O() {
        
        //#line 124 "x10/regionarray/RectRegion.x10"
        final long t$157338 = this.size;
        
        //#line 124 "x10/regionarray/RectRegion.x10"
        final boolean t$157339 = ((long) t$157338) == ((long) 0L);
        
        //#line 124 "x10/regionarray/RectRegion.x10"
        return t$157339;
    }
    
    
    //#line 126 "x10/regionarray/RectRegion.x10"
    public long indexOf$O(final x10.lang.Point pt) {
        
        //#line 127 "x10/regionarray/RectRegion.x10"
        final boolean t$157340 = this.contains$O(((x10.lang.Point)(pt)));
        
        //#line 127 "x10/regionarray/RectRegion.x10"
        final boolean t$157341 = !(t$157340);
        
        //#line 127 "x10/regionarray/RectRegion.x10"
        if (t$157341) {
            
            //#line 127 "x10/regionarray/RectRegion.x10"
            return -1L;
        }
        
        //#line 128 "x10/regionarray/RectRegion.x10"
        final long t$157342 = ((long)(((int)(0))));
        
        //#line 128 "x10/regionarray/RectRegion.x10"
        final long t$157344 = pt.$apply$O((long)(t$157342));
        
        //#line 128 "x10/regionarray/RectRegion.x10"
        final long t$157343 = ((long)(((int)(0))));
        
        //#line 128 "x10/regionarray/RectRegion.x10"
        final long t$157345 = this.min$O((long)(t$157343));
        
        //#line 128 "x10/regionarray/RectRegion.x10"
        long offset = ((t$157344) - (((long)(t$157345))));
        
        //#line 129 "x10/regionarray/RectRegion.x10"
        final long t$158028 = this.rank;
        
        //#line 129 "x10/regionarray/RectRegion.x10"
        final long i$146141max$158029 = ((t$158028) - (((long)(1L))));
        
        //#line 129 "x10/regionarray/RectRegion.x10"
        long i$158025 = 1L;
        
        //#line 129 "x10/regionarray/RectRegion.x10"
        for (;
             true;
             ) {
            
            //#line 129 "x10/regionarray/RectRegion.x10"
            final boolean t$158027 = ((i$158025) <= (((long)(i$146141max$158029))));
            
            //#line 129 "x10/regionarray/RectRegion.x10"
            if (!(t$158027)) {
                
                //#line 129 "x10/regionarray/RectRegion.x10"
                break;
            }
            
            //#line 130 "x10/regionarray/RectRegion.x10"
            final long min_i$158013 = this.min$O((long)(i$158025));
            
            //#line 131 "x10/regionarray/RectRegion.x10"
            final long max_i$158014 = this.max$O((long)(i$158025));
            
            //#line 132 "x10/regionarray/RectRegion.x10"
            final long pt_i$158015 = pt.$apply$O((long)(i$158025));
            
            //#line 133 "x10/regionarray/RectRegion.x10"
            final long t$158016 = ((max_i$158014) - (((long)(min_i$158013))));
            
            //#line 133 "x10/regionarray/RectRegion.x10"
            final long delta_i$158017 = ((t$158016) + (((long)(1L))));
            
            //#line 134 "x10/regionarray/RectRegion.x10"
            final long t$158019 = ((offset) * (((long)(delta_i$158017))));
            
            //#line 134 "x10/regionarray/RectRegion.x10"
            final long t$158020 = ((t$158019) + (((long)(pt_i$158015))));
            
            //#line 134 "x10/regionarray/RectRegion.x10"
            final long t$158021 = ((t$158020) - (((long)(min_i$158013))));
            
            //#line 134 "x10/regionarray/RectRegion.x10"
            offset = t$158021;
            
            //#line 129 "x10/regionarray/RectRegion.x10"
            final long t$158024 = ((i$158025) + (((long)(1L))));
            
            //#line 129 "x10/regionarray/RectRegion.x10"
            i$158025 = t$158024;
        }
        
        //#line 136 "x10/regionarray/RectRegion.x10"
        return offset;
    }
    
    
    //#line 139 "x10/regionarray/RectRegion.x10"
    public long indexOf$O(final long i0) {
        
        //#line 140 "x10/regionarray/RectRegion.x10"
        final boolean t$157374 = this.zeroBased;
        
        //#line 140 "x10/regionarray/RectRegion.x10"
        if (t$157374) {
            
            //#line 141 "x10/regionarray/RectRegion.x10"
            final long t$157358 = this.rank;
            
            //#line 141 "x10/regionarray/RectRegion.x10"
            boolean t$157363 = ((long) t$157358) != ((long) 1L);
            
            //#line 141 "x10/regionarray/RectRegion.x10"
            if (!(t$157363)) {
                
                //#line 141 "x10/regionarray/RectRegion.x10"
                final x10.regionarray.RectRegion this$157185 = ((x10.regionarray.RectRegion)(this));
                
                //#line 264 . "x10/regionarray/RectRegion.x10"
                final long t$157359 = this$157185.min0;
                
                //#line 264 . "x10/regionarray/RectRegion.x10"
                boolean t$157361 = ((i0) >= (((long)(t$157359))));
                
                //#line 264 . "x10/regionarray/RectRegion.x10"
                if (t$157361) {
                    
                    //#line 264 . "x10/regionarray/RectRegion.x10"
                    final long t$157360 = this$157185.max0;
                    
                    //#line 264 . "x10/regionarray/RectRegion.x10"
                    t$157361 = ((i0) <= (((long)(t$157360))));
                }
                
                //#line 141 "x10/regionarray/RectRegion.x10"
                t$157363 = !(t$157361);
            }
            
            //#line 141 "x10/regionarray/RectRegion.x10"
            if (t$157363) {
                
                //#line 141 "x10/regionarray/RectRegion.x10"
                return -1L;
            }
            
            //#line 142 "x10/regionarray/RectRegion.x10"
            return i0;
        } else {
            
            //#line 144 "x10/regionarray/RectRegion.x10"
            final long t$157365 = this.rank;
            
            //#line 144 "x10/regionarray/RectRegion.x10"
            boolean t$157370 = ((long) t$157365) != ((long) 1L);
            
            //#line 144 "x10/regionarray/RectRegion.x10"
            if (!(t$157370)) {
                
                //#line 144 "x10/regionarray/RectRegion.x10"
                final x10.regionarray.RectRegion this$157188 = ((x10.regionarray.RectRegion)(this));
                
                //#line 264 . "x10/regionarray/RectRegion.x10"
                final long t$157366 = this$157188.min0;
                
                //#line 264 . "x10/regionarray/RectRegion.x10"
                boolean t$157368 = ((i0) >= (((long)(t$157366))));
                
                //#line 264 . "x10/regionarray/RectRegion.x10"
                if (t$157368) {
                    
                    //#line 264 . "x10/regionarray/RectRegion.x10"
                    final long t$157367 = this$157188.max0;
                    
                    //#line 264 . "x10/regionarray/RectRegion.x10"
                    t$157368 = ((i0) <= (((long)(t$157367))));
                }
                
                //#line 144 "x10/regionarray/RectRegion.x10"
                t$157370 = !(t$157368);
            }
            
            //#line 144 "x10/regionarray/RectRegion.x10"
            if (t$157370) {
                
                //#line 144 "x10/regionarray/RectRegion.x10"
                return -1L;
            }
            
            //#line 145 "x10/regionarray/RectRegion.x10"
            final long t$157372 = this.min0;
            
            //#line 145 "x10/regionarray/RectRegion.x10"
            final long t$157373 = ((i0) - (((long)(t$157372))));
            
            //#line 145 "x10/regionarray/RectRegion.x10"
            return t$157373;
        }
    }
    
    
    //#line 149 "x10/regionarray/RectRegion.x10"
    public long indexOf$O(final long i0, final long i1) {
        
        //#line 150 "x10/regionarray/RectRegion.x10"
        final boolean t$157400 = this.zeroBased;
        
        //#line 150 "x10/regionarray/RectRegion.x10"
        if (t$157400) {
            
            //#line 151 "x10/regionarray/RectRegion.x10"
            final long t$157375 = this.rank;
            
            //#line 151 "x10/regionarray/RectRegion.x10"
            boolean t$157377 = ((long) t$157375) != ((long) 2L);
            
            //#line 151 "x10/regionarray/RectRegion.x10"
            if (!(t$157377)) {
                
                //#line 151 "x10/regionarray/RectRegion.x10"
                final boolean t$157376 = this.containsInternal$O((long)(i0), (long)(i1));
                
                //#line 151 "x10/regionarray/RectRegion.x10"
                t$157377 = !(t$157376);
            }
            
            //#line 151 "x10/regionarray/RectRegion.x10"
            if (t$157377) {
                
                //#line 151 "x10/regionarray/RectRegion.x10"
                return -1L;
            }
            
            //#line 152 "x10/regionarray/RectRegion.x10"
            long offset = i0;
            
            //#line 153 "x10/regionarray/RectRegion.x10"
            final long t$157379 = this.max1;
            
            //#line 153 "x10/regionarray/RectRegion.x10"
            final long t$157381 = ((t$157379) + (((long)(1L))));
            
            //#line 153 "x10/regionarray/RectRegion.x10"
            final long t$157382 = ((i0) * (((long)(t$157381))));
            
            //#line 153 "x10/regionarray/RectRegion.x10"
            final long t$157383 = ((t$157382) + (((long)(i1))));
            
            //#line 153 "x10/regionarray/RectRegion.x10"
            offset = t$157383;
            
            //#line 154 "x10/regionarray/RectRegion.x10"
            return offset;
        } else {
            
            //#line 156 "x10/regionarray/RectRegion.x10"
            final long t$157385 = this.rank;
            
            //#line 156 "x10/regionarray/RectRegion.x10"
            boolean t$157387 = ((long) t$157385) != ((long) 2L);
            
            //#line 156 "x10/regionarray/RectRegion.x10"
            if (!(t$157387)) {
                
                //#line 156 "x10/regionarray/RectRegion.x10"
                final boolean t$157386 = this.containsInternal$O((long)(i0), (long)(i1));
                
                //#line 156 "x10/regionarray/RectRegion.x10"
                t$157387 = !(t$157386);
            }
            
            //#line 156 "x10/regionarray/RectRegion.x10"
            if (t$157387) {
                
                //#line 156 "x10/regionarray/RectRegion.x10"
                return -1L;
            }
            
            //#line 157 "x10/regionarray/RectRegion.x10"
            final long t$157389 = this.min0;
            
            //#line 157 "x10/regionarray/RectRegion.x10"
            long offset = ((i0) - (((long)(t$157389))));
            
            //#line 158 "x10/regionarray/RectRegion.x10"
            final long t$157390 = this.max1;
            
            //#line 158 "x10/regionarray/RectRegion.x10"
            final long t$157391 = this.min1;
            
            //#line 158 "x10/regionarray/RectRegion.x10"
            final long t$157392 = ((t$157390) - (((long)(t$157391))));
            
            //#line 158 "x10/regionarray/RectRegion.x10"
            final long t$157394 = ((t$157392) + (((long)(1L))));
            
            //#line 158 "x10/regionarray/RectRegion.x10"
            final long t$157395 = ((offset) * (((long)(t$157394))));
            
            //#line 158 "x10/regionarray/RectRegion.x10"
            final long t$157396 = ((t$157395) + (((long)(i1))));
            
            //#line 158 "x10/regionarray/RectRegion.x10"
            final long t$157397 = this.min1;
            
            //#line 158 "x10/regionarray/RectRegion.x10"
            final long t$157398 = ((t$157396) - (((long)(t$157397))));
            
            //#line 158 "x10/regionarray/RectRegion.x10"
            offset = t$157398;
            
            //#line 159 "x10/regionarray/RectRegion.x10"
            return offset;
        }
    }
    
    
    //#line 163 "x10/regionarray/RectRegion.x10"
    public long indexOf$O(final long i0, final long i1, final long i2) {
        
        //#line 164 "x10/regionarray/RectRegion.x10"
        final boolean t$157440 = this.zeroBased;
        
        //#line 164 "x10/regionarray/RectRegion.x10"
        if (t$157440) {
            
            //#line 165 "x10/regionarray/RectRegion.x10"
            final long t$157401 = this.rank;
            
            //#line 165 "x10/regionarray/RectRegion.x10"
            boolean t$157403 = ((long) t$157401) != ((long) 3L);
            
            //#line 165 "x10/regionarray/RectRegion.x10"
            if (!(t$157403)) {
                
                //#line 165 "x10/regionarray/RectRegion.x10"
                final boolean t$157402 = this.containsInternal$O((long)(i0), (long)(i1), (long)(i2));
                
                //#line 165 "x10/regionarray/RectRegion.x10"
                t$157403 = !(t$157402);
            }
            
            //#line 165 "x10/regionarray/RectRegion.x10"
            if (t$157403) {
                
                //#line 165 "x10/regionarray/RectRegion.x10"
                return -1L;
            }
            
            //#line 166 "x10/regionarray/RectRegion.x10"
            long offset = i0;
            
            //#line 167 "x10/regionarray/RectRegion.x10"
            final long t$157405 = this.max1;
            
            //#line 167 "x10/regionarray/RectRegion.x10"
            final long t$157407 = ((t$157405) + (((long)(1L))));
            
            //#line 167 "x10/regionarray/RectRegion.x10"
            final long t$157408 = ((i0) * (((long)(t$157407))));
            
            //#line 167 "x10/regionarray/RectRegion.x10"
            final long t$157409 = ((t$157408) + (((long)(i1))));
            
            //#line 167 "x10/regionarray/RectRegion.x10"
            offset = t$157409;
            
            //#line 168 "x10/regionarray/RectRegion.x10"
            final long t$157410 = this.max2;
            
            //#line 168 "x10/regionarray/RectRegion.x10"
            final long t$157412 = ((t$157410) + (((long)(1L))));
            
            //#line 168 "x10/regionarray/RectRegion.x10"
            final long t$157413 = ((offset) * (((long)(t$157412))));
            
            //#line 168 "x10/regionarray/RectRegion.x10"
            final long t$157414 = ((t$157413) + (((long)(i2))));
            
            //#line 168 "x10/regionarray/RectRegion.x10"
            offset = t$157414;
            
            //#line 169 "x10/regionarray/RectRegion.x10"
            return offset;
        } else {
            
            //#line 171 "x10/regionarray/RectRegion.x10"
            final long t$157416 = this.rank;
            
            //#line 171 "x10/regionarray/RectRegion.x10"
            boolean t$157418 = ((long) t$157416) != ((long) 3L);
            
            //#line 171 "x10/regionarray/RectRegion.x10"
            if (!(t$157418)) {
                
                //#line 171 "x10/regionarray/RectRegion.x10"
                final boolean t$157417 = this.containsInternal$O((long)(i0), (long)(i1), (long)(i2));
                
                //#line 171 "x10/regionarray/RectRegion.x10"
                t$157418 = !(t$157417);
            }
            
            //#line 171 "x10/regionarray/RectRegion.x10"
            if (t$157418) {
                
                //#line 171 "x10/regionarray/RectRegion.x10"
                return -1L;
            }
            
            //#line 172 "x10/regionarray/RectRegion.x10"
            final long t$157420 = this.min0;
            
            //#line 172 "x10/regionarray/RectRegion.x10"
            long offset = ((i0) - (((long)(t$157420))));
            
            //#line 173 "x10/regionarray/RectRegion.x10"
            final long t$157421 = this.max1;
            
            //#line 173 "x10/regionarray/RectRegion.x10"
            final long t$157422 = this.min1;
            
            //#line 173 "x10/regionarray/RectRegion.x10"
            final long t$157423 = ((t$157421) - (((long)(t$157422))));
            
            //#line 173 "x10/regionarray/RectRegion.x10"
            final long t$157425 = ((t$157423) + (((long)(1L))));
            
            //#line 173 "x10/regionarray/RectRegion.x10"
            final long t$157426 = ((offset) * (((long)(t$157425))));
            
            //#line 173 "x10/regionarray/RectRegion.x10"
            final long t$157427 = ((t$157426) + (((long)(i1))));
            
            //#line 173 "x10/regionarray/RectRegion.x10"
            final long t$157428 = this.min1;
            
            //#line 173 "x10/regionarray/RectRegion.x10"
            final long t$157429 = ((t$157427) - (((long)(t$157428))));
            
            //#line 173 "x10/regionarray/RectRegion.x10"
            offset = t$157429;
            
            //#line 174 "x10/regionarray/RectRegion.x10"
            final long t$157430 = this.max2;
            
            //#line 174 "x10/regionarray/RectRegion.x10"
            final long t$157431 = this.min2;
            
            //#line 174 "x10/regionarray/RectRegion.x10"
            final long t$157432 = ((t$157430) - (((long)(t$157431))));
            
            //#line 174 "x10/regionarray/RectRegion.x10"
            final long t$157434 = ((t$157432) + (((long)(1L))));
            
            //#line 174 "x10/regionarray/RectRegion.x10"
            final long t$157435 = ((offset) * (((long)(t$157434))));
            
            //#line 174 "x10/regionarray/RectRegion.x10"
            final long t$157436 = ((t$157435) + (((long)(i2))));
            
            //#line 174 "x10/regionarray/RectRegion.x10"
            final long t$157437 = this.min2;
            
            //#line 174 "x10/regionarray/RectRegion.x10"
            final long t$157438 = ((t$157436) - (((long)(t$157437))));
            
            //#line 174 "x10/regionarray/RectRegion.x10"
            offset = t$157438;
            
            //#line 175 "x10/regionarray/RectRegion.x10"
            return offset;
        }
    }
    
    
    //#line 179 "x10/regionarray/RectRegion.x10"
    public long indexOf$O(final long i0, final long i1, final long i2, final long i3) {
        
        //#line 180 "x10/regionarray/RectRegion.x10"
        final boolean t$157494 = this.zeroBased;
        
        //#line 180 "x10/regionarray/RectRegion.x10"
        if (t$157494) {
            
            //#line 181 "x10/regionarray/RectRegion.x10"
            final long t$157441 = this.rank;
            
            //#line 181 "x10/regionarray/RectRegion.x10"
            boolean t$157443 = ((long) t$157441) != ((long) 4L);
            
            //#line 181 "x10/regionarray/RectRegion.x10"
            if (!(t$157443)) {
                
                //#line 181 "x10/regionarray/RectRegion.x10"
                final boolean t$157442 = this.containsInternal$O((long)(i0), (long)(i1), (long)(i2), (long)(i3));
                
                //#line 181 "x10/regionarray/RectRegion.x10"
                t$157443 = !(t$157442);
            }
            
            //#line 181 "x10/regionarray/RectRegion.x10"
            if (t$157443) {
                
                //#line 181 "x10/regionarray/RectRegion.x10"
                return -1L;
            }
            
            //#line 182 "x10/regionarray/RectRegion.x10"
            long offset = i0;
            
            //#line 183 "x10/regionarray/RectRegion.x10"
            final long t$157445 = this.max1;
            
            //#line 183 "x10/regionarray/RectRegion.x10"
            final long t$157447 = ((t$157445) + (((long)(1L))));
            
            //#line 183 "x10/regionarray/RectRegion.x10"
            final long t$157448 = ((i0) * (((long)(t$157447))));
            
            //#line 183 "x10/regionarray/RectRegion.x10"
            final long t$157449 = ((t$157448) + (((long)(i1))));
            
            //#line 183 "x10/regionarray/RectRegion.x10"
            offset = t$157449;
            
            //#line 184 "x10/regionarray/RectRegion.x10"
            final long t$157450 = this.max2;
            
            //#line 184 "x10/regionarray/RectRegion.x10"
            final long t$157452 = ((t$157450) + (((long)(1L))));
            
            //#line 184 "x10/regionarray/RectRegion.x10"
            final long t$157453 = ((offset) * (((long)(t$157452))));
            
            //#line 184 "x10/regionarray/RectRegion.x10"
            final long t$157454 = ((t$157453) + (((long)(i2))));
            
            //#line 184 "x10/regionarray/RectRegion.x10"
            offset = t$157454;
            
            //#line 185 "x10/regionarray/RectRegion.x10"
            final long t$157455 = this.max3;
            
            //#line 185 "x10/regionarray/RectRegion.x10"
            final long t$157457 = ((t$157455) + (((long)(1L))));
            
            //#line 185 "x10/regionarray/RectRegion.x10"
            final long t$157458 = ((offset) * (((long)(t$157457))));
            
            //#line 185 "x10/regionarray/RectRegion.x10"
            final long t$157459 = ((t$157458) + (((long)(i3))));
            
            //#line 185 "x10/regionarray/RectRegion.x10"
            offset = t$157459;
            
            //#line 186 "x10/regionarray/RectRegion.x10"
            return offset;
        } else {
            
            //#line 188 "x10/regionarray/RectRegion.x10"
            final long t$157461 = this.rank;
            
            //#line 188 "x10/regionarray/RectRegion.x10"
            boolean t$157463 = ((long) t$157461) != ((long) 4L);
            
            //#line 188 "x10/regionarray/RectRegion.x10"
            if (!(t$157463)) {
                
                //#line 188 "x10/regionarray/RectRegion.x10"
                final boolean t$157462 = this.containsInternal$O((long)(i0), (long)(i1), (long)(i2), (long)(i3));
                
                //#line 188 "x10/regionarray/RectRegion.x10"
                t$157463 = !(t$157462);
            }
            
            //#line 188 "x10/regionarray/RectRegion.x10"
            if (t$157463) {
                
                //#line 188 "x10/regionarray/RectRegion.x10"
                return -1L;
            }
            
            //#line 189 "x10/regionarray/RectRegion.x10"
            final long t$157465 = this.min0;
            
            //#line 189 "x10/regionarray/RectRegion.x10"
            long offset = ((i0) - (((long)(t$157465))));
            
            //#line 190 "x10/regionarray/RectRegion.x10"
            final long t$157466 = this.max1;
            
            //#line 190 "x10/regionarray/RectRegion.x10"
            final long t$157467 = this.min1;
            
            //#line 190 "x10/regionarray/RectRegion.x10"
            final long t$157468 = ((t$157466) - (((long)(t$157467))));
            
            //#line 190 "x10/regionarray/RectRegion.x10"
            final long t$157470 = ((t$157468) + (((long)(1L))));
            
            //#line 190 "x10/regionarray/RectRegion.x10"
            final long t$157471 = ((offset) * (((long)(t$157470))));
            
            //#line 190 "x10/regionarray/RectRegion.x10"
            final long t$157472 = ((t$157471) + (((long)(i1))));
            
            //#line 190 "x10/regionarray/RectRegion.x10"
            final long t$157473 = this.min1;
            
            //#line 190 "x10/regionarray/RectRegion.x10"
            final long t$157474 = ((t$157472) - (((long)(t$157473))));
            
            //#line 190 "x10/regionarray/RectRegion.x10"
            offset = t$157474;
            
            //#line 191 "x10/regionarray/RectRegion.x10"
            final long t$157475 = this.max2;
            
            //#line 191 "x10/regionarray/RectRegion.x10"
            final long t$157476 = this.min2;
            
            //#line 191 "x10/regionarray/RectRegion.x10"
            final long t$157477 = ((t$157475) - (((long)(t$157476))));
            
            //#line 191 "x10/regionarray/RectRegion.x10"
            final long t$157479 = ((t$157477) + (((long)(1L))));
            
            //#line 191 "x10/regionarray/RectRegion.x10"
            final long t$157480 = ((offset) * (((long)(t$157479))));
            
            //#line 191 "x10/regionarray/RectRegion.x10"
            final long t$157481 = ((t$157480) + (((long)(i2))));
            
            //#line 191 "x10/regionarray/RectRegion.x10"
            final long t$157482 = this.min2;
            
            //#line 191 "x10/regionarray/RectRegion.x10"
            final long t$157483 = ((t$157481) - (((long)(t$157482))));
            
            //#line 191 "x10/regionarray/RectRegion.x10"
            offset = t$157483;
            
            //#line 192 "x10/regionarray/RectRegion.x10"
            final long t$157484 = this.max3;
            
            //#line 192 "x10/regionarray/RectRegion.x10"
            final long t$157485 = this.min3;
            
            //#line 192 "x10/regionarray/RectRegion.x10"
            final long t$157486 = ((t$157484) - (((long)(t$157485))));
            
            //#line 192 "x10/regionarray/RectRegion.x10"
            final long t$157488 = ((t$157486) + (((long)(1L))));
            
            //#line 192 "x10/regionarray/RectRegion.x10"
            final long t$157489 = ((offset) * (((long)(t$157488))));
            
            //#line 192 "x10/regionarray/RectRegion.x10"
            final long t$157490 = ((t$157489) + (((long)(i3))));
            
            //#line 192 "x10/regionarray/RectRegion.x10"
            final long t$157491 = this.min3;
            
            //#line 192 "x10/regionarray/RectRegion.x10"
            final long t$157492 = ((t$157490) - (((long)(t$157491))));
            
            //#line 192 "x10/regionarray/RectRegion.x10"
            offset = t$157492;
            
            //#line 193 "x10/regionarray/RectRegion.x10"
            return offset;
        }
    }
    
    
    //#line 198 "x10/regionarray/RectRegion.x10"
    public long min$O(final long i) {
        
        //#line 199 "x10/regionarray/RectRegion.x10"
        final boolean t$157496 = ((long) i) == ((long) 0L);
        
        //#line 199 "x10/regionarray/RectRegion.x10"
        if (t$157496) {
            
            //#line 199 "x10/regionarray/RectRegion.x10"
            final long t$157495 = this.min0;
            
            //#line 199 "x10/regionarray/RectRegion.x10"
            return t$157495;
        }
        
        //#line 200 "x10/regionarray/RectRegion.x10"
        final boolean t$157498 = ((long) i) == ((long) 1L);
        
        //#line 200 "x10/regionarray/RectRegion.x10"
        if (t$157498) {
            
            //#line 200 "x10/regionarray/RectRegion.x10"
            final long t$157497 = this.min1;
            
            //#line 200 "x10/regionarray/RectRegion.x10"
            return t$157497;
        }
        
        //#line 201 "x10/regionarray/RectRegion.x10"
        final boolean t$157500 = ((long) i) == ((long) 2L);
        
        //#line 201 "x10/regionarray/RectRegion.x10"
        if (t$157500) {
            
            //#line 201 "x10/regionarray/RectRegion.x10"
            final long t$157499 = this.min2;
            
            //#line 201 "x10/regionarray/RectRegion.x10"
            return t$157499;
        }
        
        //#line 202 "x10/regionarray/RectRegion.x10"
        final boolean t$157502 = ((long) i) == ((long) 3L);
        
        //#line 202 "x10/regionarray/RectRegion.x10"
        if (t$157502) {
            
            //#line 202 "x10/regionarray/RectRegion.x10"
            final long t$157501 = this.min3;
            
            //#line 202 "x10/regionarray/RectRegion.x10"
            return t$157501;
        }
        
        //#line 203 "x10/regionarray/RectRegion.x10"
        boolean t$157504 = ((i) < (((long)(0L))));
        
        //#line 203 "x10/regionarray/RectRegion.x10"
        if (!(t$157504)) {
            
            //#line 203 "x10/regionarray/RectRegion.x10"
            final long t$157503 = this.rank;
            
            //#line 203 "x10/regionarray/RectRegion.x10"
            t$157504 = ((i) >= (((long)(t$157503))));
        }
        
        //#line 203 "x10/regionarray/RectRegion.x10"
        if (t$157504) {
            
            //#line 203 "x10/regionarray/RectRegion.x10"
            final java.lang.String t$157505 = (("min: ") + ((x10.core.Long.$box(i))));
            
            //#line 203 "x10/regionarray/RectRegion.x10"
            final java.lang.String t$157506 = ((t$157505) + (" is not a valid rank for "));
            
            //#line 203 "x10/regionarray/RectRegion.x10"
            final java.lang.String t$157507 = ((t$157506) + (this));
            
            //#line 203 "x10/regionarray/RectRegion.x10"
            final java.lang.ArrayIndexOutOfBoundsException t$157508 = ((java.lang.ArrayIndexOutOfBoundsException)(new java.lang.ArrayIndexOutOfBoundsException(t$157507)));
            
            //#line 203 "x10/regionarray/RectRegion.x10"
            throw t$157508;
        }
        
        //#line 204 "x10/regionarray/RectRegion.x10"
        final x10.core.Rail t$157510 = ((x10.core.Rail)(this.mins));
        
        //#line 204 "x10/regionarray/RectRegion.x10"
        final long t$157511 = ((long[])t$157510.value)[(int)i];
        
        //#line 204 "x10/regionarray/RectRegion.x10"
        return t$157511;
    }
    
    
    //#line 207 "x10/regionarray/RectRegion.x10"
    public long max$O(final long i) {
        
        //#line 208 "x10/regionarray/RectRegion.x10"
        final boolean t$157513 = ((long) i) == ((long) 0L);
        
        //#line 208 "x10/regionarray/RectRegion.x10"
        if (t$157513) {
            
            //#line 208 "x10/regionarray/RectRegion.x10"
            final long t$157512 = this.max0;
            
            //#line 208 "x10/regionarray/RectRegion.x10"
            return t$157512;
        }
        
        //#line 209 "x10/regionarray/RectRegion.x10"
        final boolean t$157515 = ((long) i) == ((long) 1L);
        
        //#line 209 "x10/regionarray/RectRegion.x10"
        if (t$157515) {
            
            //#line 209 "x10/regionarray/RectRegion.x10"
            final long t$157514 = this.max1;
            
            //#line 209 "x10/regionarray/RectRegion.x10"
            return t$157514;
        }
        
        //#line 210 "x10/regionarray/RectRegion.x10"
        final boolean t$157517 = ((long) i) == ((long) 2L);
        
        //#line 210 "x10/regionarray/RectRegion.x10"
        if (t$157517) {
            
            //#line 210 "x10/regionarray/RectRegion.x10"
            final long t$157516 = this.max2;
            
            //#line 210 "x10/regionarray/RectRegion.x10"
            return t$157516;
        }
        
        //#line 211 "x10/regionarray/RectRegion.x10"
        final boolean t$157519 = ((long) i) == ((long) 3L);
        
        //#line 211 "x10/regionarray/RectRegion.x10"
        if (t$157519) {
            
            //#line 211 "x10/regionarray/RectRegion.x10"
            final long t$157518 = this.max3;
            
            //#line 211 "x10/regionarray/RectRegion.x10"
            return t$157518;
        }
        
        //#line 212 "x10/regionarray/RectRegion.x10"
        boolean t$157521 = ((i) < (((long)(0L))));
        
        //#line 212 "x10/regionarray/RectRegion.x10"
        if (!(t$157521)) {
            
            //#line 212 "x10/regionarray/RectRegion.x10"
            final long t$157520 = this.rank;
            
            //#line 212 "x10/regionarray/RectRegion.x10"
            t$157521 = ((i) >= (((long)(t$157520))));
        }
        
        //#line 212 "x10/regionarray/RectRegion.x10"
        if (t$157521) {
            
            //#line 212 "x10/regionarray/RectRegion.x10"
            final java.lang.String t$157522 = (("max: ") + ((x10.core.Long.$box(i))));
            
            //#line 212 "x10/regionarray/RectRegion.x10"
            final java.lang.String t$157523 = ((t$157522) + (" is not a valid rank for "));
            
            //#line 212 "x10/regionarray/RectRegion.x10"
            final java.lang.String t$157524 = ((t$157523) + (this));
            
            //#line 212 "x10/regionarray/RectRegion.x10"
            final java.lang.ArrayIndexOutOfBoundsException t$157525 = ((java.lang.ArrayIndexOutOfBoundsException)(new java.lang.ArrayIndexOutOfBoundsException(t$157524)));
            
            //#line 212 "x10/regionarray/RectRegion.x10"
            throw t$157525;
        }
        
        //#line 213 "x10/regionarray/RectRegion.x10"
        final x10.core.Rail t$157527 = ((x10.core.Rail)(this.maxs));
        
        //#line 213 "x10/regionarray/RectRegion.x10"
        final long t$157528 = ((long[])t$157527.value)[(int)i];
        
        //#line 213 "x10/regionarray/RectRegion.x10"
        return t$157528;
    }
    
    
    //#line 221 "x10/regionarray/RectRegion.x10"
    public x10.regionarray.Region computeBoundingBox() {
        
        //#line 221 "x10/regionarray/RectRegion.x10"
        return this;
    }
    
    
    //#line 223 "x10/regionarray/RectRegion.x10"
    public x10.core.fun.Fun_0_1 min() {
        
        //#line 223 "x10/regionarray/RectRegion.x10"
        final x10.core.fun.Fun_0_1 t$157530 = ((x10.core.fun.Fun_0_1)(new x10.regionarray.RectRegion.$Closure$264(this)));
        
        //#line 223 "x10/regionarray/RectRegion.x10"
        return t$157530;
    }
    
    
    //#line 224 "x10/regionarray/RectRegion.x10"
    public x10.core.fun.Fun_0_1 max() {
        
        //#line 224 "x10/regionarray/RectRegion.x10"
        final x10.core.fun.Fun_0_1 t$157532 = ((x10.core.fun.Fun_0_1)(new x10.regionarray.RectRegion.$Closure$265(this)));
        
        //#line 224 "x10/regionarray/RectRegion.x10"
        return t$157532;
    }
    
    
    //#line 226 "x10/regionarray/RectRegion.x10"
    public boolean contains$O(final x10.regionarray.Region that) {
        
        //#line 227 "x10/regionarray/RectRegion.x10"
        final boolean t$157558 = x10.regionarray.RectRegion.$RTT.isInstance(that);
        
        //#line 227 "x10/regionarray/RectRegion.x10"
        if (t$157558) {
            
            //#line 228 "x10/regionarray/RectRegion.x10"
            final x10.regionarray.RectRegion this$157191 = ((x10.regionarray.RectRegion)(x10.rtt.Types.<x10.regionarray.RectRegion> cast(that,x10.regionarray.RectRegion.$RTT)));
            
            //#line 223 . "x10/regionarray/RectRegion.x10"
            x10.core.fun.Fun_0_1 ret$157192 =  null;
            
            //#line 223 . "x10/regionarray/RectRegion.x10"
            final x10.core.fun.Fun_0_1 t$158042 = ((x10.core.fun.Fun_0_1)(new x10.regionarray.RectRegion.$Closure$266(this$157191)));
            
            //#line 223 . "x10/regionarray/RectRegion.x10"
            ret$157192 = ((x10.core.fun.Fun_0_1)(t$158042));
            
            //#line 228 "x10/regionarray/RectRegion.x10"
            final x10.core.fun.Fun_0_1 thatMin = ret$157192;
            
            //#line 229 "x10/regionarray/RectRegion.x10"
            final x10.regionarray.RectRegion this$157195 = ((x10.regionarray.RectRegion)(x10.rtt.Types.<x10.regionarray.RectRegion> cast(that,x10.regionarray.RectRegion.$RTT)));
            
            //#line 224 . "x10/regionarray/RectRegion.x10"
            x10.core.fun.Fun_0_1 ret$157196 =  null;
            
            //#line 224 . "x10/regionarray/RectRegion.x10"
            final x10.core.fun.Fun_0_1 t$158045 = ((x10.core.fun.Fun_0_1)(new x10.regionarray.RectRegion.$Closure$267(this$157195)));
            
            //#line 224 . "x10/regionarray/RectRegion.x10"
            ret$157196 = ((x10.core.fun.Fun_0_1)(t$158045));
            
            //#line 230 "x10/regionarray/RectRegion.x10"
            final long t$158048 = this.rank;
            
            //#line 230 "x10/regionarray/RectRegion.x10"
            final long i$146159max$158049 = ((t$158048) - (((long)(1L))));
            
            //#line 230 "x10/regionarray/RectRegion.x10"
            long i$158039 = 0L;
            
            //#line 230 "x10/regionarray/RectRegion.x10"
            for (;
                 true;
                 ) {
                
                //#line 230 "x10/regionarray/RectRegion.x10"
                final boolean t$158041 = ((i$158039) <= (((long)(i$146159max$158049))));
                
                //#line 230 "x10/regionarray/RectRegion.x10"
                if (!(t$158041)) {
                    
                    //#line 230 "x10/regionarray/RectRegion.x10"
                    break;
                }
                
                //#line 231 "x10/regionarray/RectRegion.x10"
                final long t$158030 = this.min$O((long)(i$158039));
                
                //#line 231 "x10/regionarray/RectRegion.x10"
                final long t$158031 = x10.core.Long.$unbox(((x10.core.fun.Fun_0_1<x10.core.Long,x10.core.Long>)thatMin).$apply(x10.core.Long.$box(i$158039), x10.rtt.Types.LONG));
                
                //#line 231 "x10/regionarray/RectRegion.x10"
                final boolean t$158032 = ((t$158030) > (((long)(t$158031))));
                
                //#line 231 "x10/regionarray/RectRegion.x10"
                if (t$158032) {
                    
                    //#line 231 "x10/regionarray/RectRegion.x10"
                    return false;
                }
                
                //#line 232 "x10/regionarray/RectRegion.x10"
                final long t$158033 = this.max$O((long)(i$158039));
                
                //#line 232 "x10/regionarray/RectRegion.x10"
                final long t$158034 = x10.core.Long.$unbox(((x10.core.fun.Fun_0_1<x10.core.Long,x10.core.Long>)ret$157196).$apply(x10.core.Long.$box(i$158039), x10.rtt.Types.LONG));
                
                //#line 232 "x10/regionarray/RectRegion.x10"
                final boolean t$158035 = ((t$158033) < (((long)(t$158034))));
                
                //#line 232 "x10/regionarray/RectRegion.x10"
                if (t$158035) {
                    
                    //#line 232 "x10/regionarray/RectRegion.x10"
                    return false;
                }
                
                //#line 230 "x10/regionarray/RectRegion.x10"
                final long t$158038 = ((i$158039) + (((long)(1L))));
                
                //#line 230 "x10/regionarray/RectRegion.x10"
                i$158039 = t$158038;
            }
            
            //#line 234 "x10/regionarray/RectRegion.x10"
            return true;
        } else {
            
            //#line 235 "x10/regionarray/RectRegion.x10"
            final boolean t$157557 = x10.regionarray.RectRegion1D.$RTT.isInstance(that);
            
            //#line 235 "x10/regionarray/RectRegion.x10"
            if (t$157557) {
                
                //#line 236 "x10/regionarray/RectRegion.x10"
                final long t$157549 = this.min$O((long)(0L));
                
                //#line 236 "x10/regionarray/RectRegion.x10"
                final long t$157550 = that.min$O((long)(0L));
                
                //#line 236 "x10/regionarray/RectRegion.x10"
                boolean t$157553 = ((t$157549) <= (((long)(t$157550))));
                
                //#line 236 "x10/regionarray/RectRegion.x10"
                if (t$157553) {
                    
                    //#line 236 "x10/regionarray/RectRegion.x10"
                    final long t$157551 = this.max$O((long)(0L));
                    
                    //#line 236 "x10/regionarray/RectRegion.x10"
                    final long t$157552 = that.max$O((long)(0L));
                    
                    //#line 236 "x10/regionarray/RectRegion.x10"
                    t$157553 = ((t$157551) >= (((long)(t$157552))));
                }
                
                //#line 236 "x10/regionarray/RectRegion.x10"
                return t$157553;
            } else {
                
                //#line 238 "x10/regionarray/RectRegion.x10"
                final x10.regionarray.Region t$157555 = ((x10.regionarray.Region)(that.computeBoundingBox()));
                
                //#line 238 "x10/regionarray/RectRegion.x10"
                final boolean t$157556 = this.contains$O(((x10.regionarray.Region)(t$157555)));
                
                //#line 238 "x10/regionarray/RectRegion.x10"
                return t$157556;
            }
        }
    }
    
    
    //#line 242 "x10/regionarray/RectRegion.x10"
    public boolean contains$O(final x10.lang.Point p) {
        
        //#line 243 "x10/regionarray/RectRegion.x10"
        final long t$157559 = p.rank;
        
        //#line 243 "x10/regionarray/RectRegion.x10"
        final long t$157560 = this.rank;
        
        //#line 243 "x10/regionarray/RectRegion.x10"
        final boolean t$157561 = ((long) t$157559) != ((long) t$157560);
        
        //#line 243 "x10/regionarray/RectRegion.x10"
        if (t$157561) {
            
            //#line 243 "x10/regionarray/RectRegion.x10"
            return false;
        }
        
        //#line 245 "x10/regionarray/RectRegion.x10"
        final long t$157562 = p.rank;
        
        //#line 245 "x10/regionarray/RectRegion.x10"
        final long t$157563 = ((t$157562) - (((long)(1L))));
        
        //#line 245 "x10/regionarray/RectRegion.x10"
        final int t$157594 = ((int)(long)(((long)(t$157563))));
        
        //#line 245 "x10/regionarray/RectRegion.x10"
        switch (t$157594) {
            
            //#line 246 "x10/regionarray/RectRegion.x10"
            default:
                {
                    
                    //#line 247 "x10/regionarray/RectRegion.x10"
                    final long t$157564 = p.rank;
                    
                    //#line 247 "x10/regionarray/RectRegion.x10"
                    final long i$146177min$146178 = ((t$157564) - (((long)(1L))));
                    
                    //#line 247 "x10/regionarray/RectRegion.x10"
                    long i$158061 = i$146177min$146178;
                    
                    //#line 247 "x10/regionarray/RectRegion.x10"
                    for (;
                         true;
                         ) {
                        
                        //#line 247 "x10/regionarray/RectRegion.x10"
                        final boolean t$158063 = ((i$158061) <= (((long)(4L))));
                        
                        //#line 247 "x10/regionarray/RectRegion.x10"
                        if (!(t$158063)) {
                            
                            //#line 247 "x10/regionarray/RectRegion.x10"
                            break;
                        }
                        
                        //#line 248 "x10/regionarray/RectRegion.x10"
                        final long t$158050 = p.$apply$O((long)(i$158061));
                        
                        //#line 248 "x10/regionarray/RectRegion.x10"
                        final x10.core.Rail t$158051 = ((x10.core.Rail)(this.mins));
                        
                        //#line 248 "x10/regionarray/RectRegion.x10"
                        final long t$158052 = ((long[])t$158051.value)[(int)i$158061];
                        
                        //#line 248 "x10/regionarray/RectRegion.x10"
                        boolean t$158053 = ((t$158050) < (((long)(t$158052))));
                        
                        //#line 248 "x10/regionarray/RectRegion.x10"
                        if (!(t$158053)) {
                            
                            //#line 248 "x10/regionarray/RectRegion.x10"
                            final long t$158054 = p.$apply$O((long)(i$158061));
                            
                            //#line 248 "x10/regionarray/RectRegion.x10"
                            final x10.core.Rail t$158055 = ((x10.core.Rail)(this.maxs));
                            
                            //#line 248 "x10/regionarray/RectRegion.x10"
                            final long t$158056 = ((long[])t$158055.value)[(int)i$158061];
                            
                            //#line 248 "x10/regionarray/RectRegion.x10"
                            t$158053 = ((t$158054) > (((long)(t$158056))));
                        }
                        
                        //#line 248 "x10/regionarray/RectRegion.x10"
                        if (t$158053) {
                            
                            //#line 248 "x10/regionarray/RectRegion.x10"
                            return false;
                        }
                        
                        //#line 247 "x10/regionarray/RectRegion.x10"
                        final long t$158060 = ((i$158061) + (((long)(1L))));
                        
                        //#line 247 "x10/regionarray/RectRegion.x10"
                        i$158061 = t$158060;
                    }
                }
            
            //#line 250 "x10/regionarray/RectRegion.x10"
            case 3:
                {
                    
                    //#line 250 "x10/regionarray/RectRegion.x10"
                    final long tmp = p.$apply$O((long)(3L));
                    
                    //#line 250 "x10/regionarray/RectRegion.x10"
                    final long t$157578 = this.min3;
                    
                    //#line 250 "x10/regionarray/RectRegion.x10"
                    boolean t$157580 = ((tmp) < (((long)(t$157578))));
                    
                    //#line 250 "x10/regionarray/RectRegion.x10"
                    if (!(t$157580)) {
                        
                        //#line 250 "x10/regionarray/RectRegion.x10"
                        final long t$157579 = this.max3;
                        
                        //#line 250 "x10/regionarray/RectRegion.x10"
                        t$157580 = ((tmp) > (((long)(t$157579))));
                    }
                    
                    //#line 250 "x10/regionarray/RectRegion.x10"
                    if (t$157580) {
                        
                        //#line 250 "x10/regionarray/RectRegion.x10"
                        return false;
                    }
                }
            
            //#line 251 "x10/regionarray/RectRegion.x10"
            case 2:
                {
                    
                    //#line 251 "x10/regionarray/RectRegion.x10"
                    final long tmp = p.$apply$O((long)(2L));
                    
                    //#line 251 "x10/regionarray/RectRegion.x10"
                    final long t$157582 = this.min2;
                    
                    //#line 251 "x10/regionarray/RectRegion.x10"
                    boolean t$157584 = ((tmp) < (((long)(t$157582))));
                    
                    //#line 251 "x10/regionarray/RectRegion.x10"
                    if (!(t$157584)) {
                        
                        //#line 251 "x10/regionarray/RectRegion.x10"
                        final long t$157583 = this.max2;
                        
                        //#line 251 "x10/regionarray/RectRegion.x10"
                        t$157584 = ((tmp) > (((long)(t$157583))));
                    }
                    
                    //#line 251 "x10/regionarray/RectRegion.x10"
                    if (t$157584) {
                        
                        //#line 251 "x10/regionarray/RectRegion.x10"
                        return false;
                    }
                }
            
            //#line 252 "x10/regionarray/RectRegion.x10"
            case 1:
                {
                    
                    //#line 252 "x10/regionarray/RectRegion.x10"
                    final long tmp = p.$apply$O((long)(1L));
                    
                    //#line 252 "x10/regionarray/RectRegion.x10"
                    final long t$157586 = this.min1;
                    
                    //#line 252 "x10/regionarray/RectRegion.x10"
                    boolean t$157588 = ((tmp) < (((long)(t$157586))));
                    
                    //#line 252 "x10/regionarray/RectRegion.x10"
                    if (!(t$157588)) {
                        
                        //#line 252 "x10/regionarray/RectRegion.x10"
                        final long t$157587 = this.max1;
                        
                        //#line 252 "x10/regionarray/RectRegion.x10"
                        t$157588 = ((tmp) > (((long)(t$157587))));
                    }
                    
                    //#line 252 "x10/regionarray/RectRegion.x10"
                    if (t$157588) {
                        
                        //#line 252 "x10/regionarray/RectRegion.x10"
                        return false;
                    }
                }
            
            //#line 253 "x10/regionarray/RectRegion.x10"
            case 0:
                {
                    
                    //#line 253 "x10/regionarray/RectRegion.x10"
                    final long tmp = p.$apply$O((long)(0L));
                    
                    //#line 253 "x10/regionarray/RectRegion.x10"
                    final long t$157590 = this.min0;
                    
                    //#line 253 "x10/regionarray/RectRegion.x10"
                    boolean t$157592 = ((tmp) < (((long)(t$157590))));
                    
                    //#line 253 "x10/regionarray/RectRegion.x10"
                    if (!(t$157592)) {
                        
                        //#line 253 "x10/regionarray/RectRegion.x10"
                        final long t$157591 = this.max0;
                        
                        //#line 253 "x10/regionarray/RectRegion.x10"
                        t$157592 = ((tmp) > (((long)(t$157591))));
                    }
                    
                    //#line 253 "x10/regionarray/RectRegion.x10"
                    if (t$157592) {
                        
                        //#line 253 "x10/regionarray/RectRegion.x10"
                        return false;
                    }
                }
        }
        
        //#line 255 "x10/regionarray/RectRegion.x10"
        return true;
    }
    
    
    //#line 258 "x10/regionarray/RectRegion.x10"
    public boolean contains$O(final long i0) {
        
        //#line 258 "x10/regionarray/RectRegion.x10"
        final x10.regionarray.RectRegion this$157199 = ((x10.regionarray.RectRegion)(this));
        
        //#line 264 . "x10/regionarray/RectRegion.x10"
        final long t$157595 = this$157199.min0;
        
        //#line 264 . "x10/regionarray/RectRegion.x10"
        boolean t$157597 = ((i0) >= (((long)(t$157595))));
        
        //#line 264 . "x10/regionarray/RectRegion.x10"
        if (t$157597) {
            
            //#line 264 . "x10/regionarray/RectRegion.x10"
            final long t$157596 = this$157199.max0;
            
            //#line 264 . "x10/regionarray/RectRegion.x10"
            t$157597 = ((i0) <= (((long)(t$157596))));
        }
        
        //#line 258 "x10/regionarray/RectRegion.x10"
        return t$157597;
    }
    
    
    //#line 259 "x10/regionarray/RectRegion.x10"
    public boolean contains$O(final long i0, final long i1) {
        
        //#line 259 "x10/regionarray/RectRegion.x10"
        final boolean t$157599 = this.containsInternal$O((long)(i0), (long)(i1));
        
        //#line 259 "x10/regionarray/RectRegion.x10"
        return t$157599;
    }
    
    
    //#line 260 "x10/regionarray/RectRegion.x10"
    public boolean contains$O(final long i0, final long i1, final long i2) {
        
        //#line 260 "x10/regionarray/RectRegion.x10"
        final boolean t$157600 = this.containsInternal$O((long)(i0), (long)(i1), (long)(i2));
        
        //#line 260 "x10/regionarray/RectRegion.x10"
        return t$157600;
    }
    
    
    //#line 261 "x10/regionarray/RectRegion.x10"
    public boolean contains$O(final long i0, final long i1, final long i2, final long i3) {
        
        //#line 261 "x10/regionarray/RectRegion.x10"
        final boolean t$157601 = this.containsInternal$O((long)(i0), (long)(i1), (long)(i2), (long)(i3));
        
        //#line 261 "x10/regionarray/RectRegion.x10"
        return t$157601;
    }
    
    
    //#line 263 "x10/regionarray/RectRegion.x10"
    private boolean containsInternal$O(final long i0) {
        
        //#line 264 "x10/regionarray/RectRegion.x10"
        final long t$157602 = this.min0;
        
        //#line 264 "x10/regionarray/RectRegion.x10"
        boolean t$157604 = ((i0) >= (((long)(t$157602))));
        
        //#line 264 "x10/regionarray/RectRegion.x10"
        if (t$157604) {
            
            //#line 264 "x10/regionarray/RectRegion.x10"
            final long t$157603 = this.max0;
            
            //#line 264 "x10/regionarray/RectRegion.x10"
            t$157604 = ((i0) <= (((long)(t$157603))));
        }
        
        //#line 264 "x10/regionarray/RectRegion.x10"
        return t$157604;
    }
    
    public static boolean containsInternal$P$O(final long i0, final x10.regionarray.RectRegion RectRegion) {
        return RectRegion.containsInternal$O((long)(i0));
    }
    
    
    //#line 267 "x10/regionarray/RectRegion.x10"
    private boolean containsInternal$O(final long i0, final long i1) {
        
        //#line 268 "x10/regionarray/RectRegion.x10"
        boolean t$157606 = true;
        
        //#line 268 "x10/regionarray/RectRegion.x10"
        if (t$157606) {
            
            //#line 268 "x10/regionarray/RectRegion.x10"
            t$157606 = this.zeroBased;
        }
        
        //#line 268 "x10/regionarray/RectRegion.x10"
        if (t$157606) {
            
            //#line 269 "x10/regionarray/RectRegion.x10"
            final long t$157608 = ((long)(((long)(i0))));
            
            //#line 269 "x10/regionarray/RectRegion.x10"
            final long t$157607 = this.max0;
            
            //#line 269 "x10/regionarray/RectRegion.x10"
            final long t$157609 = ((long)(((long)(t$157607))));
            
            //#line 269 "x10/regionarray/RectRegion.x10"
            boolean t$157613 = x10.runtime.impl.java.ULongUtils.le(t$157608, ((long)(t$157609)));
            
            //#line 269 "x10/regionarray/RectRegion.x10"
            if (t$157613) {
                
                //#line 270 "x10/regionarray/RectRegion.x10"
                final long t$157611 = ((long)(((long)(i1))));
                
                //#line 270 "x10/regionarray/RectRegion.x10"
                final long t$157610 = this.max1;
                
                //#line 270 "x10/regionarray/RectRegion.x10"
                final long t$157612 = ((long)(((long)(t$157610))));
                
                //#line 269 "x10/regionarray/RectRegion.x10"
                t$157613 = x10.runtime.impl.java.ULongUtils.le(t$157611, ((long)(t$157612)));
            }
            
            //#line 269 "x10/regionarray/RectRegion.x10"
            return t$157613;
        } else {
            
            //#line 272 "x10/regionarray/RectRegion.x10"
            final long t$157615 = this.min0;
            
            //#line 272 "x10/regionarray/RectRegion.x10"
            boolean t$157617 = ((i0) >= (((long)(t$157615))));
            
            //#line 272 "x10/regionarray/RectRegion.x10"
            if (t$157617) {
                
                //#line 272 "x10/regionarray/RectRegion.x10"
                final long t$157616 = this.max0;
                
                //#line 272 "x10/regionarray/RectRegion.x10"
                t$157617 = ((i0) <= (((long)(t$157616))));
            }
            
            //#line 272 "x10/regionarray/RectRegion.x10"
            boolean t$157619 = t$157617;
            
            //#line 272 "x10/regionarray/RectRegion.x10"
            if (t$157617) {
                
                //#line 273 "x10/regionarray/RectRegion.x10"
                final long t$157618 = this.min1;
                
                //#line 272 "x10/regionarray/RectRegion.x10"
                t$157619 = ((i1) >= (((long)(t$157618))));
            }
            
            //#line 272 "x10/regionarray/RectRegion.x10"
            boolean t$157621 = t$157619;
            
            //#line 272 "x10/regionarray/RectRegion.x10"
            if (t$157619) {
                
                //#line 273 "x10/regionarray/RectRegion.x10"
                final long t$157620 = this.max1;
                
                //#line 272 "x10/regionarray/RectRegion.x10"
                t$157621 = ((i1) <= (((long)(t$157620))));
            }
            
            //#line 272 "x10/regionarray/RectRegion.x10"
            return t$157621;
        }
    }
    
    public static boolean containsInternal$P$O(final long i0, final long i1, final x10.regionarray.RectRegion RectRegion) {
        return RectRegion.containsInternal$O((long)(i0), (long)(i1));
    }
    
    
    //#line 277 "x10/regionarray/RectRegion.x10"
    private boolean containsInternal$O(final long i0, final long i1, final long i2) {
        
        //#line 278 "x10/regionarray/RectRegion.x10"
        boolean t$157624 = true;
        
        //#line 278 "x10/regionarray/RectRegion.x10"
        if (t$157624) {
            
            //#line 278 "x10/regionarray/RectRegion.x10"
            t$157624 = this.zeroBased;
        }
        
        //#line 278 "x10/regionarray/RectRegion.x10"
        if (t$157624) {
            
            //#line 279 "x10/regionarray/RectRegion.x10"
            final long t$157626 = ((long)(((long)(i0))));
            
            //#line 279 "x10/regionarray/RectRegion.x10"
            final long t$157625 = this.max0;
            
            //#line 279 "x10/regionarray/RectRegion.x10"
            final long t$157627 = ((long)(((long)(t$157625))));
            
            //#line 279 "x10/regionarray/RectRegion.x10"
            boolean t$157631 = x10.runtime.impl.java.ULongUtils.le(t$157626, ((long)(t$157627)));
            
            //#line 279 "x10/regionarray/RectRegion.x10"
            if (t$157631) {
                
                //#line 280 "x10/regionarray/RectRegion.x10"
                final long t$157629 = ((long)(((long)(i1))));
                
                //#line 280 "x10/regionarray/RectRegion.x10"
                final long t$157628 = this.max1;
                
                //#line 280 "x10/regionarray/RectRegion.x10"
                final long t$157630 = ((long)(((long)(t$157628))));
                
                //#line 279 "x10/regionarray/RectRegion.x10"
                t$157631 = x10.runtime.impl.java.ULongUtils.le(t$157629, ((long)(t$157630)));
            }
            
            //#line 279 "x10/regionarray/RectRegion.x10"
            boolean t$157635 = t$157631;
            
            //#line 279 "x10/regionarray/RectRegion.x10"
            if (t$157631) {
                
                //#line 281 "x10/regionarray/RectRegion.x10"
                final long t$157633 = ((long)(((long)(i2))));
                
                //#line 281 "x10/regionarray/RectRegion.x10"
                final long t$157632 = this.max2;
                
                //#line 281 "x10/regionarray/RectRegion.x10"
                final long t$157634 = ((long)(((long)(t$157632))));
                
                //#line 279 "x10/regionarray/RectRegion.x10"
                t$157635 = x10.runtime.impl.java.ULongUtils.le(t$157633, ((long)(t$157634)));
            }
            
            //#line 279 "x10/regionarray/RectRegion.x10"
            return t$157635;
        } else {
            
            //#line 283 "x10/regionarray/RectRegion.x10"
            final long t$157637 = this.min0;
            
            //#line 283 "x10/regionarray/RectRegion.x10"
            boolean t$157639 = ((i0) >= (((long)(t$157637))));
            
            //#line 283 "x10/regionarray/RectRegion.x10"
            if (t$157639) {
                
                //#line 283 "x10/regionarray/RectRegion.x10"
                final long t$157638 = this.max0;
                
                //#line 283 "x10/regionarray/RectRegion.x10"
                t$157639 = ((i0) <= (((long)(t$157638))));
            }
            
            //#line 283 "x10/regionarray/RectRegion.x10"
            boolean t$157641 = t$157639;
            
            //#line 283 "x10/regionarray/RectRegion.x10"
            if (t$157639) {
                
                //#line 284 "x10/regionarray/RectRegion.x10"
                final long t$157640 = this.min1;
                
                //#line 283 "x10/regionarray/RectRegion.x10"
                t$157641 = ((i1) >= (((long)(t$157640))));
            }
            
            //#line 283 "x10/regionarray/RectRegion.x10"
            boolean t$157643 = t$157641;
            
            //#line 283 "x10/regionarray/RectRegion.x10"
            if (t$157641) {
                
                //#line 284 "x10/regionarray/RectRegion.x10"
                final long t$157642 = this.max1;
                
                //#line 283 "x10/regionarray/RectRegion.x10"
                t$157643 = ((i1) <= (((long)(t$157642))));
            }
            
            //#line 283 "x10/regionarray/RectRegion.x10"
            boolean t$157645 = t$157643;
            
            //#line 283 "x10/regionarray/RectRegion.x10"
            if (t$157643) {
                
                //#line 285 "x10/regionarray/RectRegion.x10"
                final long t$157644 = this.min2;
                
                //#line 283 "x10/regionarray/RectRegion.x10"
                t$157645 = ((i2) >= (((long)(t$157644))));
            }
            
            //#line 283 "x10/regionarray/RectRegion.x10"
            boolean t$157647 = t$157645;
            
            //#line 283 "x10/regionarray/RectRegion.x10"
            if (t$157645) {
                
                //#line 285 "x10/regionarray/RectRegion.x10"
                final long t$157646 = this.max2;
                
                //#line 283 "x10/regionarray/RectRegion.x10"
                t$157647 = ((i2) <= (((long)(t$157646))));
            }
            
            //#line 283 "x10/regionarray/RectRegion.x10"
            return t$157647;
        }
    }
    
    public static boolean containsInternal$P$O(final long i0, final long i1, final long i2, final x10.regionarray.RectRegion RectRegion) {
        return RectRegion.containsInternal$O((long)(i0), (long)(i1), (long)(i2));
    }
    
    
    //#line 289 "x10/regionarray/RectRegion.x10"
    private boolean containsInternal$O(final long i0, final long i1, final long i2, final long i3) {
        
        //#line 290 "x10/regionarray/RectRegion.x10"
        boolean t$157650 = true;
        
        //#line 290 "x10/regionarray/RectRegion.x10"
        if (t$157650) {
            
            //#line 290 "x10/regionarray/RectRegion.x10"
            t$157650 = this.zeroBased;
        }
        
        //#line 290 "x10/regionarray/RectRegion.x10"
        if (t$157650) {
            
            //#line 291 "x10/regionarray/RectRegion.x10"
            final long t$157652 = ((long)(((long)(i0))));
            
            //#line 291 "x10/regionarray/RectRegion.x10"
            final long t$157651 = this.max0;
            
            //#line 291 "x10/regionarray/RectRegion.x10"
            final long t$157653 = ((long)(((long)(t$157651))));
            
            //#line 291 "x10/regionarray/RectRegion.x10"
            boolean t$157657 = x10.runtime.impl.java.ULongUtils.le(t$157652, ((long)(t$157653)));
            
            //#line 291 "x10/regionarray/RectRegion.x10"
            if (t$157657) {
                
                //#line 292 "x10/regionarray/RectRegion.x10"
                final long t$157655 = ((long)(((long)(i1))));
                
                //#line 292 "x10/regionarray/RectRegion.x10"
                final long t$157654 = this.max1;
                
                //#line 292 "x10/regionarray/RectRegion.x10"
                final long t$157656 = ((long)(((long)(t$157654))));
                
                //#line 291 "x10/regionarray/RectRegion.x10"
                t$157657 = x10.runtime.impl.java.ULongUtils.le(t$157655, ((long)(t$157656)));
            }
            
            //#line 291 "x10/regionarray/RectRegion.x10"
            boolean t$157661 = t$157657;
            
            //#line 291 "x10/regionarray/RectRegion.x10"
            if (t$157657) {
                
                //#line 293 "x10/regionarray/RectRegion.x10"
                final long t$157659 = ((long)(((long)(i2))));
                
                //#line 293 "x10/regionarray/RectRegion.x10"
                final long t$157658 = this.max2;
                
                //#line 293 "x10/regionarray/RectRegion.x10"
                final long t$157660 = ((long)(((long)(t$157658))));
                
                //#line 291 "x10/regionarray/RectRegion.x10"
                t$157661 = x10.runtime.impl.java.ULongUtils.le(t$157659, ((long)(t$157660)));
            }
            
            //#line 291 "x10/regionarray/RectRegion.x10"
            boolean t$157665 = t$157661;
            
            //#line 291 "x10/regionarray/RectRegion.x10"
            if (t$157661) {
                
                //#line 294 "x10/regionarray/RectRegion.x10"
                final long t$157663 = ((long)(((long)(i3))));
                
                //#line 294 "x10/regionarray/RectRegion.x10"
                final long t$157662 = this.max3;
                
                //#line 294 "x10/regionarray/RectRegion.x10"
                final long t$157664 = ((long)(((long)(t$157662))));
                
                //#line 291 "x10/regionarray/RectRegion.x10"
                t$157665 = x10.runtime.impl.java.ULongUtils.le(t$157663, ((long)(t$157664)));
            }
            
            //#line 291 "x10/regionarray/RectRegion.x10"
            return t$157665;
        } else {
            
            //#line 296 "x10/regionarray/RectRegion.x10"
            final long t$157667 = this.min0;
            
            //#line 296 "x10/regionarray/RectRegion.x10"
            boolean t$157669 = ((i0) >= (((long)(t$157667))));
            
            //#line 296 "x10/regionarray/RectRegion.x10"
            if (t$157669) {
                
                //#line 296 "x10/regionarray/RectRegion.x10"
                final long t$157668 = this.max0;
                
                //#line 296 "x10/regionarray/RectRegion.x10"
                t$157669 = ((i0) <= (((long)(t$157668))));
            }
            
            //#line 296 "x10/regionarray/RectRegion.x10"
            boolean t$157671 = t$157669;
            
            //#line 296 "x10/regionarray/RectRegion.x10"
            if (t$157669) {
                
                //#line 297 "x10/regionarray/RectRegion.x10"
                final long t$157670 = this.min1;
                
                //#line 296 "x10/regionarray/RectRegion.x10"
                t$157671 = ((i1) >= (((long)(t$157670))));
            }
            
            //#line 296 "x10/regionarray/RectRegion.x10"
            boolean t$157673 = t$157671;
            
            //#line 296 "x10/regionarray/RectRegion.x10"
            if (t$157671) {
                
                //#line 297 "x10/regionarray/RectRegion.x10"
                final long t$157672 = this.max1;
                
                //#line 296 "x10/regionarray/RectRegion.x10"
                t$157673 = ((i1) <= (((long)(t$157672))));
            }
            
            //#line 296 "x10/regionarray/RectRegion.x10"
            boolean t$157675 = t$157673;
            
            //#line 296 "x10/regionarray/RectRegion.x10"
            if (t$157673) {
                
                //#line 298 "x10/regionarray/RectRegion.x10"
                final long t$157674 = this.min2;
                
                //#line 296 "x10/regionarray/RectRegion.x10"
                t$157675 = ((i2) >= (((long)(t$157674))));
            }
            
            //#line 296 "x10/regionarray/RectRegion.x10"
            boolean t$157677 = t$157675;
            
            //#line 296 "x10/regionarray/RectRegion.x10"
            if (t$157675) {
                
                //#line 298 "x10/regionarray/RectRegion.x10"
                final long t$157676 = this.max2;
                
                //#line 296 "x10/regionarray/RectRegion.x10"
                t$157677 = ((i2) <= (((long)(t$157676))));
            }
            
            //#line 296 "x10/regionarray/RectRegion.x10"
            boolean t$157679 = t$157677;
            
            //#line 296 "x10/regionarray/RectRegion.x10"
            if (t$157677) {
                
                //#line 299 "x10/regionarray/RectRegion.x10"
                final long t$157678 = this.min3;
                
                //#line 296 "x10/regionarray/RectRegion.x10"
                t$157679 = ((i3) >= (((long)(t$157678))));
            }
            
            //#line 296 "x10/regionarray/RectRegion.x10"
            boolean t$157681 = t$157679;
            
            //#line 296 "x10/regionarray/RectRegion.x10"
            if (t$157679) {
                
                //#line 299 "x10/regionarray/RectRegion.x10"
                final long t$157680 = this.max3;
                
                //#line 296 "x10/regionarray/RectRegion.x10"
                t$157681 = ((i3) <= (((long)(t$157680))));
            }
            
            //#line 296 "x10/regionarray/RectRegion.x10"
            return t$157681;
        }
    }
    
    public static boolean containsInternal$P$O(final long i0, final long i1, final long i2, final long i3, final x10.regionarray.RectRegion RectRegion) {
        return RectRegion.containsInternal$O((long)(i0), (long)(i1), (long)(i2), (long)(i3));
    }
    
    
    //#line 308 "x10/regionarray/RectRegion.x10"
    /**
     * Return a PolyRegion with the same set of points as this region. This permits
     * general algorithms for intersection, restriction etc to be applied to RectRegion's.
     */
    public x10.regionarray.Region toPolyRegion() {
        
        //#line 309 "x10/regionarray/RectRegion.x10"
        final x10.regionarray.Region t$157684 = ((x10.regionarray.Region)(this.polyRep));
        
        //#line 309 "x10/regionarray/RectRegion.x10"
        final boolean t$157699 = ((t$157684) == (null));
        
        //#line 309 "x10/regionarray/RectRegion.x10"
        if (t$157699) {
            
            //#line 310 "x10/regionarray/RectRegion.x10"
            final long t$157686 = this.rank;
            
            //#line 310 "x10/regionarray/RectRegion.x10"
            final x10.core.fun.Fun_0_1 t$157687 = ((x10.core.fun.Fun_0_1)(new x10.regionarray.RectRegion.$Closure$268(this)));
            
            //#line 310 "x10/regionarray/RectRegion.x10"
            final x10.core.Rail t$157691 = ((x10.core.Rail)(new x10.core.Rail<x10.core.Long>(x10.rtt.Types.LONG, ((long)(t$157686)), ((x10.core.fun.Fun_0_1)(t$157687)), (x10.core.Rail.__1$1x10$lang$Long$3x10$lang$Rail$$T$2) null)));
            
            //#line 311 "x10/regionarray/RectRegion.x10"
            final long t$157689 = this.rank;
            
            //#line 311 "x10/regionarray/RectRegion.x10"
            final x10.core.fun.Fun_0_1 t$157690 = ((x10.core.fun.Fun_0_1)(new x10.regionarray.RectRegion.$Closure$269(this)));
            
            //#line 311 "x10/regionarray/RectRegion.x10"
            final x10.core.Rail t$157692 = ((x10.core.Rail)(new x10.core.Rail<x10.core.Long>(x10.rtt.Types.LONG, ((long)(t$157689)), ((x10.core.fun.Fun_0_1)(t$157690)), (x10.core.Rail.__1$1x10$lang$Long$3x10$lang$Rail$$T$2) null)));
            
            //#line 310 "x10/regionarray/RectRegion.x10"
            final x10.regionarray.Region t$157693 = ((x10.regionarray.Region)(x10.regionarray.Region.makeRectangularPoly__0$1x10$lang$Long$2__1$1x10$lang$Long$2(((x10.core.Rail)(t$157691)), ((x10.core.Rail)(t$157692)))));
            
            //#line 310 "x10/regionarray/RectRegion.x10"
            final x10.regionarray.Region t$145595 = ((x10.regionarray.Region)
                                                      t$157693);
            
            //#line 311 "x10/regionarray/RectRegion.x10"
            final long t$157694 = t$145595.rank;
            
            //#line 311 "x10/regionarray/RectRegion.x10"
            final long t$157695 = x10.regionarray.RectRegion.this.rank;
            
            //#line 311 "x10/regionarray/RectRegion.x10"
            final boolean t$157696 = ((long) t$157694) == ((long) t$157695);
            
            //#line 310 "x10/regionarray/RectRegion.x10"
            final boolean t$157698 = !(t$157696);
            
            //#line 310 "x10/regionarray/RectRegion.x10"
            if (t$157698) {
                
                //#line 310 "x10/regionarray/RectRegion.x10"
                final x10.lang.FailedDynamicCheckException t$157697 = new x10.lang.FailedDynamicCheckException("x10.regionarray.Region{self.rank==this(:x10.regionarray.RectRegion).rank}");
                
                //#line 310 "x10/regionarray/RectRegion.x10"
                throw t$157697;
            }
            
            //#line 310 "x10/regionarray/RectRegion.x10"
            this.polyRep = ((x10.regionarray.Region)(t$145595));
        }
        
        //#line 313 "x10/regionarray/RectRegion.x10"
        final x10.regionarray.Region t$157700 = ((x10.regionarray.Region)(this.polyRep));
        
        //#line 313 "x10/regionarray/RectRegion.x10"
        return t$157700;
    }
    
    
    //#line 317 "x10/regionarray/RectRegion.x10"
    public x10.regionarray.Region intersection(final x10.regionarray.Region that) {
        
        //#line 318 "x10/regionarray/RectRegion.x10"
        final boolean t$157756 = that.isEmpty$O();
        
        //#line 318 "x10/regionarray/RectRegion.x10"
        if (t$157756) {
            
            //#line 319 "x10/regionarray/RectRegion.x10"
            return that;
        } else {
            
            //#line 320 "x10/regionarray/RectRegion.x10"
            final boolean t$157755 = x10.regionarray.FullRegion.$RTT.isInstance(that);
            
            //#line 320 "x10/regionarray/RectRegion.x10"
            if (t$157755) {
                
                //#line 321 "x10/regionarray/RectRegion.x10"
                return this;
            } else {
                
                //#line 322 "x10/regionarray/RectRegion.x10"
                final boolean t$157754 = x10.regionarray.RectRegion.$RTT.isInstance(that);
                
                //#line 322 "x10/regionarray/RectRegion.x10"
                if (t$157754) {
                    
                    //#line 323 "x10/regionarray/RectRegion.x10"
                    final x10.regionarray.RectRegion this$157202 = ((x10.regionarray.RectRegion)(x10.rtt.Types.<x10.regionarray.RectRegion> cast(that,x10.regionarray.RectRegion.$RTT)));
                    
                    //#line 223 . "x10/regionarray/RectRegion.x10"
                    x10.core.fun.Fun_0_1 ret$157203 =  null;
                    
                    //#line 223 . "x10/regionarray/RectRegion.x10"
                    final x10.core.fun.Fun_0_1 t$158076 = ((x10.core.fun.Fun_0_1)(new x10.regionarray.RectRegion.$Closure$270(this$157202)));
                    
                    //#line 223 . "x10/regionarray/RectRegion.x10"
                    ret$157203 = ((x10.core.fun.Fun_0_1)(t$158076));
                    
                    //#line 323 "x10/regionarray/RectRegion.x10"
                    final x10.core.fun.Fun_0_1 thatMin = ret$157203;
                    
                    //#line 324 "x10/regionarray/RectRegion.x10"
                    final x10.regionarray.RectRegion this$157206 = ((x10.regionarray.RectRegion)(x10.rtt.Types.<x10.regionarray.RectRegion> cast(that,x10.regionarray.RectRegion.$RTT)));
                    
                    //#line 224 . "x10/regionarray/RectRegion.x10"
                    x10.core.fun.Fun_0_1 ret$157207 =  null;
                    
                    //#line 224 . "x10/regionarray/RectRegion.x10"
                    final x10.core.fun.Fun_0_1 t$158079 = ((x10.core.fun.Fun_0_1)(new x10.regionarray.RectRegion.$Closure$271(this$157206)));
                    
                    //#line 224 . "x10/regionarray/RectRegion.x10"
                    ret$157207 = ((x10.core.fun.Fun_0_1)(t$158079));
                    
                    //#line 324 "x10/regionarray/RectRegion.x10"
                    final x10.core.fun.Fun_0_1 thatMax = ret$157207;
                    
                    //#line 325 "x10/regionarray/RectRegion.x10"
                    final long t$157708 = this.rank;
                    
                    //#line 325 "x10/regionarray/RectRegion.x10"
                    final x10.core.fun.Fun_0_1 t$157709 = ((x10.core.fun.Fun_0_1)(new x10.regionarray.RectRegion.$Closure$272(this, thatMin, (x10.regionarray.RectRegion.$Closure$272.__1$1x10$lang$Long$3x10$lang$Long$2) null)));
                    
                    //#line 325 "x10/regionarray/RectRegion.x10"
                    final x10.core.Rail newMin = ((x10.core.Rail)(new x10.core.Rail<x10.core.Long>(x10.rtt.Types.LONG, ((long)(t$157708)), ((x10.core.fun.Fun_0_1)(t$157709)), (x10.core.Rail.__1$1x10$lang$Long$3x10$lang$Rail$$T$2) null)));
                    
                    //#line 326 "x10/regionarray/RectRegion.x10"
                    final long t$157713 = this.rank;
                    
                    //#line 326 "x10/regionarray/RectRegion.x10"
                    final x10.core.fun.Fun_0_1 t$157714 = ((x10.core.fun.Fun_0_1)(new x10.regionarray.RectRegion.$Closure$273(this, thatMax, (x10.regionarray.RectRegion.$Closure$273.__1$1x10$lang$Long$3x10$lang$Long$2) null)));
                    
                    //#line 326 "x10/regionarray/RectRegion.x10"
                    final x10.core.Rail newMax = ((x10.core.Rail)(new x10.core.Rail<x10.core.Long>(x10.rtt.Types.LONG, ((long)(t$157713)), ((x10.core.fun.Fun_0_1)(t$157714)), (x10.core.Rail.__1$1x10$lang$Long$3x10$lang$Rail$$T$2) null)));
                    
                    //#line 327 "x10/regionarray/RectRegion.x10"
                    final long t$158082 = ((x10.core.Rail<x10.core.Long>)newMin).size;
                    
                    //#line 327 "x10/regionarray/RectRegion.x10"
                    final long i$146195max$158083 = ((t$158082) - (((long)(1L))));
                    
                    //#line 327 "x10/regionarray/RectRegion.x10"
                    long i$158073 = 0L;
                    {
                        
                        //#line 327 "x10/regionarray/RectRegion.x10"
                        final long[] newMax$value$158177 = ((long[])newMax.value);
                        
                        //#line 327 "x10/regionarray/RectRegion.x10"
                        final long[] newMin$value$158178 = ((long[])newMin.value);
                        
                        //#line 327 "x10/regionarray/RectRegion.x10"
                        for (;
                             true;
                             ) {
                            
                            //#line 327 "x10/regionarray/RectRegion.x10"
                            final boolean t$158075 = ((i$158073) <= (((long)(i$146195max$158083))));
                            
                            //#line 327 "x10/regionarray/RectRegion.x10"
                            if (!(t$158075)) {
                                
                                //#line 327 "x10/regionarray/RectRegion.x10"
                                break;
                            }
                            
                            //#line 328 "x10/regionarray/RectRegion.x10"
                            final long t$158064 = ((long)newMax$value$158177[(int)i$158073]);
                            
                            //#line 328 "x10/regionarray/RectRegion.x10"
                            final long t$158065 = ((long)newMin$value$158178[(int)i$158073]);
                            
                            //#line 328 "x10/regionarray/RectRegion.x10"
                            final boolean t$158066 = ((t$158064) < (((long)(t$158065))));
                            
                            //#line 328 "x10/regionarray/RectRegion.x10"
                            if (t$158066) {
                                
                                //#line 328 "x10/regionarray/RectRegion.x10"
                                final long rank$158067 = this.rank;
                                
                                //#line 60 . "x10/regionarray/Region.x10"
                                final x10.regionarray.EmptyRegion alloc$158068 = ((x10.regionarray.EmptyRegion)(new x10.regionarray.EmptyRegion((java.lang.System[]) null)));
                                
                                //#line 60 . "x10/regionarray/Region.x10"
                                alloc$158068.x10$regionarray$EmptyRegion$$init$S(((long)(rank$158067)));
                                
                                //#line 60 . "x10/regionarray/Region.x10"
                                final x10.regionarray.Region t$158069 = ((x10.regionarray.Region)(((x10.regionarray.Region)
                                                                                                    alloc$158068)));
                                
                                //#line 328 "x10/regionarray/RectRegion.x10"
                                return t$158069;
                            }
                            
                            //#line 327 "x10/regionarray/RectRegion.x10"
                            final long t$158072 = ((i$158073) + (((long)(1L))));
                            
                            //#line 327 "x10/regionarray/RectRegion.x10"
                            i$158073 = t$158072;
                        }
                    }
                    
                    //#line 330 "x10/regionarray/RectRegion.x10"
                    final x10.regionarray.RectRegion alloc$146093 = ((x10.regionarray.RectRegion)(new x10.regionarray.RectRegion((java.lang.System[]) null)));
                    
                    //#line 330 "x10/regionarray/RectRegion.x10"
                    alloc$146093.x10$regionarray$RectRegion$$init$S(((x10.core.Rail)(newMin)), ((x10.core.Rail)(newMax)), (x10.regionarray.RectRegion.__0$1x10$lang$Long$2__1$1x10$lang$Long$2) null);
                    
                    //#line 330 "x10/regionarray/RectRegion.x10"
                    final x10.regionarray.Region t$145613 = ((x10.regionarray.Region)
                                                              alloc$146093);
                    
                    //#line 330 "x10/regionarray/RectRegion.x10"
                    final long t$157725 = t$145613.rank;
                    
                    //#line 330 "x10/regionarray/RectRegion.x10"
                    final long t$157726 = x10.regionarray.RectRegion.this.rank;
                    
                    //#line 330 "x10/regionarray/RectRegion.x10"
                    final boolean t$157727 = ((long) t$157725) == ((long) t$157726);
                    
                    //#line 330 "x10/regionarray/RectRegion.x10"
                    final boolean t$157729 = !(t$157727);
                    
                    //#line 330 "x10/regionarray/RectRegion.x10"
                    if (t$157729) {
                        
                        //#line 330 "x10/regionarray/RectRegion.x10"
                        final x10.lang.FailedDynamicCheckException t$157728 = new x10.lang.FailedDynamicCheckException("x10.regionarray.Region{self.rank==this(:x10.regionarray.RectRegion).rank}");
                        
                        //#line 330 "x10/regionarray/RectRegion.x10"
                        throw t$157728;
                    }
                    
                    //#line 330 "x10/regionarray/RectRegion.x10"
                    return t$145613;
                } else {
                    
                    //#line 331 "x10/regionarray/RectRegion.x10"
                    final boolean t$157753 = x10.regionarray.RectRegion1D.$RTT.isInstance(that);
                    
                    //#line 331 "x10/regionarray/RectRegion.x10"
                    if (t$157753) {
                        
                        //#line 332 "x10/regionarray/RectRegion.x10"
                        final long t$157730 = this.min$O((long)(0L));
                        
                        //#line 332 "x10/regionarray/RectRegion.x10"
                        final long t$157731 = that.min$O((long)(0L));
                        
                        //#line 332 "x10/regionarray/RectRegion.x10"
                        final long newMin = java.lang.Math.max(((long)(t$157730)),((long)(t$157731)));
                        
                        //#line 333 "x10/regionarray/RectRegion.x10"
                        final long t$157732 = this.max$O((long)(0L));
                        
                        //#line 333 "x10/regionarray/RectRegion.x10"
                        final long t$157733 = that.max$O((long)(0L));
                        
                        //#line 333 "x10/regionarray/RectRegion.x10"
                        final long newMax = java.lang.Math.min(((long)(t$157732)),((long)(t$157733)));
                        
                        //#line 334 "x10/regionarray/RectRegion.x10"
                        final boolean t$157740 = ((newMax) < (((long)(newMin))));
                        
                        //#line 334 "x10/regionarray/RectRegion.x10"
                        if (t$157740) {
                            
                            //#line 60 . "x10/regionarray/Region.x10"
                            final x10.regionarray.EmptyRegion alloc$157213 = ((x10.regionarray.EmptyRegion)(new x10.regionarray.EmptyRegion((java.lang.System[]) null)));
                            
                            //#line 60 . "x10/regionarray/Region.x10"
                            alloc$157213.x10$regionarray$EmptyRegion$$init$S(((long)(1L)));
                            
                            //#line 60 . "x10/regionarray/Region.x10"
                            final x10.regionarray.Region t$157734 = ((x10.regionarray.Region)(((x10.regionarray.Region)
                                                                                                alloc$157213)));
                            
                            //#line 334 "x10/regionarray/RectRegion.x10"
                            final x10.regionarray.Region t$145622 = ((x10.regionarray.Region)
                                                                      t$157734);
                            
                            //#line 334 "x10/regionarray/RectRegion.x10"
                            final long t$157735 = t$145622.rank;
                            
                            //#line 334 "x10/regionarray/RectRegion.x10"
                            final long t$157736 = x10.regionarray.RectRegion.this.rank;
                            
                            //#line 334 "x10/regionarray/RectRegion.x10"
                            final boolean t$157737 = ((long) t$157735) == ((long) t$157736);
                            
                            //#line 334 "x10/regionarray/RectRegion.x10"
                            final boolean t$157739 = !(t$157737);
                            
                            //#line 334 "x10/regionarray/RectRegion.x10"
                            if (t$157739) {
                                
                                //#line 334 "x10/regionarray/RectRegion.x10"
                                final x10.lang.FailedDynamicCheckException t$157738 = new x10.lang.FailedDynamicCheckException("x10.regionarray.Region{self.rank==this(:x10.regionarray.RectRegion).rank}");
                                
                                //#line 334 "x10/regionarray/RectRegion.x10"
                                throw t$157738;
                            }
                            
                            //#line 334 "x10/regionarray/RectRegion.x10"
                            return t$145622;
                        }
                        
                        //#line 335 "x10/regionarray/RectRegion.x10"
                        final x10.regionarray.RectRegion1D alloc$146094 = ((x10.regionarray.RectRegion1D)(new x10.regionarray.RectRegion1D((java.lang.System[]) null)));
                        
                        //#line 335 "x10/regionarray/RectRegion.x10"
                        alloc$146094.x10$regionarray$RectRegion1D$$init$S(((long)(newMin)), ((long)(newMax)));
                        
                        //#line 335 "x10/regionarray/RectRegion.x10"
                        final x10.regionarray.Region t$145624 = ((x10.regionarray.Region)
                                                                  alloc$146094);
                        
                        //#line 335 "x10/regionarray/RectRegion.x10"
                        final long t$157741 = t$145624.rank;
                        
                        //#line 335 "x10/regionarray/RectRegion.x10"
                        final long t$157742 = x10.regionarray.RectRegion.this.rank;
                        
                        //#line 335 "x10/regionarray/RectRegion.x10"
                        final boolean t$157743 = ((long) t$157741) == ((long) t$157742);
                        
                        //#line 335 "x10/regionarray/RectRegion.x10"
                        final boolean t$157745 = !(t$157743);
                        
                        //#line 335 "x10/regionarray/RectRegion.x10"
                        if (t$157745) {
                            
                            //#line 335 "x10/regionarray/RectRegion.x10"
                            final x10.lang.FailedDynamicCheckException t$157744 = new x10.lang.FailedDynamicCheckException("x10.regionarray.Region{self.rank==this(:x10.regionarray.RectRegion).rank}");
                            
                            //#line 335 "x10/regionarray/RectRegion.x10"
                            throw t$157744;
                        }
                        
                        //#line 335 "x10/regionarray/RectRegion.x10"
                        return t$145624;
                    } else {
                        
                        //#line 338 "x10/regionarray/RectRegion.x10"
                        final x10.regionarray.Region t$157746 = ((x10.regionarray.Region)(this.toPolyRegion()));
                        
                        //#line 338 "x10/regionarray/RectRegion.x10"
                        final x10.regionarray.Region t$145626 = ((x10.regionarray.Region)
                                                                  t$157746);
                        
                        //#line 338 "x10/regionarray/RectRegion.x10"
                        final long t$157747 = t$145626.rank;
                        
                        //#line 338 "x10/regionarray/RectRegion.x10"
                        final long t$157748 = x10.regionarray.RectRegion.this.rank;
                        
                        //#line 338 "x10/regionarray/RectRegion.x10"
                        final boolean t$157749 = ((long) t$157747) == ((long) t$157748);
                        
                        //#line 338 "x10/regionarray/RectRegion.x10"
                        final boolean t$157751 = !(t$157749);
                        
                        //#line 338 "x10/regionarray/RectRegion.x10"
                        if (t$157751) {
                            
                            //#line 338 "x10/regionarray/RectRegion.x10"
                            final x10.lang.FailedDynamicCheckException t$157750 = new x10.lang.FailedDynamicCheckException("x10.regionarray.Region{self.rank==this(:x10.regionarray.RectRegion).rank}");
                            
                            //#line 338 "x10/regionarray/RectRegion.x10"
                            throw t$157750;
                        }
                        
                        //#line 338 "x10/regionarray/RectRegion.x10"
                        final x10.regionarray.Region t$157752 = ((x10.regionarray.Region)(t$145626.intersection(((x10.regionarray.Region)(that)))));
                        
                        //#line 338 "x10/regionarray/RectRegion.x10"
                        return t$157752;
                    }
                }
            }
        }
    }
    
    
    //#line 344 "x10/regionarray/RectRegion.x10"
    public x10.regionarray.Region product(final x10.regionarray.Region that) {
        
        //#line 345 "x10/regionarray/RectRegion.x10"
        final boolean t$157813 = that.isEmpty$O();
        
        //#line 345 "x10/regionarray/RectRegion.x10"
        if (t$157813) {
            
            //#line 346 "x10/regionarray/RectRegion.x10"
            final long t$157757 = this.rank;
            
            //#line 346 "x10/regionarray/RectRegion.x10"
            final long t$157758 = that.rank;
            
            //#line 346 "x10/regionarray/RectRegion.x10"
            final long rank$157215 = ((t$157757) + (((long)(t$157758))));
            
            //#line 60 . "x10/regionarray/Region.x10"
            final x10.regionarray.EmptyRegion alloc$157216 = ((x10.regionarray.EmptyRegion)(new x10.regionarray.EmptyRegion((java.lang.System[]) null)));
            
            //#line 60 . "x10/regionarray/Region.x10"
            alloc$157216.x10$regionarray$EmptyRegion$$init$S(((long)(rank$157215)));
            
            //#line 60 . "x10/regionarray/Region.x10"
            final x10.regionarray.Region t$157759 = ((x10.regionarray.Region)(((x10.regionarray.Region)
                                                                                alloc$157216)));
            
            //#line 346 "x10/regionarray/RectRegion.x10"
            return t$157759;
        } else {
            
            //#line 347 "x10/regionarray/RectRegion.x10"
            final boolean t$157812 = x10.regionarray.RectRegion.$RTT.isInstance(that);
            
            //#line 347 "x10/regionarray/RectRegion.x10"
            if (t$157812) {
                
                //#line 348 "x10/regionarray/RectRegion.x10"
                final x10.regionarray.RectRegion this$157219 = ((x10.regionarray.RectRegion)(x10.rtt.Types.<x10.regionarray.RectRegion> cast(that,x10.regionarray.RectRegion.$RTT)));
                
                //#line 223 . "x10/regionarray/RectRegion.x10"
                x10.core.fun.Fun_0_1 ret$157220 =  null;
                
                //#line 223 . "x10/regionarray/RectRegion.x10"
                final x10.core.fun.Fun_0_1 t$158084 = ((x10.core.fun.Fun_0_1)(new x10.regionarray.RectRegion.$Closure$274(this$157219)));
                
                //#line 223 . "x10/regionarray/RectRegion.x10"
                ret$157220 = ((x10.core.fun.Fun_0_1)(t$158084));
                
                //#line 348 "x10/regionarray/RectRegion.x10"
                final x10.core.fun.Fun_0_1 thatMin = ret$157220;
                
                //#line 349 "x10/regionarray/RectRegion.x10"
                final x10.regionarray.RectRegion this$157223 = ((x10.regionarray.RectRegion)(x10.rtt.Types.<x10.regionarray.RectRegion> cast(that,x10.regionarray.RectRegion.$RTT)));
                
                //#line 224 . "x10/regionarray/RectRegion.x10"
                x10.core.fun.Fun_0_1 ret$157224 =  null;
                
                //#line 224 . "x10/regionarray/RectRegion.x10"
                final x10.core.fun.Fun_0_1 t$158087 = ((x10.core.fun.Fun_0_1)(new x10.regionarray.RectRegion.$Closure$275(this$157223)));
                
                //#line 224 . "x10/regionarray/RectRegion.x10"
                ret$157224 = ((x10.core.fun.Fun_0_1)(t$158087));
                
                //#line 349 "x10/regionarray/RectRegion.x10"
                final x10.core.fun.Fun_0_1 thatMax = ret$157224;
                
                //#line 350 "x10/regionarray/RectRegion.x10"
                final long t$157764 = this.rank;
                
                //#line 350 "x10/regionarray/RectRegion.x10"
                final long t$157765 = that.rank;
                
                //#line 350 "x10/regionarray/RectRegion.x10"
                final long k = ((t$157764) + (((long)(t$157765))));
                
                //#line 351 "x10/regionarray/RectRegion.x10"
                final x10.core.fun.Fun_0_1 t$157772 = ((x10.core.fun.Fun_0_1)(new x10.regionarray.RectRegion.$Closure$276(this, this.rank, thatMin, (x10.regionarray.RectRegion.$Closure$276.__2$1x10$lang$Long$3x10$lang$Long$2) null)));
                
                //#line 351 "x10/regionarray/RectRegion.x10"
                final x10.core.Rail newMin = ((x10.core.Rail)(new x10.core.Rail<x10.core.Long>(x10.rtt.Types.LONG, ((long)(k)), ((x10.core.fun.Fun_0_1)(t$157772)), (x10.core.Rail.__1$1x10$lang$Long$3x10$lang$Rail$$T$2) null)));
                
                //#line 352 "x10/regionarray/RectRegion.x10"
                final x10.core.fun.Fun_0_1 t$157779 = ((x10.core.fun.Fun_0_1)(new x10.regionarray.RectRegion.$Closure$277(this, this.rank, thatMax, (x10.regionarray.RectRegion.$Closure$277.__2$1x10$lang$Long$3x10$lang$Long$2) null)));
                
                //#line 352 "x10/regionarray/RectRegion.x10"
                final x10.core.Rail newMax = ((x10.core.Rail)(new x10.core.Rail<x10.core.Long>(x10.rtt.Types.LONG, ((long)(k)), ((x10.core.fun.Fun_0_1)(t$157779)), (x10.core.Rail.__1$1x10$lang$Long$3x10$lang$Rail$$T$2) null)));
                
                //#line 353 "x10/regionarray/RectRegion.x10"
                final x10.regionarray.RectRegion alloc$146095 = ((x10.regionarray.RectRegion)(new x10.regionarray.RectRegion((java.lang.System[]) null)));
                
                //#line 353 "x10/regionarray/RectRegion.x10"
                alloc$146095.x10$regionarray$RectRegion$$init$S(((x10.core.Rail)(newMin)), ((x10.core.Rail)(newMax)), (x10.regionarray.RectRegion.__0$1x10$lang$Long$2__1$1x10$lang$Long$2) null);
                
                //#line 353 "x10/regionarray/RectRegion.x10"
                return alloc$146095;
            } else {
                
                //#line 354 "x10/regionarray/RectRegion.x10"
                final boolean t$157811 = x10.regionarray.RectRegion1D.$RTT.isInstance(that);
                
                //#line 354 "x10/regionarray/RectRegion.x10"
                if (t$157811) {
                    
                    //#line 355 "x10/regionarray/RectRegion.x10"
                    final long thatMin = that.min$O((long)(0L));
                    
                    //#line 356 "x10/regionarray/RectRegion.x10"
                    final long thatMax = that.max$O((long)(0L));
                    
                    //#line 357 "x10/regionarray/RectRegion.x10"
                    final long t$157780 = this.rank;
                    
                    //#line 357 "x10/regionarray/RectRegion.x10"
                    final long k = ((t$157780) + (((long)(1L))));
                    
                    //#line 358 "x10/regionarray/RectRegion.x10"
                    final x10.core.fun.Fun_0_1 t$157785 = ((x10.core.fun.Fun_0_1)(new x10.regionarray.RectRegion.$Closure$278(this, this.rank, thatMin)));
                    
                    //#line 358 "x10/regionarray/RectRegion.x10"
                    final x10.core.Rail newMin = ((x10.core.Rail)(new x10.core.Rail<x10.core.Long>(x10.rtt.Types.LONG, ((long)(k)), ((x10.core.fun.Fun_0_1)(t$157785)), (x10.core.Rail.__1$1x10$lang$Long$3x10$lang$Rail$$T$2) null)));
                    
                    //#line 359 "x10/regionarray/RectRegion.x10"
                    final x10.core.fun.Fun_0_1 t$157790 = ((x10.core.fun.Fun_0_1)(new x10.regionarray.RectRegion.$Closure$279(this, this.rank, thatMax)));
                    
                    //#line 359 "x10/regionarray/RectRegion.x10"
                    final x10.core.Rail newMax = ((x10.core.Rail)(new x10.core.Rail<x10.core.Long>(x10.rtt.Types.LONG, ((long)(k)), ((x10.core.fun.Fun_0_1)(t$157790)), (x10.core.Rail.__1$1x10$lang$Long$3x10$lang$Rail$$T$2) null)));
                    
                    //#line 360 "x10/regionarray/RectRegion.x10"
                    final x10.regionarray.RectRegion alloc$146096 = ((x10.regionarray.RectRegion)(new x10.regionarray.RectRegion((java.lang.System[]) null)));
                    
                    //#line 360 "x10/regionarray/RectRegion.x10"
                    alloc$146096.x10$regionarray$RectRegion$$init$S(((x10.core.Rail)(newMin)), ((x10.core.Rail)(newMax)), (x10.regionarray.RectRegion.__0$1x10$lang$Long$2__1$1x10$lang$Long$2) null);
                    
                    //#line 360 "x10/regionarray/RectRegion.x10"
                    return alloc$146096;
                } else {
                    
                    //#line 361 "x10/regionarray/RectRegion.x10"
                    final boolean t$157810 = x10.regionarray.FullRegion.$RTT.isInstance(that);
                    
                    //#line 361 "x10/regionarray/RectRegion.x10"
                    if (t$157810) {
                        
                        //#line 362 "x10/regionarray/RectRegion.x10"
                        final long t$157791 = this.rank;
                        
                        //#line 362 "x10/regionarray/RectRegion.x10"
                        final long t$157792 = that.rank;
                        
                        //#line 362 "x10/regionarray/RectRegion.x10"
                        final long k = ((t$157791) + (((long)(t$157792))));
                        
                        //#line 363 "x10/regionarray/RectRegion.x10"
                        final x10.core.fun.Fun_0_1 t$157797 = ((x10.core.fun.Fun_0_1)(new x10.regionarray.RectRegion.$Closure$280(this, this.rank)));
                        
                        //#line 363 "x10/regionarray/RectRegion.x10"
                        final x10.core.Rail newMin = ((x10.core.Rail)(new x10.core.Rail<x10.core.Long>(x10.rtt.Types.LONG, ((long)(k)), ((x10.core.fun.Fun_0_1)(t$157797)), (x10.core.Rail.__1$1x10$lang$Long$3x10$lang$Rail$$T$2) null)));
                        
                        //#line 364 "x10/regionarray/RectRegion.x10"
                        final x10.core.fun.Fun_0_1 t$157802 = ((x10.core.fun.Fun_0_1)(new x10.regionarray.RectRegion.$Closure$281(this, this.rank)));
                        
                        //#line 364 "x10/regionarray/RectRegion.x10"
                        final x10.core.Rail newMax = ((x10.core.Rail)(new x10.core.Rail<x10.core.Long>(x10.rtt.Types.LONG, ((long)(k)), ((x10.core.fun.Fun_0_1)(t$157802)), (x10.core.Rail.__1$1x10$lang$Long$3x10$lang$Rail$$T$2) null)));
                        
                        //#line 365 "x10/regionarray/RectRegion.x10"
                        final x10.regionarray.RectRegion alloc$146097 = ((x10.regionarray.RectRegion)(new x10.regionarray.RectRegion((java.lang.System[]) null)));
                        
                        //#line 365 "x10/regionarray/RectRegion.x10"
                        alloc$146097.x10$regionarray$RectRegion$$init$S(((x10.core.Rail)(newMin)), ((x10.core.Rail)(newMax)), (x10.regionarray.RectRegion.__0$1x10$lang$Long$2__1$1x10$lang$Long$2) null);
                        
                        //#line 365 "x10/regionarray/RectRegion.x10"
                        return alloc$146097;
                    } else {
                        
                        //#line 367 "x10/regionarray/RectRegion.x10"
                        final x10.regionarray.Region t$157803 = ((x10.regionarray.Region)(this.toPolyRegion()));
                        
                        //#line 367 "x10/regionarray/RectRegion.x10"
                        final x10.regionarray.Region t$145712 = ((x10.regionarray.Region)
                                                                  t$157803);
                        
                        //#line 367 "x10/regionarray/RectRegion.x10"
                        final long t$157804 = t$145712.rank;
                        
                        //#line 367 "x10/regionarray/RectRegion.x10"
                        final long t$157805 = x10.regionarray.RectRegion.this.rank;
                        
                        //#line 367 "x10/regionarray/RectRegion.x10"
                        final boolean t$157806 = ((long) t$157804) == ((long) t$157805);
                        
                        //#line 367 "x10/regionarray/RectRegion.x10"
                        final boolean t$157808 = !(t$157806);
                        
                        //#line 367 "x10/regionarray/RectRegion.x10"
                        if (t$157808) {
                            
                            //#line 367 "x10/regionarray/RectRegion.x10"
                            final x10.lang.FailedDynamicCheckException t$157807 = new x10.lang.FailedDynamicCheckException("x10.regionarray.Region{self.rank==this(:x10.regionarray.RectRegion).rank}");
                            
                            //#line 367 "x10/regionarray/RectRegion.x10"
                            throw t$157807;
                        }
                        
                        //#line 367 "x10/regionarray/RectRegion.x10"
                        final x10.regionarray.Region t$157809 = ((x10.regionarray.Region)(t$145712.product(((x10.regionarray.Region)(that)))));
                        
                        //#line 367 "x10/regionarray/RectRegion.x10"
                        return t$157809;
                    }
                }
            }
        }
    }
    
    
    //#line 371 "x10/regionarray/RectRegion.x10"
    public x10.regionarray.Region translate(final x10.lang.Point v) {
        
        //#line 372 "x10/regionarray/RectRegion.x10"
        final long t$157817 = this.rank;
        
        //#line 372 "x10/regionarray/RectRegion.x10"
        final x10.core.fun.Fun_0_1 t$157818 = ((x10.core.fun.Fun_0_1)(new x10.regionarray.RectRegion.$Closure$282(this, v)));
        
        //#line 372 "x10/regionarray/RectRegion.x10"
        final x10.core.Rail newMin = ((x10.core.Rail)(new x10.core.Rail<x10.core.Long>(x10.rtt.Types.LONG, ((long)(t$157817)), ((x10.core.fun.Fun_0_1)(t$157818)), (x10.core.Rail.__1$1x10$lang$Long$3x10$lang$Rail$$T$2) null)));
        
        //#line 373 "x10/regionarray/RectRegion.x10"
        final long t$157822 = this.rank;
        
        //#line 373 "x10/regionarray/RectRegion.x10"
        final x10.core.fun.Fun_0_1 t$157823 = ((x10.core.fun.Fun_0_1)(new x10.regionarray.RectRegion.$Closure$283(this, v)));
        
        //#line 373 "x10/regionarray/RectRegion.x10"
        final x10.core.Rail newMax = ((x10.core.Rail)(new x10.core.Rail<x10.core.Long>(x10.rtt.Types.LONG, ((long)(t$157822)), ((x10.core.fun.Fun_0_1)(t$157823)), (x10.core.Rail.__1$1x10$lang$Long$3x10$lang$Rail$$T$2) null)));
        
        //#line 374 "x10/regionarray/RectRegion.x10"
        final x10.regionarray.RectRegion alloc$146098 = ((x10.regionarray.RectRegion)(new x10.regionarray.RectRegion((java.lang.System[]) null)));
        
        //#line 374 "x10/regionarray/RectRegion.x10"
        alloc$146098.x10$regionarray$RectRegion$$init$S(((x10.core.Rail)(newMin)), ((x10.core.Rail)(newMax)), (x10.regionarray.RectRegion.__0$1x10$lang$Long$2__1$1x10$lang$Long$2) null);
        
        //#line 374 "x10/regionarray/RectRegion.x10"
        final x10.regionarray.Region t$145728 = ((x10.regionarray.Region)
                                                  alloc$146098);
        
        //#line 374 "x10/regionarray/RectRegion.x10"
        final boolean t$157824 = t$145728.rect;
        
        //#line 374 "x10/regionarray/RectRegion.x10"
        boolean t$157827 = ((boolean) t$157824) == ((boolean) true);
        
        //#line 374 "x10/regionarray/RectRegion.x10"
        if (t$157827) {
            
            //#line 374 "x10/regionarray/RectRegion.x10"
            final long t$157825 = t$145728.rank;
            
            //#line 374 "x10/regionarray/RectRegion.x10"
            final long t$157826 = x10.regionarray.RectRegion.this.rank;
            
            //#line 374 "x10/regionarray/RectRegion.x10"
            t$157827 = ((long) t$157825) == ((long) t$157826);
        }
        
        //#line 374 "x10/regionarray/RectRegion.x10"
        final boolean t$157830 = !(t$157827);
        
        //#line 374 "x10/regionarray/RectRegion.x10"
        if (t$157830) {
            
            //#line 374 "x10/regionarray/RectRegion.x10"
            final x10.lang.FailedDynamicCheckException t$157829 = new x10.lang.FailedDynamicCheckException("x10.regionarray.Region{self.rect==true, self.rank==this(:x10.regionarray.RectRegion).rank}");
            
            //#line 374 "x10/regionarray/RectRegion.x10"
            throw t$157829;
        }
        
        //#line 374 "x10/regionarray/RectRegion.x10"
        return t$145728;
    }
    
    
    //#line 377 "x10/regionarray/RectRegion.x10"
    public x10.regionarray.Region projection(final long axis) {
        
        //#line 378 "x10/regionarray/RectRegion.x10"
        final x10.regionarray.RectRegion alloc$146099 = ((x10.regionarray.RectRegion)(new x10.regionarray.RectRegion((java.lang.System[]) null)));
        
        //#line 378 "x10/regionarray/RectRegion.x10"
        final long min$157226 = this.min$O((long)(axis));
        
        //#line 378 "x10/regionarray/RectRegion.x10"
        final long max$157227 = this.max$O((long)(axis));
        
        //#line 105 . "x10/regionarray/RectRegion.x10"
        final boolean z$158091 = ((long) min$157226) == ((long) 0L);
        
        //#line 558 .. "x10/regionarray/Region.x10"
        alloc$146099.rank = 1L;
        
        //#line 558 .. "x10/regionarray/Region.x10"
        alloc$146099.rect = true;
        
        //#line 558 .. "x10/regionarray/Region.x10"
        alloc$146099.zeroBased = z$158091;
        
        //#line 558 .. "x10/regionarray/Region.x10"
        alloc$146099.rail = z$158091;
        
        //#line 21 .. "x10/regionarray/RectRegion.x10"
        alloc$146099.polyRep = null;
        
        //#line 107 . "x10/regionarray/RectRegion.x10"
        final long t$158092 = java.lang.Long.MIN_VALUE;
        
        //#line 107 . "x10/regionarray/RectRegion.x10"
        boolean t$158093 = ((long) min$157226) == ((long) t$158092);
        
        //#line 107 . "x10/regionarray/RectRegion.x10"
        if (t$158093) {
            
            //#line 107 . "x10/regionarray/RectRegion.x10"
            final long t$158094 = java.lang.Long.MAX_VALUE;
            
            //#line 107 . "x10/regionarray/RectRegion.x10"
            t$158093 = ((long) max$157227) == ((long) t$158094);
        }
        
        //#line 107 . "x10/regionarray/RectRegion.x10"
        long t$158096 =  0;
        
        //#line 107 . "x10/regionarray/RectRegion.x10"
        if (t$158093) {
            
            //#line 107 . "x10/regionarray/RectRegion.x10"
            t$158096 = -1L;
        } else {
            
            //#line 107 . "x10/regionarray/RectRegion.x10"
            final long t$158097 = ((max$157227) - (((long)(min$157226))));
            
            //#line 107 . "x10/regionarray/RectRegion.x10"
            t$158096 = ((t$158097) + (((long)(1L))));
        }
        
        //#line 107 . "x10/regionarray/RectRegion.x10"
        alloc$146099.size = t$158096;
        
        //#line 108 . "x10/regionarray/RectRegion.x10"
        alloc$146099.min0 = min$157226;
        
        //#line 109 . "x10/regionarray/RectRegion.x10"
        alloc$146099.max0 = max$157227;
        
        //#line 111 . "x10/regionarray/RectRegion.x10"
        final long t$158099 = alloc$146099.min3 = 0L;
        
        //#line 111 . "x10/regionarray/RectRegion.x10"
        final long t$158100 = alloc$146099.min2 = t$158099;
        
        //#line 111 . "x10/regionarray/RectRegion.x10"
        alloc$146099.min1 = t$158100;
        
        //#line 112 . "x10/regionarray/RectRegion.x10"
        final long t$158101 = alloc$146099.max3 = 0L;
        
        //#line 112 . "x10/regionarray/RectRegion.x10"
        final long t$158102 = alloc$146099.max2 = t$158101;
        
        //#line 112 . "x10/regionarray/RectRegion.x10"
        alloc$146099.max1 = t$158102;
        
        //#line 113 . "x10/regionarray/RectRegion.x10"
        alloc$146099.mins = null;
        
        //#line 114 . "x10/regionarray/RectRegion.x10"
        alloc$146099.maxs = null;
        
        //#line 378 "x10/regionarray/RectRegion.x10"
        return alloc$146099;
    }
    
    
    //#line 381 "x10/regionarray/RectRegion.x10"
    public x10.regionarray.Region eliminate(final long axis) {
        
        //#line 382 "x10/regionarray/RectRegion.x10"
        final long t$157842 = this.rank;
        
        //#line 382 "x10/regionarray/RectRegion.x10"
        final long k = ((t$157842) - (((long)(1L))));
        
        //#line 383 "x10/regionarray/RectRegion.x10"
        final x10.core.fun.Fun_0_1 t$157847 = ((x10.core.fun.Fun_0_1)(new x10.regionarray.RectRegion.$Closure$284(this, axis)));
        
        //#line 383 "x10/regionarray/RectRegion.x10"
        final x10.core.Rail newMin = ((x10.core.Rail)(new x10.core.Rail<x10.core.Long>(x10.rtt.Types.LONG, ((long)(k)), ((x10.core.fun.Fun_0_1)(t$157847)), (x10.core.Rail.__1$1x10$lang$Long$3x10$lang$Rail$$T$2) null)));
        
        //#line 384 "x10/regionarray/RectRegion.x10"
        final x10.core.fun.Fun_0_1 t$157852 = ((x10.core.fun.Fun_0_1)(new x10.regionarray.RectRegion.$Closure$285(this, axis)));
        
        //#line 384 "x10/regionarray/RectRegion.x10"
        final x10.core.Rail newMax = ((x10.core.Rail)(new x10.core.Rail<x10.core.Long>(x10.rtt.Types.LONG, ((long)(k)), ((x10.core.fun.Fun_0_1)(t$157852)), (x10.core.Rail.__1$1x10$lang$Long$3x10$lang$Rail$$T$2) null)));
        
        //#line 385 "x10/regionarray/RectRegion.x10"
        final x10.regionarray.RectRegion alloc$146100 = ((x10.regionarray.RectRegion)(new x10.regionarray.RectRegion((java.lang.System[]) null)));
        
        //#line 385 "x10/regionarray/RectRegion.x10"
        alloc$146100.x10$regionarray$RectRegion$$init$S(((x10.core.Rail)(newMin)), ((x10.core.Rail)(newMax)), (x10.regionarray.RectRegion.__0$1x10$lang$Long$2__1$1x10$lang$Long$2) null);
        
        //#line 385 "x10/regionarray/RectRegion.x10"
        return alloc$146100;
    }
    
    
    //#line 389 "x10/regionarray/RectRegion.x10"
    @x10.runtime.impl.java.X10Generated
    public static class RRIterator extends x10.core.Ref implements x10.lang.Iterator, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<RRIterator> $RTT = 
            x10.rtt.NamedType.<RRIterator> make("x10.regionarray.RectRegion.RRIterator",
                                                RRIterator.class,
                                                new x10.rtt.Type[] {
                                                    x10.rtt.ParameterizedType.make(x10.lang.Iterator.$RTT, x10.lang.Point.$RTT)
                                                });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static x10.serialization.X10JavaSerializable $_deserialize_body(x10.regionarray.RectRegion.RRIterator $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            $_obj.cur = $deserializer.readObject();
            $_obj.done = $deserializer.readBoolean();
            $_obj.max = $deserializer.readObject();
            $_obj.min = $deserializer.readObject();
            $_obj.myRank = $deserializer.readLong();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.regionarray.RectRegion.RRIterator $_obj = new x10.regionarray.RectRegion.RRIterator((java.lang.System[]) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            $serializer.write(this.cur);
            $serializer.write(this.done);
            $serializer.write(this.max);
            $serializer.write(this.min);
            $serializer.write(this.myRank);
            
        }
        
        // constructor just for allocation
        public RRIterator(final java.lang.System[] $dummy) {
            
        }
        
        // bridge for method abstract public x10.lang.Iterator[T].next(){}:T
        public x10.lang.Point next$G() {
            return next();
        }
        
        
        // properties
        
        //#line 389 "x10/regionarray/RectRegion.x10"
        public long myRank;
        
    
        
        //#line 390 "x10/regionarray/RectRegion.x10"
        public x10.core.fun.Fun_0_1<x10.core.Long,x10.core.Long> min;
        
        //#line 391 "x10/regionarray/RectRegion.x10"
        public x10.core.fun.Fun_0_1<x10.core.Long,x10.core.Long> max;
        
        //#line 392 "x10/regionarray/RectRegion.x10"
        public boolean done;
        
        //#line 393 "x10/regionarray/RectRegion.x10"
        public x10.core.Rail<x10.core.Long> cur;
        
        
        //#line 395 "x10/regionarray/RectRegion.x10"
        // creation method for java code (1-phase java constructor)
        public RRIterator(final x10.regionarray.RectRegion rr) {
            this((java.lang.System[]) null);
            x10$regionarray$RectRegion$RRIterator$$init$S(rr);
        }
        
        // constructor for non-virtual call
        final public x10.regionarray.RectRegion.RRIterator x10$regionarray$RectRegion$RRIterator$$init$S(final x10.regionarray.RectRegion rr) {
             {
                
                //#line 396 "x10/regionarray/RectRegion.x10"
                final long t$158103 = rr.rank;
                
                //#line 396 "x10/regionarray/RectRegion.x10"
                this.myRank = t$158103;
                
                
                //#line 389 "x10/regionarray/RectRegion.x10"
                final x10.regionarray.RectRegion.RRIterator this$158104 = this;
                
                //#line 389 "x10/regionarray/RectRegion.x10"
                this$158104.done = false;
                
                //#line 223 . "x10/regionarray/RectRegion.x10"
                x10.core.fun.Fun_0_1 ret$157239 =  null;
                
                //#line 223 . "x10/regionarray/RectRegion.x10"
                final x10.core.fun.Fun_0_1 t$158105 = ((x10.core.fun.Fun_0_1)(new x10.regionarray.RectRegion.RRIterator.$Closure$261(rr)));
                
                //#line 223 . "x10/regionarray/RectRegion.x10"
                ret$157239 = ((x10.core.fun.Fun_0_1)(t$158105));
                
                //#line 397 "x10/regionarray/RectRegion.x10"
                final x10.core.fun.Fun_0_1 t = ret$157239;
                
                //#line 398 "x10/regionarray/RectRegion.x10"
                this.min = ((x10.core.fun.Fun_0_1)(ret$157239));
                
                //#line 224 . "x10/regionarray/RectRegion.x10"
                x10.core.fun.Fun_0_1 ret$157242 =  null;
                
                //#line 224 . "x10/regionarray/RectRegion.x10"
                final x10.core.fun.Fun_0_1 t$158108 = ((x10.core.fun.Fun_0_1)(new x10.regionarray.RectRegion.RRIterator.$Closure$262(rr)));
                
                //#line 224 . "x10/regionarray/RectRegion.x10"
                ret$157242 = ((x10.core.fun.Fun_0_1)(t$158108));
                
                //#line 399 "x10/regionarray/RectRegion.x10"
                this.max = ((x10.core.fun.Fun_0_1)(ret$157242));
                
                //#line 400 "x10/regionarray/RectRegion.x10"
                final long t$157859 = rr.size;
                
                //#line 400 "x10/regionarray/RectRegion.x10"
                final boolean t$157860 = ((long) t$157859) == ((long) 0L);
                
                //#line 400 "x10/regionarray/RectRegion.x10"
                this.done = t$157860;
                
                //#line 401 "x10/regionarray/RectRegion.x10"
                final long t$157862 = this.myRank;
                
                //#line 401 "x10/regionarray/RectRegion.x10"
                final x10.core.fun.Fun_0_1 t$157863 = ((x10.core.fun.Fun_0_1)(new x10.regionarray.RectRegion.RRIterator.$Closure$263(t, (x10.regionarray.RectRegion.RRIterator.$Closure$263.__0$1x10$lang$Long$3x10$lang$Long$2) null)));
                
                //#line 401 "x10/regionarray/RectRegion.x10"
                final x10.core.Rail t$157864 = ((x10.core.Rail)(new x10.core.Rail<x10.core.Long>(x10.rtt.Types.LONG, ((long)(t$157862)), ((x10.core.fun.Fun_0_1)(t$157863)), (x10.core.Rail.__1$1x10$lang$Long$3x10$lang$Rail$$T$2) null)));
                
                //#line 401 "x10/regionarray/RectRegion.x10"
                this.cur = ((x10.core.Rail)(t$157864));
            }
            return this;
        }
        
        
        
        //#line 404 "x10/regionarray/RectRegion.x10"
        public boolean hasNext$O() {
            
            //#line 404 "x10/regionarray/RectRegion.x10"
            final boolean t$157865 = this.done;
            
            //#line 404 "x10/regionarray/RectRegion.x10"
            final boolean t$157866 = !(t$157865);
            
            //#line 404 "x10/regionarray/RectRegion.x10"
            return t$157866;
        }
        
        
        //#line 406 "x10/regionarray/RectRegion.x10"
        public x10.lang.Point next() {
            
            //#line 407 "x10/regionarray/RectRegion.x10"
            final x10.core.Rail t$157867 = ((x10.core.Rail)(this.cur));
            
            //#line 407 "x10/regionarray/RectRegion.x10"
            final x10.lang.Point ans = ((x10.lang.Point)(x10.lang.Point.make__0$1x10$lang$Long$2(((x10.core.Rail)(t$157867)))));
            
            //#line 408 "x10/regionarray/RectRegion.x10"
            final x10.core.Rail t$157869 = ((x10.core.Rail)(this.cur));
            
            //#line 408 "x10/regionarray/RectRegion.x10"
            final long t$157868 = this.myRank;
            
            //#line 408 "x10/regionarray/RectRegion.x10"
            final long t$157870 = ((t$157868) - (((long)(1L))));
            
            //#line 408 "x10/regionarray/RectRegion.x10"
            final long t$157874 = ((long[])t$157869.value)[(int)t$157870];
            
            //#line 408 "x10/regionarray/RectRegion.x10"
            final x10.core.fun.Fun_0_1 t$157872 = ((x10.core.fun.Fun_0_1)(this.max));
            
            //#line 408 "x10/regionarray/RectRegion.x10"
            final long t$157871 = this.myRank;
            
            //#line 408 "x10/regionarray/RectRegion.x10"
            final long t$157873 = ((t$157871) - (((long)(1L))));
            
            //#line 408 "x10/regionarray/RectRegion.x10"
            final long t$157875 = x10.core.Long.$unbox(((x10.core.fun.Fun_0_1<x10.core.Long,x10.core.Long>)t$157872).$apply(x10.core.Long.$box(t$157873), x10.rtt.Types.LONG));
            
            //#line 408 "x10/regionarray/RectRegion.x10"
            final boolean t$157916 = ((t$157874) < (((long)(t$157875))));
            
            //#line 408 "x10/regionarray/RectRegion.x10"
            if (t$157916) {
                
                //#line 409 "x10/regionarray/RectRegion.x10"
                final x10.core.Rail a$145795 = ((x10.core.Rail)(this.cur));
                
                //#line 409 "x10/regionarray/RectRegion.x10"
                final long t$157876 = this.myRank;
                
                //#line 409 "x10/regionarray/RectRegion.x10"
                final long i0$145796 = ((t$157876) - (((long)(1L))));
                
                //#line 409 "x10/regionarray/RectRegion.x10"
                final long t$157877 = ((long[])a$145795.value)[(int)i0$145796];
                
                //#line 409 "x10/regionarray/RectRegion.x10"
                final long r$145804 = ((t$157877) + (((long)(1L))));
                
                //#line 409 "x10/regionarray/RectRegion.x10"
                ((long[])a$145795.value)[(int)i0$145796] = r$145804;
            } else {
                
                //#line 411 "x10/regionarray/RectRegion.x10"
                final long t$157878 = this.myRank;
                
                //#line 411 "x10/regionarray/RectRegion.x10"
                final boolean t$157915 = ((long) t$157878) == ((long) 1L);
                
                //#line 411 "x10/regionarray/RectRegion.x10"
                if (t$157915) {
                    
                    //#line 412 "x10/regionarray/RectRegion.x10"
                    this.done = true;
                } else {
                    
                    //#line 415 "x10/regionarray/RectRegion.x10"
                    final x10.core.Rail t$157883 = ((x10.core.Rail)(this.cur));
                    
                    //#line 415 "x10/regionarray/RectRegion.x10"
                    final long t$157879 = this.myRank;
                    
                    //#line 415 "x10/regionarray/RectRegion.x10"
                    final long t$157884 = ((t$157879) - (((long)(1L))));
                    
                    //#line 415 "x10/regionarray/RectRegion.x10"
                    final x10.core.fun.Fun_0_1 t$157881 = ((x10.core.fun.Fun_0_1)(this.min));
                    
                    //#line 415 "x10/regionarray/RectRegion.x10"
                    final long t$157880 = this.myRank;
                    
                    //#line 415 "x10/regionarray/RectRegion.x10"
                    final long t$157882 = ((t$157880) - (((long)(1L))));
                    
                    //#line 415 "x10/regionarray/RectRegion.x10"
                    final long t$157885 = x10.core.Long.$unbox(((x10.core.fun.Fun_0_1<x10.core.Long,x10.core.Long>)t$157881).$apply(x10.core.Long.$box(t$157882), x10.rtt.Types.LONG));
                    
                    //#line 415 "x10/regionarray/RectRegion.x10"
                    ((long[])t$157883.value)[(int)t$157884] = t$157885;
                    
                    //#line 416 "x10/regionarray/RectRegion.x10"
                    final x10.core.Rail a$145828 = ((x10.core.Rail)(this.cur));
                    
                    //#line 416 "x10/regionarray/RectRegion.x10"
                    final long t$157886 = this.myRank;
                    
                    //#line 416 "x10/regionarray/RectRegion.x10"
                    final long i0$145829 = ((t$157886) - (((long)(2L))));
                    
                    //#line 416 "x10/regionarray/RectRegion.x10"
                    final long t$157887 = ((long[])a$145828.value)[(int)i0$145829];
                    
                    //#line 416 "x10/regionarray/RectRegion.x10"
                    final long r$145837 = ((t$157887) + (((long)(1L))));
                    
                    //#line 416 "x10/regionarray/RectRegion.x10"
                    ((long[])a$145828.value)[(int)i0$145829] = r$145837;
                    
                    //#line 417 "x10/regionarray/RectRegion.x10"
                    final long t$157888 = this.myRank;
                    
                    //#line 417 "x10/regionarray/RectRegion.x10"
                    long carryRank = ((t$157888) - (((long)(2L))));
                    
                    //#line 418 "x10/regionarray/RectRegion.x10"
                    while (true) {
                        
                        //#line 418 "x10/regionarray/RectRegion.x10"
                        boolean t$157896 = ((carryRank) > (((long)(0L))));
                        
                        //#line 418 "x10/regionarray/RectRegion.x10"
                        if (t$157896) {
                            
                            //#line 418 "x10/regionarray/RectRegion.x10"
                            final x10.core.Rail t$157890 = ((x10.core.Rail)(this.cur));
                            
                            //#line 418 "x10/regionarray/RectRegion.x10"
                            final long t$157894 = ((long[])t$157890.value)[(int)carryRank];
                            
                            //#line 418 "x10/regionarray/RectRegion.x10"
                            final x10.core.fun.Fun_0_1 t$157892 = ((x10.core.fun.Fun_0_1)(this.max));
                            
                            //#line 418 "x10/regionarray/RectRegion.x10"
                            final long t$157895 = x10.core.Long.$unbox(((x10.core.fun.Fun_0_1<x10.core.Long,x10.core.Long>)t$157892).$apply(x10.core.Long.$box(carryRank), x10.rtt.Types.LONG));
                            
                            //#line 418 "x10/regionarray/RectRegion.x10"
                            t$157896 = ((t$157894) > (((long)(t$157895))));
                        }
                        
                        //#line 418 "x10/regionarray/RectRegion.x10"
                        if (!(t$157896)) {
                            
                            //#line 418 "x10/regionarray/RectRegion.x10"
                            break;
                        }
                        
                        //#line 419 "x10/regionarray/RectRegion.x10"
                        final x10.core.Rail t$158111 = ((x10.core.Rail)(this.cur));
                        
                        //#line 419 "x10/regionarray/RectRegion.x10"
                        final x10.core.fun.Fun_0_1 t$158113 = ((x10.core.fun.Fun_0_1)(this.min));
                        
                        //#line 419 "x10/regionarray/RectRegion.x10"
                        final long t$158115 = x10.core.Long.$unbox(((x10.core.fun.Fun_0_1<x10.core.Long,x10.core.Long>)t$158113).$apply(x10.core.Long.$box(carryRank), x10.rtt.Types.LONG));
                        
                        //#line 419 "x10/regionarray/RectRegion.x10"
                        ((long[])t$158111.value)[(int)carryRank] = t$158115;
                        
                        //#line 420 "x10/regionarray/RectRegion.x10"
                        final x10.core.Rail a$158116 = ((x10.core.Rail)(this.cur));
                        
                        //#line 420 "x10/regionarray/RectRegion.x10"
                        final long t$158118 = ((long)(((int)(1))));
                        
                        //#line 420 "x10/regionarray/RectRegion.x10"
                        final long i$158119 = ((carryRank) - (((long)(t$158118))));
                        
                        //#line 420 "x10/regionarray/RectRegion.x10"
                        final long t$158120 = ((long[])a$158116.value)[(int)i$158119];
                        
                        //#line 420 "x10/regionarray/RectRegion.x10"
                        final long r$158121 = ((t$158120) + (((long)(1L))));
                        
                        //#line 420 "x10/regionarray/RectRegion.x10"
                        ((long[])a$158116.value)[(int)i$158119] = r$158121;
                        
                        //#line 421 "x10/regionarray/RectRegion.x10"
                        final long t$158123 = ((carryRank) - (((long)(1L))));
                        
                        //#line 421 "x10/regionarray/RectRegion.x10"
                        carryRank = t$158123;
                    }
                    
                    //#line 423 "x10/regionarray/RectRegion.x10"
                    boolean t$157913 = ((long) carryRank) == ((long) 0L);
                    
                    //#line 423 "x10/regionarray/RectRegion.x10"
                    if (t$157913) {
                        
                        //#line 423 "x10/regionarray/RectRegion.x10"
                        final x10.core.Rail t$157909 = ((x10.core.Rail)(this.cur));
                        
                        //#line 423 "x10/regionarray/RectRegion.x10"
                        final long t$157911 = ((long[])t$157909.value)[(int)0L];
                        
                        //#line 423 "x10/regionarray/RectRegion.x10"
                        final x10.core.fun.Fun_0_1 t$157910 = ((x10.core.fun.Fun_0_1)(this.max));
                        
                        //#line 423 "x10/regionarray/RectRegion.x10"
                        final long t$157912 = x10.core.Long.$unbox(((x10.core.fun.Fun_0_1<x10.core.Long,x10.core.Long>)t$157910).$apply(x10.core.Long.$box(0L), x10.rtt.Types.LONG));
                        
                        //#line 423 "x10/regionarray/RectRegion.x10"
                        t$157913 = ((t$157911) > (((long)(t$157912))));
                    }
                    
                    //#line 423 "x10/regionarray/RectRegion.x10"
                    if (t$157913) {
                        
                        //#line 424 "x10/regionarray/RectRegion.x10"
                        this.done = true;
                    }
                }
            }
            
            //#line 428 "x10/regionarray/RectRegion.x10"
            final x10.lang.Point t$145892 = ((x10.lang.Point)
                                              ans);
            
            //#line 428 "x10/regionarray/RectRegion.x10"
            final long t$157917 = t$145892.rank;
            
            //#line 428 "x10/regionarray/RectRegion.x10"
            final long t$157918 = x10.regionarray.RectRegion.RRIterator.this.myRank;
            
            //#line 428 "x10/regionarray/RectRegion.x10"
            final boolean t$157919 = ((long) t$157917) == ((long) t$157918);
            
            //#line 428 "x10/regionarray/RectRegion.x10"
            final boolean t$157921 = !(t$157919);
            
            //#line 428 "x10/regionarray/RectRegion.x10"
            if (t$157921) {
                
                //#line 428 "x10/regionarray/RectRegion.x10"
                final x10.lang.FailedDynamicCheckException t$157920 = new x10.lang.FailedDynamicCheckException("x10.lang.Point{self.rank==this(:x10.regionarray.RectRegion.RRIterator).myRank}");
                
                //#line 428 "x10/regionarray/RectRegion.x10"
                throw t$157920;
            }
            
            //#line 428 "x10/regionarray/RectRegion.x10"
            return t$145892;
        }
        
        
        //#line 389 "x10/regionarray/RectRegion.x10"
        final public x10.regionarray.RectRegion.RRIterator x10$regionarray$RectRegion$RRIterator$$this$x10$regionarray$RectRegion$RRIterator() {
            
            //#line 389 "x10/regionarray/RectRegion.x10"
            return x10.regionarray.RectRegion.RRIterator.this;
        }
        
        
        //#line 389 "x10/regionarray/RectRegion.x10"
        final public void __fieldInitializers_x10_regionarray_RectRegion_RRIterator() {
            
            //#line 389 "x10/regionarray/RectRegion.x10"
            this.done = false;
        }
        
        @x10.runtime.impl.java.X10Generated
        final public static class $Closure$261 extends x10.core.Ref implements x10.core.fun.Fun_0_1, x10.serialization.X10JavaSerializable
        {
            public static final x10.rtt.RuntimeType<$Closure$261> $RTT = 
                x10.rtt.StaticFunType.<$Closure$261> make($Closure$261.class,
                                                          new x10.rtt.Type[] {
                                                              x10.rtt.ParameterizedType.make(x10.core.fun.Fun_0_1.$RTT, x10.rtt.Types.LONG, x10.rtt.Types.LONG)
                                                          });
            
            public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
            
            public x10.rtt.Type<?> $getParam(int i) { return null; }
            
            private Object writeReplace() throws java.io.ObjectStreamException {
                return new x10.serialization.SerializationProxy(this);
            }
            
            public static x10.serialization.X10JavaSerializable $_deserialize_body(x10.regionarray.RectRegion.RRIterator.$Closure$261 $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
                $_obj.rr = $deserializer.readObject();
                return $_obj;
            }
            
            public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
                x10.regionarray.RectRegion.RRIterator.$Closure$261 $_obj = new x10.regionarray.RectRegion.RRIterator.$Closure$261((java.lang.System[]) null);
                $deserializer.record_reference($_obj);
                return $_deserialize_body($_obj, $deserializer);
            }
            
            public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
                $serializer.write(this.rr);
                
            }
            
            // constructor just for allocation
            public $Closure$261(final java.lang.System[] $dummy) {
                
            }
            
            // dispatcher for method abstract public (Z1)=>U.operator()(a1:Z1):U
            public java.lang.Object $apply(final java.lang.Object a1, final x10.rtt.Type t1) {
                return x10.core.Long.$box($apply$O(x10.core.Long.$unbox(a1)));
                
            }
            
            // dispatcher for method abstract public (Z1)=>U.operator()(a1:Z1):U
            public long $apply$J(final java.lang.Object a1, final x10.rtt.Type t1) {
                return $apply$O(x10.core.Long.$unbox(a1));
                
            }
            
            
        
            
            public long $apply$O(final long i$158106) {
                
                //#line 223 . "x10/regionarray/RectRegion.x10"
                final long t$158107 = this.rr.min$O((long)(i$158106));
                
                //#line 223 . "x10/regionarray/RectRegion.x10"
                return t$158107;
            }
            
            public x10.regionarray.RectRegion rr;
            
            public $Closure$261(final x10.regionarray.RectRegion rr) {
                 {
                    this.rr = rr;
                }
            }
            
        }
        
        @x10.runtime.impl.java.X10Generated
        final public static class $Closure$262 extends x10.core.Ref implements x10.core.fun.Fun_0_1, x10.serialization.X10JavaSerializable
        {
            public static final x10.rtt.RuntimeType<$Closure$262> $RTT = 
                x10.rtt.StaticFunType.<$Closure$262> make($Closure$262.class,
                                                          new x10.rtt.Type[] {
                                                              x10.rtt.ParameterizedType.make(x10.core.fun.Fun_0_1.$RTT, x10.rtt.Types.LONG, x10.rtt.Types.LONG)
                                                          });
            
            public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
            
            public x10.rtt.Type<?> $getParam(int i) { return null; }
            
            private Object writeReplace() throws java.io.ObjectStreamException {
                return new x10.serialization.SerializationProxy(this);
            }
            
            public static x10.serialization.X10JavaSerializable $_deserialize_body(x10.regionarray.RectRegion.RRIterator.$Closure$262 $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
                $_obj.rr = $deserializer.readObject();
                return $_obj;
            }
            
            public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
                x10.regionarray.RectRegion.RRIterator.$Closure$262 $_obj = new x10.regionarray.RectRegion.RRIterator.$Closure$262((java.lang.System[]) null);
                $deserializer.record_reference($_obj);
                return $_deserialize_body($_obj, $deserializer);
            }
            
            public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
                $serializer.write(this.rr);
                
            }
            
            // constructor just for allocation
            public $Closure$262(final java.lang.System[] $dummy) {
                
            }
            
            // dispatcher for method abstract public (Z1)=>U.operator()(a1:Z1):U
            public java.lang.Object $apply(final java.lang.Object a1, final x10.rtt.Type t1) {
                return x10.core.Long.$box($apply$O(x10.core.Long.$unbox(a1)));
                
            }
            
            // dispatcher for method abstract public (Z1)=>U.operator()(a1:Z1):U
            public long $apply$J(final java.lang.Object a1, final x10.rtt.Type t1) {
                return $apply$O(x10.core.Long.$unbox(a1));
                
            }
            
            
        
            
            public long $apply$O(final long i$158109) {
                
                //#line 224 . "x10/regionarray/RectRegion.x10"
                final long t$158110 = this.rr.max$O((long)(i$158109));
                
                //#line 224 . "x10/regionarray/RectRegion.x10"
                return t$158110;
            }
            
            public x10.regionarray.RectRegion rr;
            
            public $Closure$262(final x10.regionarray.RectRegion rr) {
                 {
                    this.rr = rr;
                }
            }
            
        }
        
        @x10.runtime.impl.java.X10Generated
        final public static class $Closure$263 extends x10.core.Ref implements x10.core.fun.Fun_0_1, x10.serialization.X10JavaSerializable
        {
            public static final x10.rtt.RuntimeType<$Closure$263> $RTT = 
                x10.rtt.StaticFunType.<$Closure$263> make($Closure$263.class,
                                                          new x10.rtt.Type[] {
                                                              x10.rtt.ParameterizedType.make(x10.core.fun.Fun_0_1.$RTT, x10.rtt.Types.LONG, x10.rtt.Types.LONG)
                                                          });
            
            public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
            
            public x10.rtt.Type<?> $getParam(int i) { return null; }
            
            private Object writeReplace() throws java.io.ObjectStreamException {
                return new x10.serialization.SerializationProxy(this);
            }
            
            public static x10.serialization.X10JavaSerializable $_deserialize_body(x10.regionarray.RectRegion.RRIterator.$Closure$263 $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
                $_obj.t = $deserializer.readObject();
                return $_obj;
            }
            
            public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
                x10.regionarray.RectRegion.RRIterator.$Closure$263 $_obj = new x10.regionarray.RectRegion.RRIterator.$Closure$263((java.lang.System[]) null);
                $deserializer.record_reference($_obj);
                return $_deserialize_body($_obj, $deserializer);
            }
            
            public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
                $serializer.write(this.t);
                
            }
            
            // constructor just for allocation
            public $Closure$263(final java.lang.System[] $dummy) {
                
            }
            
            // dispatcher for method abstract public (Z1)=>U.operator()(a1:Z1):U
            public java.lang.Object $apply(final java.lang.Object a1, final x10.rtt.Type t1) {
                return x10.core.Long.$box($apply$O(x10.core.Long.$unbox(a1)));
                
            }
            
            // dispatcher for method abstract public (Z1)=>U.operator()(a1:Z1):U
            public long $apply$J(final java.lang.Object a1, final x10.rtt.Type t1) {
                return $apply$O(x10.core.Long.$unbox(a1));
                
            }
            
            // synthetic type for parameter mangling
            public static final class __0$1x10$lang$Long$3x10$lang$Long$2 {}
            
        
            
            public long $apply$O(final long l) {
                
                //#line 401 "x10/regionarray/RectRegion.x10"
                final long t$157861 = x10.core.Long.$unbox(((x10.core.fun.Fun_0_1<x10.core.Long,x10.core.Long>)this.t).$apply(x10.core.Long.$box(l), x10.rtt.Types.LONG));
                
                //#line 401 "x10/regionarray/RectRegion.x10"
                return t$157861;
            }
            
            public x10.core.fun.Fun_0_1<x10.core.Long,x10.core.Long> t;
            
            public $Closure$263(final x10.core.fun.Fun_0_1<x10.core.Long,x10.core.Long> t, __0$1x10$lang$Long$3x10$lang$Long$2 $dummy) {
                 {
                    this.t = ((x10.core.fun.Fun_0_1)(t));
                }
            }
            
        }
        
    }
    
    
    
    //#line 431 "x10/regionarray/RectRegion.x10"
    public x10.lang.Iterator iterator() {
        
        //#line 432 "x10/regionarray/RectRegion.x10"
        final x10.regionarray.RectRegion.RRIterator alloc$146101 = ((x10.regionarray.RectRegion.RRIterator)(new x10.regionarray.RectRegion.RRIterator((java.lang.System[]) null)));
        
        //#line 432 "x10/regionarray/RectRegion.x10"
        alloc$146101.x10$regionarray$RectRegion$RRIterator$$init$S(((x10.regionarray.RectRegion)(this)));
        
        //#line 432 "x10/regionarray/RectRegion.x10"
        return alloc$146101;
    }
    
    
    //#line 436 "x10/regionarray/RectRegion.x10"
    public boolean equals(final java.lang.Object thatObj) {
        
        //#line 437 "x10/regionarray/RectRegion.x10"
        final boolean t$157922 = x10.rtt.Equality.equalsequals((this),(thatObj));
        
        //#line 437 "x10/regionarray/RectRegion.x10"
        if (t$157922) {
            
            //#line 437 "x10/regionarray/RectRegion.x10"
            return true;
        }
        
        //#line 438 "x10/regionarray/RectRegion.x10"
        final boolean t$157923 = x10.regionarray.Region.$RTT.isInstance(thatObj);
        
        //#line 438 "x10/regionarray/RectRegion.x10"
        final boolean t$157924 = !(t$157923);
        
        //#line 438 "x10/regionarray/RectRegion.x10"
        if (t$157924) {
            
            //#line 438 "x10/regionarray/RectRegion.x10"
            return false;
        }
        
        //#line 439 "x10/regionarray/RectRegion.x10"
        final x10.regionarray.Region that = x10.rtt.Types.<x10.regionarray.Region> cast(thatObj,x10.regionarray.Region.$RTT);
        
        //#line 442 "x10/regionarray/RectRegion.x10"
        final boolean t$157925 = x10.regionarray.RectRegion.$RTT.isInstance(that);
        
        //#line 442 "x10/regionarray/RectRegion.x10"
        final boolean t$157927 = !(t$157925);
        
        //#line 442 "x10/regionarray/RectRegion.x10"
        if (t$157927) {
            
            //#line 443 "x10/regionarray/RectRegion.x10"
            final boolean t$157926 = super.equals(((java.lang.Object)(that)));
            
            //#line 443 "x10/regionarray/RectRegion.x10"
            return t$157926;
        }
        
        //#line 446 "x10/regionarray/RectRegion.x10"
        final long t$157928 = this.rank;
        
        //#line 446 "x10/regionarray/RectRegion.x10"
        final long t$157929 = that.rank;
        
        //#line 446 "x10/regionarray/RectRegion.x10"
        final boolean t$157930 = ((long) t$157928) != ((long) t$157929);
        
        //#line 446 "x10/regionarray/RectRegion.x10"
        if (t$157930) {
            
            //#line 447 "x10/regionarray/RectRegion.x10"
            return false;
        }
        
        //#line 450 "x10/regionarray/RectRegion.x10"
        final x10.regionarray.RectRegion this$157245 = ((x10.regionarray.RectRegion)(this));
        
        //#line 223 . "x10/regionarray/RectRegion.x10"
        x10.core.fun.Fun_0_1 ret$157246 =  null;
        
        //#line 223 . "x10/regionarray/RectRegion.x10"
        final x10.core.fun.Fun_0_1 t$158136 = ((x10.core.fun.Fun_0_1)(new x10.regionarray.RectRegion.$Closure$286(this$157245)));
        
        //#line 223 . "x10/regionarray/RectRegion.x10"
        ret$157246 = ((x10.core.fun.Fun_0_1)(t$158136));
        
        //#line 450 "x10/regionarray/RectRegion.x10"
        final x10.core.fun.Fun_0_1 thisMin = ret$157246;
        
        //#line 451 "x10/regionarray/RectRegion.x10"
        final x10.regionarray.RectRegion this$157249 = ((x10.regionarray.RectRegion)(this));
        
        //#line 224 . "x10/regionarray/RectRegion.x10"
        x10.core.fun.Fun_0_1 ret$157250 =  null;
        
        //#line 224 . "x10/regionarray/RectRegion.x10"
        final x10.core.fun.Fun_0_1 t$158139 = ((x10.core.fun.Fun_0_1)(new x10.regionarray.RectRegion.$Closure$287(this$157249)));
        
        //#line 224 . "x10/regionarray/RectRegion.x10"
        ret$157250 = ((x10.core.fun.Fun_0_1)(t$158139));
        
        //#line 451 "x10/regionarray/RectRegion.x10"
        final x10.core.fun.Fun_0_1 thisMax = ret$157250;
        
        //#line 452 "x10/regionarray/RectRegion.x10"
        final x10.regionarray.RectRegion this$157253 = ((x10.regionarray.RectRegion)(x10.rtt.Types.<x10.regionarray.RectRegion> cast(that,x10.regionarray.RectRegion.$RTT)));
        
        //#line 223 . "x10/regionarray/RectRegion.x10"
        x10.core.fun.Fun_0_1 ret$157254 =  null;
        
        //#line 223 . "x10/regionarray/RectRegion.x10"
        final x10.core.fun.Fun_0_1 t$158142 = ((x10.core.fun.Fun_0_1)(new x10.regionarray.RectRegion.$Closure$288(this$157253)));
        
        //#line 223 . "x10/regionarray/RectRegion.x10"
        ret$157254 = ((x10.core.fun.Fun_0_1)(t$158142));
        
        //#line 452 "x10/regionarray/RectRegion.x10"
        final x10.core.fun.Fun_0_1 thatMin = ret$157254;
        
        //#line 453 "x10/regionarray/RectRegion.x10"
        final x10.regionarray.RectRegion this$157257 = ((x10.regionarray.RectRegion)(x10.rtt.Types.<x10.regionarray.RectRegion> cast(that,x10.regionarray.RectRegion.$RTT)));
        
        //#line 224 . "x10/regionarray/RectRegion.x10"
        x10.core.fun.Fun_0_1 ret$157258 =  null;
        
        //#line 224 . "x10/regionarray/RectRegion.x10"
        final x10.core.fun.Fun_0_1 t$158145 = ((x10.core.fun.Fun_0_1)(new x10.regionarray.RectRegion.$Closure$289(this$157257)));
        
        //#line 224 . "x10/regionarray/RectRegion.x10"
        ret$157258 = ((x10.core.fun.Fun_0_1)(t$158145));
        
        //#line 456 "x10/regionarray/RectRegion.x10"
        final long t$158148 = this.rank;
        
        //#line 456 "x10/regionarray/RectRegion.x10"
        final long i$146213max$158149 = ((t$158148) - (((long)(1L))));
        
        //#line 456 "x10/regionarray/RectRegion.x10"
        long i$158133 = 0L;
        
        //#line 456 "x10/regionarray/RectRegion.x10"
        for (;
             true;
             ) {
            
            //#line 456 "x10/regionarray/RectRegion.x10"
            final boolean t$158135 = ((i$158133) <= (((long)(i$146213max$158149))));
            
            //#line 456 "x10/regionarray/RectRegion.x10"
            if (!(t$158135)) {
                
                //#line 456 "x10/regionarray/RectRegion.x10"
                break;
            }
            
            //#line 457 "x10/regionarray/RectRegion.x10"
            final long t$158124 = x10.core.Long.$unbox(((x10.core.fun.Fun_0_1<x10.core.Long,x10.core.Long>)thisMin).$apply(x10.core.Long.$box(i$158133), x10.rtt.Types.LONG));
            
            //#line 457 "x10/regionarray/RectRegion.x10"
            final long t$158125 = x10.core.Long.$unbox(((x10.core.fun.Fun_0_1<x10.core.Long,x10.core.Long>)thatMin).$apply(x10.core.Long.$box(i$158133), x10.rtt.Types.LONG));
            
            //#line 457 "x10/regionarray/RectRegion.x10"
            boolean t$158126 = ((long) t$158124) != ((long) t$158125);
            
            //#line 457 "x10/regionarray/RectRegion.x10"
            if (!(t$158126)) {
                
                //#line 457 "x10/regionarray/RectRegion.x10"
                final long t$158127 = x10.core.Long.$unbox(((x10.core.fun.Fun_0_1<x10.core.Long,x10.core.Long>)thisMax).$apply(x10.core.Long.$box(i$158133), x10.rtt.Types.LONG));
                
                //#line 457 "x10/regionarray/RectRegion.x10"
                final long t$158128 = x10.core.Long.$unbox(((x10.core.fun.Fun_0_1<x10.core.Long,x10.core.Long>)ret$157258).$apply(x10.core.Long.$box(i$158133), x10.rtt.Types.LONG));
                
                //#line 457 "x10/regionarray/RectRegion.x10"
                t$158126 = ((long) t$158127) != ((long) t$158128);
            }
            
            //#line 457 "x10/regionarray/RectRegion.x10"
            if (t$158126) {
                
                //#line 458 "x10/regionarray/RectRegion.x10"
                return false;
            }
            
            //#line 456 "x10/regionarray/RectRegion.x10"
            final long t$158132 = ((i$158133) + (((long)(1L))));
            
            //#line 456 "x10/regionarray/RectRegion.x10"
            i$158133 = t$158132;
        }
        
        //#line 460 "x10/regionarray/RectRegion.x10"
        return true;
    }
    
    
    //#line 463 "x10/regionarray/RectRegion.x10"
    public java.lang.String toString() {
        
        //#line 464 "x10/regionarray/RectRegion.x10"
        final x10.regionarray.RectRegion this$157261 = ((x10.regionarray.RectRegion)(this));
        
        //#line 223 . "x10/regionarray/RectRegion.x10"
        x10.core.fun.Fun_0_1 ret$157262 =  null;
        
        //#line 223 . "x10/regionarray/RectRegion.x10"
        final x10.core.fun.Fun_0_1 t$158166 = ((x10.core.fun.Fun_0_1)(new x10.regionarray.RectRegion.$Closure$290(this$157261)));
        
        //#line 223 . "x10/regionarray/RectRegion.x10"
        ret$157262 = ((x10.core.fun.Fun_0_1)(t$158166));
        
        //#line 464 "x10/regionarray/RectRegion.x10"
        final x10.core.fun.Fun_0_1 thisMin = ret$157262;
        
        //#line 465 "x10/regionarray/RectRegion.x10"
        final x10.regionarray.RectRegion this$157265 = ((x10.regionarray.RectRegion)(this));
        
        //#line 224 . "x10/regionarray/RectRegion.x10"
        x10.core.fun.Fun_0_1 ret$157266 =  null;
        
        //#line 224 . "x10/regionarray/RectRegion.x10"
        final x10.core.fun.Fun_0_1 t$158169 = ((x10.core.fun.Fun_0_1)(new x10.regionarray.RectRegion.$Closure$291(this$157265)));
        
        //#line 224 . "x10/regionarray/RectRegion.x10"
        ret$157266 = ((x10.core.fun.Fun_0_1)(t$158169));
        
        //#line 466 "x10/regionarray/RectRegion.x10"
        java.lang.String s = "[";
        
        //#line 467 "x10/regionarray/RectRegion.x10"
        final long t$158172 = this.rank;
        
        //#line 467 "x10/regionarray/RectRegion.x10"
        final long i$146231max$158173 = ((t$158172) - (((long)(1L))));
        
        //#line 467 "x10/regionarray/RectRegion.x10"
        long i$158163 = 0L;
        
        //#line 467 "x10/regionarray/RectRegion.x10"
        for (;
             true;
             ) {
            
            //#line 467 "x10/regionarray/RectRegion.x10"
            final boolean t$158165 = ((i$158163) <= (((long)(i$146231max$158173))));
            
            //#line 467 "x10/regionarray/RectRegion.x10"
            if (!(t$158165)) {
                
                //#line 467 "x10/regionarray/RectRegion.x10"
                break;
            }
            
            //#line 468 "x10/regionarray/RectRegion.x10"
            final boolean t$158150 = ((i$158163) > (((long)(0L))));
            
            //#line 468 "x10/regionarray/RectRegion.x10"
            if (t$158150) {
                
                //#line 468 "x10/regionarray/RectRegion.x10"
                final java.lang.String t$158152 = ((s) + (","));
                
                //#line 468 "x10/regionarray/RectRegion.x10"
                s = ((java.lang.String)(t$158152));
            }
            
            //#line 469 "x10/regionarray/RectRegion.x10"
            final long t$158154 = x10.core.Long.$unbox(((x10.core.fun.Fun_0_1<x10.core.Long,x10.core.Long>)thisMin).$apply(x10.core.Long.$box(i$158163), x10.rtt.Types.LONG));
            
            //#line 469 "x10/regionarray/RectRegion.x10"
            final java.lang.String t$158155 = (("") + ((x10.core.Long.$box(t$158154))));
            
            //#line 469 "x10/regionarray/RectRegion.x10"
            final java.lang.String t$158156 = ((t$158155) + (".."));
            
            //#line 469 "x10/regionarray/RectRegion.x10"
            final long t$158157 = x10.core.Long.$unbox(((x10.core.fun.Fun_0_1<x10.core.Long,x10.core.Long>)ret$157266).$apply(x10.core.Long.$box(i$158163), x10.rtt.Types.LONG));
            
            //#line 469 "x10/regionarray/RectRegion.x10"
            final java.lang.String t$158158 = ((t$158156) + ((x10.core.Long.$box(t$158157))));
            
            //#line 469 "x10/regionarray/RectRegion.x10"
            final java.lang.String t$158159 = ((s) + (t$158158));
            
            //#line 469 "x10/regionarray/RectRegion.x10"
            s = ((java.lang.String)(t$158159));
            
            //#line 467 "x10/regionarray/RectRegion.x10"
            final long t$158162 = ((i$158163) + (((long)(1L))));
            
            //#line 467 "x10/regionarray/RectRegion.x10"
            i$158163 = t$158162;
        }
        
        //#line 471 "x10/regionarray/RectRegion.x10"
        final java.lang.String t$157972 = ((s) + ("]"));
        
        //#line 471 "x10/regionarray/RectRegion.x10"
        s = ((java.lang.String)(t$157972));
        
        //#line 472 "x10/regionarray/RectRegion.x10"
        return s;
    }
    
    
    //#line 21 "x10/regionarray/RectRegion.x10"
    final public x10.regionarray.RectRegion x10$regionarray$RectRegion$$this$x10$regionarray$RectRegion() {
        
        //#line 21 "x10/regionarray/RectRegion.x10"
        return x10.regionarray.RectRegion.this;
    }
    
    
    //#line 21 "x10/regionarray/RectRegion.x10"
    final public void __fieldInitializers_x10_regionarray_RectRegion() {
        
        //#line 21 "x10/regionarray/RectRegion.x10"
        this.polyRep = null;
    }
    
    @x10.runtime.impl.java.X10Generated
    final public static class $Closure$264 extends x10.core.Ref implements x10.core.fun.Fun_0_1, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<$Closure$264> $RTT = 
            x10.rtt.StaticFunType.<$Closure$264> make($Closure$264.class,
                                                      new x10.rtt.Type[] {
                                                          x10.rtt.ParameterizedType.make(x10.core.fun.Fun_0_1.$RTT, x10.rtt.Types.LONG, x10.rtt.Types.LONG)
                                                      });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static x10.serialization.X10JavaSerializable $_deserialize_body(x10.regionarray.RectRegion.$Closure$264 $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            $_obj.out$$ = $deserializer.readObject();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.regionarray.RectRegion.$Closure$264 $_obj = new x10.regionarray.RectRegion.$Closure$264((java.lang.System[]) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            $serializer.write(this.out$$);
            
        }
        
        // constructor just for allocation
        public $Closure$264(final java.lang.System[] $dummy) {
            
        }
        
        // dispatcher for method abstract public (Z1)=>U.operator()(a1:Z1):U
        public java.lang.Object $apply(final java.lang.Object a1, final x10.rtt.Type t1) {
            return x10.core.Long.$box($apply$O(x10.core.Long.$unbox(a1)));
            
        }
        
        // dispatcher for method abstract public (Z1)=>U.operator()(a1:Z1):U
        public long $apply$J(final java.lang.Object a1, final x10.rtt.Type t1) {
            return $apply$O(x10.core.Long.$unbox(a1));
            
        }
        
        
    
        
        public long $apply$O(final long i) {
            
            //#line 223 "x10/regionarray/RectRegion.x10"
            final long t$157529 = this.out$$.min$O((long)(i));
            
            //#line 223 "x10/regionarray/RectRegion.x10"
            return t$157529;
        }
        
        public x10.regionarray.RectRegion out$$;
        
        public $Closure$264(final x10.regionarray.RectRegion out$$) {
             {
                this.out$$ = out$$;
            }
        }
        
    }
    
    @x10.runtime.impl.java.X10Generated
    final public static class $Closure$265 extends x10.core.Ref implements x10.core.fun.Fun_0_1, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<$Closure$265> $RTT = 
            x10.rtt.StaticFunType.<$Closure$265> make($Closure$265.class,
                                                      new x10.rtt.Type[] {
                                                          x10.rtt.ParameterizedType.make(x10.core.fun.Fun_0_1.$RTT, x10.rtt.Types.LONG, x10.rtt.Types.LONG)
                                                      });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static x10.serialization.X10JavaSerializable $_deserialize_body(x10.regionarray.RectRegion.$Closure$265 $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            $_obj.out$$ = $deserializer.readObject();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.regionarray.RectRegion.$Closure$265 $_obj = new x10.regionarray.RectRegion.$Closure$265((java.lang.System[]) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            $serializer.write(this.out$$);
            
        }
        
        // constructor just for allocation
        public $Closure$265(final java.lang.System[] $dummy) {
            
        }
        
        // dispatcher for method abstract public (Z1)=>U.operator()(a1:Z1):U
        public java.lang.Object $apply(final java.lang.Object a1, final x10.rtt.Type t1) {
            return x10.core.Long.$box($apply$O(x10.core.Long.$unbox(a1)));
            
        }
        
        // dispatcher for method abstract public (Z1)=>U.operator()(a1:Z1):U
        public long $apply$J(final java.lang.Object a1, final x10.rtt.Type t1) {
            return $apply$O(x10.core.Long.$unbox(a1));
            
        }
        
        
    
        
        public long $apply$O(final long i) {
            
            //#line 224 "x10/regionarray/RectRegion.x10"
            final long t$157531 = this.out$$.max$O((long)(i));
            
            //#line 224 "x10/regionarray/RectRegion.x10"
            return t$157531;
        }
        
        public x10.regionarray.RectRegion out$$;
        
        public $Closure$265(final x10.regionarray.RectRegion out$$) {
             {
                this.out$$ = out$$;
            }
        }
        
    }
    
    @x10.runtime.impl.java.X10Generated
    final public static class $Closure$266 extends x10.core.Ref implements x10.core.fun.Fun_0_1, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<$Closure$266> $RTT = 
            x10.rtt.StaticFunType.<$Closure$266> make($Closure$266.class,
                                                      new x10.rtt.Type[] {
                                                          x10.rtt.ParameterizedType.make(x10.core.fun.Fun_0_1.$RTT, x10.rtt.Types.LONG, x10.rtt.Types.LONG)
                                                      });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static x10.serialization.X10JavaSerializable $_deserialize_body(x10.regionarray.RectRegion.$Closure$266 $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            $_obj.this$157191 = $deserializer.readObject();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.regionarray.RectRegion.$Closure$266 $_obj = new x10.regionarray.RectRegion.$Closure$266((java.lang.System[]) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            $serializer.write(this.this$157191);
            
        }
        
        // constructor just for allocation
        public $Closure$266(final java.lang.System[] $dummy) {
            
        }
        
        // dispatcher for method abstract public (Z1)=>U.operator()(a1:Z1):U
        public java.lang.Object $apply(final java.lang.Object a1, final x10.rtt.Type t1) {
            return x10.core.Long.$box($apply$O(x10.core.Long.$unbox(a1)));
            
        }
        
        // dispatcher for method abstract public (Z1)=>U.operator()(a1:Z1):U
        public long $apply$J(final java.lang.Object a1, final x10.rtt.Type t1) {
            return $apply$O(x10.core.Long.$unbox(a1));
            
        }
        
        
    
        
        public long $apply$O(final long i$158043) {
            
            //#line 223 . "x10/regionarray/RectRegion.x10"
            final long t$158044 = this.this$157191.min$O((long)(i$158043));
            
            //#line 223 . "x10/regionarray/RectRegion.x10"
            return t$158044;
        }
        
        public x10.regionarray.RectRegion this$157191;
        
        public $Closure$266(final x10.regionarray.RectRegion this$157191) {
             {
                this.this$157191 = ((x10.regionarray.RectRegion)(this$157191));
            }
        }
        
    }
    
    @x10.runtime.impl.java.X10Generated
    final public static class $Closure$267 extends x10.core.Ref implements x10.core.fun.Fun_0_1, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<$Closure$267> $RTT = 
            x10.rtt.StaticFunType.<$Closure$267> make($Closure$267.class,
                                                      new x10.rtt.Type[] {
                                                          x10.rtt.ParameterizedType.make(x10.core.fun.Fun_0_1.$RTT, x10.rtt.Types.LONG, x10.rtt.Types.LONG)
                                                      });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static x10.serialization.X10JavaSerializable $_deserialize_body(x10.regionarray.RectRegion.$Closure$267 $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            $_obj.this$157195 = $deserializer.readObject();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.regionarray.RectRegion.$Closure$267 $_obj = new x10.regionarray.RectRegion.$Closure$267((java.lang.System[]) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            $serializer.write(this.this$157195);
            
        }
        
        // constructor just for allocation
        public $Closure$267(final java.lang.System[] $dummy) {
            
        }
        
        // dispatcher for method abstract public (Z1)=>U.operator()(a1:Z1):U
        public java.lang.Object $apply(final java.lang.Object a1, final x10.rtt.Type t1) {
            return x10.core.Long.$box($apply$O(x10.core.Long.$unbox(a1)));
            
        }
        
        // dispatcher for method abstract public (Z1)=>U.operator()(a1:Z1):U
        public long $apply$J(final java.lang.Object a1, final x10.rtt.Type t1) {
            return $apply$O(x10.core.Long.$unbox(a1));
            
        }
        
        
    
        
        public long $apply$O(final long i$158046) {
            
            //#line 224 . "x10/regionarray/RectRegion.x10"
            final long t$158047 = this.this$157195.max$O((long)(i$158046));
            
            //#line 224 . "x10/regionarray/RectRegion.x10"
            return t$158047;
        }
        
        public x10.regionarray.RectRegion this$157195;
        
        public $Closure$267(final x10.regionarray.RectRegion this$157195) {
             {
                this.this$157195 = ((x10.regionarray.RectRegion)(this$157195));
            }
        }
        
    }
    
    @x10.runtime.impl.java.X10Generated
    final public static class $Closure$268 extends x10.core.Ref implements x10.core.fun.Fun_0_1, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<$Closure$268> $RTT = 
            x10.rtt.StaticFunType.<$Closure$268> make($Closure$268.class,
                                                      new x10.rtt.Type[] {
                                                          x10.rtt.ParameterizedType.make(x10.core.fun.Fun_0_1.$RTT, x10.rtt.Types.LONG, x10.rtt.Types.LONG)
                                                      });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static x10.serialization.X10JavaSerializable $_deserialize_body(x10.regionarray.RectRegion.$Closure$268 $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            $_obj.out$$ = $deserializer.readObject();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.regionarray.RectRegion.$Closure$268 $_obj = new x10.regionarray.RectRegion.$Closure$268((java.lang.System[]) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            $serializer.write(this.out$$);
            
        }
        
        // constructor just for allocation
        public $Closure$268(final java.lang.System[] $dummy) {
            
        }
        
        // dispatcher for method abstract public (Z1)=>U.operator()(a1:Z1):U
        public java.lang.Object $apply(final java.lang.Object a1, final x10.rtt.Type t1) {
            return x10.core.Long.$box($apply$O(x10.core.Long.$unbox(a1)));
            
        }
        
        // dispatcher for method abstract public (Z1)=>U.operator()(a1:Z1):U
        public long $apply$J(final java.lang.Object a1, final x10.rtt.Type t1) {
            return $apply$O(x10.core.Long.$unbox(a1));
            
        }
        
        
    
        
        public long $apply$O(final long i) {
            
            //#line 310 "x10/regionarray/RectRegion.x10"
            final long t$157685 = this.out$$.min$O((long)(i));
            
            //#line 310 "x10/regionarray/RectRegion.x10"
            return t$157685;
        }
        
        public x10.regionarray.RectRegion out$$;
        
        public $Closure$268(final x10.regionarray.RectRegion out$$) {
             {
                this.out$$ = out$$;
            }
        }
        
    }
    
    @x10.runtime.impl.java.X10Generated
    final public static class $Closure$269 extends x10.core.Ref implements x10.core.fun.Fun_0_1, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<$Closure$269> $RTT = 
            x10.rtt.StaticFunType.<$Closure$269> make($Closure$269.class,
                                                      new x10.rtt.Type[] {
                                                          x10.rtt.ParameterizedType.make(x10.core.fun.Fun_0_1.$RTT, x10.rtt.Types.LONG, x10.rtt.Types.LONG)
                                                      });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static x10.serialization.X10JavaSerializable $_deserialize_body(x10.regionarray.RectRegion.$Closure$269 $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            $_obj.out$$ = $deserializer.readObject();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.regionarray.RectRegion.$Closure$269 $_obj = new x10.regionarray.RectRegion.$Closure$269((java.lang.System[]) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            $serializer.write(this.out$$);
            
        }
        
        // constructor just for allocation
        public $Closure$269(final java.lang.System[] $dummy) {
            
        }
        
        // dispatcher for method abstract public (Z1)=>U.operator()(a1:Z1):U
        public java.lang.Object $apply(final java.lang.Object a1, final x10.rtt.Type t1) {
            return x10.core.Long.$box($apply$O(x10.core.Long.$unbox(a1)));
            
        }
        
        // dispatcher for method abstract public (Z1)=>U.operator()(a1:Z1):U
        public long $apply$J(final java.lang.Object a1, final x10.rtt.Type t1) {
            return $apply$O(x10.core.Long.$unbox(a1));
            
        }
        
        
    
        
        public long $apply$O(final long i) {
            
            //#line 311 "x10/regionarray/RectRegion.x10"
            final long t$157688 = this.out$$.max$O((long)(i));
            
            //#line 311 "x10/regionarray/RectRegion.x10"
            return t$157688;
        }
        
        public x10.regionarray.RectRegion out$$;
        
        public $Closure$269(final x10.regionarray.RectRegion out$$) {
             {
                this.out$$ = out$$;
            }
        }
        
    }
    
    @x10.runtime.impl.java.X10Generated
    final public static class $Closure$270 extends x10.core.Ref implements x10.core.fun.Fun_0_1, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<$Closure$270> $RTT = 
            x10.rtt.StaticFunType.<$Closure$270> make($Closure$270.class,
                                                      new x10.rtt.Type[] {
                                                          x10.rtt.ParameterizedType.make(x10.core.fun.Fun_0_1.$RTT, x10.rtt.Types.LONG, x10.rtt.Types.LONG)
                                                      });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static x10.serialization.X10JavaSerializable $_deserialize_body(x10.regionarray.RectRegion.$Closure$270 $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            $_obj.this$157202 = $deserializer.readObject();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.regionarray.RectRegion.$Closure$270 $_obj = new x10.regionarray.RectRegion.$Closure$270((java.lang.System[]) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            $serializer.write(this.this$157202);
            
        }
        
        // constructor just for allocation
        public $Closure$270(final java.lang.System[] $dummy) {
            
        }
        
        // dispatcher for method abstract public (Z1)=>U.operator()(a1:Z1):U
        public java.lang.Object $apply(final java.lang.Object a1, final x10.rtt.Type t1) {
            return x10.core.Long.$box($apply$O(x10.core.Long.$unbox(a1)));
            
        }
        
        // dispatcher for method abstract public (Z1)=>U.operator()(a1:Z1):U
        public long $apply$J(final java.lang.Object a1, final x10.rtt.Type t1) {
            return $apply$O(x10.core.Long.$unbox(a1));
            
        }
        
        
    
        
        public long $apply$O(final long i$158077) {
            
            //#line 223 . "x10/regionarray/RectRegion.x10"
            final long t$158078 = this.this$157202.min$O((long)(i$158077));
            
            //#line 223 . "x10/regionarray/RectRegion.x10"
            return t$158078;
        }
        
        public x10.regionarray.RectRegion this$157202;
        
        public $Closure$270(final x10.regionarray.RectRegion this$157202) {
             {
                this.this$157202 = ((x10.regionarray.RectRegion)(this$157202));
            }
        }
        
    }
    
    @x10.runtime.impl.java.X10Generated
    final public static class $Closure$271 extends x10.core.Ref implements x10.core.fun.Fun_0_1, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<$Closure$271> $RTT = 
            x10.rtt.StaticFunType.<$Closure$271> make($Closure$271.class,
                                                      new x10.rtt.Type[] {
                                                          x10.rtt.ParameterizedType.make(x10.core.fun.Fun_0_1.$RTT, x10.rtt.Types.LONG, x10.rtt.Types.LONG)
                                                      });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static x10.serialization.X10JavaSerializable $_deserialize_body(x10.regionarray.RectRegion.$Closure$271 $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            $_obj.this$157206 = $deserializer.readObject();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.regionarray.RectRegion.$Closure$271 $_obj = new x10.regionarray.RectRegion.$Closure$271((java.lang.System[]) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            $serializer.write(this.this$157206);
            
        }
        
        // constructor just for allocation
        public $Closure$271(final java.lang.System[] $dummy) {
            
        }
        
        // dispatcher for method abstract public (Z1)=>U.operator()(a1:Z1):U
        public java.lang.Object $apply(final java.lang.Object a1, final x10.rtt.Type t1) {
            return x10.core.Long.$box($apply$O(x10.core.Long.$unbox(a1)));
            
        }
        
        // dispatcher for method abstract public (Z1)=>U.operator()(a1:Z1):U
        public long $apply$J(final java.lang.Object a1, final x10.rtt.Type t1) {
            return $apply$O(x10.core.Long.$unbox(a1));
            
        }
        
        
    
        
        public long $apply$O(final long i$158080) {
            
            //#line 224 . "x10/regionarray/RectRegion.x10"
            final long t$158081 = this.this$157206.max$O((long)(i$158080));
            
            //#line 224 . "x10/regionarray/RectRegion.x10"
            return t$158081;
        }
        
        public x10.regionarray.RectRegion this$157206;
        
        public $Closure$271(final x10.regionarray.RectRegion this$157206) {
             {
                this.this$157206 = ((x10.regionarray.RectRegion)(this$157206));
            }
        }
        
    }
    
    @x10.runtime.impl.java.X10Generated
    final public static class $Closure$272 extends x10.core.Ref implements x10.core.fun.Fun_0_1, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<$Closure$272> $RTT = 
            x10.rtt.StaticFunType.<$Closure$272> make($Closure$272.class,
                                                      new x10.rtt.Type[] {
                                                          x10.rtt.ParameterizedType.make(x10.core.fun.Fun_0_1.$RTT, x10.rtt.Types.LONG, x10.rtt.Types.LONG)
                                                      });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static x10.serialization.X10JavaSerializable $_deserialize_body(x10.regionarray.RectRegion.$Closure$272 $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            $_obj.out$$ = $deserializer.readObject();
            $_obj.thatMin = $deserializer.readObject();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.regionarray.RectRegion.$Closure$272 $_obj = new x10.regionarray.RectRegion.$Closure$272((java.lang.System[]) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            $serializer.write(this.out$$);
            $serializer.write(this.thatMin);
            
        }
        
        // constructor just for allocation
        public $Closure$272(final java.lang.System[] $dummy) {
            
        }
        
        // dispatcher for method abstract public (Z1)=>U.operator()(a1:Z1):U
        public java.lang.Object $apply(final java.lang.Object a1, final x10.rtt.Type t1) {
            return x10.core.Long.$box($apply$O(x10.core.Long.$unbox(a1)));
            
        }
        
        // dispatcher for method abstract public (Z1)=>U.operator()(a1:Z1):U
        public long $apply$J(final java.lang.Object a1, final x10.rtt.Type t1) {
            return $apply$O(x10.core.Long.$unbox(a1));
            
        }
        
        // synthetic type for parameter mangling
        public static final class __1$1x10$lang$Long$3x10$lang$Long$2 {}
        
    
        
        public long $apply$O(final long i) {
            
            //#line 325 "x10/regionarray/RectRegion.x10"
            final long t$157705 = this.out$$.min$O((long)(i));
            
            //#line 325 "x10/regionarray/RectRegion.x10"
            final long t$157706 = x10.core.Long.$unbox(((x10.core.fun.Fun_0_1<x10.core.Long,x10.core.Long>)this.thatMin).$apply(x10.core.Long.$box(i), x10.rtt.Types.LONG));
            
            //#line 325 "x10/regionarray/RectRegion.x10"
            final long t$157707 = java.lang.Math.max(((long)(t$157705)),((long)(t$157706)));
            
            //#line 325 "x10/regionarray/RectRegion.x10"
            return t$157707;
        }
        
        public x10.regionarray.RectRegion out$$;
        public x10.core.fun.Fun_0_1<x10.core.Long,x10.core.Long> thatMin;
        
        public $Closure$272(final x10.regionarray.RectRegion out$$, final x10.core.fun.Fun_0_1<x10.core.Long,x10.core.Long> thatMin, __1$1x10$lang$Long$3x10$lang$Long$2 $dummy) {
             {
                this.out$$ = out$$;
                this.thatMin = ((x10.core.fun.Fun_0_1)(thatMin));
            }
        }
        
    }
    
    @x10.runtime.impl.java.X10Generated
    final public static class $Closure$273 extends x10.core.Ref implements x10.core.fun.Fun_0_1, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<$Closure$273> $RTT = 
            x10.rtt.StaticFunType.<$Closure$273> make($Closure$273.class,
                                                      new x10.rtt.Type[] {
                                                          x10.rtt.ParameterizedType.make(x10.core.fun.Fun_0_1.$RTT, x10.rtt.Types.LONG, x10.rtt.Types.LONG)
                                                      });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static x10.serialization.X10JavaSerializable $_deserialize_body(x10.regionarray.RectRegion.$Closure$273 $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            $_obj.out$$ = $deserializer.readObject();
            $_obj.thatMax = $deserializer.readObject();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.regionarray.RectRegion.$Closure$273 $_obj = new x10.regionarray.RectRegion.$Closure$273((java.lang.System[]) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            $serializer.write(this.out$$);
            $serializer.write(this.thatMax);
            
        }
        
        // constructor just for allocation
        public $Closure$273(final java.lang.System[] $dummy) {
            
        }
        
        // dispatcher for method abstract public (Z1)=>U.operator()(a1:Z1):U
        public java.lang.Object $apply(final java.lang.Object a1, final x10.rtt.Type t1) {
            return x10.core.Long.$box($apply$O(x10.core.Long.$unbox(a1)));
            
        }
        
        // dispatcher for method abstract public (Z1)=>U.operator()(a1:Z1):U
        public long $apply$J(final java.lang.Object a1, final x10.rtt.Type t1) {
            return $apply$O(x10.core.Long.$unbox(a1));
            
        }
        
        // synthetic type for parameter mangling
        public static final class __1$1x10$lang$Long$3x10$lang$Long$2 {}
        
    
        
        public long $apply$O(final long i) {
            
            //#line 326 "x10/regionarray/RectRegion.x10"
            final long t$157710 = this.out$$.max$O((long)(i));
            
            //#line 326 "x10/regionarray/RectRegion.x10"
            final long t$157711 = x10.core.Long.$unbox(((x10.core.fun.Fun_0_1<x10.core.Long,x10.core.Long>)this.thatMax).$apply(x10.core.Long.$box(i), x10.rtt.Types.LONG));
            
            //#line 326 "x10/regionarray/RectRegion.x10"
            final long t$157712 = java.lang.Math.min(((long)(t$157710)),((long)(t$157711)));
            
            //#line 326 "x10/regionarray/RectRegion.x10"
            return t$157712;
        }
        
        public x10.regionarray.RectRegion out$$;
        public x10.core.fun.Fun_0_1<x10.core.Long,x10.core.Long> thatMax;
        
        public $Closure$273(final x10.regionarray.RectRegion out$$, final x10.core.fun.Fun_0_1<x10.core.Long,x10.core.Long> thatMax, __1$1x10$lang$Long$3x10$lang$Long$2 $dummy) {
             {
                this.out$$ = out$$;
                this.thatMax = ((x10.core.fun.Fun_0_1)(thatMax));
            }
        }
        
    }
    
    @x10.runtime.impl.java.X10Generated
    final public static class $Closure$274 extends x10.core.Ref implements x10.core.fun.Fun_0_1, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<$Closure$274> $RTT = 
            x10.rtt.StaticFunType.<$Closure$274> make($Closure$274.class,
                                                      new x10.rtt.Type[] {
                                                          x10.rtt.ParameterizedType.make(x10.core.fun.Fun_0_1.$RTT, x10.rtt.Types.LONG, x10.rtt.Types.LONG)
                                                      });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static x10.serialization.X10JavaSerializable $_deserialize_body(x10.regionarray.RectRegion.$Closure$274 $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            $_obj.this$157219 = $deserializer.readObject();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.regionarray.RectRegion.$Closure$274 $_obj = new x10.regionarray.RectRegion.$Closure$274((java.lang.System[]) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            $serializer.write(this.this$157219);
            
        }
        
        // constructor just for allocation
        public $Closure$274(final java.lang.System[] $dummy) {
            
        }
        
        // dispatcher for method abstract public (Z1)=>U.operator()(a1:Z1):U
        public java.lang.Object $apply(final java.lang.Object a1, final x10.rtt.Type t1) {
            return x10.core.Long.$box($apply$O(x10.core.Long.$unbox(a1)));
            
        }
        
        // dispatcher for method abstract public (Z1)=>U.operator()(a1:Z1):U
        public long $apply$J(final java.lang.Object a1, final x10.rtt.Type t1) {
            return $apply$O(x10.core.Long.$unbox(a1));
            
        }
        
        
    
        
        public long $apply$O(final long i$158085) {
            
            //#line 223 . "x10/regionarray/RectRegion.x10"
            final long t$158086 = this.this$157219.min$O((long)(i$158085));
            
            //#line 223 . "x10/regionarray/RectRegion.x10"
            return t$158086;
        }
        
        public x10.regionarray.RectRegion this$157219;
        
        public $Closure$274(final x10.regionarray.RectRegion this$157219) {
             {
                this.this$157219 = ((x10.regionarray.RectRegion)(this$157219));
            }
        }
        
    }
    
    @x10.runtime.impl.java.X10Generated
    final public static class $Closure$275 extends x10.core.Ref implements x10.core.fun.Fun_0_1, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<$Closure$275> $RTT = 
            x10.rtt.StaticFunType.<$Closure$275> make($Closure$275.class,
                                                      new x10.rtt.Type[] {
                                                          x10.rtt.ParameterizedType.make(x10.core.fun.Fun_0_1.$RTT, x10.rtt.Types.LONG, x10.rtt.Types.LONG)
                                                      });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static x10.serialization.X10JavaSerializable $_deserialize_body(x10.regionarray.RectRegion.$Closure$275 $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            $_obj.this$157223 = $deserializer.readObject();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.regionarray.RectRegion.$Closure$275 $_obj = new x10.regionarray.RectRegion.$Closure$275((java.lang.System[]) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            $serializer.write(this.this$157223);
            
        }
        
        // constructor just for allocation
        public $Closure$275(final java.lang.System[] $dummy) {
            
        }
        
        // dispatcher for method abstract public (Z1)=>U.operator()(a1:Z1):U
        public java.lang.Object $apply(final java.lang.Object a1, final x10.rtt.Type t1) {
            return x10.core.Long.$box($apply$O(x10.core.Long.$unbox(a1)));
            
        }
        
        // dispatcher for method abstract public (Z1)=>U.operator()(a1:Z1):U
        public long $apply$J(final java.lang.Object a1, final x10.rtt.Type t1) {
            return $apply$O(x10.core.Long.$unbox(a1));
            
        }
        
        
    
        
        public long $apply$O(final long i$158088) {
            
            //#line 224 . "x10/regionarray/RectRegion.x10"
            final long t$158089 = this.this$157223.max$O((long)(i$158088));
            
            //#line 224 . "x10/regionarray/RectRegion.x10"
            return t$158089;
        }
        
        public x10.regionarray.RectRegion this$157223;
        
        public $Closure$275(final x10.regionarray.RectRegion this$157223) {
             {
                this.this$157223 = ((x10.regionarray.RectRegion)(this$157223));
            }
        }
        
    }
    
    @x10.runtime.impl.java.X10Generated
    final public static class $Closure$276 extends x10.core.Ref implements x10.core.fun.Fun_0_1, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<$Closure$276> $RTT = 
            x10.rtt.StaticFunType.<$Closure$276> make($Closure$276.class,
                                                      new x10.rtt.Type[] {
                                                          x10.rtt.ParameterizedType.make(x10.core.fun.Fun_0_1.$RTT, x10.rtt.Types.LONG, x10.rtt.Types.LONG)
                                                      });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static x10.serialization.X10JavaSerializable $_deserialize_body(x10.regionarray.RectRegion.$Closure$276 $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            $_obj.out$$ = $deserializer.readObject();
            $_obj.rank = $deserializer.readLong();
            $_obj.thatMin = $deserializer.readObject();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.regionarray.RectRegion.$Closure$276 $_obj = new x10.regionarray.RectRegion.$Closure$276((java.lang.System[]) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            $serializer.write(this.out$$);
            $serializer.write(this.rank);
            $serializer.write(this.thatMin);
            
        }
        
        // constructor just for allocation
        public $Closure$276(final java.lang.System[] $dummy) {
            
        }
        
        // dispatcher for method abstract public (Z1)=>U.operator()(a1:Z1):U
        public java.lang.Object $apply(final java.lang.Object a1, final x10.rtt.Type t1) {
            return x10.core.Long.$box($apply$O(x10.core.Long.$unbox(a1)));
            
        }
        
        // dispatcher for method abstract public (Z1)=>U.operator()(a1:Z1):U
        public long $apply$J(final java.lang.Object a1, final x10.rtt.Type t1) {
            return $apply$O(x10.core.Long.$unbox(a1));
            
        }
        
        // synthetic type for parameter mangling
        public static final class __2$1x10$lang$Long$3x10$lang$Long$2 {}
        
    
        
        public long $apply$O(final long i) {
            
            //#line 351 "x10/regionarray/RectRegion.x10"
            final long t$157766 = this.rank;
            
            //#line 351 "x10/regionarray/RectRegion.x10"
            final boolean t$157769 = ((i) < (((long)(t$157766))));
            
            //#line 351 "x10/regionarray/RectRegion.x10"
            long t$157770 =  0;
            
            //#line 351 "x10/regionarray/RectRegion.x10"
            if (t$157769) {
                
                //#line 351 "x10/regionarray/RectRegion.x10"
                t$157770 = this.out$$.min$O((long)(i));
            } else {
                
                //#line 351 "x10/regionarray/RectRegion.x10"
                final long t$157767 = this.rank;
                
                //#line 351 "x10/regionarray/RectRegion.x10"
                final long t$157768 = ((i) - (((long)(t$157767))));
                
                //#line 351 "x10/regionarray/RectRegion.x10"
                t$157770 = x10.core.Long.$unbox(((x10.core.fun.Fun_0_1<x10.core.Long,x10.core.Long>)this.thatMin).$apply(x10.core.Long.$box(t$157768), x10.rtt.Types.LONG));
            }
            
            //#line 351 "x10/regionarray/RectRegion.x10"
            return t$157770;
        }
        
        public x10.regionarray.RectRegion out$$;
        public long rank;
        public x10.core.fun.Fun_0_1<x10.core.Long,x10.core.Long> thatMin;
        
        public $Closure$276(final x10.regionarray.RectRegion out$$, final long rank, final x10.core.fun.Fun_0_1<x10.core.Long,x10.core.Long> thatMin, __2$1x10$lang$Long$3x10$lang$Long$2 $dummy) {
             {
                this.out$$ = out$$;
                this.rank = rank;
                this.thatMin = ((x10.core.fun.Fun_0_1)(thatMin));
            }
        }
        
    }
    
    @x10.runtime.impl.java.X10Generated
    final public static class $Closure$277 extends x10.core.Ref implements x10.core.fun.Fun_0_1, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<$Closure$277> $RTT = 
            x10.rtt.StaticFunType.<$Closure$277> make($Closure$277.class,
                                                      new x10.rtt.Type[] {
                                                          x10.rtt.ParameterizedType.make(x10.core.fun.Fun_0_1.$RTT, x10.rtt.Types.LONG, x10.rtt.Types.LONG)
                                                      });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static x10.serialization.X10JavaSerializable $_deserialize_body(x10.regionarray.RectRegion.$Closure$277 $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            $_obj.out$$ = $deserializer.readObject();
            $_obj.rank = $deserializer.readLong();
            $_obj.thatMax = $deserializer.readObject();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.regionarray.RectRegion.$Closure$277 $_obj = new x10.regionarray.RectRegion.$Closure$277((java.lang.System[]) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            $serializer.write(this.out$$);
            $serializer.write(this.rank);
            $serializer.write(this.thatMax);
            
        }
        
        // constructor just for allocation
        public $Closure$277(final java.lang.System[] $dummy) {
            
        }
        
        // dispatcher for method abstract public (Z1)=>U.operator()(a1:Z1):U
        public java.lang.Object $apply(final java.lang.Object a1, final x10.rtt.Type t1) {
            return x10.core.Long.$box($apply$O(x10.core.Long.$unbox(a1)));
            
        }
        
        // dispatcher for method abstract public (Z1)=>U.operator()(a1:Z1):U
        public long $apply$J(final java.lang.Object a1, final x10.rtt.Type t1) {
            return $apply$O(x10.core.Long.$unbox(a1));
            
        }
        
        // synthetic type for parameter mangling
        public static final class __2$1x10$lang$Long$3x10$lang$Long$2 {}
        
    
        
        public long $apply$O(final long i) {
            
            //#line 352 "x10/regionarray/RectRegion.x10"
            final long t$157773 = this.rank;
            
            //#line 352 "x10/regionarray/RectRegion.x10"
            final boolean t$157776 = ((i) < (((long)(t$157773))));
            
            //#line 352 "x10/regionarray/RectRegion.x10"
            long t$157777 =  0;
            
            //#line 352 "x10/regionarray/RectRegion.x10"
            if (t$157776) {
                
                //#line 352 "x10/regionarray/RectRegion.x10"
                t$157777 = this.out$$.max$O((long)(i));
            } else {
                
                //#line 352 "x10/regionarray/RectRegion.x10"
                final long t$157774 = this.rank;
                
                //#line 352 "x10/regionarray/RectRegion.x10"
                final long t$157775 = ((i) - (((long)(t$157774))));
                
                //#line 352 "x10/regionarray/RectRegion.x10"
                t$157777 = x10.core.Long.$unbox(((x10.core.fun.Fun_0_1<x10.core.Long,x10.core.Long>)this.thatMax).$apply(x10.core.Long.$box(t$157775), x10.rtt.Types.LONG));
            }
            
            //#line 352 "x10/regionarray/RectRegion.x10"
            return t$157777;
        }
        
        public x10.regionarray.RectRegion out$$;
        public long rank;
        public x10.core.fun.Fun_0_1<x10.core.Long,x10.core.Long> thatMax;
        
        public $Closure$277(final x10.regionarray.RectRegion out$$, final long rank, final x10.core.fun.Fun_0_1<x10.core.Long,x10.core.Long> thatMax, __2$1x10$lang$Long$3x10$lang$Long$2 $dummy) {
             {
                this.out$$ = out$$;
                this.rank = rank;
                this.thatMax = ((x10.core.fun.Fun_0_1)(thatMax));
            }
        }
        
    }
    
    @x10.runtime.impl.java.X10Generated
    final public static class $Closure$278 extends x10.core.Ref implements x10.core.fun.Fun_0_1, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<$Closure$278> $RTT = 
            x10.rtt.StaticFunType.<$Closure$278> make($Closure$278.class,
                                                      new x10.rtt.Type[] {
                                                          x10.rtt.ParameterizedType.make(x10.core.fun.Fun_0_1.$RTT, x10.rtt.Types.LONG, x10.rtt.Types.LONG)
                                                      });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static x10.serialization.X10JavaSerializable $_deserialize_body(x10.regionarray.RectRegion.$Closure$278 $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            $_obj.out$$ = $deserializer.readObject();
            $_obj.rank = $deserializer.readLong();
            $_obj.thatMin = $deserializer.readLong();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.regionarray.RectRegion.$Closure$278 $_obj = new x10.regionarray.RectRegion.$Closure$278((java.lang.System[]) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            $serializer.write(this.out$$);
            $serializer.write(this.rank);
            $serializer.write(this.thatMin);
            
        }
        
        // constructor just for allocation
        public $Closure$278(final java.lang.System[] $dummy) {
            
        }
        
        // dispatcher for method abstract public (Z1)=>U.operator()(a1:Z1):U
        public java.lang.Object $apply(final java.lang.Object a1, final x10.rtt.Type t1) {
            return x10.core.Long.$box($apply$O(x10.core.Long.$unbox(a1)));
            
        }
        
        // dispatcher for method abstract public (Z1)=>U.operator()(a1:Z1):U
        public long $apply$J(final java.lang.Object a1, final x10.rtt.Type t1) {
            return $apply$O(x10.core.Long.$unbox(a1));
            
        }
        
        
    
        
        public long $apply$O(final long i) {
            
            //#line 358 "x10/regionarray/RectRegion.x10"
            final long t$157781 = this.rank;
            
            //#line 358 "x10/regionarray/RectRegion.x10"
            final boolean t$157782 = ((i) < (((long)(t$157781))));
            
            //#line 358 "x10/regionarray/RectRegion.x10"
            long t$157783 =  0;
            
            //#line 358 "x10/regionarray/RectRegion.x10"
            if (t$157782) {
                
                //#line 358 "x10/regionarray/RectRegion.x10"
                t$157783 = this.out$$.min$O((long)(i));
            } else {
                
                //#line 358 "x10/regionarray/RectRegion.x10"
                t$157783 = this.thatMin;
            }
            
            //#line 358 "x10/regionarray/RectRegion.x10"
            return t$157783;
        }
        
        public x10.regionarray.RectRegion out$$;
        public long rank;
        public long thatMin;
        
        public $Closure$278(final x10.regionarray.RectRegion out$$, final long rank, final long thatMin) {
             {
                this.out$$ = out$$;
                this.rank = rank;
                this.thatMin = thatMin;
            }
        }
        
    }
    
    @x10.runtime.impl.java.X10Generated
    final public static class $Closure$279 extends x10.core.Ref implements x10.core.fun.Fun_0_1, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<$Closure$279> $RTT = 
            x10.rtt.StaticFunType.<$Closure$279> make($Closure$279.class,
                                                      new x10.rtt.Type[] {
                                                          x10.rtt.ParameterizedType.make(x10.core.fun.Fun_0_1.$RTT, x10.rtt.Types.LONG, x10.rtt.Types.LONG)
                                                      });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static x10.serialization.X10JavaSerializable $_deserialize_body(x10.regionarray.RectRegion.$Closure$279 $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            $_obj.out$$ = $deserializer.readObject();
            $_obj.rank = $deserializer.readLong();
            $_obj.thatMax = $deserializer.readLong();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.regionarray.RectRegion.$Closure$279 $_obj = new x10.regionarray.RectRegion.$Closure$279((java.lang.System[]) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            $serializer.write(this.out$$);
            $serializer.write(this.rank);
            $serializer.write(this.thatMax);
            
        }
        
        // constructor just for allocation
        public $Closure$279(final java.lang.System[] $dummy) {
            
        }
        
        // dispatcher for method abstract public (Z1)=>U.operator()(a1:Z1):U
        public java.lang.Object $apply(final java.lang.Object a1, final x10.rtt.Type t1) {
            return x10.core.Long.$box($apply$O(x10.core.Long.$unbox(a1)));
            
        }
        
        // dispatcher for method abstract public (Z1)=>U.operator()(a1:Z1):U
        public long $apply$J(final java.lang.Object a1, final x10.rtt.Type t1) {
            return $apply$O(x10.core.Long.$unbox(a1));
            
        }
        
        
    
        
        public long $apply$O(final long i) {
            
            //#line 359 "x10/regionarray/RectRegion.x10"
            final long t$157786 = this.rank;
            
            //#line 359 "x10/regionarray/RectRegion.x10"
            final boolean t$157787 = ((i) < (((long)(t$157786))));
            
            //#line 359 "x10/regionarray/RectRegion.x10"
            long t$157788 =  0;
            
            //#line 359 "x10/regionarray/RectRegion.x10"
            if (t$157787) {
                
                //#line 359 "x10/regionarray/RectRegion.x10"
                t$157788 = this.out$$.max$O((long)(i));
            } else {
                
                //#line 359 "x10/regionarray/RectRegion.x10"
                t$157788 = this.thatMax;
            }
            
            //#line 359 "x10/regionarray/RectRegion.x10"
            return t$157788;
        }
        
        public x10.regionarray.RectRegion out$$;
        public long rank;
        public long thatMax;
        
        public $Closure$279(final x10.regionarray.RectRegion out$$, final long rank, final long thatMax) {
             {
                this.out$$ = out$$;
                this.rank = rank;
                this.thatMax = thatMax;
            }
        }
        
    }
    
    @x10.runtime.impl.java.X10Generated
    final public static class $Closure$280 extends x10.core.Ref implements x10.core.fun.Fun_0_1, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<$Closure$280> $RTT = 
            x10.rtt.StaticFunType.<$Closure$280> make($Closure$280.class,
                                                      new x10.rtt.Type[] {
                                                          x10.rtt.ParameterizedType.make(x10.core.fun.Fun_0_1.$RTT, x10.rtt.Types.LONG, x10.rtt.Types.LONG)
                                                      });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static x10.serialization.X10JavaSerializable $_deserialize_body(x10.regionarray.RectRegion.$Closure$280 $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            $_obj.out$$ = $deserializer.readObject();
            $_obj.rank = $deserializer.readLong();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.regionarray.RectRegion.$Closure$280 $_obj = new x10.regionarray.RectRegion.$Closure$280((java.lang.System[]) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            $serializer.write(this.out$$);
            $serializer.write(this.rank);
            
        }
        
        // constructor just for allocation
        public $Closure$280(final java.lang.System[] $dummy) {
            
        }
        
        // dispatcher for method abstract public (Z1)=>U.operator()(a1:Z1):U
        public java.lang.Object $apply(final java.lang.Object a1, final x10.rtt.Type t1) {
            return x10.core.Long.$box($apply$O(x10.core.Long.$unbox(a1)));
            
        }
        
        // dispatcher for method abstract public (Z1)=>U.operator()(a1:Z1):U
        public long $apply$J(final java.lang.Object a1, final x10.rtt.Type t1) {
            return $apply$O(x10.core.Long.$unbox(a1));
            
        }
        
        
    
        
        public long $apply$O(final long i) {
            
            //#line 363 "x10/regionarray/RectRegion.x10"
            final long t$157793 = this.rank;
            
            //#line 363 "x10/regionarray/RectRegion.x10"
            final boolean t$157794 = ((i) < (((long)(t$157793))));
            
            //#line 363 "x10/regionarray/RectRegion.x10"
            long t$157795 =  0;
            
            //#line 363 "x10/regionarray/RectRegion.x10"
            if (t$157794) {
                
                //#line 363 "x10/regionarray/RectRegion.x10"
                t$157795 = this.out$$.min$O((long)(i));
            } else {
                
                //#line 363 "x10/regionarray/RectRegion.x10"
                t$157795 = java.lang.Long.MIN_VALUE;
            }
            
            //#line 363 "x10/regionarray/RectRegion.x10"
            return t$157795;
        }
        
        public x10.regionarray.RectRegion out$$;
        public long rank;
        
        public $Closure$280(final x10.regionarray.RectRegion out$$, final long rank) {
             {
                this.out$$ = out$$;
                this.rank = rank;
            }
        }
        
    }
    
    @x10.runtime.impl.java.X10Generated
    final public static class $Closure$281 extends x10.core.Ref implements x10.core.fun.Fun_0_1, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<$Closure$281> $RTT = 
            x10.rtt.StaticFunType.<$Closure$281> make($Closure$281.class,
                                                      new x10.rtt.Type[] {
                                                          x10.rtt.ParameterizedType.make(x10.core.fun.Fun_0_1.$RTT, x10.rtt.Types.LONG, x10.rtt.Types.LONG)
                                                      });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static x10.serialization.X10JavaSerializable $_deserialize_body(x10.regionarray.RectRegion.$Closure$281 $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            $_obj.out$$ = $deserializer.readObject();
            $_obj.rank = $deserializer.readLong();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.regionarray.RectRegion.$Closure$281 $_obj = new x10.regionarray.RectRegion.$Closure$281((java.lang.System[]) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            $serializer.write(this.out$$);
            $serializer.write(this.rank);
            
        }
        
        // constructor just for allocation
        public $Closure$281(final java.lang.System[] $dummy) {
            
        }
        
        // dispatcher for method abstract public (Z1)=>U.operator()(a1:Z1):U
        public java.lang.Object $apply(final java.lang.Object a1, final x10.rtt.Type t1) {
            return x10.core.Long.$box($apply$O(x10.core.Long.$unbox(a1)));
            
        }
        
        // dispatcher for method abstract public (Z1)=>U.operator()(a1:Z1):U
        public long $apply$J(final java.lang.Object a1, final x10.rtt.Type t1) {
            return $apply$O(x10.core.Long.$unbox(a1));
            
        }
        
        
    
        
        public long $apply$O(final long i) {
            
            //#line 364 "x10/regionarray/RectRegion.x10"
            final long t$157798 = this.rank;
            
            //#line 364 "x10/regionarray/RectRegion.x10"
            final boolean t$157799 = ((i) < (((long)(t$157798))));
            
            //#line 364 "x10/regionarray/RectRegion.x10"
            long t$157800 =  0;
            
            //#line 364 "x10/regionarray/RectRegion.x10"
            if (t$157799) {
                
                //#line 364 "x10/regionarray/RectRegion.x10"
                t$157800 = this.out$$.max$O((long)(i));
            } else {
                
                //#line 364 "x10/regionarray/RectRegion.x10"
                t$157800 = java.lang.Long.MAX_VALUE;
            }
            
            //#line 364 "x10/regionarray/RectRegion.x10"
            return t$157800;
        }
        
        public x10.regionarray.RectRegion out$$;
        public long rank;
        
        public $Closure$281(final x10.regionarray.RectRegion out$$, final long rank) {
             {
                this.out$$ = out$$;
                this.rank = rank;
            }
        }
        
    }
    
    @x10.runtime.impl.java.X10Generated
    final public static class $Closure$282 extends x10.core.Ref implements x10.core.fun.Fun_0_1, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<$Closure$282> $RTT = 
            x10.rtt.StaticFunType.<$Closure$282> make($Closure$282.class,
                                                      new x10.rtt.Type[] {
                                                          x10.rtt.ParameterizedType.make(x10.core.fun.Fun_0_1.$RTT, x10.rtt.Types.LONG, x10.rtt.Types.LONG)
                                                      });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static x10.serialization.X10JavaSerializable $_deserialize_body(x10.regionarray.RectRegion.$Closure$282 $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            $_obj.out$$ = $deserializer.readObject();
            $_obj.v = $deserializer.readObject();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.regionarray.RectRegion.$Closure$282 $_obj = new x10.regionarray.RectRegion.$Closure$282((java.lang.System[]) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            $serializer.write(this.out$$);
            $serializer.write(this.v);
            
        }
        
        // constructor just for allocation
        public $Closure$282(final java.lang.System[] $dummy) {
            
        }
        
        // dispatcher for method abstract public (Z1)=>U.operator()(a1:Z1):U
        public java.lang.Object $apply(final java.lang.Object a1, final x10.rtt.Type t1) {
            return x10.core.Long.$box($apply$O(x10.core.Long.$unbox(a1)));
            
        }
        
        // dispatcher for method abstract public (Z1)=>U.operator()(a1:Z1):U
        public long $apply$J(final java.lang.Object a1, final x10.rtt.Type t1) {
            return $apply$O(x10.core.Long.$unbox(a1));
            
        }
        
        
    
        
        public long $apply$O(final long i) {
            
            //#line 372 "x10/regionarray/RectRegion.x10"
            final long t$157814 = this.out$$.min$O((long)(i));
            
            //#line 372 "x10/regionarray/RectRegion.x10"
            final long t$157815 = this.v.$apply$O((long)(i));
            
            //#line 372 "x10/regionarray/RectRegion.x10"
            final long t$157816 = ((t$157814) + (((long)(t$157815))));
            
            //#line 372 "x10/regionarray/RectRegion.x10"
            return t$157816;
        }
        
        public x10.regionarray.RectRegion out$$;
        public x10.lang.Point v;
        
        public $Closure$282(final x10.regionarray.RectRegion out$$, final x10.lang.Point v) {
             {
                this.out$$ = out$$;
                this.v = ((x10.lang.Point)(v));
            }
        }
        
    }
    
    @x10.runtime.impl.java.X10Generated
    final public static class $Closure$283 extends x10.core.Ref implements x10.core.fun.Fun_0_1, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<$Closure$283> $RTT = 
            x10.rtt.StaticFunType.<$Closure$283> make($Closure$283.class,
                                                      new x10.rtt.Type[] {
                                                          x10.rtt.ParameterizedType.make(x10.core.fun.Fun_0_1.$RTT, x10.rtt.Types.LONG, x10.rtt.Types.LONG)
                                                      });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static x10.serialization.X10JavaSerializable $_deserialize_body(x10.regionarray.RectRegion.$Closure$283 $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            $_obj.out$$ = $deserializer.readObject();
            $_obj.v = $deserializer.readObject();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.regionarray.RectRegion.$Closure$283 $_obj = new x10.regionarray.RectRegion.$Closure$283((java.lang.System[]) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            $serializer.write(this.out$$);
            $serializer.write(this.v);
            
        }
        
        // constructor just for allocation
        public $Closure$283(final java.lang.System[] $dummy) {
            
        }
        
        // dispatcher for method abstract public (Z1)=>U.operator()(a1:Z1):U
        public java.lang.Object $apply(final java.lang.Object a1, final x10.rtt.Type t1) {
            return x10.core.Long.$box($apply$O(x10.core.Long.$unbox(a1)));
            
        }
        
        // dispatcher for method abstract public (Z1)=>U.operator()(a1:Z1):U
        public long $apply$J(final java.lang.Object a1, final x10.rtt.Type t1) {
            return $apply$O(x10.core.Long.$unbox(a1));
            
        }
        
        
    
        
        public long $apply$O(final long i) {
            
            //#line 373 "x10/regionarray/RectRegion.x10"
            final long t$157819 = this.out$$.max$O((long)(i));
            
            //#line 373 "x10/regionarray/RectRegion.x10"
            final long t$157820 = this.v.$apply$O((long)(i));
            
            //#line 373 "x10/regionarray/RectRegion.x10"
            final long t$157821 = ((t$157819) + (((long)(t$157820))));
            
            //#line 373 "x10/regionarray/RectRegion.x10"
            return t$157821;
        }
        
        public x10.regionarray.RectRegion out$$;
        public x10.lang.Point v;
        
        public $Closure$283(final x10.regionarray.RectRegion out$$, final x10.lang.Point v) {
             {
                this.out$$ = out$$;
                this.v = ((x10.lang.Point)(v));
            }
        }
        
    }
    
    @x10.runtime.impl.java.X10Generated
    final public static class $Closure$284 extends x10.core.Ref implements x10.core.fun.Fun_0_1, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<$Closure$284> $RTT = 
            x10.rtt.StaticFunType.<$Closure$284> make($Closure$284.class,
                                                      new x10.rtt.Type[] {
                                                          x10.rtt.ParameterizedType.make(x10.core.fun.Fun_0_1.$RTT, x10.rtt.Types.LONG, x10.rtt.Types.LONG)
                                                      });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static x10.serialization.X10JavaSerializable $_deserialize_body(x10.regionarray.RectRegion.$Closure$284 $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            $_obj.axis = $deserializer.readLong();
            $_obj.out$$ = $deserializer.readObject();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.regionarray.RectRegion.$Closure$284 $_obj = new x10.regionarray.RectRegion.$Closure$284((java.lang.System[]) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            $serializer.write(this.axis);
            $serializer.write(this.out$$);
            
        }
        
        // constructor just for allocation
        public $Closure$284(final java.lang.System[] $dummy) {
            
        }
        
        // dispatcher for method abstract public (Z1)=>U.operator()(a1:Z1):U
        public java.lang.Object $apply(final java.lang.Object a1, final x10.rtt.Type t1) {
            return x10.core.Long.$box($apply$O(x10.core.Long.$unbox(a1)));
            
        }
        
        // dispatcher for method abstract public (Z1)=>U.operator()(a1:Z1):U
        public long $apply$J(final java.lang.Object a1, final x10.rtt.Type t1) {
            return $apply$O(x10.core.Long.$unbox(a1));
            
        }
        
        
    
        
        public long $apply$O(final long i) {
            
            //#line 383 "x10/regionarray/RectRegion.x10"
            final boolean t$157844 = ((i) < (((long)(this.axis))));
            
            //#line 383 "x10/regionarray/RectRegion.x10"
            long t$157845 =  0;
            
            //#line 383 "x10/regionarray/RectRegion.x10"
            if (t$157844) {
                
                //#line 383 "x10/regionarray/RectRegion.x10"
                t$157845 = this.out$$.min$O((long)(i));
            } else {
                
                //#line 383 "x10/regionarray/RectRegion.x10"
                final long t$157843 = ((i) + (((long)(1L))));
                
                //#line 383 "x10/regionarray/RectRegion.x10"
                t$157845 = this.out$$.min$O((long)(t$157843));
            }
            
            //#line 383 "x10/regionarray/RectRegion.x10"
            return t$157845;
        }
        
        public x10.regionarray.RectRegion out$$;
        public long axis;
        
        public $Closure$284(final x10.regionarray.RectRegion out$$, final long axis) {
             {
                this.out$$ = out$$;
                this.axis = axis;
            }
        }
        
    }
    
    @x10.runtime.impl.java.X10Generated
    final public static class $Closure$285 extends x10.core.Ref implements x10.core.fun.Fun_0_1, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<$Closure$285> $RTT = 
            x10.rtt.StaticFunType.<$Closure$285> make($Closure$285.class,
                                                      new x10.rtt.Type[] {
                                                          x10.rtt.ParameterizedType.make(x10.core.fun.Fun_0_1.$RTT, x10.rtt.Types.LONG, x10.rtt.Types.LONG)
                                                      });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static x10.serialization.X10JavaSerializable $_deserialize_body(x10.regionarray.RectRegion.$Closure$285 $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            $_obj.axis = $deserializer.readLong();
            $_obj.out$$ = $deserializer.readObject();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.regionarray.RectRegion.$Closure$285 $_obj = new x10.regionarray.RectRegion.$Closure$285((java.lang.System[]) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            $serializer.write(this.axis);
            $serializer.write(this.out$$);
            
        }
        
        // constructor just for allocation
        public $Closure$285(final java.lang.System[] $dummy) {
            
        }
        
        // dispatcher for method abstract public (Z1)=>U.operator()(a1:Z1):U
        public java.lang.Object $apply(final java.lang.Object a1, final x10.rtt.Type t1) {
            return x10.core.Long.$box($apply$O(x10.core.Long.$unbox(a1)));
            
        }
        
        // dispatcher for method abstract public (Z1)=>U.operator()(a1:Z1):U
        public long $apply$J(final java.lang.Object a1, final x10.rtt.Type t1) {
            return $apply$O(x10.core.Long.$unbox(a1));
            
        }
        
        
    
        
        public long $apply$O(final long i) {
            
            //#line 384 "x10/regionarray/RectRegion.x10"
            final boolean t$157849 = ((i) < (((long)(this.axis))));
            
            //#line 384 "x10/regionarray/RectRegion.x10"
            long t$157850 =  0;
            
            //#line 384 "x10/regionarray/RectRegion.x10"
            if (t$157849) {
                
                //#line 384 "x10/regionarray/RectRegion.x10"
                t$157850 = this.out$$.max$O((long)(i));
            } else {
                
                //#line 384 "x10/regionarray/RectRegion.x10"
                final long t$157848 = ((i) + (((long)(1L))));
                
                //#line 384 "x10/regionarray/RectRegion.x10"
                t$157850 = this.out$$.max$O((long)(t$157848));
            }
            
            //#line 384 "x10/regionarray/RectRegion.x10"
            return t$157850;
        }
        
        public x10.regionarray.RectRegion out$$;
        public long axis;
        
        public $Closure$285(final x10.regionarray.RectRegion out$$, final long axis) {
             {
                this.out$$ = out$$;
                this.axis = axis;
            }
        }
        
    }
    
    @x10.runtime.impl.java.X10Generated
    final public static class $Closure$286 extends x10.core.Ref implements x10.core.fun.Fun_0_1, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<$Closure$286> $RTT = 
            x10.rtt.StaticFunType.<$Closure$286> make($Closure$286.class,
                                                      new x10.rtt.Type[] {
                                                          x10.rtt.ParameterizedType.make(x10.core.fun.Fun_0_1.$RTT, x10.rtt.Types.LONG, x10.rtt.Types.LONG)
                                                      });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static x10.serialization.X10JavaSerializable $_deserialize_body(x10.regionarray.RectRegion.$Closure$286 $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            $_obj.this$157245 = $deserializer.readObject();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.regionarray.RectRegion.$Closure$286 $_obj = new x10.regionarray.RectRegion.$Closure$286((java.lang.System[]) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            $serializer.write(this.this$157245);
            
        }
        
        // constructor just for allocation
        public $Closure$286(final java.lang.System[] $dummy) {
            
        }
        
        // dispatcher for method abstract public (Z1)=>U.operator()(a1:Z1):U
        public java.lang.Object $apply(final java.lang.Object a1, final x10.rtt.Type t1) {
            return x10.core.Long.$box($apply$O(x10.core.Long.$unbox(a1)));
            
        }
        
        // dispatcher for method abstract public (Z1)=>U.operator()(a1:Z1):U
        public long $apply$J(final java.lang.Object a1, final x10.rtt.Type t1) {
            return $apply$O(x10.core.Long.$unbox(a1));
            
        }
        
        
    
        
        public long $apply$O(final long i$158137) {
            
            //#line 223 . "x10/regionarray/RectRegion.x10"
            final long t$158138 = this.this$157245.min$O((long)(i$158137));
            
            //#line 223 . "x10/regionarray/RectRegion.x10"
            return t$158138;
        }
        
        public x10.regionarray.RectRegion this$157245;
        
        public $Closure$286(final x10.regionarray.RectRegion this$157245) {
             {
                this.this$157245 = ((x10.regionarray.RectRegion)(this$157245));
            }
        }
        
    }
    
    @x10.runtime.impl.java.X10Generated
    final public static class $Closure$287 extends x10.core.Ref implements x10.core.fun.Fun_0_1, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<$Closure$287> $RTT = 
            x10.rtt.StaticFunType.<$Closure$287> make($Closure$287.class,
                                                      new x10.rtt.Type[] {
                                                          x10.rtt.ParameterizedType.make(x10.core.fun.Fun_0_1.$RTT, x10.rtt.Types.LONG, x10.rtt.Types.LONG)
                                                      });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static x10.serialization.X10JavaSerializable $_deserialize_body(x10.regionarray.RectRegion.$Closure$287 $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            $_obj.this$157249 = $deserializer.readObject();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.regionarray.RectRegion.$Closure$287 $_obj = new x10.regionarray.RectRegion.$Closure$287((java.lang.System[]) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            $serializer.write(this.this$157249);
            
        }
        
        // constructor just for allocation
        public $Closure$287(final java.lang.System[] $dummy) {
            
        }
        
        // dispatcher for method abstract public (Z1)=>U.operator()(a1:Z1):U
        public java.lang.Object $apply(final java.lang.Object a1, final x10.rtt.Type t1) {
            return x10.core.Long.$box($apply$O(x10.core.Long.$unbox(a1)));
            
        }
        
        // dispatcher for method abstract public (Z1)=>U.operator()(a1:Z1):U
        public long $apply$J(final java.lang.Object a1, final x10.rtt.Type t1) {
            return $apply$O(x10.core.Long.$unbox(a1));
            
        }
        
        
    
        
        public long $apply$O(final long i$158140) {
            
            //#line 224 . "x10/regionarray/RectRegion.x10"
            final long t$158141 = this.this$157249.max$O((long)(i$158140));
            
            //#line 224 . "x10/regionarray/RectRegion.x10"
            return t$158141;
        }
        
        public x10.regionarray.RectRegion this$157249;
        
        public $Closure$287(final x10.regionarray.RectRegion this$157249) {
             {
                this.this$157249 = ((x10.regionarray.RectRegion)(this$157249));
            }
        }
        
    }
    
    @x10.runtime.impl.java.X10Generated
    final public static class $Closure$288 extends x10.core.Ref implements x10.core.fun.Fun_0_1, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<$Closure$288> $RTT = 
            x10.rtt.StaticFunType.<$Closure$288> make($Closure$288.class,
                                                      new x10.rtt.Type[] {
                                                          x10.rtt.ParameterizedType.make(x10.core.fun.Fun_0_1.$RTT, x10.rtt.Types.LONG, x10.rtt.Types.LONG)
                                                      });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static x10.serialization.X10JavaSerializable $_deserialize_body(x10.regionarray.RectRegion.$Closure$288 $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            $_obj.this$157253 = $deserializer.readObject();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.regionarray.RectRegion.$Closure$288 $_obj = new x10.regionarray.RectRegion.$Closure$288((java.lang.System[]) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            $serializer.write(this.this$157253);
            
        }
        
        // constructor just for allocation
        public $Closure$288(final java.lang.System[] $dummy) {
            
        }
        
        // dispatcher for method abstract public (Z1)=>U.operator()(a1:Z1):U
        public java.lang.Object $apply(final java.lang.Object a1, final x10.rtt.Type t1) {
            return x10.core.Long.$box($apply$O(x10.core.Long.$unbox(a1)));
            
        }
        
        // dispatcher for method abstract public (Z1)=>U.operator()(a1:Z1):U
        public long $apply$J(final java.lang.Object a1, final x10.rtt.Type t1) {
            return $apply$O(x10.core.Long.$unbox(a1));
            
        }
        
        
    
        
        public long $apply$O(final long i$158143) {
            
            //#line 223 . "x10/regionarray/RectRegion.x10"
            final long t$158144 = this.this$157253.min$O((long)(i$158143));
            
            //#line 223 . "x10/regionarray/RectRegion.x10"
            return t$158144;
        }
        
        public x10.regionarray.RectRegion this$157253;
        
        public $Closure$288(final x10.regionarray.RectRegion this$157253) {
             {
                this.this$157253 = ((x10.regionarray.RectRegion)(this$157253));
            }
        }
        
    }
    
    @x10.runtime.impl.java.X10Generated
    final public static class $Closure$289 extends x10.core.Ref implements x10.core.fun.Fun_0_1, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<$Closure$289> $RTT = 
            x10.rtt.StaticFunType.<$Closure$289> make($Closure$289.class,
                                                      new x10.rtt.Type[] {
                                                          x10.rtt.ParameterizedType.make(x10.core.fun.Fun_0_1.$RTT, x10.rtt.Types.LONG, x10.rtt.Types.LONG)
                                                      });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static x10.serialization.X10JavaSerializable $_deserialize_body(x10.regionarray.RectRegion.$Closure$289 $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            $_obj.this$157257 = $deserializer.readObject();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.regionarray.RectRegion.$Closure$289 $_obj = new x10.regionarray.RectRegion.$Closure$289((java.lang.System[]) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            $serializer.write(this.this$157257);
            
        }
        
        // constructor just for allocation
        public $Closure$289(final java.lang.System[] $dummy) {
            
        }
        
        // dispatcher for method abstract public (Z1)=>U.operator()(a1:Z1):U
        public java.lang.Object $apply(final java.lang.Object a1, final x10.rtt.Type t1) {
            return x10.core.Long.$box($apply$O(x10.core.Long.$unbox(a1)));
            
        }
        
        // dispatcher for method abstract public (Z1)=>U.operator()(a1:Z1):U
        public long $apply$J(final java.lang.Object a1, final x10.rtt.Type t1) {
            return $apply$O(x10.core.Long.$unbox(a1));
            
        }
        
        
    
        
        public long $apply$O(final long i$158146) {
            
            //#line 224 . "x10/regionarray/RectRegion.x10"
            final long t$158147 = this.this$157257.max$O((long)(i$158146));
            
            //#line 224 . "x10/regionarray/RectRegion.x10"
            return t$158147;
        }
        
        public x10.regionarray.RectRegion this$157257;
        
        public $Closure$289(final x10.regionarray.RectRegion this$157257) {
             {
                this.this$157257 = ((x10.regionarray.RectRegion)(this$157257));
            }
        }
        
    }
    
    @x10.runtime.impl.java.X10Generated
    final public static class $Closure$290 extends x10.core.Ref implements x10.core.fun.Fun_0_1, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<$Closure$290> $RTT = 
            x10.rtt.StaticFunType.<$Closure$290> make($Closure$290.class,
                                                      new x10.rtt.Type[] {
                                                          x10.rtt.ParameterizedType.make(x10.core.fun.Fun_0_1.$RTT, x10.rtt.Types.LONG, x10.rtt.Types.LONG)
                                                      });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static x10.serialization.X10JavaSerializable $_deserialize_body(x10.regionarray.RectRegion.$Closure$290 $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            $_obj.this$157261 = $deserializer.readObject();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.regionarray.RectRegion.$Closure$290 $_obj = new x10.regionarray.RectRegion.$Closure$290((java.lang.System[]) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            $serializer.write(this.this$157261);
            
        }
        
        // constructor just for allocation
        public $Closure$290(final java.lang.System[] $dummy) {
            
        }
        
        // dispatcher for method abstract public (Z1)=>U.operator()(a1:Z1):U
        public java.lang.Object $apply(final java.lang.Object a1, final x10.rtt.Type t1) {
            return x10.core.Long.$box($apply$O(x10.core.Long.$unbox(a1)));
            
        }
        
        // dispatcher for method abstract public (Z1)=>U.operator()(a1:Z1):U
        public long $apply$J(final java.lang.Object a1, final x10.rtt.Type t1) {
            return $apply$O(x10.core.Long.$unbox(a1));
            
        }
        
        
    
        
        public long $apply$O(final long i$158167) {
            
            //#line 223 . "x10/regionarray/RectRegion.x10"
            final long t$158168 = this.this$157261.min$O((long)(i$158167));
            
            //#line 223 . "x10/regionarray/RectRegion.x10"
            return t$158168;
        }
        
        public x10.regionarray.RectRegion this$157261;
        
        public $Closure$290(final x10.regionarray.RectRegion this$157261) {
             {
                this.this$157261 = ((x10.regionarray.RectRegion)(this$157261));
            }
        }
        
    }
    
    @x10.runtime.impl.java.X10Generated
    final public static class $Closure$291 extends x10.core.Ref implements x10.core.fun.Fun_0_1, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<$Closure$291> $RTT = 
            x10.rtt.StaticFunType.<$Closure$291> make($Closure$291.class,
                                                      new x10.rtt.Type[] {
                                                          x10.rtt.ParameterizedType.make(x10.core.fun.Fun_0_1.$RTT, x10.rtt.Types.LONG, x10.rtt.Types.LONG)
                                                      });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static x10.serialization.X10JavaSerializable $_deserialize_body(x10.regionarray.RectRegion.$Closure$291 $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            $_obj.this$157265 = $deserializer.readObject();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.regionarray.RectRegion.$Closure$291 $_obj = new x10.regionarray.RectRegion.$Closure$291((java.lang.System[]) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            $serializer.write(this.this$157265);
            
        }
        
        // constructor just for allocation
        public $Closure$291(final java.lang.System[] $dummy) {
            
        }
        
        // dispatcher for method abstract public (Z1)=>U.operator()(a1:Z1):U
        public java.lang.Object $apply(final java.lang.Object a1, final x10.rtt.Type t1) {
            return x10.core.Long.$box($apply$O(x10.core.Long.$unbox(a1)));
            
        }
        
        // dispatcher for method abstract public (Z1)=>U.operator()(a1:Z1):U
        public long $apply$J(final java.lang.Object a1, final x10.rtt.Type t1) {
            return $apply$O(x10.core.Long.$unbox(a1));
            
        }
        
        
    
        
        public long $apply$O(final long i$158170) {
            
            //#line 224 . "x10/regionarray/RectRegion.x10"
            final long t$158171 = this.this$157265.max$O((long)(i$158170));
            
            //#line 224 . "x10/regionarray/RectRegion.x10"
            return t$158171;
        }
        
        public x10.regionarray.RectRegion this$157265;
        
        public $Closure$291(final x10.regionarray.RectRegion this$157265) {
             {
                this.this$157265 = ((x10.regionarray.RectRegion)(this$157265));
            }
        }
        
    }
    
    
    public boolean x10$regionarray$Region$equals$S$O(final java.lang.Object a0) {
        return super.equals(((java.lang.Object)(a0)));
    }
}

