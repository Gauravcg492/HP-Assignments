package x10.regionarray;


/**
 * <p>An array defines a mapping from {@link Point}s to data values of some type T.
 * The Points in the Array's domain are defined by specifying a {@link Region}
 * over which the Array is defined.  Attempting to access a data value
 * at a Point not included in the Array's Region will result in a 
 * {@link ArrayIndexOutOfBoundsException} being raised.</p>
 * 
 * <p>All of the data in an Array is stored in a single Place, the 
 * Array's object home.  Data values may only be accessed at
 * the Array's home place.</p>
 * 
 * <p>The Array implementation is optimized for relatively dense 
 * region of points. In particular, to compute the storage required
 * to store an array instance's data, the array's Region is asked
 * for its bounding box (n-dimensional box such that all points in
 * the Region are contained within the bounding box). Backing storage 
 * is allocated for every Point in the bounding box of the array's Region.
 * Using the Array with partially defined Regions (ie, Regions that do 
 * not include every point in the Region's bounding box) is supported
 * and will operate as expected, however if the Region is sparse and large
 * there will be significant space overheads incurred for defining an Array
 * over the Region.  In future versions of X10, we may support a more 
 * space efficient implementation of Arrays over sparse regions, but 
 * such an implementation is not yet available as part of the x10.regionarray package.</p>
 * 
 * <p>The closely related class {@link DistArray} is used to define 
 * distributed arrays where the data values for the Points in the 
 * array's domain are distributed over multiple places.</p>
 * 
 * @see Point
 * @see Region
 * @see DistArray
 */
@x10.runtime.impl.java.X10Generated
final public class Array<$T> extends x10.core.Ref implements x10.core.fun.Fun_0_1, x10.lang.Iterable, x10.serialization.X10JavaSerializable
{
    public static final x10.rtt.RuntimeType<Array> $RTT = 
        x10.rtt.NamedType.<Array> make("x10.regionarray.Array",
                                       Array.class,
                                       1,
                                       new x10.rtt.Type[] {
                                           x10.rtt.ParameterizedType.make(x10.core.fun.Fun_0_1.$RTT, x10.lang.Point.$RTT, x10.rtt.UnresolvedType.PARAM(0)),
                                           x10.rtt.ParameterizedType.make(x10.lang.Iterable.$RTT, x10.lang.Point.$RTT)
                                       });
    
    public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
    
    public x10.rtt.Type<?> $getParam(int i) { if (i == 0) return $T; return null; }
    
    private Object writeReplace() throws java.io.ObjectStreamException {
        return new x10.serialization.SerializationProxy(this);
    }
    
    public static <$T> x10.serialization.X10JavaSerializable $_deserialize_body(x10.regionarray.Array<$T> $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
        $_obj.$T = (x10.rtt.Type) $deserializer.readObject();
        $_obj.layout = $deserializer.readObject();
        $_obj.layout_min0 = $deserializer.readLong();
        $_obj.layout_min1 = $deserializer.readLong();
        $_obj.layout_stride1 = $deserializer.readLong();
        $_obj.rail = $deserializer.readBoolean();
        $_obj.rank = $deserializer.readLong();
        $_obj.raw = $deserializer.readObject();
        $_obj.rect = $deserializer.readBoolean();
        $_obj.region = $deserializer.readObject();
        $_obj.size = $deserializer.readLong();
        $_obj.zeroBased = $deserializer.readBoolean();
        return $_obj;
    }
    
    public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
        x10.regionarray.Array $_obj = new x10.regionarray.Array((java.lang.System[]) null, (x10.rtt.Type) null);
        $deserializer.record_reference($_obj);
        return $_deserialize_body($_obj, $deserializer);
    }
    
    public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
        $serializer.write(this.$T);
        $serializer.write(this.layout);
        $serializer.write(this.layout_min0);
        $serializer.write(this.layout_min1);
        $serializer.write(this.layout_stride1);
        $serializer.write(this.rail);
        $serializer.write(this.rank);
        $serializer.write(this.raw);
        $serializer.write(this.rect);
        $serializer.write(this.region);
        $serializer.write(this.size);
        $serializer.write(this.zeroBased);
        
    }
    
    // constructor just for allocation
    public Array(final java.lang.System[] $dummy, final x10.rtt.Type $T) {
        x10.regionarray.Array.$initParams(this, $T);
        
    }
    
    // dispatcher for method abstract public (Z1)=>U.operator()(a1:Z1){}:U
    public java.lang.Object $apply(final java.lang.Object a1, final x10.rtt.Type t1) {
        return $apply$G((x10.lang.Point)a1);
        
    }
    
    private x10.rtt.Type $T;
    
    // initializer of type parameters
    public static void $initParams(final Array $this, final x10.rtt.Type $T) {
        $this.$T = $T;
        
    }
    // synthetic type for parameter mangling
    public static final class __1$1x10$lang$Point$3x10$regionarray$Array$$T$2 {}
    // synthetic type for parameter mangling
    public static final class __1x10$regionarray$Array$$T {}
    // synthetic type for parameter mangling
    public static final class __1$1x10$regionarray$Array$$T$2 {}
    // synthetic type for parameter mangling
    public static final class __0$1x10$regionarray$Array$$T$2 {}
    // synthetic type for parameter mangling
    public static final class __1$1x10$lang$Long$3x10$regionarray$Array$$T$2 {}
    
    // properties
    
    //#line 59 "x10/regionarray/Array.x10"
    /**
         * The region of this array.
         */
    public x10.regionarray.Region region;
    
    //#line 64 "x10/regionarray/Array.x10"
    /**
         * The rank of this array.
         */
    public long rank;
    
    //#line 69 "x10/regionarray/Array.x10"
    /**
         * Is this array defined over a rectangular region?  
         */
    public boolean rect;
    
    //#line 74 "x10/regionarray/Array.x10"
    /**
         * Is this array's region zero-based?
         */
    public boolean zeroBased;
    
    //#line 79 "x10/regionarray/Array.x10"
    /**
         * Is this array's region a "rail" (one-dimensional, rect, and zero-based)?
         */
    public boolean rail;
    
    //#line 85 "x10/regionarray/Array.x10"
    /**
         * The number of points/data values in the array.
         * Will always be equal to region.size(), but cached here to make it available as a property.
         */
    public long size;
    

    
    //#line 97 "x10/regionarray/Array.x10"
    /**
     * The backing storage for the array's elements
     */
    public x10.core.Rail<$T> raw;
    
    
    //#line 115 "x10/regionarray/Array.x10"
    /**
     * Return the Rail[T] that is providing the backing storage for the array.
     * This method is primarily intended to be used to interface with native libraries 
     * (eg BLAS, ESSL). <p>
     * 
     * This method should be used sparingly, since it may make client code dependent on the layout
     * algorithm used to map Points in the Array's Region to indicies in the backing Rail.
     * The specifics of this mapping are unspecified, although it would be reasonable to assume that
     * if the rect property is true, then every element of the backing Rail[T] actually
     * contatins a valid element of T.  Furthermore, for a multi-dimensional array it is currently true
     * (and likely to remain true) that the layout used is a row-major layout (like C, unlike Fortran)
     * and is compatible with the layout expected by platform BLAS libraries that operate on row-major
     * C arrays.
     * 
     * @return the Rail[T] that is the backing storage for the Array object.
     */
    public x10.core.Rail raw() {
        
        //#line 115 "x10/regionarray/Array.x10"
        final x10.core.Rail t$139794 = ((x10.core.Rail)(this.raw));
        
        //#line 115 "x10/regionarray/Array.x10"
        return t$139794;
    }
    
    
    //#line 122 "x10/regionarray/Array.x10"
    /**
     * Construct an Array over the region reg whose elements are zero-initialized.
     * 
     * @param reg The region over which to construct the array.
     */
    // creation method for java code (1-phase java constructor)
    public Array(final x10.rtt.Type $T, final x10.regionarray.Region reg) {
        this((java.lang.System[]) null, $T);
        x10$regionarray$Array$$init$S(reg);
    }
    
    // constructor for non-virtual call
    final public x10.regionarray.Array<$T> x10$regionarray$Array$$init$S(final x10.regionarray.Region reg) {
         {
            
            //#line 124 "x10/regionarray/Array.x10"
            final x10.regionarray.Region t$141658 = ((x10.regionarray.Region)
                                                      reg);
            
            //#line 124 "x10/regionarray/Array.x10"
            final boolean t$141659 = ((t$141658) != (null));
            
            //#line 124 "x10/regionarray/Array.x10"
            final boolean t$141660 = !(t$141659);
            
            //#line 124 "x10/regionarray/Array.x10"
            if (t$141660) {
                
                //#line 124 "x10/regionarray/Array.x10"
                final x10.lang.FailedDynamicCheckException t$141661 = new x10.lang.FailedDynamicCheckException("x10.regionarray.Region{self!=null}");
                
                //#line 124 "x10/regionarray/Array.x10"
                throw t$141661;
            }
            
            //#line 124 "x10/regionarray/Array.x10"
            final long t$141662 = reg.rank;
            
            //#line 124 "x10/regionarray/Array.x10"
            final boolean t$141663 = reg.rect;
            
            //#line 124 "x10/regionarray/Array.x10"
            final boolean t$141664 = reg.zeroBased;
            
            //#line 124 "x10/regionarray/Array.x10"
            final boolean t$141665 = reg.rail;
            
            //#line 124 "x10/regionarray/Array.x10"
            final long t$141666 = reg.size$O();
            
            //#line 124 "x10/regionarray/Array.x10"
            this.region = ((x10.regionarray.Region)(t$141658));
            this.rank = t$141662;
            this.rect = t$141663;
            this.zeroBased = t$141664;
            this.rail = t$141665;
            this.size = t$141666;
            
            
            //#line 125 "x10/regionarray/Array.x10"
            final x10.regionarray.Array.LayoutHelper crh = new x10.regionarray.Array.LayoutHelper((java.lang.System[]) null);
            
            //#line 125 "x10/regionarray/Array.x10"
            crh.x10$regionarray$Array$LayoutHelper$$init$S(((x10.regionarray.Region)(reg)));
            
            //#line 126 "x10/regionarray/Array.x10"
            final long t$139803 = crh.min0;
            
            //#line 126 "x10/regionarray/Array.x10"
            ((x10.regionarray.Array<$T>)this).layout_min0 = t$139803;
            
            //#line 127 "x10/regionarray/Array.x10"
            final long t$139804 = crh.stride1;
            
            //#line 127 "x10/regionarray/Array.x10"
            ((x10.regionarray.Array<$T>)this).layout_stride1 = t$139804;
            
            //#line 128 "x10/regionarray/Array.x10"
            final long t$139805 = crh.min1;
            
            //#line 128 "x10/regionarray/Array.x10"
            ((x10.regionarray.Array<$T>)this).layout_min1 = t$139805;
            
            //#line 129 "x10/regionarray/Array.x10"
            final x10.core.Rail t$139806 = ((x10.core.Rail)(crh.layout));
            
            //#line 129 "x10/regionarray/Array.x10"
            ((x10.regionarray.Array<$T>)this).layout = ((x10.core.Rail)(t$139806));
            
            //#line 130 "x10/regionarray/Array.x10"
            final long n = crh.size;
            
            //#line 131 "x10/regionarray/Array.x10"
            final x10.core.Rail t$139807 = ((x10.core.Rail)(new x10.core.Rail<$T>($T, ((long)(n)))));
            
            //#line 131 "x10/regionarray/Array.x10"
            ((x10.regionarray.Array<$T>)this).raw = ((x10.core.Rail)(t$139807));
        }
        return this;
    }
    
    
    
    //#line 140 "x10/regionarray/Array.x10"
    // creation method for java code (1-phase java constructor)
    public Array(final x10.rtt.Type $T, final boolean zeroed, final x10.regionarray.Region reg) {
        this((java.lang.System[]) null, $T);
        x10$regionarray$Array$$init$S(zeroed, reg);
    }
    
    // constructor for non-virtual call
    final public x10.regionarray.Array<$T> x10$regionarray$Array$$init$S(final boolean zeroed, final x10.regionarray.Region reg) {
         {
            
            //#line 142 "x10/regionarray/Array.x10"
            final x10.regionarray.Region t$141668 = ((x10.regionarray.Region)
                                                      reg);
            
            //#line 142 "x10/regionarray/Array.x10"
            final boolean t$141669 = ((t$141668) != (null));
            
            //#line 142 "x10/regionarray/Array.x10"
            final boolean t$141670 = !(t$141669);
            
            //#line 142 "x10/regionarray/Array.x10"
            if (t$141670) {
                
                //#line 142 "x10/regionarray/Array.x10"
                final x10.lang.FailedDynamicCheckException t$141671 = new x10.lang.FailedDynamicCheckException("x10.regionarray.Region{self!=null}");
                
                //#line 142 "x10/regionarray/Array.x10"
                throw t$141671;
            }
            
            //#line 142 "x10/regionarray/Array.x10"
            final long t$141672 = reg.rank;
            
            //#line 142 "x10/regionarray/Array.x10"
            final boolean t$141673 = reg.rect;
            
            //#line 142 "x10/regionarray/Array.x10"
            final boolean t$141674 = reg.zeroBased;
            
            //#line 142 "x10/regionarray/Array.x10"
            final boolean t$141675 = reg.rail;
            
            //#line 142 "x10/regionarray/Array.x10"
            final long t$141676 = reg.size$O();
            
            //#line 142 "x10/regionarray/Array.x10"
            this.region = ((x10.regionarray.Region)(t$141668));
            this.rank = t$141672;
            this.rect = t$141673;
            this.zeroBased = t$141674;
            this.rail = t$141675;
            this.size = t$141676;
            
            
            //#line 143 "x10/regionarray/Array.x10"
            final x10.regionarray.Array.LayoutHelper crh = new x10.regionarray.Array.LayoutHelper((java.lang.System[]) null);
            
            //#line 143 "x10/regionarray/Array.x10"
            crh.x10$regionarray$Array$LayoutHelper$$init$S(((x10.regionarray.Region)(reg)));
            
            //#line 144 "x10/regionarray/Array.x10"
            final long t$139816 = crh.min0;
            
            //#line 144 "x10/regionarray/Array.x10"
            ((x10.regionarray.Array<$T>)this).layout_min0 = t$139816;
            
            //#line 145 "x10/regionarray/Array.x10"
            final long t$139817 = crh.stride1;
            
            //#line 145 "x10/regionarray/Array.x10"
            ((x10.regionarray.Array<$T>)this).layout_stride1 = t$139817;
            
            //#line 146 "x10/regionarray/Array.x10"
            final long t$139818 = crh.min1;
            
            //#line 146 "x10/regionarray/Array.x10"
            ((x10.regionarray.Array<$T>)this).layout_min1 = t$139818;
            
            //#line 147 "x10/regionarray/Array.x10"
            final x10.core.Rail t$139819 = ((x10.core.Rail)(crh.layout));
            
            //#line 147 "x10/regionarray/Array.x10"
            ((x10.regionarray.Array<$T>)this).layout = ((x10.core.Rail)(t$139819));
            
            //#line 148 "x10/regionarray/Array.x10"
            final long n = crh.size;
            
            //#line 149 "x10/regionarray/Array.x10"
            if (zeroed) {
                
                //#line 150 "x10/regionarray/Array.x10"
                final x10.core.Rail t$139820 = ((x10.core.Rail)(new x10.core.Rail<$T>($T, ((long)(n)))));
                
                //#line 150 "x10/regionarray/Array.x10"
                ((x10.regionarray.Array<$T>)this).raw = ((x10.core.Rail)(t$139820));
            } else {
                
                //#line 152 "x10/regionarray/Array.x10"
                final x10.core.Rail t$139821 = ((x10.core.Rail)(x10.core.Rail.<$T>makeUnsafe($T, ((long)(n)), false)));
                
                //#line 152 "x10/regionarray/Array.x10"
                ((x10.regionarray.Array<$T>)this).raw = ((x10.core.Rail)(t$139821));
            }
        }
        return this;
    }
    
    
    
    //#line 172 "x10/regionarray/Array.x10"
    /**
     * Construct an Array over the region reg whose
     * values are initialized as specified by the init function.
     * The function will be evaluated exactly once for each point
     * in reg in an arbitrary order to 
     * compute the initial value for each array element.</p>
     * 
     * It is unspecified whether the function evaluations will
     * be done sequentially for each point by the current activity 
     * or concurrently for disjoint sets of points by one or more 
     * child activities. 
     * 
     * @param reg The region over which to construct the array.
     * @param init The function to use to initialize the array.
     */
    // creation method for java code (1-phase java constructor)
    public Array(final x10.rtt.Type $T, final x10.regionarray.Region reg, final x10.core.fun.Fun_0_1<x10.lang.Point,$T> init, __1$1x10$lang$Point$3x10$regionarray$Array$$T$2 $dummy) {
        this((java.lang.System[]) null, $T);
        x10$regionarray$Array$$init$S(reg, init, (x10.regionarray.Array.__1$1x10$lang$Point$3x10$regionarray$Array$$T$2) null);
    }
    
    // constructor for non-virtual call
    final public x10.regionarray.Array<$T> x10$regionarray$Array$$init$S(final x10.regionarray.Region reg, final x10.core.fun.Fun_0_1<x10.lang.Point,$T> init, __1$1x10$lang$Point$3x10$regionarray$Array$$T$2 $dummy) {
         {
            
            //#line 174 "x10/regionarray/Array.x10"
            final x10.regionarray.Region t$141678 = ((x10.regionarray.Region)
                                                      reg);
            
            //#line 174 "x10/regionarray/Array.x10"
            final boolean t$141679 = ((t$141678) != (null));
            
            //#line 174 "x10/regionarray/Array.x10"
            final boolean t$141680 = !(t$141679);
            
            //#line 174 "x10/regionarray/Array.x10"
            if (t$141680) {
                
                //#line 174 "x10/regionarray/Array.x10"
                final x10.lang.FailedDynamicCheckException t$141681 = new x10.lang.FailedDynamicCheckException("x10.regionarray.Region{self!=null}");
                
                //#line 174 "x10/regionarray/Array.x10"
                throw t$141681;
            }
            
            //#line 174 "x10/regionarray/Array.x10"
            final long t$141682 = reg.rank;
            
            //#line 174 "x10/regionarray/Array.x10"
            final boolean t$141683 = reg.rect;
            
            //#line 174 "x10/regionarray/Array.x10"
            final boolean t$141684 = reg.zeroBased;
            
            //#line 174 "x10/regionarray/Array.x10"
            final boolean t$141685 = reg.rail;
            
            //#line 174 "x10/regionarray/Array.x10"
            final long t$141686 = reg.size$O();
            
            //#line 174 "x10/regionarray/Array.x10"
            this.region = ((x10.regionarray.Region)(t$141678));
            this.rank = t$141682;
            this.rect = t$141683;
            this.zeroBased = t$141684;
            this.rail = t$141685;
            this.size = t$141686;
            
            
            //#line 175 "x10/regionarray/Array.x10"
            final x10.regionarray.Array.LayoutHelper crh = new x10.regionarray.Array.LayoutHelper((java.lang.System[]) null);
            
            //#line 175 "x10/regionarray/Array.x10"
            crh.x10$regionarray$Array$LayoutHelper$$init$S(((x10.regionarray.Region)(reg)));
            
            //#line 176 "x10/regionarray/Array.x10"
            final long t$139830 = crh.min0;
            
            //#line 176 "x10/regionarray/Array.x10"
            ((x10.regionarray.Array<$T>)this).layout_min0 = t$139830;
            
            //#line 177 "x10/regionarray/Array.x10"
            final long t$139831 = crh.stride1;
            
            //#line 177 "x10/regionarray/Array.x10"
            ((x10.regionarray.Array<$T>)this).layout_stride1 = t$139831;
            
            //#line 178 "x10/regionarray/Array.x10"
            final long t$139832 = crh.min1;
            
            //#line 178 "x10/regionarray/Array.x10"
            ((x10.regionarray.Array<$T>)this).layout_min1 = t$139832;
            
            //#line 179 "x10/regionarray/Array.x10"
            final x10.core.Rail t$139833 = ((x10.core.Rail)(crh.layout));
            
            //#line 179 "x10/regionarray/Array.x10"
            ((x10.regionarray.Array<$T>)this).layout = ((x10.core.Rail)(t$139833));
            
            //#line 180 "x10/regionarray/Array.x10"
            final long n = crh.size;
            
            //#line 181 "x10/regionarray/Array.x10"
            final x10.core.Rail r = ((x10.core.Rail)(x10.core.Rail.<$T>makeUnsafe($T, ((long)(n)), false)));
            
            //#line 182 "x10/regionarray/Array.x10"
            final x10.lang.Iterator p$141728 = reg.iterator();
            
            //#line 182 "x10/regionarray/Array.x10"
            for (;
                 true;
                 ) {
                
                //#line 182 "x10/regionarray/Array.x10"
                final boolean t$141729 = ((x10.lang.Iterator<x10.lang.Point>)p$141728).hasNext$O();
                
                //#line 182 "x10/regionarray/Array.x10"
                if (!(t$141729)) {
                    
                    //#line 182 "x10/regionarray/Array.x10"
                    break;
                }
                
                //#line 182 "x10/regionarray/Array.x10"
                final x10.lang.Point p$141709 = ((x10.lang.Point)(((x10.lang.Iterator<x10.lang.Point>)p$141728).next$G()));
                
                //#line 183 "x10/regionarray/Array.x10"
                final x10.regionarray.Array this$141710 = ((x10.regionarray.Array)(this));
                
                //#line 1315 . "x10/regionarray/Array.x10"
                final long t$141712 = ((long)(((int)(0))));
                
                //#line 1315 . "x10/regionarray/Array.x10"
                final long t$141713 = p$141709.$apply$O((long)(t$141712));
                
                //#line 1315 . "x10/regionarray/Array.x10"
                final long t$141714 = ((x10.regionarray.Array<$T>)this$141710).layout_min0;
                
                //#line 1315 . "x10/regionarray/Array.x10"
                long offset$141715 = ((t$141713) - (((long)(t$141714))));
                
                //#line 1316 . "x10/regionarray/Array.x10"
                final long t$141716 = p$141709.rank;
                
                //#line 1316 . "x10/regionarray/Array.x10"
                final boolean t$141717 = ((t$141716) > (((long)(1L))));
                
                //#line 1316 . "x10/regionarray/Array.x10"
                if (t$141717) {
                    
                    //#line 1317 . "x10/regionarray/Array.x10"
                    final long t$141719 = ((x10.regionarray.Array<$T>)this$141710).layout_stride1;
                    
                    //#line 1317 . "x10/regionarray/Array.x10"
                    final long t$141720 = ((offset$141715) * (((long)(t$141719))));
                    
                    //#line 1317 . "x10/regionarray/Array.x10"
                    final long t$141721 = p$141709.$apply$O((long)(1L));
                    
                    //#line 1317 . "x10/regionarray/Array.x10"
                    final long t$141722 = ((t$141720) + (((long)(t$141721))));
                    
                    //#line 1317 . "x10/regionarray/Array.x10"
                    final long t$141723 = ((x10.regionarray.Array<$T>)this$141710).layout_min1;
                    
                    //#line 1317 . "x10/regionarray/Array.x10"
                    final long t$141724 = ((t$141722) - (((long)(t$141723))));
                    
                    //#line 1317 . "x10/regionarray/Array.x10"
                    offset$141715 = t$141724;
                    
                    //#line 1318 . "x10/regionarray/Array.x10"
                    final long t$141707 = p$141709.rank;
                    
                    //#line 1318 . "x10/regionarray/Array.x10"
                    final long i$138773max$141708 = ((t$141707) - (((long)(1L))));
                    
                    //#line 1318 . "x10/regionarray/Array.x10"
                    long i$141704 = 2L;
                    
                    //#line 1318 . "x10/regionarray/Array.x10"
                    for (;
                         true;
                         ) {
                        
                        //#line 1318 . "x10/regionarray/Array.x10"
                        final boolean t$141706 = ((i$141704) <= (((long)(i$138773max$141708))));
                        
                        //#line 1318 . "x10/regionarray/Array.x10"
                        if (!(t$141706)) {
                            
                            //#line 1318 . "x10/regionarray/Array.x10"
                            break;
                        }
                        
                        //#line 1319 . "x10/regionarray/Array.x10"
                        final x10.core.Rail t$141688 = ((x10.core.Rail)(((x10.regionarray.Array<$T>)this$141710).layout));
                        
                        //#line 1319 . "x10/regionarray/Array.x10"
                        final long t$141689 = ((i$141704) - (((long)(2L))));
                        
                        //#line 1319 . "x10/regionarray/Array.x10"
                        final long t$141690 = ((2L) * (((long)(t$141689))));
                        
                        //#line 1319 . "x10/regionarray/Array.x10"
                        final long t$141691 = ((long[])t$141688.value)[(int)t$141690];
                        
                        //#line 1319 . "x10/regionarray/Array.x10"
                        final long t$141692 = ((offset$141715) * (((long)(t$141691))));
                        
                        //#line 1319 . "x10/regionarray/Array.x10"
                        final long t$141693 = p$141709.$apply$O((long)(i$141704));
                        
                        //#line 1319 . "x10/regionarray/Array.x10"
                        final long t$141694 = ((t$141692) + (((long)(t$141693))));
                        
                        //#line 1319 . "x10/regionarray/Array.x10"
                        final x10.core.Rail t$141695 = ((x10.core.Rail)(((x10.regionarray.Array<$T>)this$141710).layout));
                        
                        //#line 1319 . "x10/regionarray/Array.x10"
                        final long t$141696 = ((i$141704) - (((long)(2L))));
                        
                        //#line 1319 . "x10/regionarray/Array.x10"
                        final long t$141697 = ((2L) * (((long)(t$141696))));
                        
                        //#line 1319 . "x10/regionarray/Array.x10"
                        final long t$141698 = ((t$141697) + (((long)(1L))));
                        
                        //#line 1319 . "x10/regionarray/Array.x10"
                        final long t$141699 = ((long[])t$141695.value)[(int)t$141698];
                        
                        //#line 1319 . "x10/regionarray/Array.x10"
                        final long t$141700 = ((t$141694) - (((long)(t$141699))));
                        
                        //#line 1319 . "x10/regionarray/Array.x10"
                        offset$141715 = t$141700;
                        
                        //#line 1318 . "x10/regionarray/Array.x10"
                        final long t$141703 = ((i$141704) + (((long)(1L))));
                        
                        //#line 1318 . "x10/regionarray/Array.x10"
                        i$141704 = t$141703;
                    }
                }
                
                //#line 183 "x10/regionarray/Array.x10"
                final $T t$141726 = (($T)((($T)
                                            ((x10.core.fun.Fun_0_1<x10.lang.Point,$T>)init).$apply(p$141709, x10.lang.Point.$RTT))));
                
                //#line 183 "x10/regionarray/Array.x10"
                ((x10.core.Rail<$T>)r).$set__1x10$lang$Rail$$T$G((long)(offset$141715), (($T)(t$141726)));
            }
            
            //#line 185 "x10/regionarray/Array.x10"
            ((x10.regionarray.Array<$T>)this).raw = ((x10.core.Rail)(r));
        }
        return this;
    }
    
    
    
    //#line 195 "x10/regionarray/Array.x10"
    /**
     * Construct an Array over the region reg whose
     * values are initialized to be init.
     * 
     * @param reg The region over which to construct the array.
     * @param init The function to use to initialize the array.
     */
    // creation method for java code (1-phase java constructor)
    public Array(final x10.rtt.Type $T, final x10.regionarray.Region reg, final $T init, __1x10$regionarray$Array$$T $dummy) {
        this((java.lang.System[]) null, $T);
        x10$regionarray$Array$$init$S(reg, init, (x10.regionarray.Array.__1x10$regionarray$Array$$T) null);
    }
    
    // constructor for non-virtual call
    final public x10.regionarray.Array<$T> x10$regionarray$Array$$init$S(final x10.regionarray.Region reg, final $T init, __1x10$regionarray$Array$$T $dummy) {
         {
            
            //#line 197 "x10/regionarray/Array.x10"
            final x10.regionarray.Region t$141730 = ((x10.regionarray.Region)
                                                      reg);
            
            //#line 197 "x10/regionarray/Array.x10"
            final boolean t$141731 = ((t$141730) != (null));
            
            //#line 197 "x10/regionarray/Array.x10"
            final boolean t$141732 = !(t$141731);
            
            //#line 197 "x10/regionarray/Array.x10"
            if (t$141732) {
                
                //#line 197 "x10/regionarray/Array.x10"
                final x10.lang.FailedDynamicCheckException t$141733 = new x10.lang.FailedDynamicCheckException("x10.regionarray.Region{self!=null}");
                
                //#line 197 "x10/regionarray/Array.x10"
                throw t$141733;
            }
            
            //#line 197 "x10/regionarray/Array.x10"
            final long t$141734 = reg.rank;
            
            //#line 197 "x10/regionarray/Array.x10"
            final boolean t$141735 = reg.rect;
            
            //#line 197 "x10/regionarray/Array.x10"
            final boolean t$141736 = reg.zeroBased;
            
            //#line 197 "x10/regionarray/Array.x10"
            final boolean t$141737 = reg.rail;
            
            //#line 197 "x10/regionarray/Array.x10"
            final long t$141738 = reg.size$O();
            
            //#line 197 "x10/regionarray/Array.x10"
            this.region = ((x10.regionarray.Region)(t$141730));
            this.rank = t$141734;
            this.rect = t$141735;
            this.zeroBased = t$141736;
            this.rail = t$141737;
            this.size = t$141738;
            
            
            //#line 199 "x10/regionarray/Array.x10"
            final x10.regionarray.Array.LayoutHelper crh = new x10.regionarray.Array.LayoutHelper((java.lang.System[]) null);
            
            //#line 199 "x10/regionarray/Array.x10"
            crh.x10$regionarray$Array$LayoutHelper$$init$S(((x10.regionarray.Region)(reg)));
            
            //#line 200 "x10/regionarray/Array.x10"
            final long t$139878 = crh.min0;
            
            //#line 200 "x10/regionarray/Array.x10"
            ((x10.regionarray.Array<$T>)this).layout_min0 = t$139878;
            
            //#line 201 "x10/regionarray/Array.x10"
            final long t$139879 = crh.stride1;
            
            //#line 201 "x10/regionarray/Array.x10"
            ((x10.regionarray.Array<$T>)this).layout_stride1 = t$139879;
            
            //#line 202 "x10/regionarray/Array.x10"
            final long t$139880 = crh.min1;
            
            //#line 202 "x10/regionarray/Array.x10"
            ((x10.regionarray.Array<$T>)this).layout_min1 = t$139880;
            
            //#line 203 "x10/regionarray/Array.x10"
            final x10.core.Rail t$139881 = ((x10.core.Rail)(crh.layout));
            
            //#line 203 "x10/regionarray/Array.x10"
            ((x10.regionarray.Array<$T>)this).layout = ((x10.core.Rail)(t$139881));
            
            //#line 204 "x10/regionarray/Array.x10"
            final long n = crh.size;
            
            //#line 205 "x10/regionarray/Array.x10"
            final x10.core.Rail r = ((x10.core.Rail)(x10.core.Rail.<$T>makeUnsafe($T, ((long)(n)), false)));
            
            //#line 206 "x10/regionarray/Array.x10"
            final boolean t$139922 = reg.rect;
            
            //#line 206 "x10/regionarray/Array.x10"
            if (t$139922) {
                
                //#line 209 "x10/regionarray/Array.x10"
                final long i$138549max$138551 = ((x10.core.Rail<$T>)r).size;
                
                //#line 209 "x10/regionarray/Array.x10"
                long i$141742 = 0L;
                
                //#line 209 "x10/regionarray/Array.x10"
                for (;
                     true;
                     ) {
                    
                    //#line 209 "x10/regionarray/Array.x10"
                    final boolean t$141744 = ((i$141742) < (((long)(i$138549max$138551))));
                    
                    //#line 209 "x10/regionarray/Array.x10"
                    if (!(t$141744)) {
                        
                        //#line 209 "x10/regionarray/Array.x10"
                        break;
                    }
                    
                    //#line 210 "x10/regionarray/Array.x10"
                    ((x10.core.Rail<$T>)r).$set__1x10$lang$Rail$$T$G((long)(i$141742), (($T)(init)));
                    
                    //#line 209 "x10/regionarray/Array.x10"
                    final long t$141741 = ((i$141742) + (((long)(1L))));
                    
                    //#line 209 "x10/regionarray/Array.x10"
                    i$141742 = t$141741;
                }
            } else {
                
                //#line 213 "x10/regionarray/Array.x10"
                final x10.lang.Iterator p$138568 = reg.iterator();
                
                //#line 213 "x10/regionarray/Array.x10"
                for (;
                     true;
                     ) {
                    
                    //#line 213 "x10/regionarray/Array.x10"
                    final boolean t$139921 = ((x10.lang.Iterator<x10.lang.Point>)p$138568).hasNext$O();
                    
                    //#line 213 "x10/regionarray/Array.x10"
                    if (!(t$139921)) {
                        
                        //#line 213 "x10/regionarray/Array.x10"
                        break;
                    }
                    
                    //#line 213 "x10/regionarray/Array.x10"
                    final x10.lang.Point p$141767 = ((x10.lang.Point)(((x10.lang.Iterator<x10.lang.Point>)p$138568).next$G()));
                    
                    //#line 214 "x10/regionarray/Array.x10"
                    final x10.regionarray.Array this$141768 = ((x10.regionarray.Array)(this));
                    
                    //#line 1315 . "x10/regionarray/Array.x10"
                    final long t$141770 = ((long)(((int)(0))));
                    
                    //#line 1315 . "x10/regionarray/Array.x10"
                    final long t$141771 = p$141767.$apply$O((long)(t$141770));
                    
                    //#line 1315 . "x10/regionarray/Array.x10"
                    final long t$141772 = ((x10.regionarray.Array<$T>)this$141768).layout_min0;
                    
                    //#line 1315 . "x10/regionarray/Array.x10"
                    long offset$141773 = ((t$141771) - (((long)(t$141772))));
                    
                    //#line 1316 . "x10/regionarray/Array.x10"
                    final long t$141774 = p$141767.rank;
                    
                    //#line 1316 . "x10/regionarray/Array.x10"
                    final boolean t$141775 = ((t$141774) > (((long)(1L))));
                    
                    //#line 1316 . "x10/regionarray/Array.x10"
                    if (t$141775) {
                        
                        //#line 1317 . "x10/regionarray/Array.x10"
                        final long t$141777 = ((x10.regionarray.Array<$T>)this$141768).layout_stride1;
                        
                        //#line 1317 . "x10/regionarray/Array.x10"
                        final long t$141778 = ((offset$141773) * (((long)(t$141777))));
                        
                        //#line 1317 . "x10/regionarray/Array.x10"
                        final long t$141779 = p$141767.$apply$O((long)(1L));
                        
                        //#line 1317 . "x10/regionarray/Array.x10"
                        final long t$141780 = ((t$141778) + (((long)(t$141779))));
                        
                        //#line 1317 . "x10/regionarray/Array.x10"
                        final long t$141781 = ((x10.regionarray.Array<$T>)this$141768).layout_min1;
                        
                        //#line 1317 . "x10/regionarray/Array.x10"
                        final long t$141782 = ((t$141780) - (((long)(t$141781))));
                        
                        //#line 1317 . "x10/regionarray/Array.x10"
                        offset$141773 = t$141782;
                        
                        //#line 1318 . "x10/regionarray/Array.x10"
                        final long t$141765 = p$141767.rank;
                        
                        //#line 1318 . "x10/regionarray/Array.x10"
                        final long i$138773max$141766 = ((t$141765) - (((long)(1L))));
                        
                        //#line 1318 . "x10/regionarray/Array.x10"
                        long i$141762 = 2L;
                        
                        //#line 1318 . "x10/regionarray/Array.x10"
                        for (;
                             true;
                             ) {
                            
                            //#line 1318 . "x10/regionarray/Array.x10"
                            final boolean t$141764 = ((i$141762) <= (((long)(i$138773max$141766))));
                            
                            //#line 1318 . "x10/regionarray/Array.x10"
                            if (!(t$141764)) {
                                
                                //#line 1318 . "x10/regionarray/Array.x10"
                                break;
                            }
                            
                            //#line 1319 . "x10/regionarray/Array.x10"
                            final x10.core.Rail t$141746 = ((x10.core.Rail)(((x10.regionarray.Array<$T>)this$141768).layout));
                            
                            //#line 1319 . "x10/regionarray/Array.x10"
                            final long t$141747 = ((i$141762) - (((long)(2L))));
                            
                            //#line 1319 . "x10/regionarray/Array.x10"
                            final long t$141748 = ((2L) * (((long)(t$141747))));
                            
                            //#line 1319 . "x10/regionarray/Array.x10"
                            final long t$141749 = ((long[])t$141746.value)[(int)t$141748];
                            
                            //#line 1319 . "x10/regionarray/Array.x10"
                            final long t$141750 = ((offset$141773) * (((long)(t$141749))));
                            
                            //#line 1319 . "x10/regionarray/Array.x10"
                            final long t$141751 = p$141767.$apply$O((long)(i$141762));
                            
                            //#line 1319 . "x10/regionarray/Array.x10"
                            final long t$141752 = ((t$141750) + (((long)(t$141751))));
                            
                            //#line 1319 . "x10/regionarray/Array.x10"
                            final x10.core.Rail t$141753 = ((x10.core.Rail)(((x10.regionarray.Array<$T>)this$141768).layout));
                            
                            //#line 1319 . "x10/regionarray/Array.x10"
                            final long t$141754 = ((i$141762) - (((long)(2L))));
                            
                            //#line 1319 . "x10/regionarray/Array.x10"
                            final long t$141755 = ((2L) * (((long)(t$141754))));
                            
                            //#line 1319 . "x10/regionarray/Array.x10"
                            final long t$141756 = ((t$141755) + (((long)(1L))));
                            
                            //#line 1319 . "x10/regionarray/Array.x10"
                            final long t$141757 = ((long[])t$141753.value)[(int)t$141756];
                            
                            //#line 1319 . "x10/regionarray/Array.x10"
                            final long t$141758 = ((t$141752) - (((long)(t$141757))));
                            
                            //#line 1319 . "x10/regionarray/Array.x10"
                            offset$141773 = t$141758;
                            
                            //#line 1318 . "x10/regionarray/Array.x10"
                            final long t$141761 = ((i$141762) + (((long)(1L))));
                            
                            //#line 1318 . "x10/regionarray/Array.x10"
                            i$141762 = t$141761;
                        }
                    }
                    
                    //#line 214 "x10/regionarray/Array.x10"
                    ((x10.core.Rail<$T>)r).$set__1x10$lang$Rail$$T$G((long)(offset$141773), (($T)(init)));
                }
            }
            
            //#line 217 "x10/regionarray/Array.x10"
            ((x10.regionarray.Array<$T>)this).raw = ((x10.core.Rail)(r));
        }
        return this;
    }
    
    
    
    //#line 231 "x10/regionarray/Array.x10"
    /**
     * Construct an Array view of a backing Rail
     * using the argument region to define how to map Points into
     * offsets in the backingStorage.  The size of the Rail
     * must be at least as large as the number of points in the boundingBox
     * of the given Region.
     * 
     * @param reg The region over which to define the array.
     * @param backingStore The backing storage for the array data.
     */
    // creation method for java code (1-phase java constructor)
    public Array(final x10.rtt.Type $T, final x10.regionarray.Region reg, final x10.core.Rail<$T> backingStore, __1$1x10$regionarray$Array$$T$2 $dummy) {
        this((java.lang.System[]) null, $T);
        x10$regionarray$Array$$init$S(reg, backingStore, (x10.regionarray.Array.__1$1x10$regionarray$Array$$T$2) null);
    }
    
    // constructor for non-virtual call
    final public x10.regionarray.Array<$T> x10$regionarray$Array$$init$S(final x10.regionarray.Region reg, final x10.core.Rail<$T> backingStore, __1$1x10$regionarray$Array$$T$2 $dummy) {
         {
            
            //#line 233 "x10/regionarray/Array.x10"
            final x10.regionarray.Region t$141785 = ((x10.regionarray.Region)
                                                      reg);
            
            //#line 233 "x10/regionarray/Array.x10"
            final boolean t$141786 = ((t$141785) != (null));
            
            //#line 233 "x10/regionarray/Array.x10"
            final boolean t$141787 = !(t$141786);
            
            //#line 233 "x10/regionarray/Array.x10"
            if (t$141787) {
                
                //#line 233 "x10/regionarray/Array.x10"
                final x10.lang.FailedDynamicCheckException t$141788 = new x10.lang.FailedDynamicCheckException("x10.regionarray.Region{self!=null}");
                
                //#line 233 "x10/regionarray/Array.x10"
                throw t$141788;
            }
            
            //#line 233 "x10/regionarray/Array.x10"
            final long t$141789 = reg.rank;
            
            //#line 233 "x10/regionarray/Array.x10"
            final boolean t$141790 = reg.rect;
            
            //#line 233 "x10/regionarray/Array.x10"
            final boolean t$141791 = reg.zeroBased;
            
            //#line 233 "x10/regionarray/Array.x10"
            final boolean t$141792 = reg.rail;
            
            //#line 233 "x10/regionarray/Array.x10"
            final long t$141793 = reg.size$O();
            
            //#line 233 "x10/regionarray/Array.x10"
            this.region = ((x10.regionarray.Region)(t$141785));
            this.rank = t$141789;
            this.rect = t$141790;
            this.zeroBased = t$141791;
            this.rail = t$141792;
            this.size = t$141793;
            
            
            //#line 235 "x10/regionarray/Array.x10"
            final x10.regionarray.Array.LayoutHelper crh = new x10.regionarray.Array.LayoutHelper((java.lang.System[]) null);
            
            //#line 235 "x10/regionarray/Array.x10"
            crh.x10$regionarray$Array$LayoutHelper$$init$S(((x10.regionarray.Region)(reg)));
            
            //#line 236 "x10/regionarray/Array.x10"
            final long t$139931 = crh.min0;
            
            //#line 236 "x10/regionarray/Array.x10"
            ((x10.regionarray.Array<$T>)this).layout_min0 = t$139931;
            
            //#line 237 "x10/regionarray/Array.x10"
            final long t$139932 = crh.stride1;
            
            //#line 237 "x10/regionarray/Array.x10"
            ((x10.regionarray.Array<$T>)this).layout_stride1 = t$139932;
            
            //#line 238 "x10/regionarray/Array.x10"
            final long t$139933 = crh.min1;
            
            //#line 238 "x10/regionarray/Array.x10"
            ((x10.regionarray.Array<$T>)this).layout_min1 = t$139933;
            
            //#line 239 "x10/regionarray/Array.x10"
            final x10.core.Rail t$139934 = ((x10.core.Rail)(crh.layout));
            
            //#line 239 "x10/regionarray/Array.x10"
            ((x10.regionarray.Array<$T>)this).layout = ((x10.core.Rail)(t$139934));
            
            //#line 240 "x10/regionarray/Array.x10"
            final long n = crh.size;
            
            //#line 241 "x10/regionarray/Array.x10"
            final long t$139935 = ((x10.core.Rail<$T>)backingStore).size;
            
            //#line 241 "x10/regionarray/Array.x10"
            final boolean t$139937 = ((n) > (((long)(t$139935))));
            
            //#line 241 "x10/regionarray/Array.x10"
            if (t$139937) {
                
                //#line 242 "x10/regionarray/Array.x10"
                final java.lang.IllegalArgumentException t$139936 = ((java.lang.IllegalArgumentException)(new java.lang.IllegalArgumentException("backingStore too small")));
                
                //#line 242 "x10/regionarray/Array.x10"
                throw t$139936;
            }
            
            //#line 244 "x10/regionarray/Array.x10"
            final x10.core.Rail t$136683 = ((x10.core.Rail<$T>)
                                             backingStore);
            
            //#line 244 "x10/regionarray/Array.x10"
            final boolean t$139938 = ((t$136683) != (null));
            
            //#line 244 "x10/regionarray/Array.x10"
            final boolean t$139940 = !(t$139938);
            
            //#line 244 "x10/regionarray/Array.x10"
            if (t$139940) {
                
                //#line 244 "x10/regionarray/Array.x10"
                final x10.lang.FailedDynamicCheckException t$139939 = new x10.lang.FailedDynamicCheckException("x10.lang.Rail[T]{self!=null}");
                
                //#line 244 "x10/regionarray/Array.x10"
                throw t$139939;
            }
            
            //#line 244 "x10/regionarray/Array.x10"
            ((x10.regionarray.Array<$T>)this).raw = ((x10.core.Rail)(t$136683));
        }
        return this;
    }
    
    
    
    //#line 253 "x10/regionarray/Array.x10"
    /**
     * Construct an Array view of a backing Rail
     * using the region 0..(backingStore.size-1)
     * 
     * @param backingStore The backing storage for the array data.
     */
    // creation method for java code (1-phase java constructor)
    public Array(final x10.rtt.Type $T, final x10.core.Rail<$T> backingStore, __0$1x10$regionarray$Array$$T$2 $dummy) {
        this((java.lang.System[]) null, $T);
        x10$regionarray$Array$$init$S(backingStore, (x10.regionarray.Array.__0$1x10$regionarray$Array$$T$2) null);
    }
    
    // constructor for non-virtual call
    final public x10.regionarray.Array<$T> x10$regionarray$Array$$init$S(final x10.core.Rail<$T> backingStore, __0$1x10$regionarray$Array$$T$2 $dummy) {
         {
            
            //#line 255 "x10/regionarray/Array.x10"
            final long s = ((x10.core.Rail<$T>)backingStore).size;
            
            //#line 256 "x10/regionarray/Array.x10"
            final x10.regionarray.RectRegion1D myReg = ((x10.regionarray.RectRegion1D)(new x10.regionarray.RectRegion1D((java.lang.System[]) null)));
            
            //#line 256 "x10/regionarray/Array.x10"
            final long t$141795 = ((s) - (((long)(1L))));
            
            //#line 256 "x10/regionarray/Array.x10"
            myReg.x10$regionarray$RectRegion1D$$init$S(t$141795);
            
            //#line 257 "x10/regionarray/Array.x10"
            this.region = ((x10.regionarray.Region)(myReg));
            this.rank = 1L;
            this.rect = true;
            this.zeroBased = true;
            this.rail = true;
            this.size = s;
            
            
            //#line 259 "x10/regionarray/Array.x10"
            final long t$139942 = ((x10.regionarray.Array<$T>)this).layout_min1 = 0L;
            
            //#line 259 "x10/regionarray/Array.x10"
            final long t$139943 = ((x10.regionarray.Array<$T>)this).layout_stride1 = t$139942;
            
            //#line 259 "x10/regionarray/Array.x10"
            ((x10.regionarray.Array<$T>)this).layout_min0 = t$139943;
            
            //#line 260 "x10/regionarray/Array.x10"
            ((x10.regionarray.Array<$T>)this).layout = null;
            
            //#line 261 "x10/regionarray/Array.x10"
            final x10.core.Rail t$136692 = ((x10.core.Rail<$T>)
                                             backingStore);
            
            //#line 261 "x10/regionarray/Array.x10"
            final boolean t$139944 = ((t$136692) != (null));
            
            //#line 261 "x10/regionarray/Array.x10"
            final boolean t$139946 = !(t$139944);
            
            //#line 261 "x10/regionarray/Array.x10"
            if (t$139946) {
                
                //#line 261 "x10/regionarray/Array.x10"
                final x10.lang.FailedDynamicCheckException t$139945 = new x10.lang.FailedDynamicCheckException("x10.lang.Rail[T]{self!=null}");
                
                //#line 261 "x10/regionarray/Array.x10"
                throw t$139945;
            }
            
            //#line 261 "x10/regionarray/Array.x10"
            ((x10.regionarray.Array<$T>)this).raw = ((x10.core.Rail)(t$136692));
        }
        return this;
    }
    
    
    
    //#line 268 "x10/regionarray/Array.x10"
    /**
     * Construct Array over the region 0..(size-1) whose elements are zero-initialized.
     */
    // creation method for java code (1-phase java constructor)
    public Array(final x10.rtt.Type $T, final long size) {
        this((java.lang.System[]) null, $T);
        x10$regionarray$Array$$init$S(size);
    }
    
    // constructor for non-virtual call
    final public x10.regionarray.Array<$T> x10$regionarray$Array$$init$S(final long size) {
         {
            
            //#line 270 "x10/regionarray/Array.x10"
            final x10.regionarray.RectRegion1D myReg = ((x10.regionarray.RectRegion1D)(new x10.regionarray.RectRegion1D((java.lang.System[]) null)));
            
            //#line 270 "x10/regionarray/Array.x10"
            final long t$141797 = ((size) - (((long)(1L))));
            
            //#line 270 "x10/regionarray/Array.x10"
            myReg.x10$regionarray$RectRegion1D$$init$S(t$141797);
            
            //#line 271 "x10/regionarray/Array.x10"
            this.region = ((x10.regionarray.Region)(myReg));
            this.rank = 1L;
            this.rect = true;
            this.zeroBased = true;
            this.rail = true;
            this.size = size;
            
            
            //#line 273 "x10/regionarray/Array.x10"
            final long t$139948 = ((x10.regionarray.Array<$T>)this).layout_min1 = 0L;
            
            //#line 273 "x10/regionarray/Array.x10"
            final long t$139949 = ((x10.regionarray.Array<$T>)this).layout_stride1 = t$139948;
            
            //#line 273 "x10/regionarray/Array.x10"
            ((x10.regionarray.Array<$T>)this).layout_min0 = t$139949;
            
            //#line 274 "x10/regionarray/Array.x10"
            ((x10.regionarray.Array<$T>)this).layout = null;
            
            //#line 275 "x10/regionarray/Array.x10"
            final x10.core.Rail t$139950 = ((x10.core.Rail)(new x10.core.Rail<$T>($T, ((long)(size)))));
            
            //#line 275 "x10/regionarray/Array.x10"
            ((x10.regionarray.Array<$T>)this).raw = ((x10.core.Rail)(t$139950));
        }
        return this;
    }
    
    
    
    //#line 282 "x10/regionarray/Array.x10"
    // creation method for java code (1-phase java constructor)
    public Array(final x10.rtt.Type $T, final boolean zeroed, final long size) {
        this((java.lang.System[]) null, $T);
        x10$regionarray$Array$$init$S(zeroed, size);
    }
    
    // constructor for non-virtual call
    final public x10.regionarray.Array<$T> x10$regionarray$Array$$init$S(final boolean zeroed, final long size) {
         {
            
            //#line 284 "x10/regionarray/Array.x10"
            final x10.regionarray.RectRegion1D myReg = ((x10.regionarray.RectRegion1D)(new x10.regionarray.RectRegion1D((java.lang.System[]) null)));
            
            //#line 284 "x10/regionarray/Array.x10"
            final long t$141799 = ((size) - (((long)(1L))));
            
            //#line 284 "x10/regionarray/Array.x10"
            myReg.x10$regionarray$RectRegion1D$$init$S(t$141799);
            
            //#line 285 "x10/regionarray/Array.x10"
            this.region = ((x10.regionarray.Region)(myReg));
            this.rank = 1L;
            this.rect = true;
            this.zeroBased = true;
            this.rail = true;
            this.size = size;
            
            
            //#line 287 "x10/regionarray/Array.x10"
            final long t$139952 = ((x10.regionarray.Array<$T>)this).layout_min1 = 0L;
            
            //#line 287 "x10/regionarray/Array.x10"
            final long t$139953 = ((x10.regionarray.Array<$T>)this).layout_stride1 = t$139952;
            
            //#line 287 "x10/regionarray/Array.x10"
            ((x10.regionarray.Array<$T>)this).layout_min0 = t$139953;
            
            //#line 288 "x10/regionarray/Array.x10"
            ((x10.regionarray.Array<$T>)this).layout = null;
            
            //#line 289 "x10/regionarray/Array.x10"
            if (zeroed) {
                
                //#line 290 "x10/regionarray/Array.x10"
                final x10.core.Rail t$139954 = ((x10.core.Rail)(new x10.core.Rail<$T>($T, ((long)(size)))));
                
                //#line 290 "x10/regionarray/Array.x10"
                ((x10.regionarray.Array<$T>)this).raw = ((x10.core.Rail)(t$139954));
            } else {
                
                //#line 292 "x10/regionarray/Array.x10"
                final x10.core.Rail t$139955 = ((x10.core.Rail)(x10.core.Rail.<$T>makeUnsafe($T, ((long)(size)), false)));
                
                //#line 292 "x10/regionarray/Array.x10"
                ((x10.regionarray.Array<$T>)this).raw = ((x10.core.Rail)(t$139955));
            }
        }
        return this;
    }
    
    
    
    //#line 312 "x10/regionarray/Array.x10"
    /**
     * Construct Array over the region 0..(size-1) whose
     * values are initialized as specified by the init function.
     * The function will be evaluated exactly once for each point
     * in reg in an arbitrary order to 
     * compute the initial value for each array element.</p>
     * 
     * It is unspecified whether the function evaluations will
     * be done sequentially for each point by the current activity 
     * or concurrently for disjoint sets of points by one or more 
     * child activities. 
     * 
     * 
     * @param reg The region over which to construct the array.
     * @param init The function to use to initialize the array.
     */
    // creation method for java code (1-phase java constructor)
    public Array(final x10.rtt.Type $T, final long size, final x10.core.fun.Fun_0_1<x10.core.Long,$T> init, __1$1x10$lang$Long$3x10$regionarray$Array$$T$2 $dummy) {
        this((java.lang.System[]) null, $T);
        x10$regionarray$Array$$init$S(size, init, (x10.regionarray.Array.__1$1x10$lang$Long$3x10$regionarray$Array$$T$2) null);
    }
    
    // constructor for non-virtual call
    final public x10.regionarray.Array<$T> x10$regionarray$Array$$init$S(final long size, final x10.core.fun.Fun_0_1<x10.core.Long,$T> init, __1$1x10$lang$Long$3x10$regionarray$Array$$T$2 $dummy) {
         {
            
            //#line 314 "x10/regionarray/Array.x10"
            final x10.regionarray.RectRegion1D myReg = ((x10.regionarray.RectRegion1D)(new x10.regionarray.RectRegion1D((java.lang.System[]) null)));
            
            //#line 314 "x10/regionarray/Array.x10"
            final long t$141808 = ((size) - (((long)(1L))));
            
            //#line 314 "x10/regionarray/Array.x10"
            myReg.x10$regionarray$RectRegion1D$$init$S(t$141808);
            
            //#line 315 "x10/regionarray/Array.x10"
            this.region = ((x10.regionarray.Region)(myReg));
            this.rank = 1L;
            this.rect = true;
            this.zeroBased = true;
            this.rail = true;
            this.size = size;
            
            
            //#line 317 "x10/regionarray/Array.x10"
            final long t$139957 = ((x10.regionarray.Array<$T>)this).layout_min1 = 0L;
            
            //#line 317 "x10/regionarray/Array.x10"
            final long t$139958 = ((x10.regionarray.Array<$T>)this).layout_stride1 = t$139957;
            
            //#line 317 "x10/regionarray/Array.x10"
            ((x10.regionarray.Array<$T>)this).layout_min0 = t$139958;
            
            //#line 318 "x10/regionarray/Array.x10"
            ((x10.regionarray.Array<$T>)this).layout = null;
            
            //#line 319 "x10/regionarray/Array.x10"
            final x10.core.Rail r = ((x10.core.Rail)(x10.core.Rail.<$T>makeUnsafe($T, ((long)(size)), false)));
            
            //#line 320 "x10/regionarray/Array.x10"
            final long i$138570max$141810 = ((size) - (((long)(1L))));
            
            //#line 320 "x10/regionarray/Array.x10"
            long i$141805 = 0L;
            
            //#line 320 "x10/regionarray/Array.x10"
            for (;
                 true;
                 ) {
                
                //#line 320 "x10/regionarray/Array.x10"
                final boolean t$141807 = ((i$141805) <= (((long)(i$138570max$141810))));
                
                //#line 320 "x10/regionarray/Array.x10"
                if (!(t$141807)) {
                    
                    //#line 320 "x10/regionarray/Array.x10"
                    break;
                }
                
                //#line 321 "x10/regionarray/Array.x10"
                final $T t$141801 = (($T)((($T)
                                            ((x10.core.fun.Fun_0_1<x10.core.Long,$T>)init).$apply(x10.core.Long.$box(i$141805), x10.rtt.Types.LONG))));
                
                //#line 321 "x10/regionarray/Array.x10"
                ((x10.core.Rail<$T>)r).$set__1x10$lang$Rail$$T$G((long)(i$141805), (($T)(t$141801)));
                
                //#line 320 "x10/regionarray/Array.x10"
                final long t$141804 = ((i$141805) + (((long)(1L))));
                
                //#line 320 "x10/regionarray/Array.x10"
                i$141805 = t$141804;
            }
            
            //#line 323 "x10/regionarray/Array.x10"
            ((x10.regionarray.Array<$T>)this).raw = ((x10.core.Rail)(r));
        }
        return this;
    }
    
    
    
    //#line 333 "x10/regionarray/Array.x10"
    /**
     * Construct Array over the region 0..(size-1) whose
     * values are initialized to be init
     * 
     * @param reg The region over which to construct the array.
     * @param init The function to use to initialize the array.
     */
    // creation method for java code (1-phase java constructor)
    public Array(final x10.rtt.Type $T, final long size, final $T init, __1x10$regionarray$Array$$T $dummy) {
        this((java.lang.System[]) null, $T);
        x10$regionarray$Array$$init$S(size, init, (x10.regionarray.Array.__1x10$regionarray$Array$$T) null);
    }
    
    // constructor for non-virtual call
    final public x10.regionarray.Array<$T> x10$regionarray$Array$$init$S(final long size, final $T init, __1x10$regionarray$Array$$T $dummy) {
         {
            
            //#line 335 "x10/regionarray/Array.x10"
            final x10.regionarray.RectRegion1D myReg = ((x10.regionarray.RectRegion1D)(new x10.regionarray.RectRegion1D((java.lang.System[]) null)));
            
            //#line 335 "x10/regionarray/Array.x10"
            final long t$141817 = ((size) - (((long)(1L))));
            
            //#line 335 "x10/regionarray/Array.x10"
            myReg.x10$regionarray$RectRegion1D$$init$S(t$141817);
            
            //#line 336 "x10/regionarray/Array.x10"
            this.region = ((x10.regionarray.Region)(myReg));
            this.rank = 1L;
            this.rect = true;
            this.zeroBased = true;
            this.rail = true;
            this.size = size;
            
            
            //#line 338 "x10/regionarray/Array.x10"
            final long t$139966 = ((x10.regionarray.Array<$T>)this).layout_min1 = 0L;
            
            //#line 338 "x10/regionarray/Array.x10"
            final long t$139967 = ((x10.regionarray.Array<$T>)this).layout_stride1 = t$139966;
            
            //#line 338 "x10/regionarray/Array.x10"
            ((x10.regionarray.Array<$T>)this).layout_min0 = t$139967;
            
            //#line 339 "x10/regionarray/Array.x10"
            ((x10.regionarray.Array<$T>)this).layout = null;
            
            //#line 340 "x10/regionarray/Array.x10"
            final x10.core.Rail r = ((x10.core.Rail)(x10.core.Rail.<$T>makeUnsafe($T, ((long)(size)), false)));
            
            //#line 341 "x10/regionarray/Array.x10"
            final long i$138588max$141819 = ((size) - (((long)(1L))));
            
            //#line 341 "x10/regionarray/Array.x10"
            long i$141814 = 0L;
            
            //#line 341 "x10/regionarray/Array.x10"
            for (;
                 true;
                 ) {
                
                //#line 341 "x10/regionarray/Array.x10"
                final boolean t$141816 = ((i$141814) <= (((long)(i$138588max$141819))));
                
                //#line 341 "x10/regionarray/Array.x10"
                if (!(t$141816)) {
                    
                    //#line 341 "x10/regionarray/Array.x10"
                    break;
                }
                
                //#line 342 "x10/regionarray/Array.x10"
                ((x10.core.Rail<$T>)r).$set__1x10$lang$Rail$$T$G((long)(i$141814), (($T)(init)));
                
                //#line 341 "x10/regionarray/Array.x10"
                final long t$141813 = ((i$141814) + (((long)(1L))));
                
                //#line 341 "x10/regionarray/Array.x10"
                i$141814 = t$141813;
            }
            
            //#line 344 "x10/regionarray/Array.x10"
            ((x10.regionarray.Array<$T>)this).raw = ((x10.core.Rail)(r));
        }
        return this;
    }
    
    
    
    //#line 353 "x10/regionarray/Array.x10"
    /**
     * Construct a copy of the given Array.
     * 
     * @param init The array to copy.
     */
    // creation method for java code (1-phase java constructor)
    public Array(final x10.rtt.Type $T, final x10.regionarray.Array<$T> init, __0$1x10$regionarray$Array$$T$2 $dummy) {
        this((java.lang.System[]) null, $T);
        x10$regionarray$Array$$init$S(init, (x10.regionarray.Array.__0$1x10$regionarray$Array$$T$2) null);
    }
    
    // constructor for non-virtual call
    final public x10.regionarray.Array<$T> x10$regionarray$Array$$init$S(final x10.regionarray.Array<$T> init, __0$1x10$regionarray$Array$$T$2 $dummy) {
         {
            
            //#line 355 "x10/regionarray/Array.x10"
            final x10.regionarray.Region t$141820 = ((x10.regionarray.Region)(((x10.regionarray.Array<$T>)init).region));
            
            //#line 355 "x10/regionarray/Array.x10"
            final long t$141821 = ((x10.regionarray.Array<$T>)init).rank;
            
            //#line 355 "x10/regionarray/Array.x10"
            final boolean t$141822 = ((x10.regionarray.Array<$T>)init).rect;
            
            //#line 355 "x10/regionarray/Array.x10"
            final boolean t$141823 = ((x10.regionarray.Array<$T>)init).zeroBased;
            
            //#line 355 "x10/regionarray/Array.x10"
            final boolean t$141824 = ((x10.regionarray.Array<$T>)init).rail;
            
            //#line 355 "x10/regionarray/Array.x10"
            final long t$141825 = ((x10.regionarray.Array<$T>)init).size;
            
            //#line 355 "x10/regionarray/Array.x10"
            this.region = ((x10.regionarray.Region)(t$141820));
            this.rank = t$141821;
            this.rect = t$141822;
            this.zeroBased = t$141823;
            this.rail = t$141824;
            this.size = t$141825;
            
            
            //#line 356 "x10/regionarray/Array.x10"
            final long t$139979 = ((x10.regionarray.Array<$T>)init).layout_min0;
            
            //#line 356 "x10/regionarray/Array.x10"
            ((x10.regionarray.Array<$T>)this).layout_min0 = t$139979;
            
            //#line 357 "x10/regionarray/Array.x10"
            final long t$139980 = ((x10.regionarray.Array<$T>)init).layout_stride1;
            
            //#line 357 "x10/regionarray/Array.x10"
            ((x10.regionarray.Array<$T>)this).layout_stride1 = t$139980;
            
            //#line 358 "x10/regionarray/Array.x10"
            final long t$139981 = ((x10.regionarray.Array<$T>)init).layout_min1;
            
            //#line 358 "x10/regionarray/Array.x10"
            ((x10.regionarray.Array<$T>)this).layout_min1 = t$139981;
            
            //#line 359 "x10/regionarray/Array.x10"
            final x10.core.Rail t$139982 = ((x10.core.Rail)(((x10.regionarray.Array<$T>)init).layout));
            
            //#line 359 "x10/regionarray/Array.x10"
            ((x10.regionarray.Array<$T>)this).layout = ((x10.core.Rail)(t$139982));
            
            //#line 360 "x10/regionarray/Array.x10"
            final x10.core.Rail t$139983 = ((x10.core.Rail)(((x10.regionarray.Array<$T>)init).raw));
            
            //#line 360 "x10/regionarray/Array.x10"
            final long t$139984 = ((x10.core.Rail<$T>)t$139983).size;
            
            //#line 360 "x10/regionarray/Array.x10"
            final x10.core.Rail r = ((x10.core.Rail)(x10.core.Rail.<$T>makeUnsafe($T, ((long)(t$139984)), false)));
            
            //#line 361 "x10/regionarray/Array.x10"
            final x10.core.Rail t$139985 = ((x10.core.Rail)(((x10.regionarray.Array<$T>)init).raw));
            
            //#line 361 "x10/regionarray/Array.x10"
            final long t$139986 = ((x10.core.Rail<$T>)r).size;
            
            //#line 361 "x10/regionarray/Array.x10"
            x10.core.Rail.<$T> copy__0$1x10$lang$Rail$$T$2__2$1x10$lang$Rail$$T$2($T, ((x10.core.Rail)(t$139985)), (long)(0L), ((x10.core.Rail)(r)), (long)(0L), (long)(t$139986));
            
            //#line 362 "x10/regionarray/Array.x10"
            ((x10.regionarray.Array<$T>)this).raw = ((x10.core.Rail)(r));
        }
        return this;
    }
    
    
    
    //#line 371 "x10/regionarray/Array.x10"
    /**
     * Construct a copy of the given RemoteArray.
     * 
     * @param init The remote array to copy.
     */
    // creation method for java code (1-phase java constructor)
    public Array(final x10.rtt.Type $T, final x10.regionarray.RemoteArray<$T> init, __0$1x10$regionarray$Array$$T$2 $dummy) {
        this((java.lang.System[]) null, $T);
        x10$regionarray$Array$$init$S(init, (x10.regionarray.Array.__0$1x10$regionarray$Array$$T$2) null);
    }
    
    // constructor for non-virtual call
    final public x10.regionarray.Array<$T> x10$regionarray$Array$$init$S(final x10.regionarray.RemoteArray<$T> init, __0$1x10$regionarray$Array$$T$2 $dummy) {
         {
            
            //#line 373 "x10/regionarray/Array.x10"
            final x10.regionarray.Array this$139381 = ((x10.regionarray.Array)(this));
            
            //#line 373 "x10/regionarray/Array.x10"
            final x10.core.GlobalRef t$139987 = ((x10.core.GlobalRef)(((x10.regionarray.RemoteArray<$T>)init).array));
            
            //#line 373 "x10/regionarray/Array.x10"
            final x10.regionarray.Array init$139379 = ((x10.regionarray.Array)((((x10.core.GlobalRef<x10.regionarray.Array<$T>>)(t$139987))).$apply$G()));
            
            //#line 355 . "x10/regionarray/Array.x10"
            final x10.regionarray.Region t$141827 = ((x10.regionarray.Region)(((x10.regionarray.Array<$T>)init$139379).region));
            
            //#line 355 . "x10/regionarray/Array.x10"
            ((x10.regionarray.Array<$T>)this$139381).region = ((x10.regionarray.Region)(t$141827));
            
            //#line 355 . "x10/regionarray/Array.x10"
            final long t$141828 = ((x10.regionarray.Array<$T>)init$139379).rank;
            
            //#line 355 . "x10/regionarray/Array.x10"
            ((x10.regionarray.Array<$T>)this$139381).rank = t$141828;
            
            //#line 355 . "x10/regionarray/Array.x10"
            final boolean t$141829 = ((x10.regionarray.Array<$T>)init$139379).rect;
            
            //#line 355 . "x10/regionarray/Array.x10"
            ((x10.regionarray.Array<$T>)this$139381).rect = t$141829;
            
            //#line 355 . "x10/regionarray/Array.x10"
            final boolean t$141830 = ((x10.regionarray.Array<$T>)init$139379).zeroBased;
            
            //#line 355 . "x10/regionarray/Array.x10"
            ((x10.regionarray.Array<$T>)this$139381).zeroBased = t$141830;
            
            //#line 355 . "x10/regionarray/Array.x10"
            final boolean t$141831 = ((x10.regionarray.Array<$T>)init$139379).rail;
            
            //#line 355 . "x10/regionarray/Array.x10"
            ((x10.regionarray.Array<$T>)this$139381).rail = t$141831;
            
            //#line 355 . "x10/regionarray/Array.x10"
            final long t$141832 = ((x10.regionarray.Array<$T>)init$139379).size;
            
            //#line 355 . "x10/regionarray/Array.x10"
            ((x10.regionarray.Array<$T>)this$139381).size = t$141832;
            
            //#line 356 . "x10/regionarray/Array.x10"
            final long t$141833 = ((x10.regionarray.Array<$T>)init$139379).layout_min0;
            
            //#line 356 . "x10/regionarray/Array.x10"
            ((x10.regionarray.Array<$T>)this$139381).layout_min0 = t$141833;
            
            //#line 357 . "x10/regionarray/Array.x10"
            final long t$141834 = ((x10.regionarray.Array<$T>)init$139379).layout_stride1;
            
            //#line 357 . "x10/regionarray/Array.x10"
            ((x10.regionarray.Array<$T>)this$139381).layout_stride1 = t$141834;
            
            //#line 358 . "x10/regionarray/Array.x10"
            final long t$141835 = ((x10.regionarray.Array<$T>)init$139379).layout_min1;
            
            //#line 358 . "x10/regionarray/Array.x10"
            ((x10.regionarray.Array<$T>)this$139381).layout_min1 = t$141835;
            
            //#line 359 . "x10/regionarray/Array.x10"
            final x10.core.Rail t$141836 = ((x10.core.Rail)(((x10.regionarray.Array<$T>)init$139379).layout));
            
            //#line 359 . "x10/regionarray/Array.x10"
            ((x10.regionarray.Array<$T>)this$139381).layout = ((x10.core.Rail)(t$141836));
            
            //#line 360 . "x10/regionarray/Array.x10"
            final x10.core.Rail t$141837 = ((x10.core.Rail)(((x10.regionarray.Array<$T>)init$139379).raw));
            
            //#line 360 . "x10/regionarray/Array.x10"
            final long t$141838 = ((x10.core.Rail<$T>)t$141837).size;
            
            //#line 360 . "x10/regionarray/Array.x10"
            final x10.core.Rail r$141839 = ((x10.core.Rail)(x10.core.Rail.<$T>makeUnsafe($T, ((long)(t$141838)), false)));
            
            //#line 361 . "x10/regionarray/Array.x10"
            final x10.core.Rail t$141840 = ((x10.core.Rail)(((x10.regionarray.Array<$T>)init$139379).raw));
            
            //#line 361 . "x10/regionarray/Array.x10"
            final long t$141841 = ((x10.core.Rail<$T>)r$141839).size;
            
            //#line 361 . "x10/regionarray/Array.x10"
            x10.core.Rail.<$T> copy__0$1x10$lang$Rail$$T$2__2$1x10$lang$Rail$$T$2($T, ((x10.core.Rail)(t$141840)), (long)(0L), ((x10.core.Rail)(r$141839)), (long)(0L), (long)(t$141841));
            
            //#line 362 . "x10/regionarray/Array.x10"
            ((x10.regionarray.Array<$T>)this$139381).raw = ((x10.core.Rail)(r$141839));
        }
        return this;
    }
    
    
    
    //#line 381 "x10/regionarray/Array.x10"
    /**
     * Return the string representation of this array.
     * 
     * @return the string representation of this array.
     */
    public java.lang.String toString() {
        
        //#line 382 "x10/regionarray/Array.x10"
        final boolean t$140022 = this.rail;
        
        //#line 382 "x10/regionarray/Array.x10"
        if (t$140022) {
            
            //#line 383 "x10/regionarray/Array.x10"
            final x10.util.StringBuilder sb = ((x10.util.StringBuilder)(new x10.util.StringBuilder((java.lang.System[]) null)));
            
            //#line 383 "x10/regionarray/Array.x10"
            sb.x10$util$StringBuilder$$init$S();
            
            //#line 384 "x10/regionarray/Array.x10"
            sb.add(((java.lang.String)("[")));
            
            //#line 385 "x10/regionarray/Array.x10"
            final long t$140002 = this.size;
            
            //#line 385 "x10/regionarray/Array.x10"
            final long sz = java.lang.Math.min(((long)(t$140002)),((long)(10L)));
            
            //#line 386 "x10/regionarray/Array.x10"
            final long i$138606max$141852 = ((sz) - (((long)(1L))));
            
            //#line 386 "x10/regionarray/Array.x10"
            long i$141849 = 0L;
            
            //#line 386 "x10/regionarray/Array.x10"
            for (;
                 true;
                 ) {
                
                //#line 386 "x10/regionarray/Array.x10"
                final boolean t$141851 = ((i$141849) <= (((long)(i$138606max$141852))));
                
                //#line 386 "x10/regionarray/Array.x10"
                if (!(t$141851)) {
                    
                    //#line 386 "x10/regionarray/Array.x10"
                    break;
                }
                
                //#line 387 "x10/regionarray/Array.x10"
                final boolean t$141842 = ((i$141849) > (((long)(0L))));
                
                //#line 387 "x10/regionarray/Array.x10"
                if (t$141842) {
                    
                    //#line 387 "x10/regionarray/Array.x10"
                    sb.add(((java.lang.String)(",")));
                }
                
                //#line 388 "x10/regionarray/Array.x10"
                final x10.core.Rail t$141843 = ((x10.core.Rail)(this.raw));
                
                //#line 388 "x10/regionarray/Array.x10"
                final $T t$141844 = (($T)(((x10.core.Rail<$T>)t$141843).$apply$G((long)(i$141849))));
                
                //#line 388 "x10/regionarray/Array.x10"
                final java.lang.String t$141845 = (("") + (t$141844));
                
                //#line 388 "x10/regionarray/Array.x10"
                sb.add(((java.lang.String)(t$141845)));
                
                //#line 386 "x10/regionarray/Array.x10"
                final long t$141848 = ((i$141849) + (((long)(1L))));
                
                //#line 386 "x10/regionarray/Array.x10"
                i$141849 = t$141848;
            }
            
            //#line 390 "x10/regionarray/Array.x10"
            final long t$140012 = this.size;
            
            //#line 390 "x10/regionarray/Array.x10"
            final boolean t$140017 = ((sz) < (((long)(t$140012))));
            
            //#line 390 "x10/regionarray/Array.x10"
            if (t$140017) {
                
                //#line 390 "x10/regionarray/Array.x10"
                final long t$140013 = this.size;
                
                //#line 390 "x10/regionarray/Array.x10"
                final long t$140014 = ((t$140013) - (((long)(sz))));
                
                //#line 390 "x10/regionarray/Array.x10"
                final java.lang.String t$140015 = (("...(omitted ") + ((x10.core.Long.$box(t$140014))));
                
                //#line 390 "x10/regionarray/Array.x10"
                final java.lang.String t$140016 = ((t$140015) + (" elements)"));
                
                //#line 390 "x10/regionarray/Array.x10"
                sb.add(((java.lang.String)(t$140016)));
            }
            
            //#line 391 "x10/regionarray/Array.x10"
            sb.add(((java.lang.String)("]")));
            
            //#line 392 "x10/regionarray/Array.x10"
            final java.lang.String t$140018 = sb.toString();
            
            //#line 392 "x10/regionarray/Array.x10"
            return t$140018;
        } else {
            
            //#line 394 "x10/regionarray/Array.x10"
            final x10.regionarray.Region t$140019 = ((x10.regionarray.Region)(this.region));
            
            //#line 394 "x10/regionarray/Array.x10"
            final java.lang.String t$140020 = (("Array(") + (t$140019));
            
            //#line 394 "x10/regionarray/Array.x10"
            final java.lang.String t$140021 = ((t$140020) + (")"));
            
            //#line 394 "x10/regionarray/Array.x10"
            return t$140021;
        }
    }
    
    
    //#line 404 "x10/regionarray/Array.x10"
    /**
     * Return an iterator over the points in the region of this array.
     * 
     * @return an iterator over the points in the region of this array.
     * @see x10.lang.Iterable[T]#iterator()
     */
    public x10.lang.Iterator iterator() {
        
        //#line 404 "x10/regionarray/Array.x10"
        final x10.regionarray.Region t$140023 = ((x10.regionarray.Region)(this.region));
        
        //#line 404 "x10/regionarray/Array.x10"
        final x10.lang.Iterator t$140024 = t$140023.iterator();
        
        //#line 404 "x10/regionarray/Array.x10"
        return t$140024;
    }
    
    
    //#line 412 "x10/regionarray/Array.x10"
    /**
     * Return an Iterable[T] that can construct iterators 
     * over this array.<p>
     * @return an Iterable[T] over this array.
     */
    public x10.lang.Iterable values() {
        
        //#line 413 "x10/regionarray/Array.x10"
        final boolean t$140025 = this.rect;
        
        //#line 413 "x10/regionarray/Array.x10"
        if (t$140025) {
            
            //#line 414 "x10/regionarray/Array.x10"
            final x10.regionarray.Array.Anonymous$14235 alloc$138539 = ((x10.regionarray.Array.Anonymous$14235)(new x10.regionarray.Array.Anonymous$14235<$T>((java.lang.System[]) null, $T)));
            
            //#line 414 "x10/regionarray/Array.x10"
            final x10.regionarray.Array out$139384 = ((x10.regionarray.Array)(this));
            
            //#line 55 . "x10/regionarray/Array.x10"
            ((x10.regionarray.Array.Anonymous$14235<$T>)alloc$138539).out$ = out$139384;
            
            //#line 414 "x10/regionarray/Array.x10"
            return alloc$138539;
        } else {
            
            //#line 422 "x10/regionarray/Array.x10"
            final x10.regionarray.Array.Anonymous$14520 alloc$138540 = ((x10.regionarray.Array.Anonymous$14520)(new x10.regionarray.Array.Anonymous$14520<$T>((java.lang.System[]) null, $T)));
            
            //#line 422 "x10/regionarray/Array.x10"
            final x10.regionarray.Array out$139386 = ((x10.regionarray.Array)(this));
            
            //#line 55 . "x10/regionarray/Array.x10"
            ((x10.regionarray.Array.Anonymous$14520<$T>)alloc$138540).out$ = out$139386;
            
            //#line 422 "x10/regionarray/Array.x10"
            return alloc$138540;
        }
    }
    
    
    //#line 442 "x10/regionarray/Array.x10"
    /**
     * Return the element of this array corresponding to the given index.
     * Only applies to one-dimensional arrays.
     * Functionally equivalent to indexing the array via a one-dimensional point.
     * 
     * @param i0 the given index in the first dimension
     * @return the element of this array corresponding to the given index.
     * @see #operator(Point)
     * @see #set(T, Long)
     */
    public $T $apply$G(final long i0) {
        
        //#line 444 "x10/regionarray/Array.x10"
        final boolean t$140035 = this.rail;
        
        //#line 444 "x10/regionarray/Array.x10"
        if (t$140035) {
            
            //#line 446 "x10/regionarray/Array.x10"
            final x10.core.Rail t$140026 = ((x10.core.Rail)(this.raw));
            
            //#line 446 "x10/regionarray/Array.x10"
            final $T t$140027 = (($T)(((x10.core.Rail<$T>)t$140026).$apply$G((long)(i0))));
            
            //#line 446 "x10/regionarray/Array.x10"
            return t$140027;
        } else {
            
            //#line 448 "x10/regionarray/Array.x10"
            final x10.regionarray.Region t$140028 = ((x10.regionarray.Region)(this.region));
            
            //#line 448 "x10/regionarray/Array.x10"
            final boolean t$140029 = t$140028.contains$O((long)(i0));
            
            //#line 448 "x10/regionarray/Array.x10"
            final boolean t$140030 = !(t$140029);
            
            //#line 448 "x10/regionarray/Array.x10"
            if (t$140030) {
                
                //#line 449 "x10/regionarray/Array.x10"
                x10.regionarray.Array.raiseBoundsError((long)(i0));
            }
            
            //#line 451 "x10/regionarray/Array.x10"
            final x10.core.Rail t$140032 = ((x10.core.Rail)(this.raw));
            
            //#line 451 "x10/regionarray/Array.x10"
            final long t$140031 = this.layout_min0;
            
            //#line 451 "x10/regionarray/Array.x10"
            final long t$140033 = ((i0) - (((long)(t$140031))));
            
            //#line 451 "x10/regionarray/Array.x10"
            final $T t$140034 = (($T)(((x10.core.Rail<$T>)t$140032).$apply$G((long)(t$140033))));
            
            //#line 451 "x10/regionarray/Array.x10"
            return t$140034;
        }
    }
    
    
    //#line 466 "x10/regionarray/Array.x10"
    /**
     * Return the element of this array corresponding to the given pair of indices.
     * Only applies to two-dimensional arrays.
     * Functionally equivalent to indexing the array via a two-dimensional point.
     * 
     * @param i0 the given index in the first dimension
     * @param i1 the given index in the second dimension
     * @return the element of this array corresponding to the given pair of indices.
     * @see #operator(Point)
     * @see #set(T, Long, Long)
     */
    public $T $apply$G(final long i0, final long i1) {
        
        //#line 467 "x10/regionarray/Array.x10"
        final x10.regionarray.Region t$140036 = ((x10.regionarray.Region)(this.region));
        
        //#line 467 "x10/regionarray/Array.x10"
        final boolean t$140037 = t$140036.contains$O((long)(i0), (long)(i1));
        
        //#line 467 "x10/regionarray/Array.x10"
        final boolean t$140038 = !(t$140037);
        
        //#line 467 "x10/regionarray/Array.x10"
        if (t$140038) {
            
            //#line 468 "x10/regionarray/Array.x10"
            x10.regionarray.Array.raiseBoundsError((long)(i0), (long)(i1));
        }
        
        //#line 470 "x10/regionarray/Array.x10"
        final long t$140039 = this.layout_min0;
        
        //#line 470 "x10/regionarray/Array.x10"
        long offset = ((i0) - (((long)(t$140039))));
        
        //#line 471 "x10/regionarray/Array.x10"
        final long t$140041 = this.layout_stride1;
        
        //#line 471 "x10/regionarray/Array.x10"
        final long t$140042 = ((offset) * (((long)(t$140041))));
        
        //#line 471 "x10/regionarray/Array.x10"
        final long t$140043 = ((t$140042) + (((long)(i1))));
        
        //#line 471 "x10/regionarray/Array.x10"
        final long t$140044 = this.layout_min1;
        
        //#line 471 "x10/regionarray/Array.x10"
        final long t$140045 = ((t$140043) - (((long)(t$140044))));
        
        //#line 471 "x10/regionarray/Array.x10"
        offset = t$140045;
        
        //#line 472 "x10/regionarray/Array.x10"
        final x10.core.Rail t$140046 = ((x10.core.Rail)(this.raw));
        
        //#line 472 "x10/regionarray/Array.x10"
        final $T t$140048 = (($T)(((x10.core.Rail<$T>)t$140046).$apply$G((long)(offset))));
        
        //#line 472 "x10/regionarray/Array.x10"
        return t$140048;
    }
    
    
    //#line 487 "x10/regionarray/Array.x10"
    /**
     * Return the element of this array corresponding to the given triple of indices.
     * Only applies to three-dimensional arrays.
     * Functionally equivalent to indexing the array via a three-dimensional point.
     * 
     * @param i0 the given index in the first dimension
     * @param i1 the given index in the second dimension
     * @param i2 the given index in the third dimension
     * @return the element of this array corresponding to the given triple of indices.
     * @see #operator(Point)
     * @see #set(T, Long, Long, Long)
     */
    public $T $apply$G(final long i0, final long i1, final long i2) {
        
        //#line 488 "x10/regionarray/Array.x10"
        final x10.regionarray.Region t$140049 = ((x10.regionarray.Region)(this.region));
        
        //#line 488 "x10/regionarray/Array.x10"
        final boolean t$140050 = t$140049.contains$O((long)(i0), (long)(i1), (long)(i2));
        
        //#line 488 "x10/regionarray/Array.x10"
        final boolean t$140051 = !(t$140050);
        
        //#line 488 "x10/regionarray/Array.x10"
        if (t$140051) {
            
            //#line 489 "x10/regionarray/Array.x10"
            x10.regionarray.Array.raiseBoundsError((long)(i0), (long)(i1), (long)(i2));
        }
        
        //#line 491 "x10/regionarray/Array.x10"
        final x10.core.Rail t$140067 = ((x10.core.Rail)(this.raw));
        
        //#line 491 "x10/regionarray/Array.x10"
        final x10.regionarray.Array this$139392 = ((x10.regionarray.Array)(this));
        
        //#line 1300 . "x10/regionarray/Array.x10"
        final long t$140052 = ((x10.regionarray.Array<$T>)this$139392).layout_min0;
        
        //#line 1300 . "x10/regionarray/Array.x10"
        long offset$139391 = ((i0) - (((long)(t$140052))));
        
        //#line 1301 . "x10/regionarray/Array.x10"
        final long t$140054 = ((x10.regionarray.Array<$T>)this$139392).layout_stride1;
        
        //#line 1301 . "x10/regionarray/Array.x10"
        final long t$140055 = ((offset$139391) * (((long)(t$140054))));
        
        //#line 1301 . "x10/regionarray/Array.x10"
        final long t$140056 = ((t$140055) + (((long)(i1))));
        
        //#line 1301 . "x10/regionarray/Array.x10"
        final long t$140057 = ((x10.regionarray.Array<$T>)this$139392).layout_min1;
        
        //#line 1301 . "x10/regionarray/Array.x10"
        final long t$140058 = ((t$140056) - (((long)(t$140057))));
        
        //#line 1301 . "x10/regionarray/Array.x10"
        offset$139391 = t$140058;
        
        //#line 1302 . "x10/regionarray/Array.x10"
        final x10.core.Rail t$140059 = ((x10.core.Rail)(((x10.regionarray.Array<$T>)this$139392).layout));
        
        //#line 1302 . "x10/regionarray/Array.x10"
        final long t$140061 = ((long[])t$140059.value)[(int)0L];
        
        //#line 1302 . "x10/regionarray/Array.x10"
        final long t$140062 = ((offset$139391) * (((long)(t$140061))));
        
        //#line 1302 . "x10/regionarray/Array.x10"
        final long t$140064 = ((t$140062) + (((long)(i2))));
        
        //#line 1302 . "x10/regionarray/Array.x10"
        final x10.core.Rail t$140063 = ((x10.core.Rail)(((x10.regionarray.Array<$T>)this$139392).layout));
        
        //#line 1302 . "x10/regionarray/Array.x10"
        final long t$140065 = ((long[])t$140063.value)[(int)1L];
        
        //#line 1302 . "x10/regionarray/Array.x10"
        final long t$140066 = ((t$140064) - (((long)(t$140065))));
        
        //#line 1302 . "x10/regionarray/Array.x10"
        offset$139391 = t$140066;
        
        //#line 491 "x10/regionarray/Array.x10"
        final $T t$140069 = (($T)(((x10.core.Rail<$T>)t$140067).$apply$G((long)(offset$139391))));
        
        //#line 491 "x10/regionarray/Array.x10"
        return t$140069;
    }
    
    
    //#line 507 "x10/regionarray/Array.x10"
    /**
     * Return the element of this array corresponding to the given quartet of indices.
     * Only applies to four-dimensional arrays.
     * Functionally equivalent to indexing the array via a four-dimensional point.
     * 
     * @param i0 the given index in the first dimension
     * @param i1 the given index in the second dimension
     * @param i2 the given index in the third dimension
     * @param i3 the given index in the fourth dimension
     * @return the element of this array corresponding to the given quartet of indices.
     * @see #operator(Point)
     * @see #set(T, Long, Long, Long, Long)
     */
    public $T $apply$G(final long i0, final long i1, final long i2, final long i3) {
        
        //#line 508 "x10/regionarray/Array.x10"
        final x10.regionarray.Region t$140070 = ((x10.regionarray.Region)(this.region));
        
        //#line 508 "x10/regionarray/Array.x10"
        final boolean t$140071 = t$140070.contains$O((long)(i0), (long)(i1), (long)(i2), (long)(i3));
        
        //#line 508 "x10/regionarray/Array.x10"
        final boolean t$140072 = !(t$140071);
        
        //#line 508 "x10/regionarray/Array.x10"
        if (t$140072) {
            
            //#line 509 "x10/regionarray/Array.x10"
            x10.regionarray.Array.raiseBoundsError((long)(i0), (long)(i1), (long)(i2), (long)(i3));
        }
        
        //#line 511 "x10/regionarray/Array.x10"
        final x10.core.Rail t$140096 = ((x10.core.Rail)(this.raw));
        
        //#line 511 "x10/regionarray/Array.x10"
        final x10.regionarray.Array this$139399 = ((x10.regionarray.Array)(this));
        
        //#line 1307 . "x10/regionarray/Array.x10"
        final long t$140073 = ((x10.regionarray.Array<$T>)this$139399).layout_min0;
        
        //#line 1307 . "x10/regionarray/Array.x10"
        long offset$139398 = ((i0) - (((long)(t$140073))));
        
        //#line 1308 . "x10/regionarray/Array.x10"
        final long t$140075 = ((x10.regionarray.Array<$T>)this$139399).layout_stride1;
        
        //#line 1308 . "x10/regionarray/Array.x10"
        final long t$140076 = ((offset$139398) * (((long)(t$140075))));
        
        //#line 1308 . "x10/regionarray/Array.x10"
        final long t$140077 = ((t$140076) + (((long)(i1))));
        
        //#line 1308 . "x10/regionarray/Array.x10"
        final long t$140078 = ((x10.regionarray.Array<$T>)this$139399).layout_min1;
        
        //#line 1308 . "x10/regionarray/Array.x10"
        final long t$140079 = ((t$140077) - (((long)(t$140078))));
        
        //#line 1308 . "x10/regionarray/Array.x10"
        offset$139398 = t$140079;
        
        //#line 1309 . "x10/regionarray/Array.x10"
        final x10.core.Rail t$140080 = ((x10.core.Rail)(((x10.regionarray.Array<$T>)this$139399).layout));
        
        //#line 1309 . "x10/regionarray/Array.x10"
        final long t$140082 = ((long[])t$140080.value)[(int)0L];
        
        //#line 1309 . "x10/regionarray/Array.x10"
        final long t$140083 = ((offset$139398) * (((long)(t$140082))));
        
        //#line 1309 . "x10/regionarray/Array.x10"
        final long t$140085 = ((t$140083) + (((long)(i2))));
        
        //#line 1309 . "x10/regionarray/Array.x10"
        final x10.core.Rail t$140084 = ((x10.core.Rail)(((x10.regionarray.Array<$T>)this$139399).layout));
        
        //#line 1309 . "x10/regionarray/Array.x10"
        final long t$140086 = ((long[])t$140084.value)[(int)1L];
        
        //#line 1309 . "x10/regionarray/Array.x10"
        final long t$140087 = ((t$140085) - (((long)(t$140086))));
        
        //#line 1309 . "x10/regionarray/Array.x10"
        offset$139398 = t$140087;
        
        //#line 1310 . "x10/regionarray/Array.x10"
        final x10.core.Rail t$140088 = ((x10.core.Rail)(((x10.regionarray.Array<$T>)this$139399).layout));
        
        //#line 1310 . "x10/regionarray/Array.x10"
        final long t$140090 = ((long[])t$140088.value)[(int)2L];
        
        //#line 1310 . "x10/regionarray/Array.x10"
        final long t$140091 = ((offset$139398) * (((long)(t$140090))));
        
        //#line 1310 . "x10/regionarray/Array.x10"
        final long t$140093 = ((t$140091) + (((long)(i3))));
        
        //#line 1310 . "x10/regionarray/Array.x10"
        final x10.core.Rail t$140092 = ((x10.core.Rail)(((x10.regionarray.Array<$T>)this$139399).layout));
        
        //#line 1310 . "x10/regionarray/Array.x10"
        final long t$140094 = ((long[])t$140092.value)[(int)3L];
        
        //#line 1310 . "x10/regionarray/Array.x10"
        final long t$140095 = ((t$140093) - (((long)(t$140094))));
        
        //#line 1310 . "x10/regionarray/Array.x10"
        offset$139398 = t$140095;
        
        //#line 511 "x10/regionarray/Array.x10"
        final $T t$140098 = (($T)(((x10.core.Rail<$T>)t$140096).$apply$G((long)(offset$139398))));
        
        //#line 511 "x10/regionarray/Array.x10"
        return t$140098;
    }
    
    
    //#line 523 "x10/regionarray/Array.x10"
    /**
     * Return the element of this array corresponding to the given point.
     * The rank of the given point has to be the same as the rank of this array.
     * 
     * @param pt the given point
     * @return the element of this array corresponding to the given point.
     * @see #operator(Long)
     * @see #set(T, Point)
     */
    public $T $apply$G(final x10.lang.Point pt) {
        
        //#line 524 "x10/regionarray/Array.x10"
        final x10.regionarray.Region t$140099 = ((x10.regionarray.Region)(this.region));
        
        //#line 524 "x10/regionarray/Array.x10"
        final boolean t$140100 = t$140099.contains$O(((x10.lang.Point)(pt)));
        
        //#line 524 "x10/regionarray/Array.x10"
        final boolean t$140101 = !(t$140100);
        
        //#line 524 "x10/regionarray/Array.x10"
        if (t$140101) {
            
            //#line 525 "x10/regionarray/Array.x10"
            x10.regionarray.Array.raiseBoundsError(((x10.lang.Point)(pt)));
        }
        
        //#line 527 "x10/regionarray/Array.x10"
        final x10.core.Rail t$140134 = ((x10.core.Rail)(this.raw));
        
        //#line 527 "x10/regionarray/Array.x10"
        final x10.regionarray.Array this$139407 = ((x10.regionarray.Array)(this));
        
        //#line 1315 . "x10/regionarray/Array.x10"
        final long t$140102 = ((long)(((int)(0))));
        
        //#line 1315 . "x10/regionarray/Array.x10"
        final long t$140103 = pt.$apply$O((long)(t$140102));
        
        //#line 1315 . "x10/regionarray/Array.x10"
        final long t$140104 = ((x10.regionarray.Array<$T>)this$139407).layout_min0;
        
        //#line 1315 . "x10/regionarray/Array.x10"
        long offset$139402 = ((t$140103) - (((long)(t$140104))));
        
        //#line 1316 . "x10/regionarray/Array.x10"
        final long t$140105 = pt.rank;
        
        //#line 1316 . "x10/regionarray/Array.x10"
        final boolean t$140133 = ((t$140105) > (((long)(1L))));
        
        //#line 1316 . "x10/regionarray/Array.x10"
        if (t$140133) {
            
            //#line 1317 . "x10/regionarray/Array.x10"
            final long t$140107 = ((x10.regionarray.Array<$T>)this$139407).layout_stride1;
            
            //#line 1317 . "x10/regionarray/Array.x10"
            final long t$140108 = ((offset$139402) * (((long)(t$140107))));
            
            //#line 1317 . "x10/regionarray/Array.x10"
            final long t$140109 = pt.$apply$O((long)(1L));
            
            //#line 1317 . "x10/regionarray/Array.x10"
            final long t$140110 = ((t$140108) + (((long)(t$140109))));
            
            //#line 1317 . "x10/regionarray/Array.x10"
            final long t$140111 = ((x10.regionarray.Array<$T>)this$139407).layout_min1;
            
            //#line 1317 . "x10/regionarray/Array.x10"
            final long t$140112 = ((t$140110) - (((long)(t$140111))));
            
            //#line 1317 . "x10/regionarray/Array.x10"
            offset$139402 = t$140112;
            
            //#line 1318 . "x10/regionarray/Array.x10"
            final long t$141873 = pt.rank;
            
            //#line 1318 . "x10/regionarray/Array.x10"
            final long i$138773max$141874 = ((t$141873) - (((long)(1L))));
            
            //#line 1318 . "x10/regionarray/Array.x10"
            long i$141870 = 2L;
            
            //#line 1318 . "x10/regionarray/Array.x10"
            for (;
                 true;
                 ) {
                
                //#line 1318 . "x10/regionarray/Array.x10"
                final boolean t$141872 = ((i$141870) <= (((long)(i$138773max$141874))));
                
                //#line 1318 . "x10/regionarray/Array.x10"
                if (!(t$141872)) {
                    
                    //#line 1318 . "x10/regionarray/Array.x10"
                    break;
                }
                
                //#line 1319 . "x10/regionarray/Array.x10"
                final x10.core.Rail t$141854 = ((x10.core.Rail)(((x10.regionarray.Array<$T>)this$139407).layout));
                
                //#line 1319 . "x10/regionarray/Array.x10"
                final long t$141855 = ((i$141870) - (((long)(2L))));
                
                //#line 1319 . "x10/regionarray/Array.x10"
                final long t$141856 = ((2L) * (((long)(t$141855))));
                
                //#line 1319 . "x10/regionarray/Array.x10"
                final long t$141857 = ((long[])t$141854.value)[(int)t$141856];
                
                //#line 1319 . "x10/regionarray/Array.x10"
                final long t$141858 = ((offset$139402) * (((long)(t$141857))));
                
                //#line 1319 . "x10/regionarray/Array.x10"
                final long t$141859 = pt.$apply$O((long)(i$141870));
                
                //#line 1319 . "x10/regionarray/Array.x10"
                final long t$141860 = ((t$141858) + (((long)(t$141859))));
                
                //#line 1319 . "x10/regionarray/Array.x10"
                final x10.core.Rail t$141861 = ((x10.core.Rail)(((x10.regionarray.Array<$T>)this$139407).layout));
                
                //#line 1319 . "x10/regionarray/Array.x10"
                final long t$141862 = ((i$141870) - (((long)(2L))));
                
                //#line 1319 . "x10/regionarray/Array.x10"
                final long t$141863 = ((2L) * (((long)(t$141862))));
                
                //#line 1319 . "x10/regionarray/Array.x10"
                final long t$141864 = ((t$141863) + (((long)(1L))));
                
                //#line 1319 . "x10/regionarray/Array.x10"
                final long t$141865 = ((long[])t$141861.value)[(int)t$141864];
                
                //#line 1319 . "x10/regionarray/Array.x10"
                final long t$141866 = ((t$141860) - (((long)(t$141865))));
                
                //#line 1319 . "x10/regionarray/Array.x10"
                offset$139402 = t$141866;
                
                //#line 1318 . "x10/regionarray/Array.x10"
                final long t$141869 = ((i$141870) + (((long)(1L))));
                
                //#line 1318 . "x10/regionarray/Array.x10"
                i$141870 = t$141869;
            }
        }
        
        //#line 527 "x10/regionarray/Array.x10"
        final $T t$140136 = (($T)(((x10.core.Rail<$T>)t$140134).$apply$G((long)(offset$139402))));
        
        //#line 527 "x10/regionarray/Array.x10"
        return t$140136;
    }
    
    
    //#line 543 "x10/regionarray/Array.x10"
    /**
     * Set the element of this array corresponding to the given index to the given value.
     * Return the new value of the element.
     * Only applies to one-dimensional arrays.
     * Functionally equivalent to setting the array via a one-dimensional point.
     * 
     * @param v the given value
     * @param i0 the given index in the first dimension
     * @return the new value of the element of this array corresponding to the given index.
     * @see #operator(Long)
     * @see #set(T, Point)
     */
    public $T $set__1x10$regionarray$Array$$T$G(final long i0, final $T v) {
        
        //#line 545 "x10/regionarray/Array.x10"
        final boolean t$140144 = this.rail;
        
        //#line 545 "x10/regionarray/Array.x10"
        if (t$140144) {
            
            //#line 547 "x10/regionarray/Array.x10"
            final x10.core.Rail t$140137 = ((x10.core.Rail)(this.raw));
            
            //#line 547 "x10/regionarray/Array.x10"
            ((x10.core.Rail<$T>)t$140137).$set__1x10$lang$Rail$$T$G((long)(i0), (($T)(v)));
        } else {
            
            //#line 549 "x10/regionarray/Array.x10"
            final x10.regionarray.Region t$140138 = ((x10.regionarray.Region)(this.region));
            
            //#line 549 "x10/regionarray/Array.x10"
            final boolean t$140139 = t$140138.contains$O((long)(i0));
            
            //#line 549 "x10/regionarray/Array.x10"
            final boolean t$140140 = !(t$140139);
            
            //#line 549 "x10/regionarray/Array.x10"
            if (t$140140) {
                
                //#line 550 "x10/regionarray/Array.x10"
                x10.regionarray.Array.raiseBoundsError((long)(i0));
            }
            
            //#line 552 "x10/regionarray/Array.x10"
            final x10.core.Rail t$140142 = ((x10.core.Rail)(this.raw));
            
            //#line 552 "x10/regionarray/Array.x10"
            final long t$140141 = this.layout_min0;
            
            //#line 552 "x10/regionarray/Array.x10"
            final long t$140143 = ((i0) - (((long)(t$140141))));
            
            //#line 552 "x10/regionarray/Array.x10"
            ((x10.core.Rail<$T>)t$140142).$set__1x10$lang$Rail$$T$G((long)(t$140143), (($T)(v)));
        }
        
        //#line 554 "x10/regionarray/Array.x10"
        return v;
    }
    
    
    //#line 570 "x10/regionarray/Array.x10"
    /**
     * Set the element of this array corresponding to the given pair of indices to the given value.
     * Return the new value of the element.
     * Only applies to two-dimensional arrays.
     * Functionally equivalent to setting the array via a two-dimensional point.
     * 
     * @param v the given value
     * @param i0 the given index in the first dimension
     * @param i1 the given index in the second dimension
     * @return the new value of the element of this array corresponding to the given pair of indices.
     * @see #operator(Long, Long)
     * @see #set(T, Point)
     */
    public $T $set__2x10$regionarray$Array$$T$G(final long i0, final long i1, final $T v) {
        
        //#line 571 "x10/regionarray/Array.x10"
        final x10.regionarray.Region t$140145 = ((x10.regionarray.Region)(this.region));
        
        //#line 571 "x10/regionarray/Array.x10"
        final boolean t$140146 = t$140145.contains$O((long)(i0), (long)(i1));
        
        //#line 571 "x10/regionarray/Array.x10"
        final boolean t$140147 = !(t$140146);
        
        //#line 571 "x10/regionarray/Array.x10"
        if (t$140147) {
            
            //#line 572 "x10/regionarray/Array.x10"
            x10.regionarray.Array.raiseBoundsError((long)(i0), (long)(i1));
        }
        
        //#line 574 "x10/regionarray/Array.x10"
        final long t$140148 = this.layout_min0;
        
        //#line 574 "x10/regionarray/Array.x10"
        long offset = ((i0) - (((long)(t$140148))));
        
        //#line 575 "x10/regionarray/Array.x10"
        final long t$140150 = this.layout_stride1;
        
        //#line 575 "x10/regionarray/Array.x10"
        final long t$140151 = ((offset) * (((long)(t$140150))));
        
        //#line 575 "x10/regionarray/Array.x10"
        final long t$140152 = ((t$140151) + (((long)(i1))));
        
        //#line 575 "x10/regionarray/Array.x10"
        final long t$140153 = this.layout_min1;
        
        //#line 575 "x10/regionarray/Array.x10"
        final long t$140154 = ((t$140152) - (((long)(t$140153))));
        
        //#line 575 "x10/regionarray/Array.x10"
        offset = t$140154;
        
        //#line 576 "x10/regionarray/Array.x10"
        final x10.core.Rail t$140155 = ((x10.core.Rail)(this.raw));
        
        //#line 576 "x10/regionarray/Array.x10"
        ((x10.core.Rail<$T>)t$140155).$set__1x10$lang$Rail$$T$G((long)(offset), (($T)(v)));
        
        //#line 577 "x10/regionarray/Array.x10"
        return v;
    }
    
    
    //#line 594 "x10/regionarray/Array.x10"
    /**
     * Set the element of this array corresponding to the given triple of indices to the given value.
     * Return the new value of the element.
     * Only applies to three-dimensional arrays.
     * Functionally equivalent to setting the array via a three-dimensional point.
     * 
     * @param v the given value
     * @param i0 the given index in the first dimension
     * @param i1 the given index in the second dimension
     * @param i2 the given index in the third dimension
     * @return the new value of the element of this array corresponding to the given triple of indices.
     * @see #operator(Long, Long, Long)
     * @see #set(T, Point)
     */
    public $T $set__3x10$regionarray$Array$$T$G(final long i0, final long i1, final long i2, final $T v) {
        
        //#line 595 "x10/regionarray/Array.x10"
        final x10.regionarray.Region t$140157 = ((x10.regionarray.Region)(this.region));
        
        //#line 595 "x10/regionarray/Array.x10"
        final boolean t$140158 = t$140157.contains$O((long)(i0), (long)(i1), (long)(i2));
        
        //#line 595 "x10/regionarray/Array.x10"
        final boolean t$140159 = !(t$140158);
        
        //#line 595 "x10/regionarray/Array.x10"
        if (t$140159) {
            
            //#line 596 "x10/regionarray/Array.x10"
            x10.regionarray.Array.raiseBoundsError((long)(i0), (long)(i1), (long)(i2));
        }
        
        //#line 598 "x10/regionarray/Array.x10"
        final x10.core.Rail t$140175 = ((x10.core.Rail)(this.raw));
        
        //#line 598 "x10/regionarray/Array.x10"
        final x10.regionarray.Array this$139413 = ((x10.regionarray.Array)(this));
        
        //#line 1300 . "x10/regionarray/Array.x10"
        final long t$140160 = ((x10.regionarray.Array<$T>)this$139413).layout_min0;
        
        //#line 1300 . "x10/regionarray/Array.x10"
        long offset$139412 = ((i0) - (((long)(t$140160))));
        
        //#line 1301 . "x10/regionarray/Array.x10"
        final long t$140162 = ((x10.regionarray.Array<$T>)this$139413).layout_stride1;
        
        //#line 1301 . "x10/regionarray/Array.x10"
        final long t$140163 = ((offset$139412) * (((long)(t$140162))));
        
        //#line 1301 . "x10/regionarray/Array.x10"
        final long t$140164 = ((t$140163) + (((long)(i1))));
        
        //#line 1301 . "x10/regionarray/Array.x10"
        final long t$140165 = ((x10.regionarray.Array<$T>)this$139413).layout_min1;
        
        //#line 1301 . "x10/regionarray/Array.x10"
        final long t$140166 = ((t$140164) - (((long)(t$140165))));
        
        //#line 1301 . "x10/regionarray/Array.x10"
        offset$139412 = t$140166;
        
        //#line 1302 . "x10/regionarray/Array.x10"
        final x10.core.Rail t$140167 = ((x10.core.Rail)(((x10.regionarray.Array<$T>)this$139413).layout));
        
        //#line 1302 . "x10/regionarray/Array.x10"
        final long t$140169 = ((long[])t$140167.value)[(int)0L];
        
        //#line 1302 . "x10/regionarray/Array.x10"
        final long t$140170 = ((offset$139412) * (((long)(t$140169))));
        
        //#line 1302 . "x10/regionarray/Array.x10"
        final long t$140172 = ((t$140170) + (((long)(i2))));
        
        //#line 1302 . "x10/regionarray/Array.x10"
        final x10.core.Rail t$140171 = ((x10.core.Rail)(((x10.regionarray.Array<$T>)this$139413).layout));
        
        //#line 1302 . "x10/regionarray/Array.x10"
        final long t$140173 = ((long[])t$140171.value)[(int)1L];
        
        //#line 1302 . "x10/regionarray/Array.x10"
        final long t$140174 = ((t$140172) - (((long)(t$140173))));
        
        //#line 1302 . "x10/regionarray/Array.x10"
        offset$139412 = t$140174;
        
        //#line 598 "x10/regionarray/Array.x10"
        ((x10.core.Rail<$T>)t$140175).$set__1x10$lang$Rail$$T$G((long)(offset$139412), (($T)(v)));
        
        //#line 599 "x10/regionarray/Array.x10"
        return v;
    }
    
    
    //#line 617 "x10/regionarray/Array.x10"
    /**
     * Set the element of this array corresponding to the given quartet of indices to the given value.
     * Return the new value of the element.
     * Only applies to four-dimensional arrays.
     * Functionally equivalent to setting the array via a four-dimensional point.
     * 
     * @param v the given value
     * @param i0 the given index in the first dimension
     * @param i1 the given index in the second dimension
     * @param i2 the given index in the third dimension
     * @param i3 the given index in the fourth dimension
     * @return the new value of the element of this array corresponding to the given quartet of indices.
     * @see #operator(Long, Long, Long, Long)
     * @see #set(T, Point)
     */
    public $T $set__4x10$regionarray$Array$$T$G(final long i0, final long i1, final long i2, final long i3, final $T v) {
        
        //#line 618 "x10/regionarray/Array.x10"
        final x10.regionarray.Region t$140177 = ((x10.regionarray.Region)(this.region));
        
        //#line 618 "x10/regionarray/Array.x10"
        final boolean t$140178 = t$140177.contains$O((long)(i0), (long)(i1), (long)(i2), (long)(i3));
        
        //#line 618 "x10/regionarray/Array.x10"
        final boolean t$140179 = !(t$140178);
        
        //#line 618 "x10/regionarray/Array.x10"
        if (t$140179) {
            
            //#line 619 "x10/regionarray/Array.x10"
            x10.regionarray.Array.raiseBoundsError((long)(i0), (long)(i1), (long)(i2), (long)(i3));
        }
        
        //#line 621 "x10/regionarray/Array.x10"
        final x10.core.Rail t$140203 = ((x10.core.Rail)(this.raw));
        
        //#line 621 "x10/regionarray/Array.x10"
        final x10.regionarray.Array this$139420 = ((x10.regionarray.Array)(this));
        
        //#line 1307 . "x10/regionarray/Array.x10"
        final long t$140180 = ((x10.regionarray.Array<$T>)this$139420).layout_min0;
        
        //#line 1307 . "x10/regionarray/Array.x10"
        long offset$139419 = ((i0) - (((long)(t$140180))));
        
        //#line 1308 . "x10/regionarray/Array.x10"
        final long t$140182 = ((x10.regionarray.Array<$T>)this$139420).layout_stride1;
        
        //#line 1308 . "x10/regionarray/Array.x10"
        final long t$140183 = ((offset$139419) * (((long)(t$140182))));
        
        //#line 1308 . "x10/regionarray/Array.x10"
        final long t$140184 = ((t$140183) + (((long)(i1))));
        
        //#line 1308 . "x10/regionarray/Array.x10"
        final long t$140185 = ((x10.regionarray.Array<$T>)this$139420).layout_min1;
        
        //#line 1308 . "x10/regionarray/Array.x10"
        final long t$140186 = ((t$140184) - (((long)(t$140185))));
        
        //#line 1308 . "x10/regionarray/Array.x10"
        offset$139419 = t$140186;
        
        //#line 1309 . "x10/regionarray/Array.x10"
        final x10.core.Rail t$140187 = ((x10.core.Rail)(((x10.regionarray.Array<$T>)this$139420).layout));
        
        //#line 1309 . "x10/regionarray/Array.x10"
        final long t$140189 = ((long[])t$140187.value)[(int)0L];
        
        //#line 1309 . "x10/regionarray/Array.x10"
        final long t$140190 = ((offset$139419) * (((long)(t$140189))));
        
        //#line 1309 . "x10/regionarray/Array.x10"
        final long t$140192 = ((t$140190) + (((long)(i2))));
        
        //#line 1309 . "x10/regionarray/Array.x10"
        final x10.core.Rail t$140191 = ((x10.core.Rail)(((x10.regionarray.Array<$T>)this$139420).layout));
        
        //#line 1309 . "x10/regionarray/Array.x10"
        final long t$140193 = ((long[])t$140191.value)[(int)1L];
        
        //#line 1309 . "x10/regionarray/Array.x10"
        final long t$140194 = ((t$140192) - (((long)(t$140193))));
        
        //#line 1309 . "x10/regionarray/Array.x10"
        offset$139419 = t$140194;
        
        //#line 1310 . "x10/regionarray/Array.x10"
        final x10.core.Rail t$140195 = ((x10.core.Rail)(((x10.regionarray.Array<$T>)this$139420).layout));
        
        //#line 1310 . "x10/regionarray/Array.x10"
        final long t$140197 = ((long[])t$140195.value)[(int)2L];
        
        //#line 1310 . "x10/regionarray/Array.x10"
        final long t$140198 = ((offset$139419) * (((long)(t$140197))));
        
        //#line 1310 . "x10/regionarray/Array.x10"
        final long t$140200 = ((t$140198) + (((long)(i3))));
        
        //#line 1310 . "x10/regionarray/Array.x10"
        final x10.core.Rail t$140199 = ((x10.core.Rail)(((x10.regionarray.Array<$T>)this$139420).layout));
        
        //#line 1310 . "x10/regionarray/Array.x10"
        final long t$140201 = ((long[])t$140199.value)[(int)3L];
        
        //#line 1310 . "x10/regionarray/Array.x10"
        final long t$140202 = ((t$140200) - (((long)(t$140201))));
        
        //#line 1310 . "x10/regionarray/Array.x10"
        offset$139419 = t$140202;
        
        //#line 621 "x10/regionarray/Array.x10"
        ((x10.core.Rail<$T>)t$140203).$set__1x10$lang$Rail$$T$G((long)(offset$139419), (($T)(v)));
        
        //#line 622 "x10/regionarray/Array.x10"
        return v;
    }
    
    
    //#line 636 "x10/regionarray/Array.x10"
    /**
     * Set the element of this array corresponding to the given point to the given value.
     * Return the new value of the element.
     * The rank of the given point has to be the same as the rank of this array.
     * 
     * @param v the given value
     * @param pt the given point
     * @return the new value of the element of this array corresponding to the given point.
     * @see #operator(Point)
     * @see #set(T, Long)
     */
    public $T $set__1x10$regionarray$Array$$T$G(final x10.lang.Point p, final $T v) {
        
        //#line 637 "x10/regionarray/Array.x10"
        final x10.regionarray.Region t$140205 = ((x10.regionarray.Region)(this.region));
        
        //#line 637 "x10/regionarray/Array.x10"
        final boolean t$140206 = t$140205.contains$O(((x10.lang.Point)(p)));
        
        //#line 637 "x10/regionarray/Array.x10"
        final boolean t$140207 = !(t$140206);
        
        //#line 637 "x10/regionarray/Array.x10"
        if (t$140207) {
            
            //#line 638 "x10/regionarray/Array.x10"
            x10.regionarray.Array.raiseBoundsError(((x10.lang.Point)(p)));
        }
        
        //#line 640 "x10/regionarray/Array.x10"
        final x10.core.Rail t$140240 = ((x10.core.Rail)(this.raw));
        
        //#line 640 "x10/regionarray/Array.x10"
        final x10.regionarray.Array this$139428 = ((x10.regionarray.Array)(this));
        
        //#line 1315 . "x10/regionarray/Array.x10"
        final long t$140208 = ((long)(((int)(0))));
        
        //#line 1315 . "x10/regionarray/Array.x10"
        final long t$140209 = p.$apply$O((long)(t$140208));
        
        //#line 1315 . "x10/regionarray/Array.x10"
        final long t$140210 = ((x10.regionarray.Array<$T>)this$139428).layout_min0;
        
        //#line 1315 . "x10/regionarray/Array.x10"
        long offset$139423 = ((t$140209) - (((long)(t$140210))));
        
        //#line 1316 . "x10/regionarray/Array.x10"
        final long t$140211 = p.rank;
        
        //#line 1316 . "x10/regionarray/Array.x10"
        final boolean t$140239 = ((t$140211) > (((long)(1L))));
        
        //#line 1316 . "x10/regionarray/Array.x10"
        if (t$140239) {
            
            //#line 1317 . "x10/regionarray/Array.x10"
            final long t$140213 = ((x10.regionarray.Array<$T>)this$139428).layout_stride1;
            
            //#line 1317 . "x10/regionarray/Array.x10"
            final long t$140214 = ((offset$139423) * (((long)(t$140213))));
            
            //#line 1317 . "x10/regionarray/Array.x10"
            final long t$140215 = p.$apply$O((long)(1L));
            
            //#line 1317 . "x10/regionarray/Array.x10"
            final long t$140216 = ((t$140214) + (((long)(t$140215))));
            
            //#line 1317 . "x10/regionarray/Array.x10"
            final long t$140217 = ((x10.regionarray.Array<$T>)this$139428).layout_min1;
            
            //#line 1317 . "x10/regionarray/Array.x10"
            final long t$140218 = ((t$140216) - (((long)(t$140217))));
            
            //#line 1317 . "x10/regionarray/Array.x10"
            offset$139423 = t$140218;
            
            //#line 1318 . "x10/regionarray/Array.x10"
            final long t$141895 = p.rank;
            
            //#line 1318 . "x10/regionarray/Array.x10"
            final long i$138773max$141896 = ((t$141895) - (((long)(1L))));
            
            //#line 1318 . "x10/regionarray/Array.x10"
            long i$141892 = 2L;
            
            //#line 1318 . "x10/regionarray/Array.x10"
            for (;
                 true;
                 ) {
                
                //#line 1318 . "x10/regionarray/Array.x10"
                final boolean t$141894 = ((i$141892) <= (((long)(i$138773max$141896))));
                
                //#line 1318 . "x10/regionarray/Array.x10"
                if (!(t$141894)) {
                    
                    //#line 1318 . "x10/regionarray/Array.x10"
                    break;
                }
                
                //#line 1319 . "x10/regionarray/Array.x10"
                final x10.core.Rail t$141876 = ((x10.core.Rail)(((x10.regionarray.Array<$T>)this$139428).layout));
                
                //#line 1319 . "x10/regionarray/Array.x10"
                final long t$141877 = ((i$141892) - (((long)(2L))));
                
                //#line 1319 . "x10/regionarray/Array.x10"
                final long t$141878 = ((2L) * (((long)(t$141877))));
                
                //#line 1319 . "x10/regionarray/Array.x10"
                final long t$141879 = ((long[])t$141876.value)[(int)t$141878];
                
                //#line 1319 . "x10/regionarray/Array.x10"
                final long t$141880 = ((offset$139423) * (((long)(t$141879))));
                
                //#line 1319 . "x10/regionarray/Array.x10"
                final long t$141881 = p.$apply$O((long)(i$141892));
                
                //#line 1319 . "x10/regionarray/Array.x10"
                final long t$141882 = ((t$141880) + (((long)(t$141881))));
                
                //#line 1319 . "x10/regionarray/Array.x10"
                final x10.core.Rail t$141883 = ((x10.core.Rail)(((x10.regionarray.Array<$T>)this$139428).layout));
                
                //#line 1319 . "x10/regionarray/Array.x10"
                final long t$141884 = ((i$141892) - (((long)(2L))));
                
                //#line 1319 . "x10/regionarray/Array.x10"
                final long t$141885 = ((2L) * (((long)(t$141884))));
                
                //#line 1319 . "x10/regionarray/Array.x10"
                final long t$141886 = ((t$141885) + (((long)(1L))));
                
                //#line 1319 . "x10/regionarray/Array.x10"
                final long t$141887 = ((long[])t$141883.value)[(int)t$141886];
                
                //#line 1319 . "x10/regionarray/Array.x10"
                final long t$141888 = ((t$141882) - (((long)(t$141887))));
                
                //#line 1319 . "x10/regionarray/Array.x10"
                offset$139423 = t$141888;
                
                //#line 1318 . "x10/regionarray/Array.x10"
                final long t$141891 = ((i$141892) + (((long)(1L))));
                
                //#line 1318 . "x10/regionarray/Array.x10"
                i$141892 = t$141891;
            }
        }
        
        //#line 640 "x10/regionarray/Array.x10"
        ((x10.core.Rail<$T>)t$140240).$set__1x10$lang$Rail$$T$G((long)(offset$139423), (($T)(v)));
        
        //#line 641 "x10/regionarray/Array.x10"
        return v;
    }
    
    
    //#line 650 "x10/regionarray/Array.x10"
    /**
     * Fill all elements of the array to contain the argument value.
     * 
     * @param v the value with which to fill the array
     */
    public void fill__0x10$regionarray$Array$$T(final $T v) {
        
        //#line 651 "x10/regionarray/Array.x10"
        final boolean t$140280 = this.rect;
        
        //#line 651 "x10/regionarray/Array.x10"
        if (t$140280) {
            
            //#line 654 "x10/regionarray/Array.x10"
            final x10.core.Rail t$140242 = ((x10.core.Rail)(this.raw));
            
            //#line 654 "x10/regionarray/Array.x10"
            ((x10.core.Rail<$T>)t$140242).fill__0x10$lang$Rail$$T((($T)(v)));
        } else {
            
            //#line 656 "x10/regionarray/Array.x10"
            final x10.regionarray.Region t$140244 = ((x10.regionarray.Region)(this.region));
            
            //#line 656 "x10/regionarray/Array.x10"
            final x10.lang.Iterator p$138624 = t$140244.iterator();
            
            //#line 656 "x10/regionarray/Array.x10"
            for (;
                 true;
                 ) {
                
                //#line 656 "x10/regionarray/Array.x10"
                final boolean t$140279 = ((x10.lang.Iterator<x10.lang.Point>)p$138624).hasNext$O();
                
                //#line 656 "x10/regionarray/Array.x10"
                if (!(t$140279)) {
                    
                    //#line 656 "x10/regionarray/Array.x10"
                    break;
                }
                
                //#line 656 "x10/regionarray/Array.x10"
                final x10.lang.Point p$141919 = ((x10.lang.Point)(((x10.lang.Iterator<x10.lang.Point>)p$138624).next$G()));
                
                //#line 657 "x10/regionarray/Array.x10"
                final x10.core.Rail t$141920 = ((x10.core.Rail)(this.raw));
                
                //#line 657 "x10/regionarray/Array.x10"
                final x10.regionarray.Array this$141921 = ((x10.regionarray.Array)(this));
                
                //#line 1315 . "x10/regionarray/Array.x10"
                final long t$141923 = ((long)(((int)(0))));
                
                //#line 1315 . "x10/regionarray/Array.x10"
                final long t$141924 = p$141919.$apply$O((long)(t$141923));
                
                //#line 1315 . "x10/regionarray/Array.x10"
                final long t$141925 = ((x10.regionarray.Array<$T>)this$141921).layout_min0;
                
                //#line 1315 . "x10/regionarray/Array.x10"
                long offset$141926 = ((t$141924) - (((long)(t$141925))));
                
                //#line 1316 . "x10/regionarray/Array.x10"
                final long t$141927 = p$141919.rank;
                
                //#line 1316 . "x10/regionarray/Array.x10"
                final boolean t$141928 = ((t$141927) > (((long)(1L))));
                
                //#line 1316 . "x10/regionarray/Array.x10"
                if (t$141928) {
                    
                    //#line 1317 . "x10/regionarray/Array.x10"
                    final long t$141930 = ((x10.regionarray.Array<$T>)this$141921).layout_stride1;
                    
                    //#line 1317 . "x10/regionarray/Array.x10"
                    final long t$141931 = ((offset$141926) * (((long)(t$141930))));
                    
                    //#line 1317 . "x10/regionarray/Array.x10"
                    final long t$141932 = p$141919.$apply$O((long)(1L));
                    
                    //#line 1317 . "x10/regionarray/Array.x10"
                    final long t$141933 = ((t$141931) + (((long)(t$141932))));
                    
                    //#line 1317 . "x10/regionarray/Array.x10"
                    final long t$141934 = ((x10.regionarray.Array<$T>)this$141921).layout_min1;
                    
                    //#line 1317 . "x10/regionarray/Array.x10"
                    final long t$141935 = ((t$141933) - (((long)(t$141934))));
                    
                    //#line 1317 . "x10/regionarray/Array.x10"
                    offset$141926 = t$141935;
                    
                    //#line 1318 . "x10/regionarray/Array.x10"
                    final long t$141917 = p$141919.rank;
                    
                    //#line 1318 . "x10/regionarray/Array.x10"
                    final long i$138773max$141918 = ((t$141917) - (((long)(1L))));
                    
                    //#line 1318 . "x10/regionarray/Array.x10"
                    long i$141914 = 2L;
                    
                    //#line 1318 . "x10/regionarray/Array.x10"
                    for (;
                         true;
                         ) {
                        
                        //#line 1318 . "x10/regionarray/Array.x10"
                        final boolean t$141916 = ((i$141914) <= (((long)(i$138773max$141918))));
                        
                        //#line 1318 . "x10/regionarray/Array.x10"
                        if (!(t$141916)) {
                            
                            //#line 1318 . "x10/regionarray/Array.x10"
                            break;
                        }
                        
                        //#line 1319 . "x10/regionarray/Array.x10"
                        final x10.core.Rail t$141898 = ((x10.core.Rail)(((x10.regionarray.Array<$T>)this$141921).layout));
                        
                        //#line 1319 . "x10/regionarray/Array.x10"
                        final long t$141899 = ((i$141914) - (((long)(2L))));
                        
                        //#line 1319 . "x10/regionarray/Array.x10"
                        final long t$141900 = ((2L) * (((long)(t$141899))));
                        
                        //#line 1319 . "x10/regionarray/Array.x10"
                        final long t$141901 = ((long[])t$141898.value)[(int)t$141900];
                        
                        //#line 1319 . "x10/regionarray/Array.x10"
                        final long t$141902 = ((offset$141926) * (((long)(t$141901))));
                        
                        //#line 1319 . "x10/regionarray/Array.x10"
                        final long t$141903 = p$141919.$apply$O((long)(i$141914));
                        
                        //#line 1319 . "x10/regionarray/Array.x10"
                        final long t$141904 = ((t$141902) + (((long)(t$141903))));
                        
                        //#line 1319 . "x10/regionarray/Array.x10"
                        final x10.core.Rail t$141905 = ((x10.core.Rail)(((x10.regionarray.Array<$T>)this$141921).layout));
                        
                        //#line 1319 . "x10/regionarray/Array.x10"
                        final long t$141906 = ((i$141914) - (((long)(2L))));
                        
                        //#line 1319 . "x10/regionarray/Array.x10"
                        final long t$141907 = ((2L) * (((long)(t$141906))));
                        
                        //#line 1319 . "x10/regionarray/Array.x10"
                        final long t$141908 = ((t$141907) + (((long)(1L))));
                        
                        //#line 1319 . "x10/regionarray/Array.x10"
                        final long t$141909 = ((long[])t$141905.value)[(int)t$141908];
                        
                        //#line 1319 . "x10/regionarray/Array.x10"
                        final long t$141910 = ((t$141904) - (((long)(t$141909))));
                        
                        //#line 1319 . "x10/regionarray/Array.x10"
                        offset$141926 = t$141910;
                        
                        //#line 1318 . "x10/regionarray/Array.x10"
                        final long t$141913 = ((i$141914) + (((long)(1L))));
                        
                        //#line 1318 . "x10/regionarray/Array.x10"
                        i$141914 = t$141913;
                    }
                }
                
                //#line 657 "x10/regionarray/Array.x10"
                ((x10.core.Rail<$T>)t$141920).$set__1x10$lang$Rail$$T$G((long)(offset$141926), (($T)(v)));
            }
        }
    }
    
    
    //#line 667 "x10/regionarray/Array.x10"
    /**
     * Fill all elements of the array with the zero value of type T 
     * @see x10.lang.Zero.get[T]()
     */
    public void clear() {
        
        //#line 668 "x10/regionarray/Array.x10"
        final x10.core.Rail t$140282 = ((x10.core.Rail)(this.raw));
        
        //#line 668 "x10/regionarray/Array.x10"
        final x10.core.Rail t$140281 = ((x10.core.Rail)(this.raw));
        
        //#line 668 "x10/regionarray/Array.x10"
        final long t$140283 = ((x10.core.Rail<$T>)t$140281).size;
        
        //#line 668 "x10/regionarray/Array.x10"
        ((x10.core.Rail<$T>)t$140282).clear((long)(0L), (long)(t$140283));
    }
    
    
    //#line 684 "x10/regionarray/Array.x10"
    /**
     * Map the function onto the elements of this array
     * constructing a new result array such that for all points <code>p</code>
     * in <code>this.region</code>,
     * <code>result(p) == op(this(p))</code>.<p>
     * 
     * @param op the function to apply to each element of the array
     * @return a new array with the same region as this array where <code>result(p) == op(this(p))</code>
     * 
     * @see #reduce((U,T)=>U,U)
     * @see #scan((U,T)=>U,U)
     */
    public <$U>x10.regionarray.Array map__0$1x10$regionarray$Array$$T$3x10$regionarray$Array$$U$2(final x10.rtt.Type $U, final x10.core.fun.Fun_0_1 op) {
        
        //#line 685 "x10/regionarray/Array.x10"
        final x10.regionarray.Array alloc$138541 = ((x10.regionarray.Array)(new x10.regionarray.Array<$U>((java.lang.System[]) null, $U)));
        
        //#line 685 "x10/regionarray/Array.x10"
        final x10.regionarray.Region reg$139448 = ((x10.regionarray.Region)(this.region));
        
        //#line 174 . "x10/regionarray/Array.x10"
        final x10.regionarray.Region t$142021 = ((x10.regionarray.Region)
                                                  reg$139448);
        
        //#line 174 . "x10/regionarray/Array.x10"
        final boolean t$142022 = ((t$142021) != (null));
        
        //#line 174 . "x10/regionarray/Array.x10"
        final boolean t$142023 = !(t$142022);
        
        //#line 174 . "x10/regionarray/Array.x10"
        if (t$142023) {
            
            //#line 174 . "x10/regionarray/Array.x10"
            final boolean t$142024 = true;
            
            //#line 174 . "x10/regionarray/Array.x10"
            if (t$142024) {
                
                //#line 174 . "x10/regionarray/Array.x10"
                final x10.lang.FailedDynamicCheckException t$142025 = new x10.lang.FailedDynamicCheckException("x10.regionarray.Region{self!=null}");
                
                //#line 174 . "x10/regionarray/Array.x10"
                throw t$142025;
            }
        }
        
        //#line 174 . "x10/regionarray/Array.x10"
        ((x10.regionarray.Array<$U>)alloc$138541).region = ((x10.regionarray.Region)(t$142021));
        
        //#line 174 . "x10/regionarray/Array.x10"
        final long t$142026 = reg$139448.rank;
        
        //#line 174 . "x10/regionarray/Array.x10"
        ((x10.regionarray.Array<$U>)alloc$138541).rank = t$142026;
        
        //#line 174 . "x10/regionarray/Array.x10"
        final boolean t$142027 = reg$139448.rect;
        
        //#line 174 . "x10/regionarray/Array.x10"
        ((x10.regionarray.Array<$U>)alloc$138541).rect = t$142027;
        
        //#line 174 . "x10/regionarray/Array.x10"
        final boolean t$142028 = reg$139448.zeroBased;
        
        //#line 174 . "x10/regionarray/Array.x10"
        ((x10.regionarray.Array<$U>)alloc$138541).zeroBased = t$142028;
        
        //#line 174 . "x10/regionarray/Array.x10"
        final boolean t$142029 = reg$139448.rail;
        
        //#line 174 . "x10/regionarray/Array.x10"
        ((x10.regionarray.Array<$U>)alloc$138541).rail = t$142029;
        
        //#line 174 . "x10/regionarray/Array.x10"
        final long t$142030 = reg$139448.size$O();
        
        //#line 174 . "x10/regionarray/Array.x10"
        ((x10.regionarray.Array<$U>)alloc$138541).size = t$142030;
        
        //#line 175 . "x10/regionarray/Array.x10"
        final x10.regionarray.Array.LayoutHelper crh$142033 = new x10.regionarray.Array.LayoutHelper((java.lang.System[]) null);
        
        //#line 175 . "x10/regionarray/Array.x10"
        crh$142033.x10$regionarray$Array$LayoutHelper$$init$S(((x10.regionarray.Region)(reg$139448)));
        
        //#line 176 . "x10/regionarray/Array.x10"
        final long t$142034 = crh$142033.min0;
        
        //#line 176 . "x10/regionarray/Array.x10"
        ((x10.regionarray.Array<$U>)alloc$138541).layout_min0 = t$142034;
        
        //#line 177 . "x10/regionarray/Array.x10"
        final long t$142035 = crh$142033.stride1;
        
        //#line 177 . "x10/regionarray/Array.x10"
        ((x10.regionarray.Array<$U>)alloc$138541).layout_stride1 = t$142035;
        
        //#line 178 . "x10/regionarray/Array.x10"
        final long t$142036 = crh$142033.min1;
        
        //#line 178 . "x10/regionarray/Array.x10"
        ((x10.regionarray.Array<$U>)alloc$138541).layout_min1 = t$142036;
        
        //#line 179 . "x10/regionarray/Array.x10"
        final x10.core.Rail t$142037 = ((x10.core.Rail)(crh$142033.layout));
        
        //#line 179 . "x10/regionarray/Array.x10"
        ((x10.regionarray.Array<$U>)alloc$138541).layout = ((x10.core.Rail)(t$142037));
        
        //#line 180 . "x10/regionarray/Array.x10"
        final long n$142038 = crh$142033.size;
        
        //#line 181 . "x10/regionarray/Array.x10"
        final x10.core.Rail r$142039 = ((x10.core.Rail)(x10.core.Rail.<$U>makeUnsafe($U, ((long)(n$142038)), false)));
        
        //#line 182 . "x10/regionarray/Array.x10"
        final x10.lang.Iterator p$142031 = reg$139448.iterator();
        
        //#line 182 . "x10/regionarray/Array.x10"
        for (;
             true;
             ) {
            
            //#line 182 . "x10/regionarray/Array.x10"
            final boolean t$142032 = ((x10.lang.Iterator<x10.lang.Point>)p$142031).hasNext$O();
            
            //#line 182 . "x10/regionarray/Array.x10"
            if (!(t$142032)) {
                
                //#line 182 . "x10/regionarray/Array.x10"
                break;
            }
            
            //#line 182 . "x10/regionarray/Array.x10"
            final x10.lang.Point p$141981 = ((x10.lang.Point)(((x10.lang.Iterator<x10.lang.Point>)p$142031).next$G()));
            
            //#line 1315 .. "x10/regionarray/Array.x10"
            final long t$141983 = ((long)(((int)(0))));
            
            //#line 1315 .. "x10/regionarray/Array.x10"
            final long t$141984 = p$141981.$apply$O((long)(t$141983));
            
            //#line 1315 .. "x10/regionarray/Array.x10"
            final long t$141985 = ((x10.regionarray.Array<$U>)alloc$138541).layout_min0;
            
            //#line 1315 .. "x10/regionarray/Array.x10"
            long offset$141986 = ((t$141984) - (((long)(t$141985))));
            
            //#line 1316 .. "x10/regionarray/Array.x10"
            final long t$141987 = p$141981.rank;
            
            //#line 1316 .. "x10/regionarray/Array.x10"
            final boolean t$141988 = ((t$141987) > (((long)(1L))));
            
            //#line 1316 .. "x10/regionarray/Array.x10"
            if (t$141988) {
                
                //#line 1317 .. "x10/regionarray/Array.x10"
                final long t$141990 = ((x10.regionarray.Array<$U>)alloc$138541).layout_stride1;
                
                //#line 1317 .. "x10/regionarray/Array.x10"
                final long t$141991 = ((offset$141986) * (((long)(t$141990))));
                
                //#line 1317 .. "x10/regionarray/Array.x10"
                final long t$141992 = p$141981.$apply$O((long)(1L));
                
                //#line 1317 .. "x10/regionarray/Array.x10"
                final long t$141993 = ((t$141991) + (((long)(t$141992))));
                
                //#line 1317 .. "x10/regionarray/Array.x10"
                final long t$141994 = ((x10.regionarray.Array<$U>)alloc$138541).layout_min1;
                
                //#line 1317 .. "x10/regionarray/Array.x10"
                final long t$141995 = ((t$141993) - (((long)(t$141994))));
                
                //#line 1317 .. "x10/regionarray/Array.x10"
                offset$141986 = t$141995;
                
                //#line 1318 .. "x10/regionarray/Array.x10"
                final long t$141957 = p$141981.rank;
                
                //#line 1318 .. "x10/regionarray/Array.x10"
                final long i$138773max$141958 = ((t$141957) - (((long)(1L))));
                
                //#line 1318 .. "x10/regionarray/Array.x10"
                long i$141954 = 2L;
                
                //#line 1318 .. "x10/regionarray/Array.x10"
                for (;
                     true;
                     ) {
                    
                    //#line 1318 .. "x10/regionarray/Array.x10"
                    final boolean t$141956 = ((i$141954) <= (((long)(i$138773max$141958))));
                    
                    //#line 1318 .. "x10/regionarray/Array.x10"
                    if (!(t$141956)) {
                        
                        //#line 1318 .. "x10/regionarray/Array.x10"
                        break;
                    }
                    
                    //#line 1319 .. "x10/regionarray/Array.x10"
                    final x10.core.Rail t$141938 = ((x10.core.Rail)(((x10.regionarray.Array<$U>)alloc$138541).layout));
                    
                    //#line 1319 .. "x10/regionarray/Array.x10"
                    final long t$141939 = ((i$141954) - (((long)(2L))));
                    
                    //#line 1319 .. "x10/regionarray/Array.x10"
                    final long t$141940 = ((2L) * (((long)(t$141939))));
                    
                    //#line 1319 .. "x10/regionarray/Array.x10"
                    final long t$141941 = ((long[])t$141938.value)[(int)t$141940];
                    
                    //#line 1319 .. "x10/regionarray/Array.x10"
                    final long t$141942 = ((offset$141986) * (((long)(t$141941))));
                    
                    //#line 1319 .. "x10/regionarray/Array.x10"
                    final long t$141943 = p$141981.$apply$O((long)(i$141954));
                    
                    //#line 1319 .. "x10/regionarray/Array.x10"
                    final long t$141944 = ((t$141942) + (((long)(t$141943))));
                    
                    //#line 1319 .. "x10/regionarray/Array.x10"
                    final x10.core.Rail t$141945 = ((x10.core.Rail)(((x10.regionarray.Array<$U>)alloc$138541).layout));
                    
                    //#line 1319 .. "x10/regionarray/Array.x10"
                    final long t$141946 = ((i$141954) - (((long)(2L))));
                    
                    //#line 1319 .. "x10/regionarray/Array.x10"
                    final long t$141947 = ((2L) * (((long)(t$141946))));
                    
                    //#line 1319 .. "x10/regionarray/Array.x10"
                    final long t$141948 = ((t$141947) + (((long)(1L))));
                    
                    //#line 1319 .. "x10/regionarray/Array.x10"
                    final long t$141949 = ((long[])t$141945.value)[(int)t$141948];
                    
                    //#line 1319 .. "x10/regionarray/Array.x10"
                    final long t$141950 = ((t$141944) - (((long)(t$141949))));
                    
                    //#line 1319 .. "x10/regionarray/Array.x10"
                    offset$141986 = t$141950;
                    
                    //#line 1318 .. "x10/regionarray/Array.x10"
                    final long t$141953 = ((i$141954) + (((long)(1L))));
                    
                    //#line 1318 .. "x10/regionarray/Array.x10"
                    i$141954 = t$141953;
                }
            }
            
            //#line 685 .. "x10/regionarray/Array.x10"
            final x10.regionarray.Array this$141998 = ((x10.regionarray.Array)(this));
            
            //#line 524 ... "x10/regionarray/Array.x10"
            final x10.regionarray.Region t$142000 = ((x10.regionarray.Region)(((x10.regionarray.Array<$T>)this$141998).region));
            
            //#line 524 ... "x10/regionarray/Array.x10"
            final boolean t$142001 = t$142000.contains$O(((x10.lang.Point)(p$141981)));
            
            //#line 524 ... "x10/regionarray/Array.x10"
            final boolean t$142002 = !(t$142001);
            
            //#line 524 ... "x10/regionarray/Array.x10"
            if (t$142002) {
                
                //#line 525 ... "x10/regionarray/Array.x10"
                x10.regionarray.Array.raiseBoundsError(((x10.lang.Point)(p$141981)));
            }
            
            //#line 527 ... "x10/regionarray/Array.x10"
            final x10.core.Rail t$142003 = ((x10.core.Rail)(((x10.regionarray.Array<$T>)this$141998).raw));
            
            //#line 1315 .... "x10/regionarray/Array.x10"
            final long t$142005 = ((long)(((int)(0))));
            
            //#line 1315 .... "x10/regionarray/Array.x10"
            final long t$142006 = p$141981.$apply$O((long)(t$142005));
            
            //#line 1315 .... "x10/regionarray/Array.x10"
            final long t$142007 = ((x10.regionarray.Array<$T>)this$141998).layout_min0;
            
            //#line 1315 .... "x10/regionarray/Array.x10"
            long offset$142008 = ((t$142006) - (((long)(t$142007))));
            
            //#line 1316 .... "x10/regionarray/Array.x10"
            final long t$142009 = p$141981.rank;
            
            //#line 1316 .... "x10/regionarray/Array.x10"
            final boolean t$142010 = ((t$142009) > (((long)(1L))));
            
            //#line 1316 .... "x10/regionarray/Array.x10"
            if (t$142010) {
                
                //#line 1317 .... "x10/regionarray/Array.x10"
                final long t$142012 = ((x10.regionarray.Array<$T>)this$141998).layout_stride1;
                
                //#line 1317 .... "x10/regionarray/Array.x10"
                final long t$142013 = ((offset$142008) * (((long)(t$142012))));
                
                //#line 1317 .... "x10/regionarray/Array.x10"
                final long t$142014 = p$141981.$apply$O((long)(1L));
                
                //#line 1317 .... "x10/regionarray/Array.x10"
                final long t$142015 = ((t$142013) + (((long)(t$142014))));
                
                //#line 1317 .... "x10/regionarray/Array.x10"
                final long t$142016 = ((x10.regionarray.Array<$T>)this$141998).layout_min1;
                
                //#line 1317 .... "x10/regionarray/Array.x10"
                final long t$142017 = ((t$142015) - (((long)(t$142016))));
                
                //#line 1317 .... "x10/regionarray/Array.x10"
                offset$142008 = t$142017;
                
                //#line 1318 .... "x10/regionarray/Array.x10"
                final long t$141979 = p$141981.rank;
                
                //#line 1318 .... "x10/regionarray/Array.x10"
                final long i$138773max$141980 = ((t$141979) - (((long)(1L))));
                
                //#line 1318 .... "x10/regionarray/Array.x10"
                long i$141976 = 2L;
                
                //#line 1318 .... "x10/regionarray/Array.x10"
                for (;
                     true;
                     ) {
                    
                    //#line 1318 .... "x10/regionarray/Array.x10"
                    final boolean t$141978 = ((i$141976) <= (((long)(i$138773max$141980))));
                    
                    //#line 1318 .... "x10/regionarray/Array.x10"
                    if (!(t$141978)) {
                        
                        //#line 1318 .... "x10/regionarray/Array.x10"
                        break;
                    }
                    
                    //#line 1319 .... "x10/regionarray/Array.x10"
                    final x10.core.Rail t$141960 = ((x10.core.Rail)(((x10.regionarray.Array<$T>)this$141998).layout));
                    
                    //#line 1319 .... "x10/regionarray/Array.x10"
                    final long t$141961 = ((i$141976) - (((long)(2L))));
                    
                    //#line 1319 .... "x10/regionarray/Array.x10"
                    final long t$141962 = ((2L) * (((long)(t$141961))));
                    
                    //#line 1319 .... "x10/regionarray/Array.x10"
                    final long t$141963 = ((long[])t$141960.value)[(int)t$141962];
                    
                    //#line 1319 .... "x10/regionarray/Array.x10"
                    final long t$141964 = ((offset$142008) * (((long)(t$141963))));
                    
                    //#line 1319 .... "x10/regionarray/Array.x10"
                    final long t$141965 = p$141981.$apply$O((long)(i$141976));
                    
                    //#line 1319 .... "x10/regionarray/Array.x10"
                    final long t$141966 = ((t$141964) + (((long)(t$141965))));
                    
                    //#line 1319 .... "x10/regionarray/Array.x10"
                    final x10.core.Rail t$141967 = ((x10.core.Rail)(((x10.regionarray.Array<$T>)this$141998).layout));
                    
                    //#line 1319 .... "x10/regionarray/Array.x10"
                    final long t$141968 = ((i$141976) - (((long)(2L))));
                    
                    //#line 1319 .... "x10/regionarray/Array.x10"
                    final long t$141969 = ((2L) * (((long)(t$141968))));
                    
                    //#line 1319 .... "x10/regionarray/Array.x10"
                    final long t$141970 = ((t$141969) + (((long)(1L))));
                    
                    //#line 1319 .... "x10/regionarray/Array.x10"
                    final long t$141971 = ((long[])t$141967.value)[(int)t$141970];
                    
                    //#line 1319 .... "x10/regionarray/Array.x10"
                    final long t$141972 = ((t$141966) - (((long)(t$141971))));
                    
                    //#line 1319 .... "x10/regionarray/Array.x10"
                    offset$142008 = t$141972;
                    
                    //#line 1318 .... "x10/regionarray/Array.x10"
                    final long t$141975 = ((i$141976) + (((long)(1L))));
                    
                    //#line 1318 .... "x10/regionarray/Array.x10"
                    i$141976 = t$141975;
                }
            }
            
            //#line 527 ... "x10/regionarray/Array.x10"
            final $T t$142019 = (($T)(((x10.core.Rail<$T>)t$142003).$apply$G((long)(offset$142008))));
            
            //#line 685 .. "x10/regionarray/Array.x10"
            final $U t$142020 = (($U)((($U)
                                        ((x10.core.fun.Fun_0_1<$T,$U>)op).$apply(t$142019, $T))));
            
            //#line 183 . "x10/regionarray/Array.x10"
            ((x10.core.Rail<$U>)r$142039).$set__1x10$lang$Rail$$T$G((long)(offset$141986), (($U)(t$142020)));
        }
        
        //#line 185 . "x10/regionarray/Array.x10"
        ((x10.regionarray.Array<$U>)alloc$138541).raw = ((x10.core.Rail)(r$142039));
        
        //#line 685 "x10/regionarray/Array.x10"
        return alloc$138541;
    }
    
    
    //#line 702 "x10/regionarray/Array.x10"
    /**
     * Map the given function onto the elements of this array
     * storing the results in the dst array such that for all points <code>p</code>
     * in <code>this.region</code>,
     * <code>dst(p) == op(this(p))</code>.<p>
     * 
     * @param dst the destination array for the results of the map operation
     * @param op the function to apply to each element of the array
     * @return dst after applying the map operation.
     * 
     * @see #reduce((U,T)=>U,U)
     * @see #scan((U,T)=>U,U)
     */
    public <$U>x10.regionarray.Array map__0$1x10$regionarray$Array$$U$2__1$1x10$regionarray$Array$$T$3x10$regionarray$Array$$U$2(final x10.rtt.Type $U, final x10.regionarray.Array dst, final x10.core.fun.Fun_0_1 op) {
        
        //#line 704 "x10/regionarray/Array.x10"
        final boolean t$140456 = this.rect;
        
        //#line 704 "x10/regionarray/Array.x10"
        if (t$140456) {
            
            //#line 708 "x10/regionarray/Array.x10"
            final x10.core.Rail src$139474 = ((x10.core.Rail)(this.raw));
            
            //#line 708 "x10/regionarray/Array.x10"
            final x10.core.Rail dst$139475 = ((x10.core.Rail)(((x10.regionarray.Array<$U>)dst).raw));
            
            //#line 180 . "x10/util/RailUtils.x10"
            final long i$97498max$142049 = ((x10.core.Rail<$T>)src$139474).size;
            
            //#line 180 . "x10/util/RailUtils.x10"
            long i$142045 = 0L;
            
            //#line 180 . "x10/util/RailUtils.x10"
            for (;
                 true;
                 ) {
                
                //#line 180 . "x10/util/RailUtils.x10"
                final boolean t$142047 = ((i$142045) < (((long)(i$97498max$142049))));
                
                //#line 180 . "x10/util/RailUtils.x10"
                if (!(t$142047)) {
                    
                    //#line 180 . "x10/util/RailUtils.x10"
                    break;
                }
                
                //#line 181 . "x10/util/RailUtils.x10"
                final $T t$142040 = (($T)(((x10.core.Rail<$T>)src$139474).$apply$G((long)(i$142045))));
                
                //#line 181 . "x10/util/RailUtils.x10"
                final $U t$142041 = (($U)((($U)
                                            ((x10.core.fun.Fun_0_1<$T,$U>)op).$apply(t$142040, $T))));
                
                //#line 181 . "x10/util/RailUtils.x10"
                ((x10.core.Rail<$U>)dst$139475).$set__1x10$lang$Rail$$T$G((long)(i$142045), (($U)(t$142041)));
                
                //#line 180 . "x10/util/RailUtils.x10"
                final long t$142044 = ((i$142045) + (((long)(1L))));
                
                //#line 180 . "x10/util/RailUtils.x10"
                i$142045 = t$142044;
            }
            
            //#line 709 "x10/regionarray/Array.x10"
            return dst;
        } else {
            
            //#line 711 "x10/regionarray/Array.x10"
            final x10.regionarray.Region t$140379 = ((x10.regionarray.Region)(this.region));
            
            //#line 711 "x10/regionarray/Array.x10"
            final x10.lang.Iterator p$138626 = t$140379.iterator();
            
            //#line 711 "x10/regionarray/Array.x10"
            for (;
                 true;
                 ) {
                
                //#line 711 "x10/regionarray/Array.x10"
                final boolean t$140455 = ((x10.lang.Iterator<x10.lang.Point>)p$138626).hasNext$O();
                
                //#line 711 "x10/regionarray/Array.x10"
                if (!(t$140455)) {
                    
                    //#line 711 "x10/regionarray/Array.x10"
                    break;
                }
                
                //#line 711 "x10/regionarray/Array.x10"
                final x10.lang.Point p$142094 = ((x10.lang.Point)(((x10.lang.Iterator<x10.lang.Point>)p$138626).next$G()));
                
                //#line 712 "x10/regionarray/Array.x10"
                final x10.regionarray.Array this$142096 = ((x10.regionarray.Array)(this));
                
                //#line 524 . "x10/regionarray/Array.x10"
                final x10.regionarray.Region t$142098 = ((x10.regionarray.Region)(((x10.regionarray.Array<$T>)this$142096).region));
                
                //#line 524 . "x10/regionarray/Array.x10"
                final boolean t$142099 = t$142098.contains$O(((x10.lang.Point)(p$142094)));
                
                //#line 524 . "x10/regionarray/Array.x10"
                final boolean t$142100 = !(t$142099);
                
                //#line 524 . "x10/regionarray/Array.x10"
                if (t$142100) {
                    
                    //#line 525 . "x10/regionarray/Array.x10"
                    x10.regionarray.Array.raiseBoundsError(((x10.lang.Point)(p$142094)));
                }
                
                //#line 527 . "x10/regionarray/Array.x10"
                final x10.core.Rail t$142101 = ((x10.core.Rail)(((x10.regionarray.Array<$T>)this$142096).raw));
                
                //#line 1315 .. "x10/regionarray/Array.x10"
                final long t$142103 = ((long)(((int)(0))));
                
                //#line 1315 .. "x10/regionarray/Array.x10"
                final long t$142104 = p$142094.$apply$O((long)(t$142103));
                
                //#line 1315 .. "x10/regionarray/Array.x10"
                final long t$142105 = ((x10.regionarray.Array<$T>)this$142096).layout_min0;
                
                //#line 1315 .. "x10/regionarray/Array.x10"
                long offset$142106 = ((t$142104) - (((long)(t$142105))));
                
                //#line 1316 .. "x10/regionarray/Array.x10"
                final long t$142107 = p$142094.rank;
                
                //#line 1316 .. "x10/regionarray/Array.x10"
                final boolean t$142108 = ((t$142107) > (((long)(1L))));
                
                //#line 1316 .. "x10/regionarray/Array.x10"
                if (t$142108) {
                    
                    //#line 1317 .. "x10/regionarray/Array.x10"
                    final long t$142110 = ((x10.regionarray.Array<$T>)this$142096).layout_stride1;
                    
                    //#line 1317 .. "x10/regionarray/Array.x10"
                    final long t$142111 = ((offset$142106) * (((long)(t$142110))));
                    
                    //#line 1317 .. "x10/regionarray/Array.x10"
                    final long t$142112 = p$142094.$apply$O((long)(1L));
                    
                    //#line 1317 .. "x10/regionarray/Array.x10"
                    final long t$142113 = ((t$142111) + (((long)(t$142112))));
                    
                    //#line 1317 .. "x10/regionarray/Array.x10"
                    final long t$142114 = ((x10.regionarray.Array<$T>)this$142096).layout_min1;
                    
                    //#line 1317 .. "x10/regionarray/Array.x10"
                    final long t$142115 = ((t$142113) - (((long)(t$142114))));
                    
                    //#line 1317 .. "x10/regionarray/Array.x10"
                    offset$142106 = t$142115;
                    
                    //#line 1318 .. "x10/regionarray/Array.x10"
                    final long t$142070 = p$142094.rank;
                    
                    //#line 1318 .. "x10/regionarray/Array.x10"
                    final long i$138773max$142071 = ((t$142070) - (((long)(1L))));
                    
                    //#line 1318 .. "x10/regionarray/Array.x10"
                    long i$142067 = 2L;
                    
                    //#line 1318 .. "x10/regionarray/Array.x10"
                    for (;
                         true;
                         ) {
                        
                        //#line 1318 .. "x10/regionarray/Array.x10"
                        final boolean t$142069 = ((i$142067) <= (((long)(i$138773max$142071))));
                        
                        //#line 1318 .. "x10/regionarray/Array.x10"
                        if (!(t$142069)) {
                            
                            //#line 1318 .. "x10/regionarray/Array.x10"
                            break;
                        }
                        
                        //#line 1319 .. "x10/regionarray/Array.x10"
                        final x10.core.Rail t$142051 = ((x10.core.Rail)(((x10.regionarray.Array<$T>)this$142096).layout));
                        
                        //#line 1319 .. "x10/regionarray/Array.x10"
                        final long t$142052 = ((i$142067) - (((long)(2L))));
                        
                        //#line 1319 .. "x10/regionarray/Array.x10"
                        final long t$142053 = ((2L) * (((long)(t$142052))));
                        
                        //#line 1319 .. "x10/regionarray/Array.x10"
                        final long t$142054 = ((long[])t$142051.value)[(int)t$142053];
                        
                        //#line 1319 .. "x10/regionarray/Array.x10"
                        final long t$142055 = ((offset$142106) * (((long)(t$142054))));
                        
                        //#line 1319 .. "x10/regionarray/Array.x10"
                        final long t$142056 = p$142094.$apply$O((long)(i$142067));
                        
                        //#line 1319 .. "x10/regionarray/Array.x10"
                        final long t$142057 = ((t$142055) + (((long)(t$142056))));
                        
                        //#line 1319 .. "x10/regionarray/Array.x10"
                        final x10.core.Rail t$142058 = ((x10.core.Rail)(((x10.regionarray.Array<$T>)this$142096).layout));
                        
                        //#line 1319 .. "x10/regionarray/Array.x10"
                        final long t$142059 = ((i$142067) - (((long)(2L))));
                        
                        //#line 1319 .. "x10/regionarray/Array.x10"
                        final long t$142060 = ((2L) * (((long)(t$142059))));
                        
                        //#line 1319 .. "x10/regionarray/Array.x10"
                        final long t$142061 = ((t$142060) + (((long)(1L))));
                        
                        //#line 1319 .. "x10/regionarray/Array.x10"
                        final long t$142062 = ((long[])t$142058.value)[(int)t$142061];
                        
                        //#line 1319 .. "x10/regionarray/Array.x10"
                        final long t$142063 = ((t$142057) - (((long)(t$142062))));
                        
                        //#line 1319 .. "x10/regionarray/Array.x10"
                        offset$142106 = t$142063;
                        
                        //#line 1318 .. "x10/regionarray/Array.x10"
                        final long t$142066 = ((i$142067) + (((long)(1L))));
                        
                        //#line 1318 .. "x10/regionarray/Array.x10"
                        i$142067 = t$142066;
                    }
                }
                
                //#line 527 . "x10/regionarray/Array.x10"
                final $T t$142117 = (($T)(((x10.core.Rail<$T>)t$142101).$apply$G((long)(offset$142106))));
                
                //#line 712 "x10/regionarray/Array.x10"
                final $U v$142118 = (($U)((($U)
                                            ((x10.core.fun.Fun_0_1<$T,$U>)op).$apply(t$142117, $T))));
                
                //#line 637 . "x10/regionarray/Array.x10"
                final x10.regionarray.Region t$142119 = ((x10.regionarray.Region)(((x10.regionarray.Array<$U>)dst).region));
                
                //#line 637 . "x10/regionarray/Array.x10"
                final boolean t$142120 = t$142119.contains$O(((x10.lang.Point)(p$142094)));
                
                //#line 637 . "x10/regionarray/Array.x10"
                final boolean t$142121 = !(t$142120);
                
                //#line 637 . "x10/regionarray/Array.x10"
                if (t$142121) {
                    
                    //#line 638 . "x10/regionarray/Array.x10"
                    x10.regionarray.Array.raiseBoundsError(((x10.lang.Point)(p$142094)));
                }
                
                //#line 640 . "x10/regionarray/Array.x10"
                final x10.core.Rail t$142122 = ((x10.core.Rail)(((x10.regionarray.Array<$U>)dst).raw));
                
                //#line 1315 .. "x10/regionarray/Array.x10"
                final long t$142124 = ((long)(((int)(0))));
                
                //#line 1315 .. "x10/regionarray/Array.x10"
                final long t$142125 = p$142094.$apply$O((long)(t$142124));
                
                //#line 1315 .. "x10/regionarray/Array.x10"
                final long t$142126 = ((x10.regionarray.Array<$U>)dst).layout_min0;
                
                //#line 1315 .. "x10/regionarray/Array.x10"
                long offset$142127 = ((t$142125) - (((long)(t$142126))));
                
                //#line 1316 .. "x10/regionarray/Array.x10"
                final long t$142128 = p$142094.rank;
                
                //#line 1316 .. "x10/regionarray/Array.x10"
                final boolean t$142129 = ((t$142128) > (((long)(1L))));
                
                //#line 1316 .. "x10/regionarray/Array.x10"
                if (t$142129) {
                    
                    //#line 1317 .. "x10/regionarray/Array.x10"
                    final long t$142131 = ((x10.regionarray.Array<$U>)dst).layout_stride1;
                    
                    //#line 1317 .. "x10/regionarray/Array.x10"
                    final long t$142132 = ((offset$142127) * (((long)(t$142131))));
                    
                    //#line 1317 .. "x10/regionarray/Array.x10"
                    final long t$142133 = p$142094.$apply$O((long)(1L));
                    
                    //#line 1317 .. "x10/regionarray/Array.x10"
                    final long t$142134 = ((t$142132) + (((long)(t$142133))));
                    
                    //#line 1317 .. "x10/regionarray/Array.x10"
                    final long t$142135 = ((x10.regionarray.Array<$U>)dst).layout_min1;
                    
                    //#line 1317 .. "x10/regionarray/Array.x10"
                    final long t$142136 = ((t$142134) - (((long)(t$142135))));
                    
                    //#line 1317 .. "x10/regionarray/Array.x10"
                    offset$142127 = t$142136;
                    
                    //#line 1318 .. "x10/regionarray/Array.x10"
                    final long t$142092 = p$142094.rank;
                    
                    //#line 1318 .. "x10/regionarray/Array.x10"
                    final long i$138773max$142093 = ((t$142092) - (((long)(1L))));
                    
                    //#line 1318 .. "x10/regionarray/Array.x10"
                    long i$142089 = 2L;
                    
                    //#line 1318 .. "x10/regionarray/Array.x10"
                    for (;
                         true;
                         ) {
                        
                        //#line 1318 .. "x10/regionarray/Array.x10"
                        final boolean t$142091 = ((i$142089) <= (((long)(i$138773max$142093))));
                        
                        //#line 1318 .. "x10/regionarray/Array.x10"
                        if (!(t$142091)) {
                            
                            //#line 1318 .. "x10/regionarray/Array.x10"
                            break;
                        }
                        
                        //#line 1319 .. "x10/regionarray/Array.x10"
                        final x10.core.Rail t$142073 = ((x10.core.Rail)(((x10.regionarray.Array<$U>)dst).layout));
                        
                        //#line 1319 .. "x10/regionarray/Array.x10"
                        final long t$142074 = ((i$142089) - (((long)(2L))));
                        
                        //#line 1319 .. "x10/regionarray/Array.x10"
                        final long t$142075 = ((2L) * (((long)(t$142074))));
                        
                        //#line 1319 .. "x10/regionarray/Array.x10"
                        final long t$142076 = ((long[])t$142073.value)[(int)t$142075];
                        
                        //#line 1319 .. "x10/regionarray/Array.x10"
                        final long t$142077 = ((offset$142127) * (((long)(t$142076))));
                        
                        //#line 1319 .. "x10/regionarray/Array.x10"
                        final long t$142078 = p$142094.$apply$O((long)(i$142089));
                        
                        //#line 1319 .. "x10/regionarray/Array.x10"
                        final long t$142079 = ((t$142077) + (((long)(t$142078))));
                        
                        //#line 1319 .. "x10/regionarray/Array.x10"
                        final x10.core.Rail t$142080 = ((x10.core.Rail)(((x10.regionarray.Array<$U>)dst).layout));
                        
                        //#line 1319 .. "x10/regionarray/Array.x10"
                        final long t$142081 = ((i$142089) - (((long)(2L))));
                        
                        //#line 1319 .. "x10/regionarray/Array.x10"
                        final long t$142082 = ((2L) * (((long)(t$142081))));
                        
                        //#line 1319 .. "x10/regionarray/Array.x10"
                        final long t$142083 = ((t$142082) + (((long)(1L))));
                        
                        //#line 1319 .. "x10/regionarray/Array.x10"
                        final long t$142084 = ((long[])t$142080.value)[(int)t$142083];
                        
                        //#line 1319 .. "x10/regionarray/Array.x10"
                        final long t$142085 = ((t$142079) - (((long)(t$142084))));
                        
                        //#line 1319 .. "x10/regionarray/Array.x10"
                        offset$142127 = t$142085;
                        
                        //#line 1318 .. "x10/regionarray/Array.x10"
                        final long t$142088 = ((i$142089) + (((long)(1L))));
                        
                        //#line 1318 .. "x10/regionarray/Array.x10"
                        i$142089 = t$142088;
                    }
                }
                
                //#line 640 . "x10/regionarray/Array.x10"
                ((x10.core.Rail<$U>)t$142122).$set__1x10$lang$Rail$$T$G((long)(offset$142127), (($U)(v$142118)));
            }
        }
        
        //#line 715 "x10/regionarray/Array.x10"
        return dst;
    }
    
    
    //#line 733 "x10/regionarray/Array.x10"
    /**
     * Map the given function onto the elements of this array for the subset
     * of points contained in the filter region such that for all points <code>p</code>
     * in <code>filter</code>,
     * <code>dst(p) == op(this(p))</code>.<p>
     * 
     * @param dst the destination array for the results of the map operation
     * @param filter the region to select the subset of points to include in the map
     * @param op the function to apply to each element of the array
     * @return dst after applying the map operation.
     * 
     * @see #reduce((U,T)=>U,U)
     * @see #scan((U,T)=>U,U)
     */
    public <$U>x10.regionarray.Array map__0$1x10$regionarray$Array$$U$2__2$1x10$regionarray$Array$$T$3x10$regionarray$Array$$U$2(final x10.rtt.Type $U, final x10.regionarray.Array dst, final x10.regionarray.Region filter, final x10.core.fun.Fun_0_1 op) {
        
        //#line 734 "x10/regionarray/Array.x10"
        final x10.regionarray.Region t$140457 = ((x10.regionarray.Region)(this.region));
        
        //#line 734 "x10/regionarray/Array.x10"
        final x10.regionarray.Region fregion = ((x10.regionarray.Region)(t$140457.$and(((x10.regionarray.Region)(filter)))));
        
        //#line 735 "x10/regionarray/Array.x10"
        final x10.lang.Iterator p$142226 = fregion.iterator();
        
        //#line 735 "x10/regionarray/Array.x10"
        for (;
             true;
             ) {
            
            //#line 735 "x10/regionarray/Array.x10"
            final boolean t$142227 = ((x10.lang.Iterator<x10.lang.Point>)p$142226).hasNext$O();
            
            //#line 735 "x10/regionarray/Array.x10"
            if (!(t$142227)) {
                
                //#line 735 "x10/regionarray/Array.x10"
                break;
            }
            
            //#line 735 "x10/regionarray/Array.x10"
            final x10.lang.Point p$142182 = ((x10.lang.Point)(((x10.lang.Iterator<x10.lang.Point>)p$142226).next$G()));
            
            //#line 736 "x10/regionarray/Array.x10"
            final x10.regionarray.Array this$142184 = ((x10.regionarray.Array)(this));
            
            //#line 524 . "x10/regionarray/Array.x10"
            final x10.regionarray.Region t$142186 = ((x10.regionarray.Region)(((x10.regionarray.Array<$T>)this$142184).region));
            
            //#line 524 . "x10/regionarray/Array.x10"
            final boolean t$142187 = t$142186.contains$O(((x10.lang.Point)(p$142182)));
            
            //#line 524 . "x10/regionarray/Array.x10"
            final boolean t$142188 = !(t$142187);
            
            //#line 524 . "x10/regionarray/Array.x10"
            if (t$142188) {
                
                //#line 525 . "x10/regionarray/Array.x10"
                x10.regionarray.Array.raiseBoundsError(((x10.lang.Point)(p$142182)));
            }
            
            //#line 527 . "x10/regionarray/Array.x10"
            final x10.core.Rail t$142189 = ((x10.core.Rail)(((x10.regionarray.Array<$T>)this$142184).raw));
            
            //#line 1315 .. "x10/regionarray/Array.x10"
            final long t$142191 = ((long)(((int)(0))));
            
            //#line 1315 .. "x10/regionarray/Array.x10"
            final long t$142192 = p$142182.$apply$O((long)(t$142191));
            
            //#line 1315 .. "x10/regionarray/Array.x10"
            final long t$142193 = ((x10.regionarray.Array<$T>)this$142184).layout_min0;
            
            //#line 1315 .. "x10/regionarray/Array.x10"
            long offset$142194 = ((t$142192) - (((long)(t$142193))));
            
            //#line 1316 .. "x10/regionarray/Array.x10"
            final long t$142195 = p$142182.rank;
            
            //#line 1316 .. "x10/regionarray/Array.x10"
            final boolean t$142196 = ((t$142195) > (((long)(1L))));
            
            //#line 1316 .. "x10/regionarray/Array.x10"
            if (t$142196) {
                
                //#line 1317 .. "x10/regionarray/Array.x10"
                final long t$142198 = ((x10.regionarray.Array<$T>)this$142184).layout_stride1;
                
                //#line 1317 .. "x10/regionarray/Array.x10"
                final long t$142199 = ((offset$142194) * (((long)(t$142198))));
                
                //#line 1317 .. "x10/regionarray/Array.x10"
                final long t$142200 = p$142182.$apply$O((long)(1L));
                
                //#line 1317 .. "x10/regionarray/Array.x10"
                final long t$142201 = ((t$142199) + (((long)(t$142200))));
                
                //#line 1317 .. "x10/regionarray/Array.x10"
                final long t$142202 = ((x10.regionarray.Array<$T>)this$142184).layout_min1;
                
                //#line 1317 .. "x10/regionarray/Array.x10"
                final long t$142203 = ((t$142201) - (((long)(t$142202))));
                
                //#line 1317 .. "x10/regionarray/Array.x10"
                offset$142194 = t$142203;
                
                //#line 1318 .. "x10/regionarray/Array.x10"
                final long t$142158 = p$142182.rank;
                
                //#line 1318 .. "x10/regionarray/Array.x10"
                final long i$138773max$142159 = ((t$142158) - (((long)(1L))));
                
                //#line 1318 .. "x10/regionarray/Array.x10"
                long i$142155 = 2L;
                
                //#line 1318 .. "x10/regionarray/Array.x10"
                for (;
                     true;
                     ) {
                    
                    //#line 1318 .. "x10/regionarray/Array.x10"
                    final boolean t$142157 = ((i$142155) <= (((long)(i$138773max$142159))));
                    
                    //#line 1318 .. "x10/regionarray/Array.x10"
                    if (!(t$142157)) {
                        
                        //#line 1318 .. "x10/regionarray/Array.x10"
                        break;
                    }
                    
                    //#line 1319 .. "x10/regionarray/Array.x10"
                    final x10.core.Rail t$142139 = ((x10.core.Rail)(((x10.regionarray.Array<$T>)this$142184).layout));
                    
                    //#line 1319 .. "x10/regionarray/Array.x10"
                    final long t$142140 = ((i$142155) - (((long)(2L))));
                    
                    //#line 1319 .. "x10/regionarray/Array.x10"
                    final long t$142141 = ((2L) * (((long)(t$142140))));
                    
                    //#line 1319 .. "x10/regionarray/Array.x10"
                    final long t$142142 = ((long[])t$142139.value)[(int)t$142141];
                    
                    //#line 1319 .. "x10/regionarray/Array.x10"
                    final long t$142143 = ((offset$142194) * (((long)(t$142142))));
                    
                    //#line 1319 .. "x10/regionarray/Array.x10"
                    final long t$142144 = p$142182.$apply$O((long)(i$142155));
                    
                    //#line 1319 .. "x10/regionarray/Array.x10"
                    final long t$142145 = ((t$142143) + (((long)(t$142144))));
                    
                    //#line 1319 .. "x10/regionarray/Array.x10"
                    final x10.core.Rail t$142146 = ((x10.core.Rail)(((x10.regionarray.Array<$T>)this$142184).layout));
                    
                    //#line 1319 .. "x10/regionarray/Array.x10"
                    final long t$142147 = ((i$142155) - (((long)(2L))));
                    
                    //#line 1319 .. "x10/regionarray/Array.x10"
                    final long t$142148 = ((2L) * (((long)(t$142147))));
                    
                    //#line 1319 .. "x10/regionarray/Array.x10"
                    final long t$142149 = ((t$142148) + (((long)(1L))));
                    
                    //#line 1319 .. "x10/regionarray/Array.x10"
                    final long t$142150 = ((long[])t$142146.value)[(int)t$142149];
                    
                    //#line 1319 .. "x10/regionarray/Array.x10"
                    final long t$142151 = ((t$142145) - (((long)(t$142150))));
                    
                    //#line 1319 .. "x10/regionarray/Array.x10"
                    offset$142194 = t$142151;
                    
                    //#line 1318 .. "x10/regionarray/Array.x10"
                    final long t$142154 = ((i$142155) + (((long)(1L))));
                    
                    //#line 1318 .. "x10/regionarray/Array.x10"
                    i$142155 = t$142154;
                }
            }
            
            //#line 527 . "x10/regionarray/Array.x10"
            final $T t$142205 = (($T)(((x10.core.Rail<$T>)t$142189).$apply$G((long)(offset$142194))));
            
            //#line 736 "x10/regionarray/Array.x10"
            final $U v$142206 = (($U)((($U)
                                        ((x10.core.fun.Fun_0_1<$T,$U>)op).$apply(t$142205, $T))));
            
            //#line 637 . "x10/regionarray/Array.x10"
            final x10.regionarray.Region t$142207 = ((x10.regionarray.Region)(((x10.regionarray.Array<$U>)dst).region));
            
            //#line 637 . "x10/regionarray/Array.x10"
            final boolean t$142208 = t$142207.contains$O(((x10.lang.Point)(p$142182)));
            
            //#line 637 . "x10/regionarray/Array.x10"
            final boolean t$142209 = !(t$142208);
            
            //#line 637 . "x10/regionarray/Array.x10"
            if (t$142209) {
                
                //#line 638 . "x10/regionarray/Array.x10"
                x10.regionarray.Array.raiseBoundsError(((x10.lang.Point)(p$142182)));
            }
            
            //#line 640 . "x10/regionarray/Array.x10"
            final x10.core.Rail t$142210 = ((x10.core.Rail)(((x10.regionarray.Array<$U>)dst).raw));
            
            //#line 1315 .. "x10/regionarray/Array.x10"
            final long t$142212 = ((long)(((int)(0))));
            
            //#line 1315 .. "x10/regionarray/Array.x10"
            final long t$142213 = p$142182.$apply$O((long)(t$142212));
            
            //#line 1315 .. "x10/regionarray/Array.x10"
            final long t$142214 = ((x10.regionarray.Array<$U>)dst).layout_min0;
            
            //#line 1315 .. "x10/regionarray/Array.x10"
            long offset$142215 = ((t$142213) - (((long)(t$142214))));
            
            //#line 1316 .. "x10/regionarray/Array.x10"
            final long t$142216 = p$142182.rank;
            
            //#line 1316 .. "x10/regionarray/Array.x10"
            final boolean t$142217 = ((t$142216) > (((long)(1L))));
            
            //#line 1316 .. "x10/regionarray/Array.x10"
            if (t$142217) {
                
                //#line 1317 .. "x10/regionarray/Array.x10"
                final long t$142219 = ((x10.regionarray.Array<$U>)dst).layout_stride1;
                
                //#line 1317 .. "x10/regionarray/Array.x10"
                final long t$142220 = ((offset$142215) * (((long)(t$142219))));
                
                //#line 1317 .. "x10/regionarray/Array.x10"
                final long t$142221 = p$142182.$apply$O((long)(1L));
                
                //#line 1317 .. "x10/regionarray/Array.x10"
                final long t$142222 = ((t$142220) + (((long)(t$142221))));
                
                //#line 1317 .. "x10/regionarray/Array.x10"
                final long t$142223 = ((x10.regionarray.Array<$U>)dst).layout_min1;
                
                //#line 1317 .. "x10/regionarray/Array.x10"
                final long t$142224 = ((t$142222) - (((long)(t$142223))));
                
                //#line 1317 .. "x10/regionarray/Array.x10"
                offset$142215 = t$142224;
                
                //#line 1318 .. "x10/regionarray/Array.x10"
                final long t$142180 = p$142182.rank;
                
                //#line 1318 .. "x10/regionarray/Array.x10"
                final long i$138773max$142181 = ((t$142180) - (((long)(1L))));
                
                //#line 1318 .. "x10/regionarray/Array.x10"
                long i$142177 = 2L;
                
                //#line 1318 .. "x10/regionarray/Array.x10"
                for (;
                     true;
                     ) {
                    
                    //#line 1318 .. "x10/regionarray/Array.x10"
                    final boolean t$142179 = ((i$142177) <= (((long)(i$138773max$142181))));
                    
                    //#line 1318 .. "x10/regionarray/Array.x10"
                    if (!(t$142179)) {
                        
                        //#line 1318 .. "x10/regionarray/Array.x10"
                        break;
                    }
                    
                    //#line 1319 .. "x10/regionarray/Array.x10"
                    final x10.core.Rail t$142161 = ((x10.core.Rail)(((x10.regionarray.Array<$U>)dst).layout));
                    
                    //#line 1319 .. "x10/regionarray/Array.x10"
                    final long t$142162 = ((i$142177) - (((long)(2L))));
                    
                    //#line 1319 .. "x10/regionarray/Array.x10"
                    final long t$142163 = ((2L) * (((long)(t$142162))));
                    
                    //#line 1319 .. "x10/regionarray/Array.x10"
                    final long t$142164 = ((long[])t$142161.value)[(int)t$142163];
                    
                    //#line 1319 .. "x10/regionarray/Array.x10"
                    final long t$142165 = ((offset$142215) * (((long)(t$142164))));
                    
                    //#line 1319 .. "x10/regionarray/Array.x10"
                    final long t$142166 = p$142182.$apply$O((long)(i$142177));
                    
                    //#line 1319 .. "x10/regionarray/Array.x10"
                    final long t$142167 = ((t$142165) + (((long)(t$142166))));
                    
                    //#line 1319 .. "x10/regionarray/Array.x10"
                    final x10.core.Rail t$142168 = ((x10.core.Rail)(((x10.regionarray.Array<$U>)dst).layout));
                    
                    //#line 1319 .. "x10/regionarray/Array.x10"
                    final long t$142169 = ((i$142177) - (((long)(2L))));
                    
                    //#line 1319 .. "x10/regionarray/Array.x10"
                    final long t$142170 = ((2L) * (((long)(t$142169))));
                    
                    //#line 1319 .. "x10/regionarray/Array.x10"
                    final long t$142171 = ((t$142170) + (((long)(1L))));
                    
                    //#line 1319 .. "x10/regionarray/Array.x10"
                    final long t$142172 = ((long[])t$142168.value)[(int)t$142171];
                    
                    //#line 1319 .. "x10/regionarray/Array.x10"
                    final long t$142173 = ((t$142167) - (((long)(t$142172))));
                    
                    //#line 1319 .. "x10/regionarray/Array.x10"
                    offset$142215 = t$142173;
                    
                    //#line 1318 .. "x10/regionarray/Array.x10"
                    final long t$142176 = ((i$142177) + (((long)(1L))));
                    
                    //#line 1318 .. "x10/regionarray/Array.x10"
                    i$142177 = t$142176;
                }
            }
            
            //#line 640 . "x10/regionarray/Array.x10"
            ((x10.core.Rail<$U>)t$142210).$set__1x10$lang$Rail$$T$G((long)(offset$142215), (($U)(v$142206)));
        }
        
        //#line 738 "x10/regionarray/Array.x10"
        return dst;
    }
    
    
    //#line 754 "x10/regionarray/Array.x10"
    /**
     * Map the given function onto the elements of this array
     * and the other src array, storing the results in a new result array 
     * such that for all points <code>p</code> in <code>this.region</code>,
     * <code>result(p) == op(this(p), src(p))</code>.<p>
     * 
     * @param src the other src array
     * @param op the function to apply to each element of the array
     * @return a new array with the same region as this array containing the result of the map
     * @see #reduce((U,T)=>U,U)
     * @see #scan((U,T)=>U,U)
     */
    public <$S, $U>x10.regionarray.Array map__0$1x10$regionarray$Array$$U$2__1$1x10$regionarray$Array$$T$3x10$regionarray$Array$$U$3x10$regionarray$Array$$S$2(final x10.rtt.Type $S, final x10.rtt.Type $U, final x10.regionarray.Array src, final x10.core.fun.Fun_0_2 op) {
        
        //#line 755 "x10/regionarray/Array.x10"
        final x10.regionarray.Array alloc$138542 = ((x10.regionarray.Array)(new x10.regionarray.Array<$S>((java.lang.System[]) null, $S)));
        
        //#line 755 "x10/regionarray/Array.x10"
        final x10.regionarray.Region reg$139542 = ((x10.regionarray.Region)(this.region));
        
        //#line 174 . "x10/regionarray/Array.x10"
        final x10.regionarray.Region t$142355 = ((x10.regionarray.Region)
                                                  reg$139542);
        
        //#line 174 . "x10/regionarray/Array.x10"
        final boolean t$142356 = ((t$142355) != (null));
        
        //#line 174 . "x10/regionarray/Array.x10"
        final boolean t$142357 = !(t$142356);
        
        //#line 174 . "x10/regionarray/Array.x10"
        if (t$142357) {
            
            //#line 174 . "x10/regionarray/Array.x10"
            final boolean t$142358 = true;
            
            //#line 174 . "x10/regionarray/Array.x10"
            if (t$142358) {
                
                //#line 174 . "x10/regionarray/Array.x10"
                final x10.lang.FailedDynamicCheckException t$142359 = new x10.lang.FailedDynamicCheckException("x10.regionarray.Region{self!=null}");
                
                //#line 174 . "x10/regionarray/Array.x10"
                throw t$142359;
            }
        }
        
        //#line 174 . "x10/regionarray/Array.x10"
        ((x10.regionarray.Array<$S>)alloc$138542).region = ((x10.regionarray.Region)(t$142355));
        
        //#line 174 . "x10/regionarray/Array.x10"
        final long t$142360 = reg$139542.rank;
        
        //#line 174 . "x10/regionarray/Array.x10"
        ((x10.regionarray.Array<$S>)alloc$138542).rank = t$142360;
        
        //#line 174 . "x10/regionarray/Array.x10"
        final boolean t$142361 = reg$139542.rect;
        
        //#line 174 . "x10/regionarray/Array.x10"
        ((x10.regionarray.Array<$S>)alloc$138542).rect = t$142361;
        
        //#line 174 . "x10/regionarray/Array.x10"
        final boolean t$142362 = reg$139542.zeroBased;
        
        //#line 174 . "x10/regionarray/Array.x10"
        ((x10.regionarray.Array<$S>)alloc$138542).zeroBased = t$142362;
        
        //#line 174 . "x10/regionarray/Array.x10"
        final boolean t$142363 = reg$139542.rail;
        
        //#line 174 . "x10/regionarray/Array.x10"
        ((x10.regionarray.Array<$S>)alloc$138542).rail = t$142363;
        
        //#line 174 . "x10/regionarray/Array.x10"
        final long t$142364 = reg$139542.size$O();
        
        //#line 174 . "x10/regionarray/Array.x10"
        ((x10.regionarray.Array<$S>)alloc$138542).size = t$142364;
        
        //#line 175 . "x10/regionarray/Array.x10"
        final x10.regionarray.Array.LayoutHelper crh$142367 = new x10.regionarray.Array.LayoutHelper((java.lang.System[]) null);
        
        //#line 175 . "x10/regionarray/Array.x10"
        crh$142367.x10$regionarray$Array$LayoutHelper$$init$S(((x10.regionarray.Region)(reg$139542)));
        
        //#line 176 . "x10/regionarray/Array.x10"
        final long t$142368 = crh$142367.min0;
        
        //#line 176 . "x10/regionarray/Array.x10"
        ((x10.regionarray.Array<$S>)alloc$138542).layout_min0 = t$142368;
        
        //#line 177 . "x10/regionarray/Array.x10"
        final long t$142369 = crh$142367.stride1;
        
        //#line 177 . "x10/regionarray/Array.x10"
        ((x10.regionarray.Array<$S>)alloc$138542).layout_stride1 = t$142369;
        
        //#line 178 . "x10/regionarray/Array.x10"
        final long t$142370 = crh$142367.min1;
        
        //#line 178 . "x10/regionarray/Array.x10"
        ((x10.regionarray.Array<$S>)alloc$138542).layout_min1 = t$142370;
        
        //#line 179 . "x10/regionarray/Array.x10"
        final x10.core.Rail t$142371 = ((x10.core.Rail)(crh$142367.layout));
        
        //#line 179 . "x10/regionarray/Array.x10"
        ((x10.regionarray.Array<$S>)alloc$138542).layout = ((x10.core.Rail)(t$142371));
        
        //#line 180 . "x10/regionarray/Array.x10"
        final long n$142372 = crh$142367.size;
        
        //#line 181 . "x10/regionarray/Array.x10"
        final x10.core.Rail r$142373 = ((x10.core.Rail)(x10.core.Rail.<$S>makeUnsafe($S, ((long)(n$142372)), false)));
        
        //#line 182 . "x10/regionarray/Array.x10"
        final x10.lang.Iterator p$142365 = reg$139542.iterator();
        
        //#line 182 . "x10/regionarray/Array.x10"
        for (;
             true;
             ) {
            
            //#line 182 . "x10/regionarray/Array.x10"
            final boolean t$142366 = ((x10.lang.Iterator<x10.lang.Point>)p$142365).hasNext$O();
            
            //#line 182 . "x10/regionarray/Array.x10"
            if (!(t$142366)) {
                
                //#line 182 . "x10/regionarray/Array.x10"
                break;
            }
            
            //#line 182 . "x10/regionarray/Array.x10"
            final x10.lang.Point p$142294 = ((x10.lang.Point)(((x10.lang.Iterator<x10.lang.Point>)p$142365).next$G()));
            
            //#line 1315 .. "x10/regionarray/Array.x10"
            final long t$142296 = ((long)(((int)(0))));
            
            //#line 1315 .. "x10/regionarray/Array.x10"
            final long t$142297 = p$142294.$apply$O((long)(t$142296));
            
            //#line 1315 .. "x10/regionarray/Array.x10"
            final long t$142298 = ((x10.regionarray.Array<$S>)alloc$138542).layout_min0;
            
            //#line 1315 .. "x10/regionarray/Array.x10"
            long offset$142299 = ((t$142297) - (((long)(t$142298))));
            
            //#line 1316 .. "x10/regionarray/Array.x10"
            final long t$142300 = p$142294.rank;
            
            //#line 1316 .. "x10/regionarray/Array.x10"
            final boolean t$142301 = ((t$142300) > (((long)(1L))));
            
            //#line 1316 .. "x10/regionarray/Array.x10"
            if (t$142301) {
                
                //#line 1317 .. "x10/regionarray/Array.x10"
                final long t$142303 = ((x10.regionarray.Array<$S>)alloc$138542).layout_stride1;
                
                //#line 1317 .. "x10/regionarray/Array.x10"
                final long t$142304 = ((offset$142299) * (((long)(t$142303))));
                
                //#line 1317 .. "x10/regionarray/Array.x10"
                final long t$142305 = p$142294.$apply$O((long)(1L));
                
                //#line 1317 .. "x10/regionarray/Array.x10"
                final long t$142306 = ((t$142304) + (((long)(t$142305))));
                
                //#line 1317 .. "x10/regionarray/Array.x10"
                final long t$142307 = ((x10.regionarray.Array<$S>)alloc$138542).layout_min1;
                
                //#line 1317 .. "x10/regionarray/Array.x10"
                final long t$142308 = ((t$142306) - (((long)(t$142307))));
                
                //#line 1317 .. "x10/regionarray/Array.x10"
                offset$142299 = t$142308;
                
                //#line 1318 .. "x10/regionarray/Array.x10"
                final long t$142248 = p$142294.rank;
                
                //#line 1318 .. "x10/regionarray/Array.x10"
                final long i$138773max$142249 = ((t$142248) - (((long)(1L))));
                
                //#line 1318 .. "x10/regionarray/Array.x10"
                long i$142245 = 2L;
                
                //#line 1318 .. "x10/regionarray/Array.x10"
                for (;
                     true;
                     ) {
                    
                    //#line 1318 .. "x10/regionarray/Array.x10"
                    final boolean t$142247 = ((i$142245) <= (((long)(i$138773max$142249))));
                    
                    //#line 1318 .. "x10/regionarray/Array.x10"
                    if (!(t$142247)) {
                        
                        //#line 1318 .. "x10/regionarray/Array.x10"
                        break;
                    }
                    
                    //#line 1319 .. "x10/regionarray/Array.x10"
                    final x10.core.Rail t$142229 = ((x10.core.Rail)(((x10.regionarray.Array<$S>)alloc$138542).layout));
                    
                    //#line 1319 .. "x10/regionarray/Array.x10"
                    final long t$142230 = ((i$142245) - (((long)(2L))));
                    
                    //#line 1319 .. "x10/regionarray/Array.x10"
                    final long t$142231 = ((2L) * (((long)(t$142230))));
                    
                    //#line 1319 .. "x10/regionarray/Array.x10"
                    final long t$142232 = ((long[])t$142229.value)[(int)t$142231];
                    
                    //#line 1319 .. "x10/regionarray/Array.x10"
                    final long t$142233 = ((offset$142299) * (((long)(t$142232))));
                    
                    //#line 1319 .. "x10/regionarray/Array.x10"
                    final long t$142234 = p$142294.$apply$O((long)(i$142245));
                    
                    //#line 1319 .. "x10/regionarray/Array.x10"
                    final long t$142235 = ((t$142233) + (((long)(t$142234))));
                    
                    //#line 1319 .. "x10/regionarray/Array.x10"
                    final x10.core.Rail t$142236 = ((x10.core.Rail)(((x10.regionarray.Array<$S>)alloc$138542).layout));
                    
                    //#line 1319 .. "x10/regionarray/Array.x10"
                    final long t$142237 = ((i$142245) - (((long)(2L))));
                    
                    //#line 1319 .. "x10/regionarray/Array.x10"
                    final long t$142238 = ((2L) * (((long)(t$142237))));
                    
                    //#line 1319 .. "x10/regionarray/Array.x10"
                    final long t$142239 = ((t$142238) + (((long)(1L))));
                    
                    //#line 1319 .. "x10/regionarray/Array.x10"
                    final long t$142240 = ((long[])t$142236.value)[(int)t$142239];
                    
                    //#line 1319 .. "x10/regionarray/Array.x10"
                    final long t$142241 = ((t$142235) - (((long)(t$142240))));
                    
                    //#line 1319 .. "x10/regionarray/Array.x10"
                    offset$142299 = t$142241;
                    
                    //#line 1318 .. "x10/regionarray/Array.x10"
                    final long t$142244 = ((i$142245) + (((long)(1L))));
                    
                    //#line 1318 .. "x10/regionarray/Array.x10"
                    i$142245 = t$142244;
                }
            }
            
            //#line 755 .. "x10/regionarray/Array.x10"
            final x10.regionarray.Array this$142311 = ((x10.regionarray.Array)(this));
            
            //#line 524 ... "x10/regionarray/Array.x10"
            final x10.regionarray.Region t$142313 = ((x10.regionarray.Region)(((x10.regionarray.Array<$T>)this$142311).region));
            
            //#line 524 ... "x10/regionarray/Array.x10"
            final boolean t$142314 = t$142313.contains$O(((x10.lang.Point)(p$142294)));
            
            //#line 524 ... "x10/regionarray/Array.x10"
            final boolean t$142315 = !(t$142314);
            
            //#line 524 ... "x10/regionarray/Array.x10"
            if (t$142315) {
                
                //#line 525 ... "x10/regionarray/Array.x10"
                x10.regionarray.Array.raiseBoundsError(((x10.lang.Point)(p$142294)));
            }
            
            //#line 527 ... "x10/regionarray/Array.x10"
            final x10.core.Rail t$142316 = ((x10.core.Rail)(((x10.regionarray.Array<$T>)this$142311).raw));
            
            //#line 1315 .... "x10/regionarray/Array.x10"
            final long t$142318 = ((long)(((int)(0))));
            
            //#line 1315 .... "x10/regionarray/Array.x10"
            final long t$142319 = p$142294.$apply$O((long)(t$142318));
            
            //#line 1315 .... "x10/regionarray/Array.x10"
            final long t$142320 = ((x10.regionarray.Array<$T>)this$142311).layout_min0;
            
            //#line 1315 .... "x10/regionarray/Array.x10"
            long offset$142321 = ((t$142319) - (((long)(t$142320))));
            
            //#line 1316 .... "x10/regionarray/Array.x10"
            final long t$142322 = p$142294.rank;
            
            //#line 1316 .... "x10/regionarray/Array.x10"
            final boolean t$142323 = ((t$142322) > (((long)(1L))));
            
            //#line 1316 .... "x10/regionarray/Array.x10"
            if (t$142323) {
                
                //#line 1317 .... "x10/regionarray/Array.x10"
                final long t$142325 = ((x10.regionarray.Array<$T>)this$142311).layout_stride1;
                
                //#line 1317 .... "x10/regionarray/Array.x10"
                final long t$142326 = ((offset$142321) * (((long)(t$142325))));
                
                //#line 1317 .... "x10/regionarray/Array.x10"
                final long t$142327 = p$142294.$apply$O((long)(1L));
                
                //#line 1317 .... "x10/regionarray/Array.x10"
                final long t$142328 = ((t$142326) + (((long)(t$142327))));
                
                //#line 1317 .... "x10/regionarray/Array.x10"
                final long t$142329 = ((x10.regionarray.Array<$T>)this$142311).layout_min1;
                
                //#line 1317 .... "x10/regionarray/Array.x10"
                final long t$142330 = ((t$142328) - (((long)(t$142329))));
                
                //#line 1317 .... "x10/regionarray/Array.x10"
                offset$142321 = t$142330;
                
                //#line 1318 .... "x10/regionarray/Array.x10"
                final long t$142270 = p$142294.rank;
                
                //#line 1318 .... "x10/regionarray/Array.x10"
                final long i$138773max$142271 = ((t$142270) - (((long)(1L))));
                
                //#line 1318 .... "x10/regionarray/Array.x10"
                long i$142267 = 2L;
                
                //#line 1318 .... "x10/regionarray/Array.x10"
                for (;
                     true;
                     ) {
                    
                    //#line 1318 .... "x10/regionarray/Array.x10"
                    final boolean t$142269 = ((i$142267) <= (((long)(i$138773max$142271))));
                    
                    //#line 1318 .... "x10/regionarray/Array.x10"
                    if (!(t$142269)) {
                        
                        //#line 1318 .... "x10/regionarray/Array.x10"
                        break;
                    }
                    
                    //#line 1319 .... "x10/regionarray/Array.x10"
                    final x10.core.Rail t$142251 = ((x10.core.Rail)(((x10.regionarray.Array<$T>)this$142311).layout));
                    
                    //#line 1319 .... "x10/regionarray/Array.x10"
                    final long t$142252 = ((i$142267) - (((long)(2L))));
                    
                    //#line 1319 .... "x10/regionarray/Array.x10"
                    final long t$142253 = ((2L) * (((long)(t$142252))));
                    
                    //#line 1319 .... "x10/regionarray/Array.x10"
                    final long t$142254 = ((long[])t$142251.value)[(int)t$142253];
                    
                    //#line 1319 .... "x10/regionarray/Array.x10"
                    final long t$142255 = ((offset$142321) * (((long)(t$142254))));
                    
                    //#line 1319 .... "x10/regionarray/Array.x10"
                    final long t$142256 = p$142294.$apply$O((long)(i$142267));
                    
                    //#line 1319 .... "x10/regionarray/Array.x10"
                    final long t$142257 = ((t$142255) + (((long)(t$142256))));
                    
                    //#line 1319 .... "x10/regionarray/Array.x10"
                    final x10.core.Rail t$142258 = ((x10.core.Rail)(((x10.regionarray.Array<$T>)this$142311).layout));
                    
                    //#line 1319 .... "x10/regionarray/Array.x10"
                    final long t$142259 = ((i$142267) - (((long)(2L))));
                    
                    //#line 1319 .... "x10/regionarray/Array.x10"
                    final long t$142260 = ((2L) * (((long)(t$142259))));
                    
                    //#line 1319 .... "x10/regionarray/Array.x10"
                    final long t$142261 = ((t$142260) + (((long)(1L))));
                    
                    //#line 1319 .... "x10/regionarray/Array.x10"
                    final long t$142262 = ((long[])t$142258.value)[(int)t$142261];
                    
                    //#line 1319 .... "x10/regionarray/Array.x10"
                    final long t$142263 = ((t$142257) - (((long)(t$142262))));
                    
                    //#line 1319 .... "x10/regionarray/Array.x10"
                    offset$142321 = t$142263;
                    
                    //#line 1318 .... "x10/regionarray/Array.x10"
                    final long t$142266 = ((i$142267) + (((long)(1L))));
                    
                    //#line 1318 .... "x10/regionarray/Array.x10"
                    i$142267 = t$142266;
                }
            }
            
            //#line 527 ... "x10/regionarray/Array.x10"
            final $T t$142332 = (($T)(((x10.core.Rail<$T>)t$142316).$apply$G((long)(offset$142321))));
            
            //#line 524 ... "x10/regionarray/Array.x10"
            final x10.regionarray.Region t$142334 = ((x10.regionarray.Region)(((x10.regionarray.Array<$U>)src).region));
            
            //#line 524 ... "x10/regionarray/Array.x10"
            final boolean t$142335 = t$142334.contains$O(((x10.lang.Point)(p$142294)));
            
            //#line 524 ... "x10/regionarray/Array.x10"
            final boolean t$142336 = !(t$142335);
            
            //#line 524 ... "x10/regionarray/Array.x10"
            if (t$142336) {
                
                //#line 525 ... "x10/regionarray/Array.x10"
                x10.regionarray.Array.raiseBoundsError(((x10.lang.Point)(p$142294)));
            }
            
            //#line 527 ... "x10/regionarray/Array.x10"
            final x10.core.Rail t$142337 = ((x10.core.Rail)(((x10.regionarray.Array<$U>)src).raw));
            
            //#line 1315 .... "x10/regionarray/Array.x10"
            final long t$142339 = ((long)(((int)(0))));
            
            //#line 1315 .... "x10/regionarray/Array.x10"
            final long t$142340 = p$142294.$apply$O((long)(t$142339));
            
            //#line 1315 .... "x10/regionarray/Array.x10"
            final long t$142341 = ((x10.regionarray.Array<$U>)src).layout_min0;
            
            //#line 1315 .... "x10/regionarray/Array.x10"
            long offset$142342 = ((t$142340) - (((long)(t$142341))));
            
            //#line 1316 .... "x10/regionarray/Array.x10"
            final long t$142343 = p$142294.rank;
            
            //#line 1316 .... "x10/regionarray/Array.x10"
            final boolean t$142344 = ((t$142343) > (((long)(1L))));
            
            //#line 1316 .... "x10/regionarray/Array.x10"
            if (t$142344) {
                
                //#line 1317 .... "x10/regionarray/Array.x10"
                final long t$142346 = ((x10.regionarray.Array<$U>)src).layout_stride1;
                
                //#line 1317 .... "x10/regionarray/Array.x10"
                final long t$142347 = ((offset$142342) * (((long)(t$142346))));
                
                //#line 1317 .... "x10/regionarray/Array.x10"
                final long t$142348 = p$142294.$apply$O((long)(1L));
                
                //#line 1317 .... "x10/regionarray/Array.x10"
                final long t$142349 = ((t$142347) + (((long)(t$142348))));
                
                //#line 1317 .... "x10/regionarray/Array.x10"
                final long t$142350 = ((x10.regionarray.Array<$U>)src).layout_min1;
                
                //#line 1317 .... "x10/regionarray/Array.x10"
                final long t$142351 = ((t$142349) - (((long)(t$142350))));
                
                //#line 1317 .... "x10/regionarray/Array.x10"
                offset$142342 = t$142351;
                
                //#line 1318 .... "x10/regionarray/Array.x10"
                final long t$142292 = p$142294.rank;
                
                //#line 1318 .... "x10/regionarray/Array.x10"
                final long i$138773max$142293 = ((t$142292) - (((long)(1L))));
                
                //#line 1318 .... "x10/regionarray/Array.x10"
                long i$142289 = 2L;
                
                //#line 1318 .... "x10/regionarray/Array.x10"
                for (;
                     true;
                     ) {
                    
                    //#line 1318 .... "x10/regionarray/Array.x10"
                    final boolean t$142291 = ((i$142289) <= (((long)(i$138773max$142293))));
                    
                    //#line 1318 .... "x10/regionarray/Array.x10"
                    if (!(t$142291)) {
                        
                        //#line 1318 .... "x10/regionarray/Array.x10"
                        break;
                    }
                    
                    //#line 1319 .... "x10/regionarray/Array.x10"
                    final x10.core.Rail t$142273 = ((x10.core.Rail)(((x10.regionarray.Array<$U>)src).layout));
                    
                    //#line 1319 .... "x10/regionarray/Array.x10"
                    final long t$142274 = ((i$142289) - (((long)(2L))));
                    
                    //#line 1319 .... "x10/regionarray/Array.x10"
                    final long t$142275 = ((2L) * (((long)(t$142274))));
                    
                    //#line 1319 .... "x10/regionarray/Array.x10"
                    final long t$142276 = ((long[])t$142273.value)[(int)t$142275];
                    
                    //#line 1319 .... "x10/regionarray/Array.x10"
                    final long t$142277 = ((offset$142342) * (((long)(t$142276))));
                    
                    //#line 1319 .... "x10/regionarray/Array.x10"
                    final long t$142278 = p$142294.$apply$O((long)(i$142289));
                    
                    //#line 1319 .... "x10/regionarray/Array.x10"
                    final long t$142279 = ((t$142277) + (((long)(t$142278))));
                    
                    //#line 1319 .... "x10/regionarray/Array.x10"
                    final x10.core.Rail t$142280 = ((x10.core.Rail)(((x10.regionarray.Array<$U>)src).layout));
                    
                    //#line 1319 .... "x10/regionarray/Array.x10"
                    final long t$142281 = ((i$142289) - (((long)(2L))));
                    
                    //#line 1319 .... "x10/regionarray/Array.x10"
                    final long t$142282 = ((2L) * (((long)(t$142281))));
                    
                    //#line 1319 .... "x10/regionarray/Array.x10"
                    final long t$142283 = ((t$142282) + (((long)(1L))));
                    
                    //#line 1319 .... "x10/regionarray/Array.x10"
                    final long t$142284 = ((long[])t$142280.value)[(int)t$142283];
                    
                    //#line 1319 .... "x10/regionarray/Array.x10"
                    final long t$142285 = ((t$142279) - (((long)(t$142284))));
                    
                    //#line 1319 .... "x10/regionarray/Array.x10"
                    offset$142342 = t$142285;
                    
                    //#line 1318 .... "x10/regionarray/Array.x10"
                    final long t$142288 = ((i$142289) + (((long)(1L))));
                    
                    //#line 1318 .... "x10/regionarray/Array.x10"
                    i$142289 = t$142288;
                }
            }
            
            //#line 527 ... "x10/regionarray/Array.x10"
            final $U t$142353 = (($U)(((x10.core.Rail<$U>)t$142337).$apply$G((long)(offset$142342))));
            
            //#line 755 .. "x10/regionarray/Array.x10"
            final $S t$142354 = (($S)((($S)
                                        ((x10.core.fun.Fun_0_2<$T,$U,$S>)op).$apply(t$142332, $T, t$142353, $U))));
            
            //#line 183 . "x10/regionarray/Array.x10"
            ((x10.core.Rail<$S>)r$142373).$set__1x10$lang$Rail$$T$G((long)(offset$142299), (($S)(t$142354)));
        }
        
        //#line 185 . "x10/regionarray/Array.x10"
        ((x10.regionarray.Array<$S>)alloc$138542).raw = ((x10.core.Rail)(r$142373));
        
        //#line 755 "x10/regionarray/Array.x10"
        return alloc$138542;
    }
    
    
    //#line 772 "x10/regionarray/Array.x10"
    /**
     * Map the given function onto the elements of this array
     * and the other src array, storing the results in the given dst array 
     * such that for all points <code>p</code> in <code>this.region</code>,
     * <code>dst(p) == op(this(p), src(p))</code>.<p>
     * 
     * @param dst the destination array for the map operation
     * @param src the second source array for the map operation
     * @param op the function to apply to each element of the array
     * @return destination after applying the map operation.
     * @see #reduce((U,T)=>U,U)
     * @see #scan((U,T)=>U,U)
     */
    public <$S, $U>x10.regionarray.Array map__0$1x10$regionarray$Array$$S$2__1$1x10$regionarray$Array$$U$2__2$1x10$regionarray$Array$$T$3x10$regionarray$Array$$U$3x10$regionarray$Array$$S$2(final x10.rtt.Type $S, final x10.rtt.Type $U, final x10.regionarray.Array dst, final x10.regionarray.Array src, final x10.core.fun.Fun_0_2 op) {
        
        //#line 774 "x10/regionarray/Array.x10"
        boolean t$140662 = this.rect;
        
        //#line 774 "x10/regionarray/Array.x10"
        if (t$140662) {
            
            //#line 774 "x10/regionarray/Array.x10"
            final long t$140660 = this.size;
            
            //#line 774 "x10/regionarray/Array.x10"
            final long t$140661 = ((x10.regionarray.Array<$U>)src).size;
            
            //#line 774 "x10/regionarray/Array.x10"
            t$140662 = ((long) t$140660) == ((long) t$140661);
        }
        
        //#line 774 "x10/regionarray/Array.x10"
        if (t$140662) {
            
            //#line 778 "x10/regionarray/Array.x10"
            final x10.core.Rail src$139574 = ((x10.core.Rail)(this.raw));
            
            //#line 778 "x10/regionarray/Array.x10"
            final x10.core.Rail t$140663 = ((x10.core.Rail)(((x10.regionarray.Array<$U>)src).raw));
            
            //#line 778 "x10/regionarray/Array.x10"
            final x10.core.Rail t$136960 = ((x10.core.Rail<$U>)
                                             t$140663);
            
            //#line 778 "x10/regionarray/Array.x10"
            final long t$140665 = ((x10.core.Rail<$U>)t$136960).size;
            
            //#line 778 "x10/regionarray/Array.x10"
            final x10.core.Rail t$140664 = ((x10.core.Rail)(x10.regionarray.Array.this.raw));
            
            //#line 778 "x10/regionarray/Array.x10"
            final long t$140666 = ((x10.core.Rail<$T>)t$140664).size;
            
            //#line 778 "x10/regionarray/Array.x10"
            final boolean t$140667 = ((long) t$140665) == ((long) t$140666);
            
            //#line 778 "x10/regionarray/Array.x10"
            final boolean t$140669 = !(t$140667);
            
            //#line 778 "x10/regionarray/Array.x10"
            if (t$140669) {
                
                //#line 778 "x10/regionarray/Array.x10"
                final x10.lang.FailedDynamicCheckException t$140668 = new x10.lang.FailedDynamicCheckException("x10.lang.Rail[U]{self.size==this(:x10.regionarray.Array).raw.size}");
                
                //#line 778 "x10/regionarray/Array.x10"
                throw t$140668;
            }
            
            //#line 778 "x10/regionarray/Array.x10"
            final x10.core.Rail dst$139576 = ((x10.core.Rail)(((x10.regionarray.Array<$S>)dst).raw));
            
            //#line 203 . "x10/util/RailUtils.x10"
            final long i$97517max$142384 = ((x10.core.Rail<$T>)src$139574).size;
            
            //#line 203 . "x10/util/RailUtils.x10"
            long i$142380 = 0L;
            
            //#line 203 . "x10/util/RailUtils.x10"
            for (;
                 true;
                 ) {
                
                //#line 203 . "x10/util/RailUtils.x10"
                final boolean t$142382 = ((i$142380) < (((long)(i$97517max$142384))));
                
                //#line 203 . "x10/util/RailUtils.x10"
                if (!(t$142382)) {
                    
                    //#line 203 . "x10/util/RailUtils.x10"
                    break;
                }
                
                //#line 204 . "x10/util/RailUtils.x10"
                final $T t$142374 = (($T)(((x10.core.Rail<$T>)src$139574).$apply$G((long)(i$142380))));
                
                //#line 204 . "x10/util/RailUtils.x10"
                final $U t$142375 = (($U)(((x10.core.Rail<$U>)t$136960).$apply$G((long)(i$142380))));
                
                //#line 204 . "x10/util/RailUtils.x10"
                final $S t$142376 = (($S)((($S)
                                            ((x10.core.fun.Fun_0_2<$T,$U,$S>)op).$apply(t$142374, $T, t$142375, $U))));
                
                //#line 204 . "x10/util/RailUtils.x10"
                ((x10.core.Rail<$S>)dst$139576).$set__1x10$lang$Rail$$T$G((long)(i$142380), (($S)(t$142376)));
                
                //#line 203 . "x10/util/RailUtils.x10"
                final long t$142379 = ((i$142380) + (((long)(1L))));
                
                //#line 203 . "x10/util/RailUtils.x10"
                i$142380 = t$142379;
            }
            
            //#line 779 "x10/regionarray/Array.x10"
            return dst;
        } else {
            
            //#line 781 "x10/regionarray/Array.x10"
            final x10.regionarray.Region t$140679 = ((x10.regionarray.Region)(this.region));
            
            //#line 781 "x10/regionarray/Array.x10"
            final x10.lang.Iterator p$138630 = t$140679.iterator();
            
            //#line 781 "x10/regionarray/Array.x10"
            for (;
                 true;
                 ) {
                
                //#line 781 "x10/regionarray/Array.x10"
                final boolean t$140793 = ((x10.lang.Iterator<x10.lang.Point>)p$138630).hasNext$O();
                
                //#line 781 "x10/regionarray/Array.x10"
                if (!(t$140793)) {
                    
                    //#line 781 "x10/regionarray/Array.x10"
                    break;
                }
                
                //#line 781 "x10/regionarray/Array.x10"
                final x10.lang.Point p$142451 = ((x10.lang.Point)(((x10.lang.Iterator<x10.lang.Point>)p$138630).next$G()));
                
                //#line 782 "x10/regionarray/Array.x10"
                final x10.regionarray.Array this$142453 = ((x10.regionarray.Array)(this));
                
                //#line 524 . "x10/regionarray/Array.x10"
                final x10.regionarray.Region t$142455 = ((x10.regionarray.Region)(((x10.regionarray.Array<$T>)this$142453).region));
                
                //#line 524 . "x10/regionarray/Array.x10"
                final boolean t$142456 = t$142455.contains$O(((x10.lang.Point)(p$142451)));
                
                //#line 524 . "x10/regionarray/Array.x10"
                final boolean t$142457 = !(t$142456);
                
                //#line 524 . "x10/regionarray/Array.x10"
                if (t$142457) {
                    
                    //#line 525 . "x10/regionarray/Array.x10"
                    x10.regionarray.Array.raiseBoundsError(((x10.lang.Point)(p$142451)));
                }
                
                //#line 527 . "x10/regionarray/Array.x10"
                final x10.core.Rail t$142458 = ((x10.core.Rail)(((x10.regionarray.Array<$T>)this$142453).raw));
                
                //#line 1315 .. "x10/regionarray/Array.x10"
                final long t$142460 = ((long)(((int)(0))));
                
                //#line 1315 .. "x10/regionarray/Array.x10"
                final long t$142461 = p$142451.$apply$O((long)(t$142460));
                
                //#line 1315 .. "x10/regionarray/Array.x10"
                final long t$142462 = ((x10.regionarray.Array<$T>)this$142453).layout_min0;
                
                //#line 1315 .. "x10/regionarray/Array.x10"
                long offset$142463 = ((t$142461) - (((long)(t$142462))));
                
                //#line 1316 .. "x10/regionarray/Array.x10"
                final long t$142464 = p$142451.rank;
                
                //#line 1316 .. "x10/regionarray/Array.x10"
                final boolean t$142465 = ((t$142464) > (((long)(1L))));
                
                //#line 1316 .. "x10/regionarray/Array.x10"
                if (t$142465) {
                    
                    //#line 1317 .. "x10/regionarray/Array.x10"
                    final long t$142467 = ((x10.regionarray.Array<$T>)this$142453).layout_stride1;
                    
                    //#line 1317 .. "x10/regionarray/Array.x10"
                    final long t$142468 = ((offset$142463) * (((long)(t$142467))));
                    
                    //#line 1317 .. "x10/regionarray/Array.x10"
                    final long t$142469 = p$142451.$apply$O((long)(1L));
                    
                    //#line 1317 .. "x10/regionarray/Array.x10"
                    final long t$142470 = ((t$142468) + (((long)(t$142469))));
                    
                    //#line 1317 .. "x10/regionarray/Array.x10"
                    final long t$142471 = ((x10.regionarray.Array<$T>)this$142453).layout_min1;
                    
                    //#line 1317 .. "x10/regionarray/Array.x10"
                    final long t$142472 = ((t$142470) - (((long)(t$142471))));
                    
                    //#line 1317 .. "x10/regionarray/Array.x10"
                    offset$142463 = t$142472;
                    
                    //#line 1318 .. "x10/regionarray/Array.x10"
                    final long t$142405 = p$142451.rank;
                    
                    //#line 1318 .. "x10/regionarray/Array.x10"
                    final long i$138773max$142406 = ((t$142405) - (((long)(1L))));
                    
                    //#line 1318 .. "x10/regionarray/Array.x10"
                    long i$142402 = 2L;
                    
                    //#line 1318 .. "x10/regionarray/Array.x10"
                    for (;
                         true;
                         ) {
                        
                        //#line 1318 .. "x10/regionarray/Array.x10"
                        final boolean t$142404 = ((i$142402) <= (((long)(i$138773max$142406))));
                        
                        //#line 1318 .. "x10/regionarray/Array.x10"
                        if (!(t$142404)) {
                            
                            //#line 1318 .. "x10/regionarray/Array.x10"
                            break;
                        }
                        
                        //#line 1319 .. "x10/regionarray/Array.x10"
                        final x10.core.Rail t$142386 = ((x10.core.Rail)(((x10.regionarray.Array<$T>)this$142453).layout));
                        
                        //#line 1319 .. "x10/regionarray/Array.x10"
                        final long t$142387 = ((i$142402) - (((long)(2L))));
                        
                        //#line 1319 .. "x10/regionarray/Array.x10"
                        final long t$142388 = ((2L) * (((long)(t$142387))));
                        
                        //#line 1319 .. "x10/regionarray/Array.x10"
                        final long t$142389 = ((long[])t$142386.value)[(int)t$142388];
                        
                        //#line 1319 .. "x10/regionarray/Array.x10"
                        final long t$142390 = ((offset$142463) * (((long)(t$142389))));
                        
                        //#line 1319 .. "x10/regionarray/Array.x10"
                        final long t$142391 = p$142451.$apply$O((long)(i$142402));
                        
                        //#line 1319 .. "x10/regionarray/Array.x10"
                        final long t$142392 = ((t$142390) + (((long)(t$142391))));
                        
                        //#line 1319 .. "x10/regionarray/Array.x10"
                        final x10.core.Rail t$142393 = ((x10.core.Rail)(((x10.regionarray.Array<$T>)this$142453).layout));
                        
                        //#line 1319 .. "x10/regionarray/Array.x10"
                        final long t$142394 = ((i$142402) - (((long)(2L))));
                        
                        //#line 1319 .. "x10/regionarray/Array.x10"
                        final long t$142395 = ((2L) * (((long)(t$142394))));
                        
                        //#line 1319 .. "x10/regionarray/Array.x10"
                        final long t$142396 = ((t$142395) + (((long)(1L))));
                        
                        //#line 1319 .. "x10/regionarray/Array.x10"
                        final long t$142397 = ((long[])t$142393.value)[(int)t$142396];
                        
                        //#line 1319 .. "x10/regionarray/Array.x10"
                        final long t$142398 = ((t$142392) - (((long)(t$142397))));
                        
                        //#line 1319 .. "x10/regionarray/Array.x10"
                        offset$142463 = t$142398;
                        
                        //#line 1318 .. "x10/regionarray/Array.x10"
                        final long t$142401 = ((i$142402) + (((long)(1L))));
                        
                        //#line 1318 .. "x10/regionarray/Array.x10"
                        i$142402 = t$142401;
                    }
                }
                
                //#line 527 . "x10/regionarray/Array.x10"
                final $T t$142474 = (($T)(((x10.core.Rail<$T>)t$142458).$apply$G((long)(offset$142463))));
                
                //#line 524 . "x10/regionarray/Array.x10"
                final x10.regionarray.Region t$142476 = ((x10.regionarray.Region)(((x10.regionarray.Array<$U>)src).region));
                
                //#line 524 . "x10/regionarray/Array.x10"
                final boolean t$142477 = t$142476.contains$O(((x10.lang.Point)(p$142451)));
                
                //#line 524 . "x10/regionarray/Array.x10"
                final boolean t$142478 = !(t$142477);
                
                //#line 524 . "x10/regionarray/Array.x10"
                if (t$142478) {
                    
                    //#line 525 . "x10/regionarray/Array.x10"
                    x10.regionarray.Array.raiseBoundsError(((x10.lang.Point)(p$142451)));
                }
                
                //#line 527 . "x10/regionarray/Array.x10"
                final x10.core.Rail t$142479 = ((x10.core.Rail)(((x10.regionarray.Array<$U>)src).raw));
                
                //#line 1315 .. "x10/regionarray/Array.x10"
                final long t$142481 = ((long)(((int)(0))));
                
                //#line 1315 .. "x10/regionarray/Array.x10"
                final long t$142482 = p$142451.$apply$O((long)(t$142481));
                
                //#line 1315 .. "x10/regionarray/Array.x10"
                final long t$142483 = ((x10.regionarray.Array<$U>)src).layout_min0;
                
                //#line 1315 .. "x10/regionarray/Array.x10"
                long offset$142484 = ((t$142482) - (((long)(t$142483))));
                
                //#line 1316 .. "x10/regionarray/Array.x10"
                final long t$142485 = p$142451.rank;
                
                //#line 1316 .. "x10/regionarray/Array.x10"
                final boolean t$142486 = ((t$142485) > (((long)(1L))));
                
                //#line 1316 .. "x10/regionarray/Array.x10"
                if (t$142486) {
                    
                    //#line 1317 .. "x10/regionarray/Array.x10"
                    final long t$142488 = ((x10.regionarray.Array<$U>)src).layout_stride1;
                    
                    //#line 1317 .. "x10/regionarray/Array.x10"
                    final long t$142489 = ((offset$142484) * (((long)(t$142488))));
                    
                    //#line 1317 .. "x10/regionarray/Array.x10"
                    final long t$142490 = p$142451.$apply$O((long)(1L));
                    
                    //#line 1317 .. "x10/regionarray/Array.x10"
                    final long t$142491 = ((t$142489) + (((long)(t$142490))));
                    
                    //#line 1317 .. "x10/regionarray/Array.x10"
                    final long t$142492 = ((x10.regionarray.Array<$U>)src).layout_min1;
                    
                    //#line 1317 .. "x10/regionarray/Array.x10"
                    final long t$142493 = ((t$142491) - (((long)(t$142492))));
                    
                    //#line 1317 .. "x10/regionarray/Array.x10"
                    offset$142484 = t$142493;
                    
                    //#line 1318 .. "x10/regionarray/Array.x10"
                    final long t$142427 = p$142451.rank;
                    
                    //#line 1318 .. "x10/regionarray/Array.x10"
                    final long i$138773max$142428 = ((t$142427) - (((long)(1L))));
                    
                    //#line 1318 .. "x10/regionarray/Array.x10"
                    long i$142424 = 2L;
                    
                    //#line 1318 .. "x10/regionarray/Array.x10"
                    for (;
                         true;
                         ) {
                        
                        //#line 1318 .. "x10/regionarray/Array.x10"
                        final boolean t$142426 = ((i$142424) <= (((long)(i$138773max$142428))));
                        
                        //#line 1318 .. "x10/regionarray/Array.x10"
                        if (!(t$142426)) {
                            
                            //#line 1318 .. "x10/regionarray/Array.x10"
                            break;
                        }
                        
                        //#line 1319 .. "x10/regionarray/Array.x10"
                        final x10.core.Rail t$142408 = ((x10.core.Rail)(((x10.regionarray.Array<$U>)src).layout));
                        
                        //#line 1319 .. "x10/regionarray/Array.x10"
                        final long t$142409 = ((i$142424) - (((long)(2L))));
                        
                        //#line 1319 .. "x10/regionarray/Array.x10"
                        final long t$142410 = ((2L) * (((long)(t$142409))));
                        
                        //#line 1319 .. "x10/regionarray/Array.x10"
                        final long t$142411 = ((long[])t$142408.value)[(int)t$142410];
                        
                        //#line 1319 .. "x10/regionarray/Array.x10"
                        final long t$142412 = ((offset$142484) * (((long)(t$142411))));
                        
                        //#line 1319 .. "x10/regionarray/Array.x10"
                        final long t$142413 = p$142451.$apply$O((long)(i$142424));
                        
                        //#line 1319 .. "x10/regionarray/Array.x10"
                        final long t$142414 = ((t$142412) + (((long)(t$142413))));
                        
                        //#line 1319 .. "x10/regionarray/Array.x10"
                        final x10.core.Rail t$142415 = ((x10.core.Rail)(((x10.regionarray.Array<$U>)src).layout));
                        
                        //#line 1319 .. "x10/regionarray/Array.x10"
                        final long t$142416 = ((i$142424) - (((long)(2L))));
                        
                        //#line 1319 .. "x10/regionarray/Array.x10"
                        final long t$142417 = ((2L) * (((long)(t$142416))));
                        
                        //#line 1319 .. "x10/regionarray/Array.x10"
                        final long t$142418 = ((t$142417) + (((long)(1L))));
                        
                        //#line 1319 .. "x10/regionarray/Array.x10"
                        final long t$142419 = ((long[])t$142415.value)[(int)t$142418];
                        
                        //#line 1319 .. "x10/regionarray/Array.x10"
                        final long t$142420 = ((t$142414) - (((long)(t$142419))));
                        
                        //#line 1319 .. "x10/regionarray/Array.x10"
                        offset$142484 = t$142420;
                        
                        //#line 1318 .. "x10/regionarray/Array.x10"
                        final long t$142423 = ((i$142424) + (((long)(1L))));
                        
                        //#line 1318 .. "x10/regionarray/Array.x10"
                        i$142424 = t$142423;
                    }
                }
                
                //#line 527 . "x10/regionarray/Array.x10"
                final $U t$142495 = (($U)(((x10.core.Rail<$U>)t$142479).$apply$G((long)(offset$142484))));
                
                //#line 782 "x10/regionarray/Array.x10"
                final $S v$142496 = (($S)((($S)
                                            ((x10.core.fun.Fun_0_2<$T,$U,$S>)op).$apply(t$142474, $T, t$142495, $U))));
                
                //#line 637 . "x10/regionarray/Array.x10"
                final x10.regionarray.Region t$142497 = ((x10.regionarray.Region)(((x10.regionarray.Array<$S>)dst).region));
                
                //#line 637 . "x10/regionarray/Array.x10"
                final boolean t$142498 = t$142497.contains$O(((x10.lang.Point)(p$142451)));
                
                //#line 637 . "x10/regionarray/Array.x10"
                final boolean t$142499 = !(t$142498);
                
                //#line 637 . "x10/regionarray/Array.x10"
                if (t$142499) {
                    
                    //#line 638 . "x10/regionarray/Array.x10"
                    x10.regionarray.Array.raiseBoundsError(((x10.lang.Point)(p$142451)));
                }
                
                //#line 640 . "x10/regionarray/Array.x10"
                final x10.core.Rail t$142500 = ((x10.core.Rail)(((x10.regionarray.Array<$S>)dst).raw));
                
                //#line 1315 .. "x10/regionarray/Array.x10"
                final long t$142502 = ((long)(((int)(0))));
                
                //#line 1315 .. "x10/regionarray/Array.x10"
                final long t$142503 = p$142451.$apply$O((long)(t$142502));
                
                //#line 1315 .. "x10/regionarray/Array.x10"
                final long t$142504 = ((x10.regionarray.Array<$S>)dst).layout_min0;
                
                //#line 1315 .. "x10/regionarray/Array.x10"
                long offset$142505 = ((t$142503) - (((long)(t$142504))));
                
                //#line 1316 .. "x10/regionarray/Array.x10"
                final long t$142506 = p$142451.rank;
                
                //#line 1316 .. "x10/regionarray/Array.x10"
                final boolean t$142507 = ((t$142506) > (((long)(1L))));
                
                //#line 1316 .. "x10/regionarray/Array.x10"
                if (t$142507) {
                    
                    //#line 1317 .. "x10/regionarray/Array.x10"
                    final long t$142509 = ((x10.regionarray.Array<$S>)dst).layout_stride1;
                    
                    //#line 1317 .. "x10/regionarray/Array.x10"
                    final long t$142510 = ((offset$142505) * (((long)(t$142509))));
                    
                    //#line 1317 .. "x10/regionarray/Array.x10"
                    final long t$142511 = p$142451.$apply$O((long)(1L));
                    
                    //#line 1317 .. "x10/regionarray/Array.x10"
                    final long t$142512 = ((t$142510) + (((long)(t$142511))));
                    
                    //#line 1317 .. "x10/regionarray/Array.x10"
                    final long t$142513 = ((x10.regionarray.Array<$S>)dst).layout_min1;
                    
                    //#line 1317 .. "x10/regionarray/Array.x10"
                    final long t$142514 = ((t$142512) - (((long)(t$142513))));
                    
                    //#line 1317 .. "x10/regionarray/Array.x10"
                    offset$142505 = t$142514;
                    
                    //#line 1318 .. "x10/regionarray/Array.x10"
                    final long t$142449 = p$142451.rank;
                    
                    //#line 1318 .. "x10/regionarray/Array.x10"
                    final long i$138773max$142450 = ((t$142449) - (((long)(1L))));
                    
                    //#line 1318 .. "x10/regionarray/Array.x10"
                    long i$142446 = 2L;
                    
                    //#line 1318 .. "x10/regionarray/Array.x10"
                    for (;
                         true;
                         ) {
                        
                        //#line 1318 .. "x10/regionarray/Array.x10"
                        final boolean t$142448 = ((i$142446) <= (((long)(i$138773max$142450))));
                        
                        //#line 1318 .. "x10/regionarray/Array.x10"
                        if (!(t$142448)) {
                            
                            //#line 1318 .. "x10/regionarray/Array.x10"
                            break;
                        }
                        
                        //#line 1319 .. "x10/regionarray/Array.x10"
                        final x10.core.Rail t$142430 = ((x10.core.Rail)(((x10.regionarray.Array<$S>)dst).layout));
                        
                        //#line 1319 .. "x10/regionarray/Array.x10"
                        final long t$142431 = ((i$142446) - (((long)(2L))));
                        
                        //#line 1319 .. "x10/regionarray/Array.x10"
                        final long t$142432 = ((2L) * (((long)(t$142431))));
                        
                        //#line 1319 .. "x10/regionarray/Array.x10"
                        final long t$142433 = ((long[])t$142430.value)[(int)t$142432];
                        
                        //#line 1319 .. "x10/regionarray/Array.x10"
                        final long t$142434 = ((offset$142505) * (((long)(t$142433))));
                        
                        //#line 1319 .. "x10/regionarray/Array.x10"
                        final long t$142435 = p$142451.$apply$O((long)(i$142446));
                        
                        //#line 1319 .. "x10/regionarray/Array.x10"
                        final long t$142436 = ((t$142434) + (((long)(t$142435))));
                        
                        //#line 1319 .. "x10/regionarray/Array.x10"
                        final x10.core.Rail t$142437 = ((x10.core.Rail)(((x10.regionarray.Array<$S>)dst).layout));
                        
                        //#line 1319 .. "x10/regionarray/Array.x10"
                        final long t$142438 = ((i$142446) - (((long)(2L))));
                        
                        //#line 1319 .. "x10/regionarray/Array.x10"
                        final long t$142439 = ((2L) * (((long)(t$142438))));
                        
                        //#line 1319 .. "x10/regionarray/Array.x10"
                        final long t$142440 = ((t$142439) + (((long)(1L))));
                        
                        //#line 1319 .. "x10/regionarray/Array.x10"
                        final long t$142441 = ((long[])t$142437.value)[(int)t$142440];
                        
                        //#line 1319 .. "x10/regionarray/Array.x10"
                        final long t$142442 = ((t$142436) - (((long)(t$142441))));
                        
                        //#line 1319 .. "x10/regionarray/Array.x10"
                        offset$142505 = t$142442;
                        
                        //#line 1318 .. "x10/regionarray/Array.x10"
                        final long t$142445 = ((i$142446) + (((long)(1L))));
                        
                        //#line 1318 .. "x10/regionarray/Array.x10"
                        i$142446 = t$142445;
                    }
                }
                
                //#line 640 . "x10/regionarray/Array.x10"
                ((x10.core.Rail<$S>)t$142500).$set__1x10$lang$Rail$$T$G((long)(offset$142505), (($S)(v$142496)));
            }
        }
        
        //#line 785 "x10/regionarray/Array.x10"
        return dst;
    }
    
    
    //#line 804 "x10/regionarray/Array.x10"
    /**
     * Map the given function onto the elements of this array
     * and the other src array for the subset of points contained in the filter region, 
     * storing the results in the given dst array such that for all points <code>p</code> 
     * in <code>filter</code>,
     * <code>dst(p) == op(this(p), src(p))</code>.<p>
     * 
     * @param dst the destination array for the map operation
     * @param src the second source array for the map operation
     * @param filter the region to select the subset of points to include in the map
     * @param op the function to apply to each element of the array
     * @return destination after applying the map operation.
     * @see #reduce((U,T)=>U,U)
     * @see #scan((U,T)=>U,U)
     */
    public <$S, $U>x10.regionarray.Array map__0$1x10$regionarray$Array$$S$2__1$1x10$regionarray$Array$$U$2__3$1x10$regionarray$Array$$T$3x10$regionarray$Array$$U$3x10$regionarray$Array$$S$2(final x10.rtt.Type $S, final x10.rtt.Type $U, final x10.regionarray.Array dst, final x10.regionarray.Array src, final x10.regionarray.Region filter, final x10.core.fun.Fun_0_2 op) {
        
        //#line 805 "x10/regionarray/Array.x10"
        final x10.regionarray.Region t$140795 = ((x10.regionarray.Region)(this.region));
        
        //#line 805 "x10/regionarray/Array.x10"
        final x10.regionarray.Region fregion = ((x10.regionarray.Region)(t$140795.$and(((x10.regionarray.Region)(filter)))));
        
        //#line 806 "x10/regionarray/Array.x10"
        final x10.lang.Iterator p$142647 = fregion.iterator();
        
        //#line 806 "x10/regionarray/Array.x10"
        for (;
             true;
             ) {
            
            //#line 806 "x10/regionarray/Array.x10"
            final boolean t$142648 = ((x10.lang.Iterator<x10.lang.Point>)p$142647).hasNext$O();
            
            //#line 806 "x10/regionarray/Array.x10"
            if (!(t$142648)) {
                
                //#line 806 "x10/regionarray/Array.x10"
                break;
            }
            
            //#line 806 "x10/regionarray/Array.x10"
            final x10.lang.Point p$142582 = ((x10.lang.Point)(((x10.lang.Iterator<x10.lang.Point>)p$142647).next$G()));
            
            //#line 807 "x10/regionarray/Array.x10"
            final x10.regionarray.Array this$142584 = ((x10.regionarray.Array)(this));
            
            //#line 524 . "x10/regionarray/Array.x10"
            final x10.regionarray.Region t$142586 = ((x10.regionarray.Region)(((x10.regionarray.Array<$T>)this$142584).region));
            
            //#line 524 . "x10/regionarray/Array.x10"
            final boolean t$142587 = t$142586.contains$O(((x10.lang.Point)(p$142582)));
            
            //#line 524 . "x10/regionarray/Array.x10"
            final boolean t$142588 = !(t$142587);
            
            //#line 524 . "x10/regionarray/Array.x10"
            if (t$142588) {
                
                //#line 525 . "x10/regionarray/Array.x10"
                x10.regionarray.Array.raiseBoundsError(((x10.lang.Point)(p$142582)));
            }
            
            //#line 527 . "x10/regionarray/Array.x10"
            final x10.core.Rail t$142589 = ((x10.core.Rail)(((x10.regionarray.Array<$T>)this$142584).raw));
            
            //#line 1315 .. "x10/regionarray/Array.x10"
            final long t$142591 = ((long)(((int)(0))));
            
            //#line 1315 .. "x10/regionarray/Array.x10"
            final long t$142592 = p$142582.$apply$O((long)(t$142591));
            
            //#line 1315 .. "x10/regionarray/Array.x10"
            final long t$142593 = ((x10.regionarray.Array<$T>)this$142584).layout_min0;
            
            //#line 1315 .. "x10/regionarray/Array.x10"
            long offset$142594 = ((t$142592) - (((long)(t$142593))));
            
            //#line 1316 .. "x10/regionarray/Array.x10"
            final long t$142595 = p$142582.rank;
            
            //#line 1316 .. "x10/regionarray/Array.x10"
            final boolean t$142596 = ((t$142595) > (((long)(1L))));
            
            //#line 1316 .. "x10/regionarray/Array.x10"
            if (t$142596) {
                
                //#line 1317 .. "x10/regionarray/Array.x10"
                final long t$142598 = ((x10.regionarray.Array<$T>)this$142584).layout_stride1;
                
                //#line 1317 .. "x10/regionarray/Array.x10"
                final long t$142599 = ((offset$142594) * (((long)(t$142598))));
                
                //#line 1317 .. "x10/regionarray/Array.x10"
                final long t$142600 = p$142582.$apply$O((long)(1L));
                
                //#line 1317 .. "x10/regionarray/Array.x10"
                final long t$142601 = ((t$142599) + (((long)(t$142600))));
                
                //#line 1317 .. "x10/regionarray/Array.x10"
                final long t$142602 = ((x10.regionarray.Array<$T>)this$142584).layout_min1;
                
                //#line 1317 .. "x10/regionarray/Array.x10"
                final long t$142603 = ((t$142601) - (((long)(t$142602))));
                
                //#line 1317 .. "x10/regionarray/Array.x10"
                offset$142594 = t$142603;
                
                //#line 1318 .. "x10/regionarray/Array.x10"
                final long t$142536 = p$142582.rank;
                
                //#line 1318 .. "x10/regionarray/Array.x10"
                final long i$138773max$142537 = ((t$142536) - (((long)(1L))));
                
                //#line 1318 .. "x10/regionarray/Array.x10"
                long i$142533 = 2L;
                
                //#line 1318 .. "x10/regionarray/Array.x10"
                for (;
                     true;
                     ) {
                    
                    //#line 1318 .. "x10/regionarray/Array.x10"
                    final boolean t$142535 = ((i$142533) <= (((long)(i$138773max$142537))));
                    
                    //#line 1318 .. "x10/regionarray/Array.x10"
                    if (!(t$142535)) {
                        
                        //#line 1318 .. "x10/regionarray/Array.x10"
                        break;
                    }
                    
                    //#line 1319 .. "x10/regionarray/Array.x10"
                    final x10.core.Rail t$142517 = ((x10.core.Rail)(((x10.regionarray.Array<$T>)this$142584).layout));
                    
                    //#line 1319 .. "x10/regionarray/Array.x10"
                    final long t$142518 = ((i$142533) - (((long)(2L))));
                    
                    //#line 1319 .. "x10/regionarray/Array.x10"
                    final long t$142519 = ((2L) * (((long)(t$142518))));
                    
                    //#line 1319 .. "x10/regionarray/Array.x10"
                    final long t$142520 = ((long[])t$142517.value)[(int)t$142519];
                    
                    //#line 1319 .. "x10/regionarray/Array.x10"
                    final long t$142521 = ((offset$142594) * (((long)(t$142520))));
                    
                    //#line 1319 .. "x10/regionarray/Array.x10"
                    final long t$142522 = p$142582.$apply$O((long)(i$142533));
                    
                    //#line 1319 .. "x10/regionarray/Array.x10"
                    final long t$142523 = ((t$142521) + (((long)(t$142522))));
                    
                    //#line 1319 .. "x10/regionarray/Array.x10"
                    final x10.core.Rail t$142524 = ((x10.core.Rail)(((x10.regionarray.Array<$T>)this$142584).layout));
                    
                    //#line 1319 .. "x10/regionarray/Array.x10"
                    final long t$142525 = ((i$142533) - (((long)(2L))));
                    
                    //#line 1319 .. "x10/regionarray/Array.x10"
                    final long t$142526 = ((2L) * (((long)(t$142525))));
                    
                    //#line 1319 .. "x10/regionarray/Array.x10"
                    final long t$142527 = ((t$142526) + (((long)(1L))));
                    
                    //#line 1319 .. "x10/regionarray/Array.x10"
                    final long t$142528 = ((long[])t$142524.value)[(int)t$142527];
                    
                    //#line 1319 .. "x10/regionarray/Array.x10"
                    final long t$142529 = ((t$142523) - (((long)(t$142528))));
                    
                    //#line 1319 .. "x10/regionarray/Array.x10"
                    offset$142594 = t$142529;
                    
                    //#line 1318 .. "x10/regionarray/Array.x10"
                    final long t$142532 = ((i$142533) + (((long)(1L))));
                    
                    //#line 1318 .. "x10/regionarray/Array.x10"
                    i$142533 = t$142532;
                }
            }
            
            //#line 527 . "x10/regionarray/Array.x10"
            final $T t$142605 = (($T)(((x10.core.Rail<$T>)t$142589).$apply$G((long)(offset$142594))));
            
            //#line 524 . "x10/regionarray/Array.x10"
            final x10.regionarray.Region t$142607 = ((x10.regionarray.Region)(((x10.regionarray.Array<$U>)src).region));
            
            //#line 524 . "x10/regionarray/Array.x10"
            final boolean t$142608 = t$142607.contains$O(((x10.lang.Point)(p$142582)));
            
            //#line 524 . "x10/regionarray/Array.x10"
            final boolean t$142609 = !(t$142608);
            
            //#line 524 . "x10/regionarray/Array.x10"
            if (t$142609) {
                
                //#line 525 . "x10/regionarray/Array.x10"
                x10.regionarray.Array.raiseBoundsError(((x10.lang.Point)(p$142582)));
            }
            
            //#line 527 . "x10/regionarray/Array.x10"
            final x10.core.Rail t$142610 = ((x10.core.Rail)(((x10.regionarray.Array<$U>)src).raw));
            
            //#line 1315 .. "x10/regionarray/Array.x10"
            final long t$142612 = ((long)(((int)(0))));
            
            //#line 1315 .. "x10/regionarray/Array.x10"
            final long t$142613 = p$142582.$apply$O((long)(t$142612));
            
            //#line 1315 .. "x10/regionarray/Array.x10"
            final long t$142614 = ((x10.regionarray.Array<$U>)src).layout_min0;
            
            //#line 1315 .. "x10/regionarray/Array.x10"
            long offset$142615 = ((t$142613) - (((long)(t$142614))));
            
            //#line 1316 .. "x10/regionarray/Array.x10"
            final long t$142616 = p$142582.rank;
            
            //#line 1316 .. "x10/regionarray/Array.x10"
            final boolean t$142617 = ((t$142616) > (((long)(1L))));
            
            //#line 1316 .. "x10/regionarray/Array.x10"
            if (t$142617) {
                
                //#line 1317 .. "x10/regionarray/Array.x10"
                final long t$142619 = ((x10.regionarray.Array<$U>)src).layout_stride1;
                
                //#line 1317 .. "x10/regionarray/Array.x10"
                final long t$142620 = ((offset$142615) * (((long)(t$142619))));
                
                //#line 1317 .. "x10/regionarray/Array.x10"
                final long t$142621 = p$142582.$apply$O((long)(1L));
                
                //#line 1317 .. "x10/regionarray/Array.x10"
                final long t$142622 = ((t$142620) + (((long)(t$142621))));
                
                //#line 1317 .. "x10/regionarray/Array.x10"
                final long t$142623 = ((x10.regionarray.Array<$U>)src).layout_min1;
                
                //#line 1317 .. "x10/regionarray/Array.x10"
                final long t$142624 = ((t$142622) - (((long)(t$142623))));
                
                //#line 1317 .. "x10/regionarray/Array.x10"
                offset$142615 = t$142624;
                
                //#line 1318 .. "x10/regionarray/Array.x10"
                final long t$142558 = p$142582.rank;
                
                //#line 1318 .. "x10/regionarray/Array.x10"
                final long i$138773max$142559 = ((t$142558) - (((long)(1L))));
                
                //#line 1318 .. "x10/regionarray/Array.x10"
                long i$142555 = 2L;
                
                //#line 1318 .. "x10/regionarray/Array.x10"
                for (;
                     true;
                     ) {
                    
                    //#line 1318 .. "x10/regionarray/Array.x10"
                    final boolean t$142557 = ((i$142555) <= (((long)(i$138773max$142559))));
                    
                    //#line 1318 .. "x10/regionarray/Array.x10"
                    if (!(t$142557)) {
                        
                        //#line 1318 .. "x10/regionarray/Array.x10"
                        break;
                    }
                    
                    //#line 1319 .. "x10/regionarray/Array.x10"
                    final x10.core.Rail t$142539 = ((x10.core.Rail)(((x10.regionarray.Array<$U>)src).layout));
                    
                    //#line 1319 .. "x10/regionarray/Array.x10"
                    final long t$142540 = ((i$142555) - (((long)(2L))));
                    
                    //#line 1319 .. "x10/regionarray/Array.x10"
                    final long t$142541 = ((2L) * (((long)(t$142540))));
                    
                    //#line 1319 .. "x10/regionarray/Array.x10"
                    final long t$142542 = ((long[])t$142539.value)[(int)t$142541];
                    
                    //#line 1319 .. "x10/regionarray/Array.x10"
                    final long t$142543 = ((offset$142615) * (((long)(t$142542))));
                    
                    //#line 1319 .. "x10/regionarray/Array.x10"
                    final long t$142544 = p$142582.$apply$O((long)(i$142555));
                    
                    //#line 1319 .. "x10/regionarray/Array.x10"
                    final long t$142545 = ((t$142543) + (((long)(t$142544))));
                    
                    //#line 1319 .. "x10/regionarray/Array.x10"
                    final x10.core.Rail t$142546 = ((x10.core.Rail)(((x10.regionarray.Array<$U>)src).layout));
                    
                    //#line 1319 .. "x10/regionarray/Array.x10"
                    final long t$142547 = ((i$142555) - (((long)(2L))));
                    
                    //#line 1319 .. "x10/regionarray/Array.x10"
                    final long t$142548 = ((2L) * (((long)(t$142547))));
                    
                    //#line 1319 .. "x10/regionarray/Array.x10"
                    final long t$142549 = ((t$142548) + (((long)(1L))));
                    
                    //#line 1319 .. "x10/regionarray/Array.x10"
                    final long t$142550 = ((long[])t$142546.value)[(int)t$142549];
                    
                    //#line 1319 .. "x10/regionarray/Array.x10"
                    final long t$142551 = ((t$142545) - (((long)(t$142550))));
                    
                    //#line 1319 .. "x10/regionarray/Array.x10"
                    offset$142615 = t$142551;
                    
                    //#line 1318 .. "x10/regionarray/Array.x10"
                    final long t$142554 = ((i$142555) + (((long)(1L))));
                    
                    //#line 1318 .. "x10/regionarray/Array.x10"
                    i$142555 = t$142554;
                }
            }
            
            //#line 527 . "x10/regionarray/Array.x10"
            final $U t$142626 = (($U)(((x10.core.Rail<$U>)t$142610).$apply$G((long)(offset$142615))));
            
            //#line 807 "x10/regionarray/Array.x10"
            final $S v$142627 = (($S)((($S)
                                        ((x10.core.fun.Fun_0_2<$T,$U,$S>)op).$apply(t$142605, $T, t$142626, $U))));
            
            //#line 637 . "x10/regionarray/Array.x10"
            final x10.regionarray.Region t$142628 = ((x10.regionarray.Region)(((x10.regionarray.Array<$S>)dst).region));
            
            //#line 637 . "x10/regionarray/Array.x10"
            final boolean t$142629 = t$142628.contains$O(((x10.lang.Point)(p$142582)));
            
            //#line 637 . "x10/regionarray/Array.x10"
            final boolean t$142630 = !(t$142629);
            
            //#line 637 . "x10/regionarray/Array.x10"
            if (t$142630) {
                
                //#line 638 . "x10/regionarray/Array.x10"
                x10.regionarray.Array.raiseBoundsError(((x10.lang.Point)(p$142582)));
            }
            
            //#line 640 . "x10/regionarray/Array.x10"
            final x10.core.Rail t$142631 = ((x10.core.Rail)(((x10.regionarray.Array<$S>)dst).raw));
            
            //#line 1315 .. "x10/regionarray/Array.x10"
            final long t$142633 = ((long)(((int)(0))));
            
            //#line 1315 .. "x10/regionarray/Array.x10"
            final long t$142634 = p$142582.$apply$O((long)(t$142633));
            
            //#line 1315 .. "x10/regionarray/Array.x10"
            final long t$142635 = ((x10.regionarray.Array<$S>)dst).layout_min0;
            
            //#line 1315 .. "x10/regionarray/Array.x10"
            long offset$142636 = ((t$142634) - (((long)(t$142635))));
            
            //#line 1316 .. "x10/regionarray/Array.x10"
            final long t$142637 = p$142582.rank;
            
            //#line 1316 .. "x10/regionarray/Array.x10"
            final boolean t$142638 = ((t$142637) > (((long)(1L))));
            
            //#line 1316 .. "x10/regionarray/Array.x10"
            if (t$142638) {
                
                //#line 1317 .. "x10/regionarray/Array.x10"
                final long t$142640 = ((x10.regionarray.Array<$S>)dst).layout_stride1;
                
                //#line 1317 .. "x10/regionarray/Array.x10"
                final long t$142641 = ((offset$142636) * (((long)(t$142640))));
                
                //#line 1317 .. "x10/regionarray/Array.x10"
                final long t$142642 = p$142582.$apply$O((long)(1L));
                
                //#line 1317 .. "x10/regionarray/Array.x10"
                final long t$142643 = ((t$142641) + (((long)(t$142642))));
                
                //#line 1317 .. "x10/regionarray/Array.x10"
                final long t$142644 = ((x10.regionarray.Array<$S>)dst).layout_min1;
                
                //#line 1317 .. "x10/regionarray/Array.x10"
                final long t$142645 = ((t$142643) - (((long)(t$142644))));
                
                //#line 1317 .. "x10/regionarray/Array.x10"
                offset$142636 = t$142645;
                
                //#line 1318 .. "x10/regionarray/Array.x10"
                final long t$142580 = p$142582.rank;
                
                //#line 1318 .. "x10/regionarray/Array.x10"
                final long i$138773max$142581 = ((t$142580) - (((long)(1L))));
                
                //#line 1318 .. "x10/regionarray/Array.x10"
                long i$142577 = 2L;
                
                //#line 1318 .. "x10/regionarray/Array.x10"
                for (;
                     true;
                     ) {
                    
                    //#line 1318 .. "x10/regionarray/Array.x10"
                    final boolean t$142579 = ((i$142577) <= (((long)(i$138773max$142581))));
                    
                    //#line 1318 .. "x10/regionarray/Array.x10"
                    if (!(t$142579)) {
                        
                        //#line 1318 .. "x10/regionarray/Array.x10"
                        break;
                    }
                    
                    //#line 1319 .. "x10/regionarray/Array.x10"
                    final x10.core.Rail t$142561 = ((x10.core.Rail)(((x10.regionarray.Array<$S>)dst).layout));
                    
                    //#line 1319 .. "x10/regionarray/Array.x10"
                    final long t$142562 = ((i$142577) - (((long)(2L))));
                    
                    //#line 1319 .. "x10/regionarray/Array.x10"
                    final long t$142563 = ((2L) * (((long)(t$142562))));
                    
                    //#line 1319 .. "x10/regionarray/Array.x10"
                    final long t$142564 = ((long[])t$142561.value)[(int)t$142563];
                    
                    //#line 1319 .. "x10/regionarray/Array.x10"
                    final long t$142565 = ((offset$142636) * (((long)(t$142564))));
                    
                    //#line 1319 .. "x10/regionarray/Array.x10"
                    final long t$142566 = p$142582.$apply$O((long)(i$142577));
                    
                    //#line 1319 .. "x10/regionarray/Array.x10"
                    final long t$142567 = ((t$142565) + (((long)(t$142566))));
                    
                    //#line 1319 .. "x10/regionarray/Array.x10"
                    final x10.core.Rail t$142568 = ((x10.core.Rail)(((x10.regionarray.Array<$S>)dst).layout));
                    
                    //#line 1319 .. "x10/regionarray/Array.x10"
                    final long t$142569 = ((i$142577) - (((long)(2L))));
                    
                    //#line 1319 .. "x10/regionarray/Array.x10"
                    final long t$142570 = ((2L) * (((long)(t$142569))));
                    
                    //#line 1319 .. "x10/regionarray/Array.x10"
                    final long t$142571 = ((t$142570) + (((long)(1L))));
                    
                    //#line 1319 .. "x10/regionarray/Array.x10"
                    final long t$142572 = ((long[])t$142568.value)[(int)t$142571];
                    
                    //#line 1319 .. "x10/regionarray/Array.x10"
                    final long t$142573 = ((t$142567) - (((long)(t$142572))));
                    
                    //#line 1319 .. "x10/regionarray/Array.x10"
                    offset$142636 = t$142573;
                    
                    //#line 1318 .. "x10/regionarray/Array.x10"
                    final long t$142576 = ((i$142577) + (((long)(1L))));
                    
                    //#line 1318 .. "x10/regionarray/Array.x10"
                    i$142577 = t$142576;
                }
            }
            
            //#line 640 . "x10/regionarray/Array.x10"
            ((x10.core.Rail<$S>)t$142631).$set__1x10$lang$Rail$$T$G((long)(offset$142636), (($S)(v$142627)));
        }
        
        //#line 809 "x10/regionarray/Array.x10"
        return dst;
    }
    
    
    //#line 825 "x10/regionarray/Array.x10"
    /**
     * Reduce this array using the given function and the given initial value.
     * Each element of the array will be given as an argument to the reduction
     * function exactly once, but in an arbitrary order.  The reduction function
     * may be applied concurrently to implement a parallel reduction. 
     * 
     * @param op the reduction function
     * @param unit the given initial value
     * @return the final result of the reduction.
     * @see #map((T)=>S)
     * @see #scan((U,T)=>U,U)
     */
    public <$U>$U reduce__0$1x10$regionarray$Array$$U$3x10$regionarray$Array$$T$3x10$regionarray$Array$$U$2__1x10$regionarray$Array$$U$G(final x10.rtt.Type $U, final x10.core.fun.Fun_0_2 op, final $U unit) {
        
        //#line 826 "x10/regionarray/Array.x10"
        final boolean t$140964 = this.rect;
        
        //#line 826 "x10/regionarray/Array.x10"
        if (t$140964) {
            
            //#line 830 "x10/regionarray/Array.x10"
            final x10.core.Rail src$139642 = ((x10.core.Rail)(this.raw));
            
            //#line 132 . "x10/util/RailUtils.x10"
            $U accum$139645 = (($U)(unit));
            
            //#line 133 . "x10/util/RailUtils.x10"
            final long i$97460max$142659 = ((x10.core.Rail<$T>)src$139642).size;
            
            //#line 133 . "x10/util/RailUtils.x10"
            long i$142655 = 0L;
            
            //#line 133 . "x10/util/RailUtils.x10"
            for (;
                 true;
                 ) {
                
                //#line 133 . "x10/util/RailUtils.x10"
                final boolean t$142657 = ((i$142655) < (((long)(i$97460max$142659))));
                
                //#line 133 . "x10/util/RailUtils.x10"
                if (!(t$142657)) {
                    
                    //#line 133 . "x10/util/RailUtils.x10"
                    break;
                }
                
                //#line 134 . "x10/util/RailUtils.x10"
                final $T t$142650 = (($T)(((x10.core.Rail<$T>)src$139642).$apply$G((long)(i$142655))));
                
                //#line 134 . "x10/util/RailUtils.x10"
                final $U t$142651 = (($U)((($U)
                                            ((x10.core.fun.Fun_0_2<$U,$T,$U>)op).$apply(accum$139645, $U, t$142650, $T))));
                
                //#line 134 . "x10/util/RailUtils.x10"
                accum$139645 = (($U)(t$142651));
                
                //#line 133 . "x10/util/RailUtils.x10"
                final long t$142654 = ((i$142655) + (((long)(1L))));
                
                //#line 133 . "x10/util/RailUtils.x10"
                i$142655 = t$142654;
            }
            
            //#line 830 "x10/regionarray/Array.x10"
            return accum$139645;
        } else {
            
            //#line 832 "x10/regionarray/Array.x10"
            $U accum = (($U)(unit));
            
            //#line 833 "x10/regionarray/Array.x10"
            final x10.regionarray.Region t$142707 = ((x10.regionarray.Region)(this.region));
            
            //#line 833 "x10/regionarray/Array.x10"
            final x10.lang.Iterator p$142708 = t$142707.iterator();
            
            //#line 833 "x10/regionarray/Array.x10"
            for (;
                 true;
                 ) {
                
                //#line 833 "x10/regionarray/Array.x10"
                final boolean t$142709 = ((x10.lang.Iterator<x10.lang.Point>)p$142708).hasNext$O();
                
                //#line 833 "x10/regionarray/Array.x10"
                if (!(t$142709)) {
                    
                    //#line 833 "x10/regionarray/Array.x10"
                    break;
                }
                
                //#line 833 "x10/regionarray/Array.x10"
                final x10.lang.Point p$142682 = ((x10.lang.Point)(((x10.lang.Iterator<x10.lang.Point>)p$142708).next$G()));
                
                //#line 834 "x10/regionarray/Array.x10"
                final x10.regionarray.Array this$142684 = ((x10.regionarray.Array)(this));
                
                //#line 524 . "x10/regionarray/Array.x10"
                final x10.regionarray.Region t$142686 = ((x10.regionarray.Region)(((x10.regionarray.Array<$T>)this$142684).region));
                
                //#line 524 . "x10/regionarray/Array.x10"
                final boolean t$142687 = t$142686.contains$O(((x10.lang.Point)(p$142682)));
                
                //#line 524 . "x10/regionarray/Array.x10"
                final boolean t$142688 = !(t$142687);
                
                //#line 524 . "x10/regionarray/Array.x10"
                if (t$142688) {
                    
                    //#line 525 . "x10/regionarray/Array.x10"
                    x10.regionarray.Array.raiseBoundsError(((x10.lang.Point)(p$142682)));
                }
                
                //#line 527 . "x10/regionarray/Array.x10"
                final x10.core.Rail t$142689 = ((x10.core.Rail)(((x10.regionarray.Array<$T>)this$142684).raw));
                
                //#line 1315 .. "x10/regionarray/Array.x10"
                final long t$142691 = ((long)(((int)(0))));
                
                //#line 1315 .. "x10/regionarray/Array.x10"
                final long t$142692 = p$142682.$apply$O((long)(t$142691));
                
                //#line 1315 .. "x10/regionarray/Array.x10"
                final long t$142693 = ((x10.regionarray.Array<$T>)this$142684).layout_min0;
                
                //#line 1315 .. "x10/regionarray/Array.x10"
                long offset$142694 = ((t$142692) - (((long)(t$142693))));
                
                //#line 1316 .. "x10/regionarray/Array.x10"
                final long t$142695 = p$142682.rank;
                
                //#line 1316 .. "x10/regionarray/Array.x10"
                final boolean t$142696 = ((t$142695) > (((long)(1L))));
                
                //#line 1316 .. "x10/regionarray/Array.x10"
                if (t$142696) {
                    
                    //#line 1317 .. "x10/regionarray/Array.x10"
                    final long t$142698 = ((x10.regionarray.Array<$T>)this$142684).layout_stride1;
                    
                    //#line 1317 .. "x10/regionarray/Array.x10"
                    final long t$142699 = ((offset$142694) * (((long)(t$142698))));
                    
                    //#line 1317 .. "x10/regionarray/Array.x10"
                    final long t$142700 = p$142682.$apply$O((long)(1L));
                    
                    //#line 1317 .. "x10/regionarray/Array.x10"
                    final long t$142701 = ((t$142699) + (((long)(t$142700))));
                    
                    //#line 1317 .. "x10/regionarray/Array.x10"
                    final long t$142702 = ((x10.regionarray.Array<$T>)this$142684).layout_min1;
                    
                    //#line 1317 .. "x10/regionarray/Array.x10"
                    final long t$142703 = ((t$142701) - (((long)(t$142702))));
                    
                    //#line 1317 .. "x10/regionarray/Array.x10"
                    offset$142694 = t$142703;
                    
                    //#line 1318 .. "x10/regionarray/Array.x10"
                    final long t$142680 = p$142682.rank;
                    
                    //#line 1318 .. "x10/regionarray/Array.x10"
                    final long i$138773max$142681 = ((t$142680) - (((long)(1L))));
                    
                    //#line 1318 .. "x10/regionarray/Array.x10"
                    long i$142677 = 2L;
                    
                    //#line 1318 .. "x10/regionarray/Array.x10"
                    for (;
                         true;
                         ) {
                        
                        //#line 1318 .. "x10/regionarray/Array.x10"
                        final boolean t$142679 = ((i$142677) <= (((long)(i$138773max$142681))));
                        
                        //#line 1318 .. "x10/regionarray/Array.x10"
                        if (!(t$142679)) {
                            
                            //#line 1318 .. "x10/regionarray/Array.x10"
                            break;
                        }
                        
                        //#line 1319 .. "x10/regionarray/Array.x10"
                        final x10.core.Rail t$142661 = ((x10.core.Rail)(((x10.regionarray.Array<$T>)this$142684).layout));
                        
                        //#line 1319 .. "x10/regionarray/Array.x10"
                        final long t$142662 = ((i$142677) - (((long)(2L))));
                        
                        //#line 1319 .. "x10/regionarray/Array.x10"
                        final long t$142663 = ((2L) * (((long)(t$142662))));
                        
                        //#line 1319 .. "x10/regionarray/Array.x10"
                        final long t$142664 = ((long[])t$142661.value)[(int)t$142663];
                        
                        //#line 1319 .. "x10/regionarray/Array.x10"
                        final long t$142665 = ((offset$142694) * (((long)(t$142664))));
                        
                        //#line 1319 .. "x10/regionarray/Array.x10"
                        final long t$142666 = p$142682.$apply$O((long)(i$142677));
                        
                        //#line 1319 .. "x10/regionarray/Array.x10"
                        final long t$142667 = ((t$142665) + (((long)(t$142666))));
                        
                        //#line 1319 .. "x10/regionarray/Array.x10"
                        final x10.core.Rail t$142668 = ((x10.core.Rail)(((x10.regionarray.Array<$T>)this$142684).layout));
                        
                        //#line 1319 .. "x10/regionarray/Array.x10"
                        final long t$142669 = ((i$142677) - (((long)(2L))));
                        
                        //#line 1319 .. "x10/regionarray/Array.x10"
                        final long t$142670 = ((2L) * (((long)(t$142669))));
                        
                        //#line 1319 .. "x10/regionarray/Array.x10"
                        final long t$142671 = ((t$142670) + (((long)(1L))));
                        
                        //#line 1319 .. "x10/regionarray/Array.x10"
                        final long t$142672 = ((long[])t$142668.value)[(int)t$142671];
                        
                        //#line 1319 .. "x10/regionarray/Array.x10"
                        final long t$142673 = ((t$142667) - (((long)(t$142672))));
                        
                        //#line 1319 .. "x10/regionarray/Array.x10"
                        offset$142694 = t$142673;
                        
                        //#line 1318 .. "x10/regionarray/Array.x10"
                        final long t$142676 = ((i$142677) + (((long)(1L))));
                        
                        //#line 1318 .. "x10/regionarray/Array.x10"
                        i$142677 = t$142676;
                    }
                }
                
                //#line 527 . "x10/regionarray/Array.x10"
                final $T t$142705 = (($T)(((x10.core.Rail<$T>)t$142689).$apply$G((long)(offset$142694))));
                
                //#line 834 "x10/regionarray/Array.x10"
                final $U t$142706 = (($U)((($U)
                                            ((x10.core.fun.Fun_0_2<$U,$T,$U>)op).$apply(accum, $U, t$142705, $T))));
                
                //#line 834 "x10/regionarray/Array.x10"
                accum = (($U)(t$142706));
            }
            
            //#line 836 "x10/regionarray/Array.x10"
            return accum;
        }
    }
    
    
    //#line 854 "x10/regionarray/Array.x10"
    /**
     * Scan this array using the function and the given initial value.
     * Starting with the initial value, apply the operation pointwise to the current running value
     * and each element of this array.
     * Return a new array with the same region as this array.
     * Each element of the new array is the result of applying the given function to the
     * current running value and the corresponding element of this array.
     * 
     * @param op the scan function
     * @param unit the given initial value
     * @return a new array containing the result of the scan 
     * @see #map((T)=>U)
     * @see #reduce((U,T)=>U,U)
     */
    public <$U>x10.regionarray.Array scan__0$1x10$regionarray$Array$$U$3x10$regionarray$Array$$T$3x10$regionarray$Array$$U$2__1x10$regionarray$Array$$U(final x10.rtt.Type $U, final x10.core.fun.Fun_0_2 op, final $U unit) {
        
        //#line 855 "x10/regionarray/Array.x10"
        final x10.regionarray.Array this$139675 = ((x10.regionarray.Array)(this));
        
        //#line 855 "x10/regionarray/Array.x10"
        final x10.regionarray.Array alloc$138543 = ((x10.regionarray.Array)(new x10.regionarray.Array<$U>((java.lang.System[]) null, $U)));
        
        //#line 855 "x10/regionarray/Array.x10"
        final x10.regionarray.Region reg$139663 = ((x10.regionarray.Region)(this.region));
        
        //#line 142 . "x10/regionarray/Array.x10"
        final x10.regionarray.Region t$142710 = ((x10.regionarray.Region)
                                                  reg$139663);
        
        //#line 142 . "x10/regionarray/Array.x10"
        final boolean t$142711 = ((t$142710) != (null));
        
        //#line 142 . "x10/regionarray/Array.x10"
        final boolean t$142712 = !(t$142711);
        
        //#line 142 . "x10/regionarray/Array.x10"
        if (t$142712) {
            
            //#line 142 . "x10/regionarray/Array.x10"
            final boolean t$142713 = true;
            
            //#line 142 . "x10/regionarray/Array.x10"
            if (t$142713) {
                
                //#line 142 . "x10/regionarray/Array.x10"
                final x10.lang.FailedDynamicCheckException t$142714 = new x10.lang.FailedDynamicCheckException("x10.regionarray.Region{self!=null}");
                
                //#line 142 . "x10/regionarray/Array.x10"
                throw t$142714;
            }
        }
        
        //#line 142 . "x10/regionarray/Array.x10"
        ((x10.regionarray.Array<$U>)alloc$138543).region = ((x10.regionarray.Region)(t$142710));
        
        //#line 142 . "x10/regionarray/Array.x10"
        final long t$142715 = reg$139663.rank;
        
        //#line 142 . "x10/regionarray/Array.x10"
        ((x10.regionarray.Array<$U>)alloc$138543).rank = t$142715;
        
        //#line 142 . "x10/regionarray/Array.x10"
        final boolean t$142716 = reg$139663.rect;
        
        //#line 142 . "x10/regionarray/Array.x10"
        ((x10.regionarray.Array<$U>)alloc$138543).rect = t$142716;
        
        //#line 142 . "x10/regionarray/Array.x10"
        final boolean t$142717 = reg$139663.zeroBased;
        
        //#line 142 . "x10/regionarray/Array.x10"
        ((x10.regionarray.Array<$U>)alloc$138543).zeroBased = t$142717;
        
        //#line 142 . "x10/regionarray/Array.x10"
        final boolean t$142718 = reg$139663.rail;
        
        //#line 142 . "x10/regionarray/Array.x10"
        ((x10.regionarray.Array<$U>)alloc$138543).rail = t$142718;
        
        //#line 142 . "x10/regionarray/Array.x10"
        final long t$142719 = reg$139663.size$O();
        
        //#line 142 . "x10/regionarray/Array.x10"
        ((x10.regionarray.Array<$U>)alloc$138543).size = t$142719;
        
        //#line 143 . "x10/regionarray/Array.x10"
        final x10.regionarray.Array.LayoutHelper crh$142810 = new x10.regionarray.Array.LayoutHelper((java.lang.System[]) null);
        
        //#line 143 . "x10/regionarray/Array.x10"
        crh$142810.x10$regionarray$Array$LayoutHelper$$init$S(((x10.regionarray.Region)(reg$139663)));
        
        //#line 144 . "x10/regionarray/Array.x10"
        final long t$142811 = crh$142810.min0;
        
        //#line 144 . "x10/regionarray/Array.x10"
        ((x10.regionarray.Array<$U>)alloc$138543).layout_min0 = t$142811;
        
        //#line 145 . "x10/regionarray/Array.x10"
        final long t$142812 = crh$142810.stride1;
        
        //#line 145 . "x10/regionarray/Array.x10"
        ((x10.regionarray.Array<$U>)alloc$138543).layout_stride1 = t$142812;
        
        //#line 146 . "x10/regionarray/Array.x10"
        final long t$142813 = crh$142810.min1;
        
        //#line 146 . "x10/regionarray/Array.x10"
        ((x10.regionarray.Array<$U>)alloc$138543).layout_min1 = t$142813;
        
        //#line 147 . "x10/regionarray/Array.x10"
        final x10.core.Rail t$142814 = ((x10.core.Rail)(crh$142810.layout));
        
        //#line 147 . "x10/regionarray/Array.x10"
        ((x10.regionarray.Array<$U>)alloc$138543).layout = ((x10.core.Rail)(t$142814));
        
        //#line 148 . "x10/regionarray/Array.x10"
        final long n$142815 = crh$142810.size;
        
        //#line 152 . "x10/regionarray/Array.x10"
        final x10.core.Rail t$142720 = ((x10.core.Rail)(x10.core.Rail.<$U>makeUnsafe($U, ((long)(n$142815)), false)));
        
        //#line 152 . "x10/regionarray/Array.x10"
        ((x10.regionarray.Array<$U>)alloc$138543).raw = ((x10.core.Rail)(t$142720));
        
        //#line 873 . "x10/regionarray/Array.x10"
        $U accum$139672 = (($U)(unit));
        
        //#line 874 . "x10/regionarray/Array.x10"
        final x10.regionarray.Region t$142816 = ((x10.regionarray.Region)(((x10.regionarray.Array<$T>)this$139675).region));
        
        //#line 874 . "x10/regionarray/Array.x10"
        final x10.lang.Iterator p$142817 = t$142816.iterator();
        
        //#line 874 . "x10/regionarray/Array.x10"
        for (;
             true;
             ) {
            
            //#line 874 . "x10/regionarray/Array.x10"
            final boolean t$142818 = ((x10.lang.Iterator<x10.lang.Point>)p$142817).hasNext$O();
            
            //#line 874 . "x10/regionarray/Array.x10"
            if (!(t$142818)) {
                
                //#line 874 . "x10/regionarray/Array.x10"
                break;
            }
            
            //#line 874 . "x10/regionarray/Array.x10"
            final x10.lang.Point p$142765 = ((x10.lang.Point)(((x10.lang.Iterator<x10.lang.Point>)p$142817).next$G()));
            
            //#line 524 .. "x10/regionarray/Array.x10"
            final x10.regionarray.Region t$142768 = ((x10.regionarray.Region)(((x10.regionarray.Array<$T>)this$139675).region));
            
            //#line 524 .. "x10/regionarray/Array.x10"
            final boolean t$142769 = t$142768.contains$O(((x10.lang.Point)(p$142765)));
            
            //#line 524 .. "x10/regionarray/Array.x10"
            final boolean t$142770 = !(t$142769);
            
            //#line 524 .. "x10/regionarray/Array.x10"
            if (t$142770) {
                
                //#line 525 .. "x10/regionarray/Array.x10"
                x10.regionarray.Array.raiseBoundsError(((x10.lang.Point)(p$142765)));
            }
            
            //#line 527 .. "x10/regionarray/Array.x10"
            final x10.core.Rail t$142771 = ((x10.core.Rail)(((x10.regionarray.Array<$T>)this$139675).raw));
            
            //#line 1315 ... "x10/regionarray/Array.x10"
            final long t$142773 = ((long)(((int)(0))));
            
            //#line 1315 ... "x10/regionarray/Array.x10"
            final long t$142774 = p$142765.$apply$O((long)(t$142773));
            
            //#line 1315 ... "x10/regionarray/Array.x10"
            final long t$142775 = ((x10.regionarray.Array<$T>)this$139675).layout_min0;
            
            //#line 1315 ... "x10/regionarray/Array.x10"
            long offset$142776 = ((t$142774) - (((long)(t$142775))));
            
            //#line 1316 ... "x10/regionarray/Array.x10"
            final long t$142777 = p$142765.rank;
            
            //#line 1316 ... "x10/regionarray/Array.x10"
            final boolean t$142778 = ((t$142777) > (((long)(1L))));
            
            //#line 1316 ... "x10/regionarray/Array.x10"
            if (t$142778) {
                
                //#line 1317 ... "x10/regionarray/Array.x10"
                final long t$142780 = ((x10.regionarray.Array<$T>)this$139675).layout_stride1;
                
                //#line 1317 ... "x10/regionarray/Array.x10"
                final long t$142781 = ((offset$142776) * (((long)(t$142780))));
                
                //#line 1317 ... "x10/regionarray/Array.x10"
                final long t$142782 = p$142765.$apply$O((long)(1L));
                
                //#line 1317 ... "x10/regionarray/Array.x10"
                final long t$142783 = ((t$142781) + (((long)(t$142782))));
                
                //#line 1317 ... "x10/regionarray/Array.x10"
                final long t$142784 = ((x10.regionarray.Array<$T>)this$139675).layout_min1;
                
                //#line 1317 ... "x10/regionarray/Array.x10"
                final long t$142785 = ((t$142783) - (((long)(t$142784))));
                
                //#line 1317 ... "x10/regionarray/Array.x10"
                offset$142776 = t$142785;
                
                //#line 1318 ... "x10/regionarray/Array.x10"
                final long t$142741 = p$142765.rank;
                
                //#line 1318 ... "x10/regionarray/Array.x10"
                final long i$138773max$142742 = ((t$142741) - (((long)(1L))));
                
                //#line 1318 ... "x10/regionarray/Array.x10"
                long i$142738 = 2L;
                
                //#line 1318 ... "x10/regionarray/Array.x10"
                for (;
                     true;
                     ) {
                    
                    //#line 1318 ... "x10/regionarray/Array.x10"
                    final boolean t$142740 = ((i$142738) <= (((long)(i$138773max$142742))));
                    
                    //#line 1318 ... "x10/regionarray/Array.x10"
                    if (!(t$142740)) {
                        
                        //#line 1318 ... "x10/regionarray/Array.x10"
                        break;
                    }
                    
                    //#line 1319 ... "x10/regionarray/Array.x10"
                    final x10.core.Rail t$142722 = ((x10.core.Rail)(((x10.regionarray.Array<$T>)this$139675).layout));
                    
                    //#line 1319 ... "x10/regionarray/Array.x10"
                    final long t$142723 = ((i$142738) - (((long)(2L))));
                    
                    //#line 1319 ... "x10/regionarray/Array.x10"
                    final long t$142724 = ((2L) * (((long)(t$142723))));
                    
                    //#line 1319 ... "x10/regionarray/Array.x10"
                    final long t$142725 = ((long[])t$142722.value)[(int)t$142724];
                    
                    //#line 1319 ... "x10/regionarray/Array.x10"
                    final long t$142726 = ((offset$142776) * (((long)(t$142725))));
                    
                    //#line 1319 ... "x10/regionarray/Array.x10"
                    final long t$142727 = p$142765.$apply$O((long)(i$142738));
                    
                    //#line 1319 ... "x10/regionarray/Array.x10"
                    final long t$142728 = ((t$142726) + (((long)(t$142727))));
                    
                    //#line 1319 ... "x10/regionarray/Array.x10"
                    final x10.core.Rail t$142729 = ((x10.core.Rail)(((x10.regionarray.Array<$T>)this$139675).layout));
                    
                    //#line 1319 ... "x10/regionarray/Array.x10"
                    final long t$142730 = ((i$142738) - (((long)(2L))));
                    
                    //#line 1319 ... "x10/regionarray/Array.x10"
                    final long t$142731 = ((2L) * (((long)(t$142730))));
                    
                    //#line 1319 ... "x10/regionarray/Array.x10"
                    final long t$142732 = ((t$142731) + (((long)(1L))));
                    
                    //#line 1319 ... "x10/regionarray/Array.x10"
                    final long t$142733 = ((long[])t$142729.value)[(int)t$142732];
                    
                    //#line 1319 ... "x10/regionarray/Array.x10"
                    final long t$142734 = ((t$142728) - (((long)(t$142733))));
                    
                    //#line 1319 ... "x10/regionarray/Array.x10"
                    offset$142776 = t$142734;
                    
                    //#line 1318 ... "x10/regionarray/Array.x10"
                    final long t$142737 = ((i$142738) + (((long)(1L))));
                    
                    //#line 1318 ... "x10/regionarray/Array.x10"
                    i$142738 = t$142737;
                }
            }
            
            //#line 527 .. "x10/regionarray/Array.x10"
            final $T t$142787 = (($T)(((x10.core.Rail<$T>)t$142771).$apply$G((long)(offset$142776))));
            
            //#line 875 . "x10/regionarray/Array.x10"
            final $U t$142788 = (($U)((($U)
                                        ((x10.core.fun.Fun_0_2<$U,$T,$U>)op).$apply(accum$139672, $U, t$142787, $T))));
            
            //#line 875 . "x10/regionarray/Array.x10"
            accum$139672 = (($U)(t$142788));
            
            //#line 637 .. "x10/regionarray/Array.x10"
            final x10.regionarray.Region t$142791 = ((x10.regionarray.Region)(((x10.regionarray.Array<$U>)alloc$138543).region));
            
            //#line 637 .. "x10/regionarray/Array.x10"
            final boolean t$142792 = t$142791.contains$O(((x10.lang.Point)(p$142765)));
            
            //#line 637 .. "x10/regionarray/Array.x10"
            final boolean t$142793 = !(t$142792);
            
            //#line 637 .. "x10/regionarray/Array.x10"
            if (t$142793) {
                
                //#line 638 .. "x10/regionarray/Array.x10"
                x10.regionarray.Array.raiseBoundsError(((x10.lang.Point)(p$142765)));
            }
            
            //#line 640 .. "x10/regionarray/Array.x10"
            final x10.core.Rail t$142794 = ((x10.core.Rail)(((x10.regionarray.Array<$U>)alloc$138543).raw));
            
            //#line 1315 ... "x10/regionarray/Array.x10"
            final long t$142796 = ((long)(((int)(0))));
            
            //#line 1315 ... "x10/regionarray/Array.x10"
            final long t$142797 = p$142765.$apply$O((long)(t$142796));
            
            //#line 1315 ... "x10/regionarray/Array.x10"
            final long t$142798 = ((x10.regionarray.Array<$U>)alloc$138543).layout_min0;
            
            //#line 1315 ... "x10/regionarray/Array.x10"
            long offset$142799 = ((t$142797) - (((long)(t$142798))));
            
            //#line 1316 ... "x10/regionarray/Array.x10"
            final long t$142800 = p$142765.rank;
            
            //#line 1316 ... "x10/regionarray/Array.x10"
            final boolean t$142801 = ((t$142800) > (((long)(1L))));
            
            //#line 1316 ... "x10/regionarray/Array.x10"
            if (t$142801) {
                
                //#line 1317 ... "x10/regionarray/Array.x10"
                final long t$142803 = ((x10.regionarray.Array<$U>)alloc$138543).layout_stride1;
                
                //#line 1317 ... "x10/regionarray/Array.x10"
                final long t$142804 = ((offset$142799) * (((long)(t$142803))));
                
                //#line 1317 ... "x10/regionarray/Array.x10"
                final long t$142805 = p$142765.$apply$O((long)(1L));
                
                //#line 1317 ... "x10/regionarray/Array.x10"
                final long t$142806 = ((t$142804) + (((long)(t$142805))));
                
                //#line 1317 ... "x10/regionarray/Array.x10"
                final long t$142807 = ((x10.regionarray.Array<$U>)alloc$138543).layout_min1;
                
                //#line 1317 ... "x10/regionarray/Array.x10"
                final long t$142808 = ((t$142806) - (((long)(t$142807))));
                
                //#line 1317 ... "x10/regionarray/Array.x10"
                offset$142799 = t$142808;
                
                //#line 1318 ... "x10/regionarray/Array.x10"
                final long t$142763 = p$142765.rank;
                
                //#line 1318 ... "x10/regionarray/Array.x10"
                final long i$138773max$142764 = ((t$142763) - (((long)(1L))));
                
                //#line 1318 ... "x10/regionarray/Array.x10"
                long i$142760 = 2L;
                
                //#line 1318 ... "x10/regionarray/Array.x10"
                for (;
                     true;
                     ) {
                    
                    //#line 1318 ... "x10/regionarray/Array.x10"
                    final boolean t$142762 = ((i$142760) <= (((long)(i$138773max$142764))));
                    
                    //#line 1318 ... "x10/regionarray/Array.x10"
                    if (!(t$142762)) {
                        
                        //#line 1318 ... "x10/regionarray/Array.x10"
                        break;
                    }
                    
                    //#line 1319 ... "x10/regionarray/Array.x10"
                    final x10.core.Rail t$142744 = ((x10.core.Rail)(((x10.regionarray.Array<$U>)alloc$138543).layout));
                    
                    //#line 1319 ... "x10/regionarray/Array.x10"
                    final long t$142745 = ((i$142760) - (((long)(2L))));
                    
                    //#line 1319 ... "x10/regionarray/Array.x10"
                    final long t$142746 = ((2L) * (((long)(t$142745))));
                    
                    //#line 1319 ... "x10/regionarray/Array.x10"
                    final long t$142747 = ((long[])t$142744.value)[(int)t$142746];
                    
                    //#line 1319 ... "x10/regionarray/Array.x10"
                    final long t$142748 = ((offset$142799) * (((long)(t$142747))));
                    
                    //#line 1319 ... "x10/regionarray/Array.x10"
                    final long t$142749 = p$142765.$apply$O((long)(i$142760));
                    
                    //#line 1319 ... "x10/regionarray/Array.x10"
                    final long t$142750 = ((t$142748) + (((long)(t$142749))));
                    
                    //#line 1319 ... "x10/regionarray/Array.x10"
                    final x10.core.Rail t$142751 = ((x10.core.Rail)(((x10.regionarray.Array<$U>)alloc$138543).layout));
                    
                    //#line 1319 ... "x10/regionarray/Array.x10"
                    final long t$142752 = ((i$142760) - (((long)(2L))));
                    
                    //#line 1319 ... "x10/regionarray/Array.x10"
                    final long t$142753 = ((2L) * (((long)(t$142752))));
                    
                    //#line 1319 ... "x10/regionarray/Array.x10"
                    final long t$142754 = ((t$142753) + (((long)(1L))));
                    
                    //#line 1319 ... "x10/regionarray/Array.x10"
                    final long t$142755 = ((long[])t$142751.value)[(int)t$142754];
                    
                    //#line 1319 ... "x10/regionarray/Array.x10"
                    final long t$142756 = ((t$142750) - (((long)(t$142755))));
                    
                    //#line 1319 ... "x10/regionarray/Array.x10"
                    offset$142799 = t$142756;
                    
                    //#line 1318 ... "x10/regionarray/Array.x10"
                    final long t$142759 = ((i$142760) + (((long)(1L))));
                    
                    //#line 1318 ... "x10/regionarray/Array.x10"
                    i$142760 = t$142759;
                }
            }
            
            //#line 640 .. "x10/regionarray/Array.x10"
            ((x10.core.Rail<$U>)t$142794).$set__1x10$lang$Rail$$T$G((long)(offset$142799), (($U)(accum$139672)));
        }
        
        //#line 855 "x10/regionarray/Array.x10"
        return alloc$138543;
    }
    
    
    //#line 872 "x10/regionarray/Array.x10"
    /**
     * Scan this array using the given function and the given initial value.
     * Starting with the initial value, apply the operation pointwise to the current running value
     * and each element of this array storing the result in the destination array.
     * Return the destination array where each element has been set to the result of 
     * applying the given operation to the current running value and the corresponding 
     * element of this array.
     * 
     * @param op the scan function
     * @param unit the given initial value
     * @return a new array containing the result of the scan 
     * @see #map((T)=>U)
     * @see #reduce((U,T)=>U,U)
     */
    public <$U>x10.regionarray.Array scan__0$1x10$regionarray$Array$$U$2__1$1x10$regionarray$Array$$U$3x10$regionarray$Array$$T$3x10$regionarray$Array$$U$2__2x10$regionarray$Array$$U(final x10.rtt.Type $U, final x10.regionarray.Array dst, final x10.core.fun.Fun_0_2 op, final $U unit) {
        
        //#line 873 "x10/regionarray/Array.x10"
        $U accum = (($U)(unit));
        
        //#line 874 "x10/regionarray/Array.x10"
        final x10.regionarray.Region t$142909 = ((x10.regionarray.Region)(this.region));
        
        //#line 874 "x10/regionarray/Array.x10"
        final x10.lang.Iterator p$142910 = t$142909.iterator();
        
        //#line 874 "x10/regionarray/Array.x10"
        for (;
             true;
             ) {
            
            //#line 874 "x10/regionarray/Array.x10"
            final boolean t$142911 = ((x10.lang.Iterator<x10.lang.Point>)p$142910).hasNext$O();
            
            //#line 874 "x10/regionarray/Array.x10"
            if (!(t$142911)) {
                
                //#line 874 "x10/regionarray/Array.x10"
                break;
            }
            
            //#line 874 "x10/regionarray/Array.x10"
            final x10.lang.Point p$142863 = ((x10.lang.Point)(((x10.lang.Iterator<x10.lang.Point>)p$142910).next$G()));
            
            //#line 875 "x10/regionarray/Array.x10"
            final x10.regionarray.Array this$142865 = ((x10.regionarray.Array)(this));
            
            //#line 524 . "x10/regionarray/Array.x10"
            final x10.regionarray.Region t$142867 = ((x10.regionarray.Region)(((x10.regionarray.Array<$T>)this$142865).region));
            
            //#line 524 . "x10/regionarray/Array.x10"
            final boolean t$142868 = t$142867.contains$O(((x10.lang.Point)(p$142863)));
            
            //#line 524 . "x10/regionarray/Array.x10"
            final boolean t$142869 = !(t$142868);
            
            //#line 524 . "x10/regionarray/Array.x10"
            if (t$142869) {
                
                //#line 525 . "x10/regionarray/Array.x10"
                x10.regionarray.Array.raiseBoundsError(((x10.lang.Point)(p$142863)));
            }
            
            //#line 527 . "x10/regionarray/Array.x10"
            final x10.core.Rail t$142870 = ((x10.core.Rail)(((x10.regionarray.Array<$T>)this$142865).raw));
            
            //#line 1315 .. "x10/regionarray/Array.x10"
            final long t$142872 = ((long)(((int)(0))));
            
            //#line 1315 .. "x10/regionarray/Array.x10"
            final long t$142873 = p$142863.$apply$O((long)(t$142872));
            
            //#line 1315 .. "x10/regionarray/Array.x10"
            final long t$142874 = ((x10.regionarray.Array<$T>)this$142865).layout_min0;
            
            //#line 1315 .. "x10/regionarray/Array.x10"
            long offset$142875 = ((t$142873) - (((long)(t$142874))));
            
            //#line 1316 .. "x10/regionarray/Array.x10"
            final long t$142876 = p$142863.rank;
            
            //#line 1316 .. "x10/regionarray/Array.x10"
            final boolean t$142877 = ((t$142876) > (((long)(1L))));
            
            //#line 1316 .. "x10/regionarray/Array.x10"
            if (t$142877) {
                
                //#line 1317 .. "x10/regionarray/Array.x10"
                final long t$142879 = ((x10.regionarray.Array<$T>)this$142865).layout_stride1;
                
                //#line 1317 .. "x10/regionarray/Array.x10"
                final long t$142880 = ((offset$142875) * (((long)(t$142879))));
                
                //#line 1317 .. "x10/regionarray/Array.x10"
                final long t$142881 = p$142863.$apply$O((long)(1L));
                
                //#line 1317 .. "x10/regionarray/Array.x10"
                final long t$142882 = ((t$142880) + (((long)(t$142881))));
                
                //#line 1317 .. "x10/regionarray/Array.x10"
                final long t$142883 = ((x10.regionarray.Array<$T>)this$142865).layout_min1;
                
                //#line 1317 .. "x10/regionarray/Array.x10"
                final long t$142884 = ((t$142882) - (((long)(t$142883))));
                
                //#line 1317 .. "x10/regionarray/Array.x10"
                offset$142875 = t$142884;
                
                //#line 1318 .. "x10/regionarray/Array.x10"
                final long t$142839 = p$142863.rank;
                
                //#line 1318 .. "x10/regionarray/Array.x10"
                final long i$138773max$142840 = ((t$142839) - (((long)(1L))));
                
                //#line 1318 .. "x10/regionarray/Array.x10"
                long i$142836 = 2L;
                
                //#line 1318 .. "x10/regionarray/Array.x10"
                for (;
                     true;
                     ) {
                    
                    //#line 1318 .. "x10/regionarray/Array.x10"
                    final boolean t$142838 = ((i$142836) <= (((long)(i$138773max$142840))));
                    
                    //#line 1318 .. "x10/regionarray/Array.x10"
                    if (!(t$142838)) {
                        
                        //#line 1318 .. "x10/regionarray/Array.x10"
                        break;
                    }
                    
                    //#line 1319 .. "x10/regionarray/Array.x10"
                    final x10.core.Rail t$142820 = ((x10.core.Rail)(((x10.regionarray.Array<$T>)this$142865).layout));
                    
                    //#line 1319 .. "x10/regionarray/Array.x10"
                    final long t$142821 = ((i$142836) - (((long)(2L))));
                    
                    //#line 1319 .. "x10/regionarray/Array.x10"
                    final long t$142822 = ((2L) * (((long)(t$142821))));
                    
                    //#line 1319 .. "x10/regionarray/Array.x10"
                    final long t$142823 = ((long[])t$142820.value)[(int)t$142822];
                    
                    //#line 1319 .. "x10/regionarray/Array.x10"
                    final long t$142824 = ((offset$142875) * (((long)(t$142823))));
                    
                    //#line 1319 .. "x10/regionarray/Array.x10"
                    final long t$142825 = p$142863.$apply$O((long)(i$142836));
                    
                    //#line 1319 .. "x10/regionarray/Array.x10"
                    final long t$142826 = ((t$142824) + (((long)(t$142825))));
                    
                    //#line 1319 .. "x10/regionarray/Array.x10"
                    final x10.core.Rail t$142827 = ((x10.core.Rail)(((x10.regionarray.Array<$T>)this$142865).layout));
                    
                    //#line 1319 .. "x10/regionarray/Array.x10"
                    final long t$142828 = ((i$142836) - (((long)(2L))));
                    
                    //#line 1319 .. "x10/regionarray/Array.x10"
                    final long t$142829 = ((2L) * (((long)(t$142828))));
                    
                    //#line 1319 .. "x10/regionarray/Array.x10"
                    final long t$142830 = ((t$142829) + (((long)(1L))));
                    
                    //#line 1319 .. "x10/regionarray/Array.x10"
                    final long t$142831 = ((long[])t$142827.value)[(int)t$142830];
                    
                    //#line 1319 .. "x10/regionarray/Array.x10"
                    final long t$142832 = ((t$142826) - (((long)(t$142831))));
                    
                    //#line 1319 .. "x10/regionarray/Array.x10"
                    offset$142875 = t$142832;
                    
                    //#line 1318 .. "x10/regionarray/Array.x10"
                    final long t$142835 = ((i$142836) + (((long)(1L))));
                    
                    //#line 1318 .. "x10/regionarray/Array.x10"
                    i$142836 = t$142835;
                }
            }
            
            //#line 527 . "x10/regionarray/Array.x10"
            final $T t$142886 = (($T)(((x10.core.Rail<$T>)t$142870).$apply$G((long)(offset$142875))));
            
            //#line 875 "x10/regionarray/Array.x10"
            final $U t$142887 = (($U)((($U)
                                        ((x10.core.fun.Fun_0_2<$U,$T,$U>)op).$apply(accum, $U, t$142886, $T))));
            
            //#line 875 "x10/regionarray/Array.x10"
            accum = (($U)(t$142887));
            
            //#line 637 . "x10/regionarray/Array.x10"
            final x10.regionarray.Region t$142890 = ((x10.regionarray.Region)(((x10.regionarray.Array<$U>)dst).region));
            
            //#line 637 . "x10/regionarray/Array.x10"
            final boolean t$142891 = t$142890.contains$O(((x10.lang.Point)(p$142863)));
            
            //#line 637 . "x10/regionarray/Array.x10"
            final boolean t$142892 = !(t$142891);
            
            //#line 637 . "x10/regionarray/Array.x10"
            if (t$142892) {
                
                //#line 638 . "x10/regionarray/Array.x10"
                x10.regionarray.Array.raiseBoundsError(((x10.lang.Point)(p$142863)));
            }
            
            //#line 640 . "x10/regionarray/Array.x10"
            final x10.core.Rail t$142893 = ((x10.core.Rail)(((x10.regionarray.Array<$U>)dst).raw));
            
            //#line 1315 .. "x10/regionarray/Array.x10"
            final long t$142895 = ((long)(((int)(0))));
            
            //#line 1315 .. "x10/regionarray/Array.x10"
            final long t$142896 = p$142863.$apply$O((long)(t$142895));
            
            //#line 1315 .. "x10/regionarray/Array.x10"
            final long t$142897 = ((x10.regionarray.Array<$U>)dst).layout_min0;
            
            //#line 1315 .. "x10/regionarray/Array.x10"
            long offset$142898 = ((t$142896) - (((long)(t$142897))));
            
            //#line 1316 .. "x10/regionarray/Array.x10"
            final long t$142899 = p$142863.rank;
            
            //#line 1316 .. "x10/regionarray/Array.x10"
            final boolean t$142900 = ((t$142899) > (((long)(1L))));
            
            //#line 1316 .. "x10/regionarray/Array.x10"
            if (t$142900) {
                
                //#line 1317 .. "x10/regionarray/Array.x10"
                final long t$142902 = ((x10.regionarray.Array<$U>)dst).layout_stride1;
                
                //#line 1317 .. "x10/regionarray/Array.x10"
                final long t$142903 = ((offset$142898) * (((long)(t$142902))));
                
                //#line 1317 .. "x10/regionarray/Array.x10"
                final long t$142904 = p$142863.$apply$O((long)(1L));
                
                //#line 1317 .. "x10/regionarray/Array.x10"
                final long t$142905 = ((t$142903) + (((long)(t$142904))));
                
                //#line 1317 .. "x10/regionarray/Array.x10"
                final long t$142906 = ((x10.regionarray.Array<$U>)dst).layout_min1;
                
                //#line 1317 .. "x10/regionarray/Array.x10"
                final long t$142907 = ((t$142905) - (((long)(t$142906))));
                
                //#line 1317 .. "x10/regionarray/Array.x10"
                offset$142898 = t$142907;
                
                //#line 1318 .. "x10/regionarray/Array.x10"
                final long t$142861 = p$142863.rank;
                
                //#line 1318 .. "x10/regionarray/Array.x10"
                final long i$138773max$142862 = ((t$142861) - (((long)(1L))));
                
                //#line 1318 .. "x10/regionarray/Array.x10"
                long i$142858 = 2L;
                
                //#line 1318 .. "x10/regionarray/Array.x10"
                for (;
                     true;
                     ) {
                    
                    //#line 1318 .. "x10/regionarray/Array.x10"
                    final boolean t$142860 = ((i$142858) <= (((long)(i$138773max$142862))));
                    
                    //#line 1318 .. "x10/regionarray/Array.x10"
                    if (!(t$142860)) {
                        
                        //#line 1318 .. "x10/regionarray/Array.x10"
                        break;
                    }
                    
                    //#line 1319 .. "x10/regionarray/Array.x10"
                    final x10.core.Rail t$142842 = ((x10.core.Rail)(((x10.regionarray.Array<$U>)dst).layout));
                    
                    //#line 1319 .. "x10/regionarray/Array.x10"
                    final long t$142843 = ((i$142858) - (((long)(2L))));
                    
                    //#line 1319 .. "x10/regionarray/Array.x10"
                    final long t$142844 = ((2L) * (((long)(t$142843))));
                    
                    //#line 1319 .. "x10/regionarray/Array.x10"
                    final long t$142845 = ((long[])t$142842.value)[(int)t$142844];
                    
                    //#line 1319 .. "x10/regionarray/Array.x10"
                    final long t$142846 = ((offset$142898) * (((long)(t$142845))));
                    
                    //#line 1319 .. "x10/regionarray/Array.x10"
                    final long t$142847 = p$142863.$apply$O((long)(i$142858));
                    
                    //#line 1319 .. "x10/regionarray/Array.x10"
                    final long t$142848 = ((t$142846) + (((long)(t$142847))));
                    
                    //#line 1319 .. "x10/regionarray/Array.x10"
                    final x10.core.Rail t$142849 = ((x10.core.Rail)(((x10.regionarray.Array<$U>)dst).layout));
                    
                    //#line 1319 .. "x10/regionarray/Array.x10"
                    final long t$142850 = ((i$142858) - (((long)(2L))));
                    
                    //#line 1319 .. "x10/regionarray/Array.x10"
                    final long t$142851 = ((2L) * (((long)(t$142850))));
                    
                    //#line 1319 .. "x10/regionarray/Array.x10"
                    final long t$142852 = ((t$142851) + (((long)(1L))));
                    
                    //#line 1319 .. "x10/regionarray/Array.x10"
                    final long t$142853 = ((long[])t$142849.value)[(int)t$142852];
                    
                    //#line 1319 .. "x10/regionarray/Array.x10"
                    final long t$142854 = ((t$142848) - (((long)(t$142853))));
                    
                    //#line 1319 .. "x10/regionarray/Array.x10"
                    offset$142898 = t$142854;
                    
                    //#line 1318 .. "x10/regionarray/Array.x10"
                    final long t$142857 = ((i$142858) + (((long)(1L))));
                    
                    //#line 1318 .. "x10/regionarray/Array.x10"
                    i$142858 = t$142857;
                }
            }
            
            //#line 640 . "x10/regionarray/Array.x10"
            ((x10.core.Rail<$U>)t$142893).$set__1x10$lang$Rail$$T$G((long)(offset$142898), (($U)(accum)));
        }
        
        //#line 878 "x10/regionarray/Array.x10"
        return dst;
    }
    
    
    //#line 903 "x10/regionarray/Array.x10"
    /**
     * Asynchronously copy all of the values from the source Array to the 
     * Array referenced by the destination RemoteArray.
     * The two arrays must be defined over Regions with equal size 
     * bounding boxes; if the backing storage for the two arrays is 
     * not of equal size, then an IllegalArgumentExeption will be raised.<p>
     * 
     * The activity created to do the copying will be registered with the
     * dynamically enclosing finish.<p>
     * 
     * Warning: This method is only intended to be used on Arrays containing
     *   non-Object data elements.  The elements are actually copied via an
     *   optimized DMA operation if available.  Therefore object-references will
     *   not be properly transferred. Ideally, future versions of the X10 type
     *   system would enable this restriction to be checked statically.</p>
     * 
     * @param src the source array.
     * @param dst the destination array.
     * @throws IllegalArgumentException if mismatch in size of backing storage
     *         of the two arrays.
     */
    public static <$T>void asyncCopy__0$1x10$regionarray$Array$$T$2__1$1x10$regionarray$Array$$T$2(final x10.rtt.Type $T, final x10.regionarray.Array<$T> src, final x10.regionarray.RemoteArray<$T> dst) {
        
        //#line 904 "x10/regionarray/Array.x10"
        final x10.core.Rail t$141140 = ((x10.core.Rail)(((x10.regionarray.Array<$T>)src).raw));
        
        //#line 904 "x10/regionarray/Array.x10"
        final x10.lang.GlobalRail t$141141 = ((x10.lang.GlobalRail)(((x10.regionarray.RemoteArray<$T>)dst).rawData));
        
        //#line 904 "x10/regionarray/Array.x10"
        final x10.core.Rail t$141139 = ((x10.core.Rail)(((x10.regionarray.Array<$T>)src).raw));
        
        //#line 904 "x10/regionarray/Array.x10"
        final long t$141142 = ((x10.core.Rail<$T>)t$141139).size;
        
        //#line 904 "x10/regionarray/Array.x10"
        x10.core.Rail.<$T> asyncCopy__0$1x10$lang$Rail$$T$2__2$1x10$lang$Rail$$T$2($T, ((x10.core.Rail)(t$141140)), (long)(0L), ((x10.lang.GlobalRail)(t$141141)), (long)(0L), (long)(t$141142));
    }
    
    
    //#line 934 "x10/regionarray/Array.x10"
    /**
     * Asynchronously copy the specified values from the source Array to the 
     * specified portion of the Array referenced by the destination RemoteArray.
     * If accessing any point in either the specified source or the 
     * specified destination range would in an ArrayIndexOutOfBoundsError
     * being raised, then this method will throw an IllegalArgumentException.<p>
     * 
     * The activity created to do the copying will be registered with the
     * dynamically enclosing finish.<p>
     * 
     * Warning: This method is only intended to be used on Arrays containing
     *   non-Object data elements.  The elements are actually copied via an
     *   optimized DMA operation if available.  Therefore object-references will
     *   not be properly transferred. Ideally, future versions of the X10 type
     *   system would enable this restriction to be checked statically.</p>
     * 
     * @param src the source array.
     * @param srcPoint the first element in this array to be copied.  
     * @param dst the destination array.  May actually be local or remote
     * @param dstPoint the first element in the destination
     *                 array where copied data elements will be stored.
     * @param numElems the number of elements to be copied.
     * 
     * @throws IllegalArgumentException if the specified copy regions would 
     *         result in an ArrayIndexOutOfBoundsException.
     */
    public static <$T>void asyncCopy__0$1x10$regionarray$Array$$T$2__2$1x10$regionarray$Array$$T$2(final x10.rtt.Type $T, final x10.regionarray.Array<$T> src, final x10.lang.Point srcPoint, final x10.regionarray.RemoteArray<$T> dst, final x10.lang.Point dstPoint, final long numElems) {
        
        //#line 937 "x10/regionarray/Array.x10"
        final x10.core.GlobalRef gra = ((x10.core.GlobalRef)(((x10.regionarray.RemoteArray<$T>)dst).array));
        
        //#line 938 "x10/regionarray/Array.x10"
        final x10.lang.Place t$136661 = ((x10.lang.Place)((gra).home));
        
        //#line 938 "x10/regionarray/Array.x10"
        final long dstIndex = x10.core.Long.$unbox(x10.xrx.Runtime.<x10.core.Long> evalAt__1$1x10$xrx$Runtime$$T$2$G(x10.rtt.Types.LONG, ((x10.lang.Place)(t$136661)), ((x10.core.fun.Fun_0_0)(new x10.regionarray.Array.$Closure$202<$T>($T, gra, dstPoint, (x10.regionarray.Array.$Closure$202.__0$1x10$regionarray$Array$1x10$regionarray$Array$$Closure$202$$T$2$2) null))), ((x10.xrx.Runtime.Profile)(null))));
        
        //#line 939 "x10/regionarray/Array.x10"
        final x10.regionarray.Region t$141143 = ((x10.regionarray.Region)(((x10.regionarray.Array<$T>)src).region));
        
        //#line 939 "x10/regionarray/Array.x10"
        final long srcIndex$139717 = t$141143.indexOf$O(((x10.lang.Point)(srcPoint)));
        
        //#line 981 . "x10/regionarray/Array.x10"
        final x10.core.Rail t$142912 = ((x10.core.Rail)(((x10.regionarray.Array<$T>)src).raw));
        
        //#line 981 . "x10/regionarray/Array.x10"
        final x10.lang.GlobalRail t$142913 = ((x10.lang.GlobalRail)(((x10.regionarray.RemoteArray<$T>)dst).rawData));
        
        //#line 981 . "x10/regionarray/Array.x10"
        x10.core.Rail.<$T> asyncCopy__0$1x10$lang$Rail$$T$2__2$1x10$lang$Rail$$T$2($T, ((x10.core.Rail)(t$142912)), (long)(srcIndex$139717), ((x10.lang.GlobalRail)(t$142913)), (long)(dstIndex), (long)(numElems));
    }
    
    
    //#line 978 "x10/regionarray/Array.x10"
    /**
     * Asynchronously copy the specified values from the source Array to the 
     * specified portion of the Array referenced by the destination RemoteArray.
     * The index arguments that are used to specify the start of the source
     * and destination regions are interpreted as of they were the result
     * of calling {@link Region#indexOf} on the Point that specifies the
     * start of the copy region.  Note that for Arrays that have the 
     * <code>rail</code> property, this exactly corresponds to the index
     * that would be used to access the element via apply or set.
     * If accessing any point in either the specified source or the 
     * specified destination range would in an ArrayIndexOutOfBoundsError
     * being raised, then this method will throw an IllegalArgumentException.<p>
     * 
     * The activity created to do the copying will be registered with the
     * dynamically enclosing finish.<p>
     * 
     * Warning: This method is only intended to be used on Arrays containing
     *   non-Object data elements.  The elements are actually copied via an
     *   optimized DMA operation if available.  Therefore object-references will
     *   not be properly transferred. Ideally, future versions of the X10 type
     *   system would enable this restriction to be checked statically.</p>
     * 
     * @param src the source array.
     * @param srcIndex the index of the first element in this array
     *        to be copied.  
     * @param dst the destination array.  May actually be local or remote
     * @param dstIndex the index of the first element in the destination
     *        array where copied data elements will be stored.
     * @param numElems the number of elements to be copied.
     * 
     * @see Region#indexOf
     * 
     * @throws IllegalArgumentException if the specified copy regions would 
     *         result in an ArrayIndexOutOfBoundsException.
     */
    public static <$T>void asyncCopy__0$1x10$regionarray$Array$$T$2__2$1x10$regionarray$Array$$T$2(final x10.rtt.Type $T, final x10.regionarray.Array<$T> src, final long srcIndex, final x10.regionarray.RemoteArray<$T> dst, final long dstIndex, final long numElems) {
        
        //#line 981 "x10/regionarray/Array.x10"
        final x10.core.Rail t$141146 = ((x10.core.Rail)(((x10.regionarray.Array<$T>)src).raw));
        
        //#line 981 "x10/regionarray/Array.x10"
        final x10.lang.GlobalRail t$141147 = ((x10.lang.GlobalRail)(((x10.regionarray.RemoteArray<$T>)dst).rawData));
        
        //#line 981 "x10/regionarray/Array.x10"
        x10.core.Rail.<$T> asyncCopy__0$1x10$lang$Rail$$T$2__2$1x10$lang$Rail$$T$2($T, ((x10.core.Rail)(t$141146)), (long)(srcIndex), ((x10.lang.GlobalRail)(t$141147)), (long)(dstIndex), (long)(numElems));
    }
    
    
    //#line 1006 "x10/regionarray/Array.x10"
    /**
     * Asynchronously copy all of the values from the source Array 
     * referenced by the RemoteArray to the destination Array.
     * The two arrays must be defined over Regions with equal size 
     * bounding boxes; if the backing storage for the two arrays is 
     * not of equal size, then an IllegalArgumentExeption will be raised.<p>
     * 
     * The activity created to do the copying will be registered with the
     * dynamically enclosing finish.<p>
     * 
     * Warning: This method is only intended to be used on Arrays containing
     *   non-Object data elements.  The elements are actually copied via an
     *   optimized DMA operation if available.  Therefore object-references will
     *   not be properly transferred. Ideally, future versions of the X10 type
     *   system would enable this restriction to be checked statically.</p>
     * 
     * @param src the source array.
     * @param dst the destination array.
     * @throws IllegalArgumentException if mismatch in size of backing storage
     *         of the two arrays.
     */
    public static <$T>void asyncCopy__0$1x10$regionarray$Array$$T$2__1$1x10$regionarray$Array$$T$2(final x10.rtt.Type $T, final x10.regionarray.RemoteArray<$T> src, final x10.regionarray.Array<$T> dst) {
        
        //#line 1007 "x10/regionarray/Array.x10"
        final x10.lang.GlobalRail t$141149 = ((x10.lang.GlobalRail)(((x10.regionarray.RemoteArray<$T>)src).rawData));
        
        //#line 1007 "x10/regionarray/Array.x10"
        final x10.core.Rail t$141150 = ((x10.core.Rail)(((x10.regionarray.Array<$T>)dst).raw));
        
        //#line 1007 "x10/regionarray/Array.x10"
        final x10.core.Rail t$141148 = ((x10.core.Rail)(((x10.regionarray.Array<$T>)dst).raw));
        
        //#line 1007 "x10/regionarray/Array.x10"
        final long t$141151 = ((x10.core.Rail<$T>)t$141148).size;
        
        //#line 1007 "x10/regionarray/Array.x10"
        x10.core.Rail.<$T> asyncCopy__0$1x10$lang$Rail$$T$2__2$1x10$lang$Rail$$T$2($T, ((x10.lang.GlobalRail)(t$141149)), (long)(0L), ((x10.core.Rail)(t$141150)), (long)(0L), (long)(t$141151));
    }
    
    
    //#line 1037 "x10/regionarray/Array.x10"
    /**
     * Asynchronously copy the specified values from the Array referenced by
     * the source RemoteArray to the specified portion of the destination Array.
     * If accessing any point in either the specified source or the 
     * specified destination range would in an ArrayIndexOutOfBoundsError
     * being raised, then this method will throw an IllegalArgumentException.<p>
     * 
     * The activity created to do the copying will be registered with the
     * dynamically enclosing finish.<p>
     * 
     * Warning: This method is only intended to be used on Arrays containing
     *   non-Object data elements.  The elements are actually copied via an
     *   optimized DMA operation if available.  Therefore object-references will
     *   not be properly transferred. Ideally, future versions of the X10 type
     *   system would enable this restriction to be checked statically.</p>
     * 
     * @param src the source array.
     * @param srcPoint the first element in this array to be copied.  
     * @param dst the destination array.  May actually be local or remote
     * @param dstPoint the first element in the destination
     *                 array where copied data elements will be stored.
     * @param numElems the number of elements to be copied.
     * 
     * @throws IllegalArgumentException if the specified copy regions would 
     *         result in an ArrayIndexOutOfBoundsException.
     */
    public static <$T>void asyncCopy__0$1x10$regionarray$Array$$T$2__2$1x10$regionarray$Array$$T$2(final x10.rtt.Type $T, final x10.regionarray.RemoteArray<$T> src, final x10.lang.Point srcPoint, final x10.regionarray.Array<$T> dst, final x10.lang.Point dstPoint, final long numElems) {
        
        //#line 1040 "x10/regionarray/Array.x10"
        final x10.core.GlobalRef gra = ((x10.core.GlobalRef)(((x10.regionarray.RemoteArray<$T>)src).array));
        
        //#line 1041 "x10/regionarray/Array.x10"
        final x10.lang.Place t$136665 = ((x10.lang.Place)((gra).home));
        
        //#line 1041 "x10/regionarray/Array.x10"
        final long srcIndex = x10.core.Long.$unbox(x10.xrx.Runtime.<x10.core.Long> evalAt__1$1x10$xrx$Runtime$$T$2$G(x10.rtt.Types.LONG, ((x10.lang.Place)(t$136665)), ((x10.core.fun.Fun_0_0)(new x10.regionarray.Array.$Closure$203<$T>($T, gra, srcPoint, (x10.regionarray.Array.$Closure$203.__0$1x10$regionarray$Array$1x10$regionarray$Array$$Closure$203$$T$2$2) null))), ((x10.xrx.Runtime.Profile)(null))));
        
        //#line 1042 "x10/regionarray/Array.x10"
        final x10.regionarray.Region t$141152 = ((x10.regionarray.Region)(((x10.regionarray.Array<$T>)dst).region));
        
        //#line 1042 "x10/regionarray/Array.x10"
        final long dstIndex$139725 = t$141152.indexOf$O(((x10.lang.Point)(dstPoint)));
        
        //#line 1084 . "x10/regionarray/Array.x10"
        final x10.lang.GlobalRail t$142914 = ((x10.lang.GlobalRail)(((x10.regionarray.RemoteArray<$T>)src).rawData));
        
        //#line 1084 . "x10/regionarray/Array.x10"
        final x10.core.Rail t$142915 = ((x10.core.Rail)(((x10.regionarray.Array<$T>)dst).raw));
        
        //#line 1084 . "x10/regionarray/Array.x10"
        x10.core.Rail.<$T> asyncCopy__0$1x10$lang$Rail$$T$2__2$1x10$lang$Rail$$T$2($T, ((x10.lang.GlobalRail)(t$142914)), (long)(srcIndex), ((x10.core.Rail)(t$142915)), (long)(dstIndex$139725), (long)(numElems));
    }
    
    
    //#line 1081 "x10/regionarray/Array.x10"
    /**
     * Asynchronously copy the specified values from the Array referenced by
     * the source RemoteArray to the specified portion of the destination Array.
     * The index arguments that are used to specify the start of the source
     * and destination regions are interpreted as of they were the result
     * of calling {@link Region#indexOf} on the Point that specifies the
     * start of the copy region.  Note that for Arrays that have the 
     * <code>rail</code> property, this exactly corresponds to the index
     * that would be used to access the element via apply or set.
     * If accessing any point in either the specified source or the 
     * specified destination range would in an ArrayIndexOutOfBoundsError
     * being raised, then this method will throw an IllegalArgumentException.<p>
     * 
     * The activity created to do the copying will be registered with the
     * dynamically enclosing finish.<p>
     * 
     * Warning: This method is only intended to be used on Arrays containing
     *   non-Object data elements.  The elements are actually copied via an
     *   optimized DMA operation if available.  Therefore object-references will
     *   not be properly transferred. Ideally, future versions of the X10 type
     *   system would enable this restriction to be checked statically.</p>
     * 
     * @param src the source array.
     * @param srcIndex the index of the first element in this array
     *        to be copied.  
     * @param dst the destination array.  May actually be local or remote
     * @param dstIndex the index of the first element in the destination
     *        array where copied data elements will be stored.
     * @param numElems the number of elements to be copied.
     * 
     * @see Region#indexOf
     * 
     * @throws IllegalArgumentException if the specified copy regions would 
     *         result in an ArrayIndexOutOfBoundsException.
     */
    public static <$T>void asyncCopy__0$1x10$regionarray$Array$$T$2__2$1x10$regionarray$Array$$T$2(final x10.rtt.Type $T, final x10.regionarray.RemoteArray<$T> src, final long srcIndex, final x10.regionarray.Array<$T> dst, final long dstIndex, final long numElems) {
        
        //#line 1084 "x10/regionarray/Array.x10"
        final x10.lang.GlobalRail t$141155 = ((x10.lang.GlobalRail)(((x10.regionarray.RemoteArray<$T>)src).rawData));
        
        //#line 1084 "x10/regionarray/Array.x10"
        final x10.core.Rail t$141156 = ((x10.core.Rail)(((x10.regionarray.Array<$T>)dst).raw));
        
        //#line 1084 "x10/regionarray/Array.x10"
        x10.core.Rail.<$T> asyncCopy__0$1x10$lang$Rail$$T$2__2$1x10$lang$Rail$$T$2($T, ((x10.lang.GlobalRail)(t$141155)), (long)(srcIndex), ((x10.core.Rail)(t$141156)), (long)(dstIndex), (long)(numElems));
    }
    
    
    //#line 1099 "x10/regionarray/Array.x10"
    /**
     * Copy all of the values from the source Array to the destination Array.
     * The two arrays must be defined over Regions with equal size 
     * bounding boxes; if the backing storage for the two arrays is 
     * not of equal size, then an IllegalArgumentExeption will be raised.<p>
     * 
     * @param src the source array.
     * @param dst the destination array.
     * @throws IllegalArgumentException if mismatch in size of backing storage
     *         of the two arrays.
     */
    public static <$T>void copy__0$1x10$regionarray$Array$$T$2__1$1x10$regionarray$Array$$T$2(final x10.rtt.Type $T, final x10.regionarray.Array<$T> src, final x10.regionarray.Array<$T> dst) {
        
        //#line 1100 "x10/regionarray/Array.x10"
        final x10.core.Rail t$141158 = ((x10.core.Rail)(((x10.regionarray.Array<$T>)src).raw));
        
        //#line 1100 "x10/regionarray/Array.x10"
        final x10.core.Rail t$141159 = ((x10.core.Rail)(((x10.regionarray.Array<$T>)dst).raw));
        
        //#line 1100 "x10/regionarray/Array.x10"
        final x10.core.Rail t$141157 = ((x10.core.Rail)(((x10.regionarray.Array<$T>)src).raw));
        
        //#line 1100 "x10/regionarray/Array.x10"
        final long t$141160 = ((x10.core.Rail<$T>)t$141157).size;
        
        //#line 1100 "x10/regionarray/Array.x10"
        x10.core.Rail.<$T> copy__0$1x10$lang$Rail$$T$2__2$1x10$lang$Rail$$T$2($T, ((x10.core.Rail)(t$141158)), (long)(0L), ((x10.core.Rail)(t$141159)), (long)(0L), (long)(t$141160));
    }
    
    
    //#line 1121 "x10/regionarray/Array.x10"
    /**
     * Copy the specified values from the source Array to the 
     * specified portion of the destination Array.
     * If accessing any point in either the specified source or the 
     * specified destination range would in an ArrayIndexOutOfBoundsError
     * being raised, then this method will throw an IllegalArgumentException.<p>
     * 
     * @param src the source array.
     * @param srcPoint the first element in this array to be copied.  
     * @param dst the destination array.  May actually be local or remote
     * @param dstPoint the first element in the destination
     *                 array where copied data elements will be stored.
     * @param numElems the number of elements to be copied.
     * 
     * @throws IllegalArgumentException if the specified copy regions would 
     *         result in an ArrayIndexOutOfBoundsException.
     */
    public static <$T>void copy__0$1x10$regionarray$Array$$T$2__2$1x10$regionarray$Array$$T$2(final x10.rtt.Type $T, final x10.regionarray.Array<$T> src, final x10.lang.Point srcPoint, final x10.regionarray.Array<$T> dst, final x10.lang.Point dstPoint, final long numElems) {
        
        //#line 1124 "x10/regionarray/Array.x10"
        final x10.regionarray.Region t$141161 = ((x10.regionarray.Region)(((x10.regionarray.Array<$T>)src).region));
        
        //#line 1124 "x10/regionarray/Array.x10"
        final long srcIndex$139729 = t$141161.indexOf$O(((x10.lang.Point)(srcPoint)));
        
        //#line 1124 "x10/regionarray/Array.x10"
        final x10.regionarray.Region t$141162 = ((x10.regionarray.Region)(((x10.regionarray.Array<$T>)dst).region));
        
        //#line 1124 "x10/regionarray/Array.x10"
        final long dstIndex$139731 = t$141162.indexOf$O(((x10.lang.Point)(dstPoint)));
        
        //#line 1157 . "x10/regionarray/Array.x10"
        final x10.core.Rail t$142916 = ((x10.core.Rail)(((x10.regionarray.Array<$T>)src).raw));
        
        //#line 1157 . "x10/regionarray/Array.x10"
        final x10.core.Rail t$142917 = ((x10.core.Rail)(((x10.regionarray.Array<$T>)dst).raw));
        
        //#line 1157 . "x10/regionarray/Array.x10"
        x10.core.Rail.<$T> copy__0$1x10$lang$Rail$$T$2__2$1x10$lang$Rail$$T$2($T, ((x10.core.Rail)(t$142916)), (long)(srcIndex$139729), ((x10.core.Rail)(t$142917)), (long)(dstIndex$139731), (long)(numElems));
    }
    
    
    //#line 1154 "x10/regionarray/Array.x10"
    /**
     * Copy the specified values from the source Array to the 
     * specified portion of the destination Array.
     * The index arguments that are used to specify the start of the source
     * and destination regions are interpreted as of they were the result
     * of calling {@link Region#indexOf} on the Point that specifies the
     * start of the copy region.  Note that for Arrays that have the 
     * <code>rail</code> property, this exactly corresponds to the index
     * that would be used to access the element via apply or set.
     * If accessing any point in either the specified source or the 
     * specified destination range would in an ArrayIndexOutOfBoundsError
     * being raised, then this method will throw an IllegalArgumentException.<p>
     * 
     * @param src the source array.
     * @param srcIndex the index of the first element in this array
     *        to be copied.  
     * @param dst the destination array.  May actually be local or remote
     * @param dstIndex the index of the first element in the destination
     *        array where copied data elements will be stored.
     * @param numElems the number of elements to be copied.
     * 
     * @see Region#indexOf
     * 
     * @throws IllegalArgumentException if the specified copy regions would 
     *         result in an ArrayIndexOutOfBoundsException.
     */
    public static <$T>void copy__0$1x10$regionarray$Array$$T$2__2$1x10$regionarray$Array$$T$2(final x10.rtt.Type $T, final x10.regionarray.Array<$T> src, final long srcIndex, final x10.regionarray.Array<$T> dst, final long dstIndex, final long numElems) {
        
        //#line 1157 "x10/regionarray/Array.x10"
        final x10.core.Rail t$141165 = ((x10.core.Rail)(((x10.regionarray.Array<$T>)src).raw));
        
        //#line 1157 "x10/regionarray/Array.x10"
        final x10.core.Rail t$141166 = ((x10.core.Rail)(((x10.regionarray.Array<$T>)dst).raw));
        
        //#line 1157 "x10/regionarray/Array.x10"
        x10.core.Rail.<$T> copy__0$1x10$lang$Rail$$T$2__2$1x10$lang$Rail$$T$2($T, ((x10.core.Rail)(t$141165)), (long)(srcIndex), ((x10.core.Rail)(t$141166)), (long)(dstIndex), (long)(numElems));
    }
    
    
    //#line 1174 "x10/regionarray/Array.x10"
    /**
     * Copy the specified region from the source Array to this array.
     * If the specified region is not contained in the region for the source
     * array or this array, then an ArrayIndexOutOfBoundsError is raised.
     * 
     * @param src the source array.
     * @param region the region of the array to copy to this array
     * 
     * @see Region#indexOf
     * 
     * @throws ArrayIndexOutOfBoundsException if the specified region is not
     *        contained in the source array or this array
     */
    public void copy__0$1x10$regionarray$Array$$T$2(final x10.regionarray.Array src, final x10.regionarray.Region r) {
        
        //#line 1176 "x10/regionarray/Array.x10"
        final x10.regionarray.Region t$143006 = ((x10.regionarray.Region)(((x10.regionarray.Array<$T>)src).region));
        
        //#line 1176 "x10/regionarray/Array.x10"
        final boolean t$143007 = t$143006.contains$O(((x10.regionarray.Region)(r)));
        
        //#line 1176 "x10/regionarray/Array.x10"
        final boolean t$143008 = !(t$143007);
        
        //#line 1176 "x10/regionarray/Array.x10"
        if (t$143008) {
            
            //#line 1177 "x10/regionarray/Array.x10"
            final java.lang.String t$143009 = (("region to copy: ") + (r));
            
            //#line 1177 "x10/regionarray/Array.x10"
            final java.lang.String t$143010 = ((t$143009) + (" not contained in source: "));
            
            //#line 1177 "x10/regionarray/Array.x10"
            final x10.regionarray.Region t$143011 = ((x10.regionarray.Region)(((x10.regionarray.Array<$T>)src).region));
            
            //#line 1177 "x10/regionarray/Array.x10"
            final java.lang.String t$143012 = ((t$143010) + (t$143011));
            
            //#line 1177 "x10/regionarray/Array.x10"
            final java.lang.ArrayIndexOutOfBoundsException t$143013 = ((java.lang.ArrayIndexOutOfBoundsException)(new java.lang.ArrayIndexOutOfBoundsException(t$143012)));
            
            //#line 1177 "x10/regionarray/Array.x10"
            throw t$143013;
        } else {
            
            //#line 1178 "x10/regionarray/Array.x10"
            final x10.regionarray.Region t$143014 = ((x10.regionarray.Region)(this.region));
            
            //#line 1178 "x10/regionarray/Array.x10"
            final boolean t$143015 = t$143014.contains$O(((x10.regionarray.Region)(r)));
            
            //#line 1178 "x10/regionarray/Array.x10"
            final boolean t$143016 = !(t$143015);
            
            //#line 1178 "x10/regionarray/Array.x10"
            if (t$143016) {
                
                //#line 1179 "x10/regionarray/Array.x10"
                final java.lang.String t$143017 = (("region to copy: ") + (r));
                
                //#line 1179 "x10/regionarray/Array.x10"
                final java.lang.String t$143018 = ((t$143017) + (" not contained in this array: "));
                
                //#line 1179 "x10/regionarray/Array.x10"
                final x10.regionarray.Region t$143019 = ((x10.regionarray.Region)(this.region));
                
                //#line 1179 "x10/regionarray/Array.x10"
                final java.lang.String t$143020 = ((t$143018) + (t$143019));
                
                //#line 1179 "x10/regionarray/Array.x10"
                final java.lang.ArrayIndexOutOfBoundsException t$143021 = ((java.lang.ArrayIndexOutOfBoundsException)(new java.lang.ArrayIndexOutOfBoundsException(t$143020)));
                
                //#line 1179 "x10/regionarray/Array.x10"
                throw t$143021;
            }
        }
        
        //#line 1182 "x10/regionarray/Array.x10"
        final long t$141183 = this.rank;
        
        //#line 1182 "x10/regionarray/Array.x10"
        boolean t$141184 = ((long) t$141183) == ((long) 3L);
        
        //#line 1182 "x10/regionarray/Array.x10"
        if (t$141184) {
            
            //#line 1182 "x10/regionarray/Array.x10"
            t$141184 = r.rect;
        }
        
        //#line 1182 "x10/regionarray/Array.x10"
        if (t$141184) {
            
            //#line 1183 "x10/regionarray/Array.x10"
            final x10.regionarray.Array t$137069 = ((x10.regionarray.Array<$T>)
                                                     this);
            
            //#line 1183 "x10/regionarray/Array.x10"
            final long t$141185 = ((x10.regionarray.Array<$T>)t$137069).rank;
            
            //#line 1183 "x10/regionarray/Array.x10"
            final boolean t$141186 = ((long) t$141185) == ((long) 3L);
            
            //#line 1183 "x10/regionarray/Array.x10"
            final boolean t$141188 = !(t$141186);
            
            //#line 1183 "x10/regionarray/Array.x10"
            if (t$141188) {
                
                //#line 1183 "x10/regionarray/Array.x10"
                final x10.lang.FailedDynamicCheckException t$141187 = new x10.lang.FailedDynamicCheckException("x10.regionarray.Array[T]{self.rank==3L}");
                
                //#line 1183 "x10/regionarray/Array.x10"
                throw t$141187;
            }
            
            //#line 1183 "x10/regionarray/Array.x10"
            final x10.regionarray.Array t$137071 = ((x10.regionarray.Array<$T>)
                                                     src);
            
            //#line 1183 "x10/regionarray/Array.x10"
            final long t$141189 = ((x10.regionarray.Array<$T>)t$137071).rank;
            
            //#line 1183 "x10/regionarray/Array.x10"
            final boolean t$141190 = ((long) t$141189) == ((long) 3L);
            
            //#line 1183 "x10/regionarray/Array.x10"
            final boolean t$141192 = !(t$141190);
            
            //#line 1183 "x10/regionarray/Array.x10"
            if (t$141192) {
                
                //#line 1183 "x10/regionarray/Array.x10"
                final x10.lang.FailedDynamicCheckException t$141191 = new x10.lang.FailedDynamicCheckException("x10.regionarray.Array[T]{self.rank==3L}");
                
                //#line 1183 "x10/regionarray/Array.x10"
                throw t$141191;
            }
            
            //#line 1183 "x10/regionarray/Array.x10"
            final x10.regionarray.Region t$137073 = ((x10.regionarray.Region)
                                                      r);
            
            //#line 1183 "x10/regionarray/Array.x10"
            final boolean t$141193 = t$137073.rect;
            
            //#line 1183 "x10/regionarray/Array.x10"
            boolean t$141195 = ((boolean) t$141193) == ((boolean) true);
            
            //#line 1183 "x10/regionarray/Array.x10"
            if (t$141195) {
                
                //#line 1183 "x10/regionarray/Array.x10"
                final long t$141194 = t$137073.rank;
                
                //#line 1183 "x10/regionarray/Array.x10"
                t$141195 = ((long) t$141194) == ((long) 3L);
            }
            
            //#line 1183 "x10/regionarray/Array.x10"
            final boolean t$141198 = !(t$141195);
            
            //#line 1183 "x10/regionarray/Array.x10"
            if (t$141198) {
                
                //#line 1183 "x10/regionarray/Array.x10"
                final x10.lang.FailedDynamicCheckException t$141197 = new x10.lang.FailedDynamicCheckException("x10.regionarray.Region{self.rect==true, self.rank==3L}");
                
                //#line 1183 "x10/regionarray/Array.x10"
                throw t$141197;
            }
            
            //#line 1183 "x10/regionarray/Array.x10"
            ((x10.regionarray.Array<$T>)t$137069).copy3__0$1x10$regionarray$Array$$T$2(((x10.regionarray.Array)(t$137071)), ((x10.regionarray.Region)(t$137073)));
            
            //#line 1184 "x10/regionarray/Array.x10"
            return;
        }
        
        //#line 1187 "x10/regionarray/Array.x10"
        final x10.core.Rail srcRaw = ((x10.core.Rail)(((x10.regionarray.Array<$T>)src).raw));
        
        //#line 1188 "x10/regionarray/Array.x10"
        final x10.regionarray.Region t$141200 = ((x10.regionarray.Region)(this.region));
        
        //#line 1188 "x10/regionarray/Array.x10"
        final x10.regionarray.Region t$141201 = ((x10.regionarray.Region)(((x10.regionarray.Array<$T>)src).region));
        
        //#line 1188 "x10/regionarray/Array.x10"
        final boolean t$141275 = x10.rtt.Equality.equalsequals((t$141200),(t$141201));
        
        //#line 1188 "x10/regionarray/Array.x10"
        if (t$141275) {
            
            //#line 1190 "x10/regionarray/Array.x10"
            final x10.lang.Iterator p$138638 = r.iterator();
            
            //#line 1190 "x10/regionarray/Array.x10"
            for (;
                 true;
                 ) {
                
                //#line 1190 "x10/regionarray/Array.x10"
                final boolean t$141206 = ((x10.lang.Iterator<x10.lang.Point>)p$138638).hasNext$O();
                
                //#line 1190 "x10/regionarray/Array.x10"
                if (!(t$141206)) {
                    
                    //#line 1190 "x10/regionarray/Array.x10"
                    break;
                }
                
                //#line 1190 "x10/regionarray/Array.x10"
                final x10.lang.Point p$142918 = ((x10.lang.Point)(((x10.lang.Iterator<x10.lang.Point>)p$138638).next$G()));
                
                //#line 1191 "x10/regionarray/Array.x10"
                final x10.regionarray.Region t$142919 = ((x10.regionarray.Region)(this.region));
                
                //#line 1191 "x10/regionarray/Array.x10"
                final long offset$142920 = t$142919.indexOf$O(((x10.lang.Point)(p$142918)));
                
                //#line 1192 "x10/regionarray/Array.x10"
                final x10.core.Rail t$142921 = ((x10.core.Rail)(this.raw));
                
                //#line 1192 "x10/regionarray/Array.x10"
                final $T t$142922 = (($T)(((x10.core.Rail<$T>)srcRaw).$apply$G((long)(offset$142920))));
                
                //#line 1192 "x10/regionarray/Array.x10"
                ((x10.core.Rail<$T>)t$142921).$set__1x10$lang$Rail$$T$G((long)(offset$142920), (($T)(t$142922)));
            }
        } else {
            
            //#line 1196 "x10/regionarray/Array.x10"
            final x10.regionarray.Region t$141207 = ((x10.regionarray.Region)(this.region));
            
            //#line 1196 "x10/regionarray/Array.x10"
            final x10.core.fun.Fun_0_1 min = t$141207.min();
            
            //#line 1197 "x10/regionarray/Array.x10"
            final x10.regionarray.Region t$141208 = ((x10.regionarray.Region)(this.region));
            
            //#line 1197 "x10/regionarray/Array.x10"
            t$141208.max();
            
            //#line 1198 "x10/regionarray/Array.x10"
            final x10.regionarray.Array delta = ((x10.regionarray.Array)(new x10.regionarray.Array<x10.core.Long>((java.lang.System[]) null, x10.rtt.Types.LONG)));
            
            //#line 1198 "x10/regionarray/Array.x10"
            final long size$139734 = this.rank;
            
            //#line 314 . "x10/regionarray/Array.x10"
            final x10.regionarray.RectRegion1D myReg$142996 = ((x10.regionarray.RectRegion1D)(new x10.regionarray.RectRegion1D((java.lang.System[]) null)));
            
            //#line 314 . "x10/regionarray/Array.x10"
            final long t$142936 = ((size$139734) - (((long)(1L))));
            
            //#line 314 . "x10/regionarray/Array.x10"
            myReg$142996.x10$regionarray$RectRegion1D$$init$S(t$142936);
            
            //#line 315 . "x10/regionarray/Array.x10"
            final x10.regionarray.Region t$142937 = ((x10.regionarray.Region)
                                                      myReg$142996);
            
            //#line 315 . "x10/regionarray/Array.x10"
            ((x10.regionarray.Array<x10.core.Long>)delta).region = ((x10.regionarray.Region)(t$142937));
            
            //#line 315 . "x10/regionarray/Array.x10"
            ((x10.regionarray.Array<x10.core.Long>)delta).rank = 1L;
            
            //#line 315 . "x10/regionarray/Array.x10"
            ((x10.regionarray.Array<x10.core.Long>)delta).rect = true;
            
            //#line 315 . "x10/regionarray/Array.x10"
            ((x10.regionarray.Array<x10.core.Long>)delta).zeroBased = true;
            
            //#line 315 . "x10/regionarray/Array.x10"
            ((x10.regionarray.Array<x10.core.Long>)delta).rail = true;
            
            //#line 315 . "x10/regionarray/Array.x10"
            ((x10.regionarray.Array<x10.core.Long>)delta).size = size$139734;
            
            //#line 317 . "x10/regionarray/Array.x10"
            final long t$142997 = ((x10.regionarray.Array<x10.core.Long>)delta).layout_min1 = 0L;
            
            //#line 317 . "x10/regionarray/Array.x10"
            final long t$142998 = ((x10.regionarray.Array<x10.core.Long>)delta).layout_stride1 = t$142997;
            
            //#line 317 . "x10/regionarray/Array.x10"
            ((x10.regionarray.Array<x10.core.Long>)delta).layout_min0 = t$142998;
            
            //#line 318 . "x10/regionarray/Array.x10"
            ((x10.regionarray.Array<x10.core.Long>)delta).layout = null;
            
            //#line 319 . "x10/regionarray/Array.x10"
            final x10.core.Rail r$142999 = ((x10.core.Rail)(x10.core.Rail.<x10.core.Long>makeUnsafe(x10.rtt.Types.LONG, ((long)(size$139734)), false)));
            
            //#line 320 . "x10/regionarray/Array.x10"
            final long i$138570max$142938 = ((size$139734) - (((long)(1L))));
            
            //#line 320 . "x10/regionarray/Array.x10"
            long i$142933 = 0L;
            {
                
                //#line 320 . "x10/regionarray/Array.x10"
                final long[] r$142999$value$143165 = ((long[])r$142999.value);
                
                //#line 320 . "x10/regionarray/Array.x10"
                for (;
                     true;
                     ) {
                    
                    //#line 320 . "x10/regionarray/Array.x10"
                    final boolean t$142935 = ((i$142933) <= (((long)(i$138570max$142938))));
                    
                    //#line 320 . "x10/regionarray/Array.x10"
                    if (!(t$142935)) {
                        
                        //#line 320 . "x10/regionarray/Array.x10"
                        break;
                    }
                    
                    //#line 1198 .. "x10/regionarray/Array.x10"
                    final x10.regionarray.Region t$142924 = ((x10.regionarray.Region)(this.region));
                    
                    //#line 1198 .. "x10/regionarray/Array.x10"
                    final long t$142925 = t$142924.max$O((long)(i$142933));
                    
                    //#line 1198 .. "x10/regionarray/Array.x10"
                    final x10.regionarray.Region t$142926 = ((x10.regionarray.Region)(this.region));
                    
                    //#line 1198 .. "x10/regionarray/Array.x10"
                    final long t$142927 = t$142926.min$O((long)(i$142933));
                    
                    //#line 1198 .. "x10/regionarray/Array.x10"
                    final long t$142928 = ((t$142925) - (((long)(t$142927))));
                    
                    //#line 1198 .. "x10/regionarray/Array.x10"
                    final long t$142929 = ((t$142928) + (((long)(1L))));
                    
                    //#line 321 . "x10/regionarray/Array.x10"
                    r$142999$value$143165[(int)i$142933]=t$142929;
                    
                    //#line 320 . "x10/regionarray/Array.x10"
                    final long t$142932 = ((i$142933) + (((long)(1L))));
                    
                    //#line 320 . "x10/regionarray/Array.x10"
                    i$142933 = t$142932;
                }
            }
            
            //#line 323 . "x10/regionarray/Array.x10"
            ((x10.regionarray.Array<x10.core.Long>)delta).raw = ((x10.core.Rail)(r$142999));
            
            //#line 1199 "x10/regionarray/Array.x10"
            final x10.regionarray.Region t$141224 = ((x10.regionarray.Region)(((x10.regionarray.Array<$T>)src).region));
            
            //#line 1199 "x10/regionarray/Array.x10"
            final x10.core.fun.Fun_0_1 srcMin = t$141224.min();
            
            //#line 1200 "x10/regionarray/Array.x10"
            final x10.regionarray.Region t$141225 = ((x10.regionarray.Region)(((x10.regionarray.Array<$T>)src).region));
            
            //#line 1200 "x10/regionarray/Array.x10"
            t$141225.max();
            
            //#line 1201 "x10/regionarray/Array.x10"
            final x10.regionarray.Array srcDelta = ((x10.regionarray.Array)(new x10.regionarray.Array<x10.core.Long>((java.lang.System[]) null, x10.rtt.Types.LONG)));
            
            //#line 1201 "x10/regionarray/Array.x10"
            final long size$139746 = this.rank;
            
            //#line 314 . "x10/regionarray/Array.x10"
            final x10.regionarray.RectRegion1D myReg$143000 = ((x10.regionarray.RectRegion1D)(new x10.regionarray.RectRegion1D((java.lang.System[]) null)));
            
            //#line 314 . "x10/regionarray/Array.x10"
            final long t$142952 = ((size$139746) - (((long)(1L))));
            
            //#line 314 . "x10/regionarray/Array.x10"
            myReg$143000.x10$regionarray$RectRegion1D$$init$S(t$142952);
            
            //#line 315 . "x10/regionarray/Array.x10"
            final x10.regionarray.Region t$142953 = ((x10.regionarray.Region)
                                                      myReg$143000);
            
            //#line 315 . "x10/regionarray/Array.x10"
            ((x10.regionarray.Array<x10.core.Long>)srcDelta).region = ((x10.regionarray.Region)(t$142953));
            
            //#line 315 . "x10/regionarray/Array.x10"
            ((x10.regionarray.Array<x10.core.Long>)srcDelta).rank = 1L;
            
            //#line 315 . "x10/regionarray/Array.x10"
            ((x10.regionarray.Array<x10.core.Long>)srcDelta).rect = true;
            
            //#line 315 . "x10/regionarray/Array.x10"
            ((x10.regionarray.Array<x10.core.Long>)srcDelta).zeroBased = true;
            
            //#line 315 . "x10/regionarray/Array.x10"
            ((x10.regionarray.Array<x10.core.Long>)srcDelta).rail = true;
            
            //#line 315 . "x10/regionarray/Array.x10"
            ((x10.regionarray.Array<x10.core.Long>)srcDelta).size = size$139746;
            
            //#line 317 . "x10/regionarray/Array.x10"
            final long t$143001 = ((x10.regionarray.Array<x10.core.Long>)srcDelta).layout_min1 = 0L;
            
            //#line 317 . "x10/regionarray/Array.x10"
            final long t$143002 = ((x10.regionarray.Array<x10.core.Long>)srcDelta).layout_stride1 = t$143001;
            
            //#line 317 . "x10/regionarray/Array.x10"
            ((x10.regionarray.Array<x10.core.Long>)srcDelta).layout_min0 = t$143002;
            
            //#line 318 . "x10/regionarray/Array.x10"
            ((x10.regionarray.Array<x10.core.Long>)srcDelta).layout = null;
            
            //#line 319 . "x10/regionarray/Array.x10"
            final x10.core.Rail r$143003 = ((x10.core.Rail)(x10.core.Rail.<x10.core.Long>makeUnsafe(x10.rtt.Types.LONG, ((long)(size$139746)), false)));
            
            //#line 320 . "x10/regionarray/Array.x10"
            final long i$138570max$142954 = ((size$139746) - (((long)(1L))));
            
            //#line 320 . "x10/regionarray/Array.x10"
            long i$142949 = 0L;
            {
                
                //#line 320 . "x10/regionarray/Array.x10"
                final long[] r$143003$value$143166 = ((long[])r$143003.value);
                
                //#line 320 . "x10/regionarray/Array.x10"
                for (;
                     true;
                     ) {
                    
                    //#line 320 . "x10/regionarray/Array.x10"
                    final boolean t$142951 = ((i$142949) <= (((long)(i$138570max$142954))));
                    
                    //#line 320 . "x10/regionarray/Array.x10"
                    if (!(t$142951)) {
                        
                        //#line 320 . "x10/regionarray/Array.x10"
                        break;
                    }
                    
                    //#line 1201 .. "x10/regionarray/Array.x10"
                    final x10.regionarray.Region t$142940 = ((x10.regionarray.Region)(((x10.regionarray.Array<$T>)src).region));
                    
                    //#line 1201 .. "x10/regionarray/Array.x10"
                    final long t$142941 = t$142940.max$O((long)(i$142949));
                    
                    //#line 1201 .. "x10/regionarray/Array.x10"
                    final x10.regionarray.Region t$142942 = ((x10.regionarray.Region)(((x10.regionarray.Array<$T>)src).region));
                    
                    //#line 1201 .. "x10/regionarray/Array.x10"
                    final long t$142943 = t$142942.min$O((long)(i$142949));
                    
                    //#line 1201 .. "x10/regionarray/Array.x10"
                    final long t$142944 = ((t$142941) - (((long)(t$142943))));
                    
                    //#line 1201 .. "x10/regionarray/Array.x10"
                    final long t$142945 = ((t$142944) + (((long)(1L))));
                    
                    //#line 321 . "x10/regionarray/Array.x10"
                    r$143003$value$143166[(int)i$142949]=t$142945;
                    
                    //#line 320 . "x10/regionarray/Array.x10"
                    final long t$142948 = ((i$142949) + (((long)(1L))));
                    
                    //#line 320 . "x10/regionarray/Array.x10"
                    i$142949 = t$142948;
                }
            }
            
            //#line 323 . "x10/regionarray/Array.x10"
            ((x10.regionarray.Array<x10.core.Long>)srcDelta).raw = ((x10.core.Rail)(r$143003));
            
            //#line 1202 "x10/regionarray/Array.x10"
            final x10.lang.Iterator p$143004 = r.iterator();
            
            //#line 1202 "x10/regionarray/Array.x10"
            for (;
                 true;
                 ) {
                
                //#line 1202 "x10/regionarray/Array.x10"
                final boolean t$143005 = ((x10.lang.Iterator<x10.lang.Point>)p$143004).hasNext$O();
                
                //#line 1202 "x10/regionarray/Array.x10"
                if (!(t$143005)) {
                    
                    //#line 1202 "x10/regionarray/Array.x10"
                    break;
                }
                
                //#line 1202 "x10/regionarray/Array.x10"
                final x10.lang.Point p$142985 = ((x10.lang.Point)(((x10.lang.Iterator<x10.lang.Point>)p$143004).next$G()));
                
                //#line 1203 "x10/regionarray/Array.x10"
                final long t$142986 = p$142985.$apply$O((long)(0L));
                
                //#line 1203 "x10/regionarray/Array.x10"
                final long t$142987 = x10.core.Long.$unbox(((x10.core.fun.Fun_0_1<x10.core.Long,x10.core.Long>)min).$apply(x10.core.Long.$box(0L), x10.rtt.Types.LONG));
                
                //#line 1203 "x10/regionarray/Array.x10"
                long offset$142988 = ((t$142986) - (((long)(t$142987))));
                
                //#line 1204 "x10/regionarray/Array.x10"
                final long t$142989 = p$142985.$apply$O((long)(0L));
                
                //#line 1204 "x10/regionarray/Array.x10"
                final long t$142990 = x10.core.Long.$unbox(((x10.core.fun.Fun_0_1<x10.core.Long,x10.core.Long>)srcMin).$apply(x10.core.Long.$box(0L), x10.rtt.Types.LONG));
                
                //#line 1204 "x10/regionarray/Array.x10"
                long srcOffset$142991 = ((t$142989) - (((long)(t$142990))));
                
                //#line 1205 "x10/regionarray/Array.x10"
                final long t$142983 = this.rank;
                
                //#line 1205 "x10/regionarray/Array.x10"
                final long i$138640max$142984 = ((t$142983) - (((long)(1L))));
                
                //#line 1205 "x10/regionarray/Array.x10"
                long i$142980 = 1L;
                
                //#line 1205 "x10/regionarray/Array.x10"
                for (;
                     true;
                     ) {
                    
                    //#line 1205 "x10/regionarray/Array.x10"
                    final boolean t$142982 = ((i$142980) <= (((long)(i$138640max$142984))));
                    
                    //#line 1205 "x10/regionarray/Array.x10"
                    if (!(t$142982)) {
                        
                        //#line 1205 "x10/regionarray/Array.x10"
                        break;
                    }
                    
                    //#line 442 . "x10/regionarray/Array.x10"
                    long ret$142961 =  0;
                    
                    //#line 446 . "x10/regionarray/Array.x10"
                    final x10.core.Rail t$142955 = ((x10.core.Rail)(((x10.regionarray.Array<x10.core.Long>)delta).raw));
                    
                    //#line 446 . "x10/regionarray/Array.x10"
                    final long t$142956 = ((long[])t$142955.value)[(int)i$142980];
                    
                    //#line 446 . "x10/regionarray/Array.x10"
                    ret$142961 = t$142956;
                    
                    //#line 1206 "x10/regionarray/Array.x10"
                    final long t$142963 = ((offset$142988) * (((long)(ret$142961))));
                    
                    //#line 1206 "x10/regionarray/Array.x10"
                    final long t$142964 = p$142985.$apply$O((long)(i$142980));
                    
                    //#line 1206 "x10/regionarray/Array.x10"
                    final long t$142965 = ((t$142963) + (((long)(t$142964))));
                    
                    //#line 1206 "x10/regionarray/Array.x10"
                    final long t$142966 = x10.core.Long.$unbox(((x10.core.fun.Fun_0_1<x10.core.Long,x10.core.Long>)min).$apply(x10.core.Long.$box(i$142980), x10.rtt.Types.LONG));
                    
                    //#line 1206 "x10/regionarray/Array.x10"
                    final long t$142967 = ((t$142965) - (((long)(t$142966))));
                    
                    //#line 1206 "x10/regionarray/Array.x10"
                    offset$142988 = t$142967;
                    
                    //#line 442 . "x10/regionarray/Array.x10"
                    long ret$142970 =  0;
                    
                    //#line 446 . "x10/regionarray/Array.x10"
                    final x10.core.Rail t$142957 = ((x10.core.Rail)(((x10.regionarray.Array<x10.core.Long>)srcDelta).raw));
                    
                    //#line 446 . "x10/regionarray/Array.x10"
                    final long t$142958 = ((long[])t$142957.value)[(int)i$142980];
                    
                    //#line 446 . "x10/regionarray/Array.x10"
                    ret$142970 = t$142958;
                    
                    //#line 1207 "x10/regionarray/Array.x10"
                    final long t$142972 = ((srcOffset$142991) * (((long)(ret$142970))));
                    
                    //#line 1207 "x10/regionarray/Array.x10"
                    final long t$142973 = p$142985.$apply$O((long)(i$142980));
                    
                    //#line 1207 "x10/regionarray/Array.x10"
                    final long t$142974 = ((t$142972) + (((long)(t$142973))));
                    
                    //#line 1207 "x10/regionarray/Array.x10"
                    final long t$142975 = x10.core.Long.$unbox(((x10.core.fun.Fun_0_1<x10.core.Long,x10.core.Long>)srcMin).$apply(x10.core.Long.$box(i$142980), x10.rtt.Types.LONG));
                    
                    //#line 1207 "x10/regionarray/Array.x10"
                    final long t$142976 = ((t$142974) - (((long)(t$142975))));
                    
                    //#line 1207 "x10/regionarray/Array.x10"
                    srcOffset$142991 = t$142976;
                    
                    //#line 1205 "x10/regionarray/Array.x10"
                    final long t$142979 = ((i$142980) + (((long)(1L))));
                    
                    //#line 1205 "x10/regionarray/Array.x10"
                    i$142980 = t$142979;
                }
                
                //#line 1209 "x10/regionarray/Array.x10"
                final x10.core.Rail t$142992 = ((x10.core.Rail)(this.raw));
                
                //#line 1209 "x10/regionarray/Array.x10"
                final $T t$142995 = (($T)(((x10.core.Rail<$T>)srcRaw).$apply$G((long)(srcOffset$142991))));
                
                //#line 1209 "x10/regionarray/Array.x10"
                ((x10.core.Rail<$T>)t$142992).$set__1x10$lang$Rail$$T$G((long)(offset$142988), (($T)(t$142995)));
            }
        }
    }
    
    
    //#line 1214 "x10/regionarray/Array.x10"
    private void copy3__0$1x10$regionarray$Array$$T$2(final x10.regionarray.Array src, final x10.regionarray.Region r) {
        
        //#line 1215 "x10/regionarray/Array.x10"
        final x10.core.Rail srcRaw = ((x10.core.Rail)(((x10.regionarray.Array<$T>)src).raw));
        
        //#line 1216 "x10/regionarray/Array.x10"
        final x10.regionarray.Region t$141277 = ((x10.regionarray.Region)(this.region));
        
        //#line 1216 "x10/regionarray/Array.x10"
        final x10.regionarray.Region t$141278 = ((x10.regionarray.Region)(((x10.regionarray.Array<$T>)src).region));
        
        //#line 1216 "x10/regionarray/Array.x10"
        final boolean t$141333 = x10.rtt.Equality.equalsequals((t$141277),(t$141278));
        
        //#line 1216 "x10/regionarray/Array.x10"
        if (t$141333) {
            
            //#line 1218 "x10/regionarray/Array.x10"
            final long k$138661min$138662 = r.min$O((long)(2L));
            
            //#line 1218 "x10/regionarray/Array.x10"
            final long k$138661max$138663 = r.max$O((long)(2L));
            
            //#line 1218 "x10/regionarray/Array.x10"
            final long j$138680min$138681 = r.min$O((long)(1L));
            
            //#line 1218 "x10/regionarray/Array.x10"
            final long j$138680max$138682 = r.max$O((long)(1L));
            
            //#line 1218 "x10/regionarray/Array.x10"
            final long i$138699min$138700 = r.min$O((long)(0L));
            
            //#line 1218 "x10/regionarray/Array.x10"
            final long i$138699max$138701 = r.max$O((long)(0L));
            
            //#line 1218 "x10/regionarray/Array.x10"
            long i$143043 = i$138699min$138700;
            
            //#line 1218 "x10/regionarray/Array.x10"
            for (;
                 true;
                 ) {
                
                //#line 1218 "x10/regionarray/Array.x10"
                final boolean t$143045 = ((i$143043) <= (((long)(i$138699max$138701))));
                
                //#line 1218 "x10/regionarray/Array.x10"
                if (!(t$143045)) {
                    
                    //#line 1218 "x10/regionarray/Array.x10"
                    break;
                }
                
                //#line 1218 "x10/regionarray/Array.x10"
                long j$143037 = j$138680min$138681;
                
                //#line 1218 "x10/regionarray/Array.x10"
                for (;
                     true;
                     ) {
                    
                    //#line 1218 "x10/regionarray/Array.x10"
                    final boolean t$143039 = ((j$143037) <= (((long)(j$138680max$138682))));
                    
                    //#line 1218 "x10/regionarray/Array.x10"
                    if (!(t$143039)) {
                        
                        //#line 1218 "x10/regionarray/Array.x10"
                        break;
                    }
                    
                    //#line 1218 "x10/regionarray/Array.x10"
                    long k$143031 = k$138661min$138662;
                    
                    //#line 1218 "x10/regionarray/Array.x10"
                    for (;
                         true;
                         ) {
                        
                        //#line 1218 "x10/regionarray/Array.x10"
                        final boolean t$143033 = ((k$143031) <= (((long)(k$138661max$138663))));
                        
                        //#line 1218 "x10/regionarray/Array.x10"
                        if (!(t$143033)) {
                            
                            //#line 1218 "x10/regionarray/Array.x10"
                            break;
                        }
                        
                        //#line 1219 "x10/regionarray/Array.x10"
                        final x10.regionarray.Region t$143022 = ((x10.regionarray.Region)(this.region));
                        
                        //#line 1219 "x10/regionarray/Array.x10"
                        final x10.core.Rail r$143023 = ((x10.core.Rail)(x10.runtime.impl.java.ArrayUtils.<x10.core.Long> makeRailFromJavaArray(x10.rtt.Types.LONG, new long[] {i$143043, j$143037, k$143031})));
                        
                        //#line 162 . "x10/lang/Point.x10"
                        final x10.lang.Point t$143024 = ((x10.lang.Point)(x10.lang.Point.make__0$1x10$lang$Long$2(((x10.core.Rail)(r$143023)))));
                        
                        //#line 1219 "x10/regionarray/Array.x10"
                        final long offset$143025 = t$143022.indexOf$O(((x10.lang.Point)(t$143024)));
                        
                        //#line 1220 "x10/regionarray/Array.x10"
                        final x10.core.Rail t$143026 = ((x10.core.Rail)(this.raw));
                        
                        //#line 1220 "x10/regionarray/Array.x10"
                        final $T t$143027 = (($T)(((x10.core.Rail<$T>)srcRaw).$apply$G((long)(offset$143025))));
                        
                        //#line 1220 "x10/regionarray/Array.x10"
                        ((x10.core.Rail<$T>)t$143026).$set__1x10$lang$Rail$$T$G((long)(offset$143025), (($T)(t$143027)));
                        
                        //#line 1218 "x10/regionarray/Array.x10"
                        final long t$143030 = ((k$143031) + (((long)(1L))));
                        
                        //#line 1218 "x10/regionarray/Array.x10"
                        k$143031 = t$143030;
                    }
                    
                    //#line 1218 "x10/regionarray/Array.x10"
                    final long t$143036 = ((j$143037) + (((long)(1L))));
                    
                    //#line 1218 "x10/regionarray/Array.x10"
                    j$143037 = t$143036;
                }
                
                //#line 1218 "x10/regionarray/Array.x10"
                final long t$143042 = ((i$143043) + (((long)(1L))));
                
                //#line 1218 "x10/regionarray/Array.x10"
                i$143043 = t$143042;
            }
        } else {
            
            //#line 1223 "x10/regionarray/Array.x10"
            final x10.core.Rail t$141298 = ((x10.core.Rail)(this.layout));
            
            //#line 1223 "x10/regionarray/Array.x10"
            final long layout_stride2 = ((long[])t$141298.value)[(int)0L];
            
            //#line 1224 "x10/regionarray/Array.x10"
            final x10.core.Rail t$141299 = ((x10.core.Rail)(this.layout));
            
            //#line 1224 "x10/regionarray/Array.x10"
            final long layout_stride3 = ((long[])t$141299.value)[(int)1L];
            
            //#line 1226 "x10/regionarray/Array.x10"
            final x10.regionarray.Array.LayoutHelper crh = new x10.regionarray.Array.LayoutHelper((java.lang.System[]) null);
            
            //#line 1226 "x10/regionarray/Array.x10"
            final x10.regionarray.Region t$143087 = ((x10.regionarray.Region)(((x10.regionarray.Array<$T>)src).region));
            
            //#line 1226 "x10/regionarray/Array.x10"
            crh.x10$regionarray$Array$LayoutHelper$$init$S(((x10.regionarray.Region)(t$143087)));
            
            //#line 1227 "x10/regionarray/Array.x10"
            final long src_min0 = crh.min0;
            
            //#line 1228 "x10/regionarray/Array.x10"
            final x10.regionarray.Region t$141301 = ((x10.regionarray.Region)(((x10.regionarray.Array<$T>)src).region));
            
            //#line 1228 "x10/regionarray/Array.x10"
            final long src_max0 = t$141301.max$O((long)(0L));
            
            //#line 1229 "x10/regionarray/Array.x10"
            final long src_stride1 = crh.stride1;
            
            //#line 1230 "x10/regionarray/Array.x10"
            final long src_min1 = crh.min1;
            
            //#line 1231 "x10/regionarray/Array.x10"
            final x10.regionarray.Region t$141302 = ((x10.regionarray.Region)(((x10.regionarray.Array<$T>)src).region));
            
            //#line 1231 "x10/regionarray/Array.x10"
            final long src_max1 = t$141302.max$O((long)(1L));
            
            //#line 1232 "x10/regionarray/Array.x10"
            final x10.core.Rail src_layout = ((x10.core.Rail)(crh.layout));
            
            //#line 1233 "x10/regionarray/Array.x10"
            final long src_stride2 = ((long[])src_layout.value)[(int)0L];
            
            //#line 1234 "x10/regionarray/Array.x10"
            final long src_stride3 = ((long[])src_layout.value)[(int)1L];
            
            //#line 1235 "x10/regionarray/Array.x10"
            final x10.regionarray.Region t$141303 = ((x10.regionarray.Region)(((x10.regionarray.Array<$T>)src).region));
            
            //#line 1235 "x10/regionarray/Array.x10"
            final long src_min2 = t$141303.min$O((long)(2L));
            
            //#line 1236 "x10/regionarray/Array.x10"
            final x10.regionarray.Region t$141304 = ((x10.regionarray.Region)(((x10.regionarray.Array<$T>)src).region));
            
            //#line 1236 "x10/regionarray/Array.x10"
            final long src_max2 = t$141304.max$O((long)(2L));
            
            //#line 1238 "x10/regionarray/Array.x10"
            long i$143084 = src_min0;
            
            //#line 1238 "x10/regionarray/Array.x10"
            for (;
                 true;
                 ) {
                
                //#line 1238 "x10/regionarray/Array.x10"
                final boolean t$143086 = ((i$143084) <= (((long)(src_max0))));
                
                //#line 1238 "x10/regionarray/Array.x10"
                if (!(t$143086)) {
                    
                    //#line 1238 "x10/regionarray/Array.x10"
                    break;
                }
                
                //#line 1239 "x10/regionarray/Array.x10"
                final long t$143075 = this.layout_min0;
                
                //#line 1239 "x10/regionarray/Array.x10"
                final long t$143076 = ((i$143084) - (((long)(t$143075))));
                
                //#line 1239 "x10/regionarray/Array.x10"
                final long t$143077 = this.layout_stride1;
                
                //#line 1239 "x10/regionarray/Array.x10"
                final long offset$143078 = ((t$143076) * (((long)(t$143077))));
                
                //#line 1240 "x10/regionarray/Array.x10"
                final long t$143079 = ((i$143084) - (((long)(src_min0))));
                
                //#line 1240 "x10/regionarray/Array.x10"
                final long srcOffset$143080 = ((t$143079) * (((long)(src_stride1))));
                
                //#line 1241 "x10/regionarray/Array.x10"
                long i$143070 = src_min1;
                
                //#line 1241 "x10/regionarray/Array.x10"
                for (;
                     true;
                     ) {
                    
                    //#line 1241 "x10/regionarray/Array.x10"
                    final boolean t$143072 = ((i$143070) <= (((long)(src_max1))));
                    
                    //#line 1241 "x10/regionarray/Array.x10"
                    if (!(t$143072)) {
                        
                        //#line 1241 "x10/regionarray/Array.x10"
                        break;
                    }
                    
                    //#line 1242 "x10/regionarray/Array.x10"
                    final long t$143060 = ((offset$143078) + (((long)(i$143070))));
                    
                    //#line 1242 "x10/regionarray/Array.x10"
                    final long t$143061 = this.layout_min1;
                    
                    //#line 1242 "x10/regionarray/Array.x10"
                    final long t$143062 = ((t$143060) - (((long)(t$143061))));
                    
                    //#line 1242 "x10/regionarray/Array.x10"
                    final long offset$143063 = ((t$143062) * (((long)(layout_stride2))));
                    
                    //#line 1243 "x10/regionarray/Array.x10"
                    final long t$143064 = ((srcOffset$143080) + (((long)(i$143070))));
                    
                    //#line 1243 "x10/regionarray/Array.x10"
                    final long t$143065 = ((t$143064) - (((long)(src_min1))));
                    
                    //#line 1243 "x10/regionarray/Array.x10"
                    final long srcOffset$143066 = ((t$143065) * (((long)(src_stride2))));
                    
                    //#line 1244 "x10/regionarray/Array.x10"
                    long i$143055 = src_min2;
                    
                    //#line 1244 "x10/regionarray/Array.x10"
                    for (;
                         true;
                         ) {
                        
                        //#line 1244 "x10/regionarray/Array.x10"
                        final boolean t$143057 = ((i$143055) <= (((long)(src_max2))));
                        
                        //#line 1244 "x10/regionarray/Array.x10"
                        if (!(t$143057)) {
                            
                            //#line 1244 "x10/regionarray/Array.x10"
                            break;
                        }
                        
                        //#line 1245 "x10/regionarray/Array.x10"
                        final long t$143046 = ((offset$143063) + (((long)(i$143055))));
                        
                        //#line 1245 "x10/regionarray/Array.x10"
                        final long offset$143047 = ((t$143046) - (((long)(layout_stride3))));
                        
                        //#line 1246 "x10/regionarray/Array.x10"
                        final long t$143048 = ((srcOffset$143066) + (((long)(i$143055))));
                        
                        //#line 1246 "x10/regionarray/Array.x10"
                        final long srcOffset$143049 = ((t$143048) - (((long)(src_stride3))));
                        
                        //#line 1247 "x10/regionarray/Array.x10"
                        final x10.core.Rail t$143050 = ((x10.core.Rail)(this.raw));
                        
                        //#line 1247 "x10/regionarray/Array.x10"
                        final $T t$143051 = (($T)(((x10.core.Rail<$T>)srcRaw).$apply$G((long)(srcOffset$143049))));
                        
                        //#line 1247 "x10/regionarray/Array.x10"
                        ((x10.core.Rail<$T>)t$143050).$set__1x10$lang$Rail$$T$G((long)(offset$143047), (($T)(t$143051)));
                        
                        //#line 1244 "x10/regionarray/Array.x10"
                        final long t$143054 = ((i$143055) + (((long)(1L))));
                        
                        //#line 1244 "x10/regionarray/Array.x10"
                        i$143055 = t$143054;
                    }
                    
                    //#line 1241 "x10/regionarray/Array.x10"
                    final long t$143069 = ((i$143070) + (((long)(1L))));
                    
                    //#line 1241 "x10/regionarray/Array.x10"
                    i$143070 = t$143069;
                }
                
                //#line 1238 "x10/regionarray/Array.x10"
                final long t$143083 = ((i$143084) + (((long)(1L))));
                
                //#line 1238 "x10/regionarray/Array.x10"
                i$143084 = t$143083;
            }
        }
    }
    
    public static <$T>void copy3$P__0$1x10$regionarray$Array$$T$2__2$1x10$regionarray$Array$$T$2(final x10.rtt.Type $T, final x10.regionarray.Array<$T> src, final x10.regionarray.Region r, final x10.regionarray.Array<$T> Array) {
        ((x10.regionarray.Array<$T>)Array).copy3__0$1x10$regionarray$Array$$T$2(((x10.regionarray.Array)(src)), ((x10.regionarray.Region)(r)));
    }
    
    
    //#line 1254 "x10/regionarray/Array.x10"
    private static void raiseBoundsError(final long i0) {
        
        //#line 1255 "x10/regionarray/Array.x10"
        final java.lang.String t$141334 = (("point (") + ((x10.core.Long.$box(i0))));
        
        //#line 1255 "x10/regionarray/Array.x10"
        final java.lang.String t$141335 = ((t$141334) + (") not contained in array"));
        
        //#line 1255 "x10/regionarray/Array.x10"
        final java.lang.ArrayIndexOutOfBoundsException t$141336 = ((java.lang.ArrayIndexOutOfBoundsException)(new java.lang.ArrayIndexOutOfBoundsException(t$141335)));
        
        //#line 1255 "x10/regionarray/Array.x10"
        throw t$141336;
    }
    
    public static void raiseBoundsError$P(final long i0) {
        x10.regionarray.Array.raiseBoundsError((long)(i0));
    }
    
    
    //#line 1257 "x10/regionarray/Array.x10"
    private static void raiseBoundsError(final long i0, final long i1) {
        
        //#line 1258 "x10/regionarray/Array.x10"
        final java.lang.String t$141337 = (("point (") + ((x10.core.Long.$box(i0))));
        
        //#line 1258 "x10/regionarray/Array.x10"
        final java.lang.String t$141338 = ((t$141337) + (", "));
        
        //#line 1258 "x10/regionarray/Array.x10"
        final java.lang.String t$141339 = ((t$141338) + ((x10.core.Long.$box(i1))));
        
        //#line 1258 "x10/regionarray/Array.x10"
        final java.lang.String t$141340 = ((t$141339) + (") not contained in array"));
        
        //#line 1258 "x10/regionarray/Array.x10"
        final java.lang.ArrayIndexOutOfBoundsException t$141341 = ((java.lang.ArrayIndexOutOfBoundsException)(new java.lang.ArrayIndexOutOfBoundsException(t$141340)));
        
        //#line 1258 "x10/regionarray/Array.x10"
        throw t$141341;
    }
    
    public static void raiseBoundsError$P(final long i0, final long i1) {
        x10.regionarray.Array.raiseBoundsError((long)(i0), (long)(i1));
    }
    
    
    //#line 1260 "x10/regionarray/Array.x10"
    private static void raiseBoundsError(final long i0, final long i1, final long i2) {
        
        //#line 1261 "x10/regionarray/Array.x10"
        final java.lang.String t$141342 = (("point (") + ((x10.core.Long.$box(i0))));
        
        //#line 1261 "x10/regionarray/Array.x10"
        final java.lang.String t$141343 = ((t$141342) + (", "));
        
        //#line 1261 "x10/regionarray/Array.x10"
        final java.lang.String t$141344 = ((t$141343) + ((x10.core.Long.$box(i1))));
        
        //#line 1261 "x10/regionarray/Array.x10"
        final java.lang.String t$141345 = ((t$141344) + (", "));
        
        //#line 1261 "x10/regionarray/Array.x10"
        final java.lang.String t$141346 = ((t$141345) + ((x10.core.Long.$box(i2))));
        
        //#line 1261 "x10/regionarray/Array.x10"
        final java.lang.String t$141347 = ((t$141346) + (") not contained in array"));
        
        //#line 1261 "x10/regionarray/Array.x10"
        final java.lang.ArrayIndexOutOfBoundsException t$141348 = ((java.lang.ArrayIndexOutOfBoundsException)(new java.lang.ArrayIndexOutOfBoundsException(t$141347)));
        
        //#line 1261 "x10/regionarray/Array.x10"
        throw t$141348;
    }
    
    public static void raiseBoundsError$P(final long i0, final long i1, final long i2) {
        x10.regionarray.Array.raiseBoundsError((long)(i0), (long)(i1), (long)(i2));
    }
    
    
    //#line 1263 "x10/regionarray/Array.x10"
    private static void raiseBoundsError(final long i0, final long i1, final long i2, final long i3) {
        
        //#line 1264 "x10/regionarray/Array.x10"
        final java.lang.String t$141349 = (("point (") + ((x10.core.Long.$box(i0))));
        
        //#line 1264 "x10/regionarray/Array.x10"
        final java.lang.String t$141350 = ((t$141349) + (", "));
        
        //#line 1264 "x10/regionarray/Array.x10"
        final java.lang.String t$141351 = ((t$141350) + ((x10.core.Long.$box(i1))));
        
        //#line 1264 "x10/regionarray/Array.x10"
        final java.lang.String t$141352 = ((t$141351) + (", "));
        
        //#line 1264 "x10/regionarray/Array.x10"
        final java.lang.String t$141353 = ((t$141352) + ((x10.core.Long.$box(i2))));
        
        //#line 1264 "x10/regionarray/Array.x10"
        final java.lang.String t$141354 = ((t$141353) + (", "));
        
        //#line 1264 "x10/regionarray/Array.x10"
        final java.lang.String t$141355 = ((t$141354) + ((x10.core.Long.$box(i3))));
        
        //#line 1264 "x10/regionarray/Array.x10"
        final java.lang.String t$141356 = ((t$141355) + (") not contained in array"));
        
        //#line 1264 "x10/regionarray/Array.x10"
        final java.lang.ArrayIndexOutOfBoundsException t$141357 = ((java.lang.ArrayIndexOutOfBoundsException)(new java.lang.ArrayIndexOutOfBoundsException(t$141356)));
        
        //#line 1264 "x10/regionarray/Array.x10"
        throw t$141357;
    }
    
    public static void raiseBoundsError$P(final long i0, final long i1, final long i2, final long i3) {
        x10.regionarray.Array.raiseBoundsError((long)(i0), (long)(i1), (long)(i2), (long)(i3));
    }
    
    
    //#line 1266 "x10/regionarray/Array.x10"
    private static void raiseBoundsError(final x10.lang.Point pt) {
        
        //#line 1267 "x10/regionarray/Array.x10"
        final java.lang.String t$141358 = (("point ") + (pt));
        
        //#line 1267 "x10/regionarray/Array.x10"
        final java.lang.String t$141359 = ((t$141358) + (" not contained in array"));
        
        //#line 1267 "x10/regionarray/Array.x10"
        final java.lang.ArrayIndexOutOfBoundsException t$141360 = ((java.lang.ArrayIndexOutOfBoundsException)(new java.lang.ArrayIndexOutOfBoundsException(t$141359)));
        
        //#line 1267 "x10/regionarray/Array.x10"
        throw t$141360;
    }
    
    public static void raiseBoundsError$P(final x10.lang.Point pt) {
        x10.regionarray.Array.raiseBoundsError(((x10.lang.Point)(pt)));
    }
    
    
    //#line 1277 "x10/regionarray/Array.x10"
    public long layout_min0;
    
    //#line 1278 "x10/regionarray/Array.x10"
    public long layout_stride1;
    
    //#line 1279 "x10/regionarray/Array.x10"
    public long layout_min1;
    
    //#line 1287 "x10/regionarray/Array.x10"
    public x10.core.Rail<x10.core.Long> layout;
    
    
    //#line 1290 "x10/regionarray/Array.x10"
    private long offset$O(final long i0) {
        
        //#line 1290 "x10/regionarray/Array.x10"
        final long t$141361 = this.layout_min0;
        
        //#line 1290 "x10/regionarray/Array.x10"
        final long t$141362 = ((i0) - (((long)(t$141361))));
        
        //#line 1290 "x10/regionarray/Array.x10"
        return t$141362;
    }
    
    public static <$T>long offset$P__1$1x10$regionarray$Array$$T$2$O(final x10.rtt.Type $T, final long i0, final x10.regionarray.Array<$T> Array) {
        return ((x10.regionarray.Array<$T>)Array).offset$O((long)(i0));
    }
    
    
    //#line 1293 "x10/regionarray/Array.x10"
    private long offset$O(final long i0, final long i1) {
        
        //#line 1294 "x10/regionarray/Array.x10"
        final long t$141363 = this.layout_min0;
        
        //#line 1294 "x10/regionarray/Array.x10"
        long offset = ((i0) - (((long)(t$141363))));
        
        //#line 1295 "x10/regionarray/Array.x10"
        final long t$141365 = this.layout_stride1;
        
        //#line 1295 "x10/regionarray/Array.x10"
        final long t$141366 = ((offset) * (((long)(t$141365))));
        
        //#line 1295 "x10/regionarray/Array.x10"
        final long t$141367 = ((t$141366) + (((long)(i1))));
        
        //#line 1295 "x10/regionarray/Array.x10"
        final long t$141368 = this.layout_min1;
        
        //#line 1295 "x10/regionarray/Array.x10"
        final long t$141369 = ((t$141367) - (((long)(t$141368))));
        
        //#line 1295 "x10/regionarray/Array.x10"
        offset = t$141369;
        
        //#line 1296 "x10/regionarray/Array.x10"
        return offset;
    }
    
    public static <$T>long offset$P__2$1x10$regionarray$Array$$T$2$O(final x10.rtt.Type $T, final long i0, final long i1, final x10.regionarray.Array<$T> Array) {
        return ((x10.regionarray.Array<$T>)Array).offset$O((long)(i0), (long)(i1));
    }
    
    
    //#line 1299 "x10/regionarray/Array.x10"
    private long offset$O(final long i0, final long i1, final long i2) {
        
        //#line 1300 "x10/regionarray/Array.x10"
        final long t$141371 = this.layout_min0;
        
        //#line 1300 "x10/regionarray/Array.x10"
        long offset = ((i0) - (((long)(t$141371))));
        
        //#line 1301 "x10/regionarray/Array.x10"
        final long t$141373 = this.layout_stride1;
        
        //#line 1301 "x10/regionarray/Array.x10"
        final long t$141374 = ((offset) * (((long)(t$141373))));
        
        //#line 1301 "x10/regionarray/Array.x10"
        final long t$141375 = ((t$141374) + (((long)(i1))));
        
        //#line 1301 "x10/regionarray/Array.x10"
        final long t$141376 = this.layout_min1;
        
        //#line 1301 "x10/regionarray/Array.x10"
        final long t$141377 = ((t$141375) - (((long)(t$141376))));
        
        //#line 1301 "x10/regionarray/Array.x10"
        offset = t$141377;
        
        //#line 1302 "x10/regionarray/Array.x10"
        final x10.core.Rail t$141378 = ((x10.core.Rail)(this.layout));
        
        //#line 1302 "x10/regionarray/Array.x10"
        final long t$141380 = ((long[])t$141378.value)[(int)0L];
        
        //#line 1302 "x10/regionarray/Array.x10"
        final long t$141381 = ((offset) * (((long)(t$141380))));
        
        //#line 1302 "x10/regionarray/Array.x10"
        final long t$141383 = ((t$141381) + (((long)(i2))));
        
        //#line 1302 "x10/regionarray/Array.x10"
        final x10.core.Rail t$141382 = ((x10.core.Rail)(this.layout));
        
        //#line 1302 "x10/regionarray/Array.x10"
        final long t$141384 = ((long[])t$141382.value)[(int)1L];
        
        //#line 1302 "x10/regionarray/Array.x10"
        final long t$141385 = ((t$141383) - (((long)(t$141384))));
        
        //#line 1302 "x10/regionarray/Array.x10"
        offset = t$141385;
        
        //#line 1303 "x10/regionarray/Array.x10"
        return offset;
    }
    
    public static <$T>long offset$P__3$1x10$regionarray$Array$$T$2$O(final x10.rtt.Type $T, final long i0, final long i1, final long i2, final x10.regionarray.Array<$T> Array) {
        return ((x10.regionarray.Array<$T>)Array).offset$O((long)(i0), (long)(i1), (long)(i2));
    }
    
    
    //#line 1306 "x10/regionarray/Array.x10"
    private long offset$O(final long i0, final long i1, final long i2, final long i3) {
        
        //#line 1307 "x10/regionarray/Array.x10"
        final long t$141387 = this.layout_min0;
        
        //#line 1307 "x10/regionarray/Array.x10"
        long offset = ((i0) - (((long)(t$141387))));
        
        //#line 1308 "x10/regionarray/Array.x10"
        final long t$141389 = this.layout_stride1;
        
        //#line 1308 "x10/regionarray/Array.x10"
        final long t$141390 = ((offset) * (((long)(t$141389))));
        
        //#line 1308 "x10/regionarray/Array.x10"
        final long t$141391 = ((t$141390) + (((long)(i1))));
        
        //#line 1308 "x10/regionarray/Array.x10"
        final long t$141392 = this.layout_min1;
        
        //#line 1308 "x10/regionarray/Array.x10"
        final long t$141393 = ((t$141391) - (((long)(t$141392))));
        
        //#line 1308 "x10/regionarray/Array.x10"
        offset = t$141393;
        
        //#line 1309 "x10/regionarray/Array.x10"
        final x10.core.Rail t$141394 = ((x10.core.Rail)(this.layout));
        
        //#line 1309 "x10/regionarray/Array.x10"
        final long t$141396 = ((long[])t$141394.value)[(int)0L];
        
        //#line 1309 "x10/regionarray/Array.x10"
        final long t$141397 = ((offset) * (((long)(t$141396))));
        
        //#line 1309 "x10/regionarray/Array.x10"
        final long t$141399 = ((t$141397) + (((long)(i2))));
        
        //#line 1309 "x10/regionarray/Array.x10"
        final x10.core.Rail t$141398 = ((x10.core.Rail)(this.layout));
        
        //#line 1309 "x10/regionarray/Array.x10"
        final long t$141400 = ((long[])t$141398.value)[(int)1L];
        
        //#line 1309 "x10/regionarray/Array.x10"
        final long t$141401 = ((t$141399) - (((long)(t$141400))));
        
        //#line 1309 "x10/regionarray/Array.x10"
        offset = t$141401;
        
        //#line 1310 "x10/regionarray/Array.x10"
        final x10.core.Rail t$141402 = ((x10.core.Rail)(this.layout));
        
        //#line 1310 "x10/regionarray/Array.x10"
        final long t$141404 = ((long[])t$141402.value)[(int)2L];
        
        //#line 1310 "x10/regionarray/Array.x10"
        final long t$141405 = ((offset) * (((long)(t$141404))));
        
        //#line 1310 "x10/regionarray/Array.x10"
        final long t$141407 = ((t$141405) + (((long)(i3))));
        
        //#line 1310 "x10/regionarray/Array.x10"
        final x10.core.Rail t$141406 = ((x10.core.Rail)(this.layout));
        
        //#line 1310 "x10/regionarray/Array.x10"
        final long t$141408 = ((long[])t$141406.value)[(int)3L];
        
        //#line 1310 "x10/regionarray/Array.x10"
        final long t$141409 = ((t$141407) - (((long)(t$141408))));
        
        //#line 1310 "x10/regionarray/Array.x10"
        offset = t$141409;
        
        //#line 1311 "x10/regionarray/Array.x10"
        return offset;
    }
    
    public static <$T>long offset$P__4$1x10$regionarray$Array$$T$2$O(final x10.rtt.Type $T, final long i0, final long i1, final long i2, final long i3, final x10.regionarray.Array<$T> Array) {
        return ((x10.regionarray.Array<$T>)Array).offset$O((long)(i0), (long)(i1), (long)(i2), (long)(i3));
    }
    
    
    //#line 1314 "x10/regionarray/Array.x10"
    private long offset$O(final x10.lang.Point pt) {
        
        //#line 1315 "x10/regionarray/Array.x10"
        final long t$141411 = ((long)(((int)(0))));
        
        //#line 1315 "x10/regionarray/Array.x10"
        final long t$141412 = pt.$apply$O((long)(t$141411));
        
        //#line 1315 "x10/regionarray/Array.x10"
        final long t$141413 = this.layout_min0;
        
        //#line 1315 "x10/regionarray/Array.x10"
        long offset = ((t$141412) - (((long)(t$141413))));
        
        //#line 1316 "x10/regionarray/Array.x10"
        final long t$141414 = pt.rank;
        
        //#line 1316 "x10/regionarray/Array.x10"
        final boolean t$141442 = ((t$141414) > (((long)(1L))));
        
        //#line 1316 "x10/regionarray/Array.x10"
        if (t$141442) {
            
            //#line 1317 "x10/regionarray/Array.x10"
            final long t$141416 = this.layout_stride1;
            
            //#line 1317 "x10/regionarray/Array.x10"
            final long t$141417 = ((offset) * (((long)(t$141416))));
            
            //#line 1317 "x10/regionarray/Array.x10"
            final long t$141418 = pt.$apply$O((long)(1L));
            
            //#line 1317 "x10/regionarray/Array.x10"
            final long t$141419 = ((t$141417) + (((long)(t$141418))));
            
            //#line 1317 "x10/regionarray/Array.x10"
            final long t$141420 = this.layout_min1;
            
            //#line 1317 "x10/regionarray/Array.x10"
            final long t$141421 = ((t$141419) - (((long)(t$141420))));
            
            //#line 1317 "x10/regionarray/Array.x10"
            offset = t$141421;
            
            //#line 1318 "x10/regionarray/Array.x10"
            final long t$143110 = pt.rank;
            
            //#line 1318 "x10/regionarray/Array.x10"
            final long i$138773max$143111 = ((t$143110) - (((long)(1L))));
            
            //#line 1318 "x10/regionarray/Array.x10"
            long i$143107 = 2L;
            
            //#line 1318 "x10/regionarray/Array.x10"
            for (;
                 true;
                 ) {
                
                //#line 1318 "x10/regionarray/Array.x10"
                final boolean t$143109 = ((i$143107) <= (((long)(i$138773max$143111))));
                
                //#line 1318 "x10/regionarray/Array.x10"
                if (!(t$143109)) {
                    
                    //#line 1318 "x10/regionarray/Array.x10"
                    break;
                }
                
                //#line 1319 "x10/regionarray/Array.x10"
                final x10.core.Rail t$143091 = ((x10.core.Rail)(this.layout));
                
                //#line 1319 "x10/regionarray/Array.x10"
                final long t$143092 = ((i$143107) - (((long)(2L))));
                
                //#line 1319 "x10/regionarray/Array.x10"
                final long t$143093 = ((2L) * (((long)(t$143092))));
                
                //#line 1319 "x10/regionarray/Array.x10"
                final long t$143094 = ((long[])t$143091.value)[(int)t$143093];
                
                //#line 1319 "x10/regionarray/Array.x10"
                final long t$143095 = ((offset) * (((long)(t$143094))));
                
                //#line 1319 "x10/regionarray/Array.x10"
                final long t$143096 = pt.$apply$O((long)(i$143107));
                
                //#line 1319 "x10/regionarray/Array.x10"
                final long t$143097 = ((t$143095) + (((long)(t$143096))));
                
                //#line 1319 "x10/regionarray/Array.x10"
                final x10.core.Rail t$143098 = ((x10.core.Rail)(this.layout));
                
                //#line 1319 "x10/regionarray/Array.x10"
                final long t$143099 = ((i$143107) - (((long)(2L))));
                
                //#line 1319 "x10/regionarray/Array.x10"
                final long t$143100 = ((2L) * (((long)(t$143099))));
                
                //#line 1319 "x10/regionarray/Array.x10"
                final long t$143101 = ((t$143100) + (((long)(1L))));
                
                //#line 1319 "x10/regionarray/Array.x10"
                final long t$143102 = ((long[])t$143098.value)[(int)t$143101];
                
                //#line 1319 "x10/regionarray/Array.x10"
                final long t$143103 = ((t$143097) - (((long)(t$143102))));
                
                //#line 1319 "x10/regionarray/Array.x10"
                offset = t$143103;
                
                //#line 1318 "x10/regionarray/Array.x10"
                final long t$143106 = ((i$143107) + (((long)(1L))));
                
                //#line 1318 "x10/regionarray/Array.x10"
                i$143107 = t$143106;
            }
        }
        
        //#line 1322 "x10/regionarray/Array.x10"
        return offset;
    }
    
    public static <$T>long offset$P__1$1x10$regionarray$Array$$T$2$O(final x10.rtt.Type $T, final x10.lang.Point pt, final x10.regionarray.Array<$T> Array) {
        return ((x10.regionarray.Array<$T>)Array).offset$O(((x10.lang.Point)(pt)));
    }
    
    
    //#line 1331 "x10/regionarray/Array.x10"
    @x10.runtime.impl.java.X10Generated
    public static class LayoutHelper extends x10.core.Struct implements x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<LayoutHelper> $RTT = 
            x10.rtt.NamedStructType.<LayoutHelper> make("x10.regionarray.Array.LayoutHelper",
                                                        LayoutHelper.class,
                                                        new x10.rtt.Type[] {
                                                            x10.rtt.Types.STRUCT
                                                        });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static x10.serialization.X10JavaSerializable $_deserialize_body(x10.regionarray.Array.LayoutHelper $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            $_obj.layout = $deserializer.readObject();
            $_obj.min0 = $deserializer.readLong();
            $_obj.min1 = $deserializer.readLong();
            $_obj.size = $deserializer.readLong();
            $_obj.stride1 = $deserializer.readLong();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.regionarray.Array.LayoutHelper $_obj = new x10.regionarray.Array.LayoutHelper((java.lang.System[]) null);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            $serializer.write(this.layout);
            $serializer.write(this.min0);
            $serializer.write(this.min1);
            $serializer.write(this.size);
            $serializer.write(this.stride1);
            
        }
        
        // zero value constructor
        public LayoutHelper(final java.lang.System $dummy) { this.min0 = 0L; this.stride1 = 0L; this.min1 = 0L; this.size = 0L; this.layout = null; }
        
        // constructor just for allocation
        public LayoutHelper(final java.lang.System[] $dummy) {
            
        }
        
        
    
        
        //#line 1332 "x10/regionarray/Array.x10"
        public long min0;
        
        //#line 1333 "x10/regionarray/Array.x10"
        public long stride1;
        
        //#line 1334 "x10/regionarray/Array.x10"
        public long min1;
        
        //#line 1335 "x10/regionarray/Array.x10"
        public long size;
        
        //#line 1336 "x10/regionarray/Array.x10"
        public x10.core.Rail<x10.core.Long> layout;
        
        
        //#line 1338 "x10/regionarray/Array.x10"
        // creation method for java code (1-phase java constructor)
        public LayoutHelper(final x10.regionarray.Region reg) {
            this((java.lang.System[]) null);
            x10$regionarray$Array$LayoutHelper$$init$S(reg);
        }
        
        // constructor for non-virtual call
        final public x10.regionarray.Array.LayoutHelper x10$regionarray$Array$LayoutHelper$$init$S(final x10.regionarray.Region reg) {
             {
                
                //#line 1338 "x10/regionarray/Array.x10"
                
                
                //#line 1339 "x10/regionarray/Array.x10"
                final boolean t$141505 = reg.isEmpty$O();
                
                //#line 1339 "x10/regionarray/Array.x10"
                if (t$141505) {
                    
                    //#line 1340 "x10/regionarray/Array.x10"
                    final long t$141444 = this.min1 = 0L;
                    
                    //#line 1340 "x10/regionarray/Array.x10"
                    final long t$141445 = this.stride1 = t$141444;
                    
                    //#line 1340 "x10/regionarray/Array.x10"
                    this.min0 = t$141445;
                    
                    //#line 1341 "x10/regionarray/Array.x10"
                    this.size = 0L;
                    
                    //#line 1342 "x10/regionarray/Array.x10"
                    this.layout = null;
                } else {
                    
                    //#line 1344 "x10/regionarray/Array.x10"
                    final long t$141446 = reg.rank;
                    
                    //#line 1344 "x10/regionarray/Array.x10"
                    final boolean t$141504 = ((long) t$141446) == ((long) 1L);
                    
                    //#line 1344 "x10/regionarray/Array.x10"
                    if (t$141504) {
                        
                        //#line 1345 "x10/regionarray/Array.x10"
                        final long t$141447 = ((long)(((int)(0))));
                        
                        //#line 1345 "x10/regionarray/Array.x10"
                        final long t$141448 = reg.min$O((long)(t$141447));
                        
                        //#line 1345 "x10/regionarray/Array.x10"
                        this.min0 = t$141448;
                        
                        //#line 1346 "x10/regionarray/Array.x10"
                        this.stride1 = 0L;
                        
                        //#line 1347 "x10/regionarray/Array.x10"
                        this.min1 = 0L;
                        
                        //#line 1348 "x10/regionarray/Array.x10"
                        final long t$141449 = reg.max$O((long)(0L));
                        
                        //#line 1348 "x10/regionarray/Array.x10"
                        final long t$141450 = reg.min$O((long)(0L));
                        
                        //#line 1348 "x10/regionarray/Array.x10"
                        final long t$141451 = ((t$141449) - (((long)(t$141450))));
                        
                        //#line 1348 "x10/regionarray/Array.x10"
                        final long t$141452 = ((t$141451) + (((long)(1L))));
                        
                        //#line 1348 "x10/regionarray/Array.x10"
                        this.size = t$141452;
                        
                        //#line 1349 "x10/regionarray/Array.x10"
                        this.layout = null;
                    } else {
                        
                        //#line 1350 "x10/regionarray/Array.x10"
                        final long t$141453 = reg.rank;
                        
                        //#line 1350 "x10/regionarray/Array.x10"
                        final boolean t$141503 = ((long) t$141453) == ((long) 2L);
                        
                        //#line 1350 "x10/regionarray/Array.x10"
                        if (t$141503) {
                            
                            //#line 1351 "x10/regionarray/Array.x10"
                            final long t$141454 = reg.min$O((long)(0L));
                            
                            //#line 1351 "x10/regionarray/Array.x10"
                            this.min0 = t$141454;
                            
                            //#line 1352 "x10/regionarray/Array.x10"
                            final long t$141455 = reg.min$O((long)(1L));
                            
                            //#line 1352 "x10/regionarray/Array.x10"
                            this.min1 = t$141455;
                            
                            //#line 1353 "x10/regionarray/Array.x10"
                            final long t$141456 = reg.max$O((long)(1L));
                            
                            //#line 1353 "x10/regionarray/Array.x10"
                            final long t$141457 = reg.min$O((long)(1L));
                            
                            //#line 1353 "x10/regionarray/Array.x10"
                            final long t$141458 = ((t$141456) - (((long)(t$141457))));
                            
                            //#line 1353 "x10/regionarray/Array.x10"
                            final long t$141459 = ((t$141458) + (((long)(1L))));
                            
                            //#line 1353 "x10/regionarray/Array.x10"
                            this.stride1 = t$141459;
                            
                            //#line 1354 "x10/regionarray/Array.x10"
                            final long t$141463 = this.stride1;
                            
                            //#line 1354 "x10/regionarray/Array.x10"
                            final long t$141460 = reg.max$O((long)(0L));
                            
                            //#line 1354 "x10/regionarray/Array.x10"
                            final long t$141461 = reg.min$O((long)(0L));
                            
                            //#line 1354 "x10/regionarray/Array.x10"
                            final long t$141462 = ((t$141460) - (((long)(t$141461))));
                            
                            //#line 1354 "x10/regionarray/Array.x10"
                            final long t$141464 = ((t$141462) + (((long)(1L))));
                            
                            //#line 1354 "x10/regionarray/Array.x10"
                            final long t$141465 = ((t$141463) * (((long)(t$141464))));
                            
                            //#line 1354 "x10/regionarray/Array.x10"
                            this.size = t$141465;
                            
                            //#line 1355 "x10/regionarray/Array.x10"
                            this.layout = null;
                        } else {
                            
                            //#line 1357 "x10/regionarray/Array.x10"
                            final long t$141466 = reg.rank;
                            
                            //#line 1357 "x10/regionarray/Array.x10"
                            final long t$141467 = ((t$141466) - (((long)(2L))));
                            
                            //#line 1357 "x10/regionarray/Array.x10"
                            final long t$141468 = ((2L) * (((long)(t$141467))));
                            
                            //#line 1357 "x10/regionarray/Array.x10"
                            final x10.core.Rail t$141469 = ((x10.core.Rail)(new x10.core.Rail<x10.core.Long>(x10.rtt.Types.LONG, t$141468)));
                            
                            //#line 1357 "x10/regionarray/Array.x10"
                            this.layout = ((x10.core.Rail)(t$141469));
                            
                            //#line 1358 "x10/regionarray/Array.x10"
                            final long t$141470 = reg.min$O((long)(0L));
                            
                            //#line 1358 "x10/regionarray/Array.x10"
                            this.min0 = t$141470;
                            
                            //#line 1359 "x10/regionarray/Array.x10"
                            final long t$141471 = reg.min$O((long)(1L));
                            
                            //#line 1359 "x10/regionarray/Array.x10"
                            this.min1 = t$141471;
                            
                            //#line 1360 "x10/regionarray/Array.x10"
                            final long t$141472 = reg.max$O((long)(1L));
                            
                            //#line 1360 "x10/regionarray/Array.x10"
                            final long t$141473 = reg.min$O((long)(1L));
                            
                            //#line 1360 "x10/regionarray/Array.x10"
                            final long t$141474 = ((t$141472) - (((long)(t$141473))));
                            
                            //#line 1360 "x10/regionarray/Array.x10"
                            final long t$141475 = ((t$141474) + (((long)(1L))));
                            
                            //#line 1360 "x10/regionarray/Array.x10"
                            this.stride1 = t$141475;
                            
                            //#line 1361 "x10/regionarray/Array.x10"
                            final long t$141481 = this.stride1;
                            
                            //#line 1361 "x10/regionarray/Array.x10"
                            final long t$141476 = ((long)(((int)(0))));
                            
                            //#line 1361 "x10/regionarray/Array.x10"
                            final long t$141478 = reg.max$O((long)(t$141476));
                            
                            //#line 1361 "x10/regionarray/Array.x10"
                            final long t$141477 = ((long)(((int)(0))));
                            
                            //#line 1361 "x10/regionarray/Array.x10"
                            final long t$141479 = reg.min$O((long)(t$141477));
                            
                            //#line 1361 "x10/regionarray/Array.x10"
                            final long t$141480 = ((t$141478) - (((long)(t$141479))));
                            
                            //#line 1361 "x10/regionarray/Array.x10"
                            final long t$141482 = ((t$141480) + (((long)(1L))));
                            
                            //#line 1361 "x10/regionarray/Array.x10"
                            long sz = ((t$141481) * (((long)(t$141482))));
                            
                            //#line 1362 "x10/regionarray/Array.x10"
                            final long t$143132 = reg.rank;
                            
                            //#line 1362 "x10/regionarray/Array.x10"
                            final long i$138791max$143133 = ((t$143132) - (((long)(1L))));
                            
                            //#line 1362 "x10/regionarray/Array.x10"
                            long i$143129 = 2L;
                            
                            //#line 1362 "x10/regionarray/Array.x10"
                            for (;
                                 true;
                                 ) {
                                
                                //#line 1362 "x10/regionarray/Array.x10"
                                final boolean t$143131 = ((i$143129) <= (((long)(i$138791max$143133))));
                                
                                //#line 1362 "x10/regionarray/Array.x10"
                                if (!(t$143131)) {
                                    
                                    //#line 1362 "x10/regionarray/Array.x10"
                                    break;
                                }
                                
                                //#line 1363 "x10/regionarray/Array.x10"
                                final long t$143112 = reg.max$O((long)(i$143129));
                                
                                //#line 1363 "x10/regionarray/Array.x10"
                                final long t$143113 = reg.min$O((long)(i$143129));
                                
                                //#line 1363 "x10/regionarray/Array.x10"
                                final long t$143114 = ((t$143112) - (((long)(t$143113))));
                                
                                //#line 1363 "x10/regionarray/Array.x10"
                                final long stride$143115 = ((t$143114) + (((long)(1L))));
                                
                                //#line 1364 "x10/regionarray/Array.x10"
                                final long t$143117 = ((sz) * (((long)(stride$143115))));
                                
                                //#line 1364 "x10/regionarray/Array.x10"
                                sz = t$143117;
                                
                                //#line 1365 "x10/regionarray/Array.x10"
                                final x10.core.Rail t$143118 = ((x10.core.Rail)(this.layout));
                                
                                //#line 1365 "x10/regionarray/Array.x10"
                                final long t$143119 = ((i$143129) - (((long)(2L))));
                                
                                //#line 1365 "x10/regionarray/Array.x10"
                                final long t$143120 = ((2L) * (((long)(t$143119))));
                                
                                //#line 1365 "x10/regionarray/Array.x10"
                                ((long[])t$143118.value)[(int)t$143120] = stride$143115;
                                
                                //#line 1366 "x10/regionarray/Array.x10"
                                final x10.core.Rail t$143121 = ((x10.core.Rail)(this.layout));
                                
                                //#line 1366 "x10/regionarray/Array.x10"
                                final long t$143122 = ((i$143129) - (((long)(2L))));
                                
                                //#line 1366 "x10/regionarray/Array.x10"
                                final long t$143123 = ((2L) * (((long)(t$143122))));
                                
                                //#line 1366 "x10/regionarray/Array.x10"
                                final long t$143124 = ((t$143123) + (((long)(1L))));
                                
                                //#line 1366 "x10/regionarray/Array.x10"
                                final long t$143125 = reg.min$O((long)(i$143129));
                                
                                //#line 1366 "x10/regionarray/Array.x10"
                                ((long[])t$143121.value)[(int)t$143124] = t$143125;
                                
                                //#line 1362 "x10/regionarray/Array.x10"
                                final long t$143128 = ((i$143129) + (((long)(1L))));
                                
                                //#line 1362 "x10/regionarray/Array.x10"
                                i$143129 = t$143128;
                            }
                            
                            //#line 1368 "x10/regionarray/Array.x10"
                            this.size = sz;
                        }
                    }
                }
            }
            return this;
        }
        
        
        
        //#line 1331 "x10/regionarray/Array.x10"
        final public java.lang.String typeName() {
            try {
                return x10.rtt.Types.typeName(this);
            }
            catch (java.lang.Throwable exc$206458) {
                throw x10.runtime.impl.java.ThrowableUtils.ensureX10Exception(exc$206458);
            }
            
        }
        
        
        
        //#line 1331 "x10/regionarray/Array.x10"
        final public java.lang.String toString() {
            
            //#line 1331 "x10/regionarray/Array.x10"
            final java.lang.String t$141506 = "struct x10.regionarray.Array.LayoutHelper: min0=";
            
            //#line 1331 "x10/regionarray/Array.x10"
            final long t$141507 = this.min0;
            
            //#line 1331 "x10/regionarray/Array.x10"
            final java.lang.String t$141508 = ((t$141506) + ((x10.core.Long.$box(t$141507))));
            
            //#line 1331 "x10/regionarray/Array.x10"
            final java.lang.String t$141509 = ((t$141508) + (" stride1="));
            
            //#line 1331 "x10/regionarray/Array.x10"
            final long t$141510 = this.stride1;
            
            //#line 1331 "x10/regionarray/Array.x10"
            final java.lang.String t$141511 = ((t$141509) + ((x10.core.Long.$box(t$141510))));
            
            //#line 1331 "x10/regionarray/Array.x10"
            final java.lang.String t$141512 = ((t$141511) + (" min1="));
            
            //#line 1331 "x10/regionarray/Array.x10"
            final long t$141513 = this.min1;
            
            //#line 1331 "x10/regionarray/Array.x10"
            final java.lang.String t$141514 = ((t$141512) + ((x10.core.Long.$box(t$141513))));
            
            //#line 1331 "x10/regionarray/Array.x10"
            final java.lang.String t$141515 = ((t$141514) + (" size="));
            
            //#line 1331 "x10/regionarray/Array.x10"
            final long t$141516 = this.size;
            
            //#line 1331 "x10/regionarray/Array.x10"
            final java.lang.String t$141517 = ((t$141515) + ((x10.core.Long.$box(t$141516))));
            
            //#line 1331 "x10/regionarray/Array.x10"
            final java.lang.String t$141518 = ((t$141517) + (" layout="));
            
            //#line 1331 "x10/regionarray/Array.x10"
            final x10.core.Rail t$141519 = ((x10.core.Rail)(this.layout));
            
            //#line 1331 "x10/regionarray/Array.x10"
            final java.lang.String t$141520 = ((t$141518) + (t$141519));
            
            //#line 1331 "x10/regionarray/Array.x10"
            return t$141520;
        }
        
        
        //#line 1331 "x10/regionarray/Array.x10"
        final public int hashCode() {
            
            //#line 1331 "x10/regionarray/Array.x10"
            int result = 1;
            
            //#line 1331 "x10/regionarray/Array.x10"
            final int t$141523 = ((8191) * (((int)(result))));
            
            //#line 1331 "x10/regionarray/Array.x10"
            final long t$141522 = this.min0;
            
            //#line 1331 "x10/regionarray/Array.x10"
            final int t$141524 = x10.rtt.Types.hashCode(t$141522);
            
            //#line 1331 "x10/regionarray/Array.x10"
            final int t$141525 = ((t$141523) + (((int)(t$141524))));
            
            //#line 1331 "x10/regionarray/Array.x10"
            result = t$141525;
            
            //#line 1331 "x10/regionarray/Array.x10"
            final int t$141528 = ((8191) * (((int)(result))));
            
            //#line 1331 "x10/regionarray/Array.x10"
            final long t$141527 = this.stride1;
            
            //#line 1331 "x10/regionarray/Array.x10"
            final int t$141529 = x10.rtt.Types.hashCode(t$141527);
            
            //#line 1331 "x10/regionarray/Array.x10"
            final int t$141530 = ((t$141528) + (((int)(t$141529))));
            
            //#line 1331 "x10/regionarray/Array.x10"
            result = t$141530;
            
            //#line 1331 "x10/regionarray/Array.x10"
            final int t$141533 = ((8191) * (((int)(result))));
            
            //#line 1331 "x10/regionarray/Array.x10"
            final long t$141532 = this.min1;
            
            //#line 1331 "x10/regionarray/Array.x10"
            final int t$141534 = x10.rtt.Types.hashCode(t$141532);
            
            //#line 1331 "x10/regionarray/Array.x10"
            final int t$141535 = ((t$141533) + (((int)(t$141534))));
            
            //#line 1331 "x10/regionarray/Array.x10"
            result = t$141535;
            
            //#line 1331 "x10/regionarray/Array.x10"
            final int t$141538 = ((8191) * (((int)(result))));
            
            //#line 1331 "x10/regionarray/Array.x10"
            final long t$141537 = this.size;
            
            //#line 1331 "x10/regionarray/Array.x10"
            final int t$141539 = x10.rtt.Types.hashCode(t$141537);
            
            //#line 1331 "x10/regionarray/Array.x10"
            final int t$141540 = ((t$141538) + (((int)(t$141539))));
            
            //#line 1331 "x10/regionarray/Array.x10"
            result = t$141540;
            
            //#line 1331 "x10/regionarray/Array.x10"
            final int t$141543 = ((8191) * (((int)(result))));
            
            //#line 1331 "x10/regionarray/Array.x10"
            final x10.core.Rail t$141542 = ((x10.core.Rail)(this.layout));
            
            //#line 1331 "x10/regionarray/Array.x10"
            final int t$141544 = x10.rtt.Types.hashCode(((java.lang.Object)(t$141542)));
            
            //#line 1331 "x10/regionarray/Array.x10"
            final int t$141545 = ((t$141543) + (((int)(t$141544))));
            
            //#line 1331 "x10/regionarray/Array.x10"
            result = t$141545;
            
            //#line 1331 "x10/regionarray/Array.x10"
            return result;
        }
        
        
        //#line 1331 "x10/regionarray/Array.x10"
        final public boolean equals(java.lang.Object other) {
            
            //#line 1331 "x10/regionarray/Array.x10"
            final boolean t$141548 = x10.regionarray.Array.LayoutHelper.$RTT.isInstance(other);
            
            //#line 1331 "x10/regionarray/Array.x10"
            final boolean t$141549 = !(t$141548);
            
            //#line 1331 "x10/regionarray/Array.x10"
            if (t$141549) {
                
                //#line 1331 "x10/regionarray/Array.x10"
                return false;
            }
            
            //#line 1331 "x10/regionarray/Array.x10"
            final x10.regionarray.Array.LayoutHelper t$141551 = ((x10.regionarray.Array.LayoutHelper)x10.rtt.Types.asStruct(x10.regionarray.Array.LayoutHelper.$RTT,other));
            
            //#line 1331 "x10/regionarray/Array.x10"
            final boolean t$141552 = this.equals$O(((x10.regionarray.Array.LayoutHelper)(t$141551)));
            
            //#line 1331 "x10/regionarray/Array.x10"
            return t$141552;
        }
        
        
        //#line 1331 "x10/regionarray/Array.x10"
        final public boolean equals$O(x10.regionarray.Array.LayoutHelper other) {
            
            //#line 1331 "x10/regionarray/Array.x10"
            final long t$141554 = this.min0;
            
            //#line 1331 "x10/regionarray/Array.x10"
            final long t$141555 = other.min0;
            
            //#line 1331 "x10/regionarray/Array.x10"
            boolean t$141559 = ((long) t$141554) == ((long) t$141555);
            
            //#line 1331 "x10/regionarray/Array.x10"
            if (t$141559) {
                
                //#line 1331 "x10/regionarray/Array.x10"
                final long t$141557 = this.stride1;
                
                //#line 1331 "x10/regionarray/Array.x10"
                final long t$141558 = other.stride1;
                
                //#line 1331 "x10/regionarray/Array.x10"
                t$141559 = ((long) t$141557) == ((long) t$141558);
            }
            
            //#line 1331 "x10/regionarray/Array.x10"
            boolean t$141563 = t$141559;
            
            //#line 1331 "x10/regionarray/Array.x10"
            if (t$141559) {
                
                //#line 1331 "x10/regionarray/Array.x10"
                final long t$141561 = this.min1;
                
                //#line 1331 "x10/regionarray/Array.x10"
                final long t$141562 = other.min1;
                
                //#line 1331 "x10/regionarray/Array.x10"
                t$141563 = ((long) t$141561) == ((long) t$141562);
            }
            
            //#line 1331 "x10/regionarray/Array.x10"
            boolean t$141567 = t$141563;
            
            //#line 1331 "x10/regionarray/Array.x10"
            if (t$141563) {
                
                //#line 1331 "x10/regionarray/Array.x10"
                final long t$141565 = this.size;
                
                //#line 1331 "x10/regionarray/Array.x10"
                final long t$141566 = other.size;
                
                //#line 1331 "x10/regionarray/Array.x10"
                t$141567 = ((long) t$141565) == ((long) t$141566);
            }
            
            //#line 1331 "x10/regionarray/Array.x10"
            boolean t$141571 = t$141567;
            
            //#line 1331 "x10/regionarray/Array.x10"
            if (t$141567) {
                
                //#line 1331 "x10/regionarray/Array.x10"
                final x10.core.Rail t$141569 = ((x10.core.Rail)(this.layout));
                
                //#line 1331 "x10/regionarray/Array.x10"
                final x10.core.Rail t$141570 = ((x10.core.Rail)(other.layout));
                
                //#line 1331 "x10/regionarray/Array.x10"
                t$141571 = x10.rtt.Equality.equalsequals((t$141569),(t$141570));
            }
            
            //#line 1331 "x10/regionarray/Array.x10"
            return t$141571;
        }
        
        
        //#line 1331 "x10/regionarray/Array.x10"
        final public boolean _struct_equals$O(java.lang.Object other) {
            
            //#line 1331 "x10/regionarray/Array.x10"
            final boolean t$141574 = x10.regionarray.Array.LayoutHelper.$RTT.isInstance(other);
            
            //#line 1331 "x10/regionarray/Array.x10"
            final boolean t$141575 = !(t$141574);
            
            //#line 1331 "x10/regionarray/Array.x10"
            if (t$141575) {
                
                //#line 1331 "x10/regionarray/Array.x10"
                return false;
            }
            
            //#line 1331 "x10/regionarray/Array.x10"
            final x10.regionarray.Array.LayoutHelper t$141577 = ((x10.regionarray.Array.LayoutHelper)x10.rtt.Types.asStruct(x10.regionarray.Array.LayoutHelper.$RTT,other));
            
            //#line 1331 "x10/regionarray/Array.x10"
            final boolean t$141578 = this._struct_equals$O(((x10.regionarray.Array.LayoutHelper)(t$141577)));
            
            //#line 1331 "x10/regionarray/Array.x10"
            return t$141578;
        }
        
        
        //#line 1331 "x10/regionarray/Array.x10"
        final public boolean _struct_equals$O(x10.regionarray.Array.LayoutHelper other) {
            
            //#line 1331 "x10/regionarray/Array.x10"
            final long t$141580 = this.min0;
            
            //#line 1331 "x10/regionarray/Array.x10"
            final long t$141581 = other.min0;
            
            //#line 1331 "x10/regionarray/Array.x10"
            boolean t$141585 = ((long) t$141580) == ((long) t$141581);
            
            //#line 1331 "x10/regionarray/Array.x10"
            if (t$141585) {
                
                //#line 1331 "x10/regionarray/Array.x10"
                final long t$141583 = this.stride1;
                
                //#line 1331 "x10/regionarray/Array.x10"
                final long t$141584 = other.stride1;
                
                //#line 1331 "x10/regionarray/Array.x10"
                t$141585 = ((long) t$141583) == ((long) t$141584);
            }
            
            //#line 1331 "x10/regionarray/Array.x10"
            boolean t$141589 = t$141585;
            
            //#line 1331 "x10/regionarray/Array.x10"
            if (t$141585) {
                
                //#line 1331 "x10/regionarray/Array.x10"
                final long t$141587 = this.min1;
                
                //#line 1331 "x10/regionarray/Array.x10"
                final long t$141588 = other.min1;
                
                //#line 1331 "x10/regionarray/Array.x10"
                t$141589 = ((long) t$141587) == ((long) t$141588);
            }
            
            //#line 1331 "x10/regionarray/Array.x10"
            boolean t$141593 = t$141589;
            
            //#line 1331 "x10/regionarray/Array.x10"
            if (t$141589) {
                
                //#line 1331 "x10/regionarray/Array.x10"
                final long t$141591 = this.size;
                
                //#line 1331 "x10/regionarray/Array.x10"
                final long t$141592 = other.size;
                
                //#line 1331 "x10/regionarray/Array.x10"
                t$141593 = ((long) t$141591) == ((long) t$141592);
            }
            
            //#line 1331 "x10/regionarray/Array.x10"
            boolean t$141597 = t$141593;
            
            //#line 1331 "x10/regionarray/Array.x10"
            if (t$141593) {
                
                //#line 1331 "x10/regionarray/Array.x10"
                final x10.core.Rail t$141595 = ((x10.core.Rail)(this.layout));
                
                //#line 1331 "x10/regionarray/Array.x10"
                final x10.core.Rail t$141596 = ((x10.core.Rail)(other.layout));
                
                //#line 1331 "x10/regionarray/Array.x10"
                t$141597 = x10.rtt.Equality.equalsequals((t$141595),(t$141596));
            }
            
            //#line 1331 "x10/regionarray/Array.x10"
            return t$141597;
        }
        
        
        //#line 1331 "x10/regionarray/Array.x10"
        final public x10.regionarray.Array.LayoutHelper x10$regionarray$Array$LayoutHelper$$this$x10$regionarray$Array$LayoutHelper() {
            
            //#line 1331 "x10/regionarray/Array.x10"
            return x10.regionarray.Array.LayoutHelper.this;
        }
        
        
        //#line 1331 "x10/regionarray/Array.x10"
        final public void __fieldInitializers_x10_regionarray_Array_LayoutHelper() {
            
        }
    }
    
    
    
    //#line 55 "x10/regionarray/Array.x10"
    final public x10.regionarray.Array x10$regionarray$Array$$this$x10$regionarray$Array() {
        
        //#line 55 "x10/regionarray/Array.x10"
        return x10.regionarray.Array.this;
    }
    
    
    //#line 55 "x10/regionarray/Array.x10"
    final public void __fieldInitializers_x10_regionarray_Array() {
        
    }
    
    
    //#line 414 "x10/regionarray/Array.x10"
    @x10.runtime.impl.java.X10Generated
    final public static class Anonymous$14235<$T> extends x10.core.Ref implements x10.lang.Iterable, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<Anonymous$14235> $RTT = 
            x10.rtt.NamedType.<Anonymous$14235> make("x10.regionarray.Array.Anonymous$14235",
                                                     Anonymous$14235.class,
                                                     1,
                                                     new x10.rtt.Type[] {
                                                         x10.rtt.ParameterizedType.make(x10.lang.Iterable.$RTT, x10.rtt.UnresolvedType.PARAM(0))
                                                     });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { if (i == 0) return $T; return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static <$T> x10.serialization.X10JavaSerializable $_deserialize_body(x10.regionarray.Array.Anonymous$14235<$T> $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            $_obj.$T = (x10.rtt.Type) $deserializer.readObject();
            $_obj.out$ = $deserializer.readObject();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.regionarray.Array.Anonymous$14235 $_obj = new x10.regionarray.Array.Anonymous$14235((java.lang.System[]) null, (x10.rtt.Type) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            $serializer.write(this.$T);
            $serializer.write(this.out$);
            
        }
        
        // constructor just for allocation
        public Anonymous$14235(final java.lang.System[] $dummy, final x10.rtt.Type $T) {
            x10.regionarray.Array.Anonymous$14235.$initParams(this, $T);
            
        }
        
        private x10.rtt.Type $T;
        
        // initializer of type parameters
        public static void $initParams(final Anonymous$14235 $this, final x10.rtt.Type $T) {
            $this.$T = $T;
            
        }
        // synthetic type for parameter mangling
        public static final class __0$1x10$regionarray$Array$Anonymous$14235$$T$2 {}
        
    
        
        //#line 55 "x10/regionarray/Array.x10"
        public x10.regionarray.Array<$T> out$;
        
        
        //#line 415 "x10/regionarray/Array.x10"
        public x10.regionarray.Array.Anonymous$14235.Anonymous$14292 iterator() {
            
            //#line 415 "x10/regionarray/Array.x10"
            final x10.regionarray.Array.Anonymous$14235.Anonymous$14292 alloc$138544 = ((x10.regionarray.Array.Anonymous$14235.Anonymous$14292)(new x10.regionarray.Array.Anonymous$14235.Anonymous$14292<$T>((java.lang.System[]) null, $T)));
            
            //#line 415 "x10/regionarray/Array.x10"
            final x10.regionarray.Array.Anonymous$14235 out$139768 = ((x10.regionarray.Array.Anonymous$14235)(this));
            
            //#line 414 . "x10/regionarray/Array.x10"
            ((x10.regionarray.Array.Anonymous$14235.Anonymous$14292<$T>)alloc$138544).out$ = out$139768;
            
            //#line 415 "x10/regionarray/Array.x10"
            return alloc$138544;
        }
        
        
        //#line 414 "x10/regionarray/Array.x10"
        // creation method for java code (1-phase java constructor)
        public Anonymous$14235(final x10.rtt.Type $T, final x10.regionarray.Array<$T> out$, __0$1x10$regionarray$Array$Anonymous$14235$$T$2 $dummy) {
            this((java.lang.System[]) null, $T);
            x10$regionarray$Array$Anonymous$14235$$init$S(out$, (x10.regionarray.Array.Anonymous$14235.__0$1x10$regionarray$Array$Anonymous$14235$$T$2) null);
        }
        
        // constructor for non-virtual call
        final public x10.regionarray.Array.Anonymous$14235<$T> x10$regionarray$Array$Anonymous$14235$$init$S(final x10.regionarray.Array<$T> out$, __0$1x10$regionarray$Array$Anonymous$14235$$T$2 $dummy) {
             {
                
                //#line 55 "x10/regionarray/Array.x10"
                ((x10.regionarray.Array.Anonymous$14235<$T>)this).out$ = out$;
            }
            return this;
        }
        
        
        
        //#line 415 "x10/regionarray/Array.x10"
        @x10.runtime.impl.java.X10Generated
        final public static class Anonymous$14292<$T> extends x10.core.Ref implements x10.lang.Iterator, x10.serialization.X10JavaSerializable
        {
            public static final x10.rtt.RuntimeType<Anonymous$14292> $RTT = 
                x10.rtt.NamedType.<Anonymous$14292> make("x10.regionarray.Array.Anonymous$14235.Anonymous$14292",
                                                         Anonymous$14292.class,
                                                         1,
                                                         new x10.rtt.Type[] {
                                                             x10.rtt.ParameterizedType.make(x10.lang.Iterator.$RTT, x10.rtt.UnresolvedType.PARAM(0))
                                                         });
            
            public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
            
            public x10.rtt.Type<?> $getParam(int i) { if (i == 0) return $T; return null; }
            
            private Object writeReplace() throws java.io.ObjectStreamException {
                return new x10.serialization.SerializationProxy(this);
            }
            
            public static <$T> x10.serialization.X10JavaSerializable $_deserialize_body(x10.regionarray.Array.Anonymous$14235.Anonymous$14292<$T> $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
                $_obj.$T = (x10.rtt.Type) $deserializer.readObject();
                $_obj.cur = $deserializer.readLong();
                $_obj.out$ = $deserializer.readObject();
                return $_obj;
            }
            
            public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
                x10.regionarray.Array.Anonymous$14235.Anonymous$14292 $_obj = new x10.regionarray.Array.Anonymous$14235.Anonymous$14292((java.lang.System[]) null, (x10.rtt.Type) null);
                $deserializer.record_reference($_obj);
                return $_deserialize_body($_obj, $deserializer);
            }
            
            public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
                $serializer.write(this.$T);
                $serializer.write(this.cur);
                $serializer.write(this.out$);
                
            }
            
            // constructor just for allocation
            public Anonymous$14292(final java.lang.System[] $dummy, final x10.rtt.Type $T) {
                x10.regionarray.Array.Anonymous$14235.Anonymous$14292.$initParams(this, $T);
                
            }
            
            private x10.rtt.Type $T;
            
            // initializer of type parameters
            public static void $initParams(final Anonymous$14292 $this, final x10.rtt.Type $T) {
                $this.$T = $T;
                
            }
            // synthetic type for parameter mangling
            public static final class __0$1x10$regionarray$Array$Anonymous$14235$Anonymous$14292$$T$2 {}
            
        
            
            //#line 414 "x10/regionarray/Array.x10"
            public x10.regionarray.Array.Anonymous$14235<$T> out$;
            
            //#line 416 "x10/regionarray/Array.x10"
            public long cur = 0L;
            
            
            //#line 417 "x10/regionarray/Array.x10"
            public $T next$G() {
                
                //#line 417 "x10/regionarray/Array.x10"
                final x10.regionarray.Array.Anonymous$14235 t$141599 = this.out$;
                
                //#line 417 "x10/regionarray/Array.x10"
                final x10.regionarray.Array t$141600 = ((x10.regionarray.Array.Anonymous$14235<$T>)t$141599).out$;
                
                //#line 417 "x10/regionarray/Array.x10"
                final x10.core.Rail t$141604 = ((x10.core.Rail)(((x10.regionarray.Array<$T>)t$141600).raw));
                
                //#line 417 "x10/regionarray/Array.x10"
                final long t$141601 = this.cur;
                
                //#line 417 "x10/regionarray/Array.x10"
                final long t$141602 = ((t$141601) + (((long)(1L))));
                
                //#line 417 "x10/regionarray/Array.x10"
                final long t$141603 = ((x10.regionarray.Array.Anonymous$14235.Anonymous$14292<$T>)this).cur = t$141602;
                
                //#line 417 "x10/regionarray/Array.x10"
                final long t$141605 = ((t$141603) - (((long)(1L))));
                
                //#line 417 "x10/regionarray/Array.x10"
                final $T t$141606 = (($T)(((x10.core.Rail<$T>)t$141604).$apply$G((long)(t$141605))));
                
                //#line 417 "x10/regionarray/Array.x10"
                return t$141606;
            }
            
            
            //#line 418 "x10/regionarray/Array.x10"
            public boolean hasNext$O() {
                
                //#line 418 "x10/regionarray/Array.x10"
                final long t$141610 = this.cur;
                
                //#line 418 "x10/regionarray/Array.x10"
                final x10.regionarray.Array.Anonymous$14235 t$141607 = this.out$;
                
                //#line 418 "x10/regionarray/Array.x10"
                final x10.regionarray.Array t$141608 = ((x10.regionarray.Array.Anonymous$14235<$T>)t$141607).out$;
                
                //#line 418 "x10/regionarray/Array.x10"
                final x10.core.Rail t$141609 = ((x10.core.Rail)(((x10.regionarray.Array<$T>)t$141608).raw));
                
                //#line 418 "x10/regionarray/Array.x10"
                final long t$141611 = ((x10.core.Rail<$T>)t$141609).size;
                
                //#line 418 "x10/regionarray/Array.x10"
                final boolean t$141612 = ((t$141610) < (((long)(t$141611))));
                
                //#line 418 "x10/regionarray/Array.x10"
                return t$141612;
            }
            
            
            //#line 415 "x10/regionarray/Array.x10"
            // creation method for java code (1-phase java constructor)
            public Anonymous$14292(final x10.rtt.Type $T, final x10.regionarray.Array.Anonymous$14235<$T> out$, __0$1x10$regionarray$Array$Anonymous$14235$Anonymous$14292$$T$2 $dummy) {
                this((java.lang.System[]) null, $T);
                x10$regionarray$Array$Anonymous$14235$Anonymous$14292$$init$S(out$, (x10.regionarray.Array.Anonymous$14235.Anonymous$14292.__0$1x10$regionarray$Array$Anonymous$14235$Anonymous$14292$$T$2) null);
            }
            
            // constructor for non-virtual call
            final public x10.regionarray.Array.Anonymous$14235.Anonymous$14292<$T> x10$regionarray$Array$Anonymous$14235$Anonymous$14292$$init$S(final x10.regionarray.Array.Anonymous$14235<$T> out$, __0$1x10$regionarray$Array$Anonymous$14235$Anonymous$14292$$T$2 $dummy) {
                 {
                    
                    //#line 414 "x10/regionarray/Array.x10"
                    ((x10.regionarray.Array.Anonymous$14235.Anonymous$14292<$T>)this).out$ = out$;
                }
                return this;
            }
            
        }
        
    }
    
    
    //#line 422 "x10/regionarray/Array.x10"
    @x10.runtime.impl.java.X10Generated
    final public static class Anonymous$14520<$T> extends x10.core.Ref implements x10.lang.Iterable, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<Anonymous$14520> $RTT = 
            x10.rtt.NamedType.<Anonymous$14520> make("x10.regionarray.Array.Anonymous$14520",
                                                     Anonymous$14520.class,
                                                     1,
                                                     new x10.rtt.Type[] {
                                                         x10.rtt.ParameterizedType.make(x10.lang.Iterable.$RTT, x10.rtt.UnresolvedType.PARAM(0))
                                                     });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { if (i == 0) return $T; return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static <$T> x10.serialization.X10JavaSerializable $_deserialize_body(x10.regionarray.Array.Anonymous$14520<$T> $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            $_obj.$T = (x10.rtt.Type) $deserializer.readObject();
            $_obj.out$ = $deserializer.readObject();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.regionarray.Array.Anonymous$14520 $_obj = new x10.regionarray.Array.Anonymous$14520((java.lang.System[]) null, (x10.rtt.Type) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            $serializer.write(this.$T);
            $serializer.write(this.out$);
            
        }
        
        // constructor just for allocation
        public Anonymous$14520(final java.lang.System[] $dummy, final x10.rtt.Type $T) {
            x10.regionarray.Array.Anonymous$14520.$initParams(this, $T);
            
        }
        
        private x10.rtt.Type $T;
        
        // initializer of type parameters
        public static void $initParams(final Anonymous$14520 $this, final x10.rtt.Type $T) {
            $this.$T = $T;
            
        }
        // synthetic type for parameter mangling
        public static final class __0$1x10$regionarray$Array$Anonymous$14520$$T$2 {}
        
    
        
        //#line 55 "x10/regionarray/Array.x10"
        public x10.regionarray.Array<$T> out$;
        
        
        //#line 423 "x10/regionarray/Array.x10"
        public x10.regionarray.Array.Anonymous$14520.Anonymous$14577 iterator() {
            
            //#line 423 "x10/regionarray/Array.x10"
            final x10.regionarray.Array.Anonymous$14520.Anonymous$14577 alloc$138545 = ((x10.regionarray.Array.Anonymous$14520.Anonymous$14577)(new x10.regionarray.Array.Anonymous$14520.Anonymous$14577<$T>((java.lang.System[]) null, $T)));
            
            //#line 423 "x10/regionarray/Array.x10"
            alloc$138545.x10$regionarray$Array$Anonymous$14520$Anonymous$14577$$init$S(this, (x10.regionarray.Array.Anonymous$14520.Anonymous$14577.__0$1x10$regionarray$Array$Anonymous$14520$Anonymous$14577$$T$2) null);
            
            //#line 423 "x10/regionarray/Array.x10"
            return alloc$138545;
        }
        
        
        //#line 422 "x10/regionarray/Array.x10"
        // creation method for java code (1-phase java constructor)
        public Anonymous$14520(final x10.rtt.Type $T, final x10.regionarray.Array<$T> out$, __0$1x10$regionarray$Array$Anonymous$14520$$T$2 $dummy) {
            this((java.lang.System[]) null, $T);
            x10$regionarray$Array$Anonymous$14520$$init$S(out$, (x10.regionarray.Array.Anonymous$14520.__0$1x10$regionarray$Array$Anonymous$14520$$T$2) null);
        }
        
        // constructor for non-virtual call
        final public x10.regionarray.Array.Anonymous$14520<$T> x10$regionarray$Array$Anonymous$14520$$init$S(final x10.regionarray.Array<$T> out$, __0$1x10$regionarray$Array$Anonymous$14520$$T$2 $dummy) {
             {
                
                //#line 55 "x10/regionarray/Array.x10"
                ((x10.regionarray.Array.Anonymous$14520<$T>)this).out$ = out$;
            }
            return this;
        }
        
        
        
        //#line 423 "x10/regionarray/Array.x10"
        @x10.runtime.impl.java.X10Generated
        final public static class Anonymous$14577<$T> extends x10.core.Ref implements x10.lang.Iterator, x10.serialization.X10JavaSerializable
        {
            public static final x10.rtt.RuntimeType<Anonymous$14577> $RTT = 
                x10.rtt.NamedType.<Anonymous$14577> make("x10.regionarray.Array.Anonymous$14520.Anonymous$14577",
                                                         Anonymous$14577.class,
                                                         1,
                                                         new x10.rtt.Type[] {
                                                             x10.rtt.ParameterizedType.make(x10.lang.Iterator.$RTT, x10.rtt.UnresolvedType.PARAM(0))
                                                         });
            
            public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
            
            public x10.rtt.Type<?> $getParam(int i) { if (i == 0) return $T; return null; }
            
            private Object writeReplace() throws java.io.ObjectStreamException {
                return new x10.serialization.SerializationProxy(this);
            }
            
            public static <$T> x10.serialization.X10JavaSerializable $_deserialize_body(x10.regionarray.Array.Anonymous$14520.Anonymous$14577<$T> $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
                $_obj.$T = (x10.rtt.Type) $deserializer.readObject();
                $_obj.out$ = $deserializer.readObject();
                $_obj.regIt = $deserializer.readObject();
                return $_obj;
            }
            
            public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
                x10.regionarray.Array.Anonymous$14520.Anonymous$14577 $_obj = new x10.regionarray.Array.Anonymous$14520.Anonymous$14577((java.lang.System[]) null, (x10.rtt.Type) null);
                $deserializer.record_reference($_obj);
                return $_deserialize_body($_obj, $deserializer);
            }
            
            public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
                $serializer.write(this.$T);
                $serializer.write(this.out$);
                $serializer.write(this.regIt);
                
            }
            
            // constructor just for allocation
            public Anonymous$14577(final java.lang.System[] $dummy, final x10.rtt.Type $T) {
                x10.regionarray.Array.Anonymous$14520.Anonymous$14577.$initParams(this, $T);
                
            }
            
            private x10.rtt.Type $T;
            
            // initializer of type parameters
            public static void $initParams(final Anonymous$14577 $this, final x10.rtt.Type $T) {
                $this.$T = $T;
                
            }
            // synthetic type for parameter mangling
            public static final class __0$1x10$regionarray$Array$Anonymous$14520$Anonymous$14577$$T$2 {}
            
        
            
            //#line 422 "x10/regionarray/Array.x10"
            public x10.regionarray.Array.Anonymous$14520<$T> out$;
            
            //#line 424 "x10/regionarray/Array.x10"
            public x10.lang.Iterator<x10.lang.Point> regIt;
            
            
            //#line 425 "x10/regionarray/Array.x10"
            public $T next$G() {
                
                //#line 425 "x10/regionarray/Array.x10"
                final x10.regionarray.Array.Anonymous$14520 t$141613 = this.out$;
                
                //#line 425 "x10/regionarray/Array.x10"
                final x10.regionarray.Array this$139771 = ((x10.regionarray.Array.Anonymous$14520<$T>)t$141613).out$;
                
                //#line 425 "x10/regionarray/Array.x10"
                final x10.lang.Iterator t$141614 = ((x10.lang.Iterator)(this.regIt));
                
                //#line 425 "x10/regionarray/Array.x10"
                final x10.lang.Point pt$139770 = ((x10.lang.Point)(((x10.lang.Iterator<x10.lang.Point>)t$141614).next$G()));
                
                //#line 524 . "x10/regionarray/Array.x10"
                final x10.regionarray.Region t$141615 = ((x10.regionarray.Region)(((x10.regionarray.Array<$T>)this$139771).region));
                
                //#line 524 . "x10/regionarray/Array.x10"
                final boolean t$141616 = t$141615.contains$O(((x10.lang.Point)(pt$139770)));
                
                //#line 524 . "x10/regionarray/Array.x10"
                final boolean t$141617 = !(t$141616);
                
                //#line 524 . "x10/regionarray/Array.x10"
                if (t$141617) {
                    
                    //#line 525 . "x10/regionarray/Array.x10"
                    x10.regionarray.Array.raiseBoundsError(((x10.lang.Point)(pt$139770)));
                }
                
                //#line 527 . "x10/regionarray/Array.x10"
                final x10.core.Rail t$141650 = ((x10.core.Rail)(((x10.regionarray.Array<$T>)this$139771).raw));
                
                //#line 1315 .. "x10/regionarray/Array.x10"
                final long t$141618 = ((long)(((int)(0))));
                
                //#line 1315 .. "x10/regionarray/Array.x10"
                final long t$141619 = pt$139770.$apply$O((long)(t$141618));
                
                //#line 1315 .. "x10/regionarray/Array.x10"
                final long t$141620 = ((x10.regionarray.Array<$T>)this$139771).layout_min0;
                
                //#line 1315 .. "x10/regionarray/Array.x10"
                long offset$139774 = ((t$141619) - (((long)(t$141620))));
                
                //#line 1316 .. "x10/regionarray/Array.x10"
                final long t$141621 = pt$139770.rank;
                
                //#line 1316 .. "x10/regionarray/Array.x10"
                final boolean t$141649 = ((t$141621) > (((long)(1L))));
                
                //#line 1316 .. "x10/regionarray/Array.x10"
                if (t$141649) {
                    
                    //#line 1317 .. "x10/regionarray/Array.x10"
                    final long t$141623 = ((x10.regionarray.Array<$T>)this$139771).layout_stride1;
                    
                    //#line 1317 .. "x10/regionarray/Array.x10"
                    final long t$141624 = ((offset$139774) * (((long)(t$141623))));
                    
                    //#line 1317 .. "x10/regionarray/Array.x10"
                    final long t$141625 = pt$139770.$apply$O((long)(1L));
                    
                    //#line 1317 .. "x10/regionarray/Array.x10"
                    final long t$141626 = ((t$141624) + (((long)(t$141625))));
                    
                    //#line 1317 .. "x10/regionarray/Array.x10"
                    final long t$141627 = ((x10.regionarray.Array<$T>)this$139771).layout_min1;
                    
                    //#line 1317 .. "x10/regionarray/Array.x10"
                    final long t$141628 = ((t$141626) - (((long)(t$141627))));
                    
                    //#line 1317 .. "x10/regionarray/Array.x10"
                    offset$139774 = t$141628;
                    
                    //#line 1318 .. "x10/regionarray/Array.x10"
                    final long t$143155 = pt$139770.rank;
                    
                    //#line 1318 .. "x10/regionarray/Array.x10"
                    final long i$138773max$143156 = ((t$143155) - (((long)(1L))));
                    
                    //#line 1318 .. "x10/regionarray/Array.x10"
                    long i$143152 = 2L;
                    
                    //#line 1318 .. "x10/regionarray/Array.x10"
                    for (;
                         true;
                         ) {
                        
                        //#line 1318 .. "x10/regionarray/Array.x10"
                        final boolean t$143154 = ((i$143152) <= (((long)(i$138773max$143156))));
                        
                        //#line 1318 .. "x10/regionarray/Array.x10"
                        if (!(t$143154)) {
                            
                            //#line 1318 .. "x10/regionarray/Array.x10"
                            break;
                        }
                        
                        //#line 1319 .. "x10/regionarray/Array.x10"
                        final x10.core.Rail t$143136 = ((x10.core.Rail)(((x10.regionarray.Array<$T>)this$139771).layout));
                        
                        //#line 1319 .. "x10/regionarray/Array.x10"
                        final long t$143137 = ((i$143152) - (((long)(2L))));
                        
                        //#line 1319 .. "x10/regionarray/Array.x10"
                        final long t$143138 = ((2L) * (((long)(t$143137))));
                        
                        //#line 1319 .. "x10/regionarray/Array.x10"
                        final long t$143139 = ((long[])t$143136.value)[(int)t$143138];
                        
                        //#line 1319 .. "x10/regionarray/Array.x10"
                        final long t$143140 = ((offset$139774) * (((long)(t$143139))));
                        
                        //#line 1319 .. "x10/regionarray/Array.x10"
                        final long t$143141 = pt$139770.$apply$O((long)(i$143152));
                        
                        //#line 1319 .. "x10/regionarray/Array.x10"
                        final long t$143142 = ((t$143140) + (((long)(t$143141))));
                        
                        //#line 1319 .. "x10/regionarray/Array.x10"
                        final x10.core.Rail t$143143 = ((x10.core.Rail)(((x10.regionarray.Array<$T>)this$139771).layout));
                        
                        //#line 1319 .. "x10/regionarray/Array.x10"
                        final long t$143144 = ((i$143152) - (((long)(2L))));
                        
                        //#line 1319 .. "x10/regionarray/Array.x10"
                        final long t$143145 = ((2L) * (((long)(t$143144))));
                        
                        //#line 1319 .. "x10/regionarray/Array.x10"
                        final long t$143146 = ((t$143145) + (((long)(1L))));
                        
                        //#line 1319 .. "x10/regionarray/Array.x10"
                        final long t$143147 = ((long[])t$143143.value)[(int)t$143146];
                        
                        //#line 1319 .. "x10/regionarray/Array.x10"
                        final long t$143148 = ((t$143142) - (((long)(t$143147))));
                        
                        //#line 1319 .. "x10/regionarray/Array.x10"
                        offset$139774 = t$143148;
                        
                        //#line 1318 .. "x10/regionarray/Array.x10"
                        final long t$143151 = ((i$143152) + (((long)(1L))));
                        
                        //#line 1318 .. "x10/regionarray/Array.x10"
                        i$143152 = t$143151;
                    }
                }
                
                //#line 527 . "x10/regionarray/Array.x10"
                final $T t$141652 = (($T)(((x10.core.Rail<$T>)t$141650).$apply$G((long)(offset$139774))));
                
                //#line 425 "x10/regionarray/Array.x10"
                return t$141652;
            }
            
            
            //#line 426 "x10/regionarray/Array.x10"
            public boolean hasNext$O() {
                
                //#line 426 "x10/regionarray/Array.x10"
                final x10.lang.Iterator t$141653 = ((x10.lang.Iterator)(this.regIt));
                
                //#line 426 "x10/regionarray/Array.x10"
                final boolean t$141654 = ((x10.lang.Iterator<x10.lang.Point>)t$141653).hasNext$O();
                
                //#line 426 "x10/regionarray/Array.x10"
                return t$141654;
            }
            
            
            //#line 423 "x10/regionarray/Array.x10"
            // creation method for java code (1-phase java constructor)
            public Anonymous$14577(final x10.rtt.Type $T, final x10.regionarray.Array.Anonymous$14520<$T> out$, __0$1x10$regionarray$Array$Anonymous$14520$Anonymous$14577$$T$2 $dummy) {
                this((java.lang.System[]) null, $T);
                x10$regionarray$Array$Anonymous$14520$Anonymous$14577$$init$S(out$, (x10.regionarray.Array.Anonymous$14520.Anonymous$14577.__0$1x10$regionarray$Array$Anonymous$14520$Anonymous$14577$$T$2) null);
            }
            
            // constructor for non-virtual call
            final public x10.regionarray.Array.Anonymous$14520.Anonymous$14577<$T> x10$regionarray$Array$Anonymous$14520$Anonymous$14577$$init$S(final x10.regionarray.Array.Anonymous$14520<$T> out$, __0$1x10$regionarray$Array$Anonymous$14520$Anonymous$14577$$T$2 $dummy) {
                 {
                    
                    //#line 422 "x10/regionarray/Array.x10"
                    ((x10.regionarray.Array.Anonymous$14520.Anonymous$14577<$T>)this).out$ = out$;
                    
                    //#line 424 "x10/regionarray/Array.x10"
                    final x10.regionarray.Array.Anonymous$14520 t$141655 = this.out$;
                    
                    //#line 424 "x10/regionarray/Array.x10"
                    final x10.regionarray.Array this$139780 = ((x10.regionarray.Array.Anonymous$14520<$T>)t$141655).out$;
                    
                    //#line 404 . "x10/regionarray/Array.x10"
                    final x10.regionarray.Region t$141656 = ((x10.regionarray.Region)(((x10.regionarray.Array<$T>)this$139780).region));
                    
                    //#line 404 . "x10/regionarray/Array.x10"
                    final x10.lang.Iterator t$141657 = t$141656.iterator();
                    
                    //#line 424 "x10/regionarray/Array.x10"
                    ((x10.regionarray.Array.Anonymous$14520.Anonymous$14577<$T>)this).regIt = ((x10.lang.Iterator)(t$141657));
                }
                return this;
            }
            
        }
        
    }
    
    @x10.runtime.impl.java.X10Generated
    final public static class $Closure$202<$T> extends x10.core.Ref implements x10.core.fun.Fun_0_0, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<$Closure$202> $RTT = 
            x10.rtt.StaticFunType.<$Closure$202> make($Closure$202.class,
                                                      1,
                                                      new x10.rtt.Type[] {
                                                          x10.rtt.ParameterizedType.make(x10.core.fun.Fun_0_0.$RTT, x10.rtt.Types.LONG)
                                                      });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { if (i == 0) return $T; return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static <$T> x10.serialization.X10JavaSerializable $_deserialize_body(x10.regionarray.Array.$Closure$202<$T> $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            $_obj.$T = (x10.rtt.Type) $deserializer.readObject();
            $_obj.dstPoint = $deserializer.readObject();
            $_obj.gra = $deserializer.readObject();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.regionarray.Array.$Closure$202 $_obj = new x10.regionarray.Array.$Closure$202((java.lang.System[]) null, (x10.rtt.Type) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            $serializer.write(this.$T);
            $serializer.write(this.dstPoint);
            $serializer.write(this.gra);
            
        }
        
        // constructor just for allocation
        public $Closure$202(final java.lang.System[] $dummy, final x10.rtt.Type $T) {
            x10.regionarray.Array.$Closure$202.$initParams(this, $T);
            
        }
        
        // bridge for method abstract public ()=>U.operator()():U
        public x10.core.Long $apply$G() {
            return x10.core.Long.$box($apply$O());
        }
        
        private x10.rtt.Type $T;
        
        // initializer of type parameters
        public static void $initParams(final $Closure$202 $this, final x10.rtt.Type $T) {
            $this.$T = $T;
            
        }
        // synthetic type for parameter mangling
        public static final class __0$1x10$regionarray$Array$1x10$regionarray$Array$$Closure$202$$T$2$2 {}
        
    
        
        public long $apply$O() {
            
            //#line 938 "x10/regionarray/Array.x10"
            try {{
                
                //#line 938 "x10/regionarray/Array.x10"
                final x10.regionarray.Array t$136658 = (((x10.core.GlobalRef<x10.regionarray.Array<$T>>)(this.gra))).$apply$G();
                
                //#line 938 "x10/regionarray/Array.x10"
                final x10.regionarray.Region t$136659 = ((x10.regionarray.Region)(((x10.regionarray.Array<$T>)t$136658).region));
                
                //#line 938 "x10/regionarray/Array.x10"
                final long t$136660 = t$136659.indexOf$O(((x10.lang.Point)(this.dstPoint)));
                
                //#line 938 "x10/regionarray/Array.x10"
                return t$136660;
            }}catch (java.lang.Throwable __lowerer__var__0__) {
                
                //#line 938 "x10/regionarray/Array.x10"
                long __lowerer__var__1__ = (x10.core.Long.$unbox(x10.xrx.Runtime.<x10.core.Long> wrapAtChecked$G(x10.rtt.Types.LONG, ((java.lang.Throwable)(__lowerer__var__0__)))));
                
                //#line 938 "x10/regionarray/Array.x10"
                return __lowerer__var__1__;
            }
        }
        
        public x10.core.GlobalRef<x10.regionarray.Array<$T>> gra;
        public x10.lang.Point dstPoint;
        
        public $Closure$202(final x10.rtt.Type $T, final x10.core.GlobalRef<x10.regionarray.Array<$T>> gra, final x10.lang.Point dstPoint, __0$1x10$regionarray$Array$1x10$regionarray$Array$$Closure$202$$T$2$2 $dummy) {
            x10.regionarray.Array.$Closure$202.$initParams(this, $T);
             {
                ((x10.regionarray.Array.$Closure$202<$T>)this).gra = ((x10.core.GlobalRef)(gra));
                ((x10.regionarray.Array.$Closure$202<$T>)this).dstPoint = ((x10.lang.Point)(dstPoint));
            }
        }
        
    }
    
    @x10.runtime.impl.java.X10Generated
    final public static class $Closure$203<$T> extends x10.core.Ref implements x10.core.fun.Fun_0_0, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<$Closure$203> $RTT = 
            x10.rtt.StaticFunType.<$Closure$203> make($Closure$203.class,
                                                      1,
                                                      new x10.rtt.Type[] {
                                                          x10.rtt.ParameterizedType.make(x10.core.fun.Fun_0_0.$RTT, x10.rtt.Types.LONG)
                                                      });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { if (i == 0) return $T; return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static <$T> x10.serialization.X10JavaSerializable $_deserialize_body(x10.regionarray.Array.$Closure$203<$T> $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            $_obj.$T = (x10.rtt.Type) $deserializer.readObject();
            $_obj.gra = $deserializer.readObject();
            $_obj.srcPoint = $deserializer.readObject();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.regionarray.Array.$Closure$203 $_obj = new x10.regionarray.Array.$Closure$203((java.lang.System[]) null, (x10.rtt.Type) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            $serializer.write(this.$T);
            $serializer.write(this.gra);
            $serializer.write(this.srcPoint);
            
        }
        
        // constructor just for allocation
        public $Closure$203(final java.lang.System[] $dummy, final x10.rtt.Type $T) {
            x10.regionarray.Array.$Closure$203.$initParams(this, $T);
            
        }
        
        // bridge for method abstract public ()=>U.operator()():U
        public x10.core.Long $apply$G() {
            return x10.core.Long.$box($apply$O());
        }
        
        private x10.rtt.Type $T;
        
        // initializer of type parameters
        public static void $initParams(final $Closure$203 $this, final x10.rtt.Type $T) {
            $this.$T = $T;
            
        }
        // synthetic type for parameter mangling
        public static final class __0$1x10$regionarray$Array$1x10$regionarray$Array$$Closure$203$$T$2$2 {}
        
    
        
        public long $apply$O() {
            
            //#line 1041 "x10/regionarray/Array.x10"
            try {{
                
                //#line 1041 "x10/regionarray/Array.x10"
                final x10.regionarray.Array t$136662 = (((x10.core.GlobalRef<x10.regionarray.Array<$T>>)(this.gra))).$apply$G();
                
                //#line 1041 "x10/regionarray/Array.x10"
                final x10.regionarray.Region t$136663 = ((x10.regionarray.Region)(((x10.regionarray.Array<$T>)t$136662).region));
                
                //#line 1041 "x10/regionarray/Array.x10"
                final long t$136664 = t$136663.indexOf$O(((x10.lang.Point)(this.srcPoint)));
                
                //#line 1041 "x10/regionarray/Array.x10"
                return t$136664;
            }}catch (java.lang.Throwable __lowerer__var__0__) {
                
                //#line 1041 "x10/regionarray/Array.x10"
                long __lowerer__var__1__ = (x10.core.Long.$unbox(x10.xrx.Runtime.<x10.core.Long> wrapAtChecked$G(x10.rtt.Types.LONG, ((java.lang.Throwable)(__lowerer__var__0__)))));
                
                //#line 1041 "x10/regionarray/Array.x10"
                return __lowerer__var__1__;
            }
        }
        
        public x10.core.GlobalRef<x10.regionarray.Array<$T>> gra;
        public x10.lang.Point srcPoint;
        
        public $Closure$203(final x10.rtt.Type $T, final x10.core.GlobalRef<x10.regionarray.Array<$T>> gra, final x10.lang.Point srcPoint, __0$1x10$regionarray$Array$1x10$regionarray$Array$$Closure$203$$T$2$2 $dummy) {
            x10.regionarray.Array.$Closure$203.$initParams(this, $T);
             {
                ((x10.regionarray.Array.$Closure$203<$T>)this).gra = ((x10.core.GlobalRef)(gra));
                ((x10.regionarray.Array.$Closure$203<$T>)this).srcPoint = ((x10.lang.Point)(srcPoint));
            }
        }
        
    }
    
}




