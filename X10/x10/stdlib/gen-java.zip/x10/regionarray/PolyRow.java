package x10.regionarray;


/**
 * This class represents a single polyhedral halfspace of the form
 *
 *     a0*x0 + a1*x1 + ... + constant <= 0
 *
 * The a's are stored in the first rank elements of ValRow.this; the
 * constant is stored in this(rank) (using homogeneous coordinates).
 *
 * Equivalently, this class may be considered to represent a linear
 * inequality constraint, or a row in a constraint matrix.
 */
@x10.runtime.impl.java.X10Generated
public class PolyRow extends x10.regionarray.ValRow implements x10.serialization.X10JavaSerializable
{
    public static final x10.rtt.RuntimeType<PolyRow> $RTT = 
        x10.rtt.NamedType.<PolyRow> make("x10.regionarray.PolyRow",
                                         PolyRow.class,
                                         new x10.rtt.Type[] {
                                             x10.regionarray.ValRow.$RTT
                                         });
    
    public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
    
    public x10.rtt.Type<?> $getParam(int i) { return null; }
    
    private Object writeReplace() throws java.io.ObjectStreamException {
        return new x10.serialization.SerializationProxy(this);
    }
    
    public static x10.serialization.X10JavaSerializable $_deserialize_body(x10.regionarray.PolyRow $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
        x10.regionarray.ValRow.$_deserialize_body($_obj, $deserializer);
        $_obj.rank = $deserializer.readLong();
        return $_obj;
    }
    
    public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
        x10.regionarray.PolyRow $_obj = new x10.regionarray.PolyRow((java.lang.System[]) null);
        $deserializer.record_reference($_obj);
        return $_deserialize_body($_obj, $deserializer);
    }
    
    public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
        super.$_serialize($serializer);
        $serializer.write(this.rank);
        
    }
    
    // constructor just for allocation
    public PolyRow(final java.lang.System[] $dummy) {
        super($dummy);
        
    }
    
    // synthetic type for parameter mangling
    public static final class __0$1x10$lang$Int$2 {}
    // synthetic type for parameter mangling
    public static final class __1$1x10$lang$Int$3x10$lang$Int$2 {}
    
    // properties
    
    //#line 27 "x10/regionarray/PolyRow.x10"
    public long rank;
    

    
    
    //#line 29 "x10/regionarray/PolyRow.x10"
    // creation method for java code (1-phase java constructor)
    public PolyRow(final x10.core.Rail<x10.core.Int> as_, __0$1x10$lang$Int$2 $dummy) {
        this((java.lang.System[]) null);
        x10$regionarray$PolyRow$$init$S(as_, (x10.regionarray.PolyRow.__0$1x10$lang$Int$2) null);
    }
    
    // constructor for non-virtual call
    final public x10.regionarray.PolyRow x10$regionarray$PolyRow$$init$S(final x10.core.Rail<x10.core.Int> as_, __0$1x10$lang$Int$2 $dummy) {
         {
            
            //#line 29 "x10/regionarray/PolyRow.x10"
            final long t$155597 = ((x10.core.Rail<x10.core.Int>)as_).size;
            
            //#line 29 "x10/regionarray/PolyRow.x10"
            final long t$155598 = ((t$155597) - (((long)(1L))));
            
            //#line 29 "x10/regionarray/PolyRow.x10"
            /*this.*/x10$regionarray$PolyRow$$init$S(((x10.core.Rail)(as_)), t$155598, (x10.regionarray.PolyRow.__0$1x10$lang$Int$2) null);
        }
        return this;
    }
    
    
    
    //#line 31 "x10/regionarray/PolyRow.x10"
    // creation method for java code (1-phase java constructor)
    public PolyRow(final x10.core.Rail<x10.core.Int> as_, final long n, __0$1x10$lang$Int$2 $dummy) {
        this((java.lang.System[]) null);
        x10$regionarray$PolyRow$$init$S(as_, n, (x10.regionarray.PolyRow.__0$1x10$lang$Int$2) null);
    }
    
    // constructor for non-virtual call
    final public x10.regionarray.PolyRow x10$regionarray$PolyRow$$init$S(final x10.core.Rail<x10.core.Int> as_, final long n, __0$1x10$lang$Int$2 $dummy) {
         {
            
            //#line 32 "x10/regionarray/PolyRow.x10"
            /*super.*/x10$regionarray$ValRow$$init$S(((x10.core.Rail)(as_)), (x10.regionarray.ValRow.__0$1x10$lang$Int$2) null);
            
            //#line 33 "x10/regionarray/PolyRow.x10"
            final long t$155749 = n;
            
            //#line 33 "x10/regionarray/PolyRow.x10"
            this.rank = t$155749;
            
        }
        return this;
    }
    
    
    
    //#line 36 "x10/regionarray/PolyRow.x10"
    // creation method for java code (1-phase java constructor)
    public PolyRow(final x10.lang.Point p, final int k) {
        this((java.lang.System[]) null);
        x10$regionarray$PolyRow$$init$S(p, k);
    }
    
    // constructor for non-virtual call
    final public x10.regionarray.PolyRow x10$regionarray$PolyRow$$init$S(final x10.lang.Point p, final int k) {
         {
            
            //#line 37 "x10/regionarray/PolyRow.x10"
            final long t$155752 = p.rank;
            
            //#line 37 "x10/regionarray/PolyRow.x10"
            final long t$155753 = ((t$155752) + (((long)(1L))));
            
            //#line 37 "x10/regionarray/PolyRow.x10"
            final int t$155754 = ((int)(long)(((long)(t$155753))));
            
            //#line 37 "x10/regionarray/PolyRow.x10"
            final x10.core.fun.Fun_0_1 t$155755 = ((x10.core.fun.Fun_0_1)(new x10.regionarray.PolyRow.$Closure$258(p, k)));
            
            //#line 37 "x10/regionarray/PolyRow.x10"
            /*super.*/x10$regionarray$ValRow$$init$S(t$155754, ((x10.core.fun.Fun_0_1)(t$155755)), (x10.regionarray.ValRow.__1$1x10$lang$Int$3x10$lang$Int$2) null);
            
            //#line 38 "x10/regionarray/PolyRow.x10"
            final long t$155751 = p.rank;
            
            //#line 38 "x10/regionarray/PolyRow.x10"
            this.rank = t$155751;
            
        }
        return this;
    }
    
    
    
    //#line 41 "x10/regionarray/PolyRow.x10"
    // creation method for java code (1-phase java constructor)
    public PolyRow(final int cols, final x10.core.fun.Fun_0_1<x10.core.Int,x10.core.Int> init, __1$1x10$lang$Int$3x10$lang$Int$2 $dummy) {
        this((java.lang.System[]) null);
        x10$regionarray$PolyRow$$init$S(cols, init, (x10.regionarray.PolyRow.__1$1x10$lang$Int$3x10$lang$Int$2) null);
    }
    
    // constructor for non-virtual call
    final public x10.regionarray.PolyRow x10$regionarray$PolyRow$$init$S(final int cols, final x10.core.fun.Fun_0_1<x10.core.Int,x10.core.Int> init, __1$1x10$lang$Int$3x10$lang$Int$2 $dummy) {
         {
            
            //#line 42 "x10/regionarray/PolyRow.x10"
            /*super.*/x10$regionarray$ValRow$$init$S(((int)(cols)), ((x10.core.fun.Fun_0_1)(init)), (x10.regionarray.ValRow.__1$1x10$lang$Int$3x10$lang$Int$2) null);
            
            //#line 43 "x10/regionarray/PolyRow.x10"
            final int cols1 = ((cols) - (((int)(1))));
            
            //#line 44 "x10/regionarray/PolyRow.x10"
            final long t$155765 = ((long)(((int)(cols1))));
            
            //#line 44 "x10/regionarray/PolyRow.x10"
            this.rank = t$155765;
            
        }
        return this;
    }
    
    
    
    //#line 53 "x10/regionarray/PolyRow.x10"
    /**
     * natural sort order for halfspaces: from lo to hi on each
     * axis, from most major to least major axis, with constant as
     * least siginficant part of key
     */
    public static int compare$O(final x10.regionarray.Row a, final x10.regionarray.Row b) {
        
        //#line 54 "x10/regionarray/PolyRow.x10"
        int i$155779 = 0;
        
        //#line 54 "x10/regionarray/PolyRow.x10"
        for (;
             true;
             ) {
            
            //#line 54 "x10/regionarray/PolyRow.x10"
            final int t$155781 = a.cols;
            
            //#line 54 "x10/regionarray/PolyRow.x10"
            final boolean t$155782 = ((i$155779) < (((int)(t$155781))));
            
            //#line 54 "x10/regionarray/PolyRow.x10"
            if (!(t$155782)) {
                
                //#line 54 "x10/regionarray/PolyRow.x10"
                break;
            }
            
            //#line 55 "x10/regionarray/PolyRow.x10"
            final int t$155768 = a.$apply$O((int)(i$155779));
            
            //#line 55 "x10/regionarray/PolyRow.x10"
            final int t$155770 = b.$apply$O((int)(i$155779));
            
            //#line 55 "x10/regionarray/PolyRow.x10"
            final boolean t$155771 = ((t$155768) < (((int)(t$155770))));
            
            //#line 55 "x10/regionarray/PolyRow.x10"
            if (t$155771) {
                
                //#line 56 "x10/regionarray/PolyRow.x10"
                return -1;
            } else {
                
                //#line 57 "x10/regionarray/PolyRow.x10"
                final int t$155773 = a.$apply$O((int)(i$155779));
                
                //#line 57 "x10/regionarray/PolyRow.x10"
                final int t$155775 = b.$apply$O((int)(i$155779));
                
                //#line 57 "x10/regionarray/PolyRow.x10"
                final boolean t$155776 = ((t$155773) > (((int)(t$155775))));
                
                //#line 57 "x10/regionarray/PolyRow.x10"
                if (t$155776) {
                    
                    //#line 58 "x10/regionarray/PolyRow.x10"
                    return 1;
                }
            }
            
            //#line 54 "x10/regionarray/PolyRow.x10"
            final int t$155778 = ((i$155779) + (((int)(1))));
            
            //#line 54 "x10/regionarray/PolyRow.x10"
            i$155779 = t$155778;
        }
        
        //#line 60 "x10/regionarray/PolyRow.x10"
        return 0;
    }
    
    
    //#line 71 "x10/regionarray/PolyRow.x10"
    /**
     * two halfspaces are parallel if all coefficients are the
     * same; constants may differ
     *
     * XXX only right if first coefficients are the same; needs to
     * allow for multiplication by positive constant
     */
    public boolean isParallel$O(final x10.regionarray.PolyRow that) {
        
        //#line 72 "x10/regionarray/PolyRow.x10"
        int i$155790 = 0;
        
        //#line 72 "x10/regionarray/PolyRow.x10"
        for (;
             true;
             ) {
            
            //#line 72 "x10/regionarray/PolyRow.x10"
            final int t$155792 = this.cols;
            
            //#line 72 "x10/regionarray/PolyRow.x10"
            final int t$155793 = ((t$155792) - (((int)(1))));
            
            //#line 72 "x10/regionarray/PolyRow.x10"
            final boolean t$155794 = ((i$155790) < (((int)(t$155793))));
            
            //#line 72 "x10/regionarray/PolyRow.x10"
            if (!(t$155794)) {
                
                //#line 72 "x10/regionarray/PolyRow.x10"
                break;
            }
            
            //#line 73 "x10/regionarray/PolyRow.x10"
            final int t$155784 = this.$apply$O((int)(i$155790));
            
            //#line 73 "x10/regionarray/PolyRow.x10"
            final int t$155786 = that.$apply$O((int)(i$155790));
            
            //#line 73 "x10/regionarray/PolyRow.x10"
            final boolean t$155787 = ((int) t$155784) != ((int) t$155786);
            
            //#line 73 "x10/regionarray/PolyRow.x10"
            if (t$155787) {
                
                //#line 74 "x10/regionarray/PolyRow.x10"
                return false;
            }
            
            //#line 72 "x10/regionarray/PolyRow.x10"
            final int t$155789 = ((i$155790) + (((int)(1))));
            
            //#line 72 "x10/regionarray/PolyRow.x10"
            i$155790 = t$155789;
        }
        
        //#line 75 "x10/regionarray/PolyRow.x10"
        return true;
    }
    
    
    //#line 83 "x10/regionarray/PolyRow.x10"
    /**
     * halfspace is rectangular if only one coefficent is
     * non-zero
     */
    public boolean isRect$O() {
        
        //#line 84 "x10/regionarray/PolyRow.x10"
        boolean nz = false;
        
        //#line 85 "x10/regionarray/PolyRow.x10"
        int i$155801 = 0;
        
        //#line 85 "x10/regionarray/PolyRow.x10"
        for (;
             true;
             ) {
            
            //#line 85 "x10/regionarray/PolyRow.x10"
            final int t$155803 = this.cols;
            
            //#line 85 "x10/regionarray/PolyRow.x10"
            final int t$155804 = ((t$155803) - (((int)(1))));
            
            //#line 85 "x10/regionarray/PolyRow.x10"
            final boolean t$155805 = ((i$155801) < (((int)(t$155804))));
            
            //#line 85 "x10/regionarray/PolyRow.x10"
            if (!(t$155805)) {
                
                //#line 85 "x10/regionarray/PolyRow.x10"
                break;
            }
            
            //#line 86 "x10/regionarray/PolyRow.x10"
            final int t$155796 = this.$apply$O((int)(i$155801));
            
            //#line 86 "x10/regionarray/PolyRow.x10"
            final boolean t$155797 = ((int) t$155796) != ((int) 0);
            
            //#line 86 "x10/regionarray/PolyRow.x10"
            if (t$155797) {
                
                //#line 87 "x10/regionarray/PolyRow.x10"
                if (nz) {
                    
                    //#line 87 "x10/regionarray/PolyRow.x10"
                    return false;
                }
                
                //#line 88 "x10/regionarray/PolyRow.x10"
                nz = true;
            }
            
            //#line 85 "x10/regionarray/PolyRow.x10"
            final int t$155800 = ((i$155801) + (((int)(1))));
            
            //#line 85 "x10/regionarray/PolyRow.x10"
            i$155801 = t$155800;
        }
        
        //#line 91 "x10/regionarray/PolyRow.x10"
        return true;
    }
    
    
    //#line 98 "x10/regionarray/PolyRow.x10"
    /**
     * determine whether point satisfies halfspace
     */
    public boolean contains$O(final x10.lang.Point p) {
        
        //#line 99 "x10/regionarray/PolyRow.x10"
        final long t$155652 = this.rank;
        
        //#line 99 "x10/regionarray/PolyRow.x10"
        final int t$155653 = ((int)(long)(((long)(t$155652))));
        
        //#line 99 "x10/regionarray/PolyRow.x10"
        int sum = this.$apply$O((int)(t$155653));
        
        //#line 100 "x10/regionarray/PolyRow.x10"
        int i$155818 = 0;
        
        //#line 100 "x10/regionarray/PolyRow.x10"
        for (;
             true;
             ) {
            
            //#line 100 "x10/regionarray/PolyRow.x10"
            final long t$155820 = ((long)(((int)(i$155818))));
            
            //#line 100 "x10/regionarray/PolyRow.x10"
            final long t$155821 = this.rank;
            
            //#line 100 "x10/regionarray/PolyRow.x10"
            final boolean t$155822 = ((t$155820) < (((long)(t$155821))));
            
            //#line 100 "x10/regionarray/PolyRow.x10"
            if (!(t$155822)) {
                
                //#line 100 "x10/regionarray/PolyRow.x10"
                break;
            }
            
            //#line 101 "x10/regionarray/PolyRow.x10"
            final long t$155807 = ((long)(((int)(sum))));
            
            //#line 101 "x10/regionarray/PolyRow.x10"
            final int t$155809 = this.$apply$O((int)(i$155818));
            
            //#line 101 "x10/regionarray/PolyRow.x10"
            final long t$155810 = ((long)(((int)(t$155809))));
            
            //#line 101 "x10/regionarray/PolyRow.x10"
            final long t$155812 = ((long)(((int)(i$155818))));
            
            //#line 101 "x10/regionarray/PolyRow.x10"
            final long t$155813 = p.$apply$O((long)(t$155812));
            
            //#line 101 "x10/regionarray/PolyRow.x10"
            final long t$155814 = ((t$155810) * (((long)(t$155813))));
            
            //#line 101 "x10/regionarray/PolyRow.x10"
            final long t$155815 = ((t$155807) + (((long)(t$155814))));
            
            //#line 101 "x10/regionarray/PolyRow.x10"
            sum = ((int)(((long)(t$155815))));
            
            //#line 100 "x10/regionarray/PolyRow.x10"
            final int t$155817 = ((i$155818) + (((int)(1))));
            
            //#line 100 "x10/regionarray/PolyRow.x10"
            i$155818 = t$155817;
        }
        
        //#line 102 "x10/regionarray/PolyRow.x10"
        final boolean t$155672 = ((sum) <= (((int)(0))));
        
        //#line 102 "x10/regionarray/PolyRow.x10"
        return t$155672;
    }
    
    
    //#line 115 "x10/regionarray/PolyRow.x10"
    /**
     * given
     *    a0*x0 + ... +ar   <=  0
     * complement is
     *    a0*x0 + ... +ar   >   0
     *   -a0*x0 - ... -ar   <   0
     *   -a0*x0 - ... -ar   <= -1
     *   -a0*x0 - ... -ar+1 <=  0
     */
    public x10.regionarray.PolyRow complement() {
        
        //#line 117 "x10/regionarray/PolyRow.x10"
        final long t$155673 = this.rank;
        
        //#line 117 "x10/regionarray/PolyRow.x10"
        final long t$155674 = ((long)(((int)(1))));
        
        //#line 117 "x10/regionarray/PolyRow.x10"
        final long t$155687 = ((t$155673) + (((long)(t$155674))));
        
        //#line 116 "x10/regionarray/PolyRow.x10"
        final x10.core.fun.Fun_0_1 t$155688 = ((x10.core.fun.Fun_0_1)(new x10.regionarray.PolyRow.$Closure$259(this, this.rank)));
        
        //#line 117 "x10/regionarray/PolyRow.x10"
        final x10.core.Rail as_ = ((x10.core.Rail)(new x10.core.Rail<x10.core.Int>(x10.rtt.Types.INT, t$155687, ((x10.core.fun.Fun_0_1)(t$155688)), (x10.core.Rail.__1$1x10$lang$Long$3x10$lang$Rail$$T$2) null)));
        
        //#line 118 "x10/regionarray/PolyRow.x10"
        final x10.regionarray.PolyRow alloc$153385 = ((x10.regionarray.PolyRow)(new x10.regionarray.PolyRow((java.lang.System[]) null)));
        
        //#line 29 . "x10/regionarray/PolyRow.x10"
        final long t$155823 = ((x10.core.Rail<x10.core.Int>)as_).size;
        
        //#line 29 . "x10/regionarray/PolyRow.x10"
        final long t$155824 = ((t$155823) - (((long)(1L))));
        
        //#line 29 . "x10/regionarray/PolyRow.x10"
        alloc$153385.x10$regionarray$PolyRow$$init$S(((x10.core.Rail)(as_)), t$155824, (x10.regionarray.PolyRow.__0$1x10$lang$Int$2) null);
        
        //#line 118 "x10/regionarray/PolyRow.x10"
        return alloc$153385;
    }
    
    
    //#line 125 "x10/regionarray/PolyRow.x10"
    /**
     * print a halfspace in equation form
     */
    public void printEqn(final x10.io.Printer ps, final java.lang.String spc, final int row) {
        
        //#line 126 "x10/regionarray/PolyRow.x10"
        int sgn = 0;
        
        //#line 127 "x10/regionarray/PolyRow.x10"
        boolean first = true;
        
        //#line 128 "x10/regionarray/PolyRow.x10"
        int i$155861 = 0;
        
        //#line 128 "x10/regionarray/PolyRow.x10"
        for (;
             true;
             ) {
            
            //#line 128 "x10/regionarray/PolyRow.x10"
            final long t$155863 = ((long)(((int)(i$155861))));
            
            //#line 128 "x10/regionarray/PolyRow.x10"
            final int t$155864 = this.cols;
            
            //#line 128 "x10/regionarray/PolyRow.x10"
            final long t$155865 = ((long)(((int)(t$155864))));
            
            //#line 128 "x10/regionarray/PolyRow.x10"
            final long t$155866 = ((t$155865) - (((long)(1L))));
            
            //#line 128 "x10/regionarray/PolyRow.x10"
            final boolean t$155867 = ((t$155863) < (((long)(t$155866))));
            
            //#line 128 "x10/regionarray/PolyRow.x10"
            if (!(t$155867)) {
                
                //#line 128 "x10/regionarray/PolyRow.x10"
                break;
            }
            
            //#line 129 "x10/regionarray/PolyRow.x10"
            final boolean t$155826 = ((int) sgn) == ((int) 0);
            
            //#line 129 "x10/regionarray/PolyRow.x10"
            if (t$155826) {
                
                //#line 130 "x10/regionarray/PolyRow.x10"
                final int t$155828 = this.$apply$O((int)(i$155861));
                
                //#line 130 "x10/regionarray/PolyRow.x10"
                final boolean t$155829 = ((t$155828) < (((int)(0))));
                
                //#line 130 "x10/regionarray/PolyRow.x10"
                if (t$155829) {
                    
                    //#line 131 "x10/regionarray/PolyRow.x10"
                    sgn = -1;
                } else {
                    
                    //#line 132 "x10/regionarray/PolyRow.x10"
                    final int t$155831 = this.$apply$O((int)(i$155861));
                    
                    //#line 132 "x10/regionarray/PolyRow.x10"
                    final boolean t$155832 = ((t$155831) > (((int)(0))));
                    
                    //#line 132 "x10/regionarray/PolyRow.x10"
                    if (t$155832) {
                        
                        //#line 133 "x10/regionarray/PolyRow.x10"
                        sgn = 1;
                    }
                }
            }
            
            //#line 135 "x10/regionarray/PolyRow.x10"
            final int t$155835 = this.$apply$O((int)(i$155861));
            
            //#line 135 "x10/regionarray/PolyRow.x10"
            final int c$155836 = ((sgn) * (((int)(t$155835))));
            
            //#line 136 "x10/regionarray/PolyRow.x10"
            final boolean t$155837 = ((int) c$155836) == ((int) 1);
            
            //#line 136 "x10/regionarray/PolyRow.x10"
            if (t$155837) {
                
                //#line 137 "x10/regionarray/PolyRow.x10"
                if (first) {
                    
                    //#line 138 "x10/regionarray/PolyRow.x10"
                    final java.lang.String t$155840 = (("x") + ((x10.core.Int.$box(i$155861))));
                    
                    //#line 138 "x10/regionarray/PolyRow.x10"
                    ps.print(((java.lang.String)(t$155840)));
                } else {
                    
                    //#line 140 "x10/regionarray/PolyRow.x10"
                    final java.lang.String t$155842 = (("+x") + ((x10.core.Int.$box(i$155861))));
                    
                    //#line 140 "x10/regionarray/PolyRow.x10"
                    ps.print(((java.lang.String)(t$155842)));
                }
            } else {
                
                //#line 141 "x10/regionarray/PolyRow.x10"
                final boolean t$155843 = ((int) c$155836) == ((int) -1);
                
                //#line 141 "x10/regionarray/PolyRow.x10"
                if (t$155843) {
                    
                    //#line 142 "x10/regionarray/PolyRow.x10"
                    final java.lang.String t$155845 = (("-x") + ((x10.core.Int.$box(i$155861))));
                    
                    //#line 142 "x10/regionarray/PolyRow.x10"
                    ps.print(((java.lang.String)(t$155845)));
                } else {
                    
                    //#line 143 "x10/regionarray/PolyRow.x10"
                    final boolean t$155846 = ((int) c$155836) != ((int) 0);
                    
                    //#line 143 "x10/regionarray/PolyRow.x10"
                    if (t$155846) {
                        
                        //#line 144 "x10/regionarray/PolyRow.x10"
                        final long t$155847 = ((long)(((int)(c$155836))));
                        
                        //#line 144 "x10/regionarray/PolyRow.x10"
                        boolean t$155848 = ((t$155847) >= (((long)(0L))));
                        
                        //#line 144 "x10/regionarray/PolyRow.x10"
                        if (t$155848) {
                            
                            //#line 144 "x10/regionarray/PolyRow.x10"
                            t$155848 = !(first);
                        }
                        
                        //#line 144 "x10/regionarray/PolyRow.x10"
                        java.lang.String t$155851 =  null;
                        
                        //#line 144 "x10/regionarray/PolyRow.x10"
                        if (t$155848) {
                            
                            //#line 144 "x10/regionarray/PolyRow.x10"
                            t$155851 = "+";
                        } else {
                            
                            //#line 144 "x10/regionarray/PolyRow.x10"
                            t$155851 = "";
                        }
                        
                        //#line 144 "x10/regionarray/PolyRow.x10"
                        final java.lang.String t$155853 = ((t$155851) + ((x10.core.Int.$box(c$155836))));
                        
                        //#line 144 "x10/regionarray/PolyRow.x10"
                        final java.lang.String t$155854 = ((t$155853) + ("*x"));
                        
                        //#line 144 "x10/regionarray/PolyRow.x10"
                        final java.lang.String t$155856 = ((t$155854) + ((x10.core.Int.$box(i$155861))));
                        
                        //#line 144 "x10/regionarray/PolyRow.x10"
                        final java.lang.String t$155857 = ((t$155856) + (" "));
                        
                        //#line 144 "x10/regionarray/PolyRow.x10"
                        ps.print(((java.lang.String)(t$155857)));
                    }
                }
            }
            
            //#line 145 "x10/regionarray/PolyRow.x10"
            final boolean t$155858 = ((int) c$155836) != ((int) 0);
            
            //#line 145 "x10/regionarray/PolyRow.x10"
            if (t$155858) {
                
                //#line 146 "x10/regionarray/PolyRow.x10"
                first = false;
            }
            
            //#line 128 "x10/regionarray/PolyRow.x10"
            final int t$155860 = ((i$155861) + (((int)(1))));
            
            //#line 128 "x10/regionarray/PolyRow.x10"
            i$155861 = t$155860;
        }
        
        //#line 148 "x10/regionarray/PolyRow.x10"
        if (first) {
            
            //#line 149 "x10/regionarray/PolyRow.x10"
            ps.print(((java.lang.String)("0")));
        }
        
        //#line 150 "x10/regionarray/PolyRow.x10"
        final boolean t$155748 = ((sgn) > (((int)(0))));
        
        //#line 150 "x10/regionarray/PolyRow.x10"
        if (t$155748) {
            
            //#line 151 "x10/regionarray/PolyRow.x10"
            final java.lang.String t$155735 = ((spc) + ("<="));
            
            //#line 151 "x10/regionarray/PolyRow.x10"
            final java.lang.String t$155739 = ((t$155735) + (spc));
            
            //#line 151 "x10/regionarray/PolyRow.x10"
            final int t$155736 = this.cols;
            
            //#line 151 "x10/regionarray/PolyRow.x10"
            final int t$155737 = ((t$155736) - (((int)(1))));
            
            //#line 151 "x10/regionarray/PolyRow.x10"
            final int t$155738 = this.$apply$O((int)(t$155737));
            
            //#line 151 "x10/regionarray/PolyRow.x10"
            final int t$155740 = (-(t$155738));
            
            //#line 151 "x10/regionarray/PolyRow.x10"
            final java.lang.String t$155741 = ((t$155739) + ((x10.core.Int.$box(t$155740))));
            
            //#line 151 "x10/regionarray/PolyRow.x10"
            ps.print(((java.lang.String)(t$155741)));
        } else {
            
            //#line 153 "x10/regionarray/PolyRow.x10"
            final java.lang.String t$155742 = ((spc) + (">="));
            
            //#line 153 "x10/regionarray/PolyRow.x10"
            final java.lang.String t$155745 = ((t$155742) + (spc));
            
            //#line 153 "x10/regionarray/PolyRow.x10"
            final int t$155743 = this.cols;
            
            //#line 153 "x10/regionarray/PolyRow.x10"
            final int t$155744 = ((t$155743) - (((int)(1))));
            
            //#line 153 "x10/regionarray/PolyRow.x10"
            final int t$155746 = this.$apply$O((int)(t$155744));
            
            //#line 153 "x10/regionarray/PolyRow.x10"
            final java.lang.String t$155747 = ((t$155745) + ((x10.core.Int.$box(t$155746))));
            
            //#line 153 "x10/regionarray/PolyRow.x10"
            ps.print(((java.lang.String)(t$155747)));
        }
    }
    
    
    //#line 27 "x10/regionarray/PolyRow.x10"
    final public x10.regionarray.PolyRow x10$regionarray$PolyRow$$this$x10$regionarray$PolyRow() {
        
        //#line 27 "x10/regionarray/PolyRow.x10"
        return x10.regionarray.PolyRow.this;
    }
    
    
    //#line 27 "x10/regionarray/PolyRow.x10"
    final public void __fieldInitializers_x10_regionarray_PolyRow() {
        
    }
    
    @x10.runtime.impl.java.X10Generated
    final public static class $Closure$258 extends x10.core.Ref implements x10.core.fun.Fun_0_1, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<$Closure$258> $RTT = 
            x10.rtt.StaticFunType.<$Closure$258> make($Closure$258.class,
                                                      new x10.rtt.Type[] {
                                                          x10.rtt.ParameterizedType.make(x10.core.fun.Fun_0_1.$RTT, x10.rtt.Types.INT, x10.rtt.Types.INT)
                                                      });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static x10.serialization.X10JavaSerializable $_deserialize_body(x10.regionarray.PolyRow.$Closure$258 $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            $_obj.k = $deserializer.readInt();
            $_obj.p = $deserializer.readObject();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.regionarray.PolyRow.$Closure$258 $_obj = new x10.regionarray.PolyRow.$Closure$258((java.lang.System[]) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            $serializer.write(this.k);
            $serializer.write(this.p);
            
        }
        
        // constructor just for allocation
        public $Closure$258(final java.lang.System[] $dummy) {
            
        }
        
        // dispatcher for method abstract public (Z1)=>U.operator()(a1:Z1):U
        public java.lang.Object $apply(final java.lang.Object a1, final x10.rtt.Type t1) {
            return x10.core.Int.$box($apply$O(x10.core.Int.$unbox(a1)));
            
        }
        
        // dispatcher for method abstract public (Z1)=>U.operator()(a1:Z1):U
        public int $apply$I(final java.lang.Object a1, final x10.rtt.Type t1) {
            return $apply$O(x10.core.Int.$unbox(a1));
            
        }
        
        
    
        
        public int $apply$O(final int i$155756) {
            
            //#line 37 "x10/regionarray/PolyRow.x10"
            final long t$155757 = ((long)(((int)(i$155756))));
            
            //#line 37 "x10/regionarray/PolyRow.x10"
            final long t$155758 = this.p.rank;
            
            //#line 37 "x10/regionarray/PolyRow.x10"
            final boolean t$155759 = ((t$155757) < (((long)(t$155758))));
            
            //#line 37 "x10/regionarray/PolyRow.x10"
            int t$155760 =  0;
            
            //#line 37 "x10/regionarray/PolyRow.x10"
            if (t$155759) {
                
                //#line 37 "x10/regionarray/PolyRow.x10"
                final long t$155761 = ((long)(((int)(i$155756))));
                
                //#line 37 "x10/regionarray/PolyRow.x10"
                final long t$155762 = this.p.$apply$O((long)(t$155761));
                
                //#line 37 "x10/regionarray/PolyRow.x10"
                t$155760 = ((int)(long)(((long)(t$155762))));
            } else {
                
                //#line 37 "x10/regionarray/PolyRow.x10"
                t$155760 = this.k;
            }
            
            //#line 37 "x10/regionarray/PolyRow.x10"
            return t$155760;
        }
        
        public x10.lang.Point p;
        public int k;
        
        public $Closure$258(final x10.lang.Point p, final int k) {
             {
                this.p = ((x10.lang.Point)(p));
                this.k = k;
            }
        }
        
    }
    
    @x10.runtime.impl.java.X10Generated
    final public static class $Closure$259 extends x10.core.Ref implements x10.core.fun.Fun_0_1, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<$Closure$259> $RTT = 
            x10.rtt.StaticFunType.<$Closure$259> make($Closure$259.class,
                                                      new x10.rtt.Type[] {
                                                          x10.rtt.ParameterizedType.make(x10.core.fun.Fun_0_1.$RTT, x10.rtt.Types.LONG, x10.rtt.Types.INT)
                                                      });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static x10.serialization.X10JavaSerializable $_deserialize_body(x10.regionarray.PolyRow.$Closure$259 $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            $_obj.out$$ = $deserializer.readObject();
            $_obj.rank = $deserializer.readLong();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.regionarray.PolyRow.$Closure$259 $_obj = new x10.regionarray.PolyRow.$Closure$259((java.lang.System[]) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            $serializer.write(this.out$$);
            $serializer.write(this.rank);
            
        }
        
        // constructor just for allocation
        public $Closure$259(final java.lang.System[] $dummy) {
            
        }
        
        // dispatcher for method abstract public (Z1)=>U.operator()(a1:Z1):U
        public java.lang.Object $apply(final java.lang.Object a1, final x10.rtt.Type t1) {
            return x10.core.Int.$box($apply$O(x10.core.Long.$unbox(a1)));
            
        }
        
        // dispatcher for method abstract public (Z1)=>U.operator()(a1:Z1):U
        public int $apply$I(final java.lang.Object a1, final x10.rtt.Type t1) {
            return $apply$O(x10.core.Long.$unbox(a1));
            
        }
        
        
    
        
        public int $apply$O(final long i) {
            
            //#line 116 "x10/regionarray/PolyRow.x10"
            final int t$155675 = ((int)(long)(((long)(i))));
            
            //#line 116 "x10/regionarray/PolyRow.x10"
            final long t$155676 = ((long)(((int)(t$155675))));
            
            //#line 116 "x10/regionarray/PolyRow.x10"
            final long t$155677 = this.rank;
            
            //#line 116 "x10/regionarray/PolyRow.x10"
            final boolean t$155684 = ((t$155676) < (((long)(t$155677))));
            
            //#line 116 "x10/regionarray/PolyRow.x10"
            int t$155685 =  0;
            
            //#line 116 "x10/regionarray/PolyRow.x10"
            if (t$155684) {
                
                //#line 116 "x10/regionarray/PolyRow.x10"
                final int t$155678 = ((int)(long)(((long)(i))));
                
                //#line 116 "x10/regionarray/PolyRow.x10"
                final int t$155679 = this.out$$.$apply$O((int)(t$155678));
                
                //#line 116 "x10/regionarray/PolyRow.x10"
                t$155685 = (-(t$155679));
            } else {
                
                //#line 116 "x10/regionarray/PolyRow.x10"
                final long t$155680 = this.rank;
                
                //#line 116 "x10/regionarray/PolyRow.x10"
                final int t$155681 = ((int)(long)(((long)(t$155680))));
                
                //#line 116 "x10/regionarray/PolyRow.x10"
                final int t$155682 = this.out$$.$apply$O((int)(t$155681));
                
                //#line 116 "x10/regionarray/PolyRow.x10"
                final int t$155683 = (-(t$155682));
                
                //#line 116 "x10/regionarray/PolyRow.x10"
                t$155685 = ((t$155683) + (((int)(1))));
            }
            
            //#line 116 "x10/regionarray/PolyRow.x10"
            return t$155685;
        }
        
        public x10.regionarray.PolyRow out$$;
        public long rank;
        
        public $Closure$259(final x10.regionarray.PolyRow out$$, final long rank) {
             {
                this.out$$ = out$$;
                this.rank = rank;
            }
        }
        
    }
    
}


