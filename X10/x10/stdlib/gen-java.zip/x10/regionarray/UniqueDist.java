package x10.regionarray;


/**
 * A distribution that maps the region 0..(numPlaces()-1)
 * to the members of its PlaceGroup such that for 
 * every Place p the region returned by get is 
 * the single point region that matches the indexOf
 * p in the PlaceGroup.
 * In particular, if the PlaceGroup of the UniqueDist 
 * is Place.places() and no Place has failed, then each Place p 
 * will be assigned the region p.id..p.id.
 */
@x10.runtime.impl.java.X10Generated
final public class UniqueDist extends x10.regionarray.Dist implements x10.serialization.X10JavaSerializable
{
    public static final x10.rtt.RuntimeType<UniqueDist> $RTT = 
        x10.rtt.NamedType.<UniqueDist> make("x10.regionarray.UniqueDist",
                                            UniqueDist.class,
                                            new x10.rtt.Type[] {
                                                x10.regionarray.Dist.$RTT
                                            });
    
    public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
    
    public x10.rtt.Type<?> $getParam(int i) { return null; }
    
    private Object writeReplace() throws java.io.ObjectStreamException {
        return new x10.serialization.SerializationProxy(this);
    }
    
    public static x10.serialization.X10JavaSerializable $_deserialize_body(x10.regionarray.UniqueDist $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
        x10.regionarray.Dist.$_deserialize_body($_obj, $deserializer);
        $_obj.pg = $deserializer.readObject();
        return $_obj;
    }
    
    public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
        x10.regionarray.UniqueDist $_obj = new x10.regionarray.UniqueDist((java.lang.System[]) null);
        $deserializer.record_reference($_obj);
        return $_deserialize_body($_obj, $deserializer);
    }
    
    public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
        super.$_serialize($serializer);
        $serializer.write(this.pg);
        
    }
    
    // constructor just for allocation
    public UniqueDist(final java.lang.System[] $dummy) {
        super($dummy);
        
    }
    
    

    
    //#line 31 "x10/regionarray/UniqueDist.x10"
    /**
    * The place group for this distribution
    */
    public x10.lang.PlaceGroup pg;
    
    //#line 36 "x10/regionarray/UniqueDist.x10"
    /**
     * Cached restricted region for the current place.
     */
    public transient x10.regionarray.Region regionForHere;
    
    
    //#line 42 "x10/regionarray/UniqueDist.x10"
    /**
     * Create a unique distribution over the argument PlaceGroup
     * @param g the place group
     */
    // creation method for java code (1-phase java constructor)
    public UniqueDist(final x10.lang.PlaceGroup g) {
        this((java.lang.System[]) null);
        x10$regionarray$UniqueDist$$init$S(g);
    }
    
    // constructor for non-virtual call
    final public x10.regionarray.UniqueDist x10$regionarray$UniqueDist$$init$S(final x10.lang.PlaceGroup g) {
         {
            
            //#line 43 "x10/regionarray/UniqueDist.x10"
            final x10.regionarray.Dist this$159146 = ((x10.regionarray.Dist)(this));
            
            //#line 43 "x10/regionarray/UniqueDist.x10"
            final long t$159171 = g.numPlaces$O();
            
            //#line 43 "x10/regionarray/UniqueDist.x10"
            final long max$159142 = ((t$159171) - (((long)(1L))));
            
            //#line 279 . "x10/regionarray/Region.x10"
            final x10.regionarray.RectRegion1D alloc$159143 = ((x10.regionarray.RectRegion1D)(new x10.regionarray.RectRegion1D((java.lang.System[]) null)));
            
            //#line 279 . "x10/regionarray/Region.x10"
            alloc$159143.x10$regionarray$RectRegion1D$$init$S(((long)(0L)), ((long)(max$159142)));
            
            //#line 43 "x10/regionarray/UniqueDist.x10"
            final x10.regionarray.Region region$159145 = ((x10.regionarray.Region)(((x10.regionarray.Region)
                                                                                     alloc$159143)));
            
            //#line 548 . "x10/regionarray/Dist.x10"
            this$159146.region = region$159145;
            
            //#line 42 "x10/regionarray/UniqueDist.x10"
            
            
            //#line 26 "x10/regionarray/UniqueDist.x10"
            final x10.regionarray.UniqueDist this$159237 = this;
            
            //#line 26 "x10/regionarray/UniqueDist.x10"
            this$159237.regionForHere = null;
            
            //#line 44 "x10/regionarray/UniqueDist.x10"
            this.pg = ((x10.lang.PlaceGroup)(g));
        }
        return this;
    }
    
    
    
    //#line 50 "x10/regionarray/UniqueDist.x10"
    /**
     * Create a unique distribution over Place.places();
     */
    // creation method for java code (1-phase java constructor)
    public UniqueDist() {
        this((java.lang.System[]) null);
        x10$regionarray$UniqueDist$$init$S();
    }
    
    // constructor for non-virtual call
    final public x10.regionarray.UniqueDist x10$regionarray$UniqueDist$$init$S() {
         {
            
            //#line 51 "x10/regionarray/UniqueDist.x10"
            final x10.lang.PlaceGroup t$159172 = ((x10.lang.PlaceGroup)(x10.lang.Place.places()));
            
            //#line 51 "x10/regionarray/UniqueDist.x10"
            /*this.*/x10$regionarray$UniqueDist$$init$S(((x10.lang.PlaceGroup)(t$159172)));
        }
        return this;
    }
    
    
    
    //#line 54 "x10/regionarray/UniqueDist.x10"
    public x10.lang.PlaceGroup places() {
        
        //#line 54 "x10/regionarray/UniqueDist.x10"
        final x10.lang.PlaceGroup t$159173 = ((x10.lang.PlaceGroup)(this.pg));
        
        //#line 54 "x10/regionarray/UniqueDist.x10"
        return t$159173;
    }
    
    
    //#line 56 "x10/regionarray/UniqueDist.x10"
    public long numPlaces$O() {
        
        //#line 56 "x10/regionarray/UniqueDist.x10"
        final x10.lang.PlaceGroup t$159174 = ((x10.lang.PlaceGroup)(this.pg));
        
        //#line 56 "x10/regionarray/UniqueDist.x10"
        final long t$159175 = t$159174.numPlaces$O();
        
        //#line 56 "x10/regionarray/UniqueDist.x10"
        return t$159175;
    }
    
    
    //#line 58 "x10/regionarray/UniqueDist.x10"
    public x10.lang.Iterable regions() {
        
        //#line 59 "x10/regionarray/UniqueDist.x10"
        final x10.lang.PlaceGroup t$159176 = ((x10.lang.PlaceGroup)(this.pg));
        
        //#line 59 "x10/regionarray/UniqueDist.x10"
        final long t$159184 = t$159176.numPlaces$O();
        
        //#line 59 "x10/regionarray/UniqueDist.x10"
        final x10.core.fun.Fun_0_1 t$159185 = ((x10.core.fun.Fun_0_1)(new x10.regionarray.UniqueDist.$Closure$300(this)));
        
        //#line 59 "x10/regionarray/UniqueDist.x10"
        final x10.core.Rail t$159186 = ((x10.core.Rail)(new x10.core.Rail<x10.regionarray.Region>(x10.regionarray.Region.$RTT, t$159184, ((x10.core.fun.Fun_0_1)(t$159185)), (x10.core.Rail.__1$1x10$lang$Long$3x10$lang$Rail$$T$2) null)));
        
        //#line 59 "x10/regionarray/UniqueDist.x10"
        return t$159186;
    }
    
    
    //#line 62 "x10/regionarray/UniqueDist.x10"
    public x10.regionarray.Region get(final x10.lang.Place p) {
        
        //#line 63 "x10/regionarray/UniqueDist.x10"
        final boolean t$159206 = x10.rtt.Equality.equalsequals((p),(x10.x10rt.X10RT.here()));
        
        //#line 63 "x10/regionarray/UniqueDist.x10"
        if (t$159206) {
            
            //#line 64 "x10/regionarray/UniqueDist.x10"
            final x10.regionarray.Region t$159187 = ((x10.regionarray.Region)(this.regionForHere));
            
            //#line 64 "x10/regionarray/UniqueDist.x10"
            final boolean t$159196 = ((t$159187) == (null));
            
            //#line 64 "x10/regionarray/UniqueDist.x10"
            if (t$159196) {
                
                //#line 65 "x10/regionarray/UniqueDist.x10"
                final x10.lang.PlaceGroup t$159188 = ((x10.lang.PlaceGroup)(this.pg));
                
                //#line 65 "x10/regionarray/UniqueDist.x10"
                final long idx = t$159188.indexOf$O(((x10.lang.Place)(x10.x10rt.X10RT.here())));
                
                //#line 279 . "x10/regionarray/Region.x10"
                final x10.regionarray.RectRegion1D alloc$159157 = ((x10.regionarray.RectRegion1D)(new x10.regionarray.RectRegion1D((java.lang.System[]) null)));
                
                //#line 279 . "x10/regionarray/Region.x10"
                alloc$159157.x10$regionarray$RectRegion1D$$init$S(idx, idx);
                
                //#line 279 . "x10/regionarray/Region.x10"
                final x10.regionarray.Region t$159189 = ((x10.regionarray.Region)(((x10.regionarray.Region)
                                                                                    alloc$159157)));
                
                //#line 66 "x10/regionarray/UniqueDist.x10"
                final x10.regionarray.Region t$149305 = ((x10.regionarray.Region)
                                                          t$159189);
                
                //#line 66 "x10/regionarray/UniqueDist.x10"
                final long t$159191 = t$149305.rank;
                
                //#line 66 "x10/regionarray/UniqueDist.x10"
                final x10.regionarray.Region t$159190 = ((x10.regionarray.Region)(x10.regionarray.UniqueDist.this.region));
                
                //#line 66 "x10/regionarray/UniqueDist.x10"
                final long t$159192 = t$159190.rank;
                
                //#line 66 "x10/regionarray/UniqueDist.x10"
                final boolean t$159193 = ((long) t$159191) == ((long) t$159192);
                
                //#line 66 "x10/regionarray/UniqueDist.x10"
                final boolean t$159195 = !(t$159193);
                
                //#line 66 "x10/regionarray/UniqueDist.x10"
                if (t$159195) {
                    
                    //#line 66 "x10/regionarray/UniqueDist.x10"
                    final x10.lang.FailedDynamicCheckException t$159194 = new x10.lang.FailedDynamicCheckException("x10.regionarray.Region{self.rank==this(:x10.regionarray.UniqueDist).region.rank}");
                    
                    //#line 66 "x10/regionarray/UniqueDist.x10"
                    throw t$159194;
                }
                
                //#line 66 "x10/regionarray/UniqueDist.x10"
                this.regionForHere = ((x10.regionarray.Region)(t$149305));
            }
            
            //#line 68 "x10/regionarray/UniqueDist.x10"
            final x10.regionarray.Region t$159197 = ((x10.regionarray.Region)(this.regionForHere));
            
            //#line 68 "x10/regionarray/UniqueDist.x10"
            return t$159197;
        } else {
            
            //#line 70 "x10/regionarray/UniqueDist.x10"
            final x10.lang.PlaceGroup t$159198 = ((x10.lang.PlaceGroup)(this.pg));
            
            //#line 70 "x10/regionarray/UniqueDist.x10"
            final long idx = t$159198.indexOf$O(((x10.lang.Place)(p)));
            
            //#line 279 . "x10/regionarray/Region.x10"
            final x10.regionarray.RectRegion1D alloc$159161 = ((x10.regionarray.RectRegion1D)(new x10.regionarray.RectRegion1D((java.lang.System[]) null)));
            
            //#line 279 . "x10/regionarray/Region.x10"
            alloc$159161.x10$regionarray$RectRegion1D$$init$S(idx, idx);
            
            //#line 279 . "x10/regionarray/Region.x10"
            final x10.regionarray.Region t$159199 = ((x10.regionarray.Region)(((x10.regionarray.Region)
                                                                                alloc$159161)));
            
            //#line 71 "x10/regionarray/UniqueDist.x10"
            final x10.regionarray.Region t$149307 = ((x10.regionarray.Region)
                                                      t$159199);
            
            //#line 71 "x10/regionarray/UniqueDist.x10"
            final long t$159201 = t$149307.rank;
            
            //#line 71 "x10/regionarray/UniqueDist.x10"
            final x10.regionarray.Region t$159200 = ((x10.regionarray.Region)(x10.regionarray.UniqueDist.this.region));
            
            //#line 71 "x10/regionarray/UniqueDist.x10"
            final long t$159202 = t$159200.rank;
            
            //#line 71 "x10/regionarray/UniqueDist.x10"
            final boolean t$159203 = ((long) t$159201) == ((long) t$159202);
            
            //#line 71 "x10/regionarray/UniqueDist.x10"
            final boolean t$159205 = !(t$159203);
            
            //#line 71 "x10/regionarray/UniqueDist.x10"
            if (t$159205) {
                
                //#line 71 "x10/regionarray/UniqueDist.x10"
                final x10.lang.FailedDynamicCheckException t$159204 = new x10.lang.FailedDynamicCheckException("x10.regionarray.Region{self.rank==this(:x10.regionarray.UniqueDist).region.rank}");
                
                //#line 71 "x10/regionarray/UniqueDist.x10"
                throw t$159204;
            }
            
            //#line 71 "x10/regionarray/UniqueDist.x10"
            return t$149307;
        }
    }
    
    
    //#line 76 "x10/regionarray/UniqueDist.x10"
    public x10.regionarray.Region $apply(final x10.lang.Place p) {
        
        //#line 76 "x10/regionarray/UniqueDist.x10"
        final x10.regionarray.Region t$159207 = ((x10.regionarray.Region)(this.get(((x10.lang.Place)(p)))));
        
        //#line 76 "x10/regionarray/UniqueDist.x10"
        return t$159207;
    }
    
    
    //#line 78 "x10/regionarray/UniqueDist.x10"
    public x10.lang.Place $apply(final x10.lang.Point pt) {
        
        //#line 78 "x10/regionarray/UniqueDist.x10"
        final x10.lang.PlaceGroup t$159209 = ((x10.lang.PlaceGroup)(this.pg));
        
        //#line 78 "x10/regionarray/UniqueDist.x10"
        final long t$159208 = ((long)(((int)(0))));
        
        //#line 78 "x10/regionarray/UniqueDist.x10"
        final long t$159210 = pt.$apply$O((long)(t$159208));
        
        //#line 78 "x10/regionarray/UniqueDist.x10"
        final x10.lang.Place t$159211 = t$159209.$apply((long)(t$159210));
        
        //#line 78 "x10/regionarray/UniqueDist.x10"
        return t$159211;
    }
    
    
    //#line 80 "x10/regionarray/UniqueDist.x10"
    public x10.lang.Place $apply(final long i0) {
        
        //#line 80 "x10/regionarray/UniqueDist.x10"
        final x10.lang.PlaceGroup t$159214 = ((x10.lang.PlaceGroup)(this.pg));
        
        //#line 80 "x10/regionarray/UniqueDist.x10"
        final x10.lang.Place t$159215 = t$159214.$apply((long)(i0));
        
        //#line 80 "x10/regionarray/UniqueDist.x10"
        return t$159215;
    }
    
    
    //#line 84 "x10/regionarray/UniqueDist.x10"
    public x10.lang.Place $apply(final long i0, final long i1) {
        
        //#line 85 "x10/regionarray/UniqueDist.x10"
        final java.lang.UnsupportedOperationException t$159218 = ((java.lang.UnsupportedOperationException)(new java.lang.UnsupportedOperationException("operator(i0:Long,i1:Long)")));
        
        //#line 85 "x10/regionarray/UniqueDist.x10"
        throw t$159218;
    }
    
    
    //#line 90 "x10/regionarray/UniqueDist.x10"
    public x10.lang.Place $apply(final long i0, final long i1, final long i2) {
        
        //#line 91 "x10/regionarray/UniqueDist.x10"
        final java.lang.UnsupportedOperationException t$159221 = ((java.lang.UnsupportedOperationException)(new java.lang.UnsupportedOperationException("operator(i0:Long,i1:Long,i2:Long)")));
        
        //#line 91 "x10/regionarray/UniqueDist.x10"
        throw t$159221;
    }
    
    
    //#line 96 "x10/regionarray/UniqueDist.x10"
    public x10.lang.Place $apply(final long i0, final long i1, final long i2, final long i3) {
        
        //#line 97 "x10/regionarray/UniqueDist.x10"
        final java.lang.UnsupportedOperationException t$159224 = ((java.lang.UnsupportedOperationException)(new java.lang.UnsupportedOperationException("operator(i0:Long,i1:Long,i2:Long,i3:Long)")));
        
        //#line 97 "x10/regionarray/UniqueDist.x10"
        throw t$159224;
    }
    
    
    //#line 100 "x10/regionarray/UniqueDist.x10"
    public x10.regionarray.Dist restriction(final x10.regionarray.Region r) {
        
        //#line 101 "x10/regionarray/UniqueDist.x10"
        final x10.regionarray.WrappedDistRegionRestricted alloc$149311 = ((x10.regionarray.WrappedDistRegionRestricted)(new x10.regionarray.WrappedDistRegionRestricted((java.lang.System[]) null)));
        
        //#line 101 "x10/regionarray/UniqueDist.x10"
        alloc$149311.x10$regionarray$WrappedDistRegionRestricted$$init$S(((x10.regionarray.Dist)(this)), ((x10.regionarray.Region)(r)));
        
        //#line 101 "x10/regionarray/UniqueDist.x10"
        return alloc$149311;
    }
    
    
    //#line 104 "x10/regionarray/UniqueDist.x10"
    public x10.regionarray.Dist restriction(final x10.lang.Place p) {
        
        //#line 105 "x10/regionarray/UniqueDist.x10"
        final x10.regionarray.WrappedDistPlaceRestricted alloc$149312 = ((x10.regionarray.WrappedDistPlaceRestricted)(new x10.regionarray.WrappedDistPlaceRestricted((java.lang.System[]) null)));
        
        //#line 105 "x10/regionarray/UniqueDist.x10"
        alloc$149312.x10$regionarray$WrappedDistPlaceRestricted$$init$S(((x10.regionarray.Dist)(this)), ((x10.lang.Place)(p)));
        
        //#line 105 "x10/regionarray/UniqueDist.x10"
        final x10.regionarray.Dist t$149309 = ((x10.regionarray.Dist)
                                                alloc$149312);
        
        //#line 105 "x10/regionarray/UniqueDist.x10"
        final x10.regionarray.Region t$159225 = ((x10.regionarray.Region)(t$149309.region));
        
        //#line 105 "x10/regionarray/UniqueDist.x10"
        final long t$159227 = t$159225.rank;
        
        //#line 105 "x10/regionarray/UniqueDist.x10"
        final x10.regionarray.Region t$159226 = ((x10.regionarray.Region)(x10.regionarray.UniqueDist.this.region));
        
        //#line 105 "x10/regionarray/UniqueDist.x10"
        final long t$159228 = t$159226.rank;
        
        //#line 105 "x10/regionarray/UniqueDist.x10"
        final boolean t$159229 = ((long) t$159227) == ((long) t$159228);
        
        //#line 105 "x10/regionarray/UniqueDist.x10"
        final boolean t$159231 = !(t$159229);
        
        //#line 105 "x10/regionarray/UniqueDist.x10"
        if (t$159231) {
            
            //#line 105 "x10/regionarray/UniqueDist.x10"
            final x10.lang.FailedDynamicCheckException t$159230 = new x10.lang.FailedDynamicCheckException("x10.regionarray.Dist{self.region.rank==this(:x10.regionarray.UniqueDist).region.rank}");
            
            //#line 105 "x10/regionarray/UniqueDist.x10"
            throw t$159230;
        }
        
        //#line 105 "x10/regionarray/UniqueDist.x10"
        return t$149309;
    }
    
    
    //#line 108 "x10/regionarray/UniqueDist.x10"
    public boolean equals(final java.lang.Object thatObj) {
        
        //#line 109 "x10/regionarray/UniqueDist.x10"
        final boolean t$159236 = x10.regionarray.UniqueDist.$RTT.isInstance(thatObj);
        
        //#line 109 "x10/regionarray/UniqueDist.x10"
        if (t$159236) {
            
            //#line 110 "x10/regionarray/UniqueDist.x10"
            final x10.regionarray.UniqueDist that = ((x10.regionarray.UniqueDist)(x10.rtt.Types.<x10.regionarray.UniqueDist> cast(thatObj,x10.regionarray.UniqueDist.$RTT)));
            
            //#line 111 "x10/regionarray/UniqueDist.x10"
            final x10.lang.PlaceGroup t$159232 = ((x10.lang.PlaceGroup)(this.pg));
            
            //#line 111 "x10/regionarray/UniqueDist.x10"
            final x10.lang.PlaceGroup t$159233 = ((x10.lang.PlaceGroup)(that.pg));
            
            //#line 111 "x10/regionarray/UniqueDist.x10"
            final boolean t$159234 = t$159232.equals(((java.lang.Object)(t$159233)));
            
            //#line 111 "x10/regionarray/UniqueDist.x10"
            return t$159234;
        } else {
            
            //#line 113 "x10/regionarray/UniqueDist.x10"
            final boolean t$159235 = super.equals(((java.lang.Object)(thatObj)));
            
            //#line 113 "x10/regionarray/UniqueDist.x10"
            return t$159235;
        }
    }
    
    
    //#line 26 "x10/regionarray/UniqueDist.x10"
    final public x10.regionarray.UniqueDist x10$regionarray$UniqueDist$$this$x10$regionarray$UniqueDist() {
        
        //#line 26 "x10/regionarray/UniqueDist.x10"
        return x10.regionarray.UniqueDist.this;
    }
    
    
    //#line 26 "x10/regionarray/UniqueDist.x10"
    final public void __fieldInitializers_x10_regionarray_UniqueDist() {
        
        //#line 26 "x10/regionarray/UniqueDist.x10"
        this.regionForHere = null;
    }
    
    @x10.runtime.impl.java.X10Generated
    final public static class $Closure$300 extends x10.core.Ref implements x10.core.fun.Fun_0_1, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<$Closure$300> $RTT = 
            x10.rtt.StaticFunType.<$Closure$300> make($Closure$300.class,
                                                      new x10.rtt.Type[] {
                                                          x10.rtt.ParameterizedType.make(x10.core.fun.Fun_0_1.$RTT, x10.rtt.Types.LONG, x10.regionarray.Region.$RTT)
                                                      });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static x10.serialization.X10JavaSerializable $_deserialize_body(x10.regionarray.UniqueDist.$Closure$300 $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            $_obj.out$$ = $deserializer.readObject();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.regionarray.UniqueDist.$Closure$300 $_obj = new x10.regionarray.UniqueDist.$Closure$300((java.lang.System[]) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            $serializer.write(this.out$$);
            
        }
        
        // constructor just for allocation
        public $Closure$300(final java.lang.System[] $dummy) {
            
        }
        
        // dispatcher for method abstract public (Z1)=>U.operator()(a1:Z1):U
        public java.lang.Object $apply(final java.lang.Object a1, final x10.rtt.Type t1) {
            return $apply(x10.core.Long.$unbox(a1));
            
        }
        
        
    
        
        public x10.regionarray.Region $apply(final long i) {
            
            //#line 279 . "x10/regionarray/Region.x10"
            final x10.regionarray.RectRegion1D alloc$159153 = ((x10.regionarray.RectRegion1D)(new x10.regionarray.RectRegion1D((java.lang.System[]) null)));
            
            //#line 279 . "x10/regionarray/Region.x10"
            alloc$159153.x10$regionarray$RectRegion1D$$init$S(i, i);
            
            //#line 279 . "x10/regionarray/Region.x10"
            final x10.regionarray.Region t$159177 = ((x10.regionarray.Region)(((x10.regionarray.Region)
                                                                                alloc$159153)));
            
            //#line 59 "x10/regionarray/UniqueDist.x10"
            final x10.regionarray.Region t$149303 = ((x10.regionarray.Region)
                                                      t$159177);
            
            //#line 59 "x10/regionarray/UniqueDist.x10"
            final long t$159179 = t$149303.rank;
            
            //#line 59 "x10/regionarray/UniqueDist.x10"
            final x10.regionarray.Region t$159178 = ((x10.regionarray.Region)(this.out$$.region));
            
            //#line 59 "x10/regionarray/UniqueDist.x10"
            final long t$159180 = t$159178.rank;
            
            //#line 59 "x10/regionarray/UniqueDist.x10"
            final boolean t$159181 = ((long) t$159179) == ((long) t$159180);
            
            //#line 59 "x10/regionarray/UniqueDist.x10"
            final boolean t$159183 = !(t$159181);
            
            //#line 59 "x10/regionarray/UniqueDist.x10"
            if (t$159183) {
                
                //#line 59 "x10/regionarray/UniqueDist.x10"
                final x10.lang.FailedDynamicCheckException t$159182 = new x10.lang.FailedDynamicCheckException("x10.regionarray.Region{self.rank==this(:x10.regionarray.UniqueDist).region.rank}");
                
                //#line 59 "x10/regionarray/UniqueDist.x10"
                throw t$159182;
            }
            
            //#line 59 "x10/regionarray/UniqueDist.x10"
            return t$149303;
        }
        
        public x10.regionarray.UniqueDist out$$;
        
        public $Closure$300(final x10.regionarray.UniqueDist out$$) {
             {
                this.out$$ = out$$;
            }
        }
        
    }
    
    
    public boolean x10$regionarray$Dist$equals$S$O(final java.lang.Object a0) {
        return super.equals(((java.lang.Object)(a0)));
    }
}

