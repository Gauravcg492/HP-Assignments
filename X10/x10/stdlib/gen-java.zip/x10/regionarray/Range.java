package x10.regionarray;


