package x10.regionarray;


/**
 * <p>A BlockBlock distribution maps points in its region
 * in a 2D blocked fashion to the places in its PlaceGroup</p>
 *
 * It caches the region for the current place as a transient field.
 * This makes the initial access to this information somewhat slow,
 * but optimizes the wire-transfer size of the Dist object. 
 * This appears to be the appropriate tradeoff, since Dist objects
 * are frequently serialized and usually the restriction operation is 
 * applied to get the Region for here, not for other places.
 */
@x10.runtime.impl.java.X10Generated
final public class BlockBlockDist extends x10.regionarray.Dist implements x10.serialization.X10JavaSerializable
{
    public static final x10.rtt.RuntimeType<BlockBlockDist> $RTT = 
        x10.rtt.NamedType.<BlockBlockDist> make("x10.regionarray.BlockBlockDist",
                                                BlockBlockDist.class,
                                                new x10.rtt.Type[] {
                                                    x10.regionarray.Dist.$RTT
                                                });
    
    public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
    
    public x10.rtt.Type<?> $getParam(int i) { return null; }
    
    private Object writeReplace() throws java.io.ObjectStreamException {
        return new x10.serialization.SerializationProxy(this);
    }
    
    public static x10.serialization.X10JavaSerializable $_deserialize_body(x10.regionarray.BlockBlockDist $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
        x10.regionarray.Dist.$_deserialize_body($_obj, $deserializer);
        $_obj.axis0 = $deserializer.readLong();
        $_obj.axis1 = $deserializer.readLong();
        $_obj.pg = $deserializer.readObject();
        return $_obj;
    }
    
    public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
        x10.regionarray.BlockBlockDist $_obj = new x10.regionarray.BlockBlockDist((java.lang.System[]) null);
        $deserializer.record_reference($_obj);
        return $_deserialize_body($_obj, $deserializer);
    }
    
    public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
        super.$_serialize($serializer);
        $serializer.write(this.axis0);
        $serializer.write(this.axis1);
        $serializer.write(this.pg);
        
    }
    
    // constructor just for allocation
    public BlockBlockDist(final java.lang.System[] $dummy) {
        super($dummy);
        
    }
    
    

    
    //#line 32 "x10/regionarray/BlockBlockDist.x10"
    /**
     * The place group for this distribution
     */
    public x10.lang.PlaceGroup pg;
    
    //#line 37 "x10/regionarray/BlockBlockDist.x10"
    /**
     * The first axis along which the region is distributed
     */
    public long axis0;
    
    //#line 42 "x10/regionarray/BlockBlockDist.x10"
    /**
     * The second axis along which the region is distributed
     */
    public long axis1;
    
    //#line 47 "x10/regionarray/BlockBlockDist.x10"
    /**
     * Cached restricted region for the current place.
     */
    public transient x10.regionarray.Region regionForHere;
    
    
    //#line 50 "x10/regionarray/BlockBlockDist.x10"
    // creation method for java code (1-phase java constructor)
    public BlockBlockDist(final x10.regionarray.Region r, final long axis0, final long axis1, final x10.lang.PlaceGroup pg) {
        this((java.lang.System[]) null);
        x10$regionarray$BlockBlockDist$$init$S(r, axis0, axis1, pg);
    }
    
    // constructor for non-virtual call
    final public x10.regionarray.BlockBlockDist x10$regionarray$BlockBlockDist$$init$S(final x10.regionarray.Region r, final long axis0, final long axis1, final x10.lang.PlaceGroup pg) {
         {
            
            //#line 51 "x10/regionarray/BlockBlockDist.x10"
            final x10.regionarray.Dist this$144507 = ((x10.regionarray.Dist)(this));
            
            //#line 548 . "x10/regionarray/Dist.x10"
            this$144507.region = r;
            
            //#line 50 "x10/regionarray/BlockBlockDist.x10"
            
            
            //#line 27 "x10/regionarray/BlockBlockDist.x10"
            final x10.regionarray.BlockBlockDist this$147796 = this;
            
            //#line 27 "x10/regionarray/BlockBlockDist.x10"
            this$147796.regionForHere = null;
            
            //#line 52 "x10/regionarray/BlockBlockDist.x10"
            this.axis0 = axis0;
            
            //#line 53 "x10/regionarray/BlockBlockDist.x10"
            this.axis1 = axis1;
            
            //#line 54 "x10/regionarray/BlockBlockDist.x10"
            this.pg = ((x10.lang.PlaceGroup)(pg));
        }
        return this;
    }
    
    
    
    //#line 65 "x10/regionarray/BlockBlockDist.x10"
    /**
     * The key algorithm for this class.
     * Compute the region for the given place by doing region algebra.
     *
     * Assumption: Caller has done error checking to ensure that place is 
     *   actually a member of pg.
     */
    private x10.regionarray.Region blockBlockRegionForPlace(final x10.lang.Place place) {
        
        //#line 66 "x10/regionarray/BlockBlockDist.x10"
        final x10.regionarray.Region t$147506 = ((x10.regionarray.Region)(this.region));
        
        //#line 66 "x10/regionarray/BlockBlockDist.x10"
        final x10.regionarray.Region b = ((x10.regionarray.Region)(t$147506.boundingBox()));
        
        //#line 67 "x10/regionarray/BlockBlockDist.x10"
        final long t$147507 = this.axis0;
        
        //#line 67 "x10/regionarray/BlockBlockDist.x10"
        final long min0 = b.min$O((long)(t$147507));
        
        //#line 68 "x10/regionarray/BlockBlockDist.x10"
        final long t$147508 = this.axis0;
        
        //#line 68 "x10/regionarray/BlockBlockDist.x10"
        final long max0 = b.max$O((long)(t$147508));
        
        //#line 69 "x10/regionarray/BlockBlockDist.x10"
        final long t$147509 = this.axis1;
        
        //#line 69 "x10/regionarray/BlockBlockDist.x10"
        final long min1 = b.min$O((long)(t$147509));
        
        //#line 70 "x10/regionarray/BlockBlockDist.x10"
        final long t$147510 = this.axis1;
        
        //#line 70 "x10/regionarray/BlockBlockDist.x10"
        final long max1 = b.max$O((long)(t$147510));
        
        //#line 71 "x10/regionarray/BlockBlockDist.x10"
        final long t$147511 = ((max0) - (((long)(min0))));
        
        //#line 71 "x10/regionarray/BlockBlockDist.x10"
        final long size0 = ((t$147511) + (((long)(1L))));
        
        //#line 72 "x10/regionarray/BlockBlockDist.x10"
        final long t$147512 = ((max1) - (((long)(min1))));
        
        //#line 72 "x10/regionarray/BlockBlockDist.x10"
        final long size1 = ((t$147512) + (((long)(1L))));
        
        //#line 73 "x10/regionarray/BlockBlockDist.x10"
        final long divisions0;
        
        //#line 74 "x10/regionarray/BlockBlockDist.x10"
        final long P;
        
        //#line 75 "x10/regionarray/BlockBlockDist.x10"
        final boolean t$147533 = ((size0) > (((long)(1L))));
        
        //#line 75 "x10/regionarray/BlockBlockDist.x10"
        if (t$147533) {
            
            //#line 76 "x10/regionarray/BlockBlockDist.x10"
            final long t$147513 = ((size0) % (((long)(2L))));
            
            //#line 76 "x10/regionarray/BlockBlockDist.x10"
            final boolean t$147514 = ((long) t$147513) == ((long) 0L);
            
            //#line 76 "x10/regionarray/BlockBlockDist.x10"
            long t$147515 =  0;
            
            //#line 76 "x10/regionarray/BlockBlockDist.x10"
            if (t$147514) {
                
                //#line 76 "x10/regionarray/BlockBlockDist.x10"
                t$147515 = size0;
            } else {
                
                //#line 76 "x10/regionarray/BlockBlockDist.x10"
                t$147515 = ((size0) - (((long)(1L))));
            }
            
            //#line 77 "x10/regionarray/BlockBlockDist.x10"
            final x10.lang.PlaceGroup t$147516 = ((x10.lang.PlaceGroup)(this.pg));
            
            //#line 77 "x10/regionarray/BlockBlockDist.x10"
            final long t$147517 = t$147516.numPlaces$O();
            
            //#line 77 "x10/regionarray/BlockBlockDist.x10"
            final long t$147518 = t$147517;
            
            //#line 77 "x10/regionarray/BlockBlockDist.x10"
            final long t$147519 = ((t$147515) * (((long)(size1))));
            
            //#line 77 "x10/regionarray/BlockBlockDist.x10"
            final long t$147520 = java.lang.Math.min(((long)(t$147518)),((long)(t$147519)));
            
            //#line 77 "x10/regionarray/BlockBlockDist.x10"
            P = t$147520;
            
            //#line 78 "x10/regionarray/BlockBlockDist.x10"
            final double t$147521 = ((double)(long)(((long)(P))));
            
            //#line 78 "x10/regionarray/BlockBlockDist.x10"
            final double t$147522 = java.lang.Math.log(((double)(t$147521)));
            
            //#line 78 "x10/regionarray/BlockBlockDist.x10"
            final double t$147523 = java.lang.Math.log(((double)(2.0)));
            
            //#line 78 "x10/regionarray/BlockBlockDist.x10"
            final double t$147524 = ((t$147522) / (((double)(t$147523))));
            
            //#line 78 "x10/regionarray/BlockBlockDist.x10"
            final double t$147525 = ((t$147524) / (((double)(2.0))));
            
            //#line 78 "x10/regionarray/BlockBlockDist.x10"
            final double t$147526 = java.lang.Math.ceil(((double)(t$147525)));
            
            //#line 78 "x10/regionarray/BlockBlockDist.x10"
            final long t$147527 = ((long)(double)(((double)(t$147526))));
            
            //#line 78 "x10/regionarray/BlockBlockDist.x10"
            final long t$147528 = x10.lang.Math.pow2$O((long)(t$147527));
            
            //#line 78 "x10/regionarray/BlockBlockDist.x10"
            final long t$147529 = java.lang.Math.min(((long)(t$147515)),((long)(t$147528)));
            
            //#line 78 "x10/regionarray/BlockBlockDist.x10"
            divisions0 = t$147529;
        } else {
            
            //#line 80 "x10/regionarray/BlockBlockDist.x10"
            final x10.lang.PlaceGroup t$147530 = ((x10.lang.PlaceGroup)(this.pg));
            
            //#line 80 "x10/regionarray/BlockBlockDist.x10"
            final long t$147531 = t$147530.numPlaces$O();
            
            //#line 80 "x10/regionarray/BlockBlockDist.x10"
            final long t$147532 = java.lang.Math.min(((long)(t$147531)),((long)(size1)));
            
            //#line 80 "x10/regionarray/BlockBlockDist.x10"
            P = t$147532;
            
            //#line 81 "x10/regionarray/BlockBlockDist.x10"
            divisions0 = 1L;
        }
        
        //#line 83 "x10/regionarray/BlockBlockDist.x10"
        final double t$147534 = ((double)(long)(((long)(P))));
        
        //#line 83 "x10/regionarray/BlockBlockDist.x10"
        final double t$147535 = ((double)(long)(((long)(divisions0))));
        
        //#line 83 "x10/regionarray/BlockBlockDist.x10"
        final double t$147536 = ((t$147534) / (((double)(t$147535))));
        
        //#line 83 "x10/regionarray/BlockBlockDist.x10"
        final double t$147537 = java.lang.Math.ceil(((double)(t$147536)));
        
        //#line 83 "x10/regionarray/BlockBlockDist.x10"
        final long t$147538 = ((long)(double)(((double)(t$147537))));
        
        //#line 83 "x10/regionarray/BlockBlockDist.x10"
        final long divisions1 = java.lang.Math.min(((long)(size1)),((long)(t$147538)));
        
        //#line 84 "x10/regionarray/BlockBlockDist.x10"
        final long t$147539 = ((divisions0) * (((long)(divisions1))));
        
        //#line 84 "x10/regionarray/BlockBlockDist.x10"
        final long leftOver = ((t$147539) - (((long)(P))));
        
        //#line 86 "x10/regionarray/BlockBlockDist.x10"
        final x10.lang.PlaceGroup t$147540 = ((x10.lang.PlaceGroup)(this.pg));
        
        //#line 86 "x10/regionarray/BlockBlockDist.x10"
        final long i = t$147540.indexOf$O(((x10.lang.Place)(place)));
        
        //#line 87 "x10/regionarray/BlockBlockDist.x10"
        final boolean t$147543 = ((i) >= (((long)(P))));
        
        //#line 87 "x10/regionarray/BlockBlockDist.x10"
        if (t$147543) {
            
            //#line 87 "x10/regionarray/BlockBlockDist.x10"
            final x10.regionarray.Dist this$144512 = ((x10.regionarray.Dist)
                                                       this);
            
            //#line 38 . "x10/regionarray/Dist.x10"
            final x10.regionarray.Region t$147541 = ((x10.regionarray.Region)(this$144512.region));
            
            //#line 87 "x10/regionarray/BlockBlockDist.x10"
            final long rank$144514 = t$147541.rank;
            
            //#line 60 . "x10/regionarray/Region.x10"
            final x10.regionarray.EmptyRegion alloc$144515 = ((x10.regionarray.EmptyRegion)(new x10.regionarray.EmptyRegion((java.lang.System[]) null)));
            
            //#line 60 . "x10/regionarray/Region.x10"
            alloc$144515.x10$regionarray$EmptyRegion$$init$S(((long)(rank$144514)));
            
            //#line 60 . "x10/regionarray/Region.x10"
            final x10.regionarray.Region t$147542 = ((x10.regionarray.Region)(((x10.regionarray.Region)
                                                                                alloc$144515)));
            
            //#line 87 "x10/regionarray/BlockBlockDist.x10"
            return t$147542;
        }
        
        //#line 89 "x10/regionarray/BlockBlockDist.x10"
        final long t$147544 = ((divisions0) % (((long)(2L))));
        
        //#line 89 "x10/regionarray/BlockBlockDist.x10"
        final boolean t$147547 = ((long) t$147544) == ((long) 0L);
        
        //#line 89 "x10/regionarray/BlockBlockDist.x10"
        long t$147548 =  0;
        
        //#line 89 "x10/regionarray/BlockBlockDist.x10"
        if (t$147547) {
            
            //#line 89 "x10/regionarray/BlockBlockDist.x10"
            t$147548 = 0L;
        } else {
            
            //#line 89 "x10/regionarray/BlockBlockDist.x10"
            final long t$147545 = ((i) * (((long)(2L))));
            
            //#line 89 "x10/regionarray/BlockBlockDist.x10"
            final long t$147546 = ((divisions0) + (((long)(1L))));
            
            //#line 89 "x10/regionarray/BlockBlockDist.x10"
            t$147548 = ((t$147545) / (((long)(t$147546))));
        }
        
        //#line 91 "x10/regionarray/BlockBlockDist.x10"
        final boolean t$147552 = ((i) < (((long)(leftOver))));
        
        //#line 91 "x10/regionarray/BlockBlockDist.x10"
        long t$147553 =  0;
        
        //#line 91 "x10/regionarray/BlockBlockDist.x10"
        if (t$147552) {
            
            //#line 91 "x10/regionarray/BlockBlockDist.x10"
            final long t$147549 = ((i) * (((long)(2L))));
            
            //#line 91 "x10/regionarray/BlockBlockDist.x10"
            final long t$147550 = ((t$147549) - (((long)(t$147548))));
            
            //#line 91 "x10/regionarray/BlockBlockDist.x10"
            t$147553 = ((t$147550) % (((long)(divisions0))));
        } else {
            
            //#line 91 "x10/regionarray/BlockBlockDist.x10"
            final long t$147551 = ((i) + (((long)(leftOver))));
            
            //#line 91 "x10/regionarray/BlockBlockDist.x10"
            t$147553 = ((t$147551) % (((long)(divisions0))));
        }
        
        //#line 92 "x10/regionarray/BlockBlockDist.x10"
        final boolean t$147556 = ((i) < (((long)(leftOver))));
        
        //#line 92 "x10/regionarray/BlockBlockDist.x10"
        long t$147557 =  0;
        
        //#line 92 "x10/regionarray/BlockBlockDist.x10"
        if (t$147556) {
            
            //#line 92 "x10/regionarray/BlockBlockDist.x10"
            final long t$147554 = ((i) * (((long)(2L))));
            
            //#line 92 "x10/regionarray/BlockBlockDist.x10"
            t$147557 = ((t$147554) / (((long)(divisions0))));
        } else {
            
            //#line 92 "x10/regionarray/BlockBlockDist.x10"
            final long t$147555 = ((i) + (((long)(leftOver))));
            
            //#line 92 "x10/regionarray/BlockBlockDist.x10"
            t$147557 = ((t$147555) / (((long)(divisions0))));
        }
        
        //#line 94 "x10/regionarray/BlockBlockDist.x10"
        final long t$147558 = ((t$147553) * (((long)(size0))));
        
        //#line 94 "x10/regionarray/BlockBlockDist.x10"
        final double t$147559 = ((double)(long)(((long)(t$147558))));
        
        //#line 94 "x10/regionarray/BlockBlockDist.x10"
        final double t$147560 = ((double)(long)(((long)(divisions0))));
        
        //#line 94 "x10/regionarray/BlockBlockDist.x10"
        final double t$147561 = ((t$147559) / (((double)(t$147560))));
        
        //#line 94 "x10/regionarray/BlockBlockDist.x10"
        final double t$147562 = java.lang.Math.ceil(((double)(t$147561)));
        
        //#line 94 "x10/regionarray/BlockBlockDist.x10"
        final long t$147563 = ((long)(double)(((double)(t$147562))));
        
        //#line 94 "x10/regionarray/BlockBlockDist.x10"
        final long low0 = ((min0) + (((long)(t$147563))));
        
        //#line 95 "x10/regionarray/BlockBlockDist.x10"
        final boolean t$147564 = ((i) < (((long)(leftOver))));
        
        //#line 95 "x10/regionarray/BlockBlockDist.x10"
        long t$147565 =  0;
        
        //#line 95 "x10/regionarray/BlockBlockDist.x10"
        if (t$147564) {
            
            //#line 95 "x10/regionarray/BlockBlockDist.x10"
            t$147565 = 2L;
        } else {
            
            //#line 95 "x10/regionarray/BlockBlockDist.x10"
            t$147565 = 1L;
        }
        
        //#line 95 "x10/regionarray/BlockBlockDist.x10"
        final long blockHi0 = ((t$147553) + (((long)(t$147565))));
        
        //#line 96 "x10/regionarray/BlockBlockDist.x10"
        final long t$147567 = ((blockHi0) * (((long)(size0))));
        
        //#line 96 "x10/regionarray/BlockBlockDist.x10"
        final double t$147568 = ((double)(long)(((long)(t$147567))));
        
        //#line 96 "x10/regionarray/BlockBlockDist.x10"
        final double t$147569 = ((double)(long)(((long)(divisions0))));
        
        //#line 96 "x10/regionarray/BlockBlockDist.x10"
        final double t$147570 = ((t$147568) / (((double)(t$147569))));
        
        //#line 96 "x10/regionarray/BlockBlockDist.x10"
        final double t$147571 = java.lang.Math.ceil(((double)(t$147570)));
        
        //#line 96 "x10/regionarray/BlockBlockDist.x10"
        final long t$147572 = ((long)(double)(((double)(t$147571))));
        
        //#line 96 "x10/regionarray/BlockBlockDist.x10"
        final long t$147573 = ((min0) + (((long)(t$147572))));
        
        //#line 96 "x10/regionarray/BlockBlockDist.x10"
        final long hi0 = ((t$147573) - (((long)(1L))));
        
        //#line 98 "x10/regionarray/BlockBlockDist.x10"
        final long t$147574 = ((t$147557) * (((long)(size1))));
        
        //#line 98 "x10/regionarray/BlockBlockDist.x10"
        final double t$147575 = ((double)(long)(((long)(t$147574))));
        
        //#line 98 "x10/regionarray/BlockBlockDist.x10"
        final double t$147576 = ((double)(long)(((long)(divisions1))));
        
        //#line 98 "x10/regionarray/BlockBlockDist.x10"
        final double t$147577 = ((t$147575) / (((double)(t$147576))));
        
        //#line 98 "x10/regionarray/BlockBlockDist.x10"
        final double t$147578 = java.lang.Math.ceil(((double)(t$147577)));
        
        //#line 98 "x10/regionarray/BlockBlockDist.x10"
        final long t$147579 = ((long)(double)(((double)(t$147578))));
        
        //#line 98 "x10/regionarray/BlockBlockDist.x10"
        final long low1 = ((min1) + (((long)(t$147579))));
        
        //#line 99 "x10/regionarray/BlockBlockDist.x10"
        final long t$147580 = ((t$147557) + (((long)(1L))));
        
        //#line 99 "x10/regionarray/BlockBlockDist.x10"
        final long t$147581 = ((t$147580) * (((long)(size1))));
        
        //#line 99 "x10/regionarray/BlockBlockDist.x10"
        final double t$147582 = ((double)(long)(((long)(t$147581))));
        
        //#line 99 "x10/regionarray/BlockBlockDist.x10"
        final double t$147583 = ((double)(long)(((long)(divisions1))));
        
        //#line 99 "x10/regionarray/BlockBlockDist.x10"
        final double t$147584 = ((t$147582) / (((double)(t$147583))));
        
        //#line 99 "x10/regionarray/BlockBlockDist.x10"
        final double t$147585 = java.lang.Math.ceil(((double)(t$147584)));
        
        //#line 99 "x10/regionarray/BlockBlockDist.x10"
        final long t$147586 = ((long)(double)(((double)(t$147585))));
        
        //#line 99 "x10/regionarray/BlockBlockDist.x10"
        final long t$147587 = ((min1) + (((long)(t$147586))));
        
        //#line 99 "x10/regionarray/BlockBlockDist.x10"
        final long hi1 = ((t$147587) - (((long)(1L))));
        
        //#line 101 "x10/regionarray/BlockBlockDist.x10"
        final x10.regionarray.Region t$147588 = ((x10.regionarray.Region)(this.region));
        
        //#line 101 "x10/regionarray/BlockBlockDist.x10"
        final boolean t$147658 = x10.regionarray.RectRegion.$RTT.isInstance(t$147588);
        
        //#line 101 "x10/regionarray/BlockBlockDist.x10"
        if (t$147658) {
            
            //#line 103 "x10/regionarray/BlockBlockDist.x10"
            final x10.regionarray.Dist this$144634 = ((x10.regionarray.Dist)
                                                       this);
            
            //#line 38 . "x10/regionarray/Dist.x10"
            final x10.regionarray.Region t$147589 = ((x10.regionarray.Region)(this$144634.region));
            
            //#line 38 . "x10/regionarray/Dist.x10"
            final long t$147594 = t$147589.rank;
            
            //#line 103 "x10/regionarray/BlockBlockDist.x10"
            final x10.core.fun.Fun_0_1 t$147595 = ((x10.core.fun.Fun_0_1)(new x10.regionarray.BlockBlockDist.$Closure$204(this, this.region)));
            
            //#line 103 "x10/regionarray/BlockBlockDist.x10"
            final x10.core.Rail newMin = ((x10.core.Rail)(new x10.core.Rail<x10.core.Long>(x10.rtt.Types.LONG, ((long)(t$147594)), ((x10.core.fun.Fun_0_1)(t$147595)), (x10.core.Rail.__1$1x10$lang$Long$3x10$lang$Rail$$T$2) null)));
            
            //#line 104 "x10/regionarray/BlockBlockDist.x10"
            final x10.regionarray.Dist this$144636 = ((x10.regionarray.Dist)
                                                       this);
            
            //#line 38 . "x10/regionarray/Dist.x10"
            final x10.regionarray.Region t$147596 = ((x10.regionarray.Region)(this$144636.region));
            
            //#line 38 . "x10/regionarray/Dist.x10"
            final long t$147601 = t$147596.rank;
            
            //#line 104 "x10/regionarray/BlockBlockDist.x10"
            final x10.core.fun.Fun_0_1 t$147602 = ((x10.core.fun.Fun_0_1)(new x10.regionarray.BlockBlockDist.$Closure$205(this, this.region)));
            
            //#line 104 "x10/regionarray/BlockBlockDist.x10"
            final x10.core.Rail newMax = ((x10.core.Rail)(new x10.core.Rail<x10.core.Long>(x10.rtt.Types.LONG, ((long)(t$147601)), ((x10.core.fun.Fun_0_1)(t$147602)), (x10.core.Rail.__1$1x10$lang$Long$3x10$lang$Rail$$T$2) null)));
            
            //#line 105 "x10/regionarray/BlockBlockDist.x10"
            final long t$147603 = this.axis0;
            
            //#line 105 "x10/regionarray/BlockBlockDist.x10"
            ((long[])newMin.value)[(int)t$147603] = low0;
            
            //#line 106 "x10/regionarray/BlockBlockDist.x10"
            final long t$147604 = this.axis1;
            
            //#line 106 "x10/regionarray/BlockBlockDist.x10"
            ((long[])newMin.value)[(int)t$147604] = low1;
            
            //#line 107 "x10/regionarray/BlockBlockDist.x10"
            final long t$147605 = this.axis0;
            
            //#line 107 "x10/regionarray/BlockBlockDist.x10"
            ((long[])newMax.value)[(int)t$147605] = hi0;
            
            //#line 108 "x10/regionarray/BlockBlockDist.x10"
            final long t$147606 = this.axis1;
            
            //#line 108 "x10/regionarray/BlockBlockDist.x10"
            ((long[])newMax.value)[(int)t$147606] = hi1;
            
            //#line 109 "x10/regionarray/BlockBlockDist.x10"
            final x10.regionarray.RectRegion alloc$143722 = ((x10.regionarray.RectRegion)(new x10.regionarray.RectRegion((java.lang.System[]) null)));
            
            //#line 109 "x10/regionarray/BlockBlockDist.x10"
            alloc$143722.x10$regionarray$RectRegion$$init$S(((x10.core.Rail)(newMin)), ((x10.core.Rail)(newMax)), (x10.regionarray.RectRegion.__0$1x10$lang$Long$2__1$1x10$lang$Long$2) null);
            
            //#line 109 "x10/regionarray/BlockBlockDist.x10"
            final x10.regionarray.Region t$143465 = ((x10.regionarray.Region)
                                                      alloc$143722);
            
            //#line 109 "x10/regionarray/BlockBlockDist.x10"
            final long t$147608 = t$143465.rank;
            
            //#line 109 "x10/regionarray/BlockBlockDist.x10"
            final x10.regionarray.Region t$147607 = ((x10.regionarray.Region)(x10.regionarray.BlockBlockDist.this.region));
            
            //#line 109 "x10/regionarray/BlockBlockDist.x10"
            final long t$147609 = t$147607.rank;
            
            //#line 109 "x10/regionarray/BlockBlockDist.x10"
            final boolean t$147610 = ((long) t$147608) == ((long) t$147609);
            
            //#line 109 "x10/regionarray/BlockBlockDist.x10"
            final boolean t$147612 = !(t$147610);
            
            //#line 109 "x10/regionarray/BlockBlockDist.x10"
            if (t$147612) {
                
                //#line 109 "x10/regionarray/BlockBlockDist.x10"
                final x10.lang.FailedDynamicCheckException t$147611 = new x10.lang.FailedDynamicCheckException("x10.regionarray.Region{self.rank==this(:x10.regionarray.BlockBlockDist).region.rank}");
                
                //#line 109 "x10/regionarray/BlockBlockDist.x10"
                throw t$147611;
            }
            
            //#line 109 "x10/regionarray/BlockBlockDist.x10"
            return t$143465;
        } else {
            
            //#line 112 "x10/regionarray/BlockBlockDist.x10"
            final long t$147613 = this.axis1;
            
            //#line 112 "x10/regionarray/BlockBlockDist.x10"
            final long t$147614 = this.axis0;
            
            //#line 112 "x10/regionarray/BlockBlockDist.x10"
            final boolean t$147615 = ((t$147613) > (((long)(t$147614))));
            
            //#line 112 "x10/regionarray/BlockBlockDist.x10"
            x10.regionarray.Region t$147616 =  null;
            
            //#line 112 "x10/regionarray/BlockBlockDist.x10"
            if (t$147615) {
                
                //#line 112 "x10/regionarray/BlockBlockDist.x10"
                final long rank$146248 = this.axis0;
                
                //#line 66 . "x10/regionarray/Region.x10"
                final x10.regionarray.FullRegion alloc$146249 = ((x10.regionarray.FullRegion)(new x10.regionarray.FullRegion((java.lang.System[]) null)));
                
                //#line 66 . "x10/regionarray/Region.x10"
                alloc$146249.x10$regionarray$FullRegion$$init$S(((long)(rank$146248)));
                
                //#line 112 "x10/regionarray/BlockBlockDist.x10"
                t$147616 = ((x10.regionarray.Region)(((x10.regionarray.Region)
                                                       alloc$146249)));
            } else {
                
                //#line 112 "x10/regionarray/BlockBlockDist.x10"
                final long rank$146583 = this.axis1;
                
                //#line 66 . "x10/regionarray/Region.x10"
                final x10.regionarray.FullRegion alloc$146584 = ((x10.regionarray.FullRegion)(new x10.regionarray.FullRegion((java.lang.System[]) null)));
                
                //#line 66 . "x10/regionarray/Region.x10"
                alloc$146584.x10$regionarray$FullRegion$$init$S(((long)(rank$146583)));
                
                //#line 112 "x10/regionarray/BlockBlockDist.x10"
                t$147616 = ((x10.regionarray.Region)(((x10.regionarray.Region)
                                                       alloc$146584)));
            }
            
            //#line 113 "x10/regionarray/BlockBlockDist.x10"
            final long t$147617 = this.axis1;
            
            //#line 113 "x10/regionarray/BlockBlockDist.x10"
            final long t$147618 = this.axis0;
            
            //#line 113 "x10/regionarray/BlockBlockDist.x10"
            final boolean t$147627 = ((t$147617) > (((long)(t$147618))));
            
            //#line 113 "x10/regionarray/BlockBlockDist.x10"
            x10.regionarray.Region t$147628 =  null;
            
            //#line 113 "x10/regionarray/BlockBlockDist.x10"
            if (t$147627) {
                
                //#line 113 "x10/regionarray/BlockBlockDist.x10"
                final long t$147619 = this.axis1;
                
                //#line 113 "x10/regionarray/BlockBlockDist.x10"
                final long t$147620 = this.axis0;
                
                //#line 113 "x10/regionarray/BlockBlockDist.x10"
                final long t$147621 = ((t$147619) - (((long)(t$147620))));
                
                //#line 113 "x10/regionarray/BlockBlockDist.x10"
                final long t$147622 = ((long)(((int)(1))));
                
                //#line 113 "x10/regionarray/BlockBlockDist.x10"
                final long rank$146586 = ((t$147621) - (((long)(t$147622))));
                
                //#line 66 . "x10/regionarray/Region.x10"
                final x10.regionarray.FullRegion alloc$146587 = ((x10.regionarray.FullRegion)(new x10.regionarray.FullRegion((java.lang.System[]) null)));
                
                //#line 66 . "x10/regionarray/Region.x10"
                alloc$146587.x10$regionarray$FullRegion$$init$S(((long)(rank$146586)));
                
                //#line 113 "x10/regionarray/BlockBlockDist.x10"
                t$147628 = ((x10.regionarray.Region)(((x10.regionarray.Region)
                                                       alloc$146587)));
            } else {
                
                //#line 113 "x10/regionarray/BlockBlockDist.x10"
                final long t$147623 = this.axis0;
                
                //#line 113 "x10/regionarray/BlockBlockDist.x10"
                final long t$147624 = this.axis1;
                
                //#line 113 "x10/regionarray/BlockBlockDist.x10"
                final long t$147625 = ((t$147623) - (((long)(t$147624))));
                
                //#line 113 "x10/regionarray/BlockBlockDist.x10"
                final long t$147626 = ((long)(((int)(1))));
                
                //#line 113 "x10/regionarray/BlockBlockDist.x10"
                final long rank$146589 = ((t$147625) - (((long)(t$147626))));
                
                //#line 66 . "x10/regionarray/Region.x10"
                final x10.regionarray.FullRegion alloc$146590 = ((x10.regionarray.FullRegion)(new x10.regionarray.FullRegion((java.lang.System[]) null)));
                
                //#line 66 . "x10/regionarray/Region.x10"
                alloc$146590.x10$regionarray$FullRegion$$init$S(((long)(rank$146589)));
                
                //#line 113 "x10/regionarray/BlockBlockDist.x10"
                t$147628 = ((x10.regionarray.Region)(((x10.regionarray.Region)
                                                       alloc$146590)));
            }
            
            //#line 114 "x10/regionarray/BlockBlockDist.x10"
            final long t$147629 = this.axis1;
            
            //#line 114 "x10/regionarray/BlockBlockDist.x10"
            final long t$147630 = this.axis0;
            
            //#line 114 "x10/regionarray/BlockBlockDist.x10"
            final boolean t$147641 = ((t$147629) > (((long)(t$147630))));
            
            //#line 114 "x10/regionarray/BlockBlockDist.x10"
            x10.regionarray.Region t$147642 =  null;
            
            //#line 114 "x10/regionarray/BlockBlockDist.x10"
            if (t$147641) {
                
                //#line 114 "x10/regionarray/BlockBlockDist.x10"
                final x10.regionarray.Region t$147631 = ((x10.regionarray.Region)(this.region));
                
                //#line 114 "x10/regionarray/BlockBlockDist.x10"
                final long t$147632 = t$147631.rank;
                
                //#line 114 "x10/regionarray/BlockBlockDist.x10"
                final long t$147633 = this.axis1;
                
                //#line 114 "x10/regionarray/BlockBlockDist.x10"
                final long t$147634 = ((t$147632) - (((long)(t$147633))));
                
                //#line 114 "x10/regionarray/BlockBlockDist.x10"
                final long t$147635 = ((long)(((int)(1))));
                
                //#line 114 "x10/regionarray/BlockBlockDist.x10"
                final long rank$146592 = ((t$147634) - (((long)(t$147635))));
                
                //#line 66 . "x10/regionarray/Region.x10"
                final x10.regionarray.FullRegion alloc$146593 = ((x10.regionarray.FullRegion)(new x10.regionarray.FullRegion((java.lang.System[]) null)));
                
                //#line 66 . "x10/regionarray/Region.x10"
                alloc$146593.x10$regionarray$FullRegion$$init$S(((long)(rank$146592)));
                
                //#line 114 "x10/regionarray/BlockBlockDist.x10"
                t$147642 = ((x10.regionarray.Region)(((x10.regionarray.Region)
                                                       alloc$146593)));
            } else {
                
                //#line 114 "x10/regionarray/BlockBlockDist.x10"
                final x10.regionarray.Region t$147636 = ((x10.regionarray.Region)(this.region));
                
                //#line 114 "x10/regionarray/BlockBlockDist.x10"
                final long t$147637 = t$147636.rank;
                
                //#line 114 "x10/regionarray/BlockBlockDist.x10"
                final long t$147638 = this.axis0;
                
                //#line 114 "x10/regionarray/BlockBlockDist.x10"
                final long t$147639 = ((t$147637) - (((long)(t$147638))));
                
                //#line 114 "x10/regionarray/BlockBlockDist.x10"
                final long t$147640 = ((long)(((int)(1))));
                
                //#line 114 "x10/regionarray/BlockBlockDist.x10"
                final long rank$146595 = ((t$147639) - (((long)(t$147640))));
                
                //#line 66 . "x10/regionarray/Region.x10"
                final x10.regionarray.FullRegion alloc$146596 = ((x10.regionarray.FullRegion)(new x10.regionarray.FullRegion((java.lang.System[]) null)));
                
                //#line 66 . "x10/regionarray/Region.x10"
                alloc$146596.x10$regionarray$FullRegion$$init$S(((long)(rank$146595)));
                
                //#line 114 "x10/regionarray/BlockBlockDist.x10"
                t$147642 = ((x10.regionarray.Region)(((x10.regionarray.Region)
                                                       alloc$146596)));
            }
            
            //#line 115 "x10/regionarray/BlockBlockDist.x10"
            long lowFirst =  0;
            
            //#line 116 "x10/regionarray/BlockBlockDist.x10"
            final long hiFirst;
            
            //#line 117 "x10/regionarray/BlockBlockDist.x10"
            final long lowSecond;
            
            //#line 118 "x10/regionarray/BlockBlockDist.x10"
            final long hiSecond;
            
            //#line 119 "x10/regionarray/BlockBlockDist.x10"
            final long t$147643 = this.axis1;
            
            //#line 119 "x10/regionarray/BlockBlockDist.x10"
            final long t$147644 = this.axis0;
            
            //#line 119 "x10/regionarray/BlockBlockDist.x10"
            final boolean t$147645 = ((t$147643) > (((long)(t$147644))));
            
            //#line 119 "x10/regionarray/BlockBlockDist.x10"
            if (t$147645) {
                
                //#line 120 "x10/regionarray/BlockBlockDist.x10"
                lowFirst = low0;
                
                //#line 121 "x10/regionarray/BlockBlockDist.x10"
                lowSecond = low1;
                
                //#line 122 "x10/regionarray/BlockBlockDist.x10"
                hiFirst = hi0;
                
                //#line 123 "x10/regionarray/BlockBlockDist.x10"
                hiSecond = hi1;
            } else {
                
                //#line 125 "x10/regionarray/BlockBlockDist.x10"
                lowFirst = low1;
                
                //#line 126 "x10/regionarray/BlockBlockDist.x10"
                lowSecond = low0;
                
                //#line 127 "x10/regionarray/BlockBlockDist.x10"
                hiFirst = hi1;
                
                //#line 128 "x10/regionarray/BlockBlockDist.x10"
                hiSecond = hi0;
            }
            
            //#line 279 . "x10/regionarray/Region.x10"
            final x10.regionarray.RectRegion1D alloc$146600 = ((x10.regionarray.RectRegion1D)(new x10.regionarray.RectRegion1D((java.lang.System[]) null)));
            
            //#line 279 . "x10/regionarray/Region.x10"
            alloc$146600.x10$regionarray$RectRegion1D$$init$S(lowFirst, hiFirst);
            
            //#line 130 "x10/regionarray/BlockBlockDist.x10"
            final x10.regionarray.Region rFirst = ((x10.regionarray.Region)(((x10.regionarray.Region)
                                                                              alloc$146600)));
            
            //#line 279 . "x10/regionarray/Region.x10"
            final x10.regionarray.RectRegion1D alloc$146604 = ((x10.regionarray.RectRegion1D)(new x10.regionarray.RectRegion1D((java.lang.System[]) null)));
            
            //#line 279 . "x10/regionarray/Region.x10"
            alloc$146604.x10$regionarray$RectRegion1D$$init$S(lowSecond, hiSecond);
            
            //#line 131 "x10/regionarray/BlockBlockDist.x10"
            final x10.regionarray.Region rSecond = ((x10.regionarray.Region)(((x10.regionarray.Region)
                                                                               alloc$146604)));
            
            //#line 133 "x10/regionarray/BlockBlockDist.x10"
            final x10.regionarray.Region t$147646 = ((x10.regionarray.Region)(t$147616.product(((x10.regionarray.Region)(rFirst)))));
            
            //#line 133 "x10/regionarray/BlockBlockDist.x10"
            final x10.regionarray.Region t$147647 = ((x10.regionarray.Region)(t$147646.product(((x10.regionarray.Region)(t$147628)))));
            
            //#line 133 "x10/regionarray/BlockBlockDist.x10"
            final x10.regionarray.Region t$147648 = ((x10.regionarray.Region)(t$147647.product(((x10.regionarray.Region)(rSecond)))));
            
            //#line 133 "x10/regionarray/BlockBlockDist.x10"
            final x10.regionarray.Region t$147649 = ((x10.regionarray.Region)(t$147648.product(((x10.regionarray.Region)(t$147642)))));
            
            //#line 133 "x10/regionarray/BlockBlockDist.x10"
            final x10.regionarray.Region t$143551 = ((x10.regionarray.Region)
                                                      t$147649);
            
            //#line 133 "x10/regionarray/BlockBlockDist.x10"
            final long t$147651 = t$143551.rank;
            
            //#line 133 "x10/regionarray/BlockBlockDist.x10"
            final x10.regionarray.Region t$147650 = ((x10.regionarray.Region)(x10.regionarray.BlockBlockDist.this.region));
            
            //#line 133 "x10/regionarray/BlockBlockDist.x10"
            final long t$147652 = t$147650.rank;
            
            //#line 133 "x10/regionarray/BlockBlockDist.x10"
            final boolean t$147653 = ((long) t$147651) == ((long) t$147652);
            
            //#line 133 "x10/regionarray/BlockBlockDist.x10"
            final boolean t$147655 = !(t$147653);
            
            //#line 133 "x10/regionarray/BlockBlockDist.x10"
            if (t$147655) {
                
                //#line 133 "x10/regionarray/BlockBlockDist.x10"
                final x10.lang.FailedDynamicCheckException t$147654 = new x10.lang.FailedDynamicCheckException("x10.regionarray.Region{self.rank==this(:x10.regionarray.BlockBlockDist).region.rank}");
                
                //#line 133 "x10/regionarray/BlockBlockDist.x10"
                throw t$147654;
            }
            
            //#line 133 "x10/regionarray/BlockBlockDist.x10"
            final x10.regionarray.Region t$147656 = ((x10.regionarray.Region)(this.region));
            
            //#line 133 "x10/regionarray/BlockBlockDist.x10"
            final x10.regionarray.Region t$147657 = ((x10.regionarray.Region)(t$143551.intersection(((x10.regionarray.Region)(t$147656)))));
            
            //#line 133 "x10/regionarray/BlockBlockDist.x10"
            return t$147657;
        }
    }
    
    public static x10.regionarray.Region blockBlockRegionForPlace$P(final x10.lang.Place place, final x10.regionarray.BlockBlockDist BlockBlockDist) {
        return BlockBlockDist.blockBlockRegionForPlace(((x10.lang.Place)(place)));
    }
    
    
    //#line 143 "x10/regionarray/BlockBlockDist.x10"
    /**
     * Given an index into the "axis dimensions" determine which place it 
     * is mapped to.
     * Assumption: Caller has done error checking to ensure that index is 
     *   actually within the bounds of the axis dimension.
     */
    private x10.lang.Place mapIndexToPlace(final long index0, final long index1) {
        
        //#line 144 "x10/regionarray/BlockBlockDist.x10"
        final x10.regionarray.Region t$147659 = ((x10.regionarray.Region)(this.region));
        
        //#line 144 "x10/regionarray/BlockBlockDist.x10"
        final x10.regionarray.Region b = ((x10.regionarray.Region)(t$147659.boundingBox()));
        
        //#line 145 "x10/regionarray/BlockBlockDist.x10"
        final long t$147660 = this.axis0;
        
        //#line 145 "x10/regionarray/BlockBlockDist.x10"
        final long min0 = b.min$O((long)(t$147660));
        
        //#line 146 "x10/regionarray/BlockBlockDist.x10"
        final long t$147661 = this.axis0;
        
        //#line 146 "x10/regionarray/BlockBlockDist.x10"
        final long max0 = b.max$O((long)(t$147661));
        
        //#line 147 "x10/regionarray/BlockBlockDist.x10"
        final long t$147662 = this.axis1;
        
        //#line 147 "x10/regionarray/BlockBlockDist.x10"
        final long min1 = b.min$O((long)(t$147662));
        
        //#line 148 "x10/regionarray/BlockBlockDist.x10"
        final long t$147663 = this.axis1;
        
        //#line 148 "x10/regionarray/BlockBlockDist.x10"
        final long max1 = b.max$O((long)(t$147663));
        
        //#line 149 "x10/regionarray/BlockBlockDist.x10"
        final long t$147664 = ((max0) - (((long)(min0))));
        
        //#line 149 "x10/regionarray/BlockBlockDist.x10"
        final long size0 = ((t$147664) + (((long)(1L))));
        
        //#line 150 "x10/regionarray/BlockBlockDist.x10"
        final long t$147665 = ((max1) - (((long)(min1))));
        
        //#line 150 "x10/regionarray/BlockBlockDist.x10"
        final long size1 = ((t$147665) + (((long)(1L))));
        
        //#line 151 "x10/regionarray/BlockBlockDist.x10"
        final long divisions0;
        
        //#line 152 "x10/regionarray/BlockBlockDist.x10"
        final long P;
        
        //#line 153 "x10/regionarray/BlockBlockDist.x10"
        final boolean t$147686 = ((size0) > (((long)(1L))));
        
        //#line 153 "x10/regionarray/BlockBlockDist.x10"
        if (t$147686) {
            
            //#line 154 "x10/regionarray/BlockBlockDist.x10"
            final long t$147666 = ((size0) % (((long)(2L))));
            
            //#line 154 "x10/regionarray/BlockBlockDist.x10"
            final boolean t$147667 = ((long) t$147666) == ((long) 0L);
            
            //#line 154 "x10/regionarray/BlockBlockDist.x10"
            long t$147668 =  0;
            
            //#line 154 "x10/regionarray/BlockBlockDist.x10"
            if (t$147667) {
                
                //#line 154 "x10/regionarray/BlockBlockDist.x10"
                t$147668 = size0;
            } else {
                
                //#line 154 "x10/regionarray/BlockBlockDist.x10"
                t$147668 = ((size0) - (((long)(1L))));
            }
            
            //#line 155 "x10/regionarray/BlockBlockDist.x10"
            final x10.lang.PlaceGroup t$147669 = ((x10.lang.PlaceGroup)(this.pg));
            
            //#line 155 "x10/regionarray/BlockBlockDist.x10"
            final long t$147670 = t$147669.numPlaces$O();
            
            //#line 155 "x10/regionarray/BlockBlockDist.x10"
            final long t$147671 = t$147670;
            
            //#line 155 "x10/regionarray/BlockBlockDist.x10"
            final long t$147672 = ((t$147668) * (((long)(size1))));
            
            //#line 155 "x10/regionarray/BlockBlockDist.x10"
            final long t$147673 = java.lang.Math.min(((long)(t$147671)),((long)(t$147672)));
            
            //#line 155 "x10/regionarray/BlockBlockDist.x10"
            P = t$147673;
            
            //#line 156 "x10/regionarray/BlockBlockDist.x10"
            final double t$147674 = ((double)(long)(((long)(P))));
            
            //#line 156 "x10/regionarray/BlockBlockDist.x10"
            final double t$147675 = java.lang.Math.log(((double)(t$147674)));
            
            //#line 156 "x10/regionarray/BlockBlockDist.x10"
            final double t$147676 = java.lang.Math.log(((double)(2.0)));
            
            //#line 156 "x10/regionarray/BlockBlockDist.x10"
            final double t$147677 = ((t$147675) / (((double)(t$147676))));
            
            //#line 156 "x10/regionarray/BlockBlockDist.x10"
            final double t$147678 = ((t$147677) / (((double)(2.0))));
            
            //#line 156 "x10/regionarray/BlockBlockDist.x10"
            final double t$147679 = java.lang.Math.ceil(((double)(t$147678)));
            
            //#line 156 "x10/regionarray/BlockBlockDist.x10"
            final long t$147680 = ((long)(double)(((double)(t$147679))));
            
            //#line 156 "x10/regionarray/BlockBlockDist.x10"
            final long t$147681 = x10.lang.Math.pow2$O((long)(t$147680));
            
            //#line 156 "x10/regionarray/BlockBlockDist.x10"
            final long t$147682 = java.lang.Math.min(((long)(t$147668)),((long)(t$147681)));
            
            //#line 156 "x10/regionarray/BlockBlockDist.x10"
            divisions0 = t$147682;
        } else {
            
            //#line 158 "x10/regionarray/BlockBlockDist.x10"
            final x10.lang.PlaceGroup t$147683 = ((x10.lang.PlaceGroup)(this.pg));
            
            //#line 158 "x10/regionarray/BlockBlockDist.x10"
            final long t$147684 = t$147683.numPlaces$O();
            
            //#line 158 "x10/regionarray/BlockBlockDist.x10"
            final long t$147685 = java.lang.Math.min(((long)(t$147684)),((long)(size1)));
            
            //#line 158 "x10/regionarray/BlockBlockDist.x10"
            P = t$147685;
            
            //#line 159 "x10/regionarray/BlockBlockDist.x10"
            divisions0 = 1L;
        }
        
        //#line 161 "x10/regionarray/BlockBlockDist.x10"
        final double t$147687 = ((double)(long)(((long)(P))));
        
        //#line 161 "x10/regionarray/BlockBlockDist.x10"
        final double t$147688 = ((double)(long)(((long)(divisions0))));
        
        //#line 161 "x10/regionarray/BlockBlockDist.x10"
        final double t$147689 = ((t$147687) / (((double)(t$147688))));
        
        //#line 161 "x10/regionarray/BlockBlockDist.x10"
        final double t$147690 = java.lang.Math.ceil(((double)(t$147689)));
        
        //#line 161 "x10/regionarray/BlockBlockDist.x10"
        final long t$147691 = ((long)(double)(((double)(t$147690))));
        
        //#line 161 "x10/regionarray/BlockBlockDist.x10"
        final long divisions1 = java.lang.Math.min(((long)(size1)),((long)(t$147691)));
        
        //#line 162 "x10/regionarray/BlockBlockDist.x10"
        final long numBlocks = ((divisions0) * (((long)(divisions1))));
        
        //#line 163 "x10/regionarray/BlockBlockDist.x10"
        final long leftOver = ((numBlocks) - (((long)(P))));
        
        //#line 165 "x10/regionarray/BlockBlockDist.x10"
        final boolean t$147694 = ((long) divisions0) == ((long) 1L);
        
        //#line 165 "x10/regionarray/BlockBlockDist.x10"
        long t$147695 =  0;
        
        //#line 165 "x10/regionarray/BlockBlockDist.x10"
        if (t$147694) {
            
            //#line 165 "x10/regionarray/BlockBlockDist.x10"
            t$147695 = 0L;
        } else {
            
            //#line 165 "x10/regionarray/BlockBlockDist.x10"
            final long t$147692 = ((index0) - (((long)(min0))));
            
            //#line 165 "x10/regionarray/BlockBlockDist.x10"
            final long t$147693 = ((t$147692) * (((long)(divisions0))));
            
            //#line 165 "x10/regionarray/BlockBlockDist.x10"
            t$147695 = ((t$147693) / (((long)(size0))));
        }
        
        //#line 166 "x10/regionarray/BlockBlockDist.x10"
        final boolean t$147698 = ((long) divisions1) == ((long) 1L);
        
        //#line 166 "x10/regionarray/BlockBlockDist.x10"
        long t$147699 =  0;
        
        //#line 166 "x10/regionarray/BlockBlockDist.x10"
        if (t$147698) {
            
            //#line 166 "x10/regionarray/BlockBlockDist.x10"
            t$147699 = 0L;
        } else {
            
            //#line 166 "x10/regionarray/BlockBlockDist.x10"
            final long t$147696 = ((index1) - (((long)(min1))));
            
            //#line 166 "x10/regionarray/BlockBlockDist.x10"
            final long t$147697 = ((t$147696) * (((long)(divisions1))));
            
            //#line 166 "x10/regionarray/BlockBlockDist.x10"
            t$147699 = ((t$147697) / (((long)(size1))));
        }
        
        //#line 167 "x10/regionarray/BlockBlockDist.x10"
        final long t$147700 = ((t$147699) * (((long)(divisions0))));
        
        //#line 167 "x10/regionarray/BlockBlockDist.x10"
        final long blockIndex = ((t$147700) + (((long)(t$147695))));
        
        //#line 169 "x10/regionarray/BlockBlockDist.x10"
        final long t$147701 = ((leftOver) * (((long)(2L))));
        
        //#line 169 "x10/regionarray/BlockBlockDist.x10"
        final boolean t$147712 = ((blockIndex) <= (((long)(t$147701))));
        
        //#line 169 "x10/regionarray/BlockBlockDist.x10"
        if (t$147712) {
            
            //#line 170 "x10/regionarray/BlockBlockDist.x10"
            final x10.lang.PlaceGroup t$147704 = ((x10.lang.PlaceGroup)(this.pg));
            
            //#line 170 "x10/regionarray/BlockBlockDist.x10"
            final long t$147702 = ((blockIndex) / (((long)(2L))));
            
            //#line 170 "x10/regionarray/BlockBlockDist.x10"
            final int t$147703 = ((int)(long)(((long)(t$147702))));
            
            //#line 170 "x10/regionarray/BlockBlockDist.x10"
            final long t$147705 = ((long)(((int)(t$147703))));
            
            //#line 170 "x10/regionarray/BlockBlockDist.x10"
            final x10.lang.Place t$147706 = t$147704.$apply((long)(t$147705));
            
            //#line 170 "x10/regionarray/BlockBlockDist.x10"
            return t$147706;
        } else {
            
            //#line 172 "x10/regionarray/BlockBlockDist.x10"
            final x10.lang.PlaceGroup t$147709 = ((x10.lang.PlaceGroup)(this.pg));
            
            //#line 172 "x10/regionarray/BlockBlockDist.x10"
            final long t$147707 = ((blockIndex) - (((long)(leftOver))));
            
            //#line 172 "x10/regionarray/BlockBlockDist.x10"
            final int t$147708 = ((int)(long)(((long)(t$147707))));
            
            //#line 172 "x10/regionarray/BlockBlockDist.x10"
            final long t$147710 = ((long)(((int)(t$147708))));
            
            //#line 172 "x10/regionarray/BlockBlockDist.x10"
            final x10.lang.Place t$147711 = t$147709.$apply((long)(t$147710));
            
            //#line 172 "x10/regionarray/BlockBlockDist.x10"
            return t$147711;
        }
    }
    
    public static x10.lang.Place mapIndexToPlace$P(final long index0, final long index1, final x10.regionarray.BlockBlockDist BlockBlockDist) {
        return BlockBlockDist.mapIndexToPlace((long)(index0), (long)(index1));
    }
    
    
    //#line 176 "x10/regionarray/BlockBlockDist.x10"
    public x10.lang.PlaceGroup places() {
        
        //#line 176 "x10/regionarray/BlockBlockDist.x10"
        final x10.lang.PlaceGroup t$147713 = ((x10.lang.PlaceGroup)(this.pg));
        
        //#line 176 "x10/regionarray/BlockBlockDist.x10"
        return t$147713;
    }
    
    
    //#line 178 "x10/regionarray/BlockBlockDist.x10"
    public long numPlaces$O() {
        
        //#line 178 "x10/regionarray/BlockBlockDist.x10"
        final x10.lang.PlaceGroup t$147714 = ((x10.lang.PlaceGroup)(this.pg));
        
        //#line 178 "x10/regionarray/BlockBlockDist.x10"
        final long t$147715 = t$147714.numPlaces$O();
        
        //#line 178 "x10/regionarray/BlockBlockDist.x10"
        return t$147715;
    }
    
    
    //#line 180 "x10/regionarray/BlockBlockDist.x10"
    public x10.lang.Iterable regions() {
        
        //#line 181 "x10/regionarray/BlockBlockDist.x10"
        final x10.lang.PlaceGroup t$147716 = ((x10.lang.PlaceGroup)(this.pg));
        
        //#line 181 "x10/regionarray/BlockBlockDist.x10"
        final long t$147722 = t$147716.numPlaces$O();
        
        //#line 181 "x10/regionarray/BlockBlockDist.x10"
        final x10.core.fun.Fun_0_1 t$147723 = ((x10.core.fun.Fun_0_1)(new x10.regionarray.BlockBlockDist.$Closure$206(this, this.pg)));
        
        //#line 181 "x10/regionarray/BlockBlockDist.x10"
        final x10.core.Rail t$147724 = ((x10.core.Rail)(new x10.core.Rail<x10.regionarray.Region>(x10.regionarray.Region.$RTT, t$147722, ((x10.core.fun.Fun_0_1)(t$147723)), (x10.core.Rail.__1$1x10$lang$Long$3x10$lang$Rail$$T$2) null)));
        
        //#line 181 "x10/regionarray/BlockBlockDist.x10"
        return t$147724;
    }
    
    
    //#line 184 "x10/regionarray/BlockBlockDist.x10"
    public x10.regionarray.Region get(final x10.lang.Place p) {
        
        //#line 185 "x10/regionarray/BlockBlockDist.x10"
        final boolean t$147730 = x10.rtt.Equality.equalsequals((p),(x10.x10rt.X10RT.here()));
        
        //#line 185 "x10/regionarray/BlockBlockDist.x10"
        if (t$147730) {
            
            //#line 186 "x10/regionarray/BlockBlockDist.x10"
            final x10.regionarray.Region t$147725 = ((x10.regionarray.Region)(this.regionForHere));
            
            //#line 186 "x10/regionarray/BlockBlockDist.x10"
            final boolean t$147727 = ((t$147725) == (null));
            
            //#line 186 "x10/regionarray/BlockBlockDist.x10"
            if (t$147727) {
                
                //#line 187 "x10/regionarray/BlockBlockDist.x10"
                final x10.regionarray.Region t$147726 = ((x10.regionarray.Region)(this.blockBlockRegionForPlace(((x10.lang.Place)(x10.x10rt.X10RT.here())))));
                
                //#line 187 "x10/regionarray/BlockBlockDist.x10"
                this.regionForHere = ((x10.regionarray.Region)(t$147726));
            }
            
            //#line 189 "x10/regionarray/BlockBlockDist.x10"
            final x10.regionarray.Region t$147728 = ((x10.regionarray.Region)(this.regionForHere));
            
            //#line 189 "x10/regionarray/BlockBlockDist.x10"
            return t$147728;
        } else {
            
            //#line 191 "x10/regionarray/BlockBlockDist.x10"
            final x10.regionarray.Region t$147729 = ((x10.regionarray.Region)(this.blockBlockRegionForPlace(((x10.lang.Place)(p)))));
            
            //#line 191 "x10/regionarray/BlockBlockDist.x10"
            return t$147729;
        }
    }
    
    
    //#line 195 "x10/regionarray/BlockBlockDist.x10"
    public boolean containsLocally$O(final x10.lang.Point p) {
        
        //#line 195 "x10/regionarray/BlockBlockDist.x10"
        final x10.regionarray.Region t$147731 = ((x10.regionarray.Region)(this.get(((x10.lang.Place)(x10.x10rt.X10RT.here())))));
        
        //#line 195 "x10/regionarray/BlockBlockDist.x10"
        final boolean t$147732 = t$147731.contains$O(((x10.lang.Point)(p)));
        
        //#line 195 "x10/regionarray/BlockBlockDist.x10"
        return t$147732;
    }
    
    
    //#line 198 "x10/regionarray/BlockBlockDist.x10"
    public x10.regionarray.Region $apply(final x10.lang.Place p) {
        
        //#line 198 "x10/regionarray/BlockBlockDist.x10"
        final x10.regionarray.Region t$147733 = ((x10.regionarray.Region)(this.get(((x10.lang.Place)(p)))));
        
        //#line 198 "x10/regionarray/BlockBlockDist.x10"
        return t$147733;
    }
    
    
    //#line 200 "x10/regionarray/BlockBlockDist.x10"
    public x10.lang.Place $apply(final x10.lang.Point pt) {
        
        //#line 201 "x10/regionarray/BlockBlockDist.x10"
        final x10.regionarray.Region t$147734 = ((x10.regionarray.Region)(this.region));
        
        //#line 201 "x10/regionarray/BlockBlockDist.x10"
        final boolean t$147735 = t$147734.contains$O(((x10.lang.Point)(pt)));
        
        //#line 201 "x10/regionarray/BlockBlockDist.x10"
        final boolean t$147736 = !(t$147735);
        
        //#line 201 "x10/regionarray/BlockBlockDist.x10"
        if (t$147736) {
            
            //#line 201 "x10/regionarray/BlockBlockDist.x10"
            x10.regionarray.Dist.raiseBoundsError(((x10.lang.Point)(pt)));
        }
        
        //#line 202 "x10/regionarray/BlockBlockDist.x10"
        final long t$147737 = this.axis0;
        
        //#line 202 "x10/regionarray/BlockBlockDist.x10"
        final long t$147739 = pt.$apply$O((long)(t$147737));
        
        //#line 202 "x10/regionarray/BlockBlockDist.x10"
        final long t$147738 = this.axis1;
        
        //#line 202 "x10/regionarray/BlockBlockDist.x10"
        final long t$147740 = pt.$apply$O((long)(t$147738));
        
        //#line 202 "x10/regionarray/BlockBlockDist.x10"
        final x10.lang.Place t$147741 = this.mapIndexToPlace((long)(t$147739), (long)(t$147740));
        
        //#line 202 "x10/regionarray/BlockBlockDist.x10"
        return t$147741;
    }
    
    
    //#line 205 "x10/regionarray/BlockBlockDist.x10"
    public x10.lang.Place $apply(final long i0) {
        
        //#line 207 "x10/regionarray/BlockBlockDist.x10"
        final java.lang.UnsupportedOperationException t$147744 = ((java.lang.UnsupportedOperationException)(new java.lang.UnsupportedOperationException("operator(i0:Long)")));
        
        //#line 207 "x10/regionarray/BlockBlockDist.x10"
        throw t$147744;
    }
    
    
    //#line 210 "x10/regionarray/BlockBlockDist.x10"
    public x10.lang.Place $apply(final long i0, final long i1) {
        
        //#line 211 "x10/regionarray/BlockBlockDist.x10"
        final x10.regionarray.Region t$147747 = ((x10.regionarray.Region)(this.region));
        
        //#line 211 "x10/regionarray/BlockBlockDist.x10"
        final boolean t$147748 = t$147747.contains$O((long)(i0), (long)(i1));
        
        //#line 211 "x10/regionarray/BlockBlockDist.x10"
        final boolean t$147749 = !(t$147748);
        
        //#line 211 "x10/regionarray/BlockBlockDist.x10"
        if (t$147749) {
            
            //#line 211 "x10/regionarray/BlockBlockDist.x10"
            x10.regionarray.Dist.raiseBoundsError((long)(i0), (long)(i1));
        }
        
        //#line 212 "x10/regionarray/BlockBlockDist.x10"
        final long t$147750 = this.axis0;
        
        //#line 212 "x10/regionarray/BlockBlockDist.x10"
        final boolean t$147751 = ((long) t$147750) == ((long) 0L);
        
        //#line 212 "x10/regionarray/BlockBlockDist.x10"
        x10.lang.Place t$147752 =  null;
        
        //#line 212 "x10/regionarray/BlockBlockDist.x10"
        if (t$147751) {
            
            //#line 212 "x10/regionarray/BlockBlockDist.x10"
            t$147752 = this.mapIndexToPlace((long)(i0), (long)(i1));
        } else {
            
            //#line 212 "x10/regionarray/BlockBlockDist.x10"
            t$147752 = this.mapIndexToPlace((long)(i1), (long)(i0));
        }
        
        //#line 212 "x10/regionarray/BlockBlockDist.x10"
        return t$147752;
    }
    
    
    //#line 215 "x10/regionarray/BlockBlockDist.x10"
    public x10.lang.Place $apply(final long i0, final long i1, final long i2) {
        
        //#line 216 "x10/regionarray/BlockBlockDist.x10"
        final x10.regionarray.Region t$147756 = ((x10.regionarray.Region)(this.region));
        
        //#line 216 "x10/regionarray/BlockBlockDist.x10"
        final boolean t$147757 = t$147756.contains$O((long)(i0), (long)(i1), (long)(i2));
        
        //#line 216 "x10/regionarray/BlockBlockDist.x10"
        final boolean t$147758 = !(t$147757);
        
        //#line 216 "x10/regionarray/BlockBlockDist.x10"
        if (t$147758) {
            
            //#line 216 "x10/regionarray/BlockBlockDist.x10"
            x10.regionarray.Dist.raiseBoundsError((long)(i0), (long)(i1), (long)(i2));
        }
        
        //#line 217 "x10/regionarray/BlockBlockDist.x10"
        final long t$147759 = this.axis0;
        
        //#line 217 "x10/regionarray/BlockBlockDist.x10"
        final boolean t$147774 = ((long) t$147759) == ((long) 0L);
        
        //#line 217 "x10/regionarray/BlockBlockDist.x10"
        if (t$147774) {
            
            //#line 218 "x10/regionarray/BlockBlockDist.x10"
            final long t$147760 = this.axis1;
            
            //#line 218 "x10/regionarray/BlockBlockDist.x10"
            final boolean t$147761 = ((long) t$147760) == ((long) 1L);
            
            //#line 218 "x10/regionarray/BlockBlockDist.x10"
            x10.lang.Place t$147762 =  null;
            
            //#line 218 "x10/regionarray/BlockBlockDist.x10"
            if (t$147761) {
                
                //#line 218 "x10/regionarray/BlockBlockDist.x10"
                t$147762 = this.mapIndexToPlace((long)(i0), (long)(i1));
            } else {
                
                //#line 218 "x10/regionarray/BlockBlockDist.x10"
                t$147762 = this.mapIndexToPlace((long)(i0), (long)(i2));
            }
            
            //#line 218 "x10/regionarray/BlockBlockDist.x10"
            return t$147762;
        } else {
            
            //#line 219 "x10/regionarray/BlockBlockDist.x10"
            final long t$147764 = this.axis0;
            
            //#line 219 "x10/regionarray/BlockBlockDist.x10"
            final boolean t$147773 = ((long) t$147764) == ((long) 1L);
            
            //#line 219 "x10/regionarray/BlockBlockDist.x10"
            if (t$147773) {
                
                //#line 220 "x10/regionarray/BlockBlockDist.x10"
                final long t$147765 = this.axis1;
                
                //#line 220 "x10/regionarray/BlockBlockDist.x10"
                final boolean t$147766 = ((long) t$147765) == ((long) 0L);
                
                //#line 220 "x10/regionarray/BlockBlockDist.x10"
                x10.lang.Place t$147767 =  null;
                
                //#line 220 "x10/regionarray/BlockBlockDist.x10"
                if (t$147766) {
                    
                    //#line 220 "x10/regionarray/BlockBlockDist.x10"
                    t$147767 = this.mapIndexToPlace((long)(i1), (long)(i0));
                } else {
                    
                    //#line 220 "x10/regionarray/BlockBlockDist.x10"
                    t$147767 = this.mapIndexToPlace((long)(i1), (long)(i2));
                }
                
                //#line 220 "x10/regionarray/BlockBlockDist.x10"
                return t$147767;
            } else {
                
                //#line 222 "x10/regionarray/BlockBlockDist.x10"
                final long t$147769 = this.axis1;
                
                //#line 222 "x10/regionarray/BlockBlockDist.x10"
                final boolean t$147770 = ((long) t$147769) == ((long) 0L);
                
                //#line 222 "x10/regionarray/BlockBlockDist.x10"
                x10.lang.Place t$147771 =  null;
                
                //#line 222 "x10/regionarray/BlockBlockDist.x10"
                if (t$147770) {
                    
                    //#line 222 "x10/regionarray/BlockBlockDist.x10"
                    t$147771 = this.mapIndexToPlace((long)(i2), (long)(i0));
                } else {
                    
                    //#line 222 "x10/regionarray/BlockBlockDist.x10"
                    t$147771 = this.mapIndexToPlace((long)(i2), (long)(i1));
                }
                
                //#line 222 "x10/regionarray/BlockBlockDist.x10"
                return t$147771;
            }
        }
    }
    
    
    //#line 226 "x10/regionarray/BlockBlockDist.x10"
    public x10.lang.Place $apply(final long i0, final long i1, final long i2, final long i3) {
        
        //#line 154 . "x10/lang/Point.x10"
        final x10.lang.Point alloc$146618 = ((x10.lang.Point)(new x10.lang.Point((java.lang.System[]) null)));
        
        //#line 154 . "x10/lang/Point.x10"
        alloc$146618.x10$lang$Point$$init$S(i0, i1, i2, i3);
        
        //#line 228 "x10/regionarray/BlockBlockDist.x10"
        final x10.regionarray.Region t$147777 = ((x10.regionarray.Region)(this.region));
        
        //#line 228 "x10/regionarray/BlockBlockDist.x10"
        final boolean t$147778 = t$147777.contains$O(((x10.lang.Point)(alloc$146618)));
        
        //#line 228 "x10/regionarray/BlockBlockDist.x10"
        final boolean t$147779 = !(t$147778);
        
        //#line 228 "x10/regionarray/BlockBlockDist.x10"
        if (t$147779) {
            
            //#line 228 "x10/regionarray/BlockBlockDist.x10"
            x10.regionarray.Dist.raiseBoundsError(((x10.lang.Point)(alloc$146618)));
        }
        
        //#line 229 "x10/regionarray/BlockBlockDist.x10"
        final long t$147780 = this.axis0;
        
        //#line 229 "x10/regionarray/BlockBlockDist.x10"
        final long t$147782 = alloc$146618.$apply$O((long)(t$147780));
        
        //#line 229 "x10/regionarray/BlockBlockDist.x10"
        final long t$147781 = this.axis1;
        
        //#line 229 "x10/regionarray/BlockBlockDist.x10"
        final long t$147783 = alloc$146618.$apply$O((long)(t$147781));
        
        //#line 229 "x10/regionarray/BlockBlockDist.x10"
        final x10.lang.Place t$147784 = this.mapIndexToPlace((long)(t$147782), (long)(t$147783));
        
        //#line 229 "x10/regionarray/BlockBlockDist.x10"
        return t$147784;
    }
    
    
    //#line 232 "x10/regionarray/BlockBlockDist.x10"
    public x10.regionarray.Dist restriction(final x10.regionarray.Region r) {
        
        //#line 233 "x10/regionarray/BlockBlockDist.x10"
        final x10.regionarray.WrappedDistRegionRestricted alloc$143723 = ((x10.regionarray.WrappedDistRegionRestricted)(new x10.regionarray.WrappedDistRegionRestricted((java.lang.System[]) null)));
        
        //#line 233 "x10/regionarray/BlockBlockDist.x10"
        alloc$143723.x10$regionarray$WrappedDistRegionRestricted$$init$S(((x10.regionarray.Dist)(this)), ((x10.regionarray.Region)(r)));
        
        //#line 233 "x10/regionarray/BlockBlockDist.x10"
        return alloc$143723;
    }
    
    
    //#line 236 "x10/regionarray/BlockBlockDist.x10"
    public x10.regionarray.Dist restriction(final x10.lang.Place p) {
        
        //#line 237 "x10/regionarray/BlockBlockDist.x10"
        final x10.regionarray.WrappedDistPlaceRestricted alloc$143724 = ((x10.regionarray.WrappedDistPlaceRestricted)(new x10.regionarray.WrappedDistPlaceRestricted((java.lang.System[]) null)));
        
        //#line 237 "x10/regionarray/BlockBlockDist.x10"
        alloc$143724.x10$regionarray$WrappedDistPlaceRestricted$$init$S(((x10.regionarray.Dist)(this)), ((x10.lang.Place)(p)));
        
        //#line 237 "x10/regionarray/BlockBlockDist.x10"
        return alloc$143724;
    }
    
    
    //#line 240 "x10/regionarray/BlockBlockDist.x10"
    public x10.regionarray.BlockBlockDistGhostManager getLocalGhostManager(final long ghostWidth, final boolean periodic) {
        
        //#line 241 "x10/regionarray/BlockBlockDist.x10"
        final x10.regionarray.BlockBlockDistGhostManager alloc$143725 = ((x10.regionarray.BlockBlockDistGhostManager)(new x10.regionarray.BlockBlockDistGhostManager((java.lang.System[]) null)));
        
        //#line 241 "x10/regionarray/BlockBlockDist.x10"
        alloc$143725.x10$regionarray$BlockBlockDistGhostManager$$init$S(((long)(ghostWidth)), ((x10.regionarray.Dist)(this)), ((boolean)(periodic)));
        
        //#line 241 "x10/regionarray/BlockBlockDist.x10"
        return alloc$143725;
    }
    
    
    //#line 244 "x10/regionarray/BlockBlockDist.x10"
    public boolean equals(final java.lang.Object thatObj) {
        
        //#line 245 "x10/regionarray/BlockBlockDist.x10"
        final boolean t$147785 = x10.regionarray.BlockBlockDist.$RTT.isInstance(thatObj);
        
        //#line 245 "x10/regionarray/BlockBlockDist.x10"
        final boolean t$147786 = !(t$147785);
        
        //#line 245 "x10/regionarray/BlockBlockDist.x10"
        if (t$147786) {
            
            //#line 245 "x10/regionarray/BlockBlockDist.x10"
            return false;
        }
        
        //#line 246 "x10/regionarray/BlockBlockDist.x10"
        final x10.regionarray.BlockBlockDist that = ((x10.regionarray.BlockBlockDist)(x10.rtt.Types.<x10.regionarray.BlockBlockDist> cast(thatObj,x10.regionarray.BlockBlockDist.$RTT)));
        
        //#line 247 "x10/regionarray/BlockBlockDist.x10"
        final long t$147787 = this.axis0;
        
        //#line 247 "x10/regionarray/BlockBlockDist.x10"
        final long t$147788 = that.axis0;
        
        //#line 247 "x10/regionarray/BlockBlockDist.x10"
        boolean t$147791 = x10.rtt.Equality.equalsequals(t$147787, ((long)(t$147788)));
        
        //#line 247 "x10/regionarray/BlockBlockDist.x10"
        if (t$147791) {
            
            //#line 247 "x10/regionarray/BlockBlockDist.x10"
            final long t$147789 = this.axis1;
            
            //#line 247 "x10/regionarray/BlockBlockDist.x10"
            final long t$147790 = that.axis1;
            
            //#line 247 "x10/regionarray/BlockBlockDist.x10"
            t$147791 = x10.rtt.Equality.equalsequals(t$147789, ((long)(t$147790)));
        }
        
        //#line 247 "x10/regionarray/BlockBlockDist.x10"
        boolean t$147794 = t$147791;
        
        //#line 247 "x10/regionarray/BlockBlockDist.x10"
        if (t$147791) {
            
            //#line 247 "x10/regionarray/BlockBlockDist.x10"
            final x10.regionarray.Region t$147792 = ((x10.regionarray.Region)(this.region));
            
            //#line 247 "x10/regionarray/BlockBlockDist.x10"
            final x10.regionarray.Region t$147793 = ((x10.regionarray.Region)(that.region));
            
            //#line 247 "x10/regionarray/BlockBlockDist.x10"
            t$147794 = t$147792.equals(((java.lang.Object)(t$147793)));
        }
        
        //#line 247 "x10/regionarray/BlockBlockDist.x10"
        return t$147794;
    }
    
    
    //#line 27 "x10/regionarray/BlockBlockDist.x10"
    final public x10.regionarray.BlockBlockDist x10$regionarray$BlockBlockDist$$this$x10$regionarray$BlockBlockDist() {
        
        //#line 27 "x10/regionarray/BlockBlockDist.x10"
        return x10.regionarray.BlockBlockDist.this;
    }
    
    
    //#line 27 "x10/regionarray/BlockBlockDist.x10"
    final public void __fieldInitializers_x10_regionarray_BlockBlockDist() {
        
        //#line 27 "x10/regionarray/BlockBlockDist.x10"
        this.regionForHere = null;
    }
    
    @x10.runtime.impl.java.X10Generated
    final public static class $Closure$204 extends x10.core.Ref implements x10.core.fun.Fun_0_1, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<$Closure$204> $RTT = 
            x10.rtt.StaticFunType.<$Closure$204> make($Closure$204.class,
                                                      new x10.rtt.Type[] {
                                                          x10.rtt.ParameterizedType.make(x10.core.fun.Fun_0_1.$RTT, x10.rtt.Types.LONG, x10.rtt.Types.LONG)
                                                      });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static x10.serialization.X10JavaSerializable $_deserialize_body(x10.regionarray.BlockBlockDist.$Closure$204 $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            $_obj.out$$ = $deserializer.readObject();
            $_obj.region = $deserializer.readObject();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.regionarray.BlockBlockDist.$Closure$204 $_obj = new x10.regionarray.BlockBlockDist.$Closure$204((java.lang.System[]) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            $serializer.write(this.out$$);
            $serializer.write(this.region);
            
        }
        
        // constructor just for allocation
        public $Closure$204(final java.lang.System[] $dummy) {
            
        }
        
        // dispatcher for method abstract public (Z1)=>U.operator()(a1:Z1):U
        public java.lang.Object $apply(final java.lang.Object a1, final x10.rtt.Type t1) {
            return x10.core.Long.$box($apply$O(x10.core.Long.$unbox(a1)));
            
        }
        
        // dispatcher for method abstract public (Z1)=>U.operator()(a1:Z1):U
        public long $apply$J(final java.lang.Object a1, final x10.rtt.Type t1) {
            return $apply$O(x10.core.Long.$unbox(a1));
            
        }
        
        
    
        
        public long $apply$O(final long i) {
            
            //#line 103 "x10/regionarray/BlockBlockDist.x10"
            final x10.regionarray.Region t$147591 = ((x10.regionarray.Region)(this.region));
            
            //#line 103 "x10/regionarray/BlockBlockDist.x10"
            final int t$147590 = ((int)(long)(((long)(i))));
            
            //#line 103 "x10/regionarray/BlockBlockDist.x10"
            final long t$147592 = ((long)(((int)(t$147590))));
            
            //#line 103 "x10/regionarray/BlockBlockDist.x10"
            final long t$147593 = t$147591.min$O((long)(t$147592));
            
            //#line 103 "x10/regionarray/BlockBlockDist.x10"
            return t$147593;
        }
        
        public x10.regionarray.BlockBlockDist out$$;
        public x10.regionarray.Region region;
        
        public $Closure$204(final x10.regionarray.BlockBlockDist out$$, final x10.regionarray.Region region) {
             {
                this.out$$ = out$$;
                this.region = ((x10.regionarray.Region)(region));
            }
        }
        
    }
    
    @x10.runtime.impl.java.X10Generated
    final public static class $Closure$205 extends x10.core.Ref implements x10.core.fun.Fun_0_1, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<$Closure$205> $RTT = 
            x10.rtt.StaticFunType.<$Closure$205> make($Closure$205.class,
                                                      new x10.rtt.Type[] {
                                                          x10.rtt.ParameterizedType.make(x10.core.fun.Fun_0_1.$RTT, x10.rtt.Types.LONG, x10.rtt.Types.LONG)
                                                      });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static x10.serialization.X10JavaSerializable $_deserialize_body(x10.regionarray.BlockBlockDist.$Closure$205 $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            $_obj.out$$ = $deserializer.readObject();
            $_obj.region = $deserializer.readObject();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.regionarray.BlockBlockDist.$Closure$205 $_obj = new x10.regionarray.BlockBlockDist.$Closure$205((java.lang.System[]) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            $serializer.write(this.out$$);
            $serializer.write(this.region);
            
        }
        
        // constructor just for allocation
        public $Closure$205(final java.lang.System[] $dummy) {
            
        }
        
        // dispatcher for method abstract public (Z1)=>U.operator()(a1:Z1):U
        public java.lang.Object $apply(final java.lang.Object a1, final x10.rtt.Type t1) {
            return x10.core.Long.$box($apply$O(x10.core.Long.$unbox(a1)));
            
        }
        
        // dispatcher for method abstract public (Z1)=>U.operator()(a1:Z1):U
        public long $apply$J(final java.lang.Object a1, final x10.rtt.Type t1) {
            return $apply$O(x10.core.Long.$unbox(a1));
            
        }
        
        
    
        
        public long $apply$O(final long i) {
            
            //#line 104 "x10/regionarray/BlockBlockDist.x10"
            final x10.regionarray.Region t$147598 = ((x10.regionarray.Region)(this.region));
            
            //#line 104 "x10/regionarray/BlockBlockDist.x10"
            final int t$147597 = ((int)(long)(((long)(i))));
            
            //#line 104 "x10/regionarray/BlockBlockDist.x10"
            final long t$147599 = ((long)(((int)(t$147597))));
            
            //#line 104 "x10/regionarray/BlockBlockDist.x10"
            final long t$147600 = t$147598.max$O((long)(t$147599));
            
            //#line 104 "x10/regionarray/BlockBlockDist.x10"
            return t$147600;
        }
        
        public x10.regionarray.BlockBlockDist out$$;
        public x10.regionarray.Region region;
        
        public $Closure$205(final x10.regionarray.BlockBlockDist out$$, final x10.regionarray.Region region) {
             {
                this.out$$ = out$$;
                this.region = ((x10.regionarray.Region)(region));
            }
        }
        
    }
    
    @x10.runtime.impl.java.X10Generated
    final public static class $Closure$206 extends x10.core.Ref implements x10.core.fun.Fun_0_1, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<$Closure$206> $RTT = 
            x10.rtt.StaticFunType.<$Closure$206> make($Closure$206.class,
                                                      new x10.rtt.Type[] {
                                                          x10.rtt.ParameterizedType.make(x10.core.fun.Fun_0_1.$RTT, x10.rtt.Types.LONG, x10.regionarray.Region.$RTT)
                                                      });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static x10.serialization.X10JavaSerializable $_deserialize_body(x10.regionarray.BlockBlockDist.$Closure$206 $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            $_obj.out$$ = $deserializer.readObject();
            $_obj.pg = $deserializer.readObject();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.regionarray.BlockBlockDist.$Closure$206 $_obj = new x10.regionarray.BlockBlockDist.$Closure$206((java.lang.System[]) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            $serializer.write(this.out$$);
            $serializer.write(this.pg);
            
        }
        
        // constructor just for allocation
        public $Closure$206(final java.lang.System[] $dummy) {
            
        }
        
        // dispatcher for method abstract public (Z1)=>U.operator()(a1:Z1):U
        public java.lang.Object $apply(final java.lang.Object a1, final x10.rtt.Type t1) {
            return $apply(x10.core.Long.$unbox(a1));
            
        }
        
        
    
        
        public x10.regionarray.Region $apply(final long i) {
            
            //#line 181 "x10/regionarray/BlockBlockDist.x10"
            final x10.lang.PlaceGroup t$147718 = ((x10.lang.PlaceGroup)(this.pg));
            
            //#line 181 "x10/regionarray/BlockBlockDist.x10"
            final int t$147717 = ((int)(long)(((long)(i))));
            
            //#line 181 "x10/regionarray/BlockBlockDist.x10"
            final long t$147719 = ((long)(((int)(t$147717))));
            
            //#line 181 "x10/regionarray/BlockBlockDist.x10"
            final x10.lang.Place t$147720 = t$147718.$apply((long)(t$147719));
            
            //#line 181 "x10/regionarray/BlockBlockDist.x10"
            final x10.regionarray.Region t$147721 = ((x10.regionarray.Region)(this.out$$.blockBlockRegionForPlace(((x10.lang.Place)(t$147720)))));
            
            //#line 181 "x10/regionarray/BlockBlockDist.x10"
            return t$147721;
        }
        
        public x10.regionarray.BlockBlockDist out$$;
        public x10.lang.PlaceGroup pg;
        
        public $Closure$206(final x10.regionarray.BlockBlockDist out$$, final x10.lang.PlaceGroup pg) {
             {
                this.out$$ = out$$;
                this.pg = ((x10.lang.PlaceGroup)(pg));
            }
        }
        
    }
    
}

