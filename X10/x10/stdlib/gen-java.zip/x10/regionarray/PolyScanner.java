package x10.regionarray;


/**
 * Here's the general scheme for the information used in scanning,
 * illustrated for a region of rank r=4. Each axis Xi is bounded by
 * two sets of halfspaces, min[i] and max[i], obtained from the
 * region halfspaces by FME (resulting in the 0 coefficients as
 * shown). Computing the bounds for Xi requires substituting X0 up to
 * Xi-1 into each halfspace (as shown for the min[i]s) and taking
 * mins and maxes.
 *
 *           0   1   2   r-1
 * 
 * min[0]
 *           A0  0   0   0   B   X0 bounded by B / A0
 *           A0  0   0   0   B   X0 bounded by B / A0
 *           ...                 ...
 * 
 * min[1]
 *           A0  A1  0   0   B   X1 bounded by (B+A0*X0) / A1
 *           A0  A1  0   0   B   X1 bounded by (B+A0*X0) / A1
 *           ...                 ...
 * 
 * min[2]
 *           A0  A1  A2  0   B   X2 bounded by (B+A0*X0+A1*X1) / A2
 *           A0  A1  A2  0   B   X2 bounded by (B+A0*X0+A1*X1) / A2
 *           ...                 ...
 * 
 * min[3]
 *           A0  A1  A2  A3  B   X3 bounded by (B+A0*X0+A1*X1+A2*X2) / A3
 *           A0  A1  A2  A3  B   X3 bounded by (B+A0*X0+A1*X1+A2*X2) / A3
 *           ...                 ...
 *
 * In the innermost loop the bounds for X3 could be computed by
 * substituting the known values of X0 through X2 into each
 * halfspace. However, part of that computation can be pulled out of
 * the inner loop by keeping track for each halfspace in in min[k]
 * and each constraint in max[k] a set of partial sums of the form
 *
 *     minSum[0] = B
 *     minSum[1] = B+A0*X0
 *     ...
 *     minSum[k] = B+A0*X0+A1*X1+...+Ak-1*Xk-1
 *
 * (and similiarly for maxSum) and updating each partial sum
 * minSum[i+1] (and similarly for maxSum[i+1]) every time Xi changes
 * by
 *
 *     minSum[i+1] := sum[i] + Ai*Xi
 *
 * The loop bounds for Xk are then obtained by computing mins and
 * maxes over the sum[k]/Ak for the halfspaces in elim[k].
 */
@x10.runtime.impl.java.X10Generated
final public class PolyScanner extends x10.core.Ref implements x10.serialization.X10JavaSerializable
{
    public static final x10.rtt.RuntimeType<PolyScanner> $RTT = 
        x10.rtt.NamedType.<PolyScanner> make("x10.regionarray.PolyScanner",
                                             PolyScanner.class);
    
    public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
    
    public x10.rtt.Type<?> $getParam(int i) { return null; }
    
    private Object writeReplace() throws java.io.ObjectStreamException {
        return new x10.serialization.SerializationProxy(this);
    }
    
    public static x10.serialization.X10JavaSerializable $_deserialize_body(x10.regionarray.PolyScanner $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
        $_obj.C = $deserializer.readObject();
        $_obj.max2 = $deserializer.readObject();
        $_obj.maxSum = $deserializer.readObject();
        $_obj.min2 = $deserializer.readObject();
        $_obj.minSum = $deserializer.readObject();
        $_obj.myMax = $deserializer.readObject();
        $_obj.myMin = $deserializer.readObject();
        $_obj.parFlags = $deserializer.readObject();
        $_obj.rank = $deserializer.readLong();
        return $_obj;
    }
    
    public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
        x10.regionarray.PolyScanner $_obj = new x10.regionarray.PolyScanner((java.lang.System[]) null);
        $deserializer.record_reference($_obj);
        return $_deserialize_body($_obj, $deserializer);
    }
    
    public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
        $serializer.write(this.C);
        $serializer.write(this.max2);
        $serializer.write(this.maxSum);
        $serializer.write(this.min2);
        $serializer.write(this.minSum);
        $serializer.write(this.myMax);
        $serializer.write(this.myMin);
        $serializer.write(this.parFlags);
        $serializer.write(this.rank);
        
    }
    
    // constructor just for allocation
    public PolyScanner(final java.lang.System[] $dummy) {
        
    }
    
    
    // properties
    
    //#line 68 "x10/regionarray/PolyScanner.x10"
    public long rank;
    

    
    //#line 70 "x10/regionarray/PolyScanner.x10"
    public x10.regionarray.PolyMat C;
    
    //#line 74 "x10/regionarray/PolyScanner.x10"
    public x10.regionarray.Array<x10.regionarray.VarMat> myMin;
    
    //#line 75 "x10/regionarray/PolyScanner.x10"
    public x10.regionarray.Array<x10.regionarray.VarMat> myMax;
    
    //#line 76 "x10/regionarray/PolyScanner.x10"
    public x10.regionarray.Array<x10.regionarray.VarMat> minSum;
    
    //#line 77 "x10/regionarray/PolyScanner.x10"
    public x10.regionarray.Array<x10.regionarray.VarMat> maxSum;
    
    //#line 79 "x10/regionarray/PolyScanner.x10"
    public x10.regionarray.Array<x10.core.Boolean> parFlags;
    
    //#line 80 "x10/regionarray/PolyScanner.x10"
    public x10.regionarray.Array<x10.regionarray.Array<x10.regionarray.PolyRow>> min2;
    
    //#line 81 "x10/regionarray/PolyScanner.x10"
    public x10.regionarray.Array<x10.regionarray.Array<x10.regionarray.PolyRow>> max2;
    
    
    //#line 83 "x10/regionarray/PolyScanner.x10"
    public static x10.regionarray.PolyScanner make(final x10.regionarray.PolyMat pm) {
        
        //#line 84 "x10/regionarray/PolyScanner.x10"
        final x10.regionarray.PolyScanner x = ((x10.regionarray.PolyScanner)(new x10.regionarray.PolyScanner((java.lang.System[]) null)));
        
        //#line 84 "x10/regionarray/PolyScanner.x10"
        x.x10$regionarray$PolyScanner$$init$S(((x10.regionarray.PolyMat)(pm)));
        
        //#line 85 "x10/regionarray/PolyScanner.x10"
        x.init();
        
        //#line 86 "x10/regionarray/PolyScanner.x10"
        return x;
    }
    
    
    //#line 89 "x10/regionarray/PolyScanner.x10"
    // creation method for java code (1-phase java constructor)
    public PolyScanner(final x10.regionarray.PolyMat pm) {
        this((java.lang.System[]) null);
        x10$regionarray$PolyScanner$$init$S(pm);
    }
    
    // constructor for non-virtual call
    final public x10.regionarray.PolyScanner x10$regionarray$PolyScanner$$init$S(final x10.regionarray.PolyMat pm) {
         {
            
            //#line 90 "x10/regionarray/PolyScanner.x10"
            final long t$156598 = pm.rank;
            
            //#line 90 "x10/regionarray/PolyScanner.x10"
            this.rank = t$156598;
            
            
            //#line 91 "x10/regionarray/PolyScanner.x10"
            x10.regionarray.PolyMat pm0 = pm.simplifyAll();
            
            //#line 93 "x10/regionarray/PolyScanner.x10"
            this.C = ((x10.regionarray.PolyMat)(pm));
            
            //#line 94 "x10/regionarray/PolyScanner.x10"
            final long r = pm0.rank;
            
            //#line 95 "x10/regionarray/PolyScanner.x10"
            final x10.regionarray.Array n = ((x10.regionarray.Array)(new x10.regionarray.Array<x10.regionarray.VarMat>((java.lang.System[]) null, x10.regionarray.VarMat.$RTT)));
            
            //#line 270 . "x10/regionarray/Array.x10"
            final x10.regionarray.RectRegion1D myReg$156614 = ((x10.regionarray.RectRegion1D)(new x10.regionarray.RectRegion1D((java.lang.System[]) null)));
            
            //#line 270 . "x10/regionarray/Array.x10"
            final long t$156599 = ((r) - (((long)(1L))));
            
            //#line 270 . "x10/regionarray/Array.x10"
            myReg$156614.x10$regionarray$RectRegion1D$$init$S(t$156599);
            
            //#line 271 . "x10/regionarray/Array.x10"
            final x10.regionarray.Region t$156600 = ((x10.regionarray.Region)
                                                      myReg$156614);
            
            //#line 271 . "x10/regionarray/Array.x10"
            ((x10.regionarray.Array<x10.regionarray.VarMat>)n).region = ((x10.regionarray.Region)(t$156600));
            
            //#line 271 . "x10/regionarray/Array.x10"
            ((x10.regionarray.Array<x10.regionarray.VarMat>)n).rank = 1L;
            
            //#line 271 . "x10/regionarray/Array.x10"
            ((x10.regionarray.Array<x10.regionarray.VarMat>)n).rect = true;
            
            //#line 271 . "x10/regionarray/Array.x10"
            ((x10.regionarray.Array<x10.regionarray.VarMat>)n).zeroBased = true;
            
            //#line 271 . "x10/regionarray/Array.x10"
            ((x10.regionarray.Array<x10.regionarray.VarMat>)n).rail = true;
            
            //#line 271 . "x10/regionarray/Array.x10"
            ((x10.regionarray.Array<x10.regionarray.VarMat>)n).size = r;
            
            //#line 273 . "x10/regionarray/Array.x10"
            final long t$156615 = ((x10.regionarray.Array<x10.regionarray.VarMat>)n).layout_min1 = 0L;
            
            //#line 273 . "x10/regionarray/Array.x10"
            final long t$156616 = ((x10.regionarray.Array<x10.regionarray.VarMat>)n).layout_stride1 = t$156615;
            
            //#line 273 . "x10/regionarray/Array.x10"
            ((x10.regionarray.Array<x10.regionarray.VarMat>)n).layout_min0 = t$156616;
            
            //#line 274 . "x10/regionarray/Array.x10"
            ((x10.regionarray.Array<x10.regionarray.VarMat>)n).layout = null;
            
            //#line 275 . "x10/regionarray/Array.x10"
            final x10.core.Rail t$156617 = ((x10.core.Rail)(new x10.core.Rail<x10.regionarray.VarMat>(x10.regionarray.VarMat.$RTT, r)));
            
            //#line 275 . "x10/regionarray/Array.x10"
            ((x10.regionarray.Array<x10.regionarray.VarMat>)n).raw = ((x10.core.Rail)(t$156617));
            
            //#line 96 "x10/regionarray/PolyScanner.x10"
            this.myMin = ((x10.regionarray.Array)(n));
            
            //#line 97 "x10/regionarray/PolyScanner.x10"
            final x10.regionarray.Array x = ((x10.regionarray.Array)(new x10.regionarray.Array<x10.regionarray.VarMat>((java.lang.System[]) null, x10.regionarray.VarMat.$RTT)));
            
            //#line 270 . "x10/regionarray/Array.x10"
            final x10.regionarray.RectRegion1D myReg$156618 = ((x10.regionarray.RectRegion1D)(new x10.regionarray.RectRegion1D((java.lang.System[]) null)));
            
            //#line 270 . "x10/regionarray/Array.x10"
            final long t$156601 = ((r) - (((long)(1L))));
            
            //#line 270 . "x10/regionarray/Array.x10"
            myReg$156618.x10$regionarray$RectRegion1D$$init$S(t$156601);
            
            //#line 271 . "x10/regionarray/Array.x10"
            final x10.regionarray.Region t$156602 = ((x10.regionarray.Region)
                                                      myReg$156618);
            
            //#line 271 . "x10/regionarray/Array.x10"
            ((x10.regionarray.Array<x10.regionarray.VarMat>)x).region = ((x10.regionarray.Region)(t$156602));
            
            //#line 271 . "x10/regionarray/Array.x10"
            ((x10.regionarray.Array<x10.regionarray.VarMat>)x).rank = 1L;
            
            //#line 271 . "x10/regionarray/Array.x10"
            ((x10.regionarray.Array<x10.regionarray.VarMat>)x).rect = true;
            
            //#line 271 . "x10/regionarray/Array.x10"
            ((x10.regionarray.Array<x10.regionarray.VarMat>)x).zeroBased = true;
            
            //#line 271 . "x10/regionarray/Array.x10"
            ((x10.regionarray.Array<x10.regionarray.VarMat>)x).rail = true;
            
            //#line 271 . "x10/regionarray/Array.x10"
            ((x10.regionarray.Array<x10.regionarray.VarMat>)x).size = r;
            
            //#line 273 . "x10/regionarray/Array.x10"
            final long t$156619 = ((x10.regionarray.Array<x10.regionarray.VarMat>)x).layout_min1 = 0L;
            
            //#line 273 . "x10/regionarray/Array.x10"
            final long t$156620 = ((x10.regionarray.Array<x10.regionarray.VarMat>)x).layout_stride1 = t$156619;
            
            //#line 273 . "x10/regionarray/Array.x10"
            ((x10.regionarray.Array<x10.regionarray.VarMat>)x).layout_min0 = t$156620;
            
            //#line 274 . "x10/regionarray/Array.x10"
            ((x10.regionarray.Array<x10.regionarray.VarMat>)x).layout = null;
            
            //#line 275 . "x10/regionarray/Array.x10"
            final x10.core.Rail t$156621 = ((x10.core.Rail)(new x10.core.Rail<x10.regionarray.VarMat>(x10.regionarray.VarMat.$RTT, r)));
            
            //#line 275 . "x10/regionarray/Array.x10"
            ((x10.regionarray.Array<x10.regionarray.VarMat>)x).raw = ((x10.core.Rail)(t$156621));
            
            //#line 98 "x10/regionarray/PolyScanner.x10"
            this.myMax = ((x10.regionarray.Array)(x));
            
            //#line 99 "x10/regionarray/PolyScanner.x10"
            final x10.regionarray.Array nSum = ((x10.regionarray.Array)(new x10.regionarray.Array<x10.regionarray.VarMat>((java.lang.System[]) null, x10.regionarray.VarMat.$RTT)));
            
            //#line 270 . "x10/regionarray/Array.x10"
            final x10.regionarray.RectRegion1D myReg$156622 = ((x10.regionarray.RectRegion1D)(new x10.regionarray.RectRegion1D((java.lang.System[]) null)));
            
            //#line 270 . "x10/regionarray/Array.x10"
            final long t$156603 = ((r) - (((long)(1L))));
            
            //#line 270 . "x10/regionarray/Array.x10"
            myReg$156622.x10$regionarray$RectRegion1D$$init$S(t$156603);
            
            //#line 271 . "x10/regionarray/Array.x10"
            final x10.regionarray.Region t$156604 = ((x10.regionarray.Region)
                                                      myReg$156622);
            
            //#line 271 . "x10/regionarray/Array.x10"
            ((x10.regionarray.Array<x10.regionarray.VarMat>)nSum).region = ((x10.regionarray.Region)(t$156604));
            
            //#line 271 . "x10/regionarray/Array.x10"
            ((x10.regionarray.Array<x10.regionarray.VarMat>)nSum).rank = 1L;
            
            //#line 271 . "x10/regionarray/Array.x10"
            ((x10.regionarray.Array<x10.regionarray.VarMat>)nSum).rect = true;
            
            //#line 271 . "x10/regionarray/Array.x10"
            ((x10.regionarray.Array<x10.regionarray.VarMat>)nSum).zeroBased = true;
            
            //#line 271 . "x10/regionarray/Array.x10"
            ((x10.regionarray.Array<x10.regionarray.VarMat>)nSum).rail = true;
            
            //#line 271 . "x10/regionarray/Array.x10"
            ((x10.regionarray.Array<x10.regionarray.VarMat>)nSum).size = r;
            
            //#line 273 . "x10/regionarray/Array.x10"
            final long t$156623 = ((x10.regionarray.Array<x10.regionarray.VarMat>)nSum).layout_min1 = 0L;
            
            //#line 273 . "x10/regionarray/Array.x10"
            final long t$156624 = ((x10.regionarray.Array<x10.regionarray.VarMat>)nSum).layout_stride1 = t$156623;
            
            //#line 273 . "x10/regionarray/Array.x10"
            ((x10.regionarray.Array<x10.regionarray.VarMat>)nSum).layout_min0 = t$156624;
            
            //#line 274 . "x10/regionarray/Array.x10"
            ((x10.regionarray.Array<x10.regionarray.VarMat>)nSum).layout = null;
            
            //#line 275 . "x10/regionarray/Array.x10"
            final x10.core.Rail t$156625 = ((x10.core.Rail)(new x10.core.Rail<x10.regionarray.VarMat>(x10.regionarray.VarMat.$RTT, r)));
            
            //#line 275 . "x10/regionarray/Array.x10"
            ((x10.regionarray.Array<x10.regionarray.VarMat>)nSum).raw = ((x10.core.Rail)(t$156625));
            
            //#line 100 "x10/regionarray/PolyScanner.x10"
            this.minSum = ((x10.regionarray.Array)(nSum));
            
            //#line 101 "x10/regionarray/PolyScanner.x10"
            final x10.regionarray.Array xSum = ((x10.regionarray.Array)(new x10.regionarray.Array<x10.regionarray.VarMat>((java.lang.System[]) null, x10.regionarray.VarMat.$RTT)));
            
            //#line 270 . "x10/regionarray/Array.x10"
            final x10.regionarray.RectRegion1D myReg$156626 = ((x10.regionarray.RectRegion1D)(new x10.regionarray.RectRegion1D((java.lang.System[]) null)));
            
            //#line 270 . "x10/regionarray/Array.x10"
            final long t$156605 = ((r) - (((long)(1L))));
            
            //#line 270 . "x10/regionarray/Array.x10"
            myReg$156626.x10$regionarray$RectRegion1D$$init$S(t$156605);
            
            //#line 271 . "x10/regionarray/Array.x10"
            final x10.regionarray.Region t$156606 = ((x10.regionarray.Region)
                                                      myReg$156626);
            
            //#line 271 . "x10/regionarray/Array.x10"
            ((x10.regionarray.Array<x10.regionarray.VarMat>)xSum).region = ((x10.regionarray.Region)(t$156606));
            
            //#line 271 . "x10/regionarray/Array.x10"
            ((x10.regionarray.Array<x10.regionarray.VarMat>)xSum).rank = 1L;
            
            //#line 271 . "x10/regionarray/Array.x10"
            ((x10.regionarray.Array<x10.regionarray.VarMat>)xSum).rect = true;
            
            //#line 271 . "x10/regionarray/Array.x10"
            ((x10.regionarray.Array<x10.regionarray.VarMat>)xSum).zeroBased = true;
            
            //#line 271 . "x10/regionarray/Array.x10"
            ((x10.regionarray.Array<x10.regionarray.VarMat>)xSum).rail = true;
            
            //#line 271 . "x10/regionarray/Array.x10"
            ((x10.regionarray.Array<x10.regionarray.VarMat>)xSum).size = r;
            
            //#line 273 . "x10/regionarray/Array.x10"
            final long t$156627 = ((x10.regionarray.Array<x10.regionarray.VarMat>)xSum).layout_min1 = 0L;
            
            //#line 273 . "x10/regionarray/Array.x10"
            final long t$156628 = ((x10.regionarray.Array<x10.regionarray.VarMat>)xSum).layout_stride1 = t$156627;
            
            //#line 273 . "x10/regionarray/Array.x10"
            ((x10.regionarray.Array<x10.regionarray.VarMat>)xSum).layout_min0 = t$156628;
            
            //#line 274 . "x10/regionarray/Array.x10"
            ((x10.regionarray.Array<x10.regionarray.VarMat>)xSum).layout = null;
            
            //#line 275 . "x10/regionarray/Array.x10"
            final x10.core.Rail t$156629 = ((x10.core.Rail)(new x10.core.Rail<x10.regionarray.VarMat>(x10.regionarray.VarMat.$RTT, r)));
            
            //#line 275 . "x10/regionarray/Array.x10"
            ((x10.regionarray.Array<x10.regionarray.VarMat>)xSum).raw = ((x10.core.Rail)(t$156629));
            
            //#line 102 "x10/regionarray/PolyScanner.x10"
            this.maxSum = ((x10.regionarray.Array)(xSum));
            
            //#line 103 "x10/regionarray/PolyScanner.x10"
            final x10.regionarray.Array n2 = ((x10.regionarray.Array)(new x10.regionarray.Array<x10.regionarray.Array<x10.regionarray.PolyRow>>((java.lang.System[]) null, x10.rtt.ParameterizedType.make(x10.regionarray.Array.$RTT, x10.regionarray.PolyRow.$RTT))));
            
            //#line 270 . "x10/regionarray/Array.x10"
            final x10.regionarray.RectRegion1D myReg$156630 = ((x10.regionarray.RectRegion1D)(new x10.regionarray.RectRegion1D((java.lang.System[]) null)));
            
            //#line 270 . "x10/regionarray/Array.x10"
            final long t$156607 = ((r) - (((long)(1L))));
            
            //#line 270 . "x10/regionarray/Array.x10"
            myReg$156630.x10$regionarray$RectRegion1D$$init$S(t$156607);
            
            //#line 271 . "x10/regionarray/Array.x10"
            final x10.regionarray.Region t$156608 = ((x10.regionarray.Region)
                                                      myReg$156630);
            
            //#line 271 . "x10/regionarray/Array.x10"
            ((x10.regionarray.Array<x10.regionarray.Array<x10.regionarray.PolyRow>>)n2).region = ((x10.regionarray.Region)(t$156608));
            
            //#line 271 . "x10/regionarray/Array.x10"
            ((x10.regionarray.Array<x10.regionarray.Array<x10.regionarray.PolyRow>>)n2).rank = 1L;
            
            //#line 271 . "x10/regionarray/Array.x10"
            ((x10.regionarray.Array<x10.regionarray.Array<x10.regionarray.PolyRow>>)n2).rect = true;
            
            //#line 271 . "x10/regionarray/Array.x10"
            ((x10.regionarray.Array<x10.regionarray.Array<x10.regionarray.PolyRow>>)n2).zeroBased = true;
            
            //#line 271 . "x10/regionarray/Array.x10"
            ((x10.regionarray.Array<x10.regionarray.Array<x10.regionarray.PolyRow>>)n2).rail = true;
            
            //#line 271 . "x10/regionarray/Array.x10"
            ((x10.regionarray.Array<x10.regionarray.Array<x10.regionarray.PolyRow>>)n2).size = r;
            
            //#line 273 . "x10/regionarray/Array.x10"
            final long t$156631 = ((x10.regionarray.Array<x10.regionarray.Array<x10.regionarray.PolyRow>>)n2).layout_min1 = 0L;
            
            //#line 273 . "x10/regionarray/Array.x10"
            final long t$156632 = ((x10.regionarray.Array<x10.regionarray.Array<x10.regionarray.PolyRow>>)n2).layout_stride1 = t$156631;
            
            //#line 273 . "x10/regionarray/Array.x10"
            ((x10.regionarray.Array<x10.regionarray.Array<x10.regionarray.PolyRow>>)n2).layout_min0 = t$156632;
            
            //#line 274 . "x10/regionarray/Array.x10"
            ((x10.regionarray.Array<x10.regionarray.Array<x10.regionarray.PolyRow>>)n2).layout = null;
            
            //#line 275 . "x10/regionarray/Array.x10"
            final x10.core.Rail t$156633 = ((x10.core.Rail)(new x10.core.Rail<x10.regionarray.Array<x10.regionarray.PolyRow>>(x10.rtt.ParameterizedType.make(x10.regionarray.Array.$RTT, x10.regionarray.PolyRow.$RTT), r)));
            
            //#line 275 . "x10/regionarray/Array.x10"
            ((x10.regionarray.Array<x10.regionarray.Array<x10.regionarray.PolyRow>>)n2).raw = ((x10.core.Rail)(t$156633));
            
            //#line 104 "x10/regionarray/PolyScanner.x10"
            this.min2 = ((x10.regionarray.Array)(n2));
            
            //#line 105 "x10/regionarray/PolyScanner.x10"
            final x10.regionarray.Array x2 = ((x10.regionarray.Array)(new x10.regionarray.Array<x10.regionarray.Array<x10.regionarray.PolyRow>>((java.lang.System[]) null, x10.rtt.ParameterizedType.make(x10.regionarray.Array.$RTT, x10.regionarray.PolyRow.$RTT))));
            
            //#line 270 . "x10/regionarray/Array.x10"
            final x10.regionarray.RectRegion1D myReg$156634 = ((x10.regionarray.RectRegion1D)(new x10.regionarray.RectRegion1D((java.lang.System[]) null)));
            
            //#line 270 . "x10/regionarray/Array.x10"
            final long t$156609 = ((r) - (((long)(1L))));
            
            //#line 270 . "x10/regionarray/Array.x10"
            myReg$156634.x10$regionarray$RectRegion1D$$init$S(t$156609);
            
            //#line 271 . "x10/regionarray/Array.x10"
            final x10.regionarray.Region t$156610 = ((x10.regionarray.Region)
                                                      myReg$156634);
            
            //#line 271 . "x10/regionarray/Array.x10"
            ((x10.regionarray.Array<x10.regionarray.Array<x10.regionarray.PolyRow>>)x2).region = ((x10.regionarray.Region)(t$156610));
            
            //#line 271 . "x10/regionarray/Array.x10"
            ((x10.regionarray.Array<x10.regionarray.Array<x10.regionarray.PolyRow>>)x2).rank = 1L;
            
            //#line 271 . "x10/regionarray/Array.x10"
            ((x10.regionarray.Array<x10.regionarray.Array<x10.regionarray.PolyRow>>)x2).rect = true;
            
            //#line 271 . "x10/regionarray/Array.x10"
            ((x10.regionarray.Array<x10.regionarray.Array<x10.regionarray.PolyRow>>)x2).zeroBased = true;
            
            //#line 271 . "x10/regionarray/Array.x10"
            ((x10.regionarray.Array<x10.regionarray.Array<x10.regionarray.PolyRow>>)x2).rail = true;
            
            //#line 271 . "x10/regionarray/Array.x10"
            ((x10.regionarray.Array<x10.regionarray.Array<x10.regionarray.PolyRow>>)x2).size = r;
            
            //#line 273 . "x10/regionarray/Array.x10"
            final long t$156635 = ((x10.regionarray.Array<x10.regionarray.Array<x10.regionarray.PolyRow>>)x2).layout_min1 = 0L;
            
            //#line 273 . "x10/regionarray/Array.x10"
            final long t$156636 = ((x10.regionarray.Array<x10.regionarray.Array<x10.regionarray.PolyRow>>)x2).layout_stride1 = t$156635;
            
            //#line 273 . "x10/regionarray/Array.x10"
            ((x10.regionarray.Array<x10.regionarray.Array<x10.regionarray.PolyRow>>)x2).layout_min0 = t$156636;
            
            //#line 274 . "x10/regionarray/Array.x10"
            ((x10.regionarray.Array<x10.regionarray.Array<x10.regionarray.PolyRow>>)x2).layout = null;
            
            //#line 275 . "x10/regionarray/Array.x10"
            final x10.core.Rail t$156637 = ((x10.core.Rail)(new x10.core.Rail<x10.regionarray.Array<x10.regionarray.PolyRow>>(x10.rtt.ParameterizedType.make(x10.regionarray.Array.$RTT, x10.regionarray.PolyRow.$RTT), r)));
            
            //#line 275 . "x10/regionarray/Array.x10"
            ((x10.regionarray.Array<x10.regionarray.Array<x10.regionarray.PolyRow>>)x2).raw = ((x10.core.Rail)(t$156637));
            
            //#line 106 "x10/regionarray/PolyScanner.x10"
            this.max2 = ((x10.regionarray.Array)(x2));
            
            //#line 109 "x10/regionarray/PolyScanner.x10"
            final x10.regionarray.Array alloc$155142 = ((x10.regionarray.Array)(new x10.regionarray.Array<x10.core.Boolean>((java.lang.System[]) null, x10.rtt.Types.BOOLEAN)));
            
            //#line 270 . "x10/regionarray/Array.x10"
            final x10.regionarray.RectRegion1D myReg$156638 = ((x10.regionarray.RectRegion1D)(new x10.regionarray.RectRegion1D((java.lang.System[]) null)));
            
            //#line 270 . "x10/regionarray/Array.x10"
            final long t$156611 = ((r) - (((long)(1L))));
            
            //#line 270 . "x10/regionarray/Array.x10"
            myReg$156638.x10$regionarray$RectRegion1D$$init$S(t$156611);
            
            //#line 271 . "x10/regionarray/Array.x10"
            final x10.regionarray.Region t$156612 = ((x10.regionarray.Region)
                                                      myReg$156638);
            
            //#line 271 . "x10/regionarray/Array.x10"
            ((x10.regionarray.Array<x10.core.Boolean>)alloc$155142).region = ((x10.regionarray.Region)(t$156612));
            
            //#line 271 . "x10/regionarray/Array.x10"
            ((x10.regionarray.Array<x10.core.Boolean>)alloc$155142).rank = 1L;
            
            //#line 271 . "x10/regionarray/Array.x10"
            ((x10.regionarray.Array<x10.core.Boolean>)alloc$155142).rect = true;
            
            //#line 271 . "x10/regionarray/Array.x10"
            ((x10.regionarray.Array<x10.core.Boolean>)alloc$155142).zeroBased = true;
            
            //#line 271 . "x10/regionarray/Array.x10"
            ((x10.regionarray.Array<x10.core.Boolean>)alloc$155142).rail = true;
            
            //#line 271 . "x10/regionarray/Array.x10"
            ((x10.regionarray.Array<x10.core.Boolean>)alloc$155142).size = r;
            
            //#line 273 . "x10/regionarray/Array.x10"
            final long t$156639 = ((x10.regionarray.Array<x10.core.Boolean>)alloc$155142).layout_min1 = 0L;
            
            //#line 273 . "x10/regionarray/Array.x10"
            final long t$156640 = ((x10.regionarray.Array<x10.core.Boolean>)alloc$155142).layout_stride1 = t$156639;
            
            //#line 273 . "x10/regionarray/Array.x10"
            ((x10.regionarray.Array<x10.core.Boolean>)alloc$155142).layout_min0 = t$156640;
            
            //#line 274 . "x10/regionarray/Array.x10"
            ((x10.regionarray.Array<x10.core.Boolean>)alloc$155142).layout = null;
            
            //#line 275 . "x10/regionarray/Array.x10"
            final x10.core.Rail t$156641 = ((x10.core.Rail)(new x10.core.Rail<x10.core.Boolean>(x10.rtt.Types.BOOLEAN, r)));
            
            //#line 275 . "x10/regionarray/Array.x10"
            ((x10.regionarray.Array<x10.core.Boolean>)alloc$155142).raw = ((x10.core.Rail)(t$156641));
            
            //#line 109 "x10/regionarray/PolyScanner.x10"
            this.parFlags = ((x10.regionarray.Array)(alloc$155142));
        }
        return this;
    }
    
    
    
    //#line 112 "x10/regionarray/PolyScanner.x10"
    private void init() {
        
        //#line 113 "x10/regionarray/PolyScanner.x10"
        x10.regionarray.PolyMat pm = this.C;
        
        //#line 114 "x10/regionarray/PolyScanner.x10"
        final long t$156099 = this.rank;
        
        //#line 114 "x10/regionarray/PolyScanner.x10"
        final int t$156100 = ((int)(long)(((long)(t$156099))));
        
        //#line 114 "x10/regionarray/PolyScanner.x10"
        final int t$156102 = ((t$156100) - (((int)(1))));
        
        //#line 114 "x10/regionarray/PolyScanner.x10"
        this.init(((x10.regionarray.PolyMat)(pm)), (int)(t$156102));
        
        //#line 115 "x10/regionarray/PolyScanner.x10"
        final long t$156650 = this.rank;
        
        //#line 115 "x10/regionarray/PolyScanner.x10"
        final int t$156651 = ((int)(long)(((long)(t$156650))));
        
        //#line 115 "x10/regionarray/PolyScanner.x10"
        int k$156652 = ((t$156651) - (((int)(2))));
        
        //#line 115 "x10/regionarray/PolyScanner.x10"
        for (;
             true;
             ) {
            
            //#line 115 "x10/regionarray/PolyScanner.x10"
            final boolean t$156654 = ((k$156652) >= (((int)(0))));
            
            //#line 115 "x10/regionarray/PolyScanner.x10"
            if (!(t$156654)) {
                
                //#line 115 "x10/regionarray/PolyScanner.x10"
                break;
            }
            
            //#line 116 "x10/regionarray/PolyScanner.x10"
            final int t$156644 = ((k$156652) + (((int)(1))));
            
            //#line 116 "x10/regionarray/PolyScanner.x10"
            final x10.regionarray.PolyMat t$156645 = ((x10.regionarray.PolyMat)(pm.eliminate((int)(t$156644), (boolean)(true))));
            
            //#line 116 "x10/regionarray/PolyScanner.x10"
            pm = ((x10.regionarray.PolyMat)(t$156645));
            
            //#line 117 "x10/regionarray/PolyScanner.x10"
            this.init(((x10.regionarray.PolyMat)(pm)), (int)(k$156652));
            
            //#line 115 "x10/regionarray/PolyScanner.x10"
            final int t$156649 = ((k$156652) - (((int)(1))));
            
            //#line 115 "x10/regionarray/PolyScanner.x10"
            k$156652 = t$156649;
        }
    }
    
    public static void init$P(final x10.regionarray.PolyScanner PolyScanner) {
        PolyScanner.init();
    }
    
    
    //#line 121 "x10/regionarray/PolyScanner.x10"
    final private void init(final x10.regionarray.PolyMat pm, final int axis) {
        
        //#line 126 "x10/regionarray/PolyScanner.x10"
        int imin = 0;
        
        //#line 127 "x10/regionarray/PolyScanner.x10"
        int imax = 0;
        
        //#line 128 "x10/regionarray/PolyScanner.x10"
        final x10.lang.Iterator r$156751 = ((x10.regionarray.Mat<x10.regionarray.PolyRow>)pm).iterator();
        
        //#line 128 "x10/regionarray/PolyScanner.x10"
        for (;
             true;
             ) {
            
            //#line 128 "x10/regionarray/PolyScanner.x10"
            final boolean t$156752 = ((x10.lang.Iterator<x10.regionarray.PolyRow>)r$156751).hasNext$O();
            
            //#line 128 "x10/regionarray/PolyScanner.x10"
            if (!(t$156752)) {
                
                //#line 128 "x10/regionarray/PolyScanner.x10"
                break;
            }
            
            //#line 128 "x10/regionarray/PolyScanner.x10"
            final x10.regionarray.PolyRow r$156655 = ((x10.lang.Iterator<x10.regionarray.PolyRow>)r$156751).next$G();
            
            //#line 129 "x10/regionarray/PolyScanner.x10"
            final int t$156656 = r$156655.$apply$O((int)(axis));
            
            //#line 129 "x10/regionarray/PolyScanner.x10"
            final boolean t$156657 = ((t$156656) < (((int)(0))));
            
            //#line 129 "x10/regionarray/PolyScanner.x10"
            if (t$156657) {
                
                //#line 129 "x10/regionarray/PolyScanner.x10"
                final int t$156659 = ((imin) + (((int)(1))));
                
                //#line 129 "x10/regionarray/PolyScanner.x10"
                imin = t$156659;
            }
            
            //#line 130 "x10/regionarray/PolyScanner.x10"
            final int t$156660 = r$156655.$apply$O((int)(axis));
            
            //#line 130 "x10/regionarray/PolyScanner.x10"
            final boolean t$156661 = ((t$156660) > (((int)(0))));
            
            //#line 130 "x10/regionarray/PolyScanner.x10"
            if (t$156661) {
                
                //#line 130 "x10/regionarray/PolyScanner.x10"
                final int t$156663 = ((imax) + (((int)(1))));
                
                //#line 130 "x10/regionarray/PolyScanner.x10"
                imax = t$156663;
            }
        }
        
        //#line 134 "x10/regionarray/PolyScanner.x10"
        boolean t$156128 = ((int) imin) == ((int) 0);
        
        //#line 134 "x10/regionarray/PolyScanner.x10"
        if (!(t$156128)) {
            
            //#line 134 "x10/regionarray/PolyScanner.x10"
            t$156128 = ((int) imax) == ((int) 0);
        }
        
        //#line 134 "x10/regionarray/PolyScanner.x10"
        if (t$156128) {
            
            //#line 135 "x10/regionarray/PolyScanner.x10"
            final boolean t$156130 = ((int) imin) == ((int) 0);
            
            //#line 135 "x10/regionarray/PolyScanner.x10"
            java.lang.String t$156131 =  null;
            
            //#line 135 "x10/regionarray/PolyScanner.x10"
            if (t$156130) {
                
                //#line 135 "x10/regionarray/PolyScanner.x10"
                t$156131 = "minimum";
            } else {
                
                //#line 135 "x10/regionarray/PolyScanner.x10"
                t$156131 = "maximum";
            }
            
            //#line 136 "x10/regionarray/PolyScanner.x10"
            final java.lang.String t$156132 = (("axis ") + ((x10.core.Int.$box(axis))));
            
            //#line 136 "x10/regionarray/PolyScanner.x10"
            final java.lang.String t$156133 = ((t$156132) + (" has no "));
            
            //#line 136 "x10/regionarray/PolyScanner.x10"
            final java.lang.String msg = ((t$156133) + (t$156131));
            
            //#line 137 "x10/regionarray/PolyScanner.x10"
            final x10.regionarray.UnboundedRegionException t$156134 = ((x10.regionarray.UnboundedRegionException)(new x10.regionarray.UnboundedRegionException(((java.lang.String)(msg)))));
            
            //#line 137 "x10/regionarray/PolyScanner.x10"
            throw t$156134;
        }
        
        //#line 141 "x10/regionarray/PolyScanner.x10"
        final x10.regionarray.Array this$155902 = ((x10.regionarray.Array)(this.myMin));
        
        //#line 141 "x10/regionarray/PolyScanner.x10"
        final long i$155900 = ((long)(((int)(axis))));
        
        //#line 141 "x10/regionarray/PolyScanner.x10"
        final x10.regionarray.VarMat alloc$155143 = ((x10.regionarray.VarMat)(new x10.regionarray.VarMat((java.lang.System[]) null)));
        
        //#line 141 "x10/regionarray/PolyScanner.x10"
        final int t$156754 = ((axis) + (((int)(1))));
        
        //#line 141 "x10/regionarray/PolyScanner.x10"
        alloc$155143.x10$regionarray$VarMat$$init$S(imin, t$156754);
        
        //#line 547 . "x10/regionarray/Array.x10"
        final x10.core.Rail t$156755 = ((x10.core.Rail)(((x10.regionarray.Array<x10.regionarray.VarMat>)this$155902).raw));
        
        //#line 547 . "x10/regionarray/Array.x10"
        ((x10.regionarray.VarMat[])t$156755.value)[(int)i$155900] = alloc$155143;
        
        //#line 142 "x10/regionarray/PolyScanner.x10"
        final x10.regionarray.Array this$155906 = ((x10.regionarray.Array)(this.myMax));
        
        //#line 142 "x10/regionarray/PolyScanner.x10"
        final long i$155904 = ((long)(((int)(axis))));
        
        //#line 142 "x10/regionarray/PolyScanner.x10"
        final x10.regionarray.VarMat alloc$155144 = ((x10.regionarray.VarMat)(new x10.regionarray.VarMat((java.lang.System[]) null)));
        
        //#line 142 "x10/regionarray/PolyScanner.x10"
        final int t$156757 = ((axis) + (((int)(1))));
        
        //#line 142 "x10/regionarray/PolyScanner.x10"
        alloc$155144.x10$regionarray$VarMat$$init$S(imax, t$156757);
        
        //#line 547 . "x10/regionarray/Array.x10"
        final x10.core.Rail t$156758 = ((x10.core.Rail)(((x10.regionarray.Array<x10.regionarray.VarMat>)this$155906).raw));
        
        //#line 547 . "x10/regionarray/Array.x10"
        ((x10.regionarray.VarMat[])t$156758.value)[(int)i$155904] = alloc$155144;
        
        //#line 143 "x10/regionarray/PolyScanner.x10"
        final x10.regionarray.Array this$155910 = ((x10.regionarray.Array)(this.minSum));
        
        //#line 143 "x10/regionarray/PolyScanner.x10"
        final long i$155908 = ((long)(((int)(axis))));
        
        //#line 143 "x10/regionarray/PolyScanner.x10"
        final x10.regionarray.VarMat alloc$155145 = ((x10.regionarray.VarMat)(new x10.regionarray.VarMat((java.lang.System[]) null)));
        
        //#line 143 "x10/regionarray/PolyScanner.x10"
        final int t$156760 = ((axis) + (((int)(1))));
        
        //#line 143 "x10/regionarray/PolyScanner.x10"
        alloc$155145.x10$regionarray$VarMat$$init$S(imin, t$156760);
        
        //#line 547 . "x10/regionarray/Array.x10"
        final x10.core.Rail t$156761 = ((x10.core.Rail)(((x10.regionarray.Array<x10.regionarray.VarMat>)this$155910).raw));
        
        //#line 547 . "x10/regionarray/Array.x10"
        ((x10.regionarray.VarMat[])t$156761.value)[(int)i$155908] = alloc$155145;
        
        //#line 144 "x10/regionarray/PolyScanner.x10"
        final x10.regionarray.Array this$155914 = ((x10.regionarray.Array)(this.maxSum));
        
        //#line 144 "x10/regionarray/PolyScanner.x10"
        final long i$155912 = ((long)(((int)(axis))));
        
        //#line 144 "x10/regionarray/PolyScanner.x10"
        final x10.regionarray.VarMat alloc$155146 = ((x10.regionarray.VarMat)(new x10.regionarray.VarMat((java.lang.System[]) null)));
        
        //#line 144 "x10/regionarray/PolyScanner.x10"
        final int t$156763 = ((axis) + (((int)(1))));
        
        //#line 144 "x10/regionarray/PolyScanner.x10"
        alloc$155146.x10$regionarray$VarMat$$init$S(imax, t$156763);
        
        //#line 547 . "x10/regionarray/Array.x10"
        final x10.core.Rail t$156764 = ((x10.core.Rail)(((x10.regionarray.Array<x10.regionarray.VarMat>)this$155914).raw));
        
        //#line 547 . "x10/regionarray/Array.x10"
        ((x10.regionarray.VarMat[])t$156764.value)[(int)i$155912] = alloc$155146;
        
        //#line 145 "x10/regionarray/PolyScanner.x10"
        final x10.regionarray.Array this$155922 = ((x10.regionarray.Array)(this.min2));
        
        //#line 145 "x10/regionarray/PolyScanner.x10"
        final long i$155920 = ((long)(((int)(axis))));
        
        //#line 145 "x10/regionarray/PolyScanner.x10"
        final x10.regionarray.Array alloc$155147 = ((x10.regionarray.Array)(new x10.regionarray.Array<x10.regionarray.PolyRow>((java.lang.System[]) null, x10.regionarray.PolyRow.$RTT)));
        
        //#line 145 "x10/regionarray/PolyScanner.x10"
        final long size$155916 = ((long)(((int)(imin))));
        
        //#line 270 . "x10/regionarray/Array.x10"
        final x10.regionarray.RectRegion1D myReg$156765 = ((x10.regionarray.RectRegion1D)(new x10.regionarray.RectRegion1D((java.lang.System[]) null)));
        
        //#line 270 . "x10/regionarray/Array.x10"
        final long t$156664 = ((size$155916) - (((long)(1L))));
        
        //#line 270 . "x10/regionarray/Array.x10"
        myReg$156765.x10$regionarray$RectRegion1D$$init$S(t$156664);
        
        //#line 271 . "x10/regionarray/Array.x10"
        final x10.regionarray.Region t$156665 = ((x10.regionarray.Region)
                                                  myReg$156765);
        
        //#line 271 . "x10/regionarray/Array.x10"
        ((x10.regionarray.Array<x10.regionarray.PolyRow>)alloc$155147).region = ((x10.regionarray.Region)(t$156665));
        
        //#line 271 . "x10/regionarray/Array.x10"
        ((x10.regionarray.Array<x10.regionarray.PolyRow>)alloc$155147).rank = 1L;
        
        //#line 271 . "x10/regionarray/Array.x10"
        ((x10.regionarray.Array<x10.regionarray.PolyRow>)alloc$155147).rect = true;
        
        //#line 271 . "x10/regionarray/Array.x10"
        ((x10.regionarray.Array<x10.regionarray.PolyRow>)alloc$155147).zeroBased = true;
        
        //#line 271 . "x10/regionarray/Array.x10"
        ((x10.regionarray.Array<x10.regionarray.PolyRow>)alloc$155147).rail = true;
        
        //#line 271 . "x10/regionarray/Array.x10"
        ((x10.regionarray.Array<x10.regionarray.PolyRow>)alloc$155147).size = size$155916;
        
        //#line 273 . "x10/regionarray/Array.x10"
        final long t$156766 = ((x10.regionarray.Array<x10.regionarray.PolyRow>)alloc$155147).layout_min1 = 0L;
        
        //#line 273 . "x10/regionarray/Array.x10"
        final long t$156767 = ((x10.regionarray.Array<x10.regionarray.PolyRow>)alloc$155147).layout_stride1 = t$156766;
        
        //#line 273 . "x10/regionarray/Array.x10"
        ((x10.regionarray.Array<x10.regionarray.PolyRow>)alloc$155147).layout_min0 = t$156767;
        
        //#line 274 . "x10/regionarray/Array.x10"
        ((x10.regionarray.Array<x10.regionarray.PolyRow>)alloc$155147).layout = null;
        
        //#line 275 . "x10/regionarray/Array.x10"
        final x10.core.Rail t$156768 = ((x10.core.Rail)(new x10.core.Rail<x10.regionarray.PolyRow>(x10.regionarray.PolyRow.$RTT, ((long)(size$155916)))));
        
        //#line 275 . "x10/regionarray/Array.x10"
        ((x10.regionarray.Array<x10.regionarray.PolyRow>)alloc$155147).raw = ((x10.core.Rail)(t$156768));
        
        //#line 547 . "x10/regionarray/Array.x10"
        final x10.core.Rail t$156769 = ((x10.core.Rail)(((x10.regionarray.Array<x10.regionarray.Array<x10.regionarray.PolyRow>>)this$155922).raw));
        
        //#line 547 . "x10/regionarray/Array.x10"
        ((x10.regionarray.Array[])t$156769.value)[(int)i$155920] = alloc$155147;
        
        //#line 146 "x10/regionarray/PolyScanner.x10"
        final x10.regionarray.Array this$155930 = ((x10.regionarray.Array)(this.max2));
        
        //#line 146 "x10/regionarray/PolyScanner.x10"
        final long i$155928 = ((long)(((int)(axis))));
        
        //#line 146 "x10/regionarray/PolyScanner.x10"
        final x10.regionarray.Array alloc$155148 = ((x10.regionarray.Array)(new x10.regionarray.Array<x10.regionarray.PolyRow>((java.lang.System[]) null, x10.regionarray.PolyRow.$RTT)));
        
        //#line 146 "x10/regionarray/PolyScanner.x10"
        final long size$155924 = ((long)(((int)(imax))));
        
        //#line 270 . "x10/regionarray/Array.x10"
        final x10.regionarray.RectRegion1D myReg$156770 = ((x10.regionarray.RectRegion1D)(new x10.regionarray.RectRegion1D((java.lang.System[]) null)));
        
        //#line 270 . "x10/regionarray/Array.x10"
        final long t$156666 = ((size$155924) - (((long)(1L))));
        
        //#line 270 . "x10/regionarray/Array.x10"
        myReg$156770.x10$regionarray$RectRegion1D$$init$S(t$156666);
        
        //#line 271 . "x10/regionarray/Array.x10"
        final x10.regionarray.Region t$156667 = ((x10.regionarray.Region)
                                                  myReg$156770);
        
        //#line 271 . "x10/regionarray/Array.x10"
        ((x10.regionarray.Array<x10.regionarray.PolyRow>)alloc$155148).region = ((x10.regionarray.Region)(t$156667));
        
        //#line 271 . "x10/regionarray/Array.x10"
        ((x10.regionarray.Array<x10.regionarray.PolyRow>)alloc$155148).rank = 1L;
        
        //#line 271 . "x10/regionarray/Array.x10"
        ((x10.regionarray.Array<x10.regionarray.PolyRow>)alloc$155148).rect = true;
        
        //#line 271 . "x10/regionarray/Array.x10"
        ((x10.regionarray.Array<x10.regionarray.PolyRow>)alloc$155148).zeroBased = true;
        
        //#line 271 . "x10/regionarray/Array.x10"
        ((x10.regionarray.Array<x10.regionarray.PolyRow>)alloc$155148).rail = true;
        
        //#line 271 . "x10/regionarray/Array.x10"
        ((x10.regionarray.Array<x10.regionarray.PolyRow>)alloc$155148).size = size$155924;
        
        //#line 273 . "x10/regionarray/Array.x10"
        final long t$156771 = ((x10.regionarray.Array<x10.regionarray.PolyRow>)alloc$155148).layout_min1 = 0L;
        
        //#line 273 . "x10/regionarray/Array.x10"
        final long t$156772 = ((x10.regionarray.Array<x10.regionarray.PolyRow>)alloc$155148).layout_stride1 = t$156771;
        
        //#line 273 . "x10/regionarray/Array.x10"
        ((x10.regionarray.Array<x10.regionarray.PolyRow>)alloc$155148).layout_min0 = t$156772;
        
        //#line 274 . "x10/regionarray/Array.x10"
        ((x10.regionarray.Array<x10.regionarray.PolyRow>)alloc$155148).layout = null;
        
        //#line 275 . "x10/regionarray/Array.x10"
        final x10.core.Rail t$156773 = ((x10.core.Rail)(new x10.core.Rail<x10.regionarray.PolyRow>(x10.regionarray.PolyRow.$RTT, ((long)(size$155924)))));
        
        //#line 275 . "x10/regionarray/Array.x10"
        ((x10.regionarray.Array<x10.regionarray.PolyRow>)alloc$155148).raw = ((x10.core.Rail)(t$156773));
        
        //#line 547 . "x10/regionarray/Array.x10"
        final x10.core.Rail t$156774 = ((x10.core.Rail)(((x10.regionarray.Array<x10.regionarray.Array<x10.regionarray.PolyRow>>)this$155930).raw));
        
        //#line 547 . "x10/regionarray/Array.x10"
        ((x10.regionarray.Array[])t$156774.value)[(int)i$155928] = alloc$155148;
        
        //#line 149 "x10/regionarray/PolyScanner.x10"
        imin = 0;
        
        //#line 149 "x10/regionarray/PolyScanner.x10"
        imax = 0;
        
        //#line 150 "x10/regionarray/PolyScanner.x10"
        final x10.lang.Iterator r$156775 = ((x10.regionarray.Mat<x10.regionarray.PolyRow>)pm).iterator();
        
        //#line 150 "x10/regionarray/PolyScanner.x10"
        for (;
             true;
             ) {
            
            //#line 150 "x10/regionarray/PolyScanner.x10"
            final boolean t$156776 = ((x10.lang.Iterator<x10.regionarray.PolyRow>)r$156775).hasNext$O();
            
            //#line 150 "x10/regionarray/PolyScanner.x10"
            if (!(t$156776)) {
                
                //#line 150 "x10/regionarray/PolyScanner.x10"
                break;
            }
            
            //#line 150 "x10/regionarray/PolyScanner.x10"
            final x10.regionarray.PolyRow r$156710 = ((x10.lang.Iterator<x10.regionarray.PolyRow>)r$156775).next$G();
            
            //#line 151 "x10/regionarray/PolyScanner.x10"
            final int t$156711 = r$156710.$apply$O((int)(axis));
            
            //#line 151 "x10/regionarray/PolyScanner.x10"
            final boolean t$156712 = ((t$156711) < (((int)(0))));
            
            //#line 151 "x10/regionarray/PolyScanner.x10"
            if (t$156712) {
                
                //#line 152 "x10/regionarray/PolyScanner.x10"
                int i$156681 = 0;
                
                //#line 152 "x10/regionarray/PolyScanner.x10"
                for (;
                     true;
                     ) {
                    
                    //#line 152 "x10/regionarray/PolyScanner.x10"
                    final boolean t$156683 = ((i$156681) <= (((int)(axis))));
                    
                    //#line 152 "x10/regionarray/PolyScanner.x10"
                    if (!(t$156683)) {
                        
                        //#line 152 "x10/regionarray/PolyScanner.x10"
                        break;
                    }
                    
                    //#line 153 "x10/regionarray/PolyScanner.x10"
                    final x10.regionarray.Array this$156670 = ((x10.regionarray.Array)(this.myMin));
                    
                    //#line 153 "x10/regionarray/PolyScanner.x10"
                    final long i$156671 = ((long)(((int)(axis))));
                    
                    //#line 442 . "x10/regionarray/Array.x10"
                    x10.regionarray.VarMat ret$156672 =  null;
                    
                    //#line 446 . "x10/regionarray/Array.x10"
                    final x10.core.Rail t$156668 = ((x10.core.Rail)(((x10.regionarray.Array<x10.regionarray.VarMat>)this$156670).raw));
                    
                    //#line 446 . "x10/regionarray/Array.x10"
                    final x10.regionarray.VarMat t$156669 = ((x10.regionarray.VarMat[])t$156668.value)[(int)i$156671];
                    
                    //#line 446 . "x10/regionarray/Array.x10"
                    ret$156672 = t$156669;
                    
                    //#line 153 "x10/regionarray/PolyScanner.x10"
                    final x10.regionarray.VarRow t$156675 = ((x10.regionarray.Mat<x10.regionarray.VarRow>)ret$156672).$apply$G((int)(imin));
                    
                    //#line 153 "x10/regionarray/PolyScanner.x10"
                    final int t$156678 = r$156710.$apply$O((int)(i$156681));
                    
                    //#line 153 "x10/regionarray/PolyScanner.x10"
                    t$156675.$set$O((int)(i$156681), (int)(t$156678));
                    
                    //#line 152 "x10/regionarray/PolyScanner.x10"
                    final int t$156680 = ((i$156681) + (((int)(1))));
                    
                    //#line 152 "x10/regionarray/PolyScanner.x10"
                    i$156681 = t$156680;
                }
                
                //#line 154 "x10/regionarray/PolyScanner.x10"
                final x10.regionarray.Array this$156713 = ((x10.regionarray.Array)(this.minSum));
                
                //#line 154 "x10/regionarray/PolyScanner.x10"
                final long i$156714 = ((long)(((int)(axis))));
                
                //#line 442 . "x10/regionarray/Array.x10"
                x10.regionarray.VarMat ret$156715 =  null;
                
                //#line 446 . "x10/regionarray/Array.x10"
                final x10.core.Rail t$156684 = ((x10.core.Rail)(((x10.regionarray.Array<x10.regionarray.VarMat>)this$156713).raw));
                
                //#line 446 . "x10/regionarray/Array.x10"
                final x10.regionarray.VarMat t$156685 = ((x10.regionarray.VarMat[])t$156684.value)[(int)i$156714];
                
                //#line 446 . "x10/regionarray/Array.x10"
                ret$156715 = t$156685;
                
                //#line 154 "x10/regionarray/PolyScanner.x10"
                final x10.regionarray.VarRow t$156718 = ((x10.regionarray.Mat<x10.regionarray.VarRow>)ret$156715).$apply$G((int)(imin));
                
                //#line 154 "x10/regionarray/PolyScanner.x10"
                final long t$156719 = this.rank;
                
                //#line 154 "x10/regionarray/PolyScanner.x10"
                final int t$156720 = ((int)(long)(((long)(t$156719))));
                
                //#line 154 "x10/regionarray/PolyScanner.x10"
                final int t$156721 = r$156710.$apply$O((int)(t$156720));
                
                //#line 154 "x10/regionarray/PolyScanner.x10"
                t$156718.$set$O((int)(0), (int)(t$156721));
                
                //#line 155 "x10/regionarray/PolyScanner.x10"
                final x10.regionarray.Array this$156722 = ((x10.regionarray.Array)(this.min2));
                
                //#line 155 "x10/regionarray/PolyScanner.x10"
                final long i$156723 = ((long)(((int)(axis))));
                
                //#line 442 . "x10/regionarray/Array.x10"
                x10.regionarray.Array ret$156724 =  null;
                
                //#line 446 . "x10/regionarray/Array.x10"
                final x10.core.Rail t$156686 = ((x10.core.Rail)(((x10.regionarray.Array<x10.regionarray.Array<x10.regionarray.PolyRow>>)this$156722).raw));
                
                //#line 446 . "x10/regionarray/Array.x10"
                final x10.regionarray.Array t$156687 = ((x10.regionarray.Array)(((x10.regionarray.Array[])t$156686.value)[(int)i$156723]));
                
                //#line 446 . "x10/regionarray/Array.x10"
                ret$156724 = ((x10.regionarray.Array)(t$156687));
                
                //#line 155 "x10/regionarray/PolyScanner.x10"
                final long i$156727 = ((long)(((int)(imin))));
                
                //#line 547 . "x10/regionarray/Array.x10"
                final x10.core.Rail t$156688 = ((x10.core.Rail)(((x10.regionarray.Array<x10.regionarray.PolyRow>)ret$156724).raw));
                
                //#line 547 . "x10/regionarray/Array.x10"
                ((x10.regionarray.PolyRow[])t$156688.value)[(int)i$156727] = r$156710;
                
                //#line 156 "x10/regionarray/PolyScanner.x10"
                final int t$156730 = ((imin) + (((int)(1))));
                
                //#line 156 "x10/regionarray/PolyScanner.x10"
                imin = t$156730;
            }
            
            //#line 158 "x10/regionarray/PolyScanner.x10"
            final int t$156731 = r$156710.$apply$O((int)(axis));
            
            //#line 158 "x10/regionarray/PolyScanner.x10"
            final boolean t$156732 = ((t$156731) > (((int)(0))));
            
            //#line 158 "x10/regionarray/PolyScanner.x10"
            if (t$156732) {
                
                //#line 159 "x10/regionarray/PolyScanner.x10"
                int i$156702 = 0;
                
                //#line 159 "x10/regionarray/PolyScanner.x10"
                for (;
                     true;
                     ) {
                    
                    //#line 159 "x10/regionarray/PolyScanner.x10"
                    final boolean t$156704 = ((i$156702) <= (((int)(axis))));
                    
                    //#line 159 "x10/regionarray/PolyScanner.x10"
                    if (!(t$156704)) {
                        
                        //#line 159 "x10/regionarray/PolyScanner.x10"
                        break;
                    }
                    
                    //#line 160 "x10/regionarray/PolyScanner.x10"
                    final x10.regionarray.Array this$156691 = ((x10.regionarray.Array)(this.myMax));
                    
                    //#line 160 "x10/regionarray/PolyScanner.x10"
                    final long i$156692 = ((long)(((int)(axis))));
                    
                    //#line 442 . "x10/regionarray/Array.x10"
                    x10.regionarray.VarMat ret$156693 =  null;
                    
                    //#line 446 . "x10/regionarray/Array.x10"
                    final x10.core.Rail t$156689 = ((x10.core.Rail)(((x10.regionarray.Array<x10.regionarray.VarMat>)this$156691).raw));
                    
                    //#line 446 . "x10/regionarray/Array.x10"
                    final x10.regionarray.VarMat t$156690 = ((x10.regionarray.VarMat[])t$156689.value)[(int)i$156692];
                    
                    //#line 446 . "x10/regionarray/Array.x10"
                    ret$156693 = t$156690;
                    
                    //#line 160 "x10/regionarray/PolyScanner.x10"
                    final x10.regionarray.VarRow t$156696 = ((x10.regionarray.Mat<x10.regionarray.VarRow>)ret$156693).$apply$G((int)(imax));
                    
                    //#line 160 "x10/regionarray/PolyScanner.x10"
                    final int t$156699 = r$156710.$apply$O((int)(i$156702));
                    
                    //#line 160 "x10/regionarray/PolyScanner.x10"
                    t$156696.$set$O((int)(i$156702), (int)(t$156699));
                    
                    //#line 159 "x10/regionarray/PolyScanner.x10"
                    final int t$156701 = ((i$156702) + (((int)(1))));
                    
                    //#line 159 "x10/regionarray/PolyScanner.x10"
                    i$156702 = t$156701;
                }
                
                //#line 161 "x10/regionarray/PolyScanner.x10"
                final x10.regionarray.Array this$156733 = ((x10.regionarray.Array)(this.maxSum));
                
                //#line 161 "x10/regionarray/PolyScanner.x10"
                final long i$156734 = ((long)(((int)(axis))));
                
                //#line 442 . "x10/regionarray/Array.x10"
                x10.regionarray.VarMat ret$156735 =  null;
                
                //#line 446 . "x10/regionarray/Array.x10"
                final x10.core.Rail t$156705 = ((x10.core.Rail)(((x10.regionarray.Array<x10.regionarray.VarMat>)this$156733).raw));
                
                //#line 446 . "x10/regionarray/Array.x10"
                final x10.regionarray.VarMat t$156706 = ((x10.regionarray.VarMat[])t$156705.value)[(int)i$156734];
                
                //#line 446 . "x10/regionarray/Array.x10"
                ret$156735 = t$156706;
                
                //#line 161 "x10/regionarray/PolyScanner.x10"
                final x10.regionarray.VarRow t$156738 = ((x10.regionarray.Mat<x10.regionarray.VarRow>)ret$156735).$apply$G((int)(imax));
                
                //#line 161 "x10/regionarray/PolyScanner.x10"
                final long t$156739 = this.rank;
                
                //#line 161 "x10/regionarray/PolyScanner.x10"
                final int t$156740 = ((int)(long)(((long)(t$156739))));
                
                //#line 161 "x10/regionarray/PolyScanner.x10"
                final int t$156741 = r$156710.$apply$O((int)(t$156740));
                
                //#line 161 "x10/regionarray/PolyScanner.x10"
                t$156738.$set$O((int)(0), (int)(t$156741));
                
                //#line 162 "x10/regionarray/PolyScanner.x10"
                final x10.regionarray.Array this$156742 = ((x10.regionarray.Array)(this.max2));
                
                //#line 162 "x10/regionarray/PolyScanner.x10"
                final long i$156743 = ((long)(((int)(axis))));
                
                //#line 442 . "x10/regionarray/Array.x10"
                x10.regionarray.Array ret$156744 =  null;
                
                //#line 446 . "x10/regionarray/Array.x10"
                final x10.core.Rail t$156707 = ((x10.core.Rail)(((x10.regionarray.Array<x10.regionarray.Array<x10.regionarray.PolyRow>>)this$156742).raw));
                
                //#line 446 . "x10/regionarray/Array.x10"
                final x10.regionarray.Array t$156708 = ((x10.regionarray.Array)(((x10.regionarray.Array[])t$156707.value)[(int)i$156743]));
                
                //#line 446 . "x10/regionarray/Array.x10"
                ret$156744 = ((x10.regionarray.Array)(t$156708));
                
                //#line 162 "x10/regionarray/PolyScanner.x10"
                final long i$156747 = ((long)(((int)(imax))));
                
                //#line 547 . "x10/regionarray/Array.x10"
                final x10.core.Rail t$156709 = ((x10.core.Rail)(((x10.regionarray.Array<x10.regionarray.PolyRow>)ret$156744).raw));
                
                //#line 547 . "x10/regionarray/Array.x10"
                ((x10.regionarray.PolyRow[])t$156709.value)[(int)i$156747] = r$156710;
                
                //#line 163 "x10/regionarray/PolyScanner.x10"
                final int t$156750 = ((imax) + (((int)(1))));
                
                //#line 163 "x10/regionarray/PolyScanner.x10"
                imax = t$156750;
            }
        }
    }
    
    final public static void init$P(final x10.regionarray.PolyMat pm, final int axis, final x10.regionarray.PolyScanner PolyScanner) {
        PolyScanner.init(((x10.regionarray.PolyMat)(pm)), (int)(axis));
    }
    
    
    //#line 177 "x10/regionarray/PolyScanner.x10"
    final public void $set(final int v, final int axis) {
        
        //#line 177 "x10/regionarray/PolyScanner.x10"
        this.set((int)(axis), (int)(v));
    }
    
    
    //#line 179 "x10/regionarray/PolyScanner.x10"
    final public void set(final int axis, final int v) {
        
        //#line 180 "x10/regionarray/PolyScanner.x10"
        int k$156871 = ((axis) + (((int)(1))));
        
        //#line 180 "x10/regionarray/PolyScanner.x10"
        for (;
             true;
             ) {
            
            //#line 180 "x10/regionarray/PolyScanner.x10"
            final long t$156873 = ((long)(((int)(k$156871))));
            
            //#line 180 "x10/regionarray/PolyScanner.x10"
            final long t$156874 = this.rank;
            
            //#line 180 "x10/regionarray/PolyScanner.x10"
            final boolean t$156875 = ((t$156873) < (((long)(t$156874))));
            
            //#line 180 "x10/regionarray/PolyScanner.x10"
            if (!(t$156875)) {
                
                //#line 180 "x10/regionarray/PolyScanner.x10"
                break;
            }
            
            //#line 181 "x10/regionarray/PolyScanner.x10"
            int l$156813 = 0;
            
            //#line 181 "x10/regionarray/PolyScanner.x10"
            for (;
                 true;
                 ) {
                
                //#line 181 "x10/regionarray/PolyScanner.x10"
                final x10.regionarray.Array this$156815 = ((x10.regionarray.Array)(this.minSum));
                
                //#line 181 "x10/regionarray/PolyScanner.x10"
                final long i$156817 = ((long)(((int)(k$156871))));
                
                //#line 442 . "x10/regionarray/Array.x10"
                x10.regionarray.VarMat ret$156818 =  null;
                
                //#line 446 . "x10/regionarray/Array.x10"
                final x10.core.Rail t$156783 = ((x10.core.Rail)(((x10.regionarray.Array<x10.regionarray.VarMat>)this$156815).raw));
                
                //#line 446 . "x10/regionarray/Array.x10"
                final x10.regionarray.VarMat t$156784 = ((x10.regionarray.VarMat[])t$156783.value)[(int)i$156817];
                
                //#line 446 . "x10/regionarray/Array.x10"
                ret$156818 = t$156784;
                
                //#line 181 "x10/regionarray/PolyScanner.x10"
                final int t$156820 = ((x10.regionarray.Mat<x10.regionarray.VarRow>)ret$156818).rows;
                
                //#line 181 "x10/regionarray/PolyScanner.x10"
                final boolean t$156821 = ((l$156813) < (((int)(t$156820))));
                
                //#line 181 "x10/regionarray/PolyScanner.x10"
                if (!(t$156821)) {
                    
                    //#line 181 "x10/regionarray/PolyScanner.x10"
                    break;
                }
                
                //#line 182 "x10/regionarray/PolyScanner.x10"
                final x10.regionarray.Array this$156785 = ((x10.regionarray.Array)(this.minSum));
                
                //#line 182 "x10/regionarray/PolyScanner.x10"
                final long i$156787 = ((long)(((int)(k$156871))));
                
                //#line 442 . "x10/regionarray/Array.x10"
                x10.regionarray.VarMat ret$156788 =  null;
                
                //#line 446 . "x10/regionarray/Array.x10"
                final x10.core.Rail t$156777 = ((x10.core.Rail)(((x10.regionarray.Array<x10.regionarray.VarMat>)this$156785).raw));
                
                //#line 446 . "x10/regionarray/Array.x10"
                final x10.regionarray.VarMat t$156778 = ((x10.regionarray.VarMat[])t$156777.value)[(int)i$156787];
                
                //#line 446 . "x10/regionarray/Array.x10"
                ret$156788 = t$156778;
                
                //#line 182 "x10/regionarray/PolyScanner.x10"
                final x10.regionarray.VarRow t$156791 = ((x10.regionarray.Mat<x10.regionarray.VarRow>)ret$156788).$apply$G((int)(l$156813));
                
                //#line 182 "x10/regionarray/PolyScanner.x10"
                final int t$156792 = ((axis) + (((int)(1))));
                
                //#line 182 "x10/regionarray/PolyScanner.x10"
                final x10.regionarray.Array this$156793 = ((x10.regionarray.Array)(this.myMin));
                
                //#line 182 "x10/regionarray/PolyScanner.x10"
                final long i$156795 = ((long)(((int)(k$156871))));
                
                //#line 442 . "x10/regionarray/Array.x10"
                x10.regionarray.VarMat ret$156796 =  null;
                
                //#line 446 . "x10/regionarray/Array.x10"
                final x10.core.Rail t$156779 = ((x10.core.Rail)(((x10.regionarray.Array<x10.regionarray.VarMat>)this$156793).raw));
                
                //#line 446 . "x10/regionarray/Array.x10"
                final x10.regionarray.VarMat t$156780 = ((x10.regionarray.VarMat[])t$156779.value)[(int)i$156795];
                
                //#line 446 . "x10/regionarray/Array.x10"
                ret$156796 = t$156780;
                
                //#line 182 "x10/regionarray/PolyScanner.x10"
                final x10.regionarray.VarRow t$156799 = ((x10.regionarray.Mat<x10.regionarray.VarRow>)ret$156796).$apply$G((int)(l$156813));
                
                //#line 182 "x10/regionarray/PolyScanner.x10"
                final int t$156800 = t$156799.$apply$O((int)(axis));
                
                //#line 182 "x10/regionarray/PolyScanner.x10"
                final int t$156801 = ((t$156800) * (((int)(v))));
                
                //#line 182 "x10/regionarray/PolyScanner.x10"
                final x10.regionarray.Array this$156802 = ((x10.regionarray.Array)(this.minSum));
                
                //#line 182 "x10/regionarray/PolyScanner.x10"
                final long i$156804 = ((long)(((int)(k$156871))));
                
                //#line 442 . "x10/regionarray/Array.x10"
                x10.regionarray.VarMat ret$156805 =  null;
                
                //#line 446 . "x10/regionarray/Array.x10"
                final x10.core.Rail t$156781 = ((x10.core.Rail)(((x10.regionarray.Array<x10.regionarray.VarMat>)this$156802).raw));
                
                //#line 446 . "x10/regionarray/Array.x10"
                final x10.regionarray.VarMat t$156782 = ((x10.regionarray.VarMat[])t$156781.value)[(int)i$156804];
                
                //#line 446 . "x10/regionarray/Array.x10"
                ret$156805 = t$156782;
                
                //#line 182 "x10/regionarray/PolyScanner.x10"
                final x10.regionarray.VarRow t$156808 = ((x10.regionarray.Mat<x10.regionarray.VarRow>)ret$156805).$apply$G((int)(l$156813));
                
                //#line 182 "x10/regionarray/PolyScanner.x10"
                final int t$156809 = t$156808.$apply$O((int)(axis));
                
                //#line 182 "x10/regionarray/PolyScanner.x10"
                final int t$156810 = ((t$156801) + (((int)(t$156809))));
                
                //#line 182 "x10/regionarray/PolyScanner.x10"
                t$156791.$set$O((int)(t$156792), (int)(t$156810));
                
                //#line 181 "x10/regionarray/PolyScanner.x10"
                final int t$156812 = ((l$156813) + (((int)(1))));
                
                //#line 181 "x10/regionarray/PolyScanner.x10"
                l$156813 = t$156812;
            }
            
            //#line 180 "x10/regionarray/PolyScanner.x10"
            final int t$156823 = ((k$156871) + (((int)(1))));
            
            //#line 180 "x10/regionarray/PolyScanner.x10"
            k$156871 = t$156823;
        }
        
        //#line 183 "x10/regionarray/PolyScanner.x10"
        int k$156876 = ((axis) + (((int)(1))));
        
        //#line 183 "x10/regionarray/PolyScanner.x10"
        for (;
             true;
             ) {
            
            //#line 183 "x10/regionarray/PolyScanner.x10"
            final long t$156878 = ((long)(((int)(k$156876))));
            
            //#line 183 "x10/regionarray/PolyScanner.x10"
            final long t$156879 = this.rank;
            
            //#line 183 "x10/regionarray/PolyScanner.x10"
            final boolean t$156880 = ((t$156878) < (((long)(t$156879))));
            
            //#line 183 "x10/regionarray/PolyScanner.x10"
            if (!(t$156880)) {
                
                //#line 183 "x10/regionarray/PolyScanner.x10"
                break;
            }
            
            //#line 184 "x10/regionarray/PolyScanner.x10"
            int l$156860 = 0;
            
            //#line 184 "x10/regionarray/PolyScanner.x10"
            for (;
                 true;
                 ) {
                
                //#line 184 "x10/regionarray/PolyScanner.x10"
                final x10.regionarray.Array this$156862 = ((x10.regionarray.Array)(this.maxSum));
                
                //#line 184 "x10/regionarray/PolyScanner.x10"
                final long i$156864 = ((long)(((int)(k$156876))));
                
                //#line 442 . "x10/regionarray/Array.x10"
                x10.regionarray.VarMat ret$156865 =  null;
                
                //#line 446 . "x10/regionarray/Array.x10"
                final x10.core.Rail t$156830 = ((x10.core.Rail)(((x10.regionarray.Array<x10.regionarray.VarMat>)this$156862).raw));
                
                //#line 446 . "x10/regionarray/Array.x10"
                final x10.regionarray.VarMat t$156831 = ((x10.regionarray.VarMat[])t$156830.value)[(int)i$156864];
                
                //#line 446 . "x10/regionarray/Array.x10"
                ret$156865 = t$156831;
                
                //#line 184 "x10/regionarray/PolyScanner.x10"
                final int t$156867 = ((x10.regionarray.Mat<x10.regionarray.VarRow>)ret$156865).rows;
                
                //#line 184 "x10/regionarray/PolyScanner.x10"
                final boolean t$156868 = ((l$156860) < (((int)(t$156867))));
                
                //#line 184 "x10/regionarray/PolyScanner.x10"
                if (!(t$156868)) {
                    
                    //#line 184 "x10/regionarray/PolyScanner.x10"
                    break;
                }
                
                //#line 185 "x10/regionarray/PolyScanner.x10"
                final x10.regionarray.Array this$156832 = ((x10.regionarray.Array)(this.maxSum));
                
                //#line 185 "x10/regionarray/PolyScanner.x10"
                final long i$156834 = ((long)(((int)(k$156876))));
                
                //#line 442 . "x10/regionarray/Array.x10"
                x10.regionarray.VarMat ret$156835 =  null;
                
                //#line 446 . "x10/regionarray/Array.x10"
                final x10.core.Rail t$156824 = ((x10.core.Rail)(((x10.regionarray.Array<x10.regionarray.VarMat>)this$156832).raw));
                
                //#line 446 . "x10/regionarray/Array.x10"
                final x10.regionarray.VarMat t$156825 = ((x10.regionarray.VarMat[])t$156824.value)[(int)i$156834];
                
                //#line 446 . "x10/regionarray/Array.x10"
                ret$156835 = t$156825;
                
                //#line 185 "x10/regionarray/PolyScanner.x10"
                final x10.regionarray.VarRow t$156838 = ((x10.regionarray.Mat<x10.regionarray.VarRow>)ret$156835).$apply$G((int)(l$156860));
                
                //#line 185 "x10/regionarray/PolyScanner.x10"
                final int t$156839 = ((axis) + (((int)(1))));
                
                //#line 185 "x10/regionarray/PolyScanner.x10"
                final x10.regionarray.Array this$156840 = ((x10.regionarray.Array)(this.myMax));
                
                //#line 185 "x10/regionarray/PolyScanner.x10"
                final long i$156842 = ((long)(((int)(k$156876))));
                
                //#line 442 . "x10/regionarray/Array.x10"
                x10.regionarray.VarMat ret$156843 =  null;
                
                //#line 446 . "x10/regionarray/Array.x10"
                final x10.core.Rail t$156826 = ((x10.core.Rail)(((x10.regionarray.Array<x10.regionarray.VarMat>)this$156840).raw));
                
                //#line 446 . "x10/regionarray/Array.x10"
                final x10.regionarray.VarMat t$156827 = ((x10.regionarray.VarMat[])t$156826.value)[(int)i$156842];
                
                //#line 446 . "x10/regionarray/Array.x10"
                ret$156843 = t$156827;
                
                //#line 185 "x10/regionarray/PolyScanner.x10"
                final x10.regionarray.VarRow t$156846 = ((x10.regionarray.Mat<x10.regionarray.VarRow>)ret$156843).$apply$G((int)(l$156860));
                
                //#line 185 "x10/regionarray/PolyScanner.x10"
                final int t$156847 = t$156846.$apply$O((int)(axis));
                
                //#line 185 "x10/regionarray/PolyScanner.x10"
                final int t$156848 = ((t$156847) * (((int)(v))));
                
                //#line 185 "x10/regionarray/PolyScanner.x10"
                final x10.regionarray.Array this$156849 = ((x10.regionarray.Array)(this.maxSum));
                
                //#line 185 "x10/regionarray/PolyScanner.x10"
                final long i$156851 = ((long)(((int)(k$156876))));
                
                //#line 442 . "x10/regionarray/Array.x10"
                x10.regionarray.VarMat ret$156852 =  null;
                
                //#line 446 . "x10/regionarray/Array.x10"
                final x10.core.Rail t$156828 = ((x10.core.Rail)(((x10.regionarray.Array<x10.regionarray.VarMat>)this$156849).raw));
                
                //#line 446 . "x10/regionarray/Array.x10"
                final x10.regionarray.VarMat t$156829 = ((x10.regionarray.VarMat[])t$156828.value)[(int)i$156851];
                
                //#line 446 . "x10/regionarray/Array.x10"
                ret$156852 = t$156829;
                
                //#line 185 "x10/regionarray/PolyScanner.x10"
                final x10.regionarray.VarRow t$156855 = ((x10.regionarray.Mat<x10.regionarray.VarRow>)ret$156852).$apply$G((int)(l$156860));
                
                //#line 185 "x10/regionarray/PolyScanner.x10"
                final int t$156856 = t$156855.$apply$O((int)(axis));
                
                //#line 185 "x10/regionarray/PolyScanner.x10"
                final int t$156857 = ((t$156848) + (((int)(t$156856))));
                
                //#line 185 "x10/regionarray/PolyScanner.x10"
                t$156838.$set$O((int)(t$156839), (int)(t$156857));
                
                //#line 184 "x10/regionarray/PolyScanner.x10"
                final int t$156859 = ((l$156860) + (((int)(1))));
                
                //#line 184 "x10/regionarray/PolyScanner.x10"
                l$156860 = t$156859;
            }
            
            //#line 183 "x10/regionarray/PolyScanner.x10"
            final int t$156870 = ((k$156876) + (((int)(1))));
            
            //#line 183 "x10/regionarray/PolyScanner.x10"
            k$156876 = t$156870;
        }
    }
    
    
    //#line 188 "x10/regionarray/PolyScanner.x10"
    final public int min$O(final int axis) {
        
        //#line 189 "x10/regionarray/PolyScanner.x10"
        int result = java.lang.Integer.MIN_VALUE;
        
        //#line 190 "x10/regionarray/PolyScanner.x10"
        int k$156915 = 0;
        
        //#line 190 "x10/regionarray/PolyScanner.x10"
        for (;
             true;
             ) {
            
            //#line 190 "x10/regionarray/PolyScanner.x10"
            final x10.regionarray.Array this$156917 = ((x10.regionarray.Array)(this.myMin));
            
            //#line 190 "x10/regionarray/PolyScanner.x10"
            final long i$156918 = ((long)(((int)(axis))));
            
            //#line 442 . "x10/regionarray/Array.x10"
            x10.regionarray.VarMat ret$156919 =  null;
            
            //#line 446 . "x10/regionarray/Array.x10"
            final x10.core.Rail t$156885 = ((x10.core.Rail)(((x10.regionarray.Array<x10.regionarray.VarMat>)this$156917).raw));
            
            //#line 446 . "x10/regionarray/Array.x10"
            final x10.regionarray.VarMat t$156886 = ((x10.regionarray.VarMat[])t$156885.value)[(int)i$156918];
            
            //#line 446 . "x10/regionarray/Array.x10"
            ret$156919 = t$156886;
            
            //#line 190 "x10/regionarray/PolyScanner.x10"
            final int t$156921 = ((x10.regionarray.Mat<x10.regionarray.VarRow>)ret$156919).rows;
            
            //#line 190 "x10/regionarray/PolyScanner.x10"
            final boolean t$156922 = ((k$156915) < (((int)(t$156921))));
            
            //#line 190 "x10/regionarray/PolyScanner.x10"
            if (!(t$156922)) {
                
                //#line 190 "x10/regionarray/PolyScanner.x10"
                break;
            }
            
            //#line 191 "x10/regionarray/PolyScanner.x10"
            final x10.regionarray.Array this$156887 = ((x10.regionarray.Array)(this.myMin));
            
            //#line 191 "x10/regionarray/PolyScanner.x10"
            final long i$156888 = ((long)(((int)(axis))));
            
            //#line 442 . "x10/regionarray/Array.x10"
            x10.regionarray.VarMat ret$156889 =  null;
            
            //#line 446 . "x10/regionarray/Array.x10"
            final x10.core.Rail t$156881 = ((x10.core.Rail)(((x10.regionarray.Array<x10.regionarray.VarMat>)this$156887).raw));
            
            //#line 446 . "x10/regionarray/Array.x10"
            final x10.regionarray.VarMat t$156882 = ((x10.regionarray.VarMat[])t$156881.value)[(int)i$156888];
            
            //#line 446 . "x10/regionarray/Array.x10"
            ret$156889 = t$156882;
            
            //#line 191 "x10/regionarray/PolyScanner.x10"
            final x10.regionarray.VarRow t$156892 = ((x10.regionarray.Mat<x10.regionarray.VarRow>)ret$156889).$apply$G((int)(k$156915));
            
            //#line 191 "x10/regionarray/PolyScanner.x10"
            final int a$156893 = t$156892.$apply$O((int)(axis));
            
            //#line 192 "x10/regionarray/PolyScanner.x10"
            final x10.regionarray.Array this$156894 = ((x10.regionarray.Array)(this.minSum));
            
            //#line 192 "x10/regionarray/PolyScanner.x10"
            final long i$156895 = ((long)(((int)(axis))));
            
            //#line 442 . "x10/regionarray/Array.x10"
            x10.regionarray.VarMat ret$156896 =  null;
            
            //#line 446 . "x10/regionarray/Array.x10"
            final x10.core.Rail t$156883 = ((x10.core.Rail)(((x10.regionarray.Array<x10.regionarray.VarMat>)this$156894).raw));
            
            //#line 446 . "x10/regionarray/Array.x10"
            final x10.regionarray.VarMat t$156884 = ((x10.regionarray.VarMat[])t$156883.value)[(int)i$156895];
            
            //#line 446 . "x10/regionarray/Array.x10"
            ret$156896 = t$156884;
            
            //#line 192 "x10/regionarray/PolyScanner.x10"
            final x10.regionarray.VarRow t$156899 = ((x10.regionarray.Mat<x10.regionarray.VarRow>)ret$156896).$apply$G((int)(k$156915));
            
            //#line 192 "x10/regionarray/PolyScanner.x10"
            int b$156900 = t$156899.$apply$O((int)(axis));
            
            //#line 194 "x10/regionarray/PolyScanner.x10"
            final boolean t$156902 = ((b$156900) > (((int)(0))));
            
            //#line 194 "x10/regionarray/PolyScanner.x10"
            int t$156903 =  0;
            
            //#line 194 "x10/regionarray/PolyScanner.x10"
            if (t$156902) {
                
                //#line 194 "x10/regionarray/PolyScanner.x10"
                final int t$156905 = (-(b$156900));
                
                //#line 194 "x10/regionarray/PolyScanner.x10"
                final int t$156906 = ((t$156905) + (((int)(a$156893))));
                
                //#line 194 "x10/regionarray/PolyScanner.x10"
                final int t$156907 = ((t$156906) + (((int)(1))));
                
                //#line 194 "x10/regionarray/PolyScanner.x10"
                t$156903 = ((t$156907) / (((int)(a$156893))));
            } else {
                
                //#line 194 "x10/regionarray/PolyScanner.x10"
                final int t$156909 = (-(b$156900));
                
                //#line 194 "x10/regionarray/PolyScanner.x10"
                t$156903 = ((t$156909) / (((int)(a$156893))));
            }
            
            //#line 195 "x10/regionarray/PolyScanner.x10"
            final boolean t$156912 = ((t$156903) > (((int)(result))));
            
            //#line 195 "x10/regionarray/PolyScanner.x10"
            if (t$156912) {
                
                //#line 195 "x10/regionarray/PolyScanner.x10"
                result = t$156903;
            }
            
            //#line 190 "x10/regionarray/PolyScanner.x10"
            final int t$156914 = ((k$156915) + (((int)(1))));
            
            //#line 190 "x10/regionarray/PolyScanner.x10"
            k$156915 = t$156914;
        }
        
        //#line 197 "x10/regionarray/PolyScanner.x10"
        return result;
    }
    
    
    //#line 200 "x10/regionarray/PolyScanner.x10"
    final public int max$O(final int axis) {
        
        //#line 201 "x10/regionarray/PolyScanner.x10"
        int result = java.lang.Integer.MAX_VALUE;
        
        //#line 202 "x10/regionarray/PolyScanner.x10"
        int k$156954 = 0;
        
        //#line 202 "x10/regionarray/PolyScanner.x10"
        for (;
             true;
             ) {
            
            //#line 202 "x10/regionarray/PolyScanner.x10"
            final x10.regionarray.Array this$156956 = ((x10.regionarray.Array)(this.myMax));
            
            //#line 202 "x10/regionarray/PolyScanner.x10"
            final long i$156957 = ((long)(((int)(axis))));
            
            //#line 442 . "x10/regionarray/Array.x10"
            x10.regionarray.VarMat ret$156958 =  null;
            
            //#line 446 . "x10/regionarray/Array.x10"
            final x10.core.Rail t$156927 = ((x10.core.Rail)(((x10.regionarray.Array<x10.regionarray.VarMat>)this$156956).raw));
            
            //#line 446 . "x10/regionarray/Array.x10"
            final x10.regionarray.VarMat t$156928 = ((x10.regionarray.VarMat[])t$156927.value)[(int)i$156957];
            
            //#line 446 . "x10/regionarray/Array.x10"
            ret$156958 = t$156928;
            
            //#line 202 "x10/regionarray/PolyScanner.x10"
            final int t$156960 = ((x10.regionarray.Mat<x10.regionarray.VarRow>)ret$156958).rows;
            
            //#line 202 "x10/regionarray/PolyScanner.x10"
            final boolean t$156961 = ((k$156954) < (((int)(t$156960))));
            
            //#line 202 "x10/regionarray/PolyScanner.x10"
            if (!(t$156961)) {
                
                //#line 202 "x10/regionarray/PolyScanner.x10"
                break;
            }
            
            //#line 203 "x10/regionarray/PolyScanner.x10"
            final x10.regionarray.Array this$156929 = ((x10.regionarray.Array)(this.myMax));
            
            //#line 203 "x10/regionarray/PolyScanner.x10"
            final long i$156930 = ((long)(((int)(axis))));
            
            //#line 442 . "x10/regionarray/Array.x10"
            x10.regionarray.VarMat ret$156931 =  null;
            
            //#line 446 . "x10/regionarray/Array.x10"
            final x10.core.Rail t$156923 = ((x10.core.Rail)(((x10.regionarray.Array<x10.regionarray.VarMat>)this$156929).raw));
            
            //#line 446 . "x10/regionarray/Array.x10"
            final x10.regionarray.VarMat t$156924 = ((x10.regionarray.VarMat[])t$156923.value)[(int)i$156930];
            
            //#line 446 . "x10/regionarray/Array.x10"
            ret$156931 = t$156924;
            
            //#line 203 "x10/regionarray/PolyScanner.x10"
            final x10.regionarray.VarRow t$156934 = ((x10.regionarray.Mat<x10.regionarray.VarRow>)ret$156931).$apply$G((int)(k$156954));
            
            //#line 203 "x10/regionarray/PolyScanner.x10"
            final int a$156935 = t$156934.$apply$O((int)(axis));
            
            //#line 204 "x10/regionarray/PolyScanner.x10"
            final x10.regionarray.Array this$156936 = ((x10.regionarray.Array)(this.maxSum));
            
            //#line 204 "x10/regionarray/PolyScanner.x10"
            final long i$156937 = ((long)(((int)(axis))));
            
            //#line 442 . "x10/regionarray/Array.x10"
            x10.regionarray.VarMat ret$156938 =  null;
            
            //#line 446 . "x10/regionarray/Array.x10"
            final x10.core.Rail t$156925 = ((x10.core.Rail)(((x10.regionarray.Array<x10.regionarray.VarMat>)this$156936).raw));
            
            //#line 446 . "x10/regionarray/Array.x10"
            final x10.regionarray.VarMat t$156926 = ((x10.regionarray.VarMat[])t$156925.value)[(int)i$156937];
            
            //#line 446 . "x10/regionarray/Array.x10"
            ret$156938 = t$156926;
            
            //#line 204 "x10/regionarray/PolyScanner.x10"
            final x10.regionarray.VarRow t$156941 = ((x10.regionarray.Mat<x10.regionarray.VarRow>)ret$156938).$apply$G((int)(k$156954));
            
            //#line 204 "x10/regionarray/PolyScanner.x10"
            final int b$156942 = t$156941.$apply$O((int)(axis));
            
            //#line 206 "x10/regionarray/PolyScanner.x10"
            final boolean t$156943 = ((b$156942) > (((int)(0))));
            
            //#line 206 "x10/regionarray/PolyScanner.x10"
            int t$156944 =  0;
            
            //#line 206 "x10/regionarray/PolyScanner.x10"
            if (t$156943) {
                
                //#line 206 "x10/regionarray/PolyScanner.x10"
                final int t$156945 = (-(b$156942));
                
                //#line 206 "x10/regionarray/PolyScanner.x10"
                final int t$156946 = ((t$156945) - (((int)(a$156935))));
                
                //#line 206 "x10/regionarray/PolyScanner.x10"
                final int t$156947 = ((t$156946) + (((int)(1))));
                
                //#line 206 "x10/regionarray/PolyScanner.x10"
                t$156944 = ((t$156947) / (((int)(a$156935))));
            } else {
                
                //#line 206 "x10/regionarray/PolyScanner.x10"
                final int t$156948 = (-(b$156942));
                
                //#line 206 "x10/regionarray/PolyScanner.x10"
                t$156944 = ((t$156948) / (((int)(a$156935))));
            }
            
            //#line 207 "x10/regionarray/PolyScanner.x10"
            final boolean t$156951 = ((t$156944) < (((int)(result))));
            
            //#line 207 "x10/regionarray/PolyScanner.x10"
            if (t$156951) {
                
                //#line 207 "x10/regionarray/PolyScanner.x10"
                result = t$156944;
            }
            
            //#line 202 "x10/regionarray/PolyScanner.x10"
            final int t$156953 = ((k$156954) + (((int)(1))));
            
            //#line 202 "x10/regionarray/PolyScanner.x10"
            k$156954 = t$156953;
        }
        
        //#line 209 "x10/regionarray/PolyScanner.x10"
        return result;
    }
    
    
    //#line 229 "x10/regionarray/PolyScanner.x10"
    /**
     * odometer-style iterator for this scanner
     *
     * advance() computes the k that is the axis to be bumped:
     *
     * axis    0    1         k        k+1
     * now   x[0] x[1] ...  x[k]   max[k+1] ...  max[rank-1]
     * next  x[0] x[1] ...  x[k]+1 min[k+1] ...  min[rank-1]
     *
     * i.e. bump k, reset k+1 through rank-1
     * finished if k<0
     *
     * next() does the bumping and resetting
     *
     * assumes no degenerate axes, which is guaranteeed by Scanner API
     */
    @x10.runtime.impl.java.X10Generated
    final public static class RailIt extends x10.core.Ref implements x10.lang.Iterator, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<RailIt> $RTT = 
            x10.rtt.NamedType.<RailIt> make("x10.regionarray.PolyScanner.RailIt",
                                            RailIt.class,
                                            new x10.rtt.Type[] {
                                                x10.rtt.ParameterizedType.make(x10.lang.Iterator.$RTT, x10.rtt.ParameterizedType.make(x10.core.Rail.$RTT, x10.rtt.Types.INT))
                                            });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static x10.serialization.X10JavaSerializable $_deserialize_body(x10.regionarray.PolyScanner.RailIt $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            $_obj.doesHaveNext = $deserializer.readBoolean();
            $_obj.k = $deserializer.readInt();
            $_obj.myMax = $deserializer.readObject();
            $_obj.myMin = $deserializer.readObject();
            $_obj.out$ = $deserializer.readObject();
            $_obj.rank = $deserializer.readLong();
            $_obj.s = $deserializer.readObject();
            $_obj.x = $deserializer.readObject();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.regionarray.PolyScanner.RailIt $_obj = new x10.regionarray.PolyScanner.RailIt((java.lang.System[]) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            $serializer.write(this.doesHaveNext);
            $serializer.write(this.k);
            $serializer.write(this.myMax);
            $serializer.write(this.myMin);
            $serializer.write(this.out$);
            $serializer.write(this.rank);
            $serializer.write(this.s);
            $serializer.write(this.x);
            
        }
        
        // constructor just for allocation
        public RailIt(final java.lang.System[] $dummy) {
            
        }
        
        // bridge for method abstract public x10.lang.Iterator[T].next(){}:T
        final public x10.core.Rail next$G() {
            return next();
        }
        
        
    
        
        //#line 68 "x10/regionarray/PolyScanner.x10"
        public x10.regionarray.PolyScanner out$;
        
        //#line 230 "x10/regionarray/PolyScanner.x10"
        public long rank;
        
        //#line 231 "x10/regionarray/PolyScanner.x10"
        public x10.regionarray.PolyScanner s;
        
        //#line 233 "x10/regionarray/PolyScanner.x10"
        public x10.core.Rail<x10.core.Int> x;
        
        //#line 234 "x10/regionarray/PolyScanner.x10"
        public x10.core.Rail<x10.core.Int> myMin;
        
        //#line 235 "x10/regionarray/PolyScanner.x10"
        public x10.core.Rail<x10.core.Int> myMax;
        
        //#line 237 "x10/regionarray/PolyScanner.x10"
        public int k;
        
        //#line 238 "x10/regionarray/PolyScanner.x10"
        public boolean doesHaveNext;
        
        
        //#line 239 "x10/regionarray/PolyScanner.x10"
        // creation method for java code (1-phase java constructor)
        public RailIt(final x10.regionarray.PolyScanner out$) {
            this((java.lang.System[]) null);
            x10$regionarray$PolyScanner$RailIt$$init$S(out$);
        }
        
        // constructor for non-virtual call
        final public x10.regionarray.PolyScanner.RailIt x10$regionarray$PolyScanner$RailIt$$init$S(final x10.regionarray.PolyScanner out$) {
             {
                
                //#line 68 "x10/regionarray/PolyScanner.x10"
                this.out$ = out$;
                
                //#line 239 "x10/regionarray/PolyScanner.x10"
                
                
                //#line 229 "x10/regionarray/PolyScanner.x10"
                this.__fieldInitializers_x10_regionarray_PolyScanner_RailIt();
                
                //#line 240 "x10/regionarray/PolyScanner.x10"
                final x10.core.Rail t$156362 = ((x10.core.Rail)(this.myMin));
                
                //#line 240 "x10/regionarray/PolyScanner.x10"
                final long t$156363 = ((long)(((int)(0))));
                
                //#line 240 "x10/regionarray/PolyScanner.x10"
                final x10.regionarray.PolyScanner t$156361 = ((x10.regionarray.PolyScanner)(this.s));
                
                //#line 240 "x10/regionarray/PolyScanner.x10"
                final int t$156364 = t$156361.min$O((int)(0));
                
                //#line 240 "x10/regionarray/PolyScanner.x10"
                ((int[])t$156362.value)[(int)t$156363] = t$156364;
                
                //#line 241 "x10/regionarray/PolyScanner.x10"
                final x10.core.Rail t$156366 = ((x10.core.Rail)(this.myMax));
                
                //#line 241 "x10/regionarray/PolyScanner.x10"
                final long t$156367 = ((long)(((int)(0))));
                
                //#line 241 "x10/regionarray/PolyScanner.x10"
                final x10.regionarray.PolyScanner t$156365 = ((x10.regionarray.PolyScanner)(this.s));
                
                //#line 241 "x10/regionarray/PolyScanner.x10"
                final int t$156368 = t$156365.max$O((int)(0));
                
                //#line 241 "x10/regionarray/PolyScanner.x10"
                ((int[])t$156366.value)[(int)t$156367] = t$156368;
                
                //#line 242 "x10/regionarray/PolyScanner.x10"
                final x10.core.Rail t$156370 = ((x10.core.Rail)(this.x));
                
                //#line 242 "x10/regionarray/PolyScanner.x10"
                final long t$156371 = ((long)(((int)(0))));
                
                //#line 242 "x10/regionarray/PolyScanner.x10"
                final x10.regionarray.PolyScanner t$156369 = ((x10.regionarray.PolyScanner)(this.s));
                
                //#line 242 "x10/regionarray/PolyScanner.x10"
                final int t$156372 = t$156369.min$O((int)(0));
                
                //#line 242 "x10/regionarray/PolyScanner.x10"
                ((int[])t$156370.value)[(int)t$156371] = t$156372;
                
                //#line 243 "x10/regionarray/PolyScanner.x10"
                this.k = 1;
                
                //#line 243 "x10/regionarray/PolyScanner.x10"
                for (;
                     true;
                     ) {
                    
                    //#line 243 "x10/regionarray/PolyScanner.x10"
                    final int t$156987 = this.k;
                    
                    //#line 243 "x10/regionarray/PolyScanner.x10"
                    final long t$156988 = ((long)(((int)(t$156987))));
                    
                    //#line 243 "x10/regionarray/PolyScanner.x10"
                    final long t$156989 = this.rank;
                    
                    //#line 243 "x10/regionarray/PolyScanner.x10"
                    final boolean t$156990 = ((t$156988) < (((long)(t$156989))));
                    
                    //#line 243 "x10/regionarray/PolyScanner.x10"
                    if (!(t$156990)) {
                        
                        //#line 243 "x10/regionarray/PolyScanner.x10"
                        break;
                    }
                    
                    //#line 244 "x10/regionarray/PolyScanner.x10"
                    final x10.regionarray.PolyScanner t$156962 = ((x10.regionarray.PolyScanner)(this.s));
                    
                    //#line 244 "x10/regionarray/PolyScanner.x10"
                    final int t$156963 = this.k;
                    
                    //#line 244 "x10/regionarray/PolyScanner.x10"
                    final int t$156964 = ((t$156963) - (((int)(1))));
                    
                    //#line 244 "x10/regionarray/PolyScanner.x10"
                    final x10.core.Rail t$156965 = ((x10.core.Rail)(this.x));
                    
                    //#line 244 "x10/regionarray/PolyScanner.x10"
                    final int t$156966 = this.k;
                    
                    //#line 244 "x10/regionarray/PolyScanner.x10"
                    final int t$156967 = ((t$156966) - (((int)(1))));
                    
                    //#line 244 "x10/regionarray/PolyScanner.x10"
                    final long t$156968 = ((long)(((int)(t$156967))));
                    
                    //#line 244 "x10/regionarray/PolyScanner.x10"
                    final int t$156969 = ((int[])t$156965.value)[(int)t$156968];
                    
                    //#line 244 "x10/regionarray/PolyScanner.x10"
                    t$156962.set((int)(t$156964), (int)(t$156969));
                    
                    //#line 245 "x10/regionarray/PolyScanner.x10"
                    final x10.regionarray.PolyScanner t$156970 = ((x10.regionarray.PolyScanner)(this.s));
                    
                    //#line 245 "x10/regionarray/PolyScanner.x10"
                    final int t$156971 = this.k;
                    
                    //#line 245 "x10/regionarray/PolyScanner.x10"
                    final int m$156972 = t$156970.min$O((int)(t$156971));
                    
                    //#line 246 "x10/regionarray/PolyScanner.x10"
                    final x10.core.Rail t$156973 = ((x10.core.Rail)(this.x));
                    
                    //#line 246 "x10/regionarray/PolyScanner.x10"
                    final int t$156974 = this.k;
                    
                    //#line 246 "x10/regionarray/PolyScanner.x10"
                    final long t$156975 = ((long)(((int)(t$156974))));
                    
                    //#line 246 "x10/regionarray/PolyScanner.x10"
                    ((int[])t$156973.value)[(int)t$156975] = m$156972;
                    
                    //#line 247 "x10/regionarray/PolyScanner.x10"
                    final x10.core.Rail t$156976 = ((x10.core.Rail)(this.myMin));
                    
                    //#line 247 "x10/regionarray/PolyScanner.x10"
                    final int t$156977 = this.k;
                    
                    //#line 247 "x10/regionarray/PolyScanner.x10"
                    final long t$156978 = ((long)(((int)(t$156977))));
                    
                    //#line 247 "x10/regionarray/PolyScanner.x10"
                    ((int[])t$156976.value)[(int)t$156978] = m$156972;
                    
                    //#line 248 "x10/regionarray/PolyScanner.x10"
                    final x10.core.Rail t$156979 = ((x10.core.Rail)(this.myMax));
                    
                    //#line 248 "x10/regionarray/PolyScanner.x10"
                    final int t$156980 = this.k;
                    
                    //#line 248 "x10/regionarray/PolyScanner.x10"
                    final long t$156981 = ((long)(((int)(t$156980))));
                    
                    //#line 248 "x10/regionarray/PolyScanner.x10"
                    final x10.regionarray.PolyScanner t$156982 = ((x10.regionarray.PolyScanner)(this.s));
                    
                    //#line 248 "x10/regionarray/PolyScanner.x10"
                    final int t$156983 = this.k;
                    
                    //#line 248 "x10/regionarray/PolyScanner.x10"
                    final int t$156984 = t$156982.max$O((int)(t$156983));
                    
                    //#line 248 "x10/regionarray/PolyScanner.x10"
                    ((int[])t$156979.value)[(int)t$156981] = t$156984;
                    
                    //#line 243 "x10/regionarray/PolyScanner.x10"
                    final int t$156985 = this.k;
                    
                    //#line 243 "x10/regionarray/PolyScanner.x10"
                    final int t$156986 = ((t$156985) + (((int)(1))));
                    
                    //#line 243 "x10/regionarray/PolyScanner.x10"
                    this.k = t$156986;
                }
                
                //#line 250 "x10/regionarray/PolyScanner.x10"
                final x10.core.Rail a$154930 = ((x10.core.Rail)(this.x));
                
                //#line 250 "x10/regionarray/PolyScanner.x10"
                final long t$156402 = this.rank;
                
                //#line 250 "x10/regionarray/PolyScanner.x10"
                final long i0$154931 = ((t$156402) - (((long)(1L))));
                
                //#line 250 "x10/regionarray/PolyScanner.x10"
                final int t$156403 = ((int[])a$154930.value)[(int)i0$154931];
                
                //#line 250 "x10/regionarray/PolyScanner.x10"
                final int r$154939 = ((t$156403) - (((int)(1))));
                
                //#line 250 "x10/regionarray/PolyScanner.x10"
                ((int[])a$154930.value)[(int)i0$154931] = r$154939;
                
                //#line 251 "x10/regionarray/PolyScanner.x10"
                this.checkHasNext();
            }
            return this;
        }
        
        
        
        //#line 254 "x10/regionarray/PolyScanner.x10"
        public boolean hasNext$O() {
            
            //#line 254 "x10/regionarray/PolyScanner.x10"
            final boolean t$156404 = this.doesHaveNext;
            
            //#line 254 "x10/regionarray/PolyScanner.x10"
            return t$156404;
        }
        
        
        //#line 256 "x10/regionarray/PolyScanner.x10"
        private void checkHasNext() {
            
            //#line 257 "x10/regionarray/PolyScanner.x10"
            final long t$156405 = this.rank;
            
            //#line 257 "x10/regionarray/PolyScanner.x10"
            final int t$156406 = ((int)(long)(((long)(t$156405))));
            
            //#line 257 "x10/regionarray/PolyScanner.x10"
            final int t$156407 = ((t$156406) - (((int)(1))));
            
            //#line 257 "x10/regionarray/PolyScanner.x10"
            this.k = t$156407;
            
            //#line 258 "x10/regionarray/PolyScanner.x10"
            while (true) {
                
                //#line 258 "x10/regionarray/PolyScanner.x10"
                final x10.core.Rail t$156409 = ((x10.core.Rail)(this.x));
                
                //#line 258 "x10/regionarray/PolyScanner.x10"
                final int t$156408 = this.k;
                
                //#line 258 "x10/regionarray/PolyScanner.x10"
                final long t$156410 = ((long)(((int)(t$156408))));
                
                //#line 258 "x10/regionarray/PolyScanner.x10"
                final int t$156414 = ((int[])t$156409.value)[(int)t$156410];
                
                //#line 258 "x10/regionarray/PolyScanner.x10"
                final x10.core.Rail t$156412 = ((x10.core.Rail)(this.myMax));
                
                //#line 258 "x10/regionarray/PolyScanner.x10"
                final int t$156411 = this.k;
                
                //#line 258 "x10/regionarray/PolyScanner.x10"
                final long t$156413 = ((long)(((int)(t$156411))));
                
                //#line 258 "x10/regionarray/PolyScanner.x10"
                final int t$156415 = ((int[])t$156412.value)[(int)t$156413];
                
                //#line 258 "x10/regionarray/PolyScanner.x10"
                final boolean t$156421 = ((t$156414) >= (((int)(t$156415))));
                
                //#line 258 "x10/regionarray/PolyScanner.x10"
                if (!(t$156421)) {
                    
                    //#line 258 "x10/regionarray/PolyScanner.x10"
                    break;
                }
                
                //#line 259 "x10/regionarray/PolyScanner.x10"
                final int t$156991 = this.k;
                
                //#line 259 "x10/regionarray/PolyScanner.x10"
                final int t$156992 = ((t$156991) - (((int)(1))));
                
                //#line 259 "x10/regionarray/PolyScanner.x10"
                final int t$156993 = this.k = t$156992;
                
                //#line 259 "x10/regionarray/PolyScanner.x10"
                final long t$156994 = ((long)(((int)(t$156993))));
                
                //#line 259 "x10/regionarray/PolyScanner.x10"
                final boolean t$156995 = ((t$156994) < (((long)(0L))));
                
                //#line 259 "x10/regionarray/PolyScanner.x10"
                if (t$156995) {
                    
                    //#line 260 "x10/regionarray/PolyScanner.x10"
                    this.doesHaveNext = false;
                    
                    //#line 261 "x10/regionarray/PolyScanner.x10"
                    return;
                }
            }
            
            //#line 264 "x10/regionarray/PolyScanner.x10"
            this.doesHaveNext = true;
        }
        
        public static void checkHasNext$P(final x10.regionarray.PolyScanner.RailIt RailIt) {
            RailIt.checkHasNext();
        }
        
        
        //#line 267 "x10/regionarray/PolyScanner.x10"
        final public x10.core.Rail next() {
            
            //#line 268 "x10/regionarray/PolyScanner.x10"
            final x10.core.Rail a$154970 = ((x10.core.Rail)(this.x));
            
            //#line 268 "x10/regionarray/PolyScanner.x10"
            final int t$156422 = this.k;
            
            //#line 268 "x10/regionarray/PolyScanner.x10"
            final long i0$154971 = ((long)(((int)(t$156422))));
            
            //#line 268 "x10/regionarray/PolyScanner.x10"
            final int t$156423 = ((int[])a$154970.value)[(int)i0$154971];
            
            //#line 268 "x10/regionarray/PolyScanner.x10"
            final int r$154979 = ((t$156423) + (((int)(1))));
            
            //#line 268 "x10/regionarray/PolyScanner.x10"
            ((int[])a$154970.value)[(int)i0$154971] = r$154979;
            
            //#line 269 "x10/regionarray/PolyScanner.x10"
            final int t$157021 = this.k;
            
            //#line 269 "x10/regionarray/PolyScanner.x10"
            final int t$157022 = ((t$157021) + (((int)(1))));
            
            //#line 269 "x10/regionarray/PolyScanner.x10"
            this.k = t$157022;
            
            //#line 269 "x10/regionarray/PolyScanner.x10"
            for (;
                 true;
                 ) {
                
                //#line 269 "x10/regionarray/PolyScanner.x10"
                final int t$157023 = this.k;
                
                //#line 269 "x10/regionarray/PolyScanner.x10"
                final long t$157024 = ((long)(((int)(t$157023))));
                
                //#line 269 "x10/regionarray/PolyScanner.x10"
                final long t$157025 = this.rank;
                
                //#line 269 "x10/regionarray/PolyScanner.x10"
                final boolean t$157026 = ((t$157024) < (((long)(t$157025))));
                
                //#line 269 "x10/regionarray/PolyScanner.x10"
                if (!(t$157026)) {
                    
                    //#line 269 "x10/regionarray/PolyScanner.x10"
                    break;
                }
                
                //#line 270 "x10/regionarray/PolyScanner.x10"
                final x10.regionarray.PolyScanner t$156996 = ((x10.regionarray.PolyScanner)(this.s));
                
                //#line 270 "x10/regionarray/PolyScanner.x10"
                final int t$156997 = this.k;
                
                //#line 270 "x10/regionarray/PolyScanner.x10"
                final int t$156998 = ((t$156997) - (((int)(1))));
                
                //#line 270 "x10/regionarray/PolyScanner.x10"
                final x10.core.Rail t$156999 = ((x10.core.Rail)(this.x));
                
                //#line 270 "x10/regionarray/PolyScanner.x10"
                final int t$157000 = this.k;
                
                //#line 270 "x10/regionarray/PolyScanner.x10"
                final int t$157001 = ((t$157000) - (((int)(1))));
                
                //#line 270 "x10/regionarray/PolyScanner.x10"
                final long t$157002 = ((long)(((int)(t$157001))));
                
                //#line 270 "x10/regionarray/PolyScanner.x10"
                final int t$157003 = ((int[])t$156999.value)[(int)t$157002];
                
                //#line 270 "x10/regionarray/PolyScanner.x10"
                t$156996.set((int)(t$156998), (int)(t$157003));
                
                //#line 271 "x10/regionarray/PolyScanner.x10"
                final x10.regionarray.PolyScanner t$157004 = ((x10.regionarray.PolyScanner)(this.s));
                
                //#line 271 "x10/regionarray/PolyScanner.x10"
                final int t$157005 = this.k;
                
                //#line 271 "x10/regionarray/PolyScanner.x10"
                final int m$157006 = t$157004.min$O((int)(t$157005));
                
                //#line 272 "x10/regionarray/PolyScanner.x10"
                final x10.core.Rail t$157007 = ((x10.core.Rail)(this.x));
                
                //#line 272 "x10/regionarray/PolyScanner.x10"
                final int t$157008 = this.k;
                
                //#line 272 "x10/regionarray/PolyScanner.x10"
                final long t$157009 = ((long)(((int)(t$157008))));
                
                //#line 272 "x10/regionarray/PolyScanner.x10"
                ((int[])t$157007.value)[(int)t$157009] = m$157006;
                
                //#line 273 "x10/regionarray/PolyScanner.x10"
                final x10.core.Rail t$157010 = ((x10.core.Rail)(this.myMin));
                
                //#line 273 "x10/regionarray/PolyScanner.x10"
                final int t$157011 = this.k;
                
                //#line 273 "x10/regionarray/PolyScanner.x10"
                final long t$157012 = ((long)(((int)(t$157011))));
                
                //#line 273 "x10/regionarray/PolyScanner.x10"
                ((int[])t$157010.value)[(int)t$157012] = m$157006;
                
                //#line 274 "x10/regionarray/PolyScanner.x10"
                final x10.core.Rail t$157013 = ((x10.core.Rail)(this.myMax));
                
                //#line 274 "x10/regionarray/PolyScanner.x10"
                final int t$157014 = this.k;
                
                //#line 274 "x10/regionarray/PolyScanner.x10"
                final long t$157015 = ((long)(((int)(t$157014))));
                
                //#line 274 "x10/regionarray/PolyScanner.x10"
                final x10.regionarray.PolyScanner t$157016 = ((x10.regionarray.PolyScanner)(this.s));
                
                //#line 274 "x10/regionarray/PolyScanner.x10"
                final int t$157017 = this.k;
                
                //#line 274 "x10/regionarray/PolyScanner.x10"
                final int t$157018 = t$157016.max$O((int)(t$157017));
                
                //#line 274 "x10/regionarray/PolyScanner.x10"
                ((int[])t$157013.value)[(int)t$157015] = t$157018;
                
                //#line 269 "x10/regionarray/PolyScanner.x10"
                final int t$157019 = this.k;
                
                //#line 269 "x10/regionarray/PolyScanner.x10"
                final int t$157020 = ((t$157019) + (((int)(1))));
                
                //#line 269 "x10/regionarray/PolyScanner.x10"
                this.k = t$157020;
            }
            
            //#line 276 "x10/regionarray/PolyScanner.x10"
            this.checkHasNext();
            
            //#line 277 "x10/regionarray/PolyScanner.x10"
            final x10.core.Rail t$156455 = ((x10.core.Rail)(this.x));
            
            //#line 277 "x10/regionarray/PolyScanner.x10"
            return t$156455;
        }
        
        
        //#line 280 "x10/regionarray/PolyScanner.x10"
        public void remove() {
            
        }
        
        
        //#line 229 "x10/regionarray/PolyScanner.x10"
        final public x10.regionarray.PolyScanner.RailIt x10$regionarray$PolyScanner$RailIt$$this$x10$regionarray$PolyScanner$RailIt() {
            
            //#line 229 "x10/regionarray/PolyScanner.x10"
            return x10.regionarray.PolyScanner.RailIt.this;
        }
        
        
        //#line 229 "x10/regionarray/PolyScanner.x10"
        final public x10.regionarray.PolyScanner x10$regionarray$PolyScanner$RailIt$$this$x10$regionarray$PolyScanner() {
            
            //#line 229 "x10/regionarray/PolyScanner.x10"
            final x10.regionarray.PolyScanner t$156456 = this.out$;
            
            //#line 229 "x10/regionarray/PolyScanner.x10"
            return t$156456;
        }
        
        
        //#line 229 "x10/regionarray/PolyScanner.x10"
        final public void __fieldInitializers_x10_regionarray_PolyScanner_RailIt() {
            
            //#line 230 "x10/regionarray/PolyScanner.x10"
            final x10.regionarray.PolyScanner t$156457 = this.out$;
            
            //#line 230 "x10/regionarray/PolyScanner.x10"
            final long t$156458 = t$156457.rank;
            
            //#line 229 "x10/regionarray/PolyScanner.x10"
            this.rank = t$156458;
            
            //#line 231 "x10/regionarray/PolyScanner.x10"
            final x10.regionarray.PolyScanner t$156459 = this.out$;
            
            //#line 229 "x10/regionarray/PolyScanner.x10"
            this.s = ((x10.regionarray.PolyScanner)(t$156459));
            
            //#line 233 "x10/regionarray/PolyScanner.x10"
            final long t$156460 = this.rank;
            
            //#line 233 "x10/regionarray/PolyScanner.x10"
            final x10.core.Rail t$156461 = ((x10.core.Rail)(new x10.core.Rail<x10.core.Int>(x10.rtt.Types.INT, ((long)(t$156460)))));
            
            //#line 229 "x10/regionarray/PolyScanner.x10"
            this.x = ((x10.core.Rail)(t$156461));
            
            //#line 234 "x10/regionarray/PolyScanner.x10"
            final long t$156462 = this.rank;
            
            //#line 234 "x10/regionarray/PolyScanner.x10"
            final x10.core.Rail t$156463 = ((x10.core.Rail)(new x10.core.Rail<x10.core.Int>(x10.rtt.Types.INT, ((long)(t$156462)))));
            
            //#line 229 "x10/regionarray/PolyScanner.x10"
            this.myMin = ((x10.core.Rail)(t$156463));
            
            //#line 235 "x10/regionarray/PolyScanner.x10"
            final long t$156464 = this.rank;
            
            //#line 235 "x10/regionarray/PolyScanner.x10"
            final x10.core.Rail t$156465 = ((x10.core.Rail)(new x10.core.Rail<x10.core.Int>(x10.rtt.Types.INT, ((long)(t$156464)))));
            
            //#line 229 "x10/regionarray/PolyScanner.x10"
            this.myMax = ((x10.core.Rail)(t$156465));
            
            //#line 229 "x10/regionarray/PolyScanner.x10"
            this.k = 0;
            
            //#line 229 "x10/regionarray/PolyScanner.x10"
            this.doesHaveNext = false;
        }
    }
    
    
    
    //#line 289 "x10/regionarray/PolyScanner.x10"
    /**
     * required by API, but less efficient b/c of allocation
     * XXX figure out how to expose
     *   1. Any/Var/ValPoint?
     *   2. hide inside iterator(body:(Point)=>void)?
     */
    public x10.lang.Iterator iterator() {
        
        //#line 289 "x10/regionarray/PolyScanner.x10"
        final x10.regionarray.PolyScanner.Anonymous$10018 alloc$155149 = ((x10.regionarray.PolyScanner.Anonymous$10018)(new x10.regionarray.PolyScanner.Anonymous$10018((java.lang.System[]) null)));
        
        //#line 289 "x10/regionarray/PolyScanner.x10"
        alloc$155149.x10$regionarray$PolyScanner$Anonymous$10018$$init$S(this);
        
        //#line 289 "x10/regionarray/PolyScanner.x10"
        return alloc$155149;
    }
    
    
    //#line 304 "x10/regionarray/PolyScanner.x10"
    public void printInfo(final x10.io.Printer ps) {
        
        //#line 305 "x10/regionarray/PolyScanner.x10"
        ps.println(((java.lang.Object)("PolyScanner")));
        
        //#line 306 "x10/regionarray/PolyScanner.x10"
        final x10.regionarray.PolyMat t$156466 = ((x10.regionarray.PolyMat)(this.C));
        
        //#line 306 "x10/regionarray/PolyScanner.x10"
        ((x10.regionarray.Mat<x10.regionarray.PolyRow>)t$156466).printInfo(((x10.io.Printer)(ps)), ((java.lang.String)("  C")));
    }
    
    
    //#line 309 "x10/regionarray/PolyScanner.x10"
    public void printInfo2(final x10.io.Printer ps) {
        
        //#line 310 "x10/regionarray/PolyScanner.x10"
        int k = 0;
        
        //#line 310 "x10/regionarray/PolyScanner.x10"
        for (;
             true;
             ) {
            
            //#line 310 "x10/regionarray/PolyScanner.x10"
            final long t$156470 = ((long)(((int)(k))));
            
            //#line 310 "x10/regionarray/PolyScanner.x10"
            final x10.regionarray.Array t$156469 = ((x10.regionarray.Array)(this.myMin));
            
            //#line 310 "x10/regionarray/PolyScanner.x10"
            final long t$156471 = ((x10.regionarray.Array<x10.regionarray.VarMat>)t$156469).size;
            
            //#line 310 "x10/regionarray/PolyScanner.x10"
            final boolean t$156580 = ((t$156470) < (((long)(t$156471))));
            
            //#line 310 "x10/regionarray/PolyScanner.x10"
            if (!(t$156580)) {
                
                //#line 310 "x10/regionarray/PolyScanner.x10"
                break;
            }
            
            //#line 311 "x10/regionarray/PolyScanner.x10"
            final java.lang.String t$157162 = (("axis ") + ((x10.core.Int.$box(k))));
            
            //#line 311 "x10/regionarray/PolyScanner.x10"
            ps.println(((java.lang.Object)(t$157162)));
            
            //#line 312 "x10/regionarray/PolyScanner.x10"
            ps.println(((java.lang.Object)("  min")));
            
            //#line 313 "x10/regionarray/PolyScanner.x10"
            int l$157143 = 0;
            
            //#line 313 "x10/regionarray/PolyScanner.x10"
            for (;
                 true;
                 ) {
                
                //#line 313 "x10/regionarray/PolyScanner.x10"
                final x10.regionarray.Array this$157145 = ((x10.regionarray.Array)(this.myMin));
                
                //#line 313 "x10/regionarray/PolyScanner.x10"
                final long i$157147 = ((long)(((int)(k))));
                
                //#line 442 . "x10/regionarray/Array.x10"
                x10.regionarray.VarMat ret$157148 =  null;
                
                //#line 446 . "x10/regionarray/Array.x10"
                final x10.core.Rail t$157081 = ((x10.core.Rail)(((x10.regionarray.Array<x10.regionarray.VarMat>)this$157145).raw));
                
                //#line 446 . "x10/regionarray/Array.x10"
                final x10.regionarray.VarMat t$157082 = ((x10.regionarray.VarMat[])t$157081.value)[(int)i$157147];
                
                //#line 446 . "x10/regionarray/Array.x10"
                ret$157148 = t$157082;
                
                //#line 313 "x10/regionarray/PolyScanner.x10"
                final int t$157150 = ((x10.regionarray.Mat<x10.regionarray.VarRow>)ret$157148).rows;
                
                //#line 313 "x10/regionarray/PolyScanner.x10"
                final boolean t$157151 = ((l$157143) < (((int)(t$157150))));
                
                //#line 313 "x10/regionarray/PolyScanner.x10"
                if (!(t$157151)) {
                    
                    //#line 313 "x10/regionarray/PolyScanner.x10"
                    break;
                }
                
                //#line 314 "x10/regionarray/PolyScanner.x10"
                ps.print(((java.lang.String)("  ")));
                
                //#line 315 "x10/regionarray/PolyScanner.x10"
                int m$157059 = 0;
                
                //#line 315 "x10/regionarray/PolyScanner.x10"
                for (;
                     true;
                     ) {
                    
                    //#line 315 "x10/regionarray/PolyScanner.x10"
                    final x10.regionarray.Array this$157061 = ((x10.regionarray.Array)(this.myMin));
                    
                    //#line 315 "x10/regionarray/PolyScanner.x10"
                    final long i$157063 = ((long)(((int)(k))));
                    
                    //#line 442 . "x10/regionarray/Array.x10"
                    x10.regionarray.VarMat ret$157064 =  null;
                    
                    //#line 446 . "x10/regionarray/Array.x10"
                    final x10.core.Rail t$157029 = ((x10.core.Rail)(((x10.regionarray.Array<x10.regionarray.VarMat>)this$157061).raw));
                    
                    //#line 446 . "x10/regionarray/Array.x10"
                    final x10.regionarray.VarMat t$157030 = ((x10.regionarray.VarMat[])t$157029.value)[(int)i$157063];
                    
                    //#line 446 . "x10/regionarray/Array.x10"
                    ret$157064 = t$157030;
                    
                    //#line 315 "x10/regionarray/PolyScanner.x10"
                    final x10.regionarray.VarRow t$157067 = ((x10.regionarray.Mat<x10.regionarray.VarRow>)ret$157064).$apply$G((int)(l$157143));
                    
                    //#line 315 "x10/regionarray/PolyScanner.x10"
                    final int t$157068 = t$157067.cols;
                    
                    //#line 315 "x10/regionarray/PolyScanner.x10"
                    final boolean t$157069 = ((m$157059) < (((int)(t$157068))));
                    
                    //#line 315 "x10/regionarray/PolyScanner.x10"
                    if (!(t$157069)) {
                        
                        //#line 315 "x10/regionarray/PolyScanner.x10"
                        break;
                    }
                    
                    //#line 316 "x10/regionarray/PolyScanner.x10"
                    final x10.regionarray.Array this$157031 = ((x10.regionarray.Array)(this.myMin));
                    
                    //#line 316 "x10/regionarray/PolyScanner.x10"
                    final long i$157033 = ((long)(((int)(k))));
                    
                    //#line 442 . "x10/regionarray/Array.x10"
                    x10.regionarray.VarMat ret$157034 =  null;
                    
                    //#line 446 . "x10/regionarray/Array.x10"
                    final x10.core.Rail t$157027 = ((x10.core.Rail)(((x10.regionarray.Array<x10.regionarray.VarMat>)this$157031).raw));
                    
                    //#line 446 . "x10/regionarray/Array.x10"
                    final x10.regionarray.VarMat t$157028 = ((x10.regionarray.VarMat[])t$157027.value)[(int)i$157033];
                    
                    //#line 446 . "x10/regionarray/Array.x10"
                    ret$157034 = t$157028;
                    
                    //#line 316 "x10/regionarray/PolyScanner.x10"
                    final x10.regionarray.VarRow t$157037 = ((x10.regionarray.Mat<x10.regionarray.VarRow>)ret$157034).$apply$G((int)(l$157143));
                    
                    //#line 316 "x10/regionarray/PolyScanner.x10"
                    final int t$157039 = t$157037.$apply$O((int)(m$157059));
                    
                    //#line 316 "x10/regionarray/PolyScanner.x10"
                    final java.lang.String t$157040 = ((" ") + ((x10.core.Int.$box(t$157039))));
                    
                    //#line 316 "x10/regionarray/PolyScanner.x10"
                    ps.print(((java.lang.String)(t$157040)));
                    
                    //#line 315 "x10/regionarray/PolyScanner.x10"
                    final int t$157042 = ((m$157059) + (((int)(1))));
                    
                    //#line 315 "x10/regionarray/PolyScanner.x10"
                    m$157059 = t$157042;
                }
                
                //#line 317 "x10/regionarray/PolyScanner.x10"
                ps.print(((java.lang.String)("  sum")));
                
                //#line 318 "x10/regionarray/PolyScanner.x10"
                int m$157070 = 0;
                
                //#line 318 "x10/regionarray/PolyScanner.x10"
                for (;
                     true;
                     ) {
                    
                    //#line 318 "x10/regionarray/PolyScanner.x10"
                    final x10.regionarray.Array this$157072 = ((x10.regionarray.Array)(this.minSum));
                    
                    //#line 318 "x10/regionarray/PolyScanner.x10"
                    final long i$157074 = ((long)(((int)(k))));
                    
                    //#line 442 . "x10/regionarray/Array.x10"
                    x10.regionarray.VarMat ret$157075 =  null;
                    
                    //#line 446 . "x10/regionarray/Array.x10"
                    final x10.core.Rail t$157045 = ((x10.core.Rail)(((x10.regionarray.Array<x10.regionarray.VarMat>)this$157072).raw));
                    
                    //#line 446 . "x10/regionarray/Array.x10"
                    final x10.regionarray.VarMat t$157046 = ((x10.regionarray.VarMat[])t$157045.value)[(int)i$157074];
                    
                    //#line 446 . "x10/regionarray/Array.x10"
                    ret$157075 = t$157046;
                    
                    //#line 318 "x10/regionarray/PolyScanner.x10"
                    final x10.regionarray.VarRow t$157078 = ((x10.regionarray.Mat<x10.regionarray.VarRow>)ret$157075).$apply$G((int)(l$157143));
                    
                    //#line 318 "x10/regionarray/PolyScanner.x10"
                    final int t$157079 = t$157078.cols;
                    
                    //#line 318 "x10/regionarray/PolyScanner.x10"
                    final boolean t$157080 = ((m$157070) < (((int)(t$157079))));
                    
                    //#line 318 "x10/regionarray/PolyScanner.x10"
                    if (!(t$157080)) {
                        
                        //#line 318 "x10/regionarray/PolyScanner.x10"
                        break;
                    }
                    
                    //#line 319 "x10/regionarray/PolyScanner.x10"
                    final x10.regionarray.Array this$157047 = ((x10.regionarray.Array)(this.minSum));
                    
                    //#line 319 "x10/regionarray/PolyScanner.x10"
                    final long i$157049 = ((long)(((int)(k))));
                    
                    //#line 442 . "x10/regionarray/Array.x10"
                    x10.regionarray.VarMat ret$157050 =  null;
                    
                    //#line 446 . "x10/regionarray/Array.x10"
                    final x10.core.Rail t$157043 = ((x10.core.Rail)(((x10.regionarray.Array<x10.regionarray.VarMat>)this$157047).raw));
                    
                    //#line 446 . "x10/regionarray/Array.x10"
                    final x10.regionarray.VarMat t$157044 = ((x10.regionarray.VarMat[])t$157043.value)[(int)i$157049];
                    
                    //#line 446 . "x10/regionarray/Array.x10"
                    ret$157050 = t$157044;
                    
                    //#line 319 "x10/regionarray/PolyScanner.x10"
                    final x10.regionarray.VarRow t$157053 = ((x10.regionarray.Mat<x10.regionarray.VarRow>)ret$157050).$apply$G((int)(l$157143));
                    
                    //#line 319 "x10/regionarray/PolyScanner.x10"
                    final int t$157055 = t$157053.$apply$O((int)(m$157070));
                    
                    //#line 319 "x10/regionarray/PolyScanner.x10"
                    final java.lang.String t$157056 = ((" ") + ((x10.core.Int.$box(t$157055))));
                    
                    //#line 319 "x10/regionarray/PolyScanner.x10"
                    ps.print(((java.lang.String)(t$157056)));
                    
                    //#line 318 "x10/regionarray/PolyScanner.x10"
                    final int t$157058 = ((m$157070) + (((int)(1))));
                    
                    //#line 318 "x10/regionarray/PolyScanner.x10"
                    m$157070 = t$157058;
                }
                
                //#line 320 "x10/regionarray/PolyScanner.x10"
                ps.print(((java.lang.String)("\n")));
                
                //#line 313 "x10/regionarray/PolyScanner.x10"
                final int t$157084 = ((l$157143) + (((int)(1))));
                
                //#line 313 "x10/regionarray/PolyScanner.x10"
                l$157143 = t$157084;
            }
            
            //#line 322 "x10/regionarray/PolyScanner.x10"
            ps.printf(((java.lang.String)("  max\n")));
            
            //#line 323 "x10/regionarray/PolyScanner.x10"
            int l$157152 = 0;
            
            //#line 323 "x10/regionarray/PolyScanner.x10"
            for (;
                 true;
                 ) {
                
                //#line 323 "x10/regionarray/PolyScanner.x10"
                final x10.regionarray.Array this$157154 = ((x10.regionarray.Array)(this.myMax));
                
                //#line 323 "x10/regionarray/PolyScanner.x10"
                final long i$157156 = ((long)(((int)(k))));
                
                //#line 442 . "x10/regionarray/Array.x10"
                x10.regionarray.VarMat ret$157157 =  null;
                
                //#line 446 . "x10/regionarray/Array.x10"
                final x10.core.Rail t$157139 = ((x10.core.Rail)(((x10.regionarray.Array<x10.regionarray.VarMat>)this$157154).raw));
                
                //#line 446 . "x10/regionarray/Array.x10"
                final x10.regionarray.VarMat t$157140 = ((x10.regionarray.VarMat[])t$157139.value)[(int)i$157156];
                
                //#line 446 . "x10/regionarray/Array.x10"
                ret$157157 = t$157140;
                
                //#line 323 "x10/regionarray/PolyScanner.x10"
                final int t$157159 = ((x10.regionarray.Mat<x10.regionarray.VarRow>)ret$157157).rows;
                
                //#line 323 "x10/regionarray/PolyScanner.x10"
                final boolean t$157160 = ((l$157152) < (((int)(t$157159))));
                
                //#line 323 "x10/regionarray/PolyScanner.x10"
                if (!(t$157160)) {
                    
                    //#line 323 "x10/regionarray/PolyScanner.x10"
                    break;
                }
                
                //#line 324 "x10/regionarray/PolyScanner.x10"
                ps.print(((java.lang.String)("  ")));
                
                //#line 325 "x10/regionarray/PolyScanner.x10"
                int m$157117 = 0;
                
                //#line 325 "x10/regionarray/PolyScanner.x10"
                for (;
                     true;
                     ) {
                    
                    //#line 325 "x10/regionarray/PolyScanner.x10"
                    final x10.regionarray.Array this$157119 = ((x10.regionarray.Array)(this.myMax));
                    
                    //#line 325 "x10/regionarray/PolyScanner.x10"
                    final long i$157121 = ((long)(((int)(k))));
                    
                    //#line 442 . "x10/regionarray/Array.x10"
                    x10.regionarray.VarMat ret$157122 =  null;
                    
                    //#line 446 . "x10/regionarray/Array.x10"
                    final x10.core.Rail t$157087 = ((x10.core.Rail)(((x10.regionarray.Array<x10.regionarray.VarMat>)this$157119).raw));
                    
                    //#line 446 . "x10/regionarray/Array.x10"
                    final x10.regionarray.VarMat t$157088 = ((x10.regionarray.VarMat[])t$157087.value)[(int)i$157121];
                    
                    //#line 446 . "x10/regionarray/Array.x10"
                    ret$157122 = t$157088;
                    
                    //#line 325 "x10/regionarray/PolyScanner.x10"
                    final x10.regionarray.VarRow t$157125 = ((x10.regionarray.Mat<x10.regionarray.VarRow>)ret$157122).$apply$G((int)(l$157152));
                    
                    //#line 325 "x10/regionarray/PolyScanner.x10"
                    final int t$157126 = t$157125.cols;
                    
                    //#line 325 "x10/regionarray/PolyScanner.x10"
                    final boolean t$157127 = ((m$157117) < (((int)(t$157126))));
                    
                    //#line 325 "x10/regionarray/PolyScanner.x10"
                    if (!(t$157127)) {
                        
                        //#line 325 "x10/regionarray/PolyScanner.x10"
                        break;
                    }
                    
                    //#line 326 "x10/regionarray/PolyScanner.x10"
                    final x10.regionarray.Array this$157089 = ((x10.regionarray.Array)(this.myMax));
                    
                    //#line 326 "x10/regionarray/PolyScanner.x10"
                    final long i$157091 = ((long)(((int)(k))));
                    
                    //#line 442 . "x10/regionarray/Array.x10"
                    x10.regionarray.VarMat ret$157092 =  null;
                    
                    //#line 446 . "x10/regionarray/Array.x10"
                    final x10.core.Rail t$157085 = ((x10.core.Rail)(((x10.regionarray.Array<x10.regionarray.VarMat>)this$157089).raw));
                    
                    //#line 446 . "x10/regionarray/Array.x10"
                    final x10.regionarray.VarMat t$157086 = ((x10.regionarray.VarMat[])t$157085.value)[(int)i$157091];
                    
                    //#line 446 . "x10/regionarray/Array.x10"
                    ret$157092 = t$157086;
                    
                    //#line 326 "x10/regionarray/PolyScanner.x10"
                    final x10.regionarray.VarRow t$157095 = ((x10.regionarray.Mat<x10.regionarray.VarRow>)ret$157092).$apply$G((int)(l$157152));
                    
                    //#line 326 "x10/regionarray/PolyScanner.x10"
                    final int t$157097 = t$157095.$apply$O((int)(m$157117));
                    
                    //#line 326 "x10/regionarray/PolyScanner.x10"
                    final java.lang.String t$157098 = ((" ") + ((x10.core.Int.$box(t$157097))));
                    
                    //#line 326 "x10/regionarray/PolyScanner.x10"
                    ps.print(((java.lang.String)(t$157098)));
                    
                    //#line 325 "x10/regionarray/PolyScanner.x10"
                    final int t$157100 = ((m$157117) + (((int)(1))));
                    
                    //#line 325 "x10/regionarray/PolyScanner.x10"
                    m$157117 = t$157100;
                }
                
                //#line 327 "x10/regionarray/PolyScanner.x10"
                ps.print(((java.lang.String)("  sum")));
                
                //#line 328 "x10/regionarray/PolyScanner.x10"
                int m$157128 = 0;
                
                //#line 328 "x10/regionarray/PolyScanner.x10"
                for (;
                     true;
                     ) {
                    
                    //#line 328 "x10/regionarray/PolyScanner.x10"
                    final x10.regionarray.Array this$157130 = ((x10.regionarray.Array)(this.maxSum));
                    
                    //#line 328 "x10/regionarray/PolyScanner.x10"
                    final long i$157132 = ((long)(((int)(k))));
                    
                    //#line 442 . "x10/regionarray/Array.x10"
                    x10.regionarray.VarMat ret$157133 =  null;
                    
                    //#line 446 . "x10/regionarray/Array.x10"
                    final x10.core.Rail t$157103 = ((x10.core.Rail)(((x10.regionarray.Array<x10.regionarray.VarMat>)this$157130).raw));
                    
                    //#line 446 . "x10/regionarray/Array.x10"
                    final x10.regionarray.VarMat t$157104 = ((x10.regionarray.VarMat[])t$157103.value)[(int)i$157132];
                    
                    //#line 446 . "x10/regionarray/Array.x10"
                    ret$157133 = t$157104;
                    
                    //#line 328 "x10/regionarray/PolyScanner.x10"
                    final x10.regionarray.VarRow t$157136 = ((x10.regionarray.Mat<x10.regionarray.VarRow>)ret$157133).$apply$G((int)(l$157152));
                    
                    //#line 328 "x10/regionarray/PolyScanner.x10"
                    final int t$157137 = t$157136.cols;
                    
                    //#line 328 "x10/regionarray/PolyScanner.x10"
                    final boolean t$157138 = ((m$157128) < (((int)(t$157137))));
                    
                    //#line 328 "x10/regionarray/PolyScanner.x10"
                    if (!(t$157138)) {
                        
                        //#line 328 "x10/regionarray/PolyScanner.x10"
                        break;
                    }
                    
                    //#line 329 "x10/regionarray/PolyScanner.x10"
                    final x10.regionarray.Array this$157105 = ((x10.regionarray.Array)(this.maxSum));
                    
                    //#line 329 "x10/regionarray/PolyScanner.x10"
                    final long i$157107 = ((long)(((int)(k))));
                    
                    //#line 442 . "x10/regionarray/Array.x10"
                    x10.regionarray.VarMat ret$157108 =  null;
                    
                    //#line 446 . "x10/regionarray/Array.x10"
                    final x10.core.Rail t$157101 = ((x10.core.Rail)(((x10.regionarray.Array<x10.regionarray.VarMat>)this$157105).raw));
                    
                    //#line 446 . "x10/regionarray/Array.x10"
                    final x10.regionarray.VarMat t$157102 = ((x10.regionarray.VarMat[])t$157101.value)[(int)i$157107];
                    
                    //#line 446 . "x10/regionarray/Array.x10"
                    ret$157108 = t$157102;
                    
                    //#line 329 "x10/regionarray/PolyScanner.x10"
                    final x10.regionarray.VarRow t$157111 = ((x10.regionarray.Mat<x10.regionarray.VarRow>)ret$157108).$apply$G((int)(l$157152));
                    
                    //#line 329 "x10/regionarray/PolyScanner.x10"
                    final int t$157113 = t$157111.$apply$O((int)(m$157128));
                    
                    //#line 329 "x10/regionarray/PolyScanner.x10"
                    final java.lang.String t$157114 = ((" ") + ((x10.core.Int.$box(t$157113))));
                    
                    //#line 329 "x10/regionarray/PolyScanner.x10"
                    ps.print(((java.lang.String)(t$157114)));
                    
                    //#line 328 "x10/regionarray/PolyScanner.x10"
                    final int t$157116 = ((m$157128) + (((int)(1))));
                    
                    //#line 328 "x10/regionarray/PolyScanner.x10"
                    m$157128 = t$157116;
                }
                
                //#line 330 "x10/regionarray/PolyScanner.x10"
                ps.println();
                
                //#line 323 "x10/regionarray/PolyScanner.x10"
                final int t$157142 = ((l$157152) + (((int)(1))));
                
                //#line 323 "x10/regionarray/PolyScanner.x10"
                l$157152 = t$157142;
            }
            
            //#line 310 "x10/regionarray/PolyScanner.x10"
            final int t$157164 = ((k) + (((int)(1))));
            
            //#line 310 "x10/regionarray/PolyScanner.x10"
            k = t$157164;
        }
    }
    
    
    //#line 68 "x10/regionarray/PolyScanner.x10"
    final public x10.regionarray.PolyScanner x10$regionarray$PolyScanner$$this$x10$regionarray$PolyScanner() {
        
        //#line 68 "x10/regionarray/PolyScanner.x10"
        return x10.regionarray.PolyScanner.this;
    }
    
    
    //#line 68 "x10/regionarray/PolyScanner.x10"
    final public void __fieldInitializers_x10_regionarray_PolyScanner() {
        
    }
    
    
    //#line 289 "x10/regionarray/PolyScanner.x10"
    @x10.runtime.impl.java.X10Generated
    final public static class Anonymous$10018 extends x10.core.Ref implements x10.lang.Iterator, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<Anonymous$10018> $RTT = 
            x10.rtt.NamedType.<Anonymous$10018> make("x10.regionarray.PolyScanner.Anonymous$10018",
                                                     Anonymous$10018.class,
                                                     new x10.rtt.Type[] {
                                                         x10.rtt.ParameterizedType.make(x10.lang.Iterator.$RTT, x10.lang.Point.$RTT)
                                                     });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static x10.serialization.X10JavaSerializable $_deserialize_body(x10.regionarray.PolyScanner.Anonymous$10018 $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            $_obj.it = $deserializer.readObject();
            $_obj.out$ = $deserializer.readObject();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.regionarray.PolyScanner.Anonymous$10018 $_obj = new x10.regionarray.PolyScanner.Anonymous$10018((java.lang.System[]) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            $serializer.write(this.it);
            $serializer.write(this.out$);
            
        }
        
        // constructor just for allocation
        public Anonymous$10018(final java.lang.System[] $dummy) {
            
        }
        
        // bridge for method abstract public x10.lang.Iterator[T].next(){}:T
        final public x10.lang.Point next$G() {
            return next();
        }
        
        
    
        
        //#line 68 "x10/regionarray/PolyScanner.x10"
        public x10.regionarray.PolyScanner out$;
        
        //#line 290 "x10/regionarray/PolyScanner.x10"
        public x10.regionarray.PolyScanner.RailIt it;
        
        
        //#line 291 "x10/regionarray/PolyScanner.x10"
        final public boolean hasNext$O() {
            
            //#line 291 "x10/regionarray/PolyScanner.x10"
            final x10.regionarray.PolyScanner.RailIt this$156060 = ((x10.regionarray.PolyScanner.RailIt)(this.it));
            
            //#line 254 . "x10/regionarray/PolyScanner.x10"
            final boolean t$156581 = this$156060.doesHaveNext;
            
            //#line 291 "x10/regionarray/PolyScanner.x10"
            return t$156581;
        }
        
        
        //#line 292 "x10/regionarray/PolyScanner.x10"
        final public x10.lang.Point next() {
            
            //#line 293 "x10/regionarray/PolyScanner.x10"
            final x10.regionarray.PolyScanner.RailIt t$156582 = ((x10.regionarray.PolyScanner.RailIt)(this.it));
            
            //#line 293 "x10/regionarray/PolyScanner.x10"
            final x10.core.Rail t = t$156582.next();
            
            //#line 294 "x10/regionarray/PolyScanner.x10"
            final long t$156587 = ((x10.core.Rail<x10.core.Int>)t).size;
            
            //#line 294 "x10/regionarray/PolyScanner.x10"
            final x10.core.fun.Fun_0_1 t$156588 = ((x10.core.fun.Fun_0_1)(new x10.regionarray.PolyScanner.Anonymous$10018.$Closure$260(t, (x10.regionarray.PolyScanner.Anonymous$10018.$Closure$260.__0$1x10$lang$Int$2) null)));
            
            //#line 294 "x10/regionarray/PolyScanner.x10"
            final x10.core.Rail t$156589 = ((x10.core.Rail)(new x10.core.Rail<x10.core.Long>(x10.rtt.Types.LONG, ((long)(t$156587)), ((x10.core.fun.Fun_0_1)(t$156588)), (x10.core.Rail.__1$1x10$lang$Long$3x10$lang$Rail$$T$2) null)));
            
            //#line 294 "x10/regionarray/PolyScanner.x10"
            final x10.lang.Point t$156590 = ((x10.lang.Point)(x10.lang.Point.make__0$1x10$lang$Long$2(((x10.core.Rail)(t$156589)))));
            
            //#line 294 "x10/regionarray/PolyScanner.x10"
            final x10.lang.Point t$155015 = ((x10.lang.Point)
                                              t$156590);
            
            //#line 294 "x10/regionarray/PolyScanner.x10"
            final long t$156592 = t$155015.rank;
            
            //#line 294 "x10/regionarray/PolyScanner.x10"
            final x10.regionarray.PolyScanner t$156591 = this.out$;
            
            //#line 294 "x10/regionarray/PolyScanner.x10"
            final long t$156593 = t$156591.rank;
            
            //#line 294 "x10/regionarray/PolyScanner.x10"
            final boolean t$156594 = ((long) t$156592) == ((long) t$156593);
            
            //#line 294 "x10/regionarray/PolyScanner.x10"
            final boolean t$156596 = !(t$156594);
            
            //#line 294 "x10/regionarray/PolyScanner.x10"
            if (t$156596) {
                
                //#line 294 "x10/regionarray/PolyScanner.x10"
                final x10.lang.FailedDynamicCheckException t$156595 = new x10.lang.FailedDynamicCheckException("x10.lang.Point{self.rank==x10.regionarray.PolyScanner.this(:<anonymous class>).rank}");
                
                //#line 294 "x10/regionarray/PolyScanner.x10"
                throw t$156595;
            }
            
            //#line 294 "x10/regionarray/PolyScanner.x10"
            return t$155015;
        }
        
        
        //#line 289 "x10/regionarray/PolyScanner.x10"
        // creation method for java code (1-phase java constructor)
        public Anonymous$10018(final x10.regionarray.PolyScanner out$) {
            this((java.lang.System[]) null);
            x10$regionarray$PolyScanner$Anonymous$10018$$init$S(out$);
        }
        
        // constructor for non-virtual call
        final public x10.regionarray.PolyScanner.Anonymous$10018 x10$regionarray$PolyScanner$Anonymous$10018$$init$S(final x10.regionarray.PolyScanner out$) {
             {
                
                //#line 68 "x10/regionarray/PolyScanner.x10"
                this.out$ = out$;
                
                //#line 290 "x10/regionarray/PolyScanner.x10"
                final x10.regionarray.PolyScanner.RailIt alloc$155150 = ((x10.regionarray.PolyScanner.RailIt)(new x10.regionarray.PolyScanner.RailIt((java.lang.System[]) null)));
                
                //#line 290 "x10/regionarray/PolyScanner.x10"
                final x10.regionarray.PolyScanner t$157165 = this.out$;
                
                //#line 290 "x10/regionarray/PolyScanner.x10"
                alloc$155150.x10$regionarray$PolyScanner$RailIt$$init$S(t$157165);
                
                //#line 290 "x10/regionarray/PolyScanner.x10"
                this.it = ((x10.regionarray.PolyScanner.RailIt)(alloc$155150));
            }
            return this;
        }
        
        
        @x10.runtime.impl.java.X10Generated
        final public static class $Closure$260 extends x10.core.Ref implements x10.core.fun.Fun_0_1, x10.serialization.X10JavaSerializable
        {
            public static final x10.rtt.RuntimeType<$Closure$260> $RTT = 
                x10.rtt.StaticFunType.<$Closure$260> make($Closure$260.class,
                                                          new x10.rtt.Type[] {
                                                              x10.rtt.ParameterizedType.make(x10.core.fun.Fun_0_1.$RTT, x10.rtt.Types.LONG, x10.rtt.Types.LONG)
                                                          });
            
            public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
            
            public x10.rtt.Type<?> $getParam(int i) { return null; }
            
            private Object writeReplace() throws java.io.ObjectStreamException {
                return new x10.serialization.SerializationProxy(this);
            }
            
            public static x10.serialization.X10JavaSerializable $_deserialize_body(x10.regionarray.PolyScanner.Anonymous$10018.$Closure$260 $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
                $_obj.t = $deserializer.readObject();
                return $_obj;
            }
            
            public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
                x10.regionarray.PolyScanner.Anonymous$10018.$Closure$260 $_obj = new x10.regionarray.PolyScanner.Anonymous$10018.$Closure$260((java.lang.System[]) null);
                $deserializer.record_reference($_obj);
                return $_deserialize_body($_obj, $deserializer);
            }
            
            public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
                $serializer.write(this.t);
                
            }
            
            // constructor just for allocation
            public $Closure$260(final java.lang.System[] $dummy) {
                
            }
            
            // dispatcher for method abstract public (Z1)=>U.operator()(a1:Z1):U
            public java.lang.Object $apply(final java.lang.Object a1, final x10.rtt.Type t1) {
                return x10.core.Long.$box($apply$O(x10.core.Long.$unbox(a1)));
                
            }
            
            // dispatcher for method abstract public (Z1)=>U.operator()(a1:Z1):U
            public long $apply$J(final java.lang.Object a1, final x10.rtt.Type t1) {
                return $apply$O(x10.core.Long.$unbox(a1));
                
            }
            
            // synthetic type for parameter mangling
            public static final class __0$1x10$lang$Int$2 {}
            
        
            
            public long $apply$O(final long i) {
                
                //#line 294 "x10/regionarray/PolyScanner.x10"
                final int t$156583 = ((int)(long)(((long)(i))));
                
                //#line 294 "x10/regionarray/PolyScanner.x10"
                final long t$156584 = ((long)(((int)(t$156583))));
                
                //#line 294 "x10/regionarray/PolyScanner.x10"
                final int t$156585 = ((int[])this.t.value)[(int)t$156584];
                
                //#line 294 "x10/regionarray/PolyScanner.x10"
                final long t$156586 = ((long)(((int)(t$156585))));
                
                //#line 294 "x10/regionarray/PolyScanner.x10"
                return t$156586;
            }
            
            public x10.core.Rail<x10.core.Int> t;
            
            public $Closure$260(final x10.core.Rail<x10.core.Int> t, __0$1x10$lang$Int$2 $dummy) {
                 {
                    this.t = ((x10.core.Rail)(t));
                }
            }
            
        }
        
    }
    
}

