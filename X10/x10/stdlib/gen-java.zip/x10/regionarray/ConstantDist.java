package x10.regionarray;


/**
 * This class is an optimized implementation for a
 * distribution that maps all points in its region
 * to a single place.<p>
 */
@x10.runtime.impl.java.X10Generated
final public class ConstantDist extends x10.regionarray.Dist implements x10.serialization.X10JavaSerializable
{
    public static final x10.rtt.RuntimeType<ConstantDist> $RTT = 
        x10.rtt.NamedType.<ConstantDist> make("x10.regionarray.ConstantDist",
                                              ConstantDist.class,
                                              new x10.rtt.Type[] {
                                                  x10.regionarray.Dist.$RTT
                                              });
    
    public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
    
    public x10.rtt.Type<?> $getParam(int i) { return null; }
    
    private Object writeReplace() throws java.io.ObjectStreamException {
        return new x10.serialization.SerializationProxy(this);
    }
    
    public static x10.serialization.X10JavaSerializable $_deserialize_body(x10.regionarray.ConstantDist $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
        x10.regionarray.Dist.$_deserialize_body($_obj, $deserializer);
        $_obj.onePlace = $deserializer.readObject();
        return $_obj;
    }
    
    public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
        x10.regionarray.ConstantDist $_obj = new x10.regionarray.ConstantDist((java.lang.System[]) null);
        $deserializer.record_reference($_obj);
        return $_deserialize_body($_obj, $deserializer);
    }
    
    public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
        super.$_serialize($serializer);
        $serializer.write(this.onePlace);
        
    }
    
    // constructor just for allocation
    public ConstantDist(final java.lang.System[] $dummy) {
        super($dummy);
        
    }
    
    
    // properties
    
    //#line 22 "x10/regionarray/ConstantDist.x10"
    public x10.lang.Place onePlace;
    

    
    
    //#line 27 "x10/regionarray/ConstantDist.x10"
    /**
     * Create a distribution that maps every point in r to p
     */
    // creation method for java code (1-phase java constructor)
    public ConstantDist(final x10.regionarray.Region r, final x10.lang.Place p) {
        this((java.lang.System[]) null);
        x10$regionarray$ConstantDist$$init$S(r, p);
    }
    
    // constructor for non-virtual call
    final public x10.regionarray.ConstantDist x10$regionarray$ConstantDist$$init$S(final x10.regionarray.Region r, final x10.lang.Place p) {
         {
            
            //#line 28 "x10/regionarray/ConstantDist.x10"
            final x10.regionarray.Dist this$149228 = ((x10.regionarray.Dist)(this));
            
            //#line 548 . "x10/regionarray/Dist.x10"
            this$149228.region = r;
            
            //#line 29 "x10/regionarray/ConstantDist.x10"
            this.onePlace = p;
            
        }
        return this;
    }
    
    
    
    //#line 32 "x10/regionarray/ConstantDist.x10"
    public x10.lang.PlaceGroup places() {
        
        //#line 32 "x10/regionarray/ConstantDist.x10"
        final x10.lang.SparsePlaceGroup alloc$149224 = ((x10.lang.SparsePlaceGroup)(new x10.lang.SparsePlaceGroup((java.lang.System[]) null)));
        
        //#line 32 "x10/regionarray/ConstantDist.x10"
        final x10.lang.Place t$149295 = ((x10.lang.Place)(this.onePlace));
        
        //#line 32 "x10/regionarray/ConstantDist.x10"
        alloc$149224.x10$lang$SparsePlaceGroup$$init$S(((x10.lang.Place)(t$149295)));
        
        //#line 32 "x10/regionarray/ConstantDist.x10"
        return alloc$149224;
    }
    
    
    //#line 34 "x10/regionarray/ConstantDist.x10"
    public long numPlaces$O() {
        
        //#line 34 "x10/regionarray/ConstantDist.x10"
        return 1L;
    }
    
    
    //#line 36 "x10/regionarray/ConstantDist.x10"
    public x10.lang.Iterable regions() {
        
        //#line 37 "x10/regionarray/ConstantDist.x10"
        final x10.regionarray.Region t$149250 = ((x10.regionarray.Region)(this.region));
        
        //#line 37 "x10/regionarray/ConstantDist.x10"
        final x10.core.Rail t$149251 = ((x10.core.Rail)(new x10.core.Rail<x10.regionarray.Region>(x10.regionarray.Region.$RTT, ((long)(1L)), ((x10.regionarray.Region)(t$149250)), (x10.core.Rail.__1x10$lang$Rail$$T) null)));
        
        //#line 37 "x10/regionarray/ConstantDist.x10"
        return t$149251;
    }
    
    
    //#line 40 "x10/regionarray/ConstantDist.x10"
    public x10.regionarray.Region get(final x10.lang.Place p) {
        
        //#line 41 "x10/regionarray/ConstantDist.x10"
        final x10.lang.Place t$149252 = ((x10.lang.Place)(this.onePlace));
        
        //#line 41 "x10/regionarray/ConstantDist.x10"
        final boolean t$149256 = x10.rtt.Equality.equalsequals((p),(t$149252));
        
        //#line 41 "x10/regionarray/ConstantDist.x10"
        if (t$149256) {
            
            //#line 42 "x10/regionarray/ConstantDist.x10"
            final x10.regionarray.Region t$149253 = ((x10.regionarray.Region)(this.region));
            
            //#line 42 "x10/regionarray/ConstantDist.x10"
            return t$149253;
        } else {
            
            //#line 44 "x10/regionarray/ConstantDist.x10"
            final x10.regionarray.Dist this$149233 = ((x10.regionarray.Dist)
                                                       this);
            
            //#line 38 . "x10/regionarray/Dist.x10"
            final x10.regionarray.Region t$149254 = ((x10.regionarray.Region)(this$149233.region));
            
            //#line 44 "x10/regionarray/ConstantDist.x10"
            final long rank$149235 = t$149254.rank;
            
            //#line 60 . "x10/regionarray/Region.x10"
            final x10.regionarray.EmptyRegion alloc$149236 = ((x10.regionarray.EmptyRegion)(new x10.regionarray.EmptyRegion((java.lang.System[]) null)));
            
            //#line 60 . "x10/regionarray/Region.x10"
            alloc$149236.x10$regionarray$EmptyRegion$$init$S(((long)(rank$149235)));
            
            //#line 60 . "x10/regionarray/Region.x10"
            final x10.regionarray.Region t$149255 = ((x10.regionarray.Region)(((x10.regionarray.Region)
                                                                                alloc$149236)));
            
            //#line 44 "x10/regionarray/ConstantDist.x10"
            return t$149255;
        }
    }
    
    
    //#line 49 "x10/regionarray/ConstantDist.x10"
    public x10.regionarray.Region $apply(final x10.lang.Place p) {
        
        //#line 49 "x10/regionarray/ConstantDist.x10"
        final x10.regionarray.Region t$149257 = ((x10.regionarray.Region)(this.get(((x10.lang.Place)(p)))));
        
        //#line 49 "x10/regionarray/ConstantDist.x10"
        return t$149257;
    }
    
    
    //#line 51 "x10/regionarray/ConstantDist.x10"
    public x10.lang.Place $apply(final x10.lang.Point pt) {
        
        //#line 52 "x10/regionarray/ConstantDist.x10"
        final x10.regionarray.Region t$149258 = ((x10.regionarray.Region)(this.region));
        
        //#line 52 "x10/regionarray/ConstantDist.x10"
        final boolean t$149259 = t$149258.contains$O(((x10.lang.Point)(pt)));
        
        //#line 52 "x10/regionarray/ConstantDist.x10"
        final boolean t$149260 = !(t$149259);
        
        //#line 52 "x10/regionarray/ConstantDist.x10"
        if (t$149260) {
            
            //#line 52 "x10/regionarray/ConstantDist.x10"
            x10.regionarray.Dist.raiseBoundsError(((x10.lang.Point)(pt)));
        }
        
        //#line 53 "x10/regionarray/ConstantDist.x10"
        final x10.lang.Place t$149261 = ((x10.lang.Place)(this.onePlace));
        
        //#line 53 "x10/regionarray/ConstantDist.x10"
        return t$149261;
    }
    
    
    //#line 56 "x10/regionarray/ConstantDist.x10"
    public x10.lang.Place $apply(final long i0) {
        
        //#line 57 "x10/regionarray/ConstantDist.x10"
        final x10.regionarray.Region t$149264 = ((x10.regionarray.Region)(this.region));
        
        //#line 57 "x10/regionarray/ConstantDist.x10"
        final boolean t$149265 = t$149264.contains$O((long)(i0));
        
        //#line 57 "x10/regionarray/ConstantDist.x10"
        final boolean t$149266 = !(t$149265);
        
        //#line 57 "x10/regionarray/ConstantDist.x10"
        if (t$149266) {
            
            //#line 57 "x10/regionarray/ConstantDist.x10"
            x10.regionarray.Dist.raiseBoundsError((long)(i0));
        }
        
        //#line 58 "x10/regionarray/ConstantDist.x10"
        final x10.lang.Place t$149267 = ((x10.lang.Place)(this.onePlace));
        
        //#line 58 "x10/regionarray/ConstantDist.x10"
        return t$149267;
    }
    
    
    //#line 61 "x10/regionarray/ConstantDist.x10"
    public x10.lang.Place $apply(final long i0, final long i1) {
        
        //#line 62 "x10/regionarray/ConstantDist.x10"
        final x10.regionarray.Region t$149270 = ((x10.regionarray.Region)(this.region));
        
        //#line 62 "x10/regionarray/ConstantDist.x10"
        final boolean t$149271 = t$149270.contains$O((long)(i0), (long)(i1));
        
        //#line 62 "x10/regionarray/ConstantDist.x10"
        final boolean t$149272 = !(t$149271);
        
        //#line 62 "x10/regionarray/ConstantDist.x10"
        if (t$149272) {
            
            //#line 62 "x10/regionarray/ConstantDist.x10"
            x10.regionarray.Dist.raiseBoundsError((long)(i0), (long)(i1));
        }
        
        //#line 63 "x10/regionarray/ConstantDist.x10"
        final x10.lang.Place t$149273 = ((x10.lang.Place)(this.onePlace));
        
        //#line 63 "x10/regionarray/ConstantDist.x10"
        return t$149273;
    }
    
    
    //#line 66 "x10/regionarray/ConstantDist.x10"
    public x10.lang.Place $apply(final long i0, final long i1, final long i2) {
        
        //#line 67 "x10/regionarray/ConstantDist.x10"
        final x10.regionarray.Region t$149276 = ((x10.regionarray.Region)(this.region));
        
        //#line 67 "x10/regionarray/ConstantDist.x10"
        final boolean t$149277 = t$149276.contains$O((long)(i0), (long)(i1), (long)(i2));
        
        //#line 67 "x10/regionarray/ConstantDist.x10"
        final boolean t$149278 = !(t$149277);
        
        //#line 67 "x10/regionarray/ConstantDist.x10"
        if (t$149278) {
            
            //#line 67 "x10/regionarray/ConstantDist.x10"
            x10.regionarray.Dist.raiseBoundsError((long)(i0), (long)(i1), (long)(i2));
        }
        
        //#line 68 "x10/regionarray/ConstantDist.x10"
        final x10.lang.Place t$149279 = ((x10.lang.Place)(this.onePlace));
        
        //#line 68 "x10/regionarray/ConstantDist.x10"
        return t$149279;
    }
    
    
    //#line 71 "x10/regionarray/ConstantDist.x10"
    public x10.lang.Place $apply(final long i0, final long i1, final long i2, final long i3) {
        
        //#line 72 "x10/regionarray/ConstantDist.x10"
        final x10.regionarray.Region t$149282 = ((x10.regionarray.Region)(this.region));
        
        //#line 72 "x10/regionarray/ConstantDist.x10"
        final boolean t$149283 = t$149282.contains$O((long)(i0), (long)(i1), (long)(i2), (long)(i3));
        
        //#line 72 "x10/regionarray/ConstantDist.x10"
        final boolean t$149284 = !(t$149283);
        
        //#line 72 "x10/regionarray/ConstantDist.x10"
        if (t$149284) {
            
            //#line 72 "x10/regionarray/ConstantDist.x10"
            x10.regionarray.Dist.raiseBoundsError((long)(i0), (long)(i1), (long)(i2), (long)(i3));
        }
        
        //#line 73 "x10/regionarray/ConstantDist.x10"
        final x10.lang.Place t$149285 = ((x10.lang.Place)(this.onePlace));
        
        //#line 73 "x10/regionarray/ConstantDist.x10"
        return t$149285;
    }
    
    
    //#line 76 "x10/regionarray/ConstantDist.x10"
    public x10.regionarray.Dist restriction(final x10.regionarray.Region r) {
        
        //#line 77 "x10/regionarray/ConstantDist.x10"
        final x10.regionarray.WrappedDistRegionRestricted alloc$149225 = ((x10.regionarray.WrappedDistRegionRestricted)(new x10.regionarray.WrappedDistRegionRestricted((java.lang.System[]) null)));
        
        //#line 77 "x10/regionarray/ConstantDist.x10"
        alloc$149225.x10$regionarray$WrappedDistRegionRestricted$$init$S(((x10.regionarray.Dist)(this)), ((x10.regionarray.Region)(r)));
        
        //#line 77 "x10/regionarray/ConstantDist.x10"
        return alloc$149225;
    }
    
    
    //#line 80 "x10/regionarray/ConstantDist.x10"
    public x10.regionarray.Dist restriction(final x10.lang.Place p) {
        
        //#line 81 "x10/regionarray/ConstantDist.x10"
        final x10.regionarray.WrappedDistPlaceRestricted alloc$149226 = ((x10.regionarray.WrappedDistPlaceRestricted)(new x10.regionarray.WrappedDistPlaceRestricted((java.lang.System[]) null)));
        
        //#line 81 "x10/regionarray/ConstantDist.x10"
        alloc$149226.x10$regionarray$WrappedDistPlaceRestricted$$init$S(((x10.regionarray.Dist)(this)), ((x10.lang.Place)(p)));
        
        //#line 81 "x10/regionarray/ConstantDist.x10"
        return alloc$149226;
    }
    
    
    //#line 84 "x10/regionarray/ConstantDist.x10"
    public boolean equals(final java.lang.Object thatObj) {
        
        //#line 85 "x10/regionarray/ConstantDist.x10"
        final boolean t$149286 = x10.regionarray.ConstantDist.$RTT.isInstance(thatObj);
        
        //#line 85 "x10/regionarray/ConstantDist.x10"
        final boolean t$149287 = !(t$149286);
        
        //#line 85 "x10/regionarray/ConstantDist.x10"
        if (t$149287) {
            
            //#line 85 "x10/regionarray/ConstantDist.x10"
            return false;
        }
        
        //#line 86 "x10/regionarray/ConstantDist.x10"
        final x10.regionarray.ConstantDist that = ((x10.regionarray.ConstantDist)(x10.rtt.Types.<x10.regionarray.ConstantDist> cast(thatObj,x10.regionarray.ConstantDist.$RTT)));
        
        //#line 87 "x10/regionarray/ConstantDist.x10"
        final x10.lang.Place this$149247 = ((x10.lang.Place)(this.onePlace));
        
        //#line 87 "x10/regionarray/ConstantDist.x10"
        final x10.lang.Place p$149246 = ((x10.lang.Place)(that.onePlace));
        
        //#line 139 . "x10/lang/Place.x10"
        final long t$149288 = p$149246.id;
        
        //#line 139 . "x10/lang/Place.x10"
        final long t$149289 = this$149247.id;
        
        //#line 87 "x10/regionarray/ConstantDist.x10"
        boolean t$149292 = ((long) t$149288) == ((long) t$149289);
        
        //#line 87 "x10/regionarray/ConstantDist.x10"
        if (t$149292) {
            
            //#line 87 "x10/regionarray/ConstantDist.x10"
            final x10.regionarray.Region t$149290 = ((x10.regionarray.Region)(this.region));
            
            //#line 87 "x10/regionarray/ConstantDist.x10"
            final x10.regionarray.Region t$149291 = ((x10.regionarray.Region)(that.region));
            
            //#line 87 "x10/regionarray/ConstantDist.x10"
            t$149292 = t$149290.equals(((java.lang.Object)(t$149291)));
        }
        
        //#line 87 "x10/regionarray/ConstantDist.x10"
        return t$149292;
    }
    
    
    //#line 22 "x10/regionarray/ConstantDist.x10"
    final public x10.regionarray.ConstantDist x10$regionarray$ConstantDist$$this$x10$regionarray$ConstantDist() {
        
        //#line 22 "x10/regionarray/ConstantDist.x10"
        return x10.regionarray.ConstantDist.this;
    }
    
    
    //#line 22 "x10/regionarray/ConstantDist.x10"
    final public void __fieldInitializers_x10_regionarray_ConstantDist() {
        
    }
}

