package x10.regionarray;


@x10.runtime.impl.java.X10Generated
public class MatBuilder extends x10.core.Ref implements x10.serialization.X10JavaSerializable
{
    public static final x10.rtt.RuntimeType<MatBuilder> $RTT = 
        x10.rtt.NamedType.<MatBuilder> make("x10.regionarray.MatBuilder",
                                            MatBuilder.class);
    
    public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
    
    public x10.rtt.Type<?> $getParam(int i) { return null; }
    
    private Object writeReplace() throws java.io.ObjectStreamException {
        return new x10.serialization.SerializationProxy(this);
    }
    
    public static x10.serialization.X10JavaSerializable $_deserialize_body(x10.regionarray.MatBuilder $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
        $_obj.cols = $deserializer.readInt();
        $_obj.mat = $deserializer.readObject();
        return $_obj;
    }
    
    public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
        x10.regionarray.MatBuilder $_obj = new x10.regionarray.MatBuilder((java.lang.System[]) null);
        $deserializer.record_reference($_obj);
        return $_deserialize_body($_obj, $deserializer);
    }
    
    public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
        $serializer.write(this.cols);
        $serializer.write(this.mat);
        
    }
    
    // constructor just for allocation
    public MatBuilder(final java.lang.System[] $dummy) {
        
    }
    
    

    
    //#line 18 "x10/regionarray/MatBuilder.x10"
    public x10.util.ArrayList<x10.regionarray.Row> mat;
    
    //#line 19 "x10/regionarray/MatBuilder.x10"
    public int cols;
    
    
    //#line 21 "x10/regionarray/MatBuilder.x10"
    // creation method for java code (1-phase java constructor)
    public MatBuilder(final int cols) {
        this((java.lang.System[]) null);
        x10$regionarray$MatBuilder$$init$S(cols);
    }
    
    // constructor for non-virtual call
    final public x10.regionarray.MatBuilder x10$regionarray$MatBuilder$$init$S(final int cols) {
         {
            
            //#line 21 "x10/regionarray/MatBuilder.x10"
            
            
            //#line 22 "x10/regionarray/MatBuilder.x10"
            this.cols = cols;
            
            //#line 23 "x10/regionarray/MatBuilder.x10"
            final x10.util.ArrayList alloc$152223 = ((x10.util.ArrayList)(new x10.util.ArrayList<x10.regionarray.Row>((java.lang.System[]) null, x10.regionarray.Row.$RTT)));
            
            //#line 23 "x10/regionarray/MatBuilder.x10"
            alloc$152223.x10$util$ArrayList$$init$S();
            
            //#line 23 "x10/regionarray/MatBuilder.x10"
            this.mat = ((x10.util.ArrayList)(alloc$152223));
        }
        return this;
    }
    
    
    
    //#line 26 "x10/regionarray/MatBuilder.x10"
    // creation method for java code (1-phase java constructor)
    public MatBuilder(final int rows, final int cols) {
        this((java.lang.System[]) null);
        x10$regionarray$MatBuilder$$init$S(rows, cols);
    }
    
    // constructor for non-virtual call
    final public x10.regionarray.MatBuilder x10$regionarray$MatBuilder$$init$S(final int rows, final int cols) {
         {
            
            //#line 26 "x10/regionarray/MatBuilder.x10"
            
            
            //#line 27 "x10/regionarray/MatBuilder.x10"
            this.cols = cols;
            
            //#line 28 "x10/regionarray/MatBuilder.x10"
            final x10.util.ArrayList m = ((x10.util.ArrayList)(new x10.util.ArrayList<x10.regionarray.Row>((java.lang.System[]) null, x10.regionarray.Row.$RTT)));
            
            //#line 28 "x10/regionarray/MatBuilder.x10"
            final long t$152290 = ((long)(((int)(rows))));
            
            //#line 28 "x10/regionarray/MatBuilder.x10"
            m.x10$util$ArrayList$$init$S(t$152290);
            
            //#line 29 "x10/regionarray/MatBuilder.x10"
            this.mat = ((x10.util.ArrayList)(m));
            
            //#line 30 "x10/regionarray/MatBuilder.x10"
            x10.regionarray.MatBuilder.need__1$1x10$regionarray$Row$2((int)(rows), ((x10.util.ArrayList)(m)), (int)(cols));
        }
        return this;
    }
    
    
    
    //#line 33 "x10/regionarray/MatBuilder.x10"
    public void add(final x10.regionarray.Row row) {
        
        //#line 34 "x10/regionarray/MatBuilder.x10"
        final x10.util.ArrayList t$152231 = ((x10.util.ArrayList)(this.mat));
        
        //#line 34 "x10/regionarray/MatBuilder.x10"
        ((x10.util.ArrayList<x10.regionarray.Row>)t$152231).add__0x10$util$ArrayList$$T$O(((x10.regionarray.Row)(row)));
    }
    
    
    //#line 37 "x10/regionarray/MatBuilder.x10"
    public void add__0$1x10$lang$Int$3x10$lang$Int$2(final x10.core.fun.Fun_0_1 a) {
        
        //#line 38 "x10/regionarray/MatBuilder.x10"
        final x10.util.ArrayList t$152233 = ((x10.util.ArrayList)(this.mat));
        
        //#line 38 "x10/regionarray/MatBuilder.x10"
        final x10.regionarray.VarRow alloc$152224 = ((x10.regionarray.VarRow)(new x10.regionarray.VarRow((java.lang.System[]) null)));
        
        //#line 38 "x10/regionarray/MatBuilder.x10"
        final int t$152291 = this.cols;
        
        //#line 38 "x10/regionarray/MatBuilder.x10"
        alloc$152224.x10$regionarray$VarRow$$init$S(((int)(t$152291)), ((x10.core.fun.Fun_0_1)(a)), (x10.regionarray.VarRow.__1$1x10$lang$Int$3x10$lang$Int$2) null);
        
        //#line 38 "x10/regionarray/MatBuilder.x10"
        ((x10.util.ArrayList<x10.regionarray.Row>)t$152233).add__0x10$util$ArrayList$$T$O(((x10.regionarray.Row)(alloc$152224)));
    }
    
    
    //#line 41 "x10/regionarray/MatBuilder.x10"
    public int $apply$O(final int i, final int j) {
        
        //#line 41 "x10/regionarray/MatBuilder.x10"
        final x10.util.ArrayList t$152234 = ((x10.util.ArrayList)(this.mat));
        
        //#line 41 "x10/regionarray/MatBuilder.x10"
        final long t$152235 = ((long)(((int)(i))));
        
        //#line 41 "x10/regionarray/MatBuilder.x10"
        final x10.regionarray.Row t$152236 = ((x10.util.ArrayList<x10.regionarray.Row>)t$152234).$apply$G((long)(t$152235));
        
        //#line 41 "x10/regionarray/MatBuilder.x10"
        final int t$152237 = t$152236.$apply$O((int)(j));
        
        //#line 41 "x10/regionarray/MatBuilder.x10"
        return t$152237;
    }
    
    
    //#line 43 "x10/regionarray/MatBuilder.x10"
    public void $set(final int i, final int j, final int v) {
        
        //#line 44 "x10/regionarray/MatBuilder.x10"
        final int t$152238 = ((i) + (((int)(1))));
        
        //#line 44 "x10/regionarray/MatBuilder.x10"
        this.need((int)(t$152238));
        
        //#line 45 "x10/regionarray/MatBuilder.x10"
        final x10.util.ArrayList t$152239 = ((x10.util.ArrayList)(this.mat));
        
        //#line 45 "x10/regionarray/MatBuilder.x10"
        final long t$152240 = ((long)(((int)(i))));
        
        //#line 45 "x10/regionarray/MatBuilder.x10"
        final x10.regionarray.Row t$152241 = ((x10.util.ArrayList<x10.regionarray.Row>)t$152239).$apply$G((long)(t$152240));
        
        //#line 45 "x10/regionarray/MatBuilder.x10"
        t$152241.$set$O((int)(j), (int)(v));
    }
    
    
    //#line 48 "x10/regionarray/MatBuilder.x10"
    public void setDiagonal__3$1x10$lang$Int$3x10$lang$Int$2(final int i, final int j, final int n, final x10.core.fun.Fun_0_1 v) {
        
        //#line 49 "x10/regionarray/MatBuilder.x10"
        final int t$152242 = ((i) + (((int)(n))));
        
        //#line 49 "x10/regionarray/MatBuilder.x10"
        this.need((int)(t$152242));
        
        //#line 50 "x10/regionarray/MatBuilder.x10"
        int k$152303 = 0;
        
        //#line 50 "x10/regionarray/MatBuilder.x10"
        for (;
             true;
             ) {
            
            //#line 50 "x10/regionarray/MatBuilder.x10"
            final boolean t$152305 = ((k$152303) < (((int)(n))));
            
            //#line 50 "x10/regionarray/MatBuilder.x10"
            if (!(t$152305)) {
                
                //#line 50 "x10/regionarray/MatBuilder.x10"
                break;
            }
            
            //#line 51 "x10/regionarray/MatBuilder.x10"
            final x10.util.ArrayList t$152292 = ((x10.util.ArrayList)(this.mat));
            
            //#line 51 "x10/regionarray/MatBuilder.x10"
            final int t$152294 = ((i) + (((int)(k$152303))));
            
            //#line 51 "x10/regionarray/MatBuilder.x10"
            final long t$152295 = ((long)(((int)(t$152294))));
            
            //#line 51 "x10/regionarray/MatBuilder.x10"
            final x10.regionarray.Row t$152296 = ((x10.util.ArrayList<x10.regionarray.Row>)t$152292).$apply$G((long)(t$152295));
            
            //#line 51 "x10/regionarray/MatBuilder.x10"
            final int t$152298 = ((j) + (((int)(k$152303))));
            
            //#line 51 "x10/regionarray/MatBuilder.x10"
            final int t$152300 = x10.core.Int.$unbox(((x10.core.fun.Fun_0_1<x10.core.Int,x10.core.Int>)v).$apply(x10.core.Int.$box(k$152303), x10.rtt.Types.INT));
            
            //#line 51 "x10/regionarray/MatBuilder.x10"
            t$152296.$set$O((int)(t$152298), (int)(t$152300));
            
            //#line 50 "x10/regionarray/MatBuilder.x10"
            final int t$152302 = ((k$152303) + (((int)(1))));
            
            //#line 50 "x10/regionarray/MatBuilder.x10"
            k$152303 = t$152302;
        }
    }
    
    
    //#line 54 "x10/regionarray/MatBuilder.x10"
    public void setColumn__3$1x10$lang$Int$3x10$lang$Int$2(final int i, final int j, final int n, final x10.core.fun.Fun_0_1 v) {
        
        //#line 55 "x10/regionarray/MatBuilder.x10"
        final int t$152257 = ((i) + (((int)(n))));
        
        //#line 55 "x10/regionarray/MatBuilder.x10"
        this.need((int)(t$152257));
        
        //#line 56 "x10/regionarray/MatBuilder.x10"
        int k$152315 = 0;
        
        //#line 56 "x10/regionarray/MatBuilder.x10"
        for (;
             true;
             ) {
            
            //#line 56 "x10/regionarray/MatBuilder.x10"
            final boolean t$152317 = ((k$152315) < (((int)(n))));
            
            //#line 56 "x10/regionarray/MatBuilder.x10"
            if (!(t$152317)) {
                
                //#line 56 "x10/regionarray/MatBuilder.x10"
                break;
            }
            
            //#line 57 "x10/regionarray/MatBuilder.x10"
            final x10.util.ArrayList t$152306 = ((x10.util.ArrayList)(this.mat));
            
            //#line 57 "x10/regionarray/MatBuilder.x10"
            final int t$152308 = ((i) + (((int)(k$152315))));
            
            //#line 57 "x10/regionarray/MatBuilder.x10"
            final long t$152309 = ((long)(((int)(t$152308))));
            
            //#line 57 "x10/regionarray/MatBuilder.x10"
            final x10.regionarray.Row t$152310 = ((x10.util.ArrayList<x10.regionarray.Row>)t$152306).$apply$G((long)(t$152309));
            
            //#line 57 "x10/regionarray/MatBuilder.x10"
            final int t$152312 = x10.core.Int.$unbox(((x10.core.fun.Fun_0_1<x10.core.Int,x10.core.Int>)v).$apply(x10.core.Int.$box(k$152315), x10.rtt.Types.INT));
            
            //#line 57 "x10/regionarray/MatBuilder.x10"
            t$152310.$set$O((int)(j), (int)(t$152312));
            
            //#line 56 "x10/regionarray/MatBuilder.x10"
            final int t$152314 = ((k$152315) + (((int)(1))));
            
            //#line 56 "x10/regionarray/MatBuilder.x10"
            k$152315 = t$152314;
        }
    }
    
    
    //#line 60 "x10/regionarray/MatBuilder.x10"
    public void setRow__3$1x10$lang$Int$3x10$lang$Int$2(final int i, final int j, final int n, final x10.core.fun.Fun_0_1 v) {
        
        //#line 61 "x10/regionarray/MatBuilder.x10"
        final int t$152270 = ((i) + (((int)(1))));
        
        //#line 61 "x10/regionarray/MatBuilder.x10"
        this.need((int)(t$152270));
        
        //#line 62 "x10/regionarray/MatBuilder.x10"
        int k$152327 = 0;
        
        //#line 62 "x10/regionarray/MatBuilder.x10"
        for (;
             true;
             ) {
            
            //#line 62 "x10/regionarray/MatBuilder.x10"
            final boolean t$152329 = ((k$152327) < (((int)(n))));
            
            //#line 62 "x10/regionarray/MatBuilder.x10"
            if (!(t$152329)) {
                
                //#line 62 "x10/regionarray/MatBuilder.x10"
                break;
            }
            
            //#line 63 "x10/regionarray/MatBuilder.x10"
            final x10.util.ArrayList t$152318 = ((x10.util.ArrayList)(this.mat));
            
            //#line 63 "x10/regionarray/MatBuilder.x10"
            final long t$152319 = ((long)(((int)(i))));
            
            //#line 63 "x10/regionarray/MatBuilder.x10"
            final x10.regionarray.Row t$152320 = ((x10.util.ArrayList<x10.regionarray.Row>)t$152318).$apply$G((long)(t$152319));
            
            //#line 63 "x10/regionarray/MatBuilder.x10"
            final int t$152322 = ((j) + (((int)(k$152327))));
            
            //#line 63 "x10/regionarray/MatBuilder.x10"
            final int t$152324 = x10.core.Int.$unbox(((x10.core.fun.Fun_0_1<x10.core.Int,x10.core.Int>)v).$apply(x10.core.Int.$box(k$152327), x10.rtt.Types.INT));
            
            //#line 63 "x10/regionarray/MatBuilder.x10"
            t$152320.$set$O((int)(t$152322), (int)(t$152324));
            
            //#line 62 "x10/regionarray/MatBuilder.x10"
            final int t$152326 = ((k$152327) + (((int)(1))));
            
            //#line 62 "x10/regionarray/MatBuilder.x10"
            k$152327 = t$152326;
        }
    }
    
    
    //#line 66 "x10/regionarray/MatBuilder.x10"
    private void need(final int n) {
        
        //#line 66 "x10/regionarray/MatBuilder.x10"
        final x10.util.ArrayList t$152283 = ((x10.util.ArrayList)(this.mat));
        
        //#line 66 "x10/regionarray/MatBuilder.x10"
        final int t$152284 = this.cols;
        
        //#line 66 "x10/regionarray/MatBuilder.x10"
        x10.regionarray.MatBuilder.need__1$1x10$regionarray$Row$2((int)(n), ((x10.util.ArrayList)(t$152283)), (int)(t$152284));
    }
    
    public static void need$P(final int n, final x10.regionarray.MatBuilder MatBuilder) {
        MatBuilder.need((int)(n));
    }
    
    
    //#line 67 "x10/regionarray/MatBuilder.x10"
    private static void need__1$1x10$regionarray$Row$2(final int n, final x10.util.ArrayList<x10.regionarray.Row> mat, final int cols) {
        
        //#line 68 "x10/regionarray/MatBuilder.x10"
        while (true) {
            
            //#line 68 "x10/regionarray/MatBuilder.x10"
            final long t$152285 = ((x10.util.ArrayList<x10.regionarray.Row>)mat).size$O();
            
            //#line 68 "x10/regionarray/MatBuilder.x10"
            final long t$152286 = ((long)(((int)(n))));
            
            //#line 68 "x10/regionarray/MatBuilder.x10"
            final boolean t$152287 = ((t$152285) < (((long)(t$152286))));
            
            //#line 68 "x10/regionarray/MatBuilder.x10"
            if (!(t$152287)) {
                
                //#line 68 "x10/regionarray/MatBuilder.x10"
                break;
            }
            
            //#line 69 "x10/regionarray/MatBuilder.x10"
            final x10.regionarray.VarRow alloc$152330 = ((x10.regionarray.VarRow)(new x10.regionarray.VarRow((java.lang.System[]) null)));
            
            //#line 69 "x10/regionarray/MatBuilder.x10"
            alloc$152330.x10$regionarray$VarRow$$init$S(((int)(cols)));
            
            //#line 69 "x10/regionarray/MatBuilder.x10"
            ((x10.util.ArrayList<x10.regionarray.Row>)mat).add__0x10$util$ArrayList$$T$O(((x10.regionarray.Row)(alloc$152330)));
        }
    }
    
    public static void need$P__1$1x10$regionarray$Row$2(final int n, final x10.util.ArrayList<x10.regionarray.Row> mat, final int cols) {
        x10.regionarray.MatBuilder.need__1$1x10$regionarray$Row$2((int)(n), ((x10.util.ArrayList)(mat)), (int)(cols));
    }
    
    
    //#line 16 "x10/regionarray/MatBuilder.x10"
    final public x10.regionarray.MatBuilder x10$regionarray$MatBuilder$$this$x10$regionarray$MatBuilder() {
        
        //#line 16 "x10/regionarray/MatBuilder.x10"
        return x10.regionarray.MatBuilder.this;
    }
    
    
    //#line 16 "x10/regionarray/MatBuilder.x10"
    final public void __fieldInitializers_x10_regionarray_MatBuilder() {
        
    }
}

