package x10.regionarray;

/**
 * A full region is the unbounded region that contains all points of its rank
 */
@x10.runtime.impl.java.X10Generated
final public class FullRegion extends x10.regionarray.Region implements x10.serialization.X10JavaSerializable
{
    public static final x10.rtt.RuntimeType<FullRegion> $RTT = 
        x10.rtt.NamedType.<FullRegion> make("x10.regionarray.FullRegion",
                                            FullRegion.class,
                                            new x10.rtt.Type[] {
                                                x10.regionarray.Region.$RTT
                                            });
    
    public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
    
    public x10.rtt.Type<?> $getParam(int i) { return null; }
    
    private Object writeReplace() throws java.io.ObjectStreamException {
        return new x10.serialization.SerializationProxy(this);
    }
    
    public static x10.serialization.X10JavaSerializable $_deserialize_body(x10.regionarray.FullRegion $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
        x10.regionarray.Region.$_deserialize_body($_obj, $deserializer);
        return $_obj;
    }
    
    public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
        x10.regionarray.FullRegion $_obj = new x10.regionarray.FullRegion((java.lang.System[]) null);
        $deserializer.record_reference($_obj);
        return $_deserialize_body($_obj, $deserializer);
    }
    
    public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
        super.$_serialize($serializer);
        
    }
    
    // constructor just for allocation
    public FullRegion(final java.lang.System[] $dummy) {
        super($dummy);
        
    }
    
    

    
    
    //#line 19 "x10/regionarray/FullRegion.x10"
    // creation method for java code (1-phase java constructor)
    public FullRegion(final long rank) {
        this((java.lang.System[]) null);
        x10$regionarray$FullRegion$$init$S(rank);
    }
    
    // constructor for non-virtual call
    final public x10.regionarray.FullRegion x10$regionarray$FullRegion$$init$S(final long rank) {
         {
            
            //#line 20 "x10/regionarray/FullRegion.x10"
            final x10.regionarray.Region this$151760 = ((x10.regionarray.Region)(this));
            
            //#line 557 . "x10/regionarray/Region.x10"
            boolean t$151844 = ((long) rank) == ((long) 1L);
            
            //#line 557 . "x10/regionarray/Region.x10"
            if (t$151844) {
                
                //#line 557 . "x10/regionarray/Region.x10"
                t$151844 = true;
            }
            
            //#line 557 . "x10/regionarray/Region.x10"
            boolean t$151845 = t$151844;
            
            //#line 557 . "x10/regionarray/Region.x10"
            if (t$151844) {
                
                //#line 557 . "x10/regionarray/Region.x10"
                t$151845 = false;
            }
            
            //#line 558 . "x10/regionarray/Region.x10"
            this$151760.rank = rank;
            
            //#line 558 . "x10/regionarray/Region.x10"
            this$151760.rect = true;
            
            //#line 558 . "x10/regionarray/Region.x10"
            this$151760.zeroBased = false;
            
            //#line 558 . "x10/regionarray/Region.x10"
            this$151760.rail = t$151845;
            
            //#line 19 "x10/regionarray/FullRegion.x10"
            
            
            //#line 21 "x10/regionarray/FullRegion.x10"
            final boolean t$151781 = ((rank) < (((long)(0L))));
            
            //#line 21 "x10/regionarray/FullRegion.x10"
            if (t$151781) {
                
                //#line 21 "x10/regionarray/FullRegion.x10"
                final java.lang.String t$151778 = (("Rank is negative (") + ((x10.core.Long.$box(rank))));
                
                //#line 21 "x10/regionarray/FullRegion.x10"
                final java.lang.String t$151779 = ((t$151778) + (")"));
                
                //#line 21 "x10/regionarray/FullRegion.x10"
                final java.lang.IllegalArgumentException t$151780 = ((java.lang.IllegalArgumentException)(new java.lang.IllegalArgumentException(t$151779)));
                
                //#line 21 "x10/regionarray/FullRegion.x10"
                throw t$151780;
            }
        }
        return this;
    }
    
    
    
    //#line 24 "x10/regionarray/FullRegion.x10"
    public boolean isConvex$O() {
        
        //#line 24 "x10/regionarray/FullRegion.x10"
        return true;
    }
    
    
    //#line 25 "x10/regionarray/FullRegion.x10"
    public boolean isEmpty$O() {
        
        //#line 25 "x10/regionarray/FullRegion.x10"
        return false;
    }
    
    
    //#line 26 "x10/regionarray/FullRegion.x10"
    public long size$O() {
        
        //#line 27 "x10/regionarray/FullRegion.x10"
        final x10.regionarray.UnboundedRegionException t$151782 = ((x10.regionarray.UnboundedRegionException)(new x10.regionarray.UnboundedRegionException(((java.lang.String)("size not supported")))));
        
        //#line 27 "x10/regionarray/FullRegion.x10"
        throw t$151782;
    }
    
    
    //#line 29 "x10/regionarray/FullRegion.x10"
    public long indexOf$O(final x10.lang.Point id$322) {
        
        //#line 30 "x10/regionarray/FullRegion.x10"
        final x10.regionarray.UnboundedRegionException t$151783 = ((x10.regionarray.UnboundedRegionException)(new x10.regionarray.UnboundedRegionException(((java.lang.String)("indexOf not supported")))));
        
        //#line 30 "x10/regionarray/FullRegion.x10"
        throw t$151783;
    }
    
    
    //#line 32 "x10/regionarray/FullRegion.x10"
    public x10.core.fun.Fun_0_1 min() {
        
        //#line 33 "x10/regionarray/FullRegion.x10"
        final x10.core.fun.Fun_0_1 t$151792 = ((x10.core.fun.Fun_0_1)(new x10.regionarray.FullRegion.$Closure$240(this, this.rank)));
        
        //#line 33 "x10/regionarray/FullRegion.x10"
        return t$151792;
    }
    
    
    //#line 38 "x10/regionarray/FullRegion.x10"
    public x10.core.fun.Fun_0_1 max() {
        
        //#line 39 "x10/regionarray/FullRegion.x10"
        final x10.core.fun.Fun_0_1 t$151801 = ((x10.core.fun.Fun_0_1)(new x10.regionarray.FullRegion.$Closure$241(this, this.rank)));
        
        //#line 39 "x10/regionarray/FullRegion.x10"
        return t$151801;
    }
    
    
    //#line 44 "x10/regionarray/FullRegion.x10"
    public x10.regionarray.Region intersection(final x10.regionarray.Region that) {
        
        //#line 44 "x10/regionarray/FullRegion.x10"
        return that;
    }
    
    
    //#line 45 "x10/regionarray/FullRegion.x10"
    public x10.regionarray.Region product(final x10.regionarray.Region that) {
        
        //#line 46 "x10/regionarray/FullRegion.x10"
        final boolean t$151837 = that.isEmpty$O();
        
        //#line 46 "x10/regionarray/FullRegion.x10"
        if (t$151837) {
            
            //#line 47 "x10/regionarray/FullRegion.x10"
            final long t$151802 = this.rank;
            
            //#line 47 "x10/regionarray/FullRegion.x10"
            final long t$151803 = that.rank;
            
            //#line 47 "x10/regionarray/FullRegion.x10"
            final long rank$151765 = ((t$151802) + (((long)(t$151803))));
            
            //#line 60 . "x10/regionarray/Region.x10"
            final x10.regionarray.EmptyRegion alloc$151766 = ((x10.regionarray.EmptyRegion)(new x10.regionarray.EmptyRegion((java.lang.System[]) null)));
            
            //#line 60 . "x10/regionarray/Region.x10"
            alloc$151766.x10$regionarray$EmptyRegion$$init$S(((long)(rank$151765)));
            
            //#line 60 . "x10/regionarray/Region.x10"
            final x10.regionarray.Region t$151804 = ((x10.regionarray.Region)(((x10.regionarray.Region)
                                                                                alloc$151766)));
            
            //#line 47 "x10/regionarray/FullRegion.x10"
            return t$151804;
        } else {
            
            //#line 48 "x10/regionarray/FullRegion.x10"
            final boolean t$151836 = x10.regionarray.FullRegion.$RTT.isInstance(that);
            
            //#line 48 "x10/regionarray/FullRegion.x10"
            if (t$151836) {
                
                //#line 49 "x10/regionarray/FullRegion.x10"
                final x10.regionarray.FullRegion alloc$146579 = ((x10.regionarray.FullRegion)(new x10.regionarray.FullRegion((java.lang.System[]) null)));
                
                //#line 49 "x10/regionarray/FullRegion.x10"
                final long t$151848 = this.rank;
                
                //#line 49 "x10/regionarray/FullRegion.x10"
                final long t$151849 = that.rank;
                
                //#line 49 "x10/regionarray/FullRegion.x10"
                final long t$151850 = ((t$151848) + (((long)(t$151849))));
                
                //#line 49 "x10/regionarray/FullRegion.x10"
                alloc$146579.x10$regionarray$FullRegion$$init$S(t$151850);
                
                //#line 49 "x10/regionarray/FullRegion.x10"
                return alloc$146579;
            } else {
                
                //#line 50 "x10/regionarray/FullRegion.x10"
                final boolean t$151835 = x10.regionarray.RectRegion.$RTT.isInstance(that);
                
                //#line 50 "x10/regionarray/FullRegion.x10"
                if (t$151835) {
                    
                    //#line 51 "x10/regionarray/FullRegion.x10"
                    final x10.regionarray.RectRegion this$151769 = ((x10.regionarray.RectRegion)(x10.rtt.Types.<x10.regionarray.RectRegion> cast(that,x10.regionarray.RectRegion.$RTT)));
                    
                    //#line 223 . "x10/regionarray/RectRegion.x10"
                    x10.core.fun.Fun_0_1 ret$151770 =  null;
                    
                    //#line 223 . "x10/regionarray/RectRegion.x10"
                    final x10.core.fun.Fun_0_1 t$151851 = ((x10.core.fun.Fun_0_1)(new x10.regionarray.FullRegion.$Closure$242(this$151769)));
                    
                    //#line 223 . "x10/regionarray/RectRegion.x10"
                    ret$151770 = ((x10.core.fun.Fun_0_1)(t$151851));
                    
                    //#line 51 "x10/regionarray/FullRegion.x10"
                    final x10.core.fun.Fun_0_1 thatMin = ret$151770;
                    
                    //#line 52 "x10/regionarray/FullRegion.x10"
                    final x10.regionarray.RectRegion this$151773 = ((x10.regionarray.RectRegion)(x10.rtt.Types.<x10.regionarray.RectRegion> cast(that,x10.regionarray.RectRegion.$RTT)));
                    
                    //#line 224 . "x10/regionarray/RectRegion.x10"
                    x10.core.fun.Fun_0_1 ret$151774 =  null;
                    
                    //#line 224 . "x10/regionarray/RectRegion.x10"
                    final x10.core.fun.Fun_0_1 t$151854 = ((x10.core.fun.Fun_0_1)(new x10.regionarray.FullRegion.$Closure$243(this$151773)));
                    
                    //#line 224 . "x10/regionarray/RectRegion.x10"
                    ret$151774 = ((x10.core.fun.Fun_0_1)(t$151854));
                    
                    //#line 52 "x10/regionarray/FullRegion.x10"
                    final x10.core.fun.Fun_0_1 thatMax = ret$151774;
                    
                    //#line 53 "x10/regionarray/FullRegion.x10"
                    final long t$151812 = this.rank;
                    
                    //#line 53 "x10/regionarray/FullRegion.x10"
                    final long t$151813 = that.rank;
                    
                    //#line 53 "x10/regionarray/FullRegion.x10"
                    final long newRank = ((t$151812) + (((long)(t$151813))));
                    
                    //#line 54 "x10/regionarray/FullRegion.x10"
                    final x10.core.fun.Fun_0_1 t$151820 = ((x10.core.fun.Fun_0_1)(new x10.regionarray.FullRegion.$Closure$244(this, this.rank, thatMin, (x10.regionarray.FullRegion.$Closure$244.__2$1x10$lang$Long$3x10$lang$Long$2) null)));
                    
                    //#line 54 "x10/regionarray/FullRegion.x10"
                    final x10.core.Rail newMin = ((x10.core.Rail)(new x10.core.Rail<x10.core.Long>(x10.rtt.Types.LONG, ((long)(newRank)), ((x10.core.fun.Fun_0_1)(t$151820)), (x10.core.Rail.__1$1x10$lang$Long$3x10$lang$Rail$$T$2) null)));
                    
                    //#line 55 "x10/regionarray/FullRegion.x10"
                    final x10.core.fun.Fun_0_1 t$151827 = ((x10.core.fun.Fun_0_1)(new x10.regionarray.FullRegion.$Closure$245(this, this.rank, thatMax, (x10.regionarray.FullRegion.$Closure$245.__2$1x10$lang$Long$3x10$lang$Long$2) null)));
                    
                    //#line 55 "x10/regionarray/FullRegion.x10"
                    final x10.core.Rail newMax = ((x10.core.Rail)(new x10.core.Rail<x10.core.Long>(x10.rtt.Types.LONG, ((long)(newRank)), ((x10.core.fun.Fun_0_1)(t$151827)), (x10.core.Rail.__1$1x10$lang$Long$3x10$lang$Rail$$T$2) null)));
                    
                    //#line 56 "x10/regionarray/FullRegion.x10"
                    final x10.regionarray.RectRegion alloc$146580 = ((x10.regionarray.RectRegion)(new x10.regionarray.RectRegion((java.lang.System[]) null)));
                    
                    //#line 56 "x10/regionarray/FullRegion.x10"
                    alloc$146580.x10$regionarray$RectRegion$$init$S(((x10.core.Rail)(newMin)), ((x10.core.Rail)(newMax)), (x10.regionarray.RectRegion.__0$1x10$lang$Long$2__1$1x10$lang$Long$2) null);
                    
                    //#line 56 "x10/regionarray/FullRegion.x10"
                    return alloc$146580;
                } else {
                    
                    //#line 57 "x10/regionarray/FullRegion.x10"
                    final boolean t$151834 = x10.regionarray.RectRegion1D.$RTT.isInstance(that);
                    
                    //#line 57 "x10/regionarray/FullRegion.x10"
                    if (t$151834) {
                        
                        //#line 58 "x10/regionarray/FullRegion.x10"
                        final x10.regionarray.RectRegion1D t$151828 = ((x10.regionarray.RectRegion1D)(x10.rtt.Types.<x10.regionarray.RectRegion1D> cast(that,x10.regionarray.RectRegion1D.$RTT)));
                        
                        //#line 58 "x10/regionarray/FullRegion.x10"
                        final x10.regionarray.RectRegion t$151829 = ((x10.regionarray.RectRegion)(t$151828.toRectRegion()));
                        
                        //#line 58 "x10/regionarray/FullRegion.x10"
                        final x10.regionarray.Region t$151830 = ((x10.regionarray.Region)(this.product(((x10.regionarray.Region)(t$151829)))));
                        
                        //#line 58 "x10/regionarray/FullRegion.x10"
                        return t$151830;
                    } else {
                        
                        //#line 60 "x10/regionarray/FullRegion.x10"
                        final java.lang.String t$151831 = x10.rtt.Types.typeName(that);
                        
                        //#line 60 "x10/regionarray/FullRegion.x10"
                        final java.lang.String t$151832 = (("haven\'t implemented FullRegion product with ") + (t$151831));
                        
                        //#line 60 "x10/regionarray/FullRegion.x10"
                        final java.lang.UnsupportedOperationException t$151833 = ((java.lang.UnsupportedOperationException)(new java.lang.UnsupportedOperationException(t$151832)));
                        
                        //#line 60 "x10/regionarray/FullRegion.x10"
                        throw t$151833;
                    }
                }
            }
        }
    }
    
    
    //#line 63 "x10/regionarray/FullRegion.x10"
    public x10.regionarray.Region projection(final long axis) {
        
        //#line 63 "x10/regionarray/FullRegion.x10"
        final x10.regionarray.FullRegion alloc$146581 = ((x10.regionarray.FullRegion)(new x10.regionarray.FullRegion((java.lang.System[]) null)));
        
        //#line 63 "x10/regionarray/FullRegion.x10"
        alloc$146581.x10$regionarray$FullRegion$$init$S(((long)(1L)));
        
        //#line 63 "x10/regionarray/FullRegion.x10"
        return alloc$146581;
    }
    
    
    //#line 64 "x10/regionarray/FullRegion.x10"
    public x10.regionarray.Region translate(final x10.lang.Point p) {
        
        //#line 64 "x10/regionarray/FullRegion.x10"
        return this;
    }
    
    
    //#line 65 "x10/regionarray/FullRegion.x10"
    public x10.regionarray.FullRegion eliminate(final long i) {
        
        //#line 65 "x10/regionarray/FullRegion.x10"
        final x10.regionarray.FullRegion alloc$146582 = ((x10.regionarray.FullRegion)(new x10.regionarray.FullRegion((java.lang.System[]) null)));
        
        //#line 65 "x10/regionarray/FullRegion.x10"
        final long t$151857 = this.rank;
        
        //#line 65 "x10/regionarray/FullRegion.x10"
        final long t$151858 = ((t$151857) - (((long)(1L))));
        
        //#line 65 "x10/regionarray/FullRegion.x10"
        alloc$146582.x10$regionarray$FullRegion$$init$S(t$151858);
        
        //#line 65 "x10/regionarray/FullRegion.x10"
        return alloc$146582;
    }
    
    
    //#line 66 "x10/regionarray/FullRegion.x10"
    public x10.regionarray.Region computeBoundingBox() {
        
        //#line 66 "x10/regionarray/FullRegion.x10"
        return this;
    }
    
    
    //#line 67 "x10/regionarray/FullRegion.x10"
    public boolean contains$O(final x10.regionarray.Region that) {
        
        //#line 67 "x10/regionarray/FullRegion.x10"
        return true;
    }
    
    
    //#line 68 "x10/regionarray/FullRegion.x10"
    public boolean contains$O(final x10.lang.Point p) {
        
        //#line 68 "x10/regionarray/FullRegion.x10"
        return true;
    }
    
    
    //#line 69 "x10/regionarray/FullRegion.x10"
    public java.lang.String toString() {
        
        //#line 69 "x10/regionarray/FullRegion.x10"
        final long t$151840 = this.rank;
        
        //#line 69 "x10/regionarray/FullRegion.x10"
        final java.lang.String t$151841 = (("full(") + ((x10.core.Long.$box(t$151840))));
        
        //#line 69 "x10/regionarray/FullRegion.x10"
        final java.lang.String t$151842 = ((t$151841) + (")"));
        
        //#line 69 "x10/regionarray/FullRegion.x10"
        return t$151842;
    }
    
    
    //#line 72 "x10/regionarray/FullRegion.x10"
    public x10.lang.Iterator iterator() {
        
        //#line 73 "x10/regionarray/FullRegion.x10"
        final x10.regionarray.UnboundedRegionException t$151843 = ((x10.regionarray.UnboundedRegionException)(new x10.regionarray.UnboundedRegionException(((java.lang.String)("iterator not supported")))));
        
        //#line 73 "x10/regionarray/FullRegion.x10"
        throw t$151843;
    }
    
    
    //#line 17 "x10/regionarray/FullRegion.x10"
    final public x10.regionarray.FullRegion x10$regionarray$FullRegion$$this$x10$regionarray$FullRegion() {
        
        //#line 17 "x10/regionarray/FullRegion.x10"
        return x10.regionarray.FullRegion.this;
    }
    
    
    //#line 17 "x10/regionarray/FullRegion.x10"
    final public void __fieldInitializers_x10_regionarray_FullRegion() {
        
    }
    
    @x10.runtime.impl.java.X10Generated
    final public static class $Closure$240 extends x10.core.Ref implements x10.core.fun.Fun_0_1, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<$Closure$240> $RTT = 
            x10.rtt.StaticFunType.<$Closure$240> make($Closure$240.class,
                                                      new x10.rtt.Type[] {
                                                          x10.rtt.ParameterizedType.make(x10.core.fun.Fun_0_1.$RTT, x10.rtt.Types.LONG, x10.rtt.Types.LONG)
                                                      });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static x10.serialization.X10JavaSerializable $_deserialize_body(x10.regionarray.FullRegion.$Closure$240 $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            $_obj.out$$ = $deserializer.readObject();
            $_obj.rank = $deserializer.readLong();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.regionarray.FullRegion.$Closure$240 $_obj = new x10.regionarray.FullRegion.$Closure$240((java.lang.System[]) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            $serializer.write(this.out$$);
            $serializer.write(this.rank);
            
        }
        
        // constructor just for allocation
        public $Closure$240(final java.lang.System[] $dummy) {
            
        }
        
        // dispatcher for method abstract public (Z1)=>U.operator()(a1:Z1):U
        public java.lang.Object $apply(final java.lang.Object a1, final x10.rtt.Type t1) {
            return x10.core.Long.$box($apply$O(x10.core.Long.$unbox(a1)));
            
        }
        
        // dispatcher for method abstract public (Z1)=>U.operator()(a1:Z1):U
        public long $apply$J(final java.lang.Object a1, final x10.rtt.Type t1) {
            return $apply$O(x10.core.Long.$unbox(a1));
            
        }
        
        
    
        
        public long $apply$O(final long i) {
            
            //#line 34 "x10/regionarray/FullRegion.x10"
            boolean t$151785 = ((i) < (((long)(0L))));
            
            //#line 34 "x10/regionarray/FullRegion.x10"
            if (!(t$151785)) {
                
                //#line 34 "x10/regionarray/FullRegion.x10"
                final long t$151784 = this.rank;
                
                //#line 34 "x10/regionarray/FullRegion.x10"
                t$151785 = ((i) >= (((long)(t$151784))));
            }
            
            //#line 34 "x10/regionarray/FullRegion.x10"
            if (t$151785) {
                
                //#line 34 "x10/regionarray/FullRegion.x10"
                final java.lang.String t$151786 = (("min: ") + ((x10.core.Long.$box(i))));
                
                //#line 34 "x10/regionarray/FullRegion.x10"
                final java.lang.String t$151787 = ((t$151786) + (" is not a valid rank for "));
                
                //#line 34 "x10/regionarray/FullRegion.x10"
                final java.lang.String t$151788 = ((t$151787) + (this.out$$));
                
                //#line 34 "x10/regionarray/FullRegion.x10"
                final java.lang.ArrayIndexOutOfBoundsException t$151789 = ((java.lang.ArrayIndexOutOfBoundsException)(new java.lang.ArrayIndexOutOfBoundsException(t$151788)));
                
                //#line 34 "x10/regionarray/FullRegion.x10"
                throw t$151789;
            }
            
            //#line 35 "x10/regionarray/FullRegion.x10"
            final long t$151791 = java.lang.Long.MIN_VALUE;
            
            //#line 35 "x10/regionarray/FullRegion.x10"
            return t$151791;
        }
        
        public x10.regionarray.FullRegion out$$;
        public long rank;
        
        public $Closure$240(final x10.regionarray.FullRegion out$$, final long rank) {
             {
                this.out$$ = out$$;
                this.rank = rank;
            }
        }
        
    }
    
    @x10.runtime.impl.java.X10Generated
    final public static class $Closure$241 extends x10.core.Ref implements x10.core.fun.Fun_0_1, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<$Closure$241> $RTT = 
            x10.rtt.StaticFunType.<$Closure$241> make($Closure$241.class,
                                                      new x10.rtt.Type[] {
                                                          x10.rtt.ParameterizedType.make(x10.core.fun.Fun_0_1.$RTT, x10.rtt.Types.LONG, x10.rtt.Types.LONG)
                                                      });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static x10.serialization.X10JavaSerializable $_deserialize_body(x10.regionarray.FullRegion.$Closure$241 $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            $_obj.out$$ = $deserializer.readObject();
            $_obj.rank = $deserializer.readLong();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.regionarray.FullRegion.$Closure$241 $_obj = new x10.regionarray.FullRegion.$Closure$241((java.lang.System[]) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            $serializer.write(this.out$$);
            $serializer.write(this.rank);
            
        }
        
        // constructor just for allocation
        public $Closure$241(final java.lang.System[] $dummy) {
            
        }
        
        // dispatcher for method abstract public (Z1)=>U.operator()(a1:Z1):U
        public java.lang.Object $apply(final java.lang.Object a1, final x10.rtt.Type t1) {
            return x10.core.Long.$box($apply$O(x10.core.Long.$unbox(a1)));
            
        }
        
        // dispatcher for method abstract public (Z1)=>U.operator()(a1:Z1):U
        public long $apply$J(final java.lang.Object a1, final x10.rtt.Type t1) {
            return $apply$O(x10.core.Long.$unbox(a1));
            
        }
        
        
    
        
        public long $apply$O(final long i) {
            
            //#line 40 "x10/regionarray/FullRegion.x10"
            boolean t$151794 = ((i) < (((long)(0L))));
            
            //#line 40 "x10/regionarray/FullRegion.x10"
            if (!(t$151794)) {
                
                //#line 40 "x10/regionarray/FullRegion.x10"
                final long t$151793 = this.rank;
                
                //#line 40 "x10/regionarray/FullRegion.x10"
                t$151794 = ((i) >= (((long)(t$151793))));
            }
            
            //#line 40 "x10/regionarray/FullRegion.x10"
            if (t$151794) {
                
                //#line 40 "x10/regionarray/FullRegion.x10"
                final java.lang.String t$151795 = (("max: ") + ((x10.core.Long.$box(i))));
                
                //#line 40 "x10/regionarray/FullRegion.x10"
                final java.lang.String t$151796 = ((t$151795) + (" is not a valid rank for "));
                
                //#line 40 "x10/regionarray/FullRegion.x10"
                final java.lang.String t$151797 = ((t$151796) + (this.out$$));
                
                //#line 40 "x10/regionarray/FullRegion.x10"
                final java.lang.ArrayIndexOutOfBoundsException t$151798 = ((java.lang.ArrayIndexOutOfBoundsException)(new java.lang.ArrayIndexOutOfBoundsException(t$151797)));
                
                //#line 40 "x10/regionarray/FullRegion.x10"
                throw t$151798;
            }
            
            //#line 41 "x10/regionarray/FullRegion.x10"
            final long t$151800 = java.lang.Long.MAX_VALUE;
            
            //#line 41 "x10/regionarray/FullRegion.x10"
            return t$151800;
        }
        
        public x10.regionarray.FullRegion out$$;
        public long rank;
        
        public $Closure$241(final x10.regionarray.FullRegion out$$, final long rank) {
             {
                this.out$$ = out$$;
                this.rank = rank;
            }
        }
        
    }
    
    @x10.runtime.impl.java.X10Generated
    final public static class $Closure$242 extends x10.core.Ref implements x10.core.fun.Fun_0_1, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<$Closure$242> $RTT = 
            x10.rtt.StaticFunType.<$Closure$242> make($Closure$242.class,
                                                      new x10.rtt.Type[] {
                                                          x10.rtt.ParameterizedType.make(x10.core.fun.Fun_0_1.$RTT, x10.rtt.Types.LONG, x10.rtt.Types.LONG)
                                                      });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static x10.serialization.X10JavaSerializable $_deserialize_body(x10.regionarray.FullRegion.$Closure$242 $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            $_obj.this$151769 = $deserializer.readObject();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.regionarray.FullRegion.$Closure$242 $_obj = new x10.regionarray.FullRegion.$Closure$242((java.lang.System[]) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            $serializer.write(this.this$151769);
            
        }
        
        // constructor just for allocation
        public $Closure$242(final java.lang.System[] $dummy) {
            
        }
        
        // dispatcher for method abstract public (Z1)=>U.operator()(a1:Z1):U
        public java.lang.Object $apply(final java.lang.Object a1, final x10.rtt.Type t1) {
            return x10.core.Long.$box($apply$O(x10.core.Long.$unbox(a1)));
            
        }
        
        // dispatcher for method abstract public (Z1)=>U.operator()(a1:Z1):U
        public long $apply$J(final java.lang.Object a1, final x10.rtt.Type t1) {
            return $apply$O(x10.core.Long.$unbox(a1));
            
        }
        
        
    
        
        public long $apply$O(final long i$151852) {
            
            //#line 223 . "x10/regionarray/RectRegion.x10"
            final long t$151853 = this.this$151769.min$O((long)(i$151852));
            
            //#line 223 . "x10/regionarray/RectRegion.x10"
            return t$151853;
        }
        
        public x10.regionarray.RectRegion this$151769;
        
        public $Closure$242(final x10.regionarray.RectRegion this$151769) {
             {
                this.this$151769 = ((x10.regionarray.RectRegion)(this$151769));
            }
        }
        
    }
    
    @x10.runtime.impl.java.X10Generated
    final public static class $Closure$243 extends x10.core.Ref implements x10.core.fun.Fun_0_1, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<$Closure$243> $RTT = 
            x10.rtt.StaticFunType.<$Closure$243> make($Closure$243.class,
                                                      new x10.rtt.Type[] {
                                                          x10.rtt.ParameterizedType.make(x10.core.fun.Fun_0_1.$RTT, x10.rtt.Types.LONG, x10.rtt.Types.LONG)
                                                      });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static x10.serialization.X10JavaSerializable $_deserialize_body(x10.regionarray.FullRegion.$Closure$243 $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            $_obj.this$151773 = $deserializer.readObject();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.regionarray.FullRegion.$Closure$243 $_obj = new x10.regionarray.FullRegion.$Closure$243((java.lang.System[]) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            $serializer.write(this.this$151773);
            
        }
        
        // constructor just for allocation
        public $Closure$243(final java.lang.System[] $dummy) {
            
        }
        
        // dispatcher for method abstract public (Z1)=>U.operator()(a1:Z1):U
        public java.lang.Object $apply(final java.lang.Object a1, final x10.rtt.Type t1) {
            return x10.core.Long.$box($apply$O(x10.core.Long.$unbox(a1)));
            
        }
        
        // dispatcher for method abstract public (Z1)=>U.operator()(a1:Z1):U
        public long $apply$J(final java.lang.Object a1, final x10.rtt.Type t1) {
            return $apply$O(x10.core.Long.$unbox(a1));
            
        }
        
        
    
        
        public long $apply$O(final long i$151855) {
            
            //#line 224 . "x10/regionarray/RectRegion.x10"
            final long t$151856 = this.this$151773.max$O((long)(i$151855));
            
            //#line 224 . "x10/regionarray/RectRegion.x10"
            return t$151856;
        }
        
        public x10.regionarray.RectRegion this$151773;
        
        public $Closure$243(final x10.regionarray.RectRegion this$151773) {
             {
                this.this$151773 = ((x10.regionarray.RectRegion)(this$151773));
            }
        }
        
    }
    
    @x10.runtime.impl.java.X10Generated
    final public static class $Closure$244 extends x10.core.Ref implements x10.core.fun.Fun_0_1, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<$Closure$244> $RTT = 
            x10.rtt.StaticFunType.<$Closure$244> make($Closure$244.class,
                                                      new x10.rtt.Type[] {
                                                          x10.rtt.ParameterizedType.make(x10.core.fun.Fun_0_1.$RTT, x10.rtt.Types.LONG, x10.rtt.Types.LONG)
                                                      });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static x10.serialization.X10JavaSerializable $_deserialize_body(x10.regionarray.FullRegion.$Closure$244 $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            $_obj.out$$ = $deserializer.readObject();
            $_obj.rank = $deserializer.readLong();
            $_obj.thatMin = $deserializer.readObject();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.regionarray.FullRegion.$Closure$244 $_obj = new x10.regionarray.FullRegion.$Closure$244((java.lang.System[]) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            $serializer.write(this.out$$);
            $serializer.write(this.rank);
            $serializer.write(this.thatMin);
            
        }
        
        // constructor just for allocation
        public $Closure$244(final java.lang.System[] $dummy) {
            
        }
        
        // dispatcher for method abstract public (Z1)=>U.operator()(a1:Z1):U
        public java.lang.Object $apply(final java.lang.Object a1, final x10.rtt.Type t1) {
            return x10.core.Long.$box($apply$O(x10.core.Long.$unbox(a1)));
            
        }
        
        // dispatcher for method abstract public (Z1)=>U.operator()(a1:Z1):U
        public long $apply$J(final java.lang.Object a1, final x10.rtt.Type t1) {
            return $apply$O(x10.core.Long.$unbox(a1));
            
        }
        
        // synthetic type for parameter mangling
        public static final class __2$1x10$lang$Long$3x10$lang$Long$2 {}
        
    
        
        public long $apply$O(final long i) {
            
            //#line 54 "x10/regionarray/FullRegion.x10"
            final long t$151814 = this.rank;
            
            //#line 54 "x10/regionarray/FullRegion.x10"
            final boolean t$151817 = ((i) < (((long)(t$151814))));
            
            //#line 54 "x10/regionarray/FullRegion.x10"
            long t$151818 =  0;
            
            //#line 54 "x10/regionarray/FullRegion.x10"
            if (t$151817) {
                
                //#line 54 "x10/regionarray/FullRegion.x10"
                t$151818 = java.lang.Long.MIN_VALUE;
            } else {
                
                //#line 54 "x10/regionarray/FullRegion.x10"
                final long t$151815 = this.rank;
                
                //#line 54 "x10/regionarray/FullRegion.x10"
                final long t$151816 = ((i) - (((long)(t$151815))));
                
                //#line 54 "x10/regionarray/FullRegion.x10"
                t$151818 = x10.core.Long.$unbox(((x10.core.fun.Fun_0_1<x10.core.Long,x10.core.Long>)this.thatMin).$apply(x10.core.Long.$box(t$151816), x10.rtt.Types.LONG));
            }
            
            //#line 54 "x10/regionarray/FullRegion.x10"
            return t$151818;
        }
        
        public x10.regionarray.FullRegion out$$;
        public long rank;
        public x10.core.fun.Fun_0_1<x10.core.Long,x10.core.Long> thatMin;
        
        public $Closure$244(final x10.regionarray.FullRegion out$$, final long rank, final x10.core.fun.Fun_0_1<x10.core.Long,x10.core.Long> thatMin, __2$1x10$lang$Long$3x10$lang$Long$2 $dummy) {
             {
                this.out$$ = out$$;
                this.rank = rank;
                this.thatMin = ((x10.core.fun.Fun_0_1)(thatMin));
            }
        }
        
    }
    
    @x10.runtime.impl.java.X10Generated
    final public static class $Closure$245 extends x10.core.Ref implements x10.core.fun.Fun_0_1, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<$Closure$245> $RTT = 
            x10.rtt.StaticFunType.<$Closure$245> make($Closure$245.class,
                                                      new x10.rtt.Type[] {
                                                          x10.rtt.ParameterizedType.make(x10.core.fun.Fun_0_1.$RTT, x10.rtt.Types.LONG, x10.rtt.Types.LONG)
                                                      });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static x10.serialization.X10JavaSerializable $_deserialize_body(x10.regionarray.FullRegion.$Closure$245 $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            $_obj.out$$ = $deserializer.readObject();
            $_obj.rank = $deserializer.readLong();
            $_obj.thatMax = $deserializer.readObject();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.regionarray.FullRegion.$Closure$245 $_obj = new x10.regionarray.FullRegion.$Closure$245((java.lang.System[]) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            $serializer.write(this.out$$);
            $serializer.write(this.rank);
            $serializer.write(this.thatMax);
            
        }
        
        // constructor just for allocation
        public $Closure$245(final java.lang.System[] $dummy) {
            
        }
        
        // dispatcher for method abstract public (Z1)=>U.operator()(a1:Z1):U
        public java.lang.Object $apply(final java.lang.Object a1, final x10.rtt.Type t1) {
            return x10.core.Long.$box($apply$O(x10.core.Long.$unbox(a1)));
            
        }
        
        // dispatcher for method abstract public (Z1)=>U.operator()(a1:Z1):U
        public long $apply$J(final java.lang.Object a1, final x10.rtt.Type t1) {
            return $apply$O(x10.core.Long.$unbox(a1));
            
        }
        
        // synthetic type for parameter mangling
        public static final class __2$1x10$lang$Long$3x10$lang$Long$2 {}
        
    
        
        public long $apply$O(final long i) {
            
            //#line 55 "x10/regionarray/FullRegion.x10"
            final long t$151821 = this.rank;
            
            //#line 55 "x10/regionarray/FullRegion.x10"
            final boolean t$151824 = ((i) < (((long)(t$151821))));
            
            //#line 55 "x10/regionarray/FullRegion.x10"
            long t$151825 =  0;
            
            //#line 55 "x10/regionarray/FullRegion.x10"
            if (t$151824) {
                
                //#line 55 "x10/regionarray/FullRegion.x10"
                t$151825 = java.lang.Long.MAX_VALUE;
            } else {
                
                //#line 55 "x10/regionarray/FullRegion.x10"
                final long t$151822 = this.rank;
                
                //#line 55 "x10/regionarray/FullRegion.x10"
                final long t$151823 = ((i) - (((long)(t$151822))));
                
                //#line 55 "x10/regionarray/FullRegion.x10"
                t$151825 = x10.core.Long.$unbox(((x10.core.fun.Fun_0_1<x10.core.Long,x10.core.Long>)this.thatMax).$apply(x10.core.Long.$box(t$151823), x10.rtt.Types.LONG));
            }
            
            //#line 55 "x10/regionarray/FullRegion.x10"
            return t$151825;
        }
        
        public x10.regionarray.FullRegion out$$;
        public long rank;
        public x10.core.fun.Fun_0_1<x10.core.Long,x10.core.Long> thatMax;
        
        public $Closure$245(final x10.regionarray.FullRegion out$$, final long rank, final x10.core.fun.Fun_0_1<x10.core.Long,x10.core.Long> thatMax, __2$1x10$lang$Long$3x10$lang$Long$2 $dummy) {
             {
                this.out$$ = out$$;
                this.rank = rank;
                this.thatMax = ((x10.core.fun.Fun_0_1)(thatMax));
            }
        }
        
    }
    
}

