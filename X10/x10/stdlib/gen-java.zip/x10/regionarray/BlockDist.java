package x10.regionarray;


/**
 * <p>A BlockDist divides the coordinates along one axis
 * of its Region in a block fashion and distributes them
 * as evenly as possible to the places in its PlaceGroup.</p>
 * 
 * It caches the region for the current place as a transient field.
 * This makes the initial access to this information somewhat slow,
 * but optimizes the wire-transfer size of the Dist object. 
 * This appears to be the appropriate tradeoff, since Dist objects
 * are frequently serialized and usually the restriction operation is 
 * applied to get the Region for here, not for other places.
 */
@x10.runtime.impl.java.X10Generated
final public class BlockDist extends x10.regionarray.Dist implements x10.serialization.X10JavaSerializable
{
    public static final x10.rtt.RuntimeType<BlockDist> $RTT = 
        x10.rtt.NamedType.<BlockDist> make("x10.regionarray.BlockDist",
                                           BlockDist.class,
                                           new x10.rtt.Type[] {
                                               x10.regionarray.Dist.$RTT
                                           });
    
    public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
    
    public x10.rtt.Type<?> $getParam(int i) { return null; }
    
    private Object writeReplace() throws java.io.ObjectStreamException {
        return new x10.serialization.SerializationProxy(this);
    }
    
    public static x10.serialization.X10JavaSerializable $_deserialize_body(x10.regionarray.BlockDist $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
        x10.regionarray.Dist.$_deserialize_body($_obj, $deserializer);
        $_obj.axis = $deserializer.readLong();
        $_obj.pg = $deserializer.readObject();
        return $_obj;
    }
    
    public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
        x10.regionarray.BlockDist $_obj = new x10.regionarray.BlockDist((java.lang.System[]) null);
        $deserializer.record_reference($_obj);
        return $_deserialize_body($_obj, $deserializer);
    }
    
    public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
        super.$_serialize($serializer);
        $serializer.write(this.axis);
        $serializer.write(this.pg);
        
    }
    
    // constructor just for allocation
    public BlockDist(final java.lang.System[] $dummy) {
        super($dummy);
        
    }
    
    

    
    //#line 33 "x10/regionarray/BlockDist.x10"
    /**
     * The place group for this distribution
     */
    public x10.lang.PlaceGroup pg;
    
    //#line 38 "x10/regionarray/BlockDist.x10"
    /**
     * The axis along which the region is being distributed
     */
    public long axis;
    
    //#line 43 "x10/regionarray/BlockDist.x10"
    /**
     * Cached restricted region for the current place.
     */
    public transient x10.regionarray.Region regionForHere;
    
    
    //#line 46 "x10/regionarray/BlockDist.x10"
    // creation method for java code (1-phase java constructor)
    public BlockDist(final x10.regionarray.Region r, final long axis, final x10.lang.PlaceGroup pg) {
        this((java.lang.System[]) null);
        x10$regionarray$BlockDist$$init$S(r, axis, pg);
    }
    
    // constructor for non-virtual call
    final public x10.regionarray.BlockDist x10$regionarray$BlockDist$$init$S(final x10.regionarray.Region r, final long axis, final x10.lang.PlaceGroup pg) {
         {
            
            //#line 47 "x10/regionarray/BlockDist.x10"
            final x10.regionarray.Dist this$148485 = ((x10.regionarray.Dist)(this));
            
            //#line 548 . "x10/regionarray/Dist.x10"
            this$148485.region = r;
            
            //#line 46 "x10/regionarray/BlockDist.x10"
            
            
            //#line 28 "x10/regionarray/BlockDist.x10"
            final x10.regionarray.BlockDist this$148923 = this;
            
            //#line 28 "x10/regionarray/BlockDist.x10"
            this$148923.regionForHere = null;
            
            //#line 48 "x10/regionarray/BlockDist.x10"
            this.axis = axis;
            
            //#line 49 "x10/regionarray/BlockDist.x10"
            this.pg = ((x10.lang.PlaceGroup)(pg));
        }
        return this;
    }
    
    
    
    //#line 60 "x10/regionarray/BlockDist.x10"
    /**
     * The key algorithm for this class.
     * Compute the region for the given place by doing region algebra.
     *
     * Assumption: Caller has done error checking to ensure that place is 
     *   actually a member of pg.
     */
    private x10.regionarray.Region blockRegionForPlace(final x10.lang.Place place) {
        
        //#line 61 "x10/regionarray/BlockDist.x10"
        final x10.regionarray.Region t$148769 = ((x10.regionarray.Region)(this.region));
        
        //#line 61 "x10/regionarray/BlockDist.x10"
        final x10.regionarray.Region b = ((x10.regionarray.Region)(t$148769.boundingBox()));
        
        //#line 62 "x10/regionarray/BlockDist.x10"
        final long t$148770 = this.axis;
        
        //#line 62 "x10/regionarray/BlockDist.x10"
        final long min = b.min$O((long)(t$148770));
        
        //#line 63 "x10/regionarray/BlockDist.x10"
        final long t$148771 = this.axis;
        
        //#line 63 "x10/regionarray/BlockDist.x10"
        final long max = b.max$O((long)(t$148771));
        
        //#line 64 "x10/regionarray/BlockDist.x10"
        final x10.lang.PlaceGroup t$148772 = ((x10.lang.PlaceGroup)(this.pg));
        
        //#line 64 "x10/regionarray/BlockDist.x10"
        final long t$148773 = t$148772.numPlaces$O();
        
        //#line 64 "x10/regionarray/BlockDist.x10"
        final long P = t$148773;
        
        //#line 65 "x10/regionarray/BlockDist.x10"
        final long t$148774 = ((max) - (((long)(min))));
        
        //#line 65 "x10/regionarray/BlockDist.x10"
        final long numElems = ((t$148774) + (((long)(1L))));
        
        //#line 66 "x10/regionarray/BlockDist.x10"
        final long blockSize = ((numElems) / (((long)(P))));
        
        //#line 67 "x10/regionarray/BlockDist.x10"
        final long t$148775 = ((P) * (((long)(blockSize))));
        
        //#line 67 "x10/regionarray/BlockDist.x10"
        final long leftOver = ((numElems) - (((long)(t$148775))));
        
        //#line 68 "x10/regionarray/BlockDist.x10"
        final x10.lang.PlaceGroup t$148776 = ((x10.lang.PlaceGroup)(this.pg));
        
        //#line 68 "x10/regionarray/BlockDist.x10"
        final long t$148777 = t$148776.indexOf$O(((x10.lang.Place)(place)));
        
        //#line 68 "x10/regionarray/BlockDist.x10"
        final long i = t$148777;
        
        //#line 69 "x10/regionarray/BlockDist.x10"
        final long t$148778 = ((blockSize) * (((long)(i))));
        
        //#line 69 "x10/regionarray/BlockDist.x10"
        final long t$148781 = ((min) + (((long)(t$148778))));
        
        //#line 69 "x10/regionarray/BlockDist.x10"
        final boolean t$148779 = ((i) < (((long)(leftOver))));
        
        //#line 69 "x10/regionarray/BlockDist.x10"
        long t$148780 =  0;
        
        //#line 69 "x10/regionarray/BlockDist.x10"
        if (t$148779) {
            
            //#line 69 "x10/regionarray/BlockDist.x10"
            t$148780 = i;
        } else {
            
            //#line 69 "x10/regionarray/BlockDist.x10"
            t$148780 = leftOver;
        }
        
        //#line 69 "x10/regionarray/BlockDist.x10"
        final long low = ((t$148781) + (((long)(t$148780))));
        
        //#line 70 "x10/regionarray/BlockDist.x10"
        final long t$148785 = ((low) + (((long)(blockSize))));
        
        //#line 70 "x10/regionarray/BlockDist.x10"
        final boolean t$148783 = ((i) < (((long)(leftOver))));
        
        //#line 70 "x10/regionarray/BlockDist.x10"
        long t$148784 =  0;
        
        //#line 70 "x10/regionarray/BlockDist.x10"
        if (t$148783) {
            
            //#line 70 "x10/regionarray/BlockDist.x10"
            t$148784 = 0L;
        } else {
            
            //#line 70 "x10/regionarray/BlockDist.x10"
            t$148784 = -1L;
        }
        
        //#line 70 "x10/regionarray/BlockDist.x10"
        final long hi = ((t$148785) + (((long)(t$148784))));
        
        //#line 72 "x10/regionarray/BlockDist.x10"
        final x10.regionarray.Region t$148787 = ((x10.regionarray.Region)(this.region));
        
        //#line 72 "x10/regionarray/BlockDist.x10"
        final boolean t$148828 = x10.regionarray.RectRegion.$RTT.isInstance(t$148787);
        
        //#line 72 "x10/regionarray/BlockDist.x10"
        if (t$148828) {
            
            //#line 74 "x10/regionarray/BlockDist.x10"
            final x10.regionarray.Dist this$148490 = ((x10.regionarray.Dist)
                                                       this);
            
            //#line 38 . "x10/regionarray/Dist.x10"
            final x10.regionarray.Region t$148788 = ((x10.regionarray.Region)(this$148490.region));
            
            //#line 38 . "x10/regionarray/Dist.x10"
            final long t$148791 = t$148788.rank;
            
            //#line 74 "x10/regionarray/BlockDist.x10"
            final x10.core.fun.Fun_0_1 t$148792 = ((x10.core.fun.Fun_0_1)(new x10.regionarray.BlockDist.$Closure$208(this, this.region)));
            
            //#line 74 "x10/regionarray/BlockDist.x10"
            final x10.core.Rail newMin = ((x10.core.Rail)(new x10.core.Rail<x10.core.Long>(x10.rtt.Types.LONG, ((long)(t$148791)), ((x10.core.fun.Fun_0_1)(t$148792)), (x10.core.Rail.__1$1x10$lang$Long$3x10$lang$Rail$$T$2) null)));
            
            //#line 75 "x10/regionarray/BlockDist.x10"
            final x10.regionarray.Dist this$148492 = ((x10.regionarray.Dist)
                                                       this);
            
            //#line 38 . "x10/regionarray/Dist.x10"
            final x10.regionarray.Region t$148793 = ((x10.regionarray.Region)(this$148492.region));
            
            //#line 38 . "x10/regionarray/Dist.x10"
            final long t$148796 = t$148793.rank;
            
            //#line 75 "x10/regionarray/BlockDist.x10"
            final x10.core.fun.Fun_0_1 t$148797 = ((x10.core.fun.Fun_0_1)(new x10.regionarray.BlockDist.$Closure$209(this, this.region)));
            
            //#line 75 "x10/regionarray/BlockDist.x10"
            final x10.core.Rail newMax = ((x10.core.Rail)(new x10.core.Rail<x10.core.Long>(x10.rtt.Types.LONG, ((long)(t$148796)), ((x10.core.fun.Fun_0_1)(t$148797)), (x10.core.Rail.__1$1x10$lang$Long$3x10$lang$Rail$$T$2) null)));
            
            //#line 76 "x10/regionarray/BlockDist.x10"
            final long t$148798 = this.axis;
            
            //#line 76 "x10/regionarray/BlockDist.x10"
            ((long[])newMin.value)[(int)t$148798] = low;
            
            //#line 77 "x10/regionarray/BlockDist.x10"
            final long t$148799 = this.axis;
            
            //#line 77 "x10/regionarray/BlockDist.x10"
            ((long[])newMax.value)[(int)t$148799] = hi;
            
            //#line 78 "x10/regionarray/BlockDist.x10"
            final x10.regionarray.RectRegion alloc$148479 = ((x10.regionarray.RectRegion)(new x10.regionarray.RectRegion((java.lang.System[]) null)));
            
            //#line 78 "x10/regionarray/BlockDist.x10"
            alloc$148479.x10$regionarray$RectRegion$$init$S(((x10.core.Rail)(newMin)), ((x10.core.Rail)(newMax)), (x10.regionarray.RectRegion.__0$1x10$lang$Long$2__1$1x10$lang$Long$2) null);
            
            //#line 78 "x10/regionarray/BlockDist.x10"
            final x10.regionarray.Region t$148368 = ((x10.regionarray.Region)
                                                      alloc$148479);
            
            //#line 78 "x10/regionarray/BlockDist.x10"
            final long t$148801 = t$148368.rank;
            
            //#line 78 "x10/regionarray/BlockDist.x10"
            final x10.regionarray.Region t$148800 = ((x10.regionarray.Region)(x10.regionarray.BlockDist.this.region));
            
            //#line 78 "x10/regionarray/BlockDist.x10"
            final long t$148802 = t$148800.rank;
            
            //#line 78 "x10/regionarray/BlockDist.x10"
            final boolean t$148803 = ((long) t$148801) == ((long) t$148802);
            
            //#line 78 "x10/regionarray/BlockDist.x10"
            final boolean t$148805 = !(t$148803);
            
            //#line 78 "x10/regionarray/BlockDist.x10"
            if (t$148805) {
                
                //#line 78 "x10/regionarray/BlockDist.x10"
                final x10.lang.FailedDynamicCheckException t$148804 = new x10.lang.FailedDynamicCheckException("x10.regionarray.Region{self.rank==this(:x10.regionarray.BlockDist).region.rank}");
                
                //#line 78 "x10/regionarray/BlockDist.x10"
                throw t$148804;
            }
            
            //#line 78 "x10/regionarray/BlockDist.x10"
            return t$148368;
        } else {
            
            //#line 79 "x10/regionarray/BlockDist.x10"
            final x10.regionarray.Region t$148806 = ((x10.regionarray.Region)(this.region));
            
            //#line 79 "x10/regionarray/BlockDist.x10"
            final boolean t$148827 = x10.regionarray.RectRegion1D.$RTT.isInstance(t$148806);
            
            //#line 79 "x10/regionarray/BlockDist.x10"
            if (t$148827) {
                
                //#line 80 "x10/regionarray/BlockDist.x10"
                final x10.regionarray.RectRegion1D alloc$148480 = ((x10.regionarray.RectRegion1D)(new x10.regionarray.RectRegion1D((java.lang.System[]) null)));
                
                //#line 80 "x10/regionarray/BlockDist.x10"
                alloc$148480.x10$regionarray$RectRegion1D$$init$S(((long)(low)), ((long)(hi)));
                
                //#line 80 "x10/regionarray/BlockDist.x10"
                final x10.regionarray.Region t$148370 = ((x10.regionarray.Region)
                                                          alloc$148480);
                
                //#line 80 "x10/regionarray/BlockDist.x10"
                final long t$148808 = t$148370.rank;
                
                //#line 80 "x10/regionarray/BlockDist.x10"
                final x10.regionarray.Region t$148807 = ((x10.regionarray.Region)(x10.regionarray.BlockDist.this.region));
                
                //#line 80 "x10/regionarray/BlockDist.x10"
                final long t$148809 = t$148807.rank;
                
                //#line 80 "x10/regionarray/BlockDist.x10"
                final boolean t$148810 = ((long) t$148808) == ((long) t$148809);
                
                //#line 80 "x10/regionarray/BlockDist.x10"
                final boolean t$148812 = !(t$148810);
                
                //#line 80 "x10/regionarray/BlockDist.x10"
                if (t$148812) {
                    
                    //#line 80 "x10/regionarray/BlockDist.x10"
                    final x10.lang.FailedDynamicCheckException t$148811 = new x10.lang.FailedDynamicCheckException("x10.regionarray.Region{self.rank==this(:x10.regionarray.BlockDist).region.rank}");
                    
                    //#line 80 "x10/regionarray/BlockDist.x10"
                    throw t$148811;
                }
                
                //#line 80 "x10/regionarray/BlockDist.x10"
                return t$148370;
            } else {
                
                //#line 83 "x10/regionarray/BlockDist.x10"
                final long rank$148494 = this.axis;
                
                //#line 66 . "x10/regionarray/Region.x10"
                final x10.regionarray.FullRegion alloc$148495 = ((x10.regionarray.FullRegion)(new x10.regionarray.FullRegion((java.lang.System[]) null)));
                
                //#line 66 . "x10/regionarray/Region.x10"
                alloc$148495.x10$regionarray$FullRegion$$init$S(((long)(rank$148494)));
                
                //#line 83 "x10/regionarray/BlockDist.x10"
                final x10.regionarray.Region r1 = ((x10.regionarray.Region)(((x10.regionarray.Region)
                                                                              alloc$148495)));
                
                //#line 279 . "x10/regionarray/Region.x10"
                final x10.regionarray.RectRegion1D alloc$148499 = ((x10.regionarray.RectRegion1D)(new x10.regionarray.RectRegion1D((java.lang.System[]) null)));
                
                //#line 279 . "x10/regionarray/Region.x10"
                alloc$148499.x10$regionarray$RectRegion1D$$init$S(low, hi);
                
                //#line 84 "x10/regionarray/BlockDist.x10"
                final x10.regionarray.Region r2 = ((x10.regionarray.Region)(((x10.regionarray.Region)
                                                                              alloc$148499)));
                
                //#line 85 "x10/regionarray/BlockDist.x10"
                final x10.regionarray.Region t$148813 = ((x10.regionarray.Region)(this.region));
                
                //#line 85 "x10/regionarray/BlockDist.x10"
                final long t$148814 = t$148813.rank;
                
                //#line 85 "x10/regionarray/BlockDist.x10"
                final long t$148815 = this.axis;
                
                //#line 85 "x10/regionarray/BlockDist.x10"
                final long t$148816 = ((t$148814) - (((long)(t$148815))));
                
                //#line 85 "x10/regionarray/BlockDist.x10"
                final long rank$148501 = ((t$148816) - (((long)(1L))));
                
                //#line 66 . "x10/regionarray/Region.x10"
                final x10.regionarray.FullRegion alloc$148502 = ((x10.regionarray.FullRegion)(new x10.regionarray.FullRegion((java.lang.System[]) null)));
                
                //#line 66 . "x10/regionarray/Region.x10"
                alloc$148502.x10$regionarray$FullRegion$$init$S(((long)(rank$148501)));
                
                //#line 85 "x10/regionarray/BlockDist.x10"
                final x10.regionarray.Region r3 = ((x10.regionarray.Region)(((x10.regionarray.Region)
                                                                              alloc$148502)));
                
                //#line 86 "x10/regionarray/BlockDist.x10"
                final x10.regionarray.Region t$148817 = ((x10.regionarray.Region)(r1.product(((x10.regionarray.Region)(r2)))));
                
                //#line 86 "x10/regionarray/BlockDist.x10"
                final x10.regionarray.Region t$148818 = ((x10.regionarray.Region)(t$148817.product(((x10.regionarray.Region)(r3)))));
                
                //#line 86 "x10/regionarray/BlockDist.x10"
                final x10.regionarray.Region t$148386 = ((x10.regionarray.Region)
                                                          t$148818);
                
                //#line 86 "x10/regionarray/BlockDist.x10"
                final long t$148820 = t$148386.rank;
                
                //#line 86 "x10/regionarray/BlockDist.x10"
                final x10.regionarray.Region t$148819 = ((x10.regionarray.Region)(x10.regionarray.BlockDist.this.region));
                
                //#line 86 "x10/regionarray/BlockDist.x10"
                final long t$148821 = t$148819.rank;
                
                //#line 86 "x10/regionarray/BlockDist.x10"
                final boolean t$148822 = ((long) t$148820) == ((long) t$148821);
                
                //#line 86 "x10/regionarray/BlockDist.x10"
                final boolean t$148824 = !(t$148822);
                
                //#line 86 "x10/regionarray/BlockDist.x10"
                if (t$148824) {
                    
                    //#line 86 "x10/regionarray/BlockDist.x10"
                    final x10.lang.FailedDynamicCheckException t$148823 = new x10.lang.FailedDynamicCheckException("x10.regionarray.Region{self.rank==this(:x10.regionarray.BlockDist).region.rank}");
                    
                    //#line 86 "x10/regionarray/BlockDist.x10"
                    throw t$148823;
                }
                
                //#line 86 "x10/regionarray/BlockDist.x10"
                final x10.regionarray.Region t$148825 = ((x10.regionarray.Region)(this.region));
                
                //#line 86 "x10/regionarray/BlockDist.x10"
                final x10.regionarray.Region t$148826 = ((x10.regionarray.Region)(t$148386.intersection(((x10.regionarray.Region)(t$148825)))));
                
                //#line 86 "x10/regionarray/BlockDist.x10"
                return t$148826;
            }
        }
    }
    
    public static x10.regionarray.Region blockRegionForPlace$P(final x10.lang.Place place, final x10.regionarray.BlockDist BlockDist) {
        return BlockDist.blockRegionForPlace(((x10.lang.Place)(place)));
    }
    
    
    //#line 97 "x10/regionarray/BlockDist.x10"
    /**
     * Given an index into the "axis dimension" determine which place it 
     * is mapped to.
     *
     * Assumption: Caller has done error checking to ensure that index is 
     *   actually within the bounds of the axis dimension.
     */
    private x10.lang.Place mapIndexToPlace(final long index) {
        
        //#line 98 "x10/regionarray/BlockDist.x10"
        final x10.regionarray.Region t$148829 = ((x10.regionarray.Region)(this.region));
        
        //#line 98 "x10/regionarray/BlockDist.x10"
        final x10.regionarray.Region bb = ((x10.regionarray.Region)(t$148829.boundingBox()));
        
        //#line 99 "x10/regionarray/BlockDist.x10"
        final long t$148830 = this.axis;
        
        //#line 99 "x10/regionarray/BlockDist.x10"
        final long min = bb.min$O((long)(t$148830));
        
        //#line 100 "x10/regionarray/BlockDist.x10"
        final long t$148831 = this.axis;
        
        //#line 100 "x10/regionarray/BlockDist.x10"
        final long max = bb.max$O((long)(t$148831));
        
        //#line 101 "x10/regionarray/BlockDist.x10"
        final x10.lang.PlaceGroup t$148832 = ((x10.lang.PlaceGroup)(this.pg));
        
        //#line 101 "x10/regionarray/BlockDist.x10"
        final long P = t$148832.numPlaces$O();
        
        //#line 102 "x10/regionarray/BlockDist.x10"
        final long t$148833 = ((max) - (((long)(min))));
        
        //#line 102 "x10/regionarray/BlockDist.x10"
        final long numElems = ((t$148833) + (((long)(1L))));
        
        //#line 103 "x10/regionarray/BlockDist.x10"
        final long blockSize = ((numElems) / (((long)(P))));
        
        //#line 104 "x10/regionarray/BlockDist.x10"
        final long t$148834 = ((P) * (((long)(blockSize))));
        
        //#line 104 "x10/regionarray/BlockDist.x10"
        final long leftOver = ((numElems) - (((long)(t$148834))));
        
        //#line 105 "x10/regionarray/BlockDist.x10"
        final long normalizedIndex = ((index) - (((long)(min))));
        
        //#line 107 "x10/regionarray/BlockDist.x10"
        final long t$148835 = ((blockSize) + (((long)(1L))));
        
        //#line 107 "x10/regionarray/BlockDist.x10"
        final long nominalPlace = ((normalizedIndex) / (((long)(t$148835))));
        
        //#line 108 "x10/regionarray/BlockDist.x10"
        final boolean t$148845 = ((nominalPlace) < (((long)(leftOver))));
        
        //#line 108 "x10/regionarray/BlockDist.x10"
        if (t$148845) {
            
            //#line 109 "x10/regionarray/BlockDist.x10"
            final x10.lang.PlaceGroup t$148836 = ((x10.lang.PlaceGroup)(this.pg));
            
            //#line 109 "x10/regionarray/BlockDist.x10"
            final x10.lang.Place t$148837 = t$148836.$apply((long)(nominalPlace));
            
            //#line 109 "x10/regionarray/BlockDist.x10"
            return t$148837;
        } else {
            
            //#line 111 "x10/regionarray/BlockDist.x10"
            final long indexFromTop = ((max) - (((long)(index))));
            
            //#line 112 "x10/regionarray/BlockDist.x10"
            final x10.lang.PlaceGroup t$148842 = ((x10.lang.PlaceGroup)(this.pg));
            
            //#line 112 "x10/regionarray/BlockDist.x10"
            final x10.lang.PlaceGroup t$148838 = ((x10.lang.PlaceGroup)(this.pg));
            
            //#line 112 "x10/regionarray/BlockDist.x10"
            final long t$148839 = t$148838.numPlaces$O();
            
            //#line 112 "x10/regionarray/BlockDist.x10"
            final long t$148840 = ((t$148839) - (((long)(1L))));
            
            //#line 112 "x10/regionarray/BlockDist.x10"
            final long t$148841 = ((indexFromTop) / (((long)(blockSize))));
            
            //#line 112 "x10/regionarray/BlockDist.x10"
            final long t$148843 = ((t$148840) - (((long)(t$148841))));
            
            //#line 112 "x10/regionarray/BlockDist.x10"
            final x10.lang.Place t$148844 = t$148842.$apply((long)(t$148843));
            
            //#line 112 "x10/regionarray/BlockDist.x10"
            return t$148844;
        }
    }
    
    public static x10.lang.Place mapIndexToPlace$P(final long index, final x10.regionarray.BlockDist BlockDist) {
        return BlockDist.mapIndexToPlace((long)(index));
    }
    
    
    //#line 117 "x10/regionarray/BlockDist.x10"
    public x10.lang.PlaceGroup places() {
        
        //#line 117 "x10/regionarray/BlockDist.x10"
        final x10.lang.PlaceGroup t$148846 = ((x10.lang.PlaceGroup)(this.pg));
        
        //#line 117 "x10/regionarray/BlockDist.x10"
        return t$148846;
    }
    
    
    //#line 119 "x10/regionarray/BlockDist.x10"
    public long numPlaces$O() {
        
        //#line 119 "x10/regionarray/BlockDist.x10"
        final x10.lang.PlaceGroup t$148847 = ((x10.lang.PlaceGroup)(this.pg));
        
        //#line 119 "x10/regionarray/BlockDist.x10"
        final long t$148848 = t$148847.numPlaces$O();
        
        //#line 119 "x10/regionarray/BlockDist.x10"
        return t$148848;
    }
    
    
    //#line 121 "x10/regionarray/BlockDist.x10"
    public x10.lang.Iterable regions() {
        
        //#line 122 "x10/regionarray/BlockDist.x10"
        final x10.lang.PlaceGroup t$148849 = ((x10.lang.PlaceGroup)(this.pg));
        
        //#line 122 "x10/regionarray/BlockDist.x10"
        final long t$148853 = t$148849.numPlaces$O();
        
        //#line 122 "x10/regionarray/BlockDist.x10"
        final x10.core.fun.Fun_0_1 t$148854 = ((x10.core.fun.Fun_0_1)(new x10.regionarray.BlockDist.$Closure$210(this, this.pg)));
        
        //#line 122 "x10/regionarray/BlockDist.x10"
        final x10.core.Rail t$148855 = ((x10.core.Rail)(new x10.core.Rail<x10.regionarray.Region>(x10.regionarray.Region.$RTT, t$148853, ((x10.core.fun.Fun_0_1)(t$148854)), (x10.core.Rail.__1$1x10$lang$Long$3x10$lang$Rail$$T$2) null)));
        
        //#line 122 "x10/regionarray/BlockDist.x10"
        return t$148855;
    }
    
    
    //#line 125 "x10/regionarray/BlockDist.x10"
    public x10.regionarray.Region get(final x10.lang.Place p) {
        
        //#line 126 "x10/regionarray/BlockDist.x10"
        final boolean t$148861 = x10.rtt.Equality.equalsequals((p),(x10.x10rt.X10RT.here()));
        
        //#line 126 "x10/regionarray/BlockDist.x10"
        if (t$148861) {
            
            //#line 127 "x10/regionarray/BlockDist.x10"
            final x10.regionarray.Region t$148856 = ((x10.regionarray.Region)(this.regionForHere));
            
            //#line 127 "x10/regionarray/BlockDist.x10"
            final boolean t$148858 = ((t$148856) == (null));
            
            //#line 127 "x10/regionarray/BlockDist.x10"
            if (t$148858) {
                
                //#line 128 "x10/regionarray/BlockDist.x10"
                final x10.regionarray.Region t$148857 = ((x10.regionarray.Region)(this.blockRegionForPlace(((x10.lang.Place)(x10.x10rt.X10RT.here())))));
                
                //#line 128 "x10/regionarray/BlockDist.x10"
                this.regionForHere = ((x10.regionarray.Region)(t$148857));
            }
            
            //#line 130 "x10/regionarray/BlockDist.x10"
            final x10.regionarray.Region t$148859 = ((x10.regionarray.Region)(this.regionForHere));
            
            //#line 130 "x10/regionarray/BlockDist.x10"
            return t$148859;
        } else {
            
            //#line 132 "x10/regionarray/BlockDist.x10"
            final x10.regionarray.Region t$148860 = ((x10.regionarray.Region)(this.blockRegionForPlace(((x10.lang.Place)(p)))));
            
            //#line 132 "x10/regionarray/BlockDist.x10"
            return t$148860;
        }
    }
    
    
    //#line 136 "x10/regionarray/BlockDist.x10"
    public boolean containsLocally$O(final x10.lang.Point p) {
        
        //#line 136 "x10/regionarray/BlockDist.x10"
        final x10.regionarray.Region t$148862 = ((x10.regionarray.Region)(this.get(((x10.lang.Place)(x10.x10rt.X10RT.here())))));
        
        //#line 136 "x10/regionarray/BlockDist.x10"
        final boolean t$148863 = t$148862.contains$O(((x10.lang.Point)(p)));
        
        //#line 136 "x10/regionarray/BlockDist.x10"
        return t$148863;
    }
    
    
    //#line 140 "x10/regionarray/BlockDist.x10"
    public x10.regionarray.Region $apply(final x10.lang.Place p) {
        
        //#line 140 "x10/regionarray/BlockDist.x10"
        final x10.regionarray.Region t$148864 = ((x10.regionarray.Region)(this.get(((x10.lang.Place)(p)))));
        
        //#line 140 "x10/regionarray/BlockDist.x10"
        return t$148864;
    }
    
    
    //#line 142 "x10/regionarray/BlockDist.x10"
    public x10.lang.Place $apply(final x10.lang.Point pt) {
        
        //#line 143 "x10/regionarray/BlockDist.x10"
        final x10.regionarray.Region t$148865 = ((x10.regionarray.Region)(this.region));
        
        //#line 143 "x10/regionarray/BlockDist.x10"
        final boolean t$148866 = t$148865.contains$O(((x10.lang.Point)(pt)));
        
        //#line 143 "x10/regionarray/BlockDist.x10"
        final boolean t$148867 = !(t$148866);
        
        //#line 143 "x10/regionarray/BlockDist.x10"
        if (t$148867) {
            
            //#line 143 "x10/regionarray/BlockDist.x10"
            x10.regionarray.Dist.raiseBoundsError(((x10.lang.Point)(pt)));
        }
        
        //#line 144 "x10/regionarray/BlockDist.x10"
        final long t$148868 = this.axis;
        
        //#line 144 "x10/regionarray/BlockDist.x10"
        final long t$148869 = pt.$apply$O((long)(t$148868));
        
        //#line 144 "x10/regionarray/BlockDist.x10"
        final x10.lang.Place t$148870 = this.mapIndexToPlace((long)(t$148869));
        
        //#line 144 "x10/regionarray/BlockDist.x10"
        return t$148870;
    }
    
    
    //#line 147 "x10/regionarray/BlockDist.x10"
    public x10.lang.Place $apply(final long i0) {
        
        //#line 148 "x10/regionarray/BlockDist.x10"
        final x10.regionarray.Region t$148873 = ((x10.regionarray.Region)(this.region));
        
        //#line 148 "x10/regionarray/BlockDist.x10"
        final boolean t$148874 = t$148873.contains$O((long)(i0));
        
        //#line 148 "x10/regionarray/BlockDist.x10"
        final boolean t$148875 = !(t$148874);
        
        //#line 148 "x10/regionarray/BlockDist.x10"
        if (t$148875) {
            
            //#line 148 "x10/regionarray/BlockDist.x10"
            x10.regionarray.Dist.raiseBoundsError((long)(i0));
        }
        
        //#line 149 "x10/regionarray/BlockDist.x10"
        final x10.lang.Place t$148876 = this.mapIndexToPlace((long)(i0));
        
        //#line 149 "x10/regionarray/BlockDist.x10"
        return t$148876;
    }
    
    
    //#line 152 "x10/regionarray/BlockDist.x10"
    public x10.lang.Place $apply(final long i0, final long i1) {
        
        //#line 153 "x10/regionarray/BlockDist.x10"
        final x10.regionarray.Region t$148879 = ((x10.regionarray.Region)(this.region));
        
        //#line 153 "x10/regionarray/BlockDist.x10"
        final boolean t$148880 = t$148879.contains$O((long)(i0), (long)(i1));
        
        //#line 153 "x10/regionarray/BlockDist.x10"
        final boolean t$148881 = !(t$148880);
        
        //#line 153 "x10/regionarray/BlockDist.x10"
        if (t$148881) {
            
            //#line 153 "x10/regionarray/BlockDist.x10"
            x10.regionarray.Dist.raiseBoundsError((long)(i0), (long)(i1));
        }
        
        //#line 154 "x10/regionarray/BlockDist.x10"
        final long t$148882 = this.axis;
        
        //#line 154 "x10/regionarray/BlockDist.x10"
        final boolean t$148883 = ((long) t$148882) == ((long) 0L);
        
        //#line 154 "x10/regionarray/BlockDist.x10"
        x10.lang.Place t$148884 =  null;
        
        //#line 154 "x10/regionarray/BlockDist.x10"
        if (t$148883) {
            
            //#line 154 "x10/regionarray/BlockDist.x10"
            t$148884 = this.mapIndexToPlace((long)(i0));
        } else {
            
            //#line 154 "x10/regionarray/BlockDist.x10"
            t$148884 = this.mapIndexToPlace((long)(i1));
        }
        
        //#line 154 "x10/regionarray/BlockDist.x10"
        return t$148884;
    }
    
    
    //#line 157 "x10/regionarray/BlockDist.x10"
    public x10.lang.Place $apply(final long i0, final long i1, final long i2) {
        
        //#line 158 "x10/regionarray/BlockDist.x10"
        final x10.regionarray.Region t$148888 = ((x10.regionarray.Region)(this.region));
        
        //#line 158 "x10/regionarray/BlockDist.x10"
        final boolean t$148889 = t$148888.contains$O((long)(i0), (long)(i1), (long)(i2));
        
        //#line 158 "x10/regionarray/BlockDist.x10"
        final boolean t$148890 = !(t$148889);
        
        //#line 158 "x10/regionarray/BlockDist.x10"
        if (t$148890) {
            
            //#line 158 "x10/regionarray/BlockDist.x10"
            x10.regionarray.Dist.raiseBoundsError((long)(i0), (long)(i1), (long)(i2));
        }
        
        //#line 159 "x10/regionarray/BlockDist.x10"
        final long t$148891 = this.axis;
        
        //#line 159 "x10/regionarray/BlockDist.x10"
        final boolean t$148893 = ((long) t$148891) == ((long) 0L);
        
        //#line 159 "x10/regionarray/BlockDist.x10"
        if (t$148893) {
            
            //#line 159 "x10/regionarray/BlockDist.x10"
            final x10.lang.Place t$148892 = this.mapIndexToPlace((long)(i0));
            
            //#line 159 "x10/regionarray/BlockDist.x10"
            return t$148892;
        }
        
        //#line 160 "x10/regionarray/BlockDist.x10"
        final long t$148894 = this.axis;
        
        //#line 160 "x10/regionarray/BlockDist.x10"
        final boolean t$148896 = ((long) t$148894) == ((long) 1L);
        
        //#line 160 "x10/regionarray/BlockDist.x10"
        if (t$148896) {
            
            //#line 160 "x10/regionarray/BlockDist.x10"
            final x10.lang.Place t$148895 = this.mapIndexToPlace((long)(i1));
            
            //#line 160 "x10/regionarray/BlockDist.x10"
            return t$148895;
        }
        
        //#line 161 "x10/regionarray/BlockDist.x10"
        final x10.lang.Place t$148897 = this.mapIndexToPlace((long)(i2));
        
        //#line 161 "x10/regionarray/BlockDist.x10"
        return t$148897;
    }
    
    
    //#line 164 "x10/regionarray/BlockDist.x10"
    public x10.lang.Place $apply(final long i0, final long i1, final long i2, final long i3) {
        
        //#line 165 "x10/regionarray/BlockDist.x10"
        final x10.regionarray.Region t$148900 = ((x10.regionarray.Region)(this.region));
        
        //#line 165 "x10/regionarray/BlockDist.x10"
        final boolean t$148901 = t$148900.contains$O((long)(i0), (long)(i1), (long)(i2), (long)(i3));
        
        //#line 165 "x10/regionarray/BlockDist.x10"
        final boolean t$148902 = !(t$148901);
        
        //#line 165 "x10/regionarray/BlockDist.x10"
        if (t$148902) {
            
            //#line 165 "x10/regionarray/BlockDist.x10"
            x10.regionarray.Dist.raiseBoundsError((long)(i0), (long)(i1), (long)(i2), (long)(i3));
        }
        
        //#line 166 "x10/regionarray/BlockDist.x10"
        final long t$148903 = this.axis;
        
        //#line 166 "x10/regionarray/BlockDist.x10"
        final boolean t$148905 = ((long) t$148903) == ((long) 0L);
        
        //#line 166 "x10/regionarray/BlockDist.x10"
        if (t$148905) {
            
            //#line 166 "x10/regionarray/BlockDist.x10"
            final x10.lang.Place t$148904 = this.mapIndexToPlace((long)(i0));
            
            //#line 166 "x10/regionarray/BlockDist.x10"
            return t$148904;
        }
        
        //#line 167 "x10/regionarray/BlockDist.x10"
        final long t$148906 = this.axis;
        
        //#line 167 "x10/regionarray/BlockDist.x10"
        final boolean t$148908 = ((long) t$148906) == ((long) 1L);
        
        //#line 167 "x10/regionarray/BlockDist.x10"
        if (t$148908) {
            
            //#line 167 "x10/regionarray/BlockDist.x10"
            final x10.lang.Place t$148907 = this.mapIndexToPlace((long)(i1));
            
            //#line 167 "x10/regionarray/BlockDist.x10"
            return t$148907;
        }
        
        //#line 168 "x10/regionarray/BlockDist.x10"
        final long t$148909 = this.axis;
        
        //#line 168 "x10/regionarray/BlockDist.x10"
        final boolean t$148911 = ((long) t$148909) == ((long) 2L);
        
        //#line 168 "x10/regionarray/BlockDist.x10"
        if (t$148911) {
            
            //#line 168 "x10/regionarray/BlockDist.x10"
            final x10.lang.Place t$148910 = this.mapIndexToPlace((long)(i2));
            
            //#line 168 "x10/regionarray/BlockDist.x10"
            return t$148910;
        }
        
        //#line 169 "x10/regionarray/BlockDist.x10"
        final x10.lang.Place t$148912 = this.mapIndexToPlace((long)(i3));
        
        //#line 169 "x10/regionarray/BlockDist.x10"
        return t$148912;
    }
    
    
    //#line 172 "x10/regionarray/BlockDist.x10"
    public x10.regionarray.Dist restriction(final x10.regionarray.Region r) {
        
        //#line 173 "x10/regionarray/BlockDist.x10"
        final x10.regionarray.WrappedDistRegionRestricted alloc$148481 = ((x10.regionarray.WrappedDistRegionRestricted)(new x10.regionarray.WrappedDistRegionRestricted((java.lang.System[]) null)));
        
        //#line 173 "x10/regionarray/BlockDist.x10"
        alloc$148481.x10$regionarray$WrappedDistRegionRestricted$$init$S(((x10.regionarray.Dist)(this)), ((x10.regionarray.Region)(r)));
        
        //#line 173 "x10/regionarray/BlockDist.x10"
        return alloc$148481;
    }
    
    
    //#line 176 "x10/regionarray/BlockDist.x10"
    public x10.regionarray.Dist restriction(final x10.lang.Place p) {
        
        //#line 177 "x10/regionarray/BlockDist.x10"
        final x10.regionarray.WrappedDistPlaceRestricted alloc$148482 = ((x10.regionarray.WrappedDistPlaceRestricted)(new x10.regionarray.WrappedDistPlaceRestricted((java.lang.System[]) null)));
        
        //#line 177 "x10/regionarray/BlockDist.x10"
        alloc$148482.x10$regionarray$WrappedDistPlaceRestricted$$init$S(((x10.regionarray.Dist)(this)), ((x10.lang.Place)(p)));
        
        //#line 177 "x10/regionarray/BlockDist.x10"
        return alloc$148482;
    }
    
    
    //#line 180 "x10/regionarray/BlockDist.x10"
    public x10.regionarray.BlockDistGhostManager getLocalGhostManager(final long ghostWidth, final boolean periodic) {
        
        //#line 181 "x10/regionarray/BlockDist.x10"
        final x10.regionarray.BlockDistGhostManager alloc$148483 = ((x10.regionarray.BlockDistGhostManager)(new x10.regionarray.BlockDistGhostManager((java.lang.System[]) null)));
        
        //#line 181 "x10/regionarray/BlockDist.x10"
        alloc$148483.x10$regionarray$BlockDistGhostManager$$init$S(((long)(ghostWidth)), ((x10.regionarray.BlockDist)(this)), ((boolean)(periodic)));
        
        //#line 181 "x10/regionarray/BlockDist.x10"
        return alloc$148483;
    }
    
    
    //#line 184 "x10/regionarray/BlockDist.x10"
    public boolean equals(final java.lang.Object thatObj) {
        
        //#line 185 "x10/regionarray/BlockDist.x10"
        final boolean t$148913 = x10.rtt.Equality.equalsequals((this),(thatObj));
        
        //#line 185 "x10/regionarray/BlockDist.x10"
        if (t$148913) {
            
            //#line 185 "x10/regionarray/BlockDist.x10"
            return true;
        }
        
        //#line 186 "x10/regionarray/BlockDist.x10"
        final boolean t$148914 = x10.regionarray.BlockDist.$RTT.isInstance(thatObj);
        
        //#line 186 "x10/regionarray/BlockDist.x10"
        final boolean t$148916 = !(t$148914);
        
        //#line 186 "x10/regionarray/BlockDist.x10"
        if (t$148916) {
            
            //#line 186 "x10/regionarray/BlockDist.x10"
            final boolean t$148915 = super.equals(((java.lang.Object)(thatObj)));
            
            //#line 186 "x10/regionarray/BlockDist.x10"
            return t$148915;
        }
        
        //#line 187 "x10/regionarray/BlockDist.x10"
        final x10.regionarray.BlockDist that = ((x10.regionarray.BlockDist)(x10.rtt.Types.<x10.regionarray.BlockDist> cast(thatObj,x10.regionarray.BlockDist.$RTT)));
        
        //#line 188 "x10/regionarray/BlockDist.x10"
        final long t$148917 = this.axis;
        
        //#line 188 "x10/regionarray/BlockDist.x10"
        final long t$148918 = that.axis;
        
        //#line 188 "x10/regionarray/BlockDist.x10"
        boolean t$148921 = x10.rtt.Equality.equalsequals(t$148917, ((long)(t$148918)));
        
        //#line 188 "x10/regionarray/BlockDist.x10"
        if (t$148921) {
            
            //#line 188 "x10/regionarray/BlockDist.x10"
            final x10.regionarray.Region t$148919 = ((x10.regionarray.Region)(this.region));
            
            //#line 188 "x10/regionarray/BlockDist.x10"
            final x10.regionarray.Region t$148920 = ((x10.regionarray.Region)(that.region));
            
            //#line 188 "x10/regionarray/BlockDist.x10"
            t$148921 = t$148919.equals(((java.lang.Object)(t$148920)));
        }
        
        //#line 188 "x10/regionarray/BlockDist.x10"
        return t$148921;
    }
    
    
    //#line 28 "x10/regionarray/BlockDist.x10"
    final public x10.regionarray.BlockDist x10$regionarray$BlockDist$$this$x10$regionarray$BlockDist() {
        
        //#line 28 "x10/regionarray/BlockDist.x10"
        return x10.regionarray.BlockDist.this;
    }
    
    
    //#line 28 "x10/regionarray/BlockDist.x10"
    final public void __fieldInitializers_x10_regionarray_BlockDist() {
        
        //#line 28 "x10/regionarray/BlockDist.x10"
        this.regionForHere = null;
    }
    
    @x10.runtime.impl.java.X10Generated
    final public static class $Closure$208 extends x10.core.Ref implements x10.core.fun.Fun_0_1, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<$Closure$208> $RTT = 
            x10.rtt.StaticFunType.<$Closure$208> make($Closure$208.class,
                                                      new x10.rtt.Type[] {
                                                          x10.rtt.ParameterizedType.make(x10.core.fun.Fun_0_1.$RTT, x10.rtt.Types.LONG, x10.rtt.Types.LONG)
                                                      });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static x10.serialization.X10JavaSerializable $_deserialize_body(x10.regionarray.BlockDist.$Closure$208 $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            $_obj.out$$ = $deserializer.readObject();
            $_obj.region = $deserializer.readObject();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.regionarray.BlockDist.$Closure$208 $_obj = new x10.regionarray.BlockDist.$Closure$208((java.lang.System[]) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            $serializer.write(this.out$$);
            $serializer.write(this.region);
            
        }
        
        // constructor just for allocation
        public $Closure$208(final java.lang.System[] $dummy) {
            
        }
        
        // dispatcher for method abstract public (Z1)=>U.operator()(a1:Z1):U
        public java.lang.Object $apply(final java.lang.Object a1, final x10.rtt.Type t1) {
            return x10.core.Long.$box($apply$O(x10.core.Long.$unbox(a1)));
            
        }
        
        // dispatcher for method abstract public (Z1)=>U.operator()(a1:Z1):U
        public long $apply$J(final java.lang.Object a1, final x10.rtt.Type t1) {
            return $apply$O(x10.core.Long.$unbox(a1));
            
        }
        
        
    
        
        public long $apply$O(final long i) {
            
            //#line 74 "x10/regionarray/BlockDist.x10"
            final x10.regionarray.Region t$148789 = ((x10.regionarray.Region)(this.region));
            
            //#line 74 "x10/regionarray/BlockDist.x10"
            final long t$148790 = t$148789.min$O((long)(i));
            
            //#line 74 "x10/regionarray/BlockDist.x10"
            return t$148790;
        }
        
        public x10.regionarray.BlockDist out$$;
        public x10.regionarray.Region region;
        
        public $Closure$208(final x10.regionarray.BlockDist out$$, final x10.regionarray.Region region) {
             {
                this.out$$ = out$$;
                this.region = ((x10.regionarray.Region)(region));
            }
        }
        
    }
    
    @x10.runtime.impl.java.X10Generated
    final public static class $Closure$209 extends x10.core.Ref implements x10.core.fun.Fun_0_1, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<$Closure$209> $RTT = 
            x10.rtt.StaticFunType.<$Closure$209> make($Closure$209.class,
                                                      new x10.rtt.Type[] {
                                                          x10.rtt.ParameterizedType.make(x10.core.fun.Fun_0_1.$RTT, x10.rtt.Types.LONG, x10.rtt.Types.LONG)
                                                      });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static x10.serialization.X10JavaSerializable $_deserialize_body(x10.regionarray.BlockDist.$Closure$209 $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            $_obj.out$$ = $deserializer.readObject();
            $_obj.region = $deserializer.readObject();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.regionarray.BlockDist.$Closure$209 $_obj = new x10.regionarray.BlockDist.$Closure$209((java.lang.System[]) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            $serializer.write(this.out$$);
            $serializer.write(this.region);
            
        }
        
        // constructor just for allocation
        public $Closure$209(final java.lang.System[] $dummy) {
            
        }
        
        // dispatcher for method abstract public (Z1)=>U.operator()(a1:Z1):U
        public java.lang.Object $apply(final java.lang.Object a1, final x10.rtt.Type t1) {
            return x10.core.Long.$box($apply$O(x10.core.Long.$unbox(a1)));
            
        }
        
        // dispatcher for method abstract public (Z1)=>U.operator()(a1:Z1):U
        public long $apply$J(final java.lang.Object a1, final x10.rtt.Type t1) {
            return $apply$O(x10.core.Long.$unbox(a1));
            
        }
        
        
    
        
        public long $apply$O(final long i) {
            
            //#line 75 "x10/regionarray/BlockDist.x10"
            final x10.regionarray.Region t$148794 = ((x10.regionarray.Region)(this.region));
            
            //#line 75 "x10/regionarray/BlockDist.x10"
            final long t$148795 = t$148794.max$O((long)(i));
            
            //#line 75 "x10/regionarray/BlockDist.x10"
            return t$148795;
        }
        
        public x10.regionarray.BlockDist out$$;
        public x10.regionarray.Region region;
        
        public $Closure$209(final x10.regionarray.BlockDist out$$, final x10.regionarray.Region region) {
             {
                this.out$$ = out$$;
                this.region = ((x10.regionarray.Region)(region));
            }
        }
        
    }
    
    @x10.runtime.impl.java.X10Generated
    final public static class $Closure$210 extends x10.core.Ref implements x10.core.fun.Fun_0_1, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<$Closure$210> $RTT = 
            x10.rtt.StaticFunType.<$Closure$210> make($Closure$210.class,
                                                      new x10.rtt.Type[] {
                                                          x10.rtt.ParameterizedType.make(x10.core.fun.Fun_0_1.$RTT, x10.rtt.Types.LONG, x10.regionarray.Region.$RTT)
                                                      });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static x10.serialization.X10JavaSerializable $_deserialize_body(x10.regionarray.BlockDist.$Closure$210 $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            $_obj.out$$ = $deserializer.readObject();
            $_obj.pg = $deserializer.readObject();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.regionarray.BlockDist.$Closure$210 $_obj = new x10.regionarray.BlockDist.$Closure$210((java.lang.System[]) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            $serializer.write(this.out$$);
            $serializer.write(this.pg);
            
        }
        
        // constructor just for allocation
        public $Closure$210(final java.lang.System[] $dummy) {
            
        }
        
        // dispatcher for method abstract public (Z1)=>U.operator()(a1:Z1):U
        public java.lang.Object $apply(final java.lang.Object a1, final x10.rtt.Type t1) {
            return $apply(x10.core.Long.$unbox(a1));
            
        }
        
        
    
        
        public x10.regionarray.Region $apply(final long i) {
            
            //#line 122 "x10/regionarray/BlockDist.x10"
            final x10.lang.PlaceGroup t$148850 = ((x10.lang.PlaceGroup)(this.pg));
            
            //#line 122 "x10/regionarray/BlockDist.x10"
            final x10.lang.Place t$148851 = t$148850.$apply((long)(i));
            
            //#line 122 "x10/regionarray/BlockDist.x10"
            final x10.regionarray.Region t$148852 = ((x10.regionarray.Region)(this.out$$.blockRegionForPlace(((x10.lang.Place)(t$148851)))));
            
            //#line 122 "x10/regionarray/BlockDist.x10"
            return t$148852;
        }
        
        public x10.regionarray.BlockDist out$$;
        public x10.lang.PlaceGroup pg;
        
        public $Closure$210(final x10.regionarray.BlockDist out$$, final x10.lang.PlaceGroup pg) {
             {
                this.out$$ = out$$;
                this.pg = ((x10.lang.PlaceGroup)(pg));
            }
        }
        
    }
    
    
    public boolean x10$regionarray$Dist$equals$S$O(final java.lang.Object a0) {
        return super.equals(((java.lang.Object)(a0)));
    }
}

