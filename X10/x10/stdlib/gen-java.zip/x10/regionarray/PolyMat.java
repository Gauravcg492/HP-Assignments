package x10.regionarray;


/**
 * A PolyMat is a set of linear inequalisty constraints represented as
 * a constraint matrix. Each row is represented as a PolyRow
 * object. The constraint matrix represents a set of points defined as
 * the intersection of the halfspaces represented by each PolyRow in
 * the PolyMat, or equivalently, as the set of points satisfying the
 * conjunction of the linear inequalities represented by each PolyRow
 * object.
 */
@x10.runtime.impl.java.X10Generated
public class PolyMat extends x10.regionarray.Mat<x10.regionarray.PolyRow> implements x10.serialization.X10JavaSerializable
{
    public static final x10.rtt.RuntimeType<PolyMat> $RTT = 
        x10.rtt.NamedType.<PolyMat> make("x10.regionarray.PolyMat",
                                         PolyMat.class,
                                         new x10.rtt.Type[] {
                                             x10.rtt.ParameterizedType.make(x10.regionarray.Mat.$RTT, x10.regionarray.PolyRow.$RTT)
                                         });
    
    public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
    
    public x10.rtt.Type<?> $getParam(int i) { return null; }
    
    private Object writeReplace() throws java.io.ObjectStreamException {
        return new x10.serialization.SerializationProxy(this);
    }
    
    public static x10.serialization.X10JavaSerializable $_deserialize_body(x10.regionarray.PolyMat $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
        x10.regionarray.Mat.$_deserialize_body($_obj, $deserializer);
        $_obj.isSimplified = $deserializer.readBoolean();
        $_obj.rank = $deserializer.readLong();
        return $_obj;
    }
    
    public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
        x10.regionarray.PolyMat $_obj = new x10.regionarray.PolyMat((java.lang.System[]) null);
        $deserializer.record_reference($_obj);
        return $_deserialize_body($_obj, $deserializer);
    }
    
    public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
        super.$_serialize($serializer);
        $serializer.write(this.isSimplified);
        $serializer.write(this.rank);
        
    }
    
    // constructor just for allocation
    public PolyMat(final java.lang.System[] $dummy) {
        super($dummy, x10.regionarray.PolyRow.$RTT);
        
    }
    
    // bridge for inherited method public x10.regionarray.Mat[T].operator()(i:x10.lang.Int){}:T
    public x10.regionarray.PolyRow $apply(int a1){
        return super.$apply$G((a1));
    }
    
    // synthetic type for parameter mangling
    public static final class __2$1x10$lang$Int$3x10$lang$Int$3x10$lang$Int$2 {}
    
    // properties
    
    //#line 26 "x10/regionarray/PolyMat.x10"
    public long rank;
    

    
    //#line 32 "x10/regionarray/PolyMat.x10"
    public boolean isSimplified;
    
    
    //#line 39 "x10/regionarray/PolyMat.x10"
    /**
     * Low-level constructor. For greater convenience use PolyMatBuilder.
     */
    // creation method for java code (1-phase java constructor)
    public PolyMat(final int rows, final int cols, final x10.core.fun.Fun_0_2<x10.core.Int,x10.core.Int,x10.core.Int> init, final boolean isSimplified, __2$1x10$lang$Int$3x10$lang$Int$3x10$lang$Int$2 $dummy) {
        this((java.lang.System[]) null);
        x10$regionarray$PolyMat$$init$S(rows, cols, init, isSimplified, (x10.regionarray.PolyMat.__2$1x10$lang$Int$3x10$lang$Int$3x10$lang$Int$2) null);
    }
    
    // constructor for non-virtual call
    final public x10.regionarray.PolyMat x10$regionarray$PolyMat$$init$S(final int rows, final int cols, final x10.core.fun.Fun_0_2<x10.core.Int,x10.core.Int,x10.core.Int> init, final boolean isSimplified, __2$1x10$lang$Int$3x10$lang$Int$3x10$lang$Int$2 $dummy) {
         {
            
            //#line 40 "x10/regionarray/PolyMat.x10"
            final x10.regionarray.Mat this$153389 = ((x10.regionarray.Mat)(this));
            
            //#line 40 "x10/regionarray/PolyMat.x10"
            final int rows$153386 = rows;
            
            //#line 40 "x10/regionarray/PolyMat.x10"
            final int cols$153387 = cols;
            
            //#line 40 "x10/regionarray/PolyMat.x10"
            final long t$153492 = ((long)(((int)(rows))));
            
            //#line 40 "x10/regionarray/PolyMat.x10"
            final x10.core.fun.Fun_0_1 t$153493 = ((x10.core.fun.Fun_0_1)(new x10.regionarray.PolyMat.$Closure$249(init, cols, (x10.regionarray.PolyMat.$Closure$249.__0$1x10$lang$Int$3x10$lang$Int$3x10$lang$Int$2) null)));
            
            //#line 40 "x10/regionarray/PolyMat.x10"
            final x10.core.Rail mat$153388 = ((x10.core.Rail)(new x10.core.Rail<x10.regionarray.PolyRow>(x10.regionarray.PolyRow.$RTT, t$153492, ((x10.core.fun.Fun_0_1)(t$153493)), (x10.core.Rail.__1$1x10$lang$Long$3x10$lang$Rail$$T$2) null)));
            
            //#line 22 . "x10/regionarray/Mat.x10"
            ((x10.regionarray.Mat<x10.regionarray.PolyRow>)this$153389).rows = rows$153386;
            
            //#line 22 . "x10/regionarray/Mat.x10"
            ((x10.regionarray.Mat<x10.regionarray.PolyRow>)this$153389).cols = cols$153387;
            
            //#line 23 . "x10/regionarray/Mat.x10"
            ((x10.regionarray.Mat<x10.regionarray.PolyRow>)this$153389).mat = ((x10.core.Rail)(mat$153388));
            
            //#line 41 "x10/regionarray/PolyMat.x10"
            final int cols1 = ((cols) - (((int)(1))));
            
            //#line 42 "x10/regionarray/PolyMat.x10"
            final long t$153708 = ((long)(((int)(cols1))));
            
            //#line 42 "x10/regionarray/PolyMat.x10"
            this.rank = t$153708;
            
            
            //#line 43 "x10/regionarray/PolyMat.x10"
            this.isSimplified = isSimplified;
        }
        return this;
    }
    
    
    
    //#line 55 "x10/regionarray/PolyMat.x10"
    /**
     * Eliminate redundant parallel halfspaces. Since halfspaces
     * with equal coefficients are sorted in increasing order of
     * the constant (which is the least significant part of the
     * key) taking the last of a set of parallel halfspaces
     * captures the strongest halfspace.
     */
    public x10.regionarray.PolyMat simplifyParallel() {
        
        //#line 57 "x10/regionarray/PolyMat.x10"
        final int t$153495 = this.rows;
        
        //#line 57 "x10/regionarray/PolyMat.x10"
        final boolean t$153496 = ((int) t$153495) == ((int) 0);
        
        //#line 57 "x10/regionarray/PolyMat.x10"
        if (t$153496) {
            
            //#line 58 "x10/regionarray/PolyMat.x10"
            return this;
        }
        
        //#line 60 "x10/regionarray/PolyMat.x10"
        final x10.regionarray.PolyMatBuilder pmb = ((x10.regionarray.PolyMatBuilder)(new x10.regionarray.PolyMatBuilder((java.lang.System[]) null)));
        
        //#line 60 "x10/regionarray/PolyMat.x10"
        final long t$153717 = this.rank;
        
        //#line 60 "x10/regionarray/PolyMat.x10"
        pmb.x10$regionarray$PolyMatBuilder$$init$S(((long)(t$153717)));
        
        //#line 61 "x10/regionarray/PolyMat.x10"
        x10.regionarray.PolyRow last = null;
        
        //#line 62 "x10/regionarray/PolyMat.x10"
        final x10.lang.Iterator next$153718 = this.iterator();
        
        //#line 62 "x10/regionarray/PolyMat.x10"
        for (;
             true;
             ) {
            
            //#line 62 "x10/regionarray/PolyMat.x10"
            final boolean t$153719 = ((x10.lang.Iterator<x10.regionarray.PolyRow>)next$153718).hasNext$O();
            
            //#line 62 "x10/regionarray/PolyMat.x10"
            if (!(t$153719)) {
                
                //#line 62 "x10/regionarray/PolyMat.x10"
                break;
            }
            
            //#line 62 "x10/regionarray/PolyMat.x10"
            final x10.regionarray.PolyRow next$153710 = ((x10.lang.Iterator<x10.regionarray.PolyRow>)next$153718).next$G();
            
            //#line 63 "x10/regionarray/PolyMat.x10"
            boolean t$153712 = ((last) != (null));
            
            //#line 63 "x10/regionarray/PolyMat.x10"
            if (t$153712) {
                
                //#line 63 "x10/regionarray/PolyMat.x10"
                final boolean t$153714 = next$153710.isParallel$O(((x10.regionarray.PolyRow)(last)));
                
                //#line 63 "x10/regionarray/PolyMat.x10"
                t$153712 = !(t$153714);
            }
            
            //#line 63 "x10/regionarray/PolyMat.x10"
            if (t$153712) {
                
                //#line 64 "x10/regionarray/PolyMat.x10"
                pmb.add(((x10.regionarray.Row)(last)));
            }
            
            //#line 65 "x10/regionarray/PolyMat.x10"
            last = ((x10.regionarray.PolyRow)(next$153710));
        }
        
        //#line 67 "x10/regionarray/PolyMat.x10"
        pmb.add(((x10.regionarray.Row)(last)));
        
        //#line 69 "x10/regionarray/PolyMat.x10"
        final x10.regionarray.PolyMat t$153507 = ((x10.regionarray.PolyMat)(pmb.toSortedPolyMat((boolean)(false))));
        
        //#line 69 "x10/regionarray/PolyMat.x10"
        return t$153507;
    }
    
    
    //#line 82 "x10/regionarray/PolyMat.x10"
    /**
     * Determine whether a halfspace is redundant by reductio ad
     * absurdum: assume the negation of H, and if the result is the
     * empty set then H is implied by the other halfspaces.
     *
     * This is guaranteed to remove redundant halfspaces, but it may
     * be expensive.
     */
    public x10.regionarray.PolyMat simplifyAll() {
        
        //#line 84 "x10/regionarray/PolyMat.x10"
        final boolean t$153508 = this.isSimplified;
        
        //#line 84 "x10/regionarray/PolyMat.x10"
        if (t$153508) {
            
            //#line 85 "x10/regionarray/PolyMat.x10"
            return this;
        }
        
        //#line 87 "x10/regionarray/PolyMat.x10"
        final x10.regionarray.PolyMatBuilder pmb = ((x10.regionarray.PolyMatBuilder)(new x10.regionarray.PolyMatBuilder((java.lang.System[]) null)));
        
        //#line 87 "x10/regionarray/PolyMat.x10"
        final long t$153747 = this.rank;
        
        //#line 87 "x10/regionarray/PolyMat.x10"
        pmb.x10$regionarray$PolyMatBuilder$$init$S(((long)(t$153747)));
        
        //#line 88 "x10/regionarray/PolyMat.x10"
        final int t$153510 = this.rows;
        
        //#line 88 "x10/regionarray/PolyMat.x10"
        final long t$153511 = ((long)(((int)(t$153510))));
        
        //#line 88 "x10/regionarray/PolyMat.x10"
        final x10.core.Rail removed = ((x10.core.Rail)(new x10.core.Rail<x10.core.Boolean>(x10.rtt.Types.BOOLEAN, t$153511, (x10.core.Boolean.$box(false)), (x10.core.Rail.__1x10$lang$Rail$$T) null)));
        
        //#line 90 "x10/regionarray/PolyMat.x10"
        int i$153748 = 0;
        {
            
            //#line 90 "x10/regionarray/PolyMat.x10"
            final boolean[] removed$value$153900 = ((boolean[])removed.value);
            
            //#line 90 "x10/regionarray/PolyMat.x10"
            for (;
                 true;
                 ) {
                
                //#line 90 "x10/regionarray/PolyMat.x10"
                final int t$153750 = this.rows;
                
                //#line 90 "x10/regionarray/PolyMat.x10"
                final boolean t$153751 = ((i$153748) < (((int)(t$153750))));
                
                //#line 90 "x10/regionarray/PolyMat.x10"
                if (!(t$153751)) {
                    
                    //#line 90 "x10/regionarray/PolyMat.x10"
                    break;
                }
                
                //#line 91 "x10/regionarray/PolyMat.x10"
                final x10.regionarray.PolyRow r$153738 = this.$apply$G((int)(i$153748));
                
                //#line 92 "x10/regionarray/PolyMat.x10"
                final x10.regionarray.PolyMatBuilder trial$153739 = ((x10.regionarray.PolyMatBuilder)(new x10.regionarray.PolyMatBuilder((java.lang.System[]) null)));
                
                //#line 92 "x10/regionarray/PolyMat.x10"
                final long t$153732 = this.rank;
                
                //#line 92 "x10/regionarray/PolyMat.x10"
                trial$153739.x10$regionarray$PolyMatBuilder$$init$S(((long)(t$153732)));
                
                //#line 93 "x10/regionarray/PolyMat.x10"
                int j$153733 = 0;
                {
                    
                    //#line 93 "x10/regionarray/PolyMat.x10"
                    for (;
                         true;
                         ) {
                        
                        //#line 93 "x10/regionarray/PolyMat.x10"
                        final int t$153735 = this.rows;
                        
                        //#line 93 "x10/regionarray/PolyMat.x10"
                        final boolean t$153736 = ((j$153733) < (((int)(t$153735))));
                        
                        //#line 93 "x10/regionarray/PolyMat.x10"
                        if (!(t$153736)) {
                            
                            //#line 93 "x10/regionarray/PolyMat.x10"
                            break;
                        }
                        
                        //#line 94 "x10/regionarray/PolyMat.x10"
                        final long t$153721 = ((long)(((int)(j$153733))));
                        
                        //#line 94 "x10/regionarray/PolyMat.x10"
                        final boolean t$153722 = ((boolean)removed$value$153900[(int)t$153721]);
                        
                        //#line 94 "x10/regionarray/PolyMat.x10"
                        final boolean t$153723 = !(t$153722);
                        
                        //#line 94 "x10/regionarray/PolyMat.x10"
                        if (t$153723) {
                            
                            //#line 95 "x10/regionarray/PolyMat.x10"
                            final boolean t$153726 = ((int) i$153748) == ((int) j$153733);
                            
                            //#line 95 "x10/regionarray/PolyMat.x10"
                            x10.regionarray.PolyRow t$153727 =  null;
                            
                            //#line 95 "x10/regionarray/PolyMat.x10"
                            if (t$153726) {
                                
                                //#line 95 "x10/regionarray/PolyMat.x10"
                                t$153727 = r$153738.complement();
                            } else {
                                
                                //#line 95 "x10/regionarray/PolyMat.x10"
                                t$153727 = this.$apply$G((int)(j$153733));
                            }
                            
                            //#line 95 "x10/regionarray/PolyMat.x10"
                            trial$153739.add(((x10.regionarray.Row)(t$153727)));
                        }
                        
                        //#line 93 "x10/regionarray/PolyMat.x10"
                        final int t$153731 = ((j$153733) + (((int)(1))));
                        
                        //#line 93 "x10/regionarray/PolyMat.x10"
                        j$153733 = t$153731;
                    }
                }
                
                //#line 96 "x10/regionarray/PolyMat.x10"
                final x10.regionarray.PolyMat t$153740 = ((x10.regionarray.PolyMat)(trial$153739.toSortedPolyMat((boolean)(false))));
                
                //#line 96 "x10/regionarray/PolyMat.x10"
                final boolean t$153741 = t$153740.isEmpty$O();
                
                //#line 96 "x10/regionarray/PolyMat.x10"
                final boolean t$153742 = !(t$153741);
                
                //#line 96 "x10/regionarray/PolyMat.x10"
                if (t$153742) {
                    
                    //#line 97 "x10/regionarray/PolyMat.x10"
                    pmb.add(((x10.regionarray.Row)(r$153738)));
                } else {
                    
                    //#line 99 "x10/regionarray/PolyMat.x10"
                    final long t$153744 = ((long)(((int)(i$153748))));
                    
                    //#line 99 "x10/regionarray/PolyMat.x10"
                    removed$value$153900[(int)t$153744]=true;
                }
                
                //#line 90 "x10/regionarray/PolyMat.x10"
                final int t$153746 = ((i$153748) + (((int)(1))));
                
                //#line 90 "x10/regionarray/PolyMat.x10"
                i$153748 = t$153746;
            }
        }
        
        //#line 102 "x10/regionarray/PolyMat.x10"
        final x10.regionarray.PolyMat t$153541 = ((x10.regionarray.PolyMat)(pmb.toSortedPolyMat((boolean)(true))));
        
        //#line 102 "x10/regionarray/PolyMat.x10"
        return t$153541;
    }
    
    
    //#line 122 "x10/regionarray/PolyMat.x10"
    /**
     * Apply Fourier-Motzkin Elimination to eliminate variable k:
     *
     * Copy each halfspace whose kth coefficient is already 0
     *
     * For each pair of halfspaces such that the kth coefficient is of
     * opposite sign, construct a new halfspace by adding the two
     * original halfspaces with appropriate positive multipliers to
     * obtain a halfspace with a kth coefficent of 0.
     *
     * The result is a set of halfspaces that describe the polyhedron
     * that is the projection of the polyhedron described by the
     * original halfspaces onto a rank-1 dimensional subspace obtained
     * by eliminating axis k
     */
    public x10.regionarray.PolyMat eliminate(final int k, final boolean simplifyDegenerate) {
        
        //#line 123 "x10/regionarray/PolyMat.x10"
        final x10.regionarray.PolyMatBuilder pmb = ((x10.regionarray.PolyMatBuilder)(new x10.regionarray.PolyMatBuilder((java.lang.System[]) null)));
        
        //#line 123 "x10/regionarray/PolyMat.x10"
        final long t$153825 = this.rank;
        
        //#line 123 "x10/regionarray/PolyMat.x10"
        pmb.x10$regionarray$PolyMatBuilder$$init$S(((long)(t$153825)));
        
        //#line 124 "x10/regionarray/PolyMat.x10"
        final x10.lang.Iterator ir$153826 = this.iterator();
        
        //#line 124 "x10/regionarray/PolyMat.x10"
        for (;
             true;
             ) {
            
            //#line 124 "x10/regionarray/PolyMat.x10"
            final boolean t$153827 = ((x10.lang.Iterator<x10.regionarray.PolyRow>)ir$153826).hasNext$O();
            
            //#line 124 "x10/regionarray/PolyMat.x10"
            if (!(t$153827)) {
                
                //#line 124 "x10/regionarray/PolyMat.x10"
                break;
            }
            
            //#line 124 "x10/regionarray/PolyMat.x10"
            final x10.regionarray.PolyRow ir$153820 = ((x10.lang.Iterator<x10.regionarray.PolyRow>)ir$153826).next$G();
            
            //#line 125 "x10/regionarray/PolyMat.x10"
            final int ia$153821 = ir$153820.$apply$O((int)(k));
            
            //#line 126 "x10/regionarray/PolyMat.x10"
            final boolean t$153822 = ((int) ia$153821) == ((int) 0);
            
            //#line 126 "x10/regionarray/PolyMat.x10"
            if (t$153822) {
                
                //#line 127 "x10/regionarray/PolyMat.x10"
                pmb.add(((x10.regionarray.Row)(ir$153820)));
            } else {
                
                //#line 129 "x10/regionarray/PolyMat.x10"
                final x10.lang.Iterator jr$153823 = this.iterator();
                
                //#line 129 "x10/regionarray/PolyMat.x10"
                for (;
                     true;
                     ) {
                    
                    //#line 129 "x10/regionarray/PolyMat.x10"
                    final boolean t$153824 = ((x10.lang.Iterator<x10.regionarray.PolyRow>)jr$153823).hasNext$O();
                    
                    //#line 129 "x10/regionarray/PolyMat.x10"
                    if (!(t$153824)) {
                        
                        //#line 129 "x10/regionarray/PolyMat.x10"
                        break;
                    }
                    
                    //#line 129 "x10/regionarray/PolyMat.x10"
                    final x10.regionarray.PolyRow jr$153786 = ((x10.lang.Iterator<x10.regionarray.PolyRow>)jr$153823).next$G();
                    
                    //#line 130 "x10/regionarray/PolyMat.x10"
                    final int ja$153787 = jr$153786.$apply$O((int)(k));
                    
                    //#line 131 "x10/regionarray/PolyMat.x10"
                    final long t$153788 = this.rank;
                    
                    //#line 131 "x10/regionarray/PolyMat.x10"
                    final long t$153789 = ((long)(((int)(1))));
                    
                    //#line 131 "x10/regionarray/PolyMat.x10"
                    final long t$153790 = ((t$153788) + (((long)(t$153789))));
                    
                    //#line 131 "x10/regionarray/PolyMat.x10"
                    final x10.core.Rail as_$153791 = ((x10.core.Rail)(new x10.core.Rail<x10.core.Int>(x10.rtt.Types.INT, t$153790)));
                    
                    //#line 132 "x10/regionarray/PolyMat.x10"
                    boolean t$153792 = ((ia$153821) > (((int)(0))));
                    
                    //#line 132 "x10/regionarray/PolyMat.x10"
                    if (t$153792) {
                        
                        //#line 132 "x10/regionarray/PolyMat.x10"
                        t$153792 = ((ja$153787) < (((int)(0))));
                    }
                    
                    //#line 132 "x10/regionarray/PolyMat.x10"
                    if (t$153792) {
                        
                        //#line 133 "x10/regionarray/PolyMat.x10"
                        int l$153794 = 0;
                        {
                            
                            //#line 133 "x10/regionarray/PolyMat.x10"
                            final int[] as_$153791$value$153901 = ((int[])as_$153791.value);
                            
                            //#line 133 "x10/regionarray/PolyMat.x10"
                            for (;
                                 true;
                                 ) {
                                
                                //#line 133 "x10/regionarray/PolyMat.x10"
                                final long t$153796 = ((long)(((int)(l$153794))));
                                
                                //#line 133 "x10/regionarray/PolyMat.x10"
                                final long t$153797 = this.rank;
                                
                                //#line 133 "x10/regionarray/PolyMat.x10"
                                final boolean t$153798 = ((t$153796) <= (((long)(t$153797))));
                                
                                //#line 133 "x10/regionarray/PolyMat.x10"
                                if (!(t$153798)) {
                                    
                                    //#line 133 "x10/regionarray/PolyMat.x10"
                                    break;
                                }
                                
                                //#line 134 "x10/regionarray/PolyMat.x10"
                                final long t$153753 = ((long)(((int)(l$153794))));
                                
                                //#line 134 "x10/regionarray/PolyMat.x10"
                                final int t$153755 = jr$153786.$apply$O((int)(l$153794));
                                
                                //#line 134 "x10/regionarray/PolyMat.x10"
                                final int t$153756 = ((ia$153821) * (((int)(t$153755))));
                                
                                //#line 134 "x10/regionarray/PolyMat.x10"
                                final int t$153758 = ir$153820.$apply$O((int)(l$153794));
                                
                                //#line 134 "x10/regionarray/PolyMat.x10"
                                final int t$153759 = ((ja$153787) * (((int)(t$153758))));
                                
                                //#line 134 "x10/regionarray/PolyMat.x10"
                                final int t$153760 = ((t$153756) - (((int)(t$153759))));
                                
                                //#line 134 "x10/regionarray/PolyMat.x10"
                                as_$153791$value$153901[(int)t$153753]=t$153760;
                                
                                //#line 133 "x10/regionarray/PolyMat.x10"
                                final int t$153762 = ((l$153794) + (((int)(1))));
                                
                                //#line 133 "x10/regionarray/PolyMat.x10"
                                l$153794 = t$153762;
                            }
                        }
                    } else {
                        
                        //#line 135 "x10/regionarray/PolyMat.x10"
                        boolean t$153799 = ((ia$153821) < (((int)(0))));
                        
                        //#line 135 "x10/regionarray/PolyMat.x10"
                        if (t$153799) {
                            
                            //#line 135 "x10/regionarray/PolyMat.x10"
                            t$153799 = ((ja$153787) > (((int)(0))));
                        }
                        
                        //#line 135 "x10/regionarray/PolyMat.x10"
                        if (t$153799) {
                            
                            //#line 136 "x10/regionarray/PolyMat.x10"
                            int l$153801 = 0;
                            {
                                
                                //#line 136 "x10/regionarray/PolyMat.x10"
                                final int[] as_$153791$value$153902 = ((int[])as_$153791.value);
                                
                                //#line 136 "x10/regionarray/PolyMat.x10"
                                for (;
                                     true;
                                     ) {
                                    
                                    //#line 136 "x10/regionarray/PolyMat.x10"
                                    final long t$153803 = ((long)(((int)(l$153801))));
                                    
                                    //#line 136 "x10/regionarray/PolyMat.x10"
                                    final long t$153804 = this.rank;
                                    
                                    //#line 136 "x10/regionarray/PolyMat.x10"
                                    final boolean t$153805 = ((t$153803) <= (((long)(t$153804))));
                                    
                                    //#line 136 "x10/regionarray/PolyMat.x10"
                                    if (!(t$153805)) {
                                        
                                        //#line 136 "x10/regionarray/PolyMat.x10"
                                        break;
                                    }
                                    
                                    //#line 137 "x10/regionarray/PolyMat.x10"
                                    final long t$153764 = ((long)(((int)(l$153801))));
                                    
                                    //#line 137 "x10/regionarray/PolyMat.x10"
                                    final int t$153766 = ir$153820.$apply$O((int)(l$153801));
                                    
                                    //#line 137 "x10/regionarray/PolyMat.x10"
                                    final int t$153767 = ((ja$153787) * (((int)(t$153766))));
                                    
                                    //#line 137 "x10/regionarray/PolyMat.x10"
                                    final int t$153769 = jr$153786.$apply$O((int)(l$153801));
                                    
                                    //#line 137 "x10/regionarray/PolyMat.x10"
                                    final int t$153770 = ((ia$153821) * (((int)(t$153769))));
                                    
                                    //#line 137 "x10/regionarray/PolyMat.x10"
                                    final int t$153771 = ((t$153767) - (((int)(t$153770))));
                                    
                                    //#line 137 "x10/regionarray/PolyMat.x10"
                                    as_$153791$value$153902[(int)t$153764]=t$153771;
                                    
                                    //#line 136 "x10/regionarray/PolyMat.x10"
                                    final int t$153773 = ((l$153801) + (((int)(1))));
                                    
                                    //#line 136 "x10/regionarray/PolyMat.x10"
                                    l$153801 = t$153773;
                                }
                            }
                        }
                    }
                    
                    //#line 139 "x10/regionarray/PolyMat.x10"
                    long t$153806 =  0;
                    
                    //#line 139 "x10/regionarray/PolyMat.x10"
                    if (simplifyDegenerate) {
                        
                        //#line 139 "x10/regionarray/PolyMat.x10"
                        t$153806 = this.rank;
                    } else {
                        
                        //#line 139 "x10/regionarray/PolyMat.x10"
                        final long t$153807 = this.rank;
                        
                        //#line 139 "x10/regionarray/PolyMat.x10"
                        final long t$153808 = ((long)(((int)(1))));
                        
                        //#line 139 "x10/regionarray/PolyMat.x10"
                        t$153806 = ((t$153807) + (((long)(t$153808))));
                    }
                    
                    //#line 140 "x10/regionarray/PolyMat.x10"
                    boolean degenerate$153810 = true;
                    
                    //#line 141 "x10/regionarray/PolyMat.x10"
                    int l$153782 = 0;
                    {
                        
                        //#line 141 "x10/regionarray/PolyMat.x10"
                        final int[] as_$153791$value$153903 = ((int[])as_$153791.value);
                        
                        //#line 141 "x10/regionarray/PolyMat.x10"
                        for (;
                             true;
                             ) {
                            
                            //#line 141 "x10/regionarray/PolyMat.x10"
                            final long t$153784 = ((long)(((int)(l$153782))));
                            
                            //#line 141 "x10/regionarray/PolyMat.x10"
                            final boolean t$153785 = ((t$153784) < (((long)(t$153806))));
                            
                            //#line 141 "x10/regionarray/PolyMat.x10"
                            if (!(t$153785)) {
                                
                                //#line 141 "x10/regionarray/PolyMat.x10"
                                break;
                            }
                            
                            //#line 142 "x10/regionarray/PolyMat.x10"
                            final long t$153775 = ((long)(((int)(l$153782))));
                            
                            //#line 142 "x10/regionarray/PolyMat.x10"
                            final int t$153776 = ((int)as_$153791$value$153903[(int)t$153775]);
                            
                            //#line 142 "x10/regionarray/PolyMat.x10"
                            final boolean t$153777 = ((int) t$153776) != ((int) 0);
                            
                            //#line 142 "x10/regionarray/PolyMat.x10"
                            if (t$153777) {
                                
                                //#line 143 "x10/regionarray/PolyMat.x10"
                                degenerate$153810 = false;
                            }
                            
                            //#line 141 "x10/regionarray/PolyMat.x10"
                            final int t$153779 = ((l$153782) + (((int)(1))));
                            
                            //#line 141 "x10/regionarray/PolyMat.x10"
                            l$153782 = t$153779;
                        }
                    }
                    
                    //#line 144 "x10/regionarray/PolyMat.x10"
                    final boolean t$153812 = !(degenerate$153810);
                    
                    //#line 144 "x10/regionarray/PolyMat.x10"
                    if (t$153812) {
                        
                        //#line 145 "x10/regionarray/PolyMat.x10"
                        x10.regionarray.PolyRow r$153813 = new x10.regionarray.PolyRow((java.lang.System[]) null);
                        
                        //#line 145 "x10/regionarray/PolyMat.x10"
                        final long t$153814 = ((x10.core.Rail<x10.core.Int>)as_$153791).size;
                        
                        //#line 145 "x10/regionarray/PolyMat.x10"
                        final x10.core.fun.Fun_0_1 t$153815 = ((x10.core.fun.Fun_0_1)(new x10.regionarray.PolyMat.$Closure$250(as_$153791, (x10.regionarray.PolyMat.$Closure$250.__0$1x10$lang$Int$2) null)));
                        
                        //#line 145 "x10/regionarray/PolyMat.x10"
                        final x10.core.Rail as_$153818 = ((x10.core.Rail)(new x10.core.Rail<x10.core.Int>(x10.rtt.Types.INT, ((long)(t$153814)), ((x10.core.fun.Fun_0_1)(t$153815)), (x10.core.Rail.__1$1x10$lang$Long$3x10$lang$Rail$$T$2) null)));
                        
                        //#line 29 . "x10/regionarray/PolyRow.x10"
                        final long t$153780 = ((x10.core.Rail<x10.core.Int>)as_$153818).size;
                        
                        //#line 29 . "x10/regionarray/PolyRow.x10"
                        final long t$153781 = ((t$153780) - (((long)(1L))));
                        
                        //#line 29 . "x10/regionarray/PolyRow.x10"
                        r$153813.x10$regionarray$PolyRow$$init$S(((x10.core.Rail)(as_$153818)), t$153781, (x10.regionarray.PolyRow.__0$1x10$lang$Int$2) null);
                        
                        //#line 146 "x10/regionarray/PolyMat.x10"
                        pmb.add(((x10.regionarray.Row)(r$153813)));
                    }
                }
            }
        }
        
        //#line 151 "x10/regionarray/PolyMat.x10"
        final x10.regionarray.PolyMat t$153608 = ((x10.regionarray.PolyMat)(pmb.toSortedPolyMat((boolean)(false))));
        
        //#line 151 "x10/regionarray/PolyMat.x10"
        final x10.regionarray.PolyMat t$153609 = ((x10.regionarray.PolyMat)(t$153608.simplifyParallel()));
        
        //#line 151 "x10/regionarray/PolyMat.x10"
        return t$153609;
    }
    
    
    //#line 166 "x10/regionarray/PolyMat.x10"
    /**
     * Support for constructing rectangular regions: determining
     * whether or not a cl is rectangular, and computing min/max along
     * each axis if it is.
     *
     * XXX cache these for efficiency during region construction
     * XXX assume halfspaces have been sorted and simplified - check/enforce
     * XXX rectMin/Max only work if isRect is true - check/enforce
     * XXX cache rectMin/rectMax/isZeroBased for performance
     */
    public boolean isRect$O() {
        
        //#line 167 "x10/regionarray/PolyMat.x10"
        final x10.lang.Iterator r$153831 = this.iterator();
        
        //#line 167 "x10/regionarray/PolyMat.x10"
        for (;
             true;
             ) {
            
            //#line 167 "x10/regionarray/PolyMat.x10"
            final boolean t$153832 = ((x10.lang.Iterator<x10.regionarray.PolyRow>)r$153831).hasNext$O();
            
            //#line 167 "x10/regionarray/PolyMat.x10"
            if (!(t$153832)) {
                
                //#line 167 "x10/regionarray/PolyMat.x10"
                break;
            }
            
            //#line 167 "x10/regionarray/PolyMat.x10"
            final x10.regionarray.PolyRow r$153828 = ((x10.lang.Iterator<x10.regionarray.PolyRow>)r$153831).next$G();
            
            //#line 168 "x10/regionarray/PolyMat.x10"
            final boolean t$153829 = r$153828.isRect$O();
            
            //#line 168 "x10/regionarray/PolyMat.x10"
            final boolean t$153830 = !(t$153829);
            
            //#line 168 "x10/regionarray/PolyMat.x10"
            if (t$153830) {
                
                //#line 169 "x10/regionarray/PolyMat.x10"
                return false;
            }
        }
        
        //#line 171 "x10/regionarray/PolyMat.x10"
        return true;
    }
    
    
    //#line 174 "x10/regionarray/PolyMat.x10"
    public int rectMin$O(final int axis) {
        
        //#line 176 "x10/regionarray/PolyMat.x10"
        final x10.lang.Iterator r$153842 = this.iterator();
        
        //#line 176 "x10/regionarray/PolyMat.x10"
        for (;
             true;
             ) {
            
            //#line 176 "x10/regionarray/PolyMat.x10"
            final boolean t$153843 = ((x10.lang.Iterator<x10.regionarray.PolyRow>)r$153842).hasNext$O();
            
            //#line 176 "x10/regionarray/PolyMat.x10"
            if (!(t$153843)) {
                
                //#line 176 "x10/regionarray/PolyMat.x10"
                break;
            }
            
            //#line 176 "x10/regionarray/PolyMat.x10"
            final x10.regionarray.PolyRow r$153833 = ((x10.lang.Iterator<x10.regionarray.PolyRow>)r$153842).next$G();
            
            //#line 177 "x10/regionarray/PolyMat.x10"
            final int a$153834 = r$153833.$apply$O((int)(axis));
            
            //#line 178 "x10/regionarray/PolyMat.x10"
            final long t$153835 = ((long)(((int)(a$153834))));
            
            //#line 178 "x10/regionarray/PolyMat.x10"
            final boolean t$153836 = ((t$153835) < (((long)(0L))));
            
            //#line 178 "x10/regionarray/PolyMat.x10"
            if (t$153836) {
                
                //#line 179 "x10/regionarray/PolyMat.x10"
                final long t$153837 = this.rank;
                
                //#line 179 "x10/regionarray/PolyMat.x10"
                final int t$153838 = ((int)(long)(((long)(t$153837))));
                
                //#line 179 "x10/regionarray/PolyMat.x10"
                final int t$153839 = r$153833.$apply$O((int)(t$153838));
                
                //#line 179 "x10/regionarray/PolyMat.x10"
                final int t$153840 = (-(t$153839));
                
                //#line 179 "x10/regionarray/PolyMat.x10"
                final int t$153841 = ((t$153840) / (((int)(a$153834))));
                
                //#line 179 "x10/regionarray/PolyMat.x10"
                return t$153841;
            }
        }
        
        //#line 182 "x10/regionarray/PolyMat.x10"
        final java.lang.String t$153623 = (("axis ") + ((x10.core.Int.$box(axis))));
        
        //#line 182 "x10/regionarray/PolyMat.x10"
        java.lang.String msg = ((t$153623) + (" has no minimum"));
        
        //#line 183 "x10/regionarray/PolyMat.x10"
        final x10.regionarray.UnboundedRegionException t$153625 = ((x10.regionarray.UnboundedRegionException)(new x10.regionarray.UnboundedRegionException(msg)));
        
        //#line 183 "x10/regionarray/PolyMat.x10"
        throw t$153625;
    }
    
    
    //#line 186 "x10/regionarray/PolyMat.x10"
    public int rectMax$O(final int axis) {
        
        //#line 188 "x10/regionarray/PolyMat.x10"
        final x10.lang.Iterator r$153853 = this.iterator();
        
        //#line 188 "x10/regionarray/PolyMat.x10"
        for (;
             true;
             ) {
            
            //#line 188 "x10/regionarray/PolyMat.x10"
            final boolean t$153854 = ((x10.lang.Iterator<x10.regionarray.PolyRow>)r$153853).hasNext$O();
            
            //#line 188 "x10/regionarray/PolyMat.x10"
            if (!(t$153854)) {
                
                //#line 188 "x10/regionarray/PolyMat.x10"
                break;
            }
            
            //#line 188 "x10/regionarray/PolyMat.x10"
            final x10.regionarray.PolyRow r$153844 = ((x10.lang.Iterator<x10.regionarray.PolyRow>)r$153853).next$G();
            
            //#line 189 "x10/regionarray/PolyMat.x10"
            final int a$153845 = r$153844.$apply$O((int)(axis));
            
            //#line 190 "x10/regionarray/PolyMat.x10"
            final long t$153846 = ((long)(((int)(a$153845))));
            
            //#line 190 "x10/regionarray/PolyMat.x10"
            final boolean t$153847 = ((t$153846) > (((long)(0L))));
            
            //#line 190 "x10/regionarray/PolyMat.x10"
            if (t$153847) {
                
                //#line 191 "x10/regionarray/PolyMat.x10"
                final long t$153848 = this.rank;
                
                //#line 191 "x10/regionarray/PolyMat.x10"
                final int t$153849 = ((int)(long)(((long)(t$153848))));
                
                //#line 191 "x10/regionarray/PolyMat.x10"
                final int t$153850 = r$153844.$apply$O((int)(t$153849));
                
                //#line 191 "x10/regionarray/PolyMat.x10"
                final int t$153851 = (-(t$153850));
                
                //#line 191 "x10/regionarray/PolyMat.x10"
                final int t$153852 = ((t$153851) / (((int)(a$153845))));
                
                //#line 191 "x10/regionarray/PolyMat.x10"
                return t$153852;
            }
        }
        
        //#line 194 "x10/regionarray/PolyMat.x10"
        final java.lang.String t$153635 = (("axis ") + ((x10.core.Int.$box(axis))));
        
        //#line 194 "x10/regionarray/PolyMat.x10"
        final java.lang.String msg = ((t$153635) + (" has no maximum"));
        
        //#line 195 "x10/regionarray/PolyMat.x10"
        final x10.regionarray.UnboundedRegionException t$153636 = ((x10.regionarray.UnboundedRegionException)(new x10.regionarray.UnboundedRegionException(((java.lang.String)(msg)))));
        
        //#line 195 "x10/regionarray/PolyMat.x10"
        throw t$153636;
    }
    
    
    //#line 198 "x10/regionarray/PolyMat.x10"
    public x10.core.Rail rectMin() {
        
        //#line 198 "x10/regionarray/PolyMat.x10"
        final long t$153639 = this.rank;
        
        //#line 198 "x10/regionarray/PolyMat.x10"
        final x10.core.fun.Fun_0_1 t$153640 = ((x10.core.fun.Fun_0_1)(new x10.regionarray.PolyMat.$Closure$251(this)));
        
        //#line 198 "x10/regionarray/PolyMat.x10"
        final x10.core.Rail t$153641 = ((x10.core.Rail)(new x10.core.Rail<x10.core.Int>(x10.rtt.Types.INT, ((long)(t$153639)), ((x10.core.fun.Fun_0_1)(t$153640)), (x10.core.Rail.__1$1x10$lang$Long$3x10$lang$Rail$$T$2) null)));
        
        //#line 198 "x10/regionarray/PolyMat.x10"
        return t$153641;
    }
    
    
    //#line 200 "x10/regionarray/PolyMat.x10"
    public x10.core.Rail rectMax() {
        
        //#line 200 "x10/regionarray/PolyMat.x10"
        final long t$153644 = this.rank;
        
        //#line 200 "x10/regionarray/PolyMat.x10"
        final x10.core.fun.Fun_0_1 t$153645 = ((x10.core.fun.Fun_0_1)(new x10.regionarray.PolyMat.$Closure$252(this)));
        
        //#line 200 "x10/regionarray/PolyMat.x10"
        final x10.core.Rail t$153646 = ((x10.core.Rail)(new x10.core.Rail<x10.core.Int>(x10.rtt.Types.INT, ((long)(t$153644)), ((x10.core.fun.Fun_0_1)(t$153645)), (x10.core.Rail.__1$1x10$lang$Long$3x10$lang$Rail$$T$2) null)));
        
        //#line 200 "x10/regionarray/PolyMat.x10"
        return t$153646;
    }
    
    
    //#line 202 "x10/regionarray/PolyMat.x10"
    public boolean isZeroBased$O() {
        
        //#line 203 "x10/regionarray/PolyMat.x10"
        final boolean t$153647 = this.isRect$O();
        
        //#line 203 "x10/regionarray/PolyMat.x10"
        final boolean t$153648 = !(t$153647);
        
        //#line 203 "x10/regionarray/PolyMat.x10"
        if (t$153648) {
            
            //#line 204 "x10/regionarray/PolyMat.x10"
            return false;
        }
        
        //#line 205 "x10/regionarray/PolyMat.x10"
        try {{
            
            //#line 206 "x10/regionarray/PolyMat.x10"
            int i = 0;
            
            //#line 206 "x10/regionarray/PolyMat.x10"
            for (;
                 true;
                 ) {
                
                //#line 206 "x10/regionarray/PolyMat.x10"
                final long t$153651 = ((long)(((int)(i))));
                
                //#line 206 "x10/regionarray/PolyMat.x10"
                final long t$153652 = this.rank;
                
                //#line 206 "x10/regionarray/PolyMat.x10"
                final boolean t$153658 = ((t$153651) < (((long)(t$153652))));
                
                //#line 206 "x10/regionarray/PolyMat.x10"
                if (!(t$153658)) {
                    
                    //#line 206 "x10/regionarray/PolyMat.x10"
                    break;
                }
                
                //#line 207 "x10/regionarray/PolyMat.x10"
                final int t$153856 = this.rectMin$O((int)(i));
                
                //#line 207 "x10/regionarray/PolyMat.x10"
                final boolean t$153857 = ((int) t$153856) != ((int) 0);
                
                //#line 207 "x10/regionarray/PolyMat.x10"
                if (t$153857) {
                    
                    //#line 208 "x10/regionarray/PolyMat.x10"
                    return false;
                }
                
                //#line 206 "x10/regionarray/PolyMat.x10"
                final int t$153859 = ((i) + (((int)(1))));
                
                //#line 206 "x10/regionarray/PolyMat.x10"
                i = t$153859;
            }
        }}catch (final x10.regionarray.UnboundedRegionException e) {
            
            //#line 210 "x10/regionarray/PolyMat.x10"
            return false;
        }
        
        //#line 212 "x10/regionarray/PolyMat.x10"
        return true;
    }
    
    
    //#line 215 "x10/regionarray/PolyMat.x10"
    public boolean isBounded$O() {
        
        //#line 216 "x10/regionarray/PolyMat.x10"
        try {{
            
            //#line 217 "x10/regionarray/PolyMat.x10"
            int i = 0;
            
            //#line 217 "x10/regionarray/PolyMat.x10"
            for (;
                 true;
                 ) {
                
                //#line 217 "x10/regionarray/PolyMat.x10"
                final long t$153661 = ((long)(((int)(i))));
                
                //#line 217 "x10/regionarray/PolyMat.x10"
                final long t$153662 = this.rank;
                
                //#line 217 "x10/regionarray/PolyMat.x10"
                final boolean t$153667 = ((t$153661) < (((long)(t$153662))));
                
                //#line 217 "x10/regionarray/PolyMat.x10"
                if (!(t$153667)) {
                    
                    //#line 217 "x10/regionarray/PolyMat.x10"
                    break;
                }
                
                //#line 218 "x10/regionarray/PolyMat.x10"
                this.rectMin$O((int)(i));
                
                //#line 219 "x10/regionarray/PolyMat.x10"
                this.rectMax$O((int)(i));
                
                //#line 217 "x10/regionarray/PolyMat.x10"
                final int t$153863 = ((i) + (((int)(1))));
                
                //#line 217 "x10/regionarray/PolyMat.x10"
                i = t$153863;
            }
        }}catch (final x10.regionarray.UnboundedRegionException e) {
            
            //#line 222 "x10/regionarray/PolyMat.x10"
            return false;
        }
        
        //#line 224 "x10/regionarray/PolyMat.x10"
        return true;
    }
    
    
    //#line 234 "x10/regionarray/PolyMat.x10"
    /**
     * A set of halfspaces is empty iff, after eliminating all
     * variables with FME, we are left with a contradiction, i.e. a
     * halfspace k<=0 where k>0.
     */
    public boolean isEmpty$O() {
        
        //#line 236 "x10/regionarray/PolyMat.x10"
        x10.regionarray.PolyMat pm = this;
        
        //#line 237 "x10/regionarray/PolyMat.x10"
        int i$153875 = 0;
        
        //#line 237 "x10/regionarray/PolyMat.x10"
        for (;
             true;
             ) {
            
            //#line 237 "x10/regionarray/PolyMat.x10"
            final long t$153877 = ((long)(((int)(i$153875))));
            
            //#line 237 "x10/regionarray/PolyMat.x10"
            final long t$153878 = this.rank;
            
            //#line 237 "x10/regionarray/PolyMat.x10"
            final boolean t$153879 = ((t$153877) < (((long)(t$153878))));
            
            //#line 237 "x10/regionarray/PolyMat.x10"
            if (!(t$153879)) {
                
                //#line 237 "x10/regionarray/PolyMat.x10"
                break;
            }
            
            //#line 238 "x10/regionarray/PolyMat.x10"
            final x10.regionarray.PolyMat t$153866 = ((x10.regionarray.PolyMat)(pm.eliminate((int)(i$153875), (boolean)(false))));
            
            //#line 238 "x10/regionarray/PolyMat.x10"
            pm = ((x10.regionarray.PolyMat)(t$153866));
            
            //#line 237 "x10/regionarray/PolyMat.x10"
            final int t$153868 = ((i$153875) + (((int)(1))));
            
            //#line 237 "x10/regionarray/PolyMat.x10"
            i$153875 = t$153868;
        }
        
        //#line 241 "x10/regionarray/PolyMat.x10"
        final x10.lang.Iterator r$153881 = ((x10.regionarray.Mat<x10.regionarray.PolyRow>)pm).iterator();
        
        //#line 241 "x10/regionarray/PolyMat.x10"
        for (;
             true;
             ) {
            
            //#line 241 "x10/regionarray/PolyMat.x10"
            final boolean t$153882 = ((x10.lang.Iterator<x10.regionarray.PolyRow>)r$153881).hasNext$O();
            
            //#line 241 "x10/regionarray/PolyMat.x10"
            if (!(t$153882)) {
                
                //#line 241 "x10/regionarray/PolyMat.x10"
                break;
            }
            
            //#line 241 "x10/regionarray/PolyMat.x10"
            final x10.regionarray.PolyRow r$153869 = ((x10.lang.Iterator<x10.regionarray.PolyRow>)r$153881).next$G();
            
            //#line 242 "x10/regionarray/PolyMat.x10"
            final long t$153870 = this.rank;
            
            //#line 242 "x10/regionarray/PolyMat.x10"
            final int t$153871 = ((int)(long)(((long)(t$153870))));
            
            //#line 242 "x10/regionarray/PolyMat.x10"
            final int t$153872 = r$153869.$apply$O((int)(t$153871));
            
            //#line 242 "x10/regionarray/PolyMat.x10"
            final long t$153873 = ((long)(((int)(t$153872))));
            
            //#line 242 "x10/regionarray/PolyMat.x10"
            final boolean t$153874 = ((t$153873) > (((long)(0L))));
            
            //#line 242 "x10/regionarray/PolyMat.x10"
            if (t$153874) {
                
                //#line 243 "x10/regionarray/PolyMat.x10"
                return true;
            }
        }
        
        //#line 246 "x10/regionarray/PolyMat.x10"
        return false;
    }
    
    
    //#line 254 "x10/regionarray/PolyMat.x10"
    /**
     * Concatenate matrices
     */
    public x10.regionarray.PolyMat $or(final x10.regionarray.PolyMat that) {
        
        //#line 255 "x10/regionarray/PolyMat.x10"
        final x10.regionarray.PolyMatBuilder pmb = ((x10.regionarray.PolyMatBuilder)(new x10.regionarray.PolyMatBuilder((java.lang.System[]) null)));
        
        //#line 255 "x10/regionarray/PolyMat.x10"
        final long t$153885 = this.rank;
        
        //#line 255 "x10/regionarray/PolyMat.x10"
        pmb.x10$regionarray$PolyMatBuilder$$init$S(((long)(t$153885)));
        
        //#line 256 "x10/regionarray/PolyMat.x10"
        final x10.lang.Iterator r$153886 = this.iterator();
        
        //#line 256 "x10/regionarray/PolyMat.x10"
        for (;
             true;
             ) {
            
            //#line 256 "x10/regionarray/PolyMat.x10"
            final boolean t$153887 = ((x10.lang.Iterator<x10.regionarray.PolyRow>)r$153886).hasNext$O();
            
            //#line 256 "x10/regionarray/PolyMat.x10"
            if (!(t$153887)) {
                
                //#line 256 "x10/regionarray/PolyMat.x10"
                break;
            }
            
            //#line 256 "x10/regionarray/PolyMat.x10"
            final x10.regionarray.PolyRow r$153883 = ((x10.lang.Iterator<x10.regionarray.PolyRow>)r$153886).next$G();
            
            //#line 257 "x10/regionarray/PolyMat.x10"
            pmb.add(((x10.regionarray.Row)(r$153883)));
        }
        
        //#line 258 "x10/regionarray/PolyMat.x10"
        final x10.lang.Iterator r$153888 = ((x10.regionarray.Mat<x10.regionarray.PolyRow>)that).iterator();
        
        //#line 258 "x10/regionarray/PolyMat.x10"
        for (;
             true;
             ) {
            
            //#line 258 "x10/regionarray/PolyMat.x10"
            final boolean t$153889 = ((x10.lang.Iterator<x10.regionarray.PolyRow>)r$153888).hasNext$O();
            
            //#line 258 "x10/regionarray/PolyMat.x10"
            if (!(t$153889)) {
                
                //#line 258 "x10/regionarray/PolyMat.x10"
                break;
            }
            
            //#line 258 "x10/regionarray/PolyMat.x10"
            final x10.regionarray.PolyRow r$153884 = ((x10.lang.Iterator<x10.regionarray.PolyRow>)r$153888).next$G();
            
            //#line 259 "x10/regionarray/PolyMat.x10"
            pmb.add(((x10.regionarray.Row)(r$153884)));
        }
        
        //#line 260 "x10/regionarray/PolyMat.x10"
        final x10.regionarray.PolyMat t$153691 = ((x10.regionarray.PolyMat)(pmb.toSortedPolyMat((boolean)(false))));
        
        //#line 260 "x10/regionarray/PolyMat.x10"
        return t$153691;
    }
    
    
    //#line 264 "x10/regionarray/PolyMat.x10"
    public java.lang.String toString() {
        
        //#line 266 "x10/regionarray/PolyMat.x10"
        java.lang.String s = "(";
        
        //#line 267 "x10/regionarray/PolyMat.x10"
        boolean first = true;
        
        //#line 269 "x10/regionarray/PolyMat.x10"
        final x10.lang.Iterator r$153898 = this.iterator();
        
        //#line 269 "x10/regionarray/PolyMat.x10"
        for (;
             true;
             ) {
            
            //#line 269 "x10/regionarray/PolyMat.x10"
            final boolean t$153899 = ((x10.lang.Iterator<x10.regionarray.PolyRow>)r$153898).hasNext$O();
            
            //#line 269 "x10/regionarray/PolyMat.x10"
            if (!(t$153899)) {
                
                //#line 269 "x10/regionarray/PolyMat.x10"
                break;
            }
            
            //#line 269 "x10/regionarray/PolyMat.x10"
            final x10.regionarray.PolyRow r$153890 = ((x10.lang.Iterator<x10.regionarray.PolyRow>)r$153898).next$G();
            
            //#line 270 "x10/regionarray/PolyMat.x10"
            final boolean t$153892 = !(first);
            
            //#line 270 "x10/regionarray/PolyMat.x10"
            if (t$153892) {
                
                //#line 270 "x10/regionarray/PolyMat.x10"
                final java.lang.String t$153894 = ((s) + (" && "));
                
                //#line 270 "x10/regionarray/PolyMat.x10"
                s = ((java.lang.String)(t$153894));
            }
            
            //#line 271 "x10/regionarray/PolyMat.x10"
            final java.lang.String t$153896 = r$153890.toString();
            
            //#line 271 "x10/regionarray/PolyMat.x10"
            final java.lang.String t$153897 = ((s) + (t$153896));
            
            //#line 271 "x10/regionarray/PolyMat.x10"
            s = ((java.lang.String)(t$153897));
            
            //#line 272 "x10/regionarray/PolyMat.x10"
            first = false;
        }
        
        //#line 275 "x10/regionarray/PolyMat.x10"
        final java.lang.String t$153702 = ((s) + (")"));
        
        //#line 275 "x10/regionarray/PolyMat.x10"
        s = ((java.lang.String)(t$153702));
        
        //#line 276 "x10/regionarray/PolyMat.x10"
        return s;
    }
    
    
    //#line 26 "x10/regionarray/PolyMat.x10"
    final public x10.regionarray.PolyMat x10$regionarray$PolyMat$$this$x10$regionarray$PolyMat() {
        
        //#line 26 "x10/regionarray/PolyMat.x10"
        return x10.regionarray.PolyMat.this;
    }
    
    
    //#line 26 "x10/regionarray/PolyMat.x10"
    final public void __fieldInitializers_x10_regionarray_PolyMat() {
        
    }
    
    @x10.runtime.impl.java.X10Generated
    final public static class $Closure$248 extends x10.core.Ref implements x10.core.fun.Fun_0_1, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<$Closure$248> $RTT = 
            x10.rtt.StaticFunType.<$Closure$248> make($Closure$248.class,
                                                      new x10.rtt.Type[] {
                                                          x10.rtt.ParameterizedType.make(x10.core.fun.Fun_0_1.$RTT, x10.rtt.Types.INT, x10.rtt.Types.INT)
                                                      });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static x10.serialization.X10JavaSerializable $_deserialize_body(x10.regionarray.PolyMat.$Closure$248 $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            $_obj.i = $deserializer.readLong();
            $_obj.init = $deserializer.readObject();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.regionarray.PolyMat.$Closure$248 $_obj = new x10.regionarray.PolyMat.$Closure$248((java.lang.System[]) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            $serializer.write(this.i);
            $serializer.write(this.init);
            
        }
        
        // constructor just for allocation
        public $Closure$248(final java.lang.System[] $dummy) {
            
        }
        
        // dispatcher for method abstract public (Z1)=>U.operator()(a1:Z1):U
        public java.lang.Object $apply(final java.lang.Object a1, final x10.rtt.Type t1) {
            return x10.core.Int.$box($apply$O(x10.core.Int.$unbox(a1)));
            
        }
        
        // dispatcher for method abstract public (Z1)=>U.operator()(a1:Z1):U
        public int $apply$I(final java.lang.Object a1, final x10.rtt.Type t1) {
            return $apply$O(x10.core.Int.$unbox(a1));
            
        }
        
        // synthetic type for parameter mangling
        public static final class __1$1x10$lang$Int$3x10$lang$Int$3x10$lang$Int$2 {}
        
    
        
        public int $apply$O(final int j$153705) {
            
            //#line 40 "x10/regionarray/PolyMat.x10"
            final int t$153706 = ((int)(long)(((long)(this.i))));
            
            //#line 40 "x10/regionarray/PolyMat.x10"
            final int t$153707 = x10.core.Int.$unbox(((x10.core.fun.Fun_0_2<x10.core.Int,x10.core.Int,x10.core.Int>)this.init).$apply(x10.core.Int.$box(t$153706), x10.rtt.Types.INT, x10.core.Int.$box(j$153705), x10.rtt.Types.INT));
            
            //#line 40 "x10/regionarray/PolyMat.x10"
            return t$153707;
        }
        
        public long i;
        public x10.core.fun.Fun_0_2<x10.core.Int,x10.core.Int,x10.core.Int> init;
        
        public $Closure$248(final long i, final x10.core.fun.Fun_0_2<x10.core.Int,x10.core.Int,x10.core.Int> init, __1$1x10$lang$Int$3x10$lang$Int$3x10$lang$Int$2 $dummy) {
             {
                this.i = i;
                this.init = ((x10.core.fun.Fun_0_2)(init));
            }
        }
        
    }
    
    @x10.runtime.impl.java.X10Generated
    final public static class $Closure$249 extends x10.core.Ref implements x10.core.fun.Fun_0_1, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<$Closure$249> $RTT = 
            x10.rtt.StaticFunType.<$Closure$249> make($Closure$249.class,
                                                      new x10.rtt.Type[] {
                                                          x10.rtt.ParameterizedType.make(x10.core.fun.Fun_0_1.$RTT, x10.rtt.Types.LONG, x10.regionarray.PolyRow.$RTT)
                                                      });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static x10.serialization.X10JavaSerializable $_deserialize_body(x10.regionarray.PolyMat.$Closure$249 $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            $_obj.cols = $deserializer.readInt();
            $_obj.init = $deserializer.readObject();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.regionarray.PolyMat.$Closure$249 $_obj = new x10.regionarray.PolyMat.$Closure$249((java.lang.System[]) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            $serializer.write(this.cols);
            $serializer.write(this.init);
            
        }
        
        // constructor just for allocation
        public $Closure$249(final java.lang.System[] $dummy) {
            
        }
        
        // dispatcher for method abstract public (Z1)=>U.operator()(a1:Z1):U
        public java.lang.Object $apply(final java.lang.Object a1, final x10.rtt.Type t1) {
            return $apply(x10.core.Long.$unbox(a1));
            
        }
        
        // synthetic type for parameter mangling
        public static final class __0$1x10$lang$Int$3x10$lang$Int$3x10$lang$Int$2 {}
        
    
        
        public x10.regionarray.PolyRow $apply(final long i) {
            
            //#line 40 "x10/regionarray/PolyMat.x10"
            final x10.regionarray.PolyRow alloc$152835 = ((x10.regionarray.PolyRow)(new x10.regionarray.PolyRow((java.lang.System[]) null)));
            
            //#line 40 "x10/regionarray/PolyMat.x10"
            final x10.core.fun.Fun_0_1 t$153704 = ((x10.core.fun.Fun_0_1)(new x10.regionarray.PolyMat.$Closure$248(i, ((x10.core.fun.Fun_0_2)(this.init)), (x10.regionarray.PolyMat.$Closure$248.__1$1x10$lang$Int$3x10$lang$Int$3x10$lang$Int$2) null)));
            
            //#line 40 "x10/regionarray/PolyMat.x10"
            alloc$152835.x10$regionarray$PolyRow$$init$S(this.cols, ((x10.core.fun.Fun_0_1)(t$153704)), (x10.regionarray.PolyRow.__1$1x10$lang$Int$3x10$lang$Int$2) null);
            
            //#line 40 "x10/regionarray/PolyMat.x10"
            return alloc$152835;
        }
        
        public x10.core.fun.Fun_0_2<x10.core.Int,x10.core.Int,x10.core.Int> init;
        public int cols;
        
        public $Closure$249(final x10.core.fun.Fun_0_2<x10.core.Int,x10.core.Int,x10.core.Int> init, final int cols, __0$1x10$lang$Int$3x10$lang$Int$3x10$lang$Int$2 $dummy) {
             {
                this.init = ((x10.core.fun.Fun_0_2)(init));
                this.cols = cols;
            }
        }
        
    }
    
    @x10.runtime.impl.java.X10Generated
    final public static class $Closure$250 extends x10.core.Ref implements x10.core.fun.Fun_0_1, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<$Closure$250> $RTT = 
            x10.rtt.StaticFunType.<$Closure$250> make($Closure$250.class,
                                                      new x10.rtt.Type[] {
                                                          x10.rtt.ParameterizedType.make(x10.core.fun.Fun_0_1.$RTT, x10.rtt.Types.LONG, x10.rtt.Types.INT)
                                                      });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static x10.serialization.X10JavaSerializable $_deserialize_body(x10.regionarray.PolyMat.$Closure$250 $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            $_obj.as_$153791 = $deserializer.readObject();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.regionarray.PolyMat.$Closure$250 $_obj = new x10.regionarray.PolyMat.$Closure$250((java.lang.System[]) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            $serializer.write(this.as_$153791);
            
        }
        
        // constructor just for allocation
        public $Closure$250(final java.lang.System[] $dummy) {
            
        }
        
        // dispatcher for method abstract public (Z1)=>U.operator()(a1:Z1):U
        public java.lang.Object $apply(final java.lang.Object a1, final x10.rtt.Type t1) {
            return x10.core.Int.$box($apply$O(x10.core.Long.$unbox(a1)));
            
        }
        
        // dispatcher for method abstract public (Z1)=>U.operator()(a1:Z1):U
        public int $apply$I(final java.lang.Object a1, final x10.rtt.Type t1) {
            return $apply$O(x10.core.Long.$unbox(a1));
            
        }
        
        // synthetic type for parameter mangling
        public static final class __0$1x10$lang$Int$2 {}
        
    
        
        public int $apply$O(final long i$153816) {
            
            //#line 145 "x10/regionarray/PolyMat.x10"
            final int t$153817 = ((int[])this.as_$153791.value)[(int)i$153816];
            
            //#line 145 "x10/regionarray/PolyMat.x10"
            return t$153817;
        }
        
        public x10.core.Rail<x10.core.Int> as_$153791;
        
        public $Closure$250(final x10.core.Rail<x10.core.Int> as_$153791, __0$1x10$lang$Int$2 $dummy) {
             {
                this.as_$153791 = ((x10.core.Rail)(as_$153791));
            }
        }
        
    }
    
    @x10.runtime.impl.java.X10Generated
    final public static class $Closure$251 extends x10.core.Ref implements x10.core.fun.Fun_0_1, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<$Closure$251> $RTT = 
            x10.rtt.StaticFunType.<$Closure$251> make($Closure$251.class,
                                                      new x10.rtt.Type[] {
                                                          x10.rtt.ParameterizedType.make(x10.core.fun.Fun_0_1.$RTT, x10.rtt.Types.LONG, x10.rtt.Types.INT)
                                                      });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static x10.serialization.X10JavaSerializable $_deserialize_body(x10.regionarray.PolyMat.$Closure$251 $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            $_obj.out$$ = $deserializer.readObject();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.regionarray.PolyMat.$Closure$251 $_obj = new x10.regionarray.PolyMat.$Closure$251((java.lang.System[]) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            $serializer.write(this.out$$);
            
        }
        
        // constructor just for allocation
        public $Closure$251(final java.lang.System[] $dummy) {
            
        }
        
        // dispatcher for method abstract public (Z1)=>U.operator()(a1:Z1):U
        public java.lang.Object $apply(final java.lang.Object a1, final x10.rtt.Type t1) {
            return x10.core.Int.$box($apply$O(x10.core.Long.$unbox(a1)));
            
        }
        
        // dispatcher for method abstract public (Z1)=>U.operator()(a1:Z1):U
        public int $apply$I(final java.lang.Object a1, final x10.rtt.Type t1) {
            return $apply$O(x10.core.Long.$unbox(a1));
            
        }
        
        
    
        
        public int $apply$O(final long i) {
            
            //#line 198 "x10/regionarray/PolyMat.x10"
            final int t$153637 = ((int)(long)(((long)(i))));
            
            //#line 198 "x10/regionarray/PolyMat.x10"
            final int t$153638 = this.out$$.rectMin$O((int)(t$153637));
            
            //#line 198 "x10/regionarray/PolyMat.x10"
            return t$153638;
        }
        
        public x10.regionarray.PolyMat out$$;
        
        public $Closure$251(final x10.regionarray.PolyMat out$$) {
             {
                this.out$$ = out$$;
            }
        }
        
    }
    
    @x10.runtime.impl.java.X10Generated
    final public static class $Closure$252 extends x10.core.Ref implements x10.core.fun.Fun_0_1, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<$Closure$252> $RTT = 
            x10.rtt.StaticFunType.<$Closure$252> make($Closure$252.class,
                                                      new x10.rtt.Type[] {
                                                          x10.rtt.ParameterizedType.make(x10.core.fun.Fun_0_1.$RTT, x10.rtt.Types.LONG, x10.rtt.Types.INT)
                                                      });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static x10.serialization.X10JavaSerializable $_deserialize_body(x10.regionarray.PolyMat.$Closure$252 $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            $_obj.out$$ = $deserializer.readObject();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.regionarray.PolyMat.$Closure$252 $_obj = new x10.regionarray.PolyMat.$Closure$252((java.lang.System[]) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            $serializer.write(this.out$$);
            
        }
        
        // constructor just for allocation
        public $Closure$252(final java.lang.System[] $dummy) {
            
        }
        
        // dispatcher for method abstract public (Z1)=>U.operator()(a1:Z1):U
        public java.lang.Object $apply(final java.lang.Object a1, final x10.rtt.Type t1) {
            return x10.core.Int.$box($apply$O(x10.core.Long.$unbox(a1)));
            
        }
        
        // dispatcher for method abstract public (Z1)=>U.operator()(a1:Z1):U
        public int $apply$I(final java.lang.Object a1, final x10.rtt.Type t1) {
            return $apply$O(x10.core.Long.$unbox(a1));
            
        }
        
        
    
        
        public int $apply$O(final long i) {
            
            //#line 200 "x10/regionarray/PolyMat.x10"
            final int t$153642 = ((int)(long)(((long)(i))));
            
            //#line 200 "x10/regionarray/PolyMat.x10"
            final int t$153643 = this.out$$.rectMax$O((int)(t$153642));
            
            //#line 200 "x10/regionarray/PolyMat.x10"
            return t$153643;
        }
        
        public x10.regionarray.PolyMat out$$;
        
        public $Closure$252(final x10.regionarray.PolyMat out$$) {
             {
                this.out$$ = out$$;
            }
        }
        
    }
    
}


