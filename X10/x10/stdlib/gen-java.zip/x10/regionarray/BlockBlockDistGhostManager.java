package x10.regionarray;


/**
 * A BlockBlockDistGhostManager manages the local ghost region for a Ghostable
 * array that is distributed using a BlockBlockDist.
 * Ghost regions are sent using a simple put algorithm with no internal synchronization.
 */
@x10.runtime.impl.java.X10Generated
final public class BlockBlockDistGhostManager extends x10.regionarray.GhostManager implements x10.serialization.X10JavaSerializable
{
    public static final x10.rtt.RuntimeType<BlockBlockDistGhostManager> $RTT = 
        x10.rtt.NamedType.<BlockBlockDistGhostManager> make("x10.regionarray.BlockBlockDistGhostManager",
                                                            BlockBlockDistGhostManager.class,
                                                            new x10.rtt.Type[] {
                                                                x10.regionarray.GhostManager.$RTT
                                                            });
    
    public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
    
    public x10.rtt.Type<?> $getParam(int i) { return null; }
    
    private Object writeReplace() throws java.io.ObjectStreamException {
        return new x10.serialization.SerializationProxy(this);
    }
    
    public static x10.serialization.X10JavaSerializable $_deserialize_body(x10.regionarray.BlockBlockDistGhostManager $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
        x10.regionarray.GhostManager.$_deserialize_body($_obj, $deserializer);
        $_obj.bbd = $deserializer.readObject();
        $_obj.neighbors = $deserializer.readObject();
        $_obj.periodic = $deserializer.readBoolean();
        return $_obj;
    }
    
    public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
        x10.regionarray.BlockBlockDistGhostManager $_obj = new x10.regionarray.BlockBlockDistGhostManager((java.lang.System[]) null);
        $deserializer.record_reference($_obj);
        return $_deserialize_body($_obj, $deserializer);
    }
    
    public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
        super.$_serialize($serializer);
        $serializer.write(this.bbd);
        $serializer.write(this.neighbors);
        $serializer.write(this.periodic);
        
    }
    
    // constructor just for allocation
    public BlockBlockDistGhostManager(final java.lang.System[] $dummy) {
        super($dummy);
        
    }
    
    

    
    //#line 24 "x10/regionarray/BlockBlockDistGhostManager.x10"
    public x10.regionarray.BlockBlockDist bbd;
    
    //#line 25 "x10/regionarray/BlockBlockDistGhostManager.x10"
    public x10.core.Rail<x10.regionarray.GhostManager.GhostNeighborFlag> neighbors;
    
    //#line 26 "x10/regionarray/BlockBlockDistGhostManager.x10"
    public boolean periodic;
    
    
    //#line 28 "x10/regionarray/BlockBlockDistGhostManager.x10"
    // creation method for java code (1-phase java constructor)
    public BlockBlockDistGhostManager(final long ghostWidth, final x10.regionarray.Dist bbd, final boolean periodic) {
        this((java.lang.System[]) null);
        x10$regionarray$BlockBlockDistGhostManager$$init$S(ghostWidth, bbd, periodic);
    }
    
    // constructor for non-virtual call
    final public x10.regionarray.BlockBlockDistGhostManager x10$regionarray$BlockBlockDistGhostManager$$init$S(final long ghostWidth, final x10.regionarray.Dist bbd, final boolean periodic) {
         {
            
            //#line 29 "x10/regionarray/BlockBlockDistGhostManager.x10"
            final x10.regionarray.GhostManager this$147812 = this;
            
            //#line 22 .. "x10/regionarray/GhostManager.x10"
            this$147812.currentPhase = ((byte) 0);
            
            //#line 38 . "x10/regionarray/GhostManager.x10"
            this$147812.ghostWidth = ghostWidth;
            
            //#line 39 . "x10/regionarray/GhostManager.x10"
            this$147812.currentPhase = ((byte) 0);
            
            //#line 28 "x10/regionarray/BlockBlockDistGhostManager.x10"
            
            
            //#line 30 "x10/regionarray/BlockBlockDistGhostManager.x10"
            final x10.regionarray.BlockBlockDist t$147835 = ((x10.regionarray.BlockBlockDist)(x10.rtt.Types.<x10.regionarray.BlockBlockDist> cast(bbd,x10.regionarray.BlockBlockDist.$RTT)));
            
            //#line 30 "x10/regionarray/BlockBlockDistGhostManager.x10"
            this.bbd = ((x10.regionarray.BlockBlockDist)(t$147835));
            
            //#line 31 "x10/regionarray/BlockBlockDistGhostManager.x10"
            this.periodic = periodic;
            
            //#line 32 "x10/regionarray/BlockBlockDistGhostManager.x10"
            final x10.core.Rail t$147836 = this.createNeighbors();
            
            //#line 32 "x10/regionarray/BlockBlockDistGhostManager.x10"
            this.neighbors = ((x10.core.Rail)(t$147836));
        }
        return this;
    }
    
    
    
    //#line 35 "x10/regionarray/BlockBlockDistGhostManager.x10"
    public x10.core.Rail getNeighbors() {
        
        //#line 35 "x10/regionarray/BlockBlockDistGhostManager.x10"
        final x10.core.Rail t$147837 = ((x10.core.Rail)(this.neighbors));
        
        //#line 35 "x10/regionarray/BlockBlockDistGhostManager.x10"
        final long t$147841 = ((x10.core.Rail<x10.regionarray.GhostManager.GhostNeighborFlag>)t$147837).size;
        
        //#line 35 "x10/regionarray/BlockBlockDistGhostManager.x10"
        final x10.core.fun.Fun_0_1 t$147842 = ((x10.core.fun.Fun_0_1)(new x10.regionarray.BlockBlockDistGhostManager.$Closure$207(this, this.neighbors, (x10.regionarray.BlockBlockDistGhostManager.$Closure$207.__1$1x10$regionarray$GhostManager$GhostNeighborFlag$2) null)));
        
        //#line 35 "x10/regionarray/BlockBlockDistGhostManager.x10"
        final x10.core.Rail t$147843 = ((x10.core.Rail)(new x10.core.Rail<x10.lang.Place>(x10.lang.Place.$RTT, ((long)(t$147841)), ((x10.core.fun.Fun_0_1)(t$147842)), (x10.core.Rail.__1$1x10$lang$Long$3x10$lang$Rail$$T$2) null)));
        
        //#line 35 "x10/regionarray/BlockBlockDistGhostManager.x10"
        return t$147843;
    }
    
    
    //#line 54 "x10/regionarray/BlockBlockDistGhostManager.x10"
    /** 
     * Creates the list of neighboring places that hold the blocks immediately
     * surrounding place p.  In a BlockBlockDist, a place may hold two blocks
     * contiguous in axis0 ("west-east"), so a place may adjoin either one or
     * two neighboring places in the "north" and "south" directions.
     * In a periodic distribution, a single neighbor may appear multiple times
     * in the list due to wrapping in any dimension.
     * The neighbors for place p are laid out as follows:
     *
     *   -- axis0 -->
     *  6 | 7 | 8 | 9  ^
     * --------------- |
     *  4 |   p   | 5  | axis1
     * --------------- |
     *  0 | 1 | 2 | 3
     *
     */
    private x10.core.Rail createNeighbors() {
        
        //#line 55 "x10/regionarray/BlockBlockDistGhostManager.x10"
        final x10.util.ArrayList neighborList = ((x10.util.ArrayList)(new x10.util.ArrayList<x10.regionarray.GhostManager.GhostNeighborFlag>((java.lang.System[]) null, x10.regionarray.GhostManager.GhostNeighborFlag.$RTT)));
        
        //#line 55 "x10/regionarray/BlockBlockDistGhostManager.x10"
        neighborList.x10$util$ArrayList$$init$S();
        
        //#line 56 "x10/regionarray/BlockBlockDistGhostManager.x10"
        final x10.regionarray.BlockBlockDist t$147844 = ((x10.regionarray.BlockBlockDist)(this.bbd));
        
        //#line 56 "x10/regionarray/BlockBlockDistGhostManager.x10"
        final x10.regionarray.Region t$147845 = ((x10.regionarray.Region)(t$147844.region));
        
        //#line 56 "x10/regionarray/BlockBlockDistGhostManager.x10"
        final x10.regionarray.Region b = ((x10.regionarray.Region)(t$147845.boundingBox()));
        
        //#line 57 "x10/regionarray/BlockBlockDistGhostManager.x10"
        final x10.regionarray.BlockBlockDist t$147846 = ((x10.regionarray.BlockBlockDist)(this.bbd));
        
        //#line 57 "x10/regionarray/BlockBlockDistGhostManager.x10"
        final long axis0 = t$147846.axis0;
        
        //#line 58 "x10/regionarray/BlockBlockDistGhostManager.x10"
        final x10.regionarray.BlockBlockDist t$147847 = ((x10.regionarray.BlockBlockDist)(this.bbd));
        
        //#line 58 "x10/regionarray/BlockBlockDistGhostManager.x10"
        final long axis1 = t$147847.axis1;
        
        //#line 59 "x10/regionarray/BlockBlockDistGhostManager.x10"
        final x10.regionarray.BlockBlockDist this$147817 = ((x10.regionarray.BlockBlockDist)(this.bbd));
        
        //#line 59 "x10/regionarray/BlockBlockDistGhostManager.x10"
        final x10.lang.PlaceGroup pg = this$147817.pg;
        
        //#line 60 "x10/regionarray/BlockBlockDistGhostManager.x10"
        final long min0 = b.min$O((long)(axis0));
        
        //#line 61 "x10/regionarray/BlockBlockDistGhostManager.x10"
        final long max0 = b.max$O((long)(axis0));
        
        //#line 62 "x10/regionarray/BlockBlockDistGhostManager.x10"
        final long min1 = b.min$O((long)(axis1));
        
        //#line 63 "x10/regionarray/BlockBlockDistGhostManager.x10"
        final long max1 = b.max$O((long)(axis1));
        
        //#line 64 "x10/regionarray/BlockBlockDistGhostManager.x10"
        final long t$147848 = ((max0) - (((long)(min0))));
        
        //#line 64 "x10/regionarray/BlockBlockDistGhostManager.x10"
        final long size0 = ((t$147848) + (((long)(1L))));
        
        //#line 65 "x10/regionarray/BlockBlockDistGhostManager.x10"
        final long t$147849 = ((max1) - (((long)(min1))));
        
        //#line 65 "x10/regionarray/BlockBlockDistGhostManager.x10"
        final long size1 = ((t$147849) + (((long)(1L))));
        
        //#line 66 "x10/regionarray/BlockBlockDistGhostManager.x10"
        final long t$147850 = ((size0) % (((long)(2L))));
        
        //#line 66 "x10/regionarray/BlockBlockDistGhostManager.x10"
        final boolean t$147851 = ((long) t$147850) == ((long) 0L);
        
        //#line 66 "x10/regionarray/BlockBlockDistGhostManager.x10"
        long t$147852 =  0;
        
        //#line 66 "x10/regionarray/BlockBlockDistGhostManager.x10"
        if (t$147851) {
            
            //#line 66 "x10/regionarray/BlockBlockDistGhostManager.x10"
            t$147852 = size0;
        } else {
            
            //#line 66 "x10/regionarray/BlockBlockDistGhostManager.x10"
            t$147852 = ((size0) - (((long)(1L))));
        }
        
        //#line 67 "x10/regionarray/BlockBlockDistGhostManager.x10"
        final long t$147853 = pg.numPlaces$O();
        
        //#line 67 "x10/regionarray/BlockBlockDistGhostManager.x10"
        final long t$147854 = ((t$147852) * (((long)(size1))));
        
        //#line 67 "x10/regionarray/BlockBlockDistGhostManager.x10"
        final long P = java.lang.Math.min(((long)(t$147853)),((long)(t$147854)));
        
        //#line 68 "x10/regionarray/BlockBlockDistGhostManager.x10"
        final double t$147855 = ((double)(long)(((long)(P))));
        
        //#line 68 "x10/regionarray/BlockBlockDistGhostManager.x10"
        final double t$147856 = java.lang.Math.log(((double)(t$147855)));
        
        //#line 68 "x10/regionarray/BlockBlockDistGhostManager.x10"
        final double t$147857 = java.lang.Math.log(((double)(2.0)));
        
        //#line 68 "x10/regionarray/BlockBlockDistGhostManager.x10"
        final double t$147858 = ((t$147856) / (((double)(t$147857))));
        
        //#line 68 "x10/regionarray/BlockBlockDistGhostManager.x10"
        final double t$147859 = ((t$147858) / (((double)(2.0))));
        
        //#line 68 "x10/regionarray/BlockBlockDistGhostManager.x10"
        final double t$147860 = java.lang.Math.ceil(((double)(t$147859)));
        
        //#line 68 "x10/regionarray/BlockBlockDistGhostManager.x10"
        final long t$147861 = ((long)(double)(((double)(t$147860))));
        
        //#line 68 "x10/regionarray/BlockBlockDistGhostManager.x10"
        final long t$147862 = x10.lang.Math.pow2$O((long)(t$147861));
        
        //#line 68 "x10/regionarray/BlockBlockDistGhostManager.x10"
        final long divisions0 = java.lang.Math.min(((long)(t$147852)),((long)(t$147862)));
        
        //#line 69 "x10/regionarray/BlockBlockDistGhostManager.x10"
        final double t$147863 = ((double)(long)(((long)(P))));
        
        //#line 69 "x10/regionarray/BlockBlockDistGhostManager.x10"
        final double t$147864 = ((double)(long)(((long)(divisions0))));
        
        //#line 69 "x10/regionarray/BlockBlockDistGhostManager.x10"
        final double t$147865 = ((t$147863) / (((double)(t$147864))));
        
        //#line 69 "x10/regionarray/BlockBlockDistGhostManager.x10"
        final double t$147866 = java.lang.Math.ceil(((double)(t$147865)));
        
        //#line 69 "x10/regionarray/BlockBlockDistGhostManager.x10"
        final long t$147867 = ((long)(double)(((double)(t$147866))));
        
        //#line 69 "x10/regionarray/BlockBlockDistGhostManager.x10"
        final long divisions1 = java.lang.Math.min(((long)(size1)),((long)(t$147867)));
        
        //#line 70 "x10/regionarray/BlockBlockDistGhostManager.x10"
        final long numBlocks = ((divisions0) * (((long)(divisions1))));
        
        //#line 71 "x10/regionarray/BlockBlockDistGhostManager.x10"
        final long leftOver = ((numBlocks) - (((long)(P))));
        
        //#line 73 "x10/regionarray/BlockBlockDistGhostManager.x10"
        final long i = pg.indexOf$O(((x10.lang.Place)(x10.x10rt.X10RT.here())));
        
        //#line 75 "x10/regionarray/BlockBlockDistGhostManager.x10"
        final long t$147868 = ((divisions0) % (((long)(2L))));
        
        //#line 75 "x10/regionarray/BlockBlockDistGhostManager.x10"
        final boolean t$147871 = ((long) t$147868) == ((long) 0L);
        
        //#line 75 "x10/regionarray/BlockBlockDistGhostManager.x10"
        long t$147872 =  0;
        
        //#line 75 "x10/regionarray/BlockBlockDistGhostManager.x10"
        if (t$147871) {
            
            //#line 75 "x10/regionarray/BlockBlockDistGhostManager.x10"
            t$147872 = 0L;
        } else {
            
            //#line 75 "x10/regionarray/BlockBlockDistGhostManager.x10"
            final long t$147869 = ((i) * (((long)(2L))));
            
            //#line 75 "x10/regionarray/BlockBlockDistGhostManager.x10"
            final long t$147870 = ((divisions0) + (((long)(1L))));
            
            //#line 75 "x10/regionarray/BlockBlockDistGhostManager.x10"
            t$147872 = ((t$147869) / (((long)(t$147870))));
        }
        
        //#line 77 "x10/regionarray/BlockBlockDistGhostManager.x10"
        final boolean t$147876 = ((i) < (((long)(leftOver))));
        
        //#line 77 "x10/regionarray/BlockBlockDistGhostManager.x10"
        long t$147877 =  0;
        
        //#line 77 "x10/regionarray/BlockBlockDistGhostManager.x10"
        if (t$147876) {
            
            //#line 77 "x10/regionarray/BlockBlockDistGhostManager.x10"
            final long t$147873 = ((i) * (((long)(2L))));
            
            //#line 77 "x10/regionarray/BlockBlockDistGhostManager.x10"
            final long t$147874 = ((t$147873) - (((long)(t$147872))));
            
            //#line 77 "x10/regionarray/BlockBlockDistGhostManager.x10"
            t$147877 = ((t$147874) % (((long)(divisions0))));
        } else {
            
            //#line 77 "x10/regionarray/BlockBlockDistGhostManager.x10"
            final long t$147875 = ((i) + (((long)(leftOver))));
            
            //#line 77 "x10/regionarray/BlockBlockDistGhostManager.x10"
            t$147877 = ((t$147875) % (((long)(divisions0))));
        }
        
        //#line 78 "x10/regionarray/BlockBlockDistGhostManager.x10"
        final boolean t$147880 = ((i) < (((long)(leftOver))));
        
        //#line 78 "x10/regionarray/BlockBlockDistGhostManager.x10"
        long t$147881 =  0;
        
        //#line 78 "x10/regionarray/BlockBlockDistGhostManager.x10"
        if (t$147880) {
            
            //#line 78 "x10/regionarray/BlockBlockDistGhostManager.x10"
            final long t$147878 = ((i) * (((long)(2L))));
            
            //#line 78 "x10/regionarray/BlockBlockDistGhostManager.x10"
            t$147881 = ((t$147878) / (((long)(divisions0))));
        } else {
            
            //#line 78 "x10/regionarray/BlockBlockDistGhostManager.x10"
            final long t$147879 = ((i) + (((long)(leftOver))));
            
            //#line 78 "x10/regionarray/BlockBlockDistGhostManager.x10"
            t$147881 = ((t$147879) / (((long)(divisions0))));
        }
        
        //#line 80 "x10/regionarray/BlockBlockDistGhostManager.x10"
        long i$148140 = -1L;
        
        //#line 80 "x10/regionarray/BlockBlockDistGhostManager.x10"
        for (;
             true;
             ) {
            
            //#line 80 "x10/regionarray/BlockBlockDistGhostManager.x10"
            final boolean t$148142 = ((i$148140) <= (((long)(1L))));
            
            //#line 80 "x10/regionarray/BlockBlockDistGhostManager.x10"
            if (!(t$148142)) {
                
                //#line 80 "x10/regionarray/BlockBlockDistGhostManager.x10"
                break;
            }
            
            //#line 81 "x10/regionarray/BlockBlockDistGhostManager.x10"
            long i$148134 = -1L;
            
            //#line 81 "x10/regionarray/BlockBlockDistGhostManager.x10"
            for (;
                 true;
                 ) {
                
                //#line 81 "x10/regionarray/BlockBlockDistGhostManager.x10"
                final boolean t$148136 = ((i$148134) <= (((long)(1L))));
                
                //#line 81 "x10/regionarray/BlockBlockDistGhostManager.x10"
                if (!(t$148136)) {
                    
                    //#line 81 "x10/regionarray/BlockBlockDistGhostManager.x10"
                    break;
                }
                
                //#line 82 "x10/regionarray/BlockBlockDistGhostManager.x10"
                boolean t$148093 = ((long) i$148134) != ((long) 0L);
                
                //#line 82 "x10/regionarray/BlockBlockDistGhostManager.x10"
                if (!(t$148093)) {
                    
                    //#line 82 "x10/regionarray/BlockBlockDistGhostManager.x10"
                    t$148093 = ((long) i$148140) != ((long) 0L);
                }
                
                //#line 82 "x10/regionarray/BlockBlockDistGhostManager.x10"
                if (t$148093) {
                    
                    //#line 83 "x10/regionarray/BlockBlockDistGhostManager.x10"
                    long neighborBlockIndex$148095 = ((t$147877) + (((long)(i$148134))));
                    
                    //#line 84 "x10/regionarray/BlockBlockDistGhostManager.x10"
                    long neighborBlockIndex$148096 = ((t$147881) + (((long)(i$148140))));
                    
                    //#line 85 "x10/regionarray/BlockBlockDistGhostManager.x10"
                    boolean t$148097 = ((i) < (((long)(leftOver))));
                    
                    //#line 85 "x10/regionarray/BlockBlockDistGhostManager.x10"
                    if (t$148097) {
                        
                        //#line 85 "x10/regionarray/BlockBlockDistGhostManager.x10"
                        t$148097 = ((long) i$148134) == ((long) 1L);
                    }
                    
                    //#line 85 "x10/regionarray/BlockBlockDistGhostManager.x10"
                    if (t$148097) {
                        
                        //#line 87 "x10/regionarray/BlockBlockDistGhostManager.x10"
                        final long t$148100 = ((neighborBlockIndex$148095) + (((long)(1L))));
                        
                        //#line 87 "x10/regionarray/BlockBlockDistGhostManager.x10"
                        neighborBlockIndex$148095 = t$148100;
                    }
                    
                    //#line 89 "x10/regionarray/BlockBlockDistGhostManager.x10"
                    final boolean t$148103 = this.periodic;
                    
                    //#line 89 "x10/regionarray/BlockBlockDistGhostManager.x10"
                    final long groupIndex$148104 = x10.regionarray.BlockBlockDistGhostManager.getGroupIndex$O((long)(neighborBlockIndex$148095), (long)(neighborBlockIndex$148096), (long)(divisions0), (long)(divisions1), (long)(leftOver), (boolean)(t$148103), (long)(i));
                    
                    //#line 90 "x10/regionarray/BlockBlockDistGhostManager.x10"
                    final x10.lang.Place place$148105 = pg.$apply((long)(groupIndex$148104));
                    
                    //#line 91 "x10/regionarray/BlockBlockDistGhostManager.x10"
                    boolean t$148106 = this.periodic;
                    
                    //#line 91 "x10/regionarray/BlockBlockDistGhostManager.x10"
                    if (!(t$148106)) {
                        
                        //#line 91 "x10/regionarray/BlockBlockDistGhostManager.x10"
                        t$148106 = (!x10.rtt.Equality.equalsequals((place$148105),(x10.x10rt.X10RT.here())));
                    }
                    
                    //#line 91 "x10/regionarray/BlockBlockDistGhostManager.x10"
                    if (t$148106) {
                        
                        //#line 92 "x10/regionarray/BlockBlockDistGhostManager.x10"
                        final boolean t$148110 = this.periodic;
                        
                        //#line 92 "x10/regionarray/BlockBlockDistGhostManager.x10"
                        final x10.lang.Point shift$148111 = ((x10.lang.Point)(this.getNeighborShift((long)(neighborBlockIndex$148095), (long)(neighborBlockIndex$148096), (long)(divisions0), (long)(divisions1), (boolean)(t$148110))));
                        
                        //#line 93 "x10/regionarray/BlockBlockDistGhostManager.x10"
                        final x10.regionarray.GhostManager.GhostNeighborFlag alloc$148112 = ((x10.regionarray.GhostManager.GhostNeighborFlag)(new x10.regionarray.GhostManager.GhostNeighborFlag((java.lang.System[]) null)));
                        
                        //#line 79 . "x10/regionarray/GhostManager.x10"
                        alloc$148112.place = place$148105;
                        
                        //#line 79 . "x10/regionarray/GhostManager.x10"
                        alloc$148112.shift = shift$148111;
                        
                        //#line 79 .. "x10/regionarray/GhostManager.x10"
                        alloc$148112.received = false;
                        
                        //#line 93 "x10/regionarray/BlockBlockDistGhostManager.x10"
                        ((x10.util.ArrayList<x10.regionarray.GhostManager.GhostNeighborFlag>)neighborList).add__0x10$util$ArrayList$$T$O(((x10.regionarray.GhostManager.GhostNeighborFlag)(alloc$148112)));
                    }
                    
                    //#line 95 "x10/regionarray/BlockBlockDistGhostManager.x10"
                    final boolean t$148115 = ((long) i$148134) == ((long) 0L);
                    
                    //#line 95 "x10/regionarray/BlockBlockDistGhostManager.x10"
                    if (t$148115) {
                        
                        //#line 97 "x10/regionarray/BlockBlockDistGhostManager.x10"
                        boolean t$148116 = ((i) < (((long)(leftOver))));
                        
                        //#line 97 "x10/regionarray/BlockBlockDistGhostManager.x10"
                        if (t$148116) {
                            
                            //#line 97 "x10/regionarray/BlockBlockDistGhostManager.x10"
                            t$148116 = ((groupIndex$148104) >= (((long)(leftOver))));
                        }
                        
                        //#line 97 "x10/regionarray/BlockBlockDistGhostManager.x10"
                        if (t$148116) {
                            
                            //#line 98 "x10/regionarray/BlockBlockDistGhostManager.x10"
                            final long t$148118 = ((groupIndex$148104) + (((long)(1L))));
                            
                            //#line 98 "x10/regionarray/BlockBlockDistGhostManager.x10"
                            final x10.lang.Place place$148119 = pg.$apply((long)(t$148118));
                            
                            //#line 99 "x10/regionarray/BlockBlockDistGhostManager.x10"
                            boolean t$148120 = this.periodic;
                            
                            //#line 99 "x10/regionarray/BlockBlockDistGhostManager.x10"
                            if (!(t$148120)) {
                                
                                //#line 99 "x10/regionarray/BlockBlockDistGhostManager.x10"
                                t$148120 = (!x10.rtt.Equality.equalsequals((place$148119),(x10.x10rt.X10RT.here())));
                            }
                            
                            //#line 99 "x10/regionarray/BlockBlockDistGhostManager.x10"
                            if (t$148120) {
                                
                                //#line 100 "x10/regionarray/BlockBlockDistGhostManager.x10"
                                final boolean t$148124 = this.periodic;
                                
                                //#line 100 "x10/regionarray/BlockBlockDistGhostManager.x10"
                                final x10.lang.Point shift$148125 = ((x10.lang.Point)(this.getNeighborShift((long)(neighborBlockIndex$148095), (long)(neighborBlockIndex$148096), (long)(divisions0), (long)(divisions1), (boolean)(t$148124))));
                                
                                //#line 101 "x10/regionarray/BlockBlockDistGhostManager.x10"
                                final x10.regionarray.GhostManager.GhostNeighborFlag alloc$148126 = ((x10.regionarray.GhostManager.GhostNeighborFlag)(new x10.regionarray.GhostManager.GhostNeighborFlag((java.lang.System[]) null)));
                                
                                //#line 79 . "x10/regionarray/GhostManager.x10"
                                alloc$148126.place = place$148119;
                                
                                //#line 79 . "x10/regionarray/GhostManager.x10"
                                alloc$148126.shift = shift$148125;
                                
                                //#line 79 .. "x10/regionarray/GhostManager.x10"
                                alloc$148126.received = false;
                                
                                //#line 101 "x10/regionarray/BlockBlockDistGhostManager.x10"
                                ((x10.util.ArrayList<x10.regionarray.GhostManager.GhostNeighborFlag>)neighborList).add__0x10$util$ArrayList$$T$O(((x10.regionarray.GhostManager.GhostNeighborFlag)(alloc$148126)));
                            }
                        } else {
                            
                            //#line 103 "x10/regionarray/BlockBlockDistGhostManager.x10"
                            boolean t$148129 = ((i) >= (((long)(leftOver))));
                            
                            //#line 103 "x10/regionarray/BlockBlockDistGhostManager.x10"
                            if (t$148129) {
                                
                                //#line 103 "x10/regionarray/BlockBlockDistGhostManager.x10"
                                t$148129 = ((groupIndex$148104) < (((long)(leftOver))));
                            }
                            
                            //#line 103 "x10/regionarray/BlockBlockDistGhostManager.x10"
                            if (t$148129) {
                                
                                //#line 106 "x10/regionarray/BlockBlockDistGhostManager.x10"
                                ((x10.util.ArrayList<x10.regionarray.GhostManager.GhostNeighborFlag>)neighborList).removeLast$G();
                            }
                        }
                    }
                }
                
                //#line 81 "x10/regionarray/BlockBlockDistGhostManager.x10"
                final long t$148133 = ((i$148134) + (((long)(1L))));
                
                //#line 81 "x10/regionarray/BlockBlockDistGhostManager.x10"
                i$148134 = t$148133;
            }
            
            //#line 80 "x10/regionarray/BlockBlockDistGhostManager.x10"
            final long t$148139 = ((i$148140) + (((long)(1L))));
            
            //#line 80 "x10/regionarray/BlockBlockDistGhostManager.x10"
            i$148140 = t$148139;
        }
        
        //#line 112 "x10/regionarray/BlockBlockDistGhostManager.x10"
        final x10.core.Rail t$147917 = ((x10.core.Rail<x10.regionarray.GhostManager.GhostNeighborFlag>)
                                         ((x10.util.ArrayList<x10.regionarray.GhostManager.GhostNeighborFlag>)neighborList).toRail());
        
        //#line 112 "x10/regionarray/BlockBlockDistGhostManager.x10"
        return t$147917;
    }
    
    public static x10.core.Rail createNeighbors$P(final x10.regionarray.BlockBlockDistGhostManager BlockBlockDistGhostManager) {
        return BlockBlockDistGhostManager.createNeighbors();
    }
    
    
    //#line 115 "x10/regionarray/BlockBlockDistGhostManager.x10"
    public long getInverseNeighborIndex$O(final long neighborIndex) {
        
        //#line 116 "x10/regionarray/BlockBlockDistGhostManager.x10"
        assert ((neighborIndex) >= (((long)(0L)))) && ((neighborIndex) <= (((long)(9L))));
        
        //#line 117 "x10/regionarray/BlockBlockDistGhostManager.x10"
        final long t$147918 = ((9L) - (((long)(neighborIndex))));
        
        //#line 117 "x10/regionarray/BlockBlockDistGhostManager.x10"
        return t$147918;
    }
    
    
    //#line 120 "x10/regionarray/BlockBlockDistGhostManager.x10"
    public void setNeighborReceived(final x10.lang.Place place, final x10.lang.Point shift) {
        
        //#line 120 "x10/regionarray/BlockBlockDistGhostManager.x10"
        try {{
            
            //#line 120 "x10/regionarray/BlockBlockDistGhostManager.x10"
            x10.xrx.Runtime.enterAtomic();
            {
                
                //#line 121 "x10/regionarray/BlockBlockDistGhostManager.x10"
                final x10.core.Rail rail$148154 = ((x10.core.Rail)(this.neighbors));
                
                //#line 121 "x10/regionarray/BlockBlockDistGhostManager.x10"
                final long size$148155 = ((x10.core.Rail<x10.regionarray.GhostManager.GhostNeighborFlag>)rail$148154).size;
                
                //#line 121 "x10/regionarray/BlockBlockDistGhostManager.x10"
                long idx$148151 = 0L;
                {
                    
                    //#line 121 "x10/regionarray/BlockBlockDistGhostManager.x10"
                    final x10.regionarray.GhostManager.GhostNeighborFlag[] rail$148154$value$148277 = ((x10.regionarray.GhostManager.GhostNeighborFlag[])rail$148154.value);
                    
                    //#line 121 "x10/regionarray/BlockBlockDistGhostManager.x10"
                    for (;
                         true;
                         ) {
                        
                        //#line 121 "x10/regionarray/BlockBlockDistGhostManager.x10"
                        final boolean t$148153 = ((idx$148151) < (((long)(size$148155))));
                        
                        //#line 121 "x10/regionarray/BlockBlockDistGhostManager.x10"
                        if (!(t$148153)) {
                            
                            //#line 121 "x10/regionarray/BlockBlockDistGhostManager.x10"
                            break;
                        }
                        
                        //#line 121 "x10/regionarray/BlockBlockDistGhostManager.x10"
                        final x10.regionarray.GhostManager.GhostNeighborFlag neighborFlag$148148 = ((x10.regionarray.GhostManager.GhostNeighborFlag)(((x10.regionarray.GhostManager.GhostNeighborFlag)rail$148154$value$148277[(int)idx$148151])));
                        
                        //#line 122 "x10/regionarray/BlockBlockDistGhostManager.x10"
                        final x10.lang.Place t$148143 = ((x10.lang.Place)(neighborFlag$148148.place));
                        
                        //#line 122 "x10/regionarray/BlockBlockDistGhostManager.x10"
                        boolean t$148144 = x10.rtt.Equality.equalsequals((t$148143),(place));
                        
                        //#line 122 "x10/regionarray/BlockBlockDistGhostManager.x10"
                        if (t$148144) {
                            
                            //#line 122 "x10/regionarray/BlockBlockDistGhostManager.x10"
                            final x10.lang.Point t$148145 = ((x10.lang.Point)(neighborFlag$148148.shift));
                            
                            //#line 122 "x10/regionarray/BlockBlockDistGhostManager.x10"
                            t$148144 = t$148145.equals(((java.lang.Object)(shift)));
                        }
                        
                        //#line 122 "x10/regionarray/BlockBlockDistGhostManager.x10"
                        if (t$148144) {
                            
                            //#line 123 "x10/regionarray/BlockBlockDistGhostManager.x10"
                            neighborFlag$148148.received = true;
                            
                            //#line 124 "x10/regionarray/BlockBlockDistGhostManager.x10"
                            return;
                        }
                        
                        //#line 121 "x10/regionarray/BlockBlockDistGhostManager.x10"
                        final long t$148150 = ((idx$148151) + (((long)(1L))));
                        
                        //#line 121 "x10/regionarray/BlockBlockDistGhostManager.x10"
                        idx$148151 = t$148150;
                    }
                }
                
                //#line 127 "x10/regionarray/BlockBlockDistGhostManager.x10"
                final java.lang.String t$147929 = ((x10.x10rt.X10RT.here()) + (" trying to notify received from neighbor "));
                
                //#line 127 "x10/regionarray/BlockBlockDistGhostManager.x10"
                final java.lang.String t$147930 = ((t$147929) + (place));
                
                //#line 127 "x10/regionarray/BlockBlockDistGhostManager.x10"
                final java.lang.String t$147931 = ((t$147930) + (" shift "));
                
                //#line 127 "x10/regionarray/BlockBlockDistGhostManager.x10"
                final java.lang.String t$147932 = ((t$147931) + (shift));
                
                //#line 127 "x10/regionarray/BlockBlockDistGhostManager.x10"
                final java.lang.String t$147933 = ((t$147932) + (" - not a neighbor!"));
                
                //#line 127 "x10/regionarray/BlockBlockDistGhostManager.x10"
                final x10.lang.BadPlaceException t$147934 = ((x10.lang.BadPlaceException)(new x10.lang.BadPlaceException(t$147933)));
                
                //#line 127 "x10/regionarray/BlockBlockDistGhostManager.x10"
                throw t$147934;
            }
        }}finally {{
              
              //#line 120 "x10/regionarray/BlockBlockDistGhostManager.x10"
              x10.xrx.Runtime.exitAtomic();
          }}
        }
    
    
    //#line 130 "x10/regionarray/BlockBlockDistGhostManager.x10"
    public boolean allNeighborsReceived$O() {
        
        //#line 130 "x10/regionarray/BlockBlockDistGhostManager.x10"
        try {{
            
            //#line 130 "x10/regionarray/BlockBlockDistGhostManager.x10"
            x10.xrx.Runtime.enterAtomic();
            {
                
                //#line 131 "x10/regionarray/BlockBlockDistGhostManager.x10"
                long i = 0L;
                
                //#line 132 "x10/regionarray/BlockBlockDistGhostManager.x10"
                final x10.core.Rail rail$148167 = ((x10.core.Rail)(this.neighbors));
                
                //#line 132 "x10/regionarray/BlockBlockDistGhostManager.x10"
                final long size$148168 = ((x10.core.Rail<x10.regionarray.GhostManager.GhostNeighborFlag>)rail$148167).size;
                
                //#line 132 "x10/regionarray/BlockBlockDistGhostManager.x10"
                long idx$148164 = 0L;
                {
                    
                    //#line 132 "x10/regionarray/BlockBlockDistGhostManager.x10"
                    final x10.regionarray.GhostManager.GhostNeighborFlag[] rail$148167$value$148278 = ((x10.regionarray.GhostManager.GhostNeighborFlag[])rail$148167.value);
                    
                    //#line 132 "x10/regionarray/BlockBlockDistGhostManager.x10"
                    for (;
                         true;
                         ) {
                        
                        //#line 132 "x10/regionarray/BlockBlockDistGhostManager.x10"
                        final boolean t$148166 = ((idx$148164) < (((long)(size$148168))));
                        
                        //#line 132 "x10/regionarray/BlockBlockDistGhostManager.x10"
                        if (!(t$148166)) {
                            
                            //#line 132 "x10/regionarray/BlockBlockDistGhostManager.x10"
                            break;
                        }
                        
                        //#line 132 "x10/regionarray/BlockBlockDistGhostManager.x10"
                        final x10.regionarray.GhostManager.GhostNeighborFlag neighborFlag$148161 = ((x10.regionarray.GhostManager.GhostNeighborFlag)(((x10.regionarray.GhostManager.GhostNeighborFlag)rail$148167$value$148278[(int)idx$148164])));
                        
                        //#line 133 "x10/regionarray/BlockBlockDistGhostManager.x10"
                        final boolean t$148156 = neighborFlag$148161.received;
                        
                        //#line 133 "x10/regionarray/BlockBlockDistGhostManager.x10"
                        final boolean t$148157 = ((boolean) t$148156) == ((boolean) false);
                        
                        //#line 133 "x10/regionarray/BlockBlockDistGhostManager.x10"
                        if (t$148157) {
                            
                            //#line 134 "x10/regionarray/BlockBlockDistGhostManager.x10"
                            return false;
                        }
                        
                        //#line 136 "x10/regionarray/BlockBlockDistGhostManager.x10"
                        final long t$148159 = ((i) + (((long)(1L))));
                        
                        //#line 136 "x10/regionarray/BlockBlockDistGhostManager.x10"
                        i = t$148159;
                        
                        //#line 132 "x10/regionarray/BlockBlockDistGhostManager.x10"
                        final long t$148163 = ((idx$148164) + (((long)(1L))));
                        
                        //#line 132 "x10/regionarray/BlockBlockDistGhostManager.x10"
                        idx$148164 = t$148163;
                    }
                }
                
                //#line 138 "x10/regionarray/BlockBlockDistGhostManager.x10"
                return true;
            }
        }}finally {{
              
              //#line 130 "x10/regionarray/BlockBlockDistGhostManager.x10"
              x10.xrx.Runtime.exitAtomic();
          }}
        }
    
    
    //#line 141 "x10/regionarray/BlockBlockDistGhostManager.x10"
    public void resetNeighborsReceived() {
        
        //#line 141 "x10/regionarray/BlockBlockDistGhostManager.x10"
        try {{
            
            //#line 141 "x10/regionarray/BlockBlockDistGhostManager.x10"
            x10.xrx.Runtime.enterAtomic();
            {
                
                //#line 142 "x10/regionarray/BlockBlockDistGhostManager.x10"
                final x10.core.Rail rail$147415 = ((x10.core.Rail)(this.neighbors));
                
                //#line 142 "x10/regionarray/BlockBlockDistGhostManager.x10"
                final long size$147416 = ((x10.core.Rail<x10.regionarray.GhostManager.GhostNeighborFlag>)rail$147415).size;
                
                //#line 142 "x10/regionarray/BlockBlockDistGhostManager.x10"
                long idx$148173 = 0L;
                {
                    
                    //#line 142 "x10/regionarray/BlockBlockDistGhostManager.x10"
                    final x10.regionarray.GhostManager.GhostNeighborFlag[] rail$147415$value$148279 = ((x10.regionarray.GhostManager.GhostNeighborFlag[])rail$147415.value);
                    
                    //#line 142 "x10/regionarray/BlockBlockDistGhostManager.x10"
                    for (;
                         true;
                         ) {
                        
                        //#line 142 "x10/regionarray/BlockBlockDistGhostManager.x10"
                        final boolean t$148175 = ((idx$148173) < (((long)(size$147416))));
                        
                        //#line 142 "x10/regionarray/BlockBlockDistGhostManager.x10"
                        if (!(t$148175)) {
                            
                            //#line 142 "x10/regionarray/BlockBlockDistGhostManager.x10"
                            break;
                        }
                        
                        //#line 142 "x10/regionarray/BlockBlockDistGhostManager.x10"
                        final x10.regionarray.GhostManager.GhostNeighborFlag neighborFlag$148170 = ((x10.regionarray.GhostManager.GhostNeighborFlag)(((x10.regionarray.GhostManager.GhostNeighborFlag)rail$147415$value$148279[(int)idx$148173])));
                        
                        //#line 143 "x10/regionarray/BlockBlockDistGhostManager.x10"
                        neighborFlag$148170.received = false;
                        
                        //#line 142 "x10/regionarray/BlockBlockDistGhostManager.x10"
                        final long t$148172 = ((idx$148173) + (((long)(1L))));
                        
                        //#line 142 "x10/regionarray/BlockBlockDistGhostManager.x10"
                        idx$148173 = t$148172;
                    }
                }
            }
        }}finally {{
              
              //#line 141 "x10/regionarray/BlockBlockDistGhostManager.x10"
              x10.xrx.Runtime.exitAtomic();
          }}
        }
    
    
    //#line 147 "x10/regionarray/BlockBlockDistGhostManager.x10"
    private void setAllNeighborsReceived() {
        
        //#line 147 "x10/regionarray/BlockBlockDistGhostManager.x10"
        try {{
            
            //#line 147 "x10/regionarray/BlockBlockDistGhostManager.x10"
            x10.xrx.Runtime.enterAtomic();
            {
                
                //#line 148 "x10/regionarray/BlockBlockDistGhostManager.x10"
                final x10.core.Rail rail$147440 = ((x10.core.Rail)(this.neighbors));
                
                //#line 148 "x10/regionarray/BlockBlockDistGhostManager.x10"
                final long size$147441 = ((x10.core.Rail<x10.regionarray.GhostManager.GhostNeighborFlag>)rail$147440).size;
                
                //#line 148 "x10/regionarray/BlockBlockDistGhostManager.x10"
                long idx$148180 = 0L;
                {
                    
                    //#line 148 "x10/regionarray/BlockBlockDistGhostManager.x10"
                    final x10.regionarray.GhostManager.GhostNeighborFlag[] rail$147440$value$148280 = ((x10.regionarray.GhostManager.GhostNeighborFlag[])rail$147440.value);
                    
                    //#line 148 "x10/regionarray/BlockBlockDistGhostManager.x10"
                    for (;
                         true;
                         ) {
                        
                        //#line 148 "x10/regionarray/BlockBlockDistGhostManager.x10"
                        final boolean t$148182 = ((idx$148180) < (((long)(size$147441))));
                        
                        //#line 148 "x10/regionarray/BlockBlockDistGhostManager.x10"
                        if (!(t$148182)) {
                            
                            //#line 148 "x10/regionarray/BlockBlockDistGhostManager.x10"
                            break;
                        }
                        
                        //#line 148 "x10/regionarray/BlockBlockDistGhostManager.x10"
                        final x10.regionarray.GhostManager.GhostNeighborFlag neighborFlag$148177 = ((x10.regionarray.GhostManager.GhostNeighborFlag)(((x10.regionarray.GhostManager.GhostNeighborFlag)rail$147440$value$148280[(int)idx$148180])));
                        
                        //#line 149 "x10/regionarray/BlockBlockDistGhostManager.x10"
                        neighborFlag$148177.received = true;
                        
                        //#line 148 "x10/regionarray/BlockBlockDistGhostManager.x10"
                        final long t$148179 = ((idx$148180) + (((long)(1L))));
                        
                        //#line 148 "x10/regionarray/BlockBlockDistGhostManager.x10"
                        idx$148180 = t$148179;
                    }
                }
            }
        }}finally {{
              
              //#line 147 "x10/regionarray/BlockBlockDistGhostManager.x10"
              x10.xrx.Runtime.exitAtomic();
          }}
        }
    
    public static void setAllNeighborsReceived$P(final x10.regionarray.BlockBlockDistGhostManager BlockBlockDistGhostManager) {
        BlockBlockDistGhostManager.setAllNeighborsReceived();
    }
    
    
    //#line 153 "x10/regionarray/BlockBlockDistGhostManager.x10"
    private x10.lang.Point getNeighborShift(final long neighborBlockIndex0, final long neighborBlockIndex1, final long divisions0, final long divisions1, final boolean periodic) {
        
        //#line 154 "x10/regionarray/BlockBlockDistGhostManager.x10"
        long axis0Shift = 0L;
        
        //#line 155 "x10/regionarray/BlockBlockDistGhostManager.x10"
        long axis1Shift = 0L;
        
        //#line 157 "x10/regionarray/BlockBlockDistGhostManager.x10"
        if (periodic) {
            
            //#line 159 "x10/regionarray/BlockBlockDistGhostManager.x10"
            final boolean t$147958 = ((neighborBlockIndex0) < (((long)(0L))));
            
            //#line 159 "x10/regionarray/BlockBlockDistGhostManager.x10"
            if (t$147958) {
                
                //#line 160 "x10/regionarray/BlockBlockDistGhostManager.x10"
                axis0Shift = 1L;
            } else {
                
                //#line 161 "x10/regionarray/BlockBlockDistGhostManager.x10"
                final boolean t$147957 = ((neighborBlockIndex0) >= (((long)(divisions0))));
                
                //#line 161 "x10/regionarray/BlockBlockDistGhostManager.x10"
                if (t$147957) {
                    
                    //#line 162 "x10/regionarray/BlockBlockDistGhostManager.x10"
                    axis0Shift = -1L;
                }
            }
            
            //#line 164 "x10/regionarray/BlockBlockDistGhostManager.x10"
            final boolean t$147960 = ((neighborBlockIndex1) < (((long)(0L))));
            
            //#line 164 "x10/regionarray/BlockBlockDistGhostManager.x10"
            if (t$147960) {
                
                //#line 165 "x10/regionarray/BlockBlockDistGhostManager.x10"
                axis1Shift = 1L;
            } else {
                
                //#line 166 "x10/regionarray/BlockBlockDistGhostManager.x10"
                final boolean t$147959 = ((neighborBlockIndex1) >= (((long)(divisions1))));
                
                //#line 166 "x10/regionarray/BlockBlockDistGhostManager.x10"
                if (t$147959) {
                    
                    //#line 167 "x10/regionarray/BlockBlockDistGhostManager.x10"
                    axis1Shift = -1L;
                }
            }
        }
        
        //#line 170 "x10/regionarray/BlockBlockDistGhostManager.x10"
        final x10.lang.Point t$147963 = ((x10.lang.Point)(this.getShift((long)(axis0Shift), (long)(axis1Shift))));
        
        //#line 170 "x10/regionarray/BlockBlockDistGhostManager.x10"
        return t$147963;
    }
    
    public static x10.lang.Point getNeighborShift$P(final long neighborBlockIndex0, final long neighborBlockIndex1, final long divisions0, final long divisions1, final boolean periodic, final x10.regionarray.BlockBlockDistGhostManager BlockBlockDistGhostManager) {
        return BlockBlockDistGhostManager.getNeighborShift((long)(neighborBlockIndex0), (long)(neighborBlockIndex1), (long)(divisions0), (long)(divisions1), (boolean)(periodic));
    }
    
    
    //#line 173 "x10/regionarray/BlockBlockDistGhostManager.x10"
    private x10.lang.Point getShift(final long axis0Shift, final long axis1Shift) {
        
        //#line 174 "x10/regionarray/BlockBlockDistGhostManager.x10"
        final x10.regionarray.BlockBlockDist t$147964 = ((x10.regionarray.BlockBlockDist)(this.bbd));
        
        //#line 174 "x10/regionarray/BlockBlockDistGhostManager.x10"
        final x10.regionarray.Region fullRegion = ((x10.regionarray.Region)(t$147964.region));
        
        //#line 175 "x10/regionarray/BlockBlockDistGhostManager.x10"
        final x10.regionarray.BlockBlockDist t$147965 = ((x10.regionarray.BlockBlockDist)(this.bbd));
        
        //#line 175 "x10/regionarray/BlockBlockDistGhostManager.x10"
        final long axis0 = t$147965.axis0;
        
        //#line 176 "x10/regionarray/BlockBlockDistGhostManager.x10"
        final x10.regionarray.BlockBlockDist t$147966 = ((x10.regionarray.BlockBlockDist)(this.bbd));
        
        //#line 176 "x10/regionarray/BlockBlockDistGhostManager.x10"
        final long axis1 = t$147966.axis1;
        
        //#line 177 "x10/regionarray/BlockBlockDistGhostManager.x10"
        final long t$147967 = fullRegion.max$O((long)(axis0));
        
        //#line 177 "x10/regionarray/BlockBlockDistGhostManager.x10"
        final long t$147968 = fullRegion.min$O((long)(axis0));
        
        //#line 177 "x10/regionarray/BlockBlockDistGhostManager.x10"
        final long t$147969 = ((t$147967) - (((long)(t$147968))));
        
        //#line 177 "x10/regionarray/BlockBlockDistGhostManager.x10"
        final long axis0Size = ((t$147969) + (((long)(1L))));
        
        //#line 178 "x10/regionarray/BlockBlockDistGhostManager.x10"
        final long t$147970 = fullRegion.max$O((long)(axis1));
        
        //#line 178 "x10/regionarray/BlockBlockDistGhostManager.x10"
        final long t$147971 = fullRegion.min$O((long)(axis1));
        
        //#line 178 "x10/regionarray/BlockBlockDistGhostManager.x10"
        final long t$147972 = ((t$147970) - (((long)(t$147971))));
        
        //#line 178 "x10/regionarray/BlockBlockDistGhostManager.x10"
        final long axis1Size = ((t$147972) + (((long)(1L))));
        
        //#line 179 "x10/regionarray/BlockBlockDistGhostManager.x10"
        final long t$147973 = fullRegion.rank;
        
        //#line 179 "x10/regionarray/BlockBlockDistGhostManager.x10"
        final x10.core.Rail coords = ((x10.core.Rail)(new x10.core.Rail<x10.core.Long>(x10.rtt.Types.LONG, ((long)(t$147973)))));
        
        //#line 180 "x10/regionarray/BlockBlockDistGhostManager.x10"
        final long t$147974 = ((axis0Shift) * (((long)(axis0Size))));
        
        //#line 180 "x10/regionarray/BlockBlockDistGhostManager.x10"
        ((long[])coords.value)[(int)axis0] = t$147974;
        
        //#line 181 "x10/regionarray/BlockBlockDistGhostManager.x10"
        final long t$147975 = ((axis1Shift) * (((long)(axis1Size))));
        
        //#line 181 "x10/regionarray/BlockBlockDistGhostManager.x10"
        ((long[])coords.value)[(int)axis1] = t$147975;
        
        //#line 183 "x10/regionarray/BlockBlockDistGhostManager.x10"
        final x10.lang.Point t$147976 = ((x10.lang.Point)(x10.lang.Point.make__0$1x10$lang$Long$2(((x10.core.Rail)(coords)))));
        
        //#line 183 "x10/regionarray/BlockBlockDistGhostManager.x10"
        return t$147976;
    }
    
    public static x10.lang.Point getShift$P(final long axis0Shift, final long axis1Shift, final x10.regionarray.BlockBlockDistGhostManager BlockBlockDistGhostManager) {
        return BlockBlockDistGhostManager.getShift((long)(axis0Shift), (long)(axis1Shift));
    }
    
    
    //#line 190 "x10/regionarray/BlockBlockDistGhostManager.x10"
    /**
     * Send ghost data for this place to neighboring places in a BlockBlockDist 
     * using a simple 'put' algorithm with no internal synchronization.
     */
    public void sendGhosts(final x10.regionarray.Ghostable array) {
        
        //#line 191 "x10/regionarray/BlockBlockDistGhostManager.x10"
        this.prepareToSendGhosts();
        
        //#line 192 "x10/regionarray/BlockBlockDistGhostManager.x10"
        final x10.regionarray.BlockBlockDist this$147828 = ((x10.regionarray.BlockBlockDist)(this.bbd));
        
        //#line 192 "x10/regionarray/BlockBlockDistGhostManager.x10"
        final x10.lang.Place p$147827 = ((x10.lang.Place)(x10.x10rt.X10RT.here()));
        
        //#line 192 "x10/regionarray/BlockBlockDistGhostManager.x10"
        final x10.regionarray.Region regionHere = ((x10.regionarray.Region)(this$147828.get(((x10.lang.Place)(p$147827)))));
        
        //#line 193 "x10/regionarray/BlockBlockDistGhostManager.x10"
        final boolean t$147977 = regionHere.isEmpty$O();
        
        //#line 193 "x10/regionarray/BlockBlockDistGhostManager.x10"
        if (t$147977) {
            
            //#line 194 "x10/regionarray/BlockBlockDistGhostManager.x10"
            this.setAllNeighborsReceived();
            
            //#line 195 "x10/regionarray/BlockBlockDistGhostManager.x10"
            return;
        }
        
        //#line 198 "x10/regionarray/BlockBlockDistGhostManager.x10"
        final x10.core.Rail rail$148238 = ((x10.core.Rail)(this.neighbors));
        
        //#line 198 "x10/regionarray/BlockBlockDistGhostManager.x10"
        final long size$148239 = ((x10.core.Rail<x10.regionarray.GhostManager.GhostNeighborFlag>)rail$148238).size;
        
        //#line 198 "x10/regionarray/BlockBlockDistGhostManager.x10"
        long idx$148235 = 0L;
        {
            
            //#line 198 "x10/regionarray/BlockBlockDistGhostManager.x10"
            final x10.regionarray.GhostManager.GhostNeighborFlag[] rail$148238$value$148281 = ((x10.regionarray.GhostManager.GhostNeighborFlag[])rail$148238.value);
            
            //#line 198 "x10/regionarray/BlockBlockDistGhostManager.x10"
            for (;
                 true;
                 ) {
                
                //#line 198 "x10/regionarray/BlockBlockDistGhostManager.x10"
                final boolean t$148237 = ((idx$148235) < (((long)(size$148239))));
                
                //#line 198 "x10/regionarray/BlockBlockDistGhostManager.x10"
                if (!(t$148237)) {
                    
                    //#line 198 "x10/regionarray/BlockBlockDistGhostManager.x10"
                    break;
                }
                
                //#line 198 "x10/regionarray/BlockBlockDistGhostManager.x10"
                final x10.regionarray.GhostManager.GhostNeighborFlag neighborFlag$148232 = ((x10.regionarray.GhostManager.GhostNeighborFlag)(((x10.regionarray.GhostManager.GhostNeighborFlag)rail$148238$value$148281[(int)idx$148235])));
                
                //#line 199 "x10/regionarray/BlockBlockDistGhostManager.x10"
                boolean sentToNeighbor$148183 = false;
                
                //#line 200 "x10/regionarray/BlockBlockDistGhostManager.x10"
                final x10.lang.Place neighborPlace$148184 = ((x10.lang.Place)(neighborFlag$148232.place));
                
                //#line 201 "x10/regionarray/BlockBlockDistGhostManager.x10"
                boolean t$148185 = (!x10.rtt.Equality.equalsequals((neighborPlace$148184),(x10.x10rt.X10RT.here())));
                
                //#line 201 "x10/regionarray/BlockBlockDistGhostManager.x10"
                if (!(t$148185)) {
                    
                    //#line 201 "x10/regionarray/BlockBlockDistGhostManager.x10"
                    t$148185 = this.periodic;
                }
                
                //#line 201 "x10/regionarray/BlockBlockDistGhostManager.x10"
                if (t$148185) {
                    
                    //#line 202 "x10/regionarray/BlockBlockDistGhostManager.x10"
                    final x10.regionarray.Region t$148187 = this.getGhostRegion(((x10.lang.Place)(neighborPlace$148184)));
                    
                    //#line 202 "x10/regionarray/BlockBlockDistGhostManager.x10"
                    final x10.regionarray.Region t$148188 = ((x10.regionarray.Region)
                                                              t$148187);
                    
                    //#line 202 "x10/regionarray/BlockBlockDistGhostManager.x10"
                    final boolean t$148189 = t$148188.rect;
                    
                    //#line 202 "x10/regionarray/BlockBlockDistGhostManager.x10"
                    boolean t$148190 = ((boolean) t$148189) == ((boolean) true);
                    
                    //#line 202 "x10/regionarray/BlockBlockDistGhostManager.x10"
                    if (t$148190) {
                        
                        //#line 202 "x10/regionarray/BlockBlockDistGhostManager.x10"
                        final long t$148191 = t$148188.rank;
                        
                        //#line 202 "x10/regionarray/BlockBlockDistGhostManager.x10"
                        final x10.regionarray.BlockBlockDist t$148192 = ((x10.regionarray.BlockBlockDist)(x10.regionarray.BlockBlockDistGhostManager.this.bbd));
                        
                        //#line 202 "x10/regionarray/BlockBlockDistGhostManager.x10"
                        final x10.regionarray.Region t$148193 = ((x10.regionarray.Region)(t$148192.region));
                        
                        //#line 202 "x10/regionarray/BlockBlockDistGhostManager.x10"
                        final long t$148194 = t$148193.rank;
                        
                        //#line 202 "x10/regionarray/BlockBlockDistGhostManager.x10"
                        t$148190 = ((long) t$148191) == ((long) t$148194);
                    }
                    
                    //#line 202 "x10/regionarray/BlockBlockDistGhostManager.x10"
                    final boolean t$148196 = !(t$148190);
                    
                    //#line 202 "x10/regionarray/BlockBlockDistGhostManager.x10"
                    if (t$148196) {
                        
                        //#line 202 "x10/regionarray/BlockBlockDistGhostManager.x10"
                        final x10.lang.FailedDynamicCheckException t$148197 = new x10.lang.FailedDynamicCheckException("x10.regionarray.Region{self.rect==true, self.rank==this(:x10.regionarray.BlockBlockDistGhostManager).bbd.region.rank}");
                        
                        //#line 202 "x10/regionarray/BlockBlockDistGhostManager.x10"
                        throw t$148197;
                    }
                    
                    //#line 204 "x10/regionarray/BlockBlockDistGhostManager.x10"
                    x10.regionarray.Region regionToSend$148199 =  null;
                    
                    //#line 205 "x10/regionarray/BlockBlockDistGhostManager.x10"
                    final x10.lang.Point t$148200 = ((x10.lang.Point)(neighborFlag$148232.shift));
                    
                    //#line 205 "x10/regionarray/BlockBlockDistGhostManager.x10"
                    final x10.lang.Point t$148201 = ((x10.lang.Point)
                                                      t$148200);
                    
                    //#line 205 "x10/regionarray/BlockBlockDistGhostManager.x10"
                    final long t$148202 = t$148201.rank;
                    
                    //#line 205 "x10/regionarray/BlockBlockDistGhostManager.x10"
                    final long t$148203 = regionHere.rank;
                    
                    //#line 205 "x10/regionarray/BlockBlockDistGhostManager.x10"
                    final boolean t$148204 = ((long) t$148202) == ((long) t$148203);
                    
                    //#line 205 "x10/regionarray/BlockBlockDistGhostManager.x10"
                    final boolean t$148205 = !(t$148204);
                    
                    //#line 205 "x10/regionarray/BlockBlockDistGhostManager.x10"
                    if (t$148205) {
                        
                        //#line 205 "x10/regionarray/BlockBlockDistGhostManager.x10"
                        final x10.lang.FailedDynamicCheckException t$148206 = new x10.lang.FailedDynamicCheckException("x10.lang.Point{self.rank==regionHere.rank}");
                        
                        //#line 205 "x10/regionarray/BlockBlockDistGhostManager.x10"
                        throw t$148206;
                    }
                    
                    //#line 206 "x10/regionarray/BlockBlockDistGhostManager.x10"
                    final boolean t$148208 = this.periodic;
                    
                    //#line 206 "x10/regionarray/BlockBlockDistGhostManager.x10"
                    if (t$148208) {
                        
                        //#line 207 "x10/regionarray/BlockBlockDistGhostManager.x10"
                        final x10.regionarray.Region shiftedNeighbor$148209 = ((x10.regionarray.Region)(t$148188.$minus(((x10.lang.Point)(t$148201)))));
                        
                        //#line 208 "x10/regionarray/BlockBlockDistGhostManager.x10"
                        final x10.regionarray.Region t$148210 = ((x10.regionarray.Region)(regionHere.$and(((x10.regionarray.Region)(shiftedNeighbor$148209)))));
                        
                        //#line 208 "x10/regionarray/BlockBlockDistGhostManager.x10"
                        final x10.regionarray.Region t$148211 = ((x10.regionarray.Region)
                                                                  t$148210);
                        
                        //#line 208 "x10/regionarray/BlockBlockDistGhostManager.x10"
                        final boolean t$148212 = t$148211.rect;
                        
                        //#line 208 "x10/regionarray/BlockBlockDistGhostManager.x10"
                        boolean t$148213 = ((boolean) t$148212) == ((boolean) true);
                        
                        //#line 208 "x10/regionarray/BlockBlockDistGhostManager.x10"
                        if (t$148213) {
                            
                            //#line 208 "x10/regionarray/BlockBlockDistGhostManager.x10"
                            final long t$148214 = t$148211.rank;
                            
                            //#line 208 "x10/regionarray/BlockBlockDistGhostManager.x10"
                            final long t$148215 = regionHere.rank;
                            
                            //#line 208 "x10/regionarray/BlockBlockDistGhostManager.x10"
                            t$148213 = ((long) t$148214) == ((long) t$148215);
                        }
                        
                        //#line 208 "x10/regionarray/BlockBlockDistGhostManager.x10"
                        final boolean t$148217 = !(t$148213);
                        
                        //#line 208 "x10/regionarray/BlockBlockDistGhostManager.x10"
                        if (t$148217) {
                            
                            //#line 208 "x10/regionarray/BlockBlockDistGhostManager.x10"
                            final x10.lang.FailedDynamicCheckException t$148218 = new x10.lang.FailedDynamicCheckException("x10.regionarray.Region{self.rect==true, self.rank==regionHere.rank}");
                            
                            //#line 208 "x10/regionarray/BlockBlockDistGhostManager.x10"
                            throw t$148218;
                        }
                        
                        //#line 208 "x10/regionarray/BlockBlockDistGhostManager.x10"
                        regionToSend$148199 = ((x10.regionarray.Region)(t$148211));
                    } else {
                        
                        //#line 210 "x10/regionarray/BlockBlockDistGhostManager.x10"
                        final x10.regionarray.Region t$148219 = ((x10.regionarray.Region)(regionHere.$and(((x10.regionarray.Region)(t$148188)))));
                        
                        //#line 210 "x10/regionarray/BlockBlockDistGhostManager.x10"
                        final x10.regionarray.Region t$148220 = ((x10.regionarray.Region)
                                                                  t$148219);
                        
                        //#line 210 "x10/regionarray/BlockBlockDistGhostManager.x10"
                        final boolean t$148221 = t$148220.rect;
                        
                        //#line 210 "x10/regionarray/BlockBlockDistGhostManager.x10"
                        boolean t$148222 = ((boolean) t$148221) == ((boolean) true);
                        
                        //#line 210 "x10/regionarray/BlockBlockDistGhostManager.x10"
                        if (t$148222) {
                            
                            //#line 210 "x10/regionarray/BlockBlockDistGhostManager.x10"
                            final long t$148223 = t$148220.rank;
                            
                            //#line 210 "x10/regionarray/BlockBlockDistGhostManager.x10"
                            final long t$148224 = regionHere.rank;
                            
                            //#line 210 "x10/regionarray/BlockBlockDistGhostManager.x10"
                            t$148222 = ((long) t$148223) == ((long) t$148224);
                        }
                        
                        //#line 210 "x10/regionarray/BlockBlockDistGhostManager.x10"
                        final boolean t$148226 = !(t$148222);
                        
                        //#line 210 "x10/regionarray/BlockBlockDistGhostManager.x10"
                        if (t$148226) {
                            
                            //#line 210 "x10/regionarray/BlockBlockDistGhostManager.x10"
                            final x10.lang.FailedDynamicCheckException t$148227 = new x10.lang.FailedDynamicCheckException("x10.regionarray.Region{self.rect==true, self.rank==regionHere.rank}");
                            
                            //#line 210 "x10/regionarray/BlockBlockDistGhostManager.x10"
                            throw t$148227;
                        }
                        
                        //#line 210 "x10/regionarray/BlockBlockDistGhostManager.x10"
                        regionToSend$148199 = ((x10.regionarray.Region)(t$148220));
                    }
                    
                    //#line 212 "x10/regionarray/BlockBlockDistGhostManager.x10"
                    final x10.regionarray.GhostManager this$148229 = ((x10.regionarray.GhostManager)
                                                                       this);
                    
                    //#line 43 . "x10/regionarray/GhostManager.x10"
                    final byte t$148230 = this$148229.currentPhase;
                    
                    //#line 212 "x10/regionarray/BlockBlockDistGhostManager.x10"
                    array.putOverlap(((x10.regionarray.Region)(regionToSend$148199)), ((x10.lang.Place)(neighborPlace$148184)), ((x10.lang.Point)(t$148201)), (byte)(t$148230));
                    
                    //#line 213 "x10/regionarray/BlockBlockDistGhostManager.x10"
                    sentToNeighbor$148183 = true;
                }
                
                //#line 198 "x10/regionarray/BlockBlockDistGhostManager.x10"
                final long t$148234 = ((idx$148235) + (((long)(1L))));
                
                //#line 198 "x10/regionarray/BlockBlockDistGhostManager.x10"
                idx$148235 = t$148234;
            }
        }
    }
    
    
    //#line 227 "x10/regionarray/BlockBlockDistGhostManager.x10"
    /**
     * Gets the ghost region for a given place, which is the bounding box 
     * for the region held at that place, expanded in each dimension by
     * <code>ghostWidth</code>.  For a periodic distribution, the ghost
     * region may extend beyond the limits of the entire region. For a 
     * non-periodic dist, the ghost region does not extend beyond the min/max
     * of the region in any dimension.
     * @return the ghost region for the given place
     */
    public x10.regionarray.Region getGhostRegion(final x10.lang.Place place) {
        
        //#line 228 "x10/regionarray/BlockBlockDistGhostManager.x10"
        final x10.regionarray.BlockBlockDist this$147833 = ((x10.regionarray.BlockBlockDist)(this.bbd));
        
        //#line 228 "x10/regionarray/BlockBlockDistGhostManager.x10"
        final x10.regionarray.Region region = ((x10.regionarray.Region)(this$147833.get(((x10.lang.Place)(place)))));
        
        //#line 229 "x10/regionarray/BlockBlockDistGhostManager.x10"
        final boolean t$148021 = region.isEmpty$O();
        
        //#line 229 "x10/regionarray/BlockBlockDistGhostManager.x10"
        if (t$148021) {
            
            //#line 229 "x10/regionarray/BlockBlockDistGhostManager.x10"
            return region;
        }
        
        //#line 231 "x10/regionarray/BlockBlockDistGhostManager.x10"
        final x10.regionarray.Region r = ((x10.regionarray.Region)(region.boundingBox()));
        
        //#line 232 "x10/regionarray/BlockBlockDistGhostManager.x10"
        final long t$148022 = r.rank;
        
        //#line 232 "x10/regionarray/BlockBlockDistGhostManager.x10"
        final x10.core.Rail min = ((x10.core.Rail)(new x10.core.Rail<x10.core.Long>(x10.rtt.Types.LONG, ((long)(t$148022)))));
        
        //#line 233 "x10/regionarray/BlockBlockDistGhostManager.x10"
        final long t$148023 = r.rank;
        
        //#line 233 "x10/regionarray/BlockBlockDistGhostManager.x10"
        final x10.core.Rail max = ((x10.core.Rail)(new x10.core.Rail<x10.core.Long>(x10.rtt.Types.LONG, ((long)(t$148023)))));
        
        //#line 234 "x10/regionarray/BlockBlockDistGhostManager.x10"
        final long t$148275 = r.rank;
        
        //#line 234 "x10/regionarray/BlockBlockDistGhostManager.x10"
        final long i$147489max$148276 = ((t$148275) - (((long)(1L))));
        
        //#line 234 "x10/regionarray/BlockBlockDistGhostManager.x10"
        long i$148272 = 0L;
        {
            
            //#line 234 "x10/regionarray/BlockBlockDistGhostManager.x10"
            final long[] min$value$148282 = ((long[])min.value);
            
            //#line 234 "x10/regionarray/BlockBlockDistGhostManager.x10"
            final long[] max$value$148283 = ((long[])max.value);
            
            //#line 234 "x10/regionarray/BlockBlockDistGhostManager.x10"
            for (;
                 true;
                 ) {
                
                //#line 234 "x10/regionarray/BlockBlockDistGhostManager.x10"
                final boolean t$148274 = ((i$148272) <= (((long)(i$147489max$148276))));
                
                //#line 234 "x10/regionarray/BlockBlockDistGhostManager.x10"
                if (!(t$148274)) {
                    
                    //#line 234 "x10/regionarray/BlockBlockDistGhostManager.x10"
                    break;
                }
                
                //#line 235 "x10/regionarray/BlockBlockDistGhostManager.x10"
                final x10.regionarray.BlockBlockDist t$148240 = ((x10.regionarray.BlockBlockDist)(this.bbd));
                
                //#line 235 "x10/regionarray/BlockBlockDistGhostManager.x10"
                final long t$148241 = t$148240.axis0;
                
                //#line 235 "x10/regionarray/BlockBlockDistGhostManager.x10"
                boolean t$148242 = ((long) i$148272) == ((long) t$148241);
                
                //#line 235 "x10/regionarray/BlockBlockDistGhostManager.x10"
                if (!(t$148242)) {
                    
                    //#line 235 "x10/regionarray/BlockBlockDistGhostManager.x10"
                    final x10.regionarray.BlockBlockDist t$148243 = ((x10.regionarray.BlockBlockDist)(this.bbd));
                    
                    //#line 235 "x10/regionarray/BlockBlockDistGhostManager.x10"
                    final long t$148244 = t$148243.axis1;
                    
                    //#line 235 "x10/regionarray/BlockBlockDistGhostManager.x10"
                    t$148242 = ((long) i$148272) == ((long) t$148244);
                }
                
                //#line 235 "x10/regionarray/BlockBlockDistGhostManager.x10"
                if (t$148242) {
                    
                    //#line 236 "x10/regionarray/BlockBlockDistGhostManager.x10"
                    final boolean t$148246 = this.periodic;
                    
                    //#line 236 "x10/regionarray/BlockBlockDistGhostManager.x10"
                    if (t$148246) {
                        
                        //#line 237 "x10/regionarray/BlockBlockDistGhostManager.x10"
                        final long t$148247 = r.min$O((long)(i$148272));
                        
                        //#line 237 "x10/regionarray/BlockBlockDistGhostManager.x10"
                        final long t$148248 = this.ghostWidth;
                        
                        //#line 237 "x10/regionarray/BlockBlockDistGhostManager.x10"
                        final long t$148249 = ((t$148247) - (((long)(t$148248))));
                        
                        //#line 237 "x10/regionarray/BlockBlockDistGhostManager.x10"
                        min$value$148282[(int)i$148272]=t$148249;
                        
                        //#line 238 "x10/regionarray/BlockBlockDistGhostManager.x10"
                        final long t$148250 = r.max$O((long)(i$148272));
                        
                        //#line 238 "x10/regionarray/BlockBlockDistGhostManager.x10"
                        final long t$148251 = this.ghostWidth;
                        
                        //#line 238 "x10/regionarray/BlockBlockDistGhostManager.x10"
                        final long t$148252 = ((t$148250) + (((long)(t$148251))));
                        
                        //#line 238 "x10/regionarray/BlockBlockDistGhostManager.x10"
                        max$value$148283[(int)i$148272]=t$148252;
                    } else {
                        
                        //#line 240 "x10/regionarray/BlockBlockDistGhostManager.x10"
                        final x10.regionarray.BlockBlockDist t$148253 = ((x10.regionarray.BlockBlockDist)(this.bbd));
                        
                        //#line 240 "x10/regionarray/BlockBlockDistGhostManager.x10"
                        final x10.regionarray.Region t$148254 = ((x10.regionarray.Region)(t$148253.region));
                        
                        //#line 240 "x10/regionarray/BlockBlockDistGhostManager.x10"
                        final long t$148255 = t$148254.min$O((long)(i$148272));
                        
                        //#line 240 "x10/regionarray/BlockBlockDistGhostManager.x10"
                        final long t$148256 = r.min$O((long)(i$148272));
                        
                        //#line 240 "x10/regionarray/BlockBlockDistGhostManager.x10"
                        final long t$148257 = this.ghostWidth;
                        
                        //#line 240 "x10/regionarray/BlockBlockDistGhostManager.x10"
                        final long t$148258 = ((t$148256) - (((long)(t$148257))));
                        
                        //#line 240 "x10/regionarray/BlockBlockDistGhostManager.x10"
                        final long t$148259 = java.lang.Math.max(((long)(t$148255)),((long)(t$148258)));
                        
                        //#line 240 "x10/regionarray/BlockBlockDistGhostManager.x10"
                        min$value$148282[(int)i$148272]=t$148259;
                        
                        //#line 241 "x10/regionarray/BlockBlockDistGhostManager.x10"
                        final x10.regionarray.BlockBlockDist t$148260 = ((x10.regionarray.BlockBlockDist)(this.bbd));
                        
                        //#line 241 "x10/regionarray/BlockBlockDistGhostManager.x10"
                        final x10.regionarray.Region t$148261 = ((x10.regionarray.Region)(t$148260.region));
                        
                        //#line 241 "x10/regionarray/BlockBlockDistGhostManager.x10"
                        final long t$148262 = t$148261.max$O((long)(i$148272));
                        
                        //#line 241 "x10/regionarray/BlockBlockDistGhostManager.x10"
                        final long t$148263 = r.max$O((long)(i$148272));
                        
                        //#line 241 "x10/regionarray/BlockBlockDistGhostManager.x10"
                        final long t$148264 = this.ghostWidth;
                        
                        //#line 241 "x10/regionarray/BlockBlockDistGhostManager.x10"
                        final long t$148265 = ((t$148263) + (((long)(t$148264))));
                        
                        //#line 241 "x10/regionarray/BlockBlockDistGhostManager.x10"
                        final long t$148266 = java.lang.Math.min(((long)(t$148262)),((long)(t$148265)));
                        
                        //#line 241 "x10/regionarray/BlockBlockDistGhostManager.x10"
                        max$value$148283[(int)i$148272]=t$148266;
                    }
                } else {
                    
                    //#line 244 "x10/regionarray/BlockBlockDistGhostManager.x10"
                    final long t$148267 = r.min$O((long)(i$148272));
                    
                    //#line 244 "x10/regionarray/BlockBlockDistGhostManager.x10"
                    min$value$148282[(int)i$148272]=t$148267;
                    
                    //#line 245 "x10/regionarray/BlockBlockDistGhostManager.x10"
                    final long t$148268 = r.max$O((long)(i$148272));
                    
                    //#line 245 "x10/regionarray/BlockBlockDistGhostManager.x10"
                    max$value$148283[(int)i$148272]=t$148268;
                }
                
                //#line 234 "x10/regionarray/BlockBlockDistGhostManager.x10"
                final long t$148271 = ((i$148272) + (((long)(1L))));
                
                //#line 234 "x10/regionarray/BlockBlockDistGhostManager.x10"
                i$148272 = t$148271;
            }
        }
        
        //#line 248 "x10/regionarray/BlockBlockDistGhostManager.x10"
        final x10.regionarray.Region t$148059 = ((x10.regionarray.Region)(x10.regionarray.Region.makeRectangular__0$1x10$lang$Long$2__1$1x10$lang$Long$2(((x10.core.Rail)(min)), ((x10.core.Rail)(max)))));
        
        //#line 248 "x10/regionarray/BlockBlockDistGhostManager.x10"
        return t$148059;
    }
    
    
    //#line 251 "x10/regionarray/BlockBlockDistGhostManager.x10"
    private static long getGroupIndex$O(long neighborBlockIndex0, long neighborBlockIndex1, final long divisions0, final long divisions1, final long leftOver, final boolean periodic, final long groupIndexHere) {
        
        //#line 252 "x10/regionarray/BlockBlockDistGhostManager.x10"
        if (periodic) {
            
            //#line 254 "x10/regionarray/BlockBlockDistGhostManager.x10"
            final boolean t$148067 = ((neighborBlockIndex0) < (((long)(0L))));
            
            //#line 254 "x10/regionarray/BlockBlockDistGhostManager.x10"
            if (t$148067) {
                
                //#line 255 "x10/regionarray/BlockBlockDistGhostManager.x10"
                final long t$148062 = ((neighborBlockIndex0) + (((long)(divisions0))));
                
                //#line 255 "x10/regionarray/BlockBlockDistGhostManager.x10"
                neighborBlockIndex0 = t$148062;
            } else {
                
                //#line 256 "x10/regionarray/BlockBlockDistGhostManager.x10"
                final boolean t$148066 = ((neighborBlockIndex0) >= (((long)(divisions0))));
                
                //#line 256 "x10/regionarray/BlockBlockDistGhostManager.x10"
                if (t$148066) {
                    
                    //#line 257 "x10/regionarray/BlockBlockDistGhostManager.x10"
                    final long t$148065 = ((neighborBlockIndex0) - (((long)(divisions0))));
                    
                    //#line 257 "x10/regionarray/BlockBlockDistGhostManager.x10"
                    neighborBlockIndex0 = t$148065;
                }
            }
            
            //#line 259 "x10/regionarray/BlockBlockDistGhostManager.x10"
            final boolean t$148075 = ((neighborBlockIndex1) < (((long)(0L))));
            
            //#line 259 "x10/regionarray/BlockBlockDistGhostManager.x10"
            if (t$148075) {
                
                //#line 260 "x10/regionarray/BlockBlockDistGhostManager.x10"
                final long t$148070 = ((neighborBlockIndex1) + (((long)(divisions1))));
                
                //#line 260 "x10/regionarray/BlockBlockDistGhostManager.x10"
                neighborBlockIndex1 = t$148070;
            } else {
                
                //#line 261 "x10/regionarray/BlockBlockDistGhostManager.x10"
                final boolean t$148074 = ((neighborBlockIndex1) >= (((long)(divisions1))));
                
                //#line 261 "x10/regionarray/BlockBlockDistGhostManager.x10"
                if (t$148074) {
                    
                    //#line 262 "x10/regionarray/BlockBlockDistGhostManager.x10"
                    final long t$148073 = ((neighborBlockIndex1) - (((long)(divisions1))));
                    
                    //#line 262 "x10/regionarray/BlockBlockDistGhostManager.x10"
                    neighborBlockIndex1 = t$148073;
                }
            }
        } else {
            
            //#line 265 "x10/regionarray/BlockBlockDistGhostManager.x10"
            boolean t$148078 = ((neighborBlockIndex0) < (((long)(0L))));
            
            //#line 265 "x10/regionarray/BlockBlockDistGhostManager.x10"
            if (!(t$148078)) {
                
                //#line 265 "x10/regionarray/BlockBlockDistGhostManager.x10"
                t$148078 = ((neighborBlockIndex0) >= (((long)(divisions0))));
            }
            
            //#line 265 "x10/regionarray/BlockBlockDistGhostManager.x10"
            boolean t$148080 = t$148078;
            
            //#line 265 "x10/regionarray/BlockBlockDistGhostManager.x10"
            if (!(t$148078)) {
                
                //#line 265 "x10/regionarray/BlockBlockDistGhostManager.x10"
                t$148080 = ((neighborBlockIndex1) < (((long)(0L))));
            }
            
            //#line 265 "x10/regionarray/BlockBlockDistGhostManager.x10"
            boolean t$148082 = t$148080;
            
            //#line 265 "x10/regionarray/BlockBlockDistGhostManager.x10"
            if (!(t$148080)) {
                
                //#line 265 "x10/regionarray/BlockBlockDistGhostManager.x10"
                t$148082 = ((neighborBlockIndex1) >= (((long)(divisions1))));
            }
            
            //#line 265 "x10/regionarray/BlockBlockDistGhostManager.x10"
            if (t$148082) {
                
                //#line 270 "x10/regionarray/BlockBlockDistGhostManager.x10"
                return groupIndexHere;
            }
        }
        
        //#line 273 "x10/regionarray/BlockBlockDistGhostManager.x10"
        final long groupIndex;
        
        //#line 274 "x10/regionarray/BlockBlockDistGhostManager.x10"
        final long t$148085 = ((neighborBlockIndex1) * (((long)(divisions0))));
        
        //#line 274 "x10/regionarray/BlockBlockDistGhostManager.x10"
        final long neighborBlockIndex = ((t$148085) + (((long)(neighborBlockIndex0))));
        
        //#line 275 "x10/regionarray/BlockBlockDistGhostManager.x10"
        final long t$148087 = ((leftOver) * (((long)(2L))));
        
        //#line 275 "x10/regionarray/BlockBlockDistGhostManager.x10"
        final boolean t$148091 = ((neighborBlockIndex) <= (((long)(t$148087))));
        
        //#line 275 "x10/regionarray/BlockBlockDistGhostManager.x10"
        if (t$148091) {
            
            //#line 276 "x10/regionarray/BlockBlockDistGhostManager.x10"
            final long t$148088 = ((neighborBlockIndex) / (((long)(2L))));
            
            //#line 276 "x10/regionarray/BlockBlockDistGhostManager.x10"
            final long t$148089 = t$148088;
            
            //#line 276 "x10/regionarray/BlockBlockDistGhostManager.x10"
            groupIndex = t$148089;
        } else {
            
            //#line 278 "x10/regionarray/BlockBlockDistGhostManager.x10"
            final long t$148090 = ((neighborBlockIndex) - (((long)(leftOver))));
            
            //#line 278 "x10/regionarray/BlockBlockDistGhostManager.x10"
            groupIndex = t$148090;
        }
        
        //#line 280 "x10/regionarray/BlockBlockDistGhostManager.x10"
        return groupIndex;
    }
    
    public static long getGroupIndex$P$O(long neighborBlockIndex0, long neighborBlockIndex1, final long divisions0, final long divisions1, final long leftOver, final boolean periodic, final long groupIndexHere) {
        return x10.regionarray.BlockBlockDistGhostManager.getGroupIndex$O((long)(neighborBlockIndex0), (long)(neighborBlockIndex1), (long)(divisions0), (long)(divisions1), (long)(leftOver), (boolean)(periodic), (long)(groupIndexHere));
    }
    
    
    //#line 23 "x10/regionarray/BlockBlockDistGhostManager.x10"
    final public x10.regionarray.BlockBlockDistGhostManager x10$regionarray$BlockBlockDistGhostManager$$this$x10$regionarray$BlockBlockDistGhostManager() {
        
        //#line 23 "x10/regionarray/BlockBlockDistGhostManager.x10"
        return x10.regionarray.BlockBlockDistGhostManager.this;
    }
    
    
    //#line 23 "x10/regionarray/BlockBlockDistGhostManager.x10"
    final public void __fieldInitializers_x10_regionarray_BlockBlockDistGhostManager() {
        
    }
    
    @x10.runtime.impl.java.X10Generated
    final public static class $Closure$207 extends x10.core.Ref implements x10.core.fun.Fun_0_1, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<$Closure$207> $RTT = 
            x10.rtt.StaticFunType.<$Closure$207> make($Closure$207.class,
                                                      new x10.rtt.Type[] {
                                                          x10.rtt.ParameterizedType.make(x10.core.fun.Fun_0_1.$RTT, x10.rtt.Types.LONG, x10.lang.Place.$RTT)
                                                      });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static x10.serialization.X10JavaSerializable $_deserialize_body(x10.regionarray.BlockBlockDistGhostManager.$Closure$207 $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            $_obj.neighbors = $deserializer.readObject();
            $_obj.out$$ = $deserializer.readObject();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.regionarray.BlockBlockDistGhostManager.$Closure$207 $_obj = new x10.regionarray.BlockBlockDistGhostManager.$Closure$207((java.lang.System[]) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            $serializer.write(this.neighbors);
            $serializer.write(this.out$$);
            
        }
        
        // constructor just for allocation
        public $Closure$207(final java.lang.System[] $dummy) {
            
        }
        
        // dispatcher for method abstract public (Z1)=>U.operator()(a1:Z1):U
        public java.lang.Object $apply(final java.lang.Object a1, final x10.rtt.Type t1) {
            return $apply(x10.core.Long.$unbox(a1));
            
        }
        
        // synthetic type for parameter mangling
        public static final class __1$1x10$regionarray$GhostManager$GhostNeighborFlag$2 {}
        
    
        
        public x10.lang.Place $apply(final long i) {
            
            //#line 35 "x10/regionarray/BlockBlockDistGhostManager.x10"
            final x10.core.Rail t$147838 = ((x10.core.Rail)(this.neighbors));
            
            //#line 35 "x10/regionarray/BlockBlockDistGhostManager.x10"
            final x10.regionarray.GhostManager.GhostNeighborFlag t$147839 = ((x10.regionarray.GhostManager.GhostNeighborFlag[])t$147838.value)[(int)i];
            
            //#line 35 "x10/regionarray/BlockBlockDistGhostManager.x10"
            final x10.lang.Place t$147840 = ((x10.lang.Place)(t$147839.place));
            
            //#line 35 "x10/regionarray/BlockBlockDistGhostManager.x10"
            return t$147840;
        }
        
        public x10.regionarray.BlockBlockDistGhostManager out$$;
        public x10.core.Rail<x10.regionarray.GhostManager.GhostNeighborFlag> neighbors;
        
        public $Closure$207(final x10.regionarray.BlockBlockDistGhostManager out$$, final x10.core.Rail<x10.regionarray.GhostManager.GhostNeighborFlag> neighbors, __1$1x10$regionarray$GhostManager$GhostNeighborFlag$2 $dummy) {
             {
                this.out$$ = out$$;
                this.neighbors = ((x10.core.Rail)(neighbors));
            }
        }
        
    }
    
    }
    
    