package x10.regionarray;

/**
 * Represents an empty region.
 */
@x10.runtime.impl.java.X10Generated
final public class EmptyRegion extends x10.regionarray.Region implements x10.serialization.X10JavaSerializable
{
    public static final x10.rtt.RuntimeType<EmptyRegion> $RTT = 
        x10.rtt.NamedType.<EmptyRegion> make("x10.regionarray.EmptyRegion",
                                             EmptyRegion.class,
                                             new x10.rtt.Type[] {
                                                 x10.regionarray.Region.$RTT
                                             });
    
    public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
    
    public x10.rtt.Type<?> $getParam(int i) { return null; }
    
    private Object writeReplace() throws java.io.ObjectStreamException {
        return new x10.serialization.SerializationProxy(this);
    }
    
    public static x10.serialization.X10JavaSerializable $_deserialize_body(x10.regionarray.EmptyRegion $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
        x10.regionarray.Region.$_deserialize_body($_obj, $deserializer);
        return $_obj;
    }
    
    public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
        x10.regionarray.EmptyRegion $_obj = new x10.regionarray.EmptyRegion((java.lang.System[]) null);
        $deserializer.record_reference($_obj);
        return $_deserialize_body($_obj, $deserializer);
    }
    
    public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
        super.$_serialize($serializer);
        
    }
    
    // constructor just for allocation
    public EmptyRegion(final java.lang.System[] $dummy) {
        super($dummy);
        
    }
    
    

    
    
    //#line 19 "x10/regionarray/EmptyRegion.x10"
    // creation method for java code (1-phase java constructor)
    public EmptyRegion(final long rank) {
        this((java.lang.System[]) null);
        x10$regionarray$EmptyRegion$$init$S(rank);
    }
    
    // constructor for non-virtual call
    final public x10.regionarray.EmptyRegion x10$regionarray$EmptyRegion$$init$S(final long rank) {
         {
            
            //#line 20 "x10/regionarray/EmptyRegion.x10"
            final x10.regionarray.Region this$151718 = ((x10.regionarray.Region)(this));
            
            //#line 557 . "x10/regionarray/Region.x10"
            boolean t$151747 = ((long) rank) == ((long) 1L);
            
            //#line 557 . "x10/regionarray/Region.x10"
            if (t$151747) {
                
                //#line 557 . "x10/regionarray/Region.x10"
                t$151747 = true;
            }
            
            //#line 557 . "x10/regionarray/Region.x10"
            boolean t$151748 = t$151747;
            
            //#line 557 . "x10/regionarray/Region.x10"
            if (t$151747) {
                
                //#line 557 . "x10/regionarray/Region.x10"
                t$151748 = false;
            }
            
            //#line 558 . "x10/regionarray/Region.x10"
            this$151718.rank = rank;
            
            //#line 558 . "x10/regionarray/Region.x10"
            this$151718.rect = true;
            
            //#line 558 . "x10/regionarray/Region.x10"
            this$151718.zeroBased = false;
            
            //#line 558 . "x10/regionarray/Region.x10"
            this$151718.rail = t$151748;
            
            //#line 19 "x10/regionarray/EmptyRegion.x10"
            
            
            //#line 21 "x10/regionarray/EmptyRegion.x10"
            final boolean t$151733 = ((rank) < (((long)(0L))));
            
            //#line 21 "x10/regionarray/EmptyRegion.x10"
            if (t$151733) {
                
                //#line 21 "x10/regionarray/EmptyRegion.x10"
                final java.lang.String t$151730 = (("Rank is negative (") + ((x10.core.Long.$box(rank))));
                
                //#line 21 "x10/regionarray/EmptyRegion.x10"
                final java.lang.String t$151731 = ((t$151730) + (")"));
                
                //#line 21 "x10/regionarray/EmptyRegion.x10"
                final java.lang.IllegalArgumentException t$151732 = ((java.lang.IllegalArgumentException)(new java.lang.IllegalArgumentException(t$151731)));
                
                //#line 21 "x10/regionarray/EmptyRegion.x10"
                throw t$151732;
            }
        }
        return this;
    }
    
    
    
    //#line 24 "x10/regionarray/EmptyRegion.x10"
    public boolean isConvex$O() {
        
        //#line 24 "x10/regionarray/EmptyRegion.x10"
        return true;
    }
    
    
    //#line 25 "x10/regionarray/EmptyRegion.x10"
    public boolean isEmpty$O() {
        
        //#line 25 "x10/regionarray/EmptyRegion.x10"
        return true;
    }
    
    
    //#line 26 "x10/regionarray/EmptyRegion.x10"
    public long size$O() {
        
        //#line 26 "x10/regionarray/EmptyRegion.x10"
        return 0L;
    }
    
    
    //#line 27 "x10/regionarray/EmptyRegion.x10"
    public long indexOf$O(final x10.lang.Point id$319) {
        
        //#line 27 "x10/regionarray/EmptyRegion.x10"
        return -1L;
    }
    
    
    //#line 28 "x10/regionarray/EmptyRegion.x10"
    public x10.regionarray.Region intersection(final x10.regionarray.Region that) {
        
        //#line 28 "x10/regionarray/EmptyRegion.x10"
        return this;
    }
    
    
    //#line 29 "x10/regionarray/EmptyRegion.x10"
    public x10.regionarray.EmptyRegion product(final x10.regionarray.Region that) {
        
        //#line 30 "x10/regionarray/EmptyRegion.x10"
        final x10.regionarray.EmptyRegion alloc$144630 = ((x10.regionarray.EmptyRegion)(new x10.regionarray.EmptyRegion((java.lang.System[]) null)));
        
        //#line 30 "x10/regionarray/EmptyRegion.x10"
        final long t$151751 = this.rank;
        
        //#line 30 "x10/regionarray/EmptyRegion.x10"
        final long t$151752 = that.rank;
        
        //#line 30 "x10/regionarray/EmptyRegion.x10"
        final long t$151753 = ((t$151751) + (((long)(t$151752))));
        
        //#line 30 "x10/regionarray/EmptyRegion.x10"
        alloc$144630.x10$regionarray$EmptyRegion$$init$S(t$151753);
        
        //#line 30 "x10/regionarray/EmptyRegion.x10"
        return alloc$144630;
    }
    
    
    //#line 31 "x10/regionarray/EmptyRegion.x10"
    public x10.regionarray.Region projection(final long axis) {
        
        //#line 31 "x10/regionarray/EmptyRegion.x10"
        final x10.regionarray.EmptyRegion alloc$144631 = ((x10.regionarray.EmptyRegion)(new x10.regionarray.EmptyRegion((java.lang.System[]) null)));
        
        //#line 31 "x10/regionarray/EmptyRegion.x10"
        alloc$144631.x10$regionarray$EmptyRegion$$init$S(((long)(1L)));
        
        //#line 31 "x10/regionarray/EmptyRegion.x10"
        return alloc$144631;
    }
    
    
    //#line 32 "x10/regionarray/EmptyRegion.x10"
    public x10.regionarray.EmptyRegion translate(final x10.lang.Point p) {
        
        //#line 32 "x10/regionarray/EmptyRegion.x10"
        return this;
    }
    
    
    //#line 33 "x10/regionarray/EmptyRegion.x10"
    public x10.regionarray.EmptyRegion eliminate(final long i) {
        
        //#line 33 "x10/regionarray/EmptyRegion.x10"
        final x10.regionarray.EmptyRegion alloc$144632 = ((x10.regionarray.EmptyRegion)(new x10.regionarray.EmptyRegion((java.lang.System[]) null)));
        
        //#line 33 "x10/regionarray/EmptyRegion.x10"
        final long t$151754 = this.rank;
        
        //#line 33 "x10/regionarray/EmptyRegion.x10"
        final long t$151755 = ((t$151754) - (((long)(1L))));
        
        //#line 33 "x10/regionarray/EmptyRegion.x10"
        alloc$144632.x10$regionarray$EmptyRegion$$init$S(t$151755);
        
        //#line 33 "x10/regionarray/EmptyRegion.x10"
        return alloc$144632;
    }
    
    
    //#line 34 "x10/regionarray/EmptyRegion.x10"
    public x10.regionarray.Region computeBoundingBox() {
        
        //#line 35 "x10/regionarray/EmptyRegion.x10"
        final x10.lang.IllegalOperationException t$151739 = ((x10.lang.IllegalOperationException)(new x10.lang.IllegalOperationException(((java.lang.String)("bounding box not not defined for empty region")))));
        
        //#line 35 "x10/regionarray/EmptyRegion.x10"
        throw t$151739;
    }
    
    
    //#line 37 "x10/regionarray/EmptyRegion.x10"
    public x10.core.fun.Fun_0_1 min() {
        
        //#line 38 "x10/regionarray/EmptyRegion.x10"
        final x10.lang.IllegalOperationException t$151740 = ((x10.lang.IllegalOperationException)(new x10.lang.IllegalOperationException(((java.lang.String)("min not not defined for empty region")))));
        
        //#line 38 "x10/regionarray/EmptyRegion.x10"
        throw t$151740;
    }
    
    
    //#line 40 "x10/regionarray/EmptyRegion.x10"
    public x10.core.fun.Fun_0_1 max() {
        
        //#line 41 "x10/regionarray/EmptyRegion.x10"
        final x10.lang.IllegalOperationException t$151741 = ((x10.lang.IllegalOperationException)(new x10.lang.IllegalOperationException(((java.lang.String)("max not not defined for empty region")))));
        
        //#line 41 "x10/regionarray/EmptyRegion.x10"
        throw t$151741;
    }
    
    
    //#line 43 "x10/regionarray/EmptyRegion.x10"
    public boolean contains$O(final x10.regionarray.Region that) {
        
        //#line 43 "x10/regionarray/EmptyRegion.x10"
        final boolean t$151742 = that.isEmpty$O();
        
        //#line 43 "x10/regionarray/EmptyRegion.x10"
        return t$151742;
    }
    
    
    //#line 44 "x10/regionarray/EmptyRegion.x10"
    public boolean contains$O(final x10.lang.Point p) {
        
        //#line 44 "x10/regionarray/EmptyRegion.x10"
        return false;
    }
    
    
    //#line 46 "x10/regionarray/EmptyRegion.x10"
    @x10.runtime.impl.java.X10Generated
    public static class ERIterator extends x10.core.Ref implements x10.lang.Iterator, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<ERIterator> $RTT = 
            x10.rtt.NamedType.<ERIterator> make("x10.regionarray.EmptyRegion.ERIterator",
                                                ERIterator.class,
                                                new x10.rtt.Type[] {
                                                    x10.rtt.ParameterizedType.make(x10.lang.Iterator.$RTT, x10.lang.Point.$RTT)
                                                });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static x10.serialization.X10JavaSerializable $_deserialize_body(x10.regionarray.EmptyRegion.ERIterator $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            $_obj.myRank = $deserializer.readLong();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.regionarray.EmptyRegion.ERIterator $_obj = new x10.regionarray.EmptyRegion.ERIterator((java.lang.System[]) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            $serializer.write(this.myRank);
            
        }
        
        // constructor just for allocation
        public ERIterator(final java.lang.System[] $dummy) {
            
        }
        
        // bridge for method abstract public x10.lang.Iterator[T].next(){}:T
        public x10.lang.Point next$G() {
            return next();
        }
        
        
        // properties
        
        //#line 46 "x10/regionarray/EmptyRegion.x10"
        public long myRank;
        
    
        
        
        //#line 47 "x10/regionarray/EmptyRegion.x10"
        // creation method for java code (1-phase java constructor)
        public ERIterator(final long r) {
            this((java.lang.System[]) null);
            x10$regionarray$EmptyRegion$ERIterator$$init$S(r);
        }
        
        // constructor for non-virtual call
        final public x10.regionarray.EmptyRegion.ERIterator x10$regionarray$EmptyRegion$ERIterator$$init$S(final long r) {
             {
                
                //#line 47 "x10/regionarray/EmptyRegion.x10"
                this.myRank = r;
                
            }
            return this;
        }
        
        
        
        //#line 48 "x10/regionarray/EmptyRegion.x10"
        public boolean hasNext$O() {
            
            //#line 48 "x10/regionarray/EmptyRegion.x10"
            return false;
        }
        
        
        //#line 49 "x10/regionarray/EmptyRegion.x10"
        public x10.lang.Point next() {
            
            //#line 50 "x10/regionarray/EmptyRegion.x10"
            final java.util.NoSuchElementException t$151743 = ((java.util.NoSuchElementException)(new java.util.NoSuchElementException()));
            
            //#line 50 "x10/regionarray/EmptyRegion.x10"
            throw t$151743;
        }
        
        
        //#line 46 "x10/regionarray/EmptyRegion.x10"
        final public x10.regionarray.EmptyRegion.ERIterator x10$regionarray$EmptyRegion$ERIterator$$this$x10$regionarray$EmptyRegion$ERIterator() {
            
            //#line 46 "x10/regionarray/EmptyRegion.x10"
            return x10.regionarray.EmptyRegion.ERIterator.this;
        }
        
        
        //#line 46 "x10/regionarray/EmptyRegion.x10"
        final public void __fieldInitializers_x10_regionarray_EmptyRegion_ERIterator() {
            
        }
    }
    
    
    
    //#line 53 "x10/regionarray/EmptyRegion.x10"
    public x10.lang.Iterator iterator() {
        
        //#line 54 "x10/regionarray/EmptyRegion.x10"
        final x10.regionarray.EmptyRegion.ERIterator alloc$144633 = ((x10.regionarray.EmptyRegion.ERIterator)(new x10.regionarray.EmptyRegion.ERIterator((java.lang.System[]) null)));
        
        //#line 54 "x10/regionarray/EmptyRegion.x10"
        final long r$151725 = this.rank;
        
        //#line 47 . "x10/regionarray/EmptyRegion.x10"
        alloc$144633.myRank = r$151725;
        
        //#line 54 "x10/regionarray/EmptyRegion.x10"
        return alloc$144633;
    }
    
    
    //#line 57 "x10/regionarray/EmptyRegion.x10"
    public java.lang.String toString() {
        
        //#line 57 "x10/regionarray/EmptyRegion.x10"
        final long t$151744 = this.rank;
        
        //#line 57 "x10/regionarray/EmptyRegion.x10"
        final java.lang.String t$151745 = (("empty(") + ((x10.core.Long.$box(t$151744))));
        
        //#line 57 "x10/regionarray/EmptyRegion.x10"
        final java.lang.String t$151746 = ((t$151745) + (")"));
        
        //#line 57 "x10/regionarray/EmptyRegion.x10"
        return t$151746;
    }
    
    
    //#line 17 "x10/regionarray/EmptyRegion.x10"
    final public x10.regionarray.EmptyRegion x10$regionarray$EmptyRegion$$this$x10$regionarray$EmptyRegion() {
        
        //#line 17 "x10/regionarray/EmptyRegion.x10"
        return x10.regionarray.EmptyRegion.this;
    }
    
    
    //#line 17 "x10/regionarray/EmptyRegion.x10"
    final public void __fieldInitializers_x10_regionarray_EmptyRegion() {
        
    }
}

