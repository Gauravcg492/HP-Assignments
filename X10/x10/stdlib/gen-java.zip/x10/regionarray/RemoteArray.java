package x10.regionarray;

/**
 * A class that encapsulates sufficient information about a remote
 * array to enable DMA operations via Array.copyTo and Array.copyFrom
 * to be performed on the encapsulated Array.<p>
 * 
 * The following relationships will always be true, but are not statically expressible
 * due to limitations of the current implementations of constrained types in X10.
 * <pre>
 * this.region.equals(at (array.home) (this.array)().region)
 * this.size == (at (array.home) (this.array)().size)
 * rawData.home == this.array.home;
 * at (rawData.home) { (this.rawData)() == (this.array)().raw() }
 * </pre>
 */
@x10.runtime.impl.java.X10Generated
final public class RemoteArray<$T> extends x10.core.Ref implements x10.serialization.X10JavaSerializable
{
    public static final x10.rtt.RuntimeType<RemoteArray> $RTT = 
        x10.rtt.NamedType.<RemoteArray> make("x10.regionarray.RemoteArray",
                                             RemoteArray.class,
                                             1);
    
    public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
    
    public x10.rtt.Type<?> $getParam(int i) { if (i == 0) return $T; return null; }
    
    private Object writeReplace() throws java.io.ObjectStreamException {
        return new x10.serialization.SerializationProxy(this);
    }
    
    public static <$T> x10.serialization.X10JavaSerializable $_deserialize_body(x10.regionarray.RemoteArray<$T> $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
        $_obj.$T = (x10.rtt.Type) $deserializer.readObject();
        $_obj.array = $deserializer.readObject();
        $_obj.rawData = $deserializer.readObject();
        $_obj.region = $deserializer.readObject();
        $_obj.size = $deserializer.readLong();
        return $_obj;
    }
    
    public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
        x10.regionarray.RemoteArray $_obj = new x10.regionarray.RemoteArray((java.lang.System[]) null, (x10.rtt.Type) null);
        $deserializer.record_reference($_obj);
        return $_deserialize_body($_obj, $deserializer);
    }
    
    public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
        $serializer.write(this.$T);
        $serializer.write(this.array);
        $serializer.write(this.rawData);
        $serializer.write(this.region);
        $serializer.write(this.size);
        
    }
    
    // constructor just for allocation
    public RemoteArray(final java.lang.System[] $dummy, final x10.rtt.Type $T) {
        x10.regionarray.RemoteArray.$initParams(this, $T);
        
    }
    
    private x10.rtt.Type $T;
    
    // initializer of type parameters
    public static void $initParams(final RemoteArray $this, final x10.rtt.Type $T) {
        $this.$T = $T;
        
    }
    // synthetic type for parameter mangling
    public static final class __0$1x10$regionarray$RemoteArray$$T$2 {}
    
    // properties
    
    //#line 32 "x10/regionarray/RemoteArray.x10"
    /**
         * The Region of the remote array
         */
    public x10.regionarray.Region region;
    
    //#line 36 "x10/regionarray/RemoteArray.x10"
    /**
         * The size of the remote array.
         */
    public long size;
    
    //#line 40 "x10/regionarray/RemoteArray.x10"
    /**
         * The GlobalRef to the remote array.
         */
    public x10.core.GlobalRef<x10.regionarray.Array<$T>> array;
    

    
    //#line 47 "x10/regionarray/RemoteArray.x10"
    /**
     * Caches a remote reference to the backing storage for the remote array
     * to enable DMA operations to be initiated remotely.  
     */
    public x10.lang.GlobalRail<$T> rawData;
    
    
    //#line 52 "x10/regionarray/RemoteArray.x10"
    /**
     * The rank of the RemoteArray is equal to region.rank
     */
    final public long rank$O() {
        
        //#line 52 "x10/regionarray/RemoteArray.x10"
        final x10.regionarray.Region t$158859 = ((x10.regionarray.Region)(this.region));
        
        //#line 52 "x10/regionarray/RemoteArray.x10"
        final long t$158860 = t$158859.rank;
        
        //#line 52 "x10/regionarray/RemoteArray.x10"
        return t$158860;
    }
    
    
    //#line 57 "x10/regionarray/RemoteArray.x10"
    /**
     * The home location of the RemoteArray is equal to array.home
     */
    final public x10.lang.Place home() {
        
        //#line 57 "x10/regionarray/RemoteArray.x10"
        final x10.core.GlobalRef t$158861 = ((x10.core.GlobalRef)(this.array));
        
        //#line 57 "x10/regionarray/RemoteArray.x10"
        final x10.lang.Place t$158862 = ((x10.lang.Place)((t$158861).home));
        
        //#line 57 "x10/regionarray/RemoteArray.x10"
        return t$158862;
    }
    
    
    //#line 63 "x10/regionarray/RemoteArray.x10"
    /**
     * Create a RemoteArray wrapping the argument local Array.
     * @param a The array object to make accessible remotely.
     */
    // creation method for java code (1-phase java constructor)
    public RemoteArray(final x10.rtt.Type $T, final x10.regionarray.Array<$T> a, __0$1x10$regionarray$RemoteArray$$T$2 $dummy) {
        this((java.lang.System[]) null, $T);
        x10$regionarray$RemoteArray$$init$S(a, (x10.regionarray.RemoteArray.__0$1x10$regionarray$RemoteArray$$T$2) null);
    }
    
    // constructor for non-virtual call
    final public x10.regionarray.RemoteArray<$T> x10$regionarray$RemoteArray$$init$S(final x10.regionarray.Array<$T> a, __0$1x10$regionarray$RemoteArray$$T$2 $dummy) {
         {
            
            //#line 64 "x10/regionarray/RemoteArray.x10"
            final x10.regionarray.Region t$158990 = ((x10.regionarray.Region)(((x10.regionarray.Array<$T>)a).region));
            
            //#line 64 "x10/regionarray/RemoteArray.x10"
            final long t$158991 = ((x10.regionarray.Array<$T>)a).size;
            
            //#line 64 "x10/regionarray/RemoteArray.x10"
            final x10.core.GlobalRef t$158992 = ((x10.core.GlobalRef)(new x10.core.GlobalRef<x10.regionarray.Array<$T>>(x10.rtt.ParameterizedType.make(x10.regionarray.Array.$RTT, $T), ((x10.regionarray.Array)(a)), (x10.core.GlobalRef.__0x10$lang$GlobalRef$$T) null)));
            
            //#line 64 "x10/regionarray/RemoteArray.x10"
            this.region = t$158990;
            this.size = t$158991;
            this.array = t$158992;
            
            
            //#line 65 "x10/regionarray/RemoteArray.x10"
            final x10.lang.GlobalRail alloc$158820 = ((x10.lang.GlobalRail)(new x10.lang.GlobalRail<$T>((java.lang.System[]) null, $T)));
            
            //#line 115 . "x10/regionarray/Array.x10"
            final x10.core.Rail t$158994 = ((x10.core.Rail)(((x10.regionarray.Array<$T>)a).raw));
            
            //#line 65 "x10/regionarray/RemoteArray.x10"
            alloc$158820.x10$lang$GlobalRail$$init$S(((x10.core.Rail)(t$158994)), (x10.lang.GlobalRail.__0$1x10$lang$GlobalRail$$T$2) null);
            
            //#line 65 "x10/regionarray/RemoteArray.x10"
            ((x10.regionarray.RemoteArray<$T>)this).rawData = ((x10.lang.GlobalRail)(alloc$158820));
        }
        return this;
    }
    
    
    
    //#line 79 "x10/regionarray/RemoteArray.x10"
    /**
     * Return the element of this array corresponding to the given index.
     * Only applies to one-dimensional arrays.
     * Can only  be called where <code>here == array.home</code>. 
     * Functionally equivalent to indexing the array via a one-dimensional point.
     * 
     * @param i0 the given index in the first dimension
     * @return the element of this array corresponding to the given index.
     * @see #operator(Point)
     * @see #set(T, Int)
     */
    public $T $apply$G(final int i) {
        
        //#line 79 "x10/regionarray/RemoteArray.x10"
        final x10.regionarray.Array this$158827 = ((x10.regionarray.Array)(((x10.regionarray.Array<$T>)
                                                                             this.$apply())));
        
        //#line 79 "x10/regionarray/RemoteArray.x10"
        final long i$158826 = ((long)(((int)(i))));
        
        //#line 442 . "x10/regionarray/Array.x10"
        $T ret$158828 =  null;
        
        //#line 443 . "x10/regionarray/Array.x10"
        __ret$158829: {
            
            //#line 444 . "x10/regionarray/Array.x10"
            final boolean t$158880 = ((x10.regionarray.Array<$T>)this$158827).rail;
            //#line 444 . "x10/regionarray/Array.x10"
            if (t$158880) {
                
                //#line 446 . "x10/regionarray/Array.x10"
                final x10.core.Rail t$158871 = ((x10.core.Rail)(((x10.regionarray.Array<$T>)this$158827).raw));
                
                //#line 446 . "x10/regionarray/Array.x10"
                final $T t$158872 = (($T)(((x10.core.Rail<$T>)t$158871).$apply$G((long)(i$158826))));
                
                //#line 446 . "x10/regionarray/Array.x10"
                ret$158828 = (($T)(t$158872));
                
                //#line 446 . "x10/regionarray/Array.x10"
                break __ret$158829;
            } else {
                
                //#line 448 . "x10/regionarray/Array.x10"
                final x10.regionarray.Region t$158873 = ((x10.regionarray.Region)(((x10.regionarray.Array<$T>)this$158827).region));
                
                //#line 448 . "x10/regionarray/Array.x10"
                final boolean t$158874 = t$158873.contains$O((long)(i$158826));
                
                //#line 448 . "x10/regionarray/Array.x10"
                final boolean t$158875 = !(t$158874);
                
                //#line 448 . "x10/regionarray/Array.x10"
                if (t$158875) {
                    
                    //#line 449 . "x10/regionarray/Array.x10"
                    x10.regionarray.Array.raiseBoundsError$P((long)(i$158826));
                }
                
                //#line 451 . "x10/regionarray/Array.x10"
                final x10.core.Rail t$158877 = ((x10.core.Rail)(((x10.regionarray.Array<$T>)this$158827).raw));
                
                //#line 451 . "x10/regionarray/Array.x10"
                final long t$158876 = ((x10.regionarray.Array<$T>)this$158827).layout_min0;
                
                //#line 451 . "x10/regionarray/Array.x10"
                final long t$158878 = ((i$158826) - (((long)(t$158876))));
                
                //#line 451 . "x10/regionarray/Array.x10"
                final $T t$158879 = (($T)(((x10.core.Rail<$T>)t$158877).$apply$G((long)(t$158878))));
                
                //#line 451 . "x10/regionarray/Array.x10"
                ret$158828 = (($T)(t$158879));
                
                //#line 451 . "x10/regionarray/Array.x10"
                break __ret$158829;
            }
        }
        
        //#line 79 "x10/regionarray/RemoteArray.x10"
        return ret$158828;
    }
    
    
    //#line 91 "x10/regionarray/RemoteArray.x10"
    /**
     * Return the element of this array corresponding to the given point.
     * The rank of the given point has to be the same as the rank of this array.
     * Can only  be called where <code>here == array.home</code>. 
     * 
     * @param pt the given point
     * @return the element of this array corresponding to the given point.
     * @see #operator(Int)
     * @see #set(T, Point)
     */
    public $T $apply$G(final x10.lang.Point p) {
        
        //#line 91 "x10/regionarray/RemoteArray.x10"
        final x10.regionarray.Array this$158831 = ((x10.regionarray.Array)(((x10.regionarray.Array<$T>)
                                                                             this.$apply())));
        
        //#line 524 . "x10/regionarray/Array.x10"
        final x10.regionarray.Region t$158884 = ((x10.regionarray.Region)(((x10.regionarray.Array<$T>)this$158831).region));
        
        //#line 524 . "x10/regionarray/Array.x10"
        final boolean t$158885 = t$158884.contains$O(((x10.lang.Point)(p)));
        
        //#line 524 . "x10/regionarray/Array.x10"
        final boolean t$158886 = !(t$158885);
        
        //#line 524 . "x10/regionarray/Array.x10"
        if (t$158886) {
            
            //#line 525 . "x10/regionarray/Array.x10"
            x10.regionarray.Array.raiseBoundsError$P(((x10.lang.Point)(p)));
        }
        
        //#line 527 . "x10/regionarray/Array.x10"
        final x10.core.Rail t$158919 = ((x10.core.Rail)(((x10.regionarray.Array<$T>)this$158831).raw));
        
        //#line 1315 .. "x10/regionarray/Array.x10"
        final long t$158887 = ((long)(((int)(0))));
        
        //#line 1315 .. "x10/regionarray/Array.x10"
        final long t$158888 = p.$apply$O((long)(t$158887));
        
        //#line 1315 .. "x10/regionarray/Array.x10"
        final long t$158889 = ((x10.regionarray.Array<$T>)this$158831).layout_min0;
        
        //#line 1315 .. "x10/regionarray/Array.x10"
        long offset$158834 = ((t$158888) - (((long)(t$158889))));
        
        //#line 1316 .. "x10/regionarray/Array.x10"
        final long t$158890 = p.rank;
        
        //#line 1316 .. "x10/regionarray/Array.x10"
        final boolean t$158918 = ((t$158890) > (((long)(1L))));
        
        //#line 1316 .. "x10/regionarray/Array.x10"
        if (t$158918) {
            
            //#line 1317 .. "x10/regionarray/Array.x10"
            final long t$158892 = ((x10.regionarray.Array<$T>)this$158831).layout_stride1;
            
            //#line 1317 .. "x10/regionarray/Array.x10"
            final long t$158893 = ((offset$158834) * (((long)(t$158892))));
            
            //#line 1317 .. "x10/regionarray/Array.x10"
            final long t$158894 = p.$apply$O((long)(1L));
            
            //#line 1317 .. "x10/regionarray/Array.x10"
            final long t$158895 = ((t$158893) + (((long)(t$158894))));
            
            //#line 1317 .. "x10/regionarray/Array.x10"
            final long t$158896 = ((x10.regionarray.Array<$T>)this$158831).layout_min1;
            
            //#line 1317 .. "x10/regionarray/Array.x10"
            final long t$158897 = ((t$158895) - (((long)(t$158896))));
            
            //#line 1317 .. "x10/regionarray/Array.x10"
            offset$158834 = t$158897;
            
            //#line 1318 .. "x10/regionarray/Array.x10"
            final long t$159015 = p.rank;
            
            //#line 1318 .. "x10/regionarray/Array.x10"
            final long i$138773max$159016 = ((t$159015) - (((long)(1L))));
            
            //#line 1318 .. "x10/regionarray/Array.x10"
            long i$159012 = 2L;
            
            //#line 1318 .. "x10/regionarray/Array.x10"
            for (;
                 true;
                 ) {
                
                //#line 1318 .. "x10/regionarray/Array.x10"
                final boolean t$159014 = ((i$159012) <= (((long)(i$138773max$159016))));
                
                //#line 1318 .. "x10/regionarray/Array.x10"
                if (!(t$159014)) {
                    
                    //#line 1318 .. "x10/regionarray/Array.x10"
                    break;
                }
                
                //#line 1319 .. "x10/regionarray/Array.x10"
                final x10.core.Rail t$158996 = ((x10.core.Rail)(((x10.regionarray.Array<$T>)this$158831).layout));
                
                //#line 1319 .. "x10/regionarray/Array.x10"
                final long t$158997 = ((i$159012) - (((long)(2L))));
                
                //#line 1319 .. "x10/regionarray/Array.x10"
                final long t$158998 = ((2L) * (((long)(t$158997))));
                
                //#line 1319 .. "x10/regionarray/Array.x10"
                final long t$158999 = ((long[])t$158996.value)[(int)t$158998];
                
                //#line 1319 .. "x10/regionarray/Array.x10"
                final long t$159000 = ((offset$158834) * (((long)(t$158999))));
                
                //#line 1319 .. "x10/regionarray/Array.x10"
                final long t$159001 = p.$apply$O((long)(i$159012));
                
                //#line 1319 .. "x10/regionarray/Array.x10"
                final long t$159002 = ((t$159000) + (((long)(t$159001))));
                
                //#line 1319 .. "x10/regionarray/Array.x10"
                final x10.core.Rail t$159003 = ((x10.core.Rail)(((x10.regionarray.Array<$T>)this$158831).layout));
                
                //#line 1319 .. "x10/regionarray/Array.x10"
                final long t$159004 = ((i$159012) - (((long)(2L))));
                
                //#line 1319 .. "x10/regionarray/Array.x10"
                final long t$159005 = ((2L) * (((long)(t$159004))));
                
                //#line 1319 .. "x10/regionarray/Array.x10"
                final long t$159006 = ((t$159005) + (((long)(1L))));
                
                //#line 1319 .. "x10/regionarray/Array.x10"
                final long t$159007 = ((long[])t$159003.value)[(int)t$159006];
                
                //#line 1319 .. "x10/regionarray/Array.x10"
                final long t$159008 = ((t$159002) - (((long)(t$159007))));
                
                //#line 1319 .. "x10/regionarray/Array.x10"
                offset$158834 = t$159008;
                
                //#line 1318 .. "x10/regionarray/Array.x10"
                final long t$159011 = ((i$159012) + (((long)(1L))));
                
                //#line 1318 .. "x10/regionarray/Array.x10"
                i$159012 = t$159011;
            }
        }
        
        //#line 527 . "x10/regionarray/Array.x10"
        final $T t$158921 = (($T)(((x10.core.Rail<$T>)t$158919).$apply$G((long)(offset$158834))));
        
        //#line 91 "x10/regionarray/RemoteArray.x10"
        return t$158921;
    }
    
    
    //#line 106 "x10/regionarray/RemoteArray.x10"
    /**
     * Set the element of this array corresponding to the given index to the given value.
     * Return the new value of the element.
     * Only applies to one-dimensional arrays.
     * Can only  be called where <code>here == array.home</code>. 
     * Functionally equivalent to setting the array via a one-dimensional point.
     * 
     * @param v the given value
     * @param i0 the given index in the first dimension
     * @return the new value of the element of this array corresponding to the given index.
     * @see #operator(Int)
     * @see #set(T, Point)
     */
    public $T $set__1x10$regionarray$RemoteArray$$T$G(final int i, final $T v) {
        
        //#line 106 "x10/regionarray/RemoteArray.x10"
        final x10.regionarray.Array this$158844 = ((x10.regionarray.Array)(((x10.regionarray.Array<$T>)
                                                                             this.$apply())));
        
        //#line 106 "x10/regionarray/RemoteArray.x10"
        final long i$158842 = ((long)(((int)(i))));
        
        //#line 545 . "x10/regionarray/Array.x10"
        final boolean t$158933 = ((x10.regionarray.Array<$T>)this$158844).rail;
        
        //#line 545 . "x10/regionarray/Array.x10"
        if (t$158933) {
            
            //#line 547 . "x10/regionarray/Array.x10"
            final x10.core.Rail t$158926 = ((x10.core.Rail)(((x10.regionarray.Array<$T>)this$158844).raw));
            
            //#line 547 . "x10/regionarray/Array.x10"
            ((x10.core.Rail<$T>)t$158926).$set__1x10$lang$Rail$$T$G((long)(i$158842), (($T)(v)));
        } else {
            
            //#line 549 . "x10/regionarray/Array.x10"
            final x10.regionarray.Region t$158927 = ((x10.regionarray.Region)(((x10.regionarray.Array<$T>)this$158844).region));
            
            //#line 549 . "x10/regionarray/Array.x10"
            final boolean t$158928 = t$158927.contains$O((long)(i$158842));
            
            //#line 549 . "x10/regionarray/Array.x10"
            final boolean t$158929 = !(t$158928);
            
            //#line 549 . "x10/regionarray/Array.x10"
            if (t$158929) {
                
                //#line 550 . "x10/regionarray/Array.x10"
                x10.regionarray.Array.raiseBoundsError$P((long)(i$158842));
            }
            
            //#line 552 . "x10/regionarray/Array.x10"
            final x10.core.Rail t$158931 = ((x10.core.Rail)(((x10.regionarray.Array<$T>)this$158844).raw));
            
            //#line 552 . "x10/regionarray/Array.x10"
            final long t$158930 = ((x10.regionarray.Array<$T>)this$158844).layout_min0;
            
            //#line 552 . "x10/regionarray/Array.x10"
            final long t$158932 = ((i$158842) - (((long)(t$158930))));
            
            //#line 552 . "x10/regionarray/Array.x10"
            ((x10.core.Rail<$T>)t$158931).$set__1x10$lang$Rail$$T$G((long)(t$158932), (($T)(v)));
        }
        
        //#line 106 "x10/regionarray/RemoteArray.x10"
        return (($T)
                 v);
    }
    
    
    //#line 120 "x10/regionarray/RemoteArray.x10"
    /**
     * Set the element of this array corresponding to the given point to the given value.
     * Return the new value of the element.
     * The rank of the given point has to be the same as the rank of this array.
     * Can only  be called where <code>here == array.home</code>. 
     * 
     * @param v the given value
     * @param p the given point
     * @return the new value of the element of this array corresponding to the given point.
     * @see #operator(Point)
     * @see #set(T, Int)
     */
    public $T $set__1x10$regionarray$RemoteArray$$T$G(final x10.lang.Point p, final $T v) {
        
        //#line 121 "x10/regionarray/RemoteArray.x10"
        final x10.regionarray.Array this$158850 = ((x10.regionarray.Array)(((x10.regionarray.Array<$T>)
                                                                             this.$apply())));
        
        //#line 637 . "x10/regionarray/Array.x10"
        final x10.regionarray.Region t$158936 = ((x10.regionarray.Region)(((x10.regionarray.Array<$T>)this$158850).region));
        
        //#line 637 . "x10/regionarray/Array.x10"
        final boolean t$158937 = t$158936.contains$O(((x10.lang.Point)(p)));
        
        //#line 637 . "x10/regionarray/Array.x10"
        final boolean t$158938 = !(t$158937);
        
        //#line 637 . "x10/regionarray/Array.x10"
        if (t$158938) {
            
            //#line 638 . "x10/regionarray/Array.x10"
            x10.regionarray.Array.raiseBoundsError$P(((x10.lang.Point)(p)));
        }
        
        //#line 640 . "x10/regionarray/Array.x10"
        final x10.core.Rail t$158971 = ((x10.core.Rail)(((x10.regionarray.Array<$T>)this$158850).raw));
        
        //#line 1315 .. "x10/regionarray/Array.x10"
        final long t$158939 = ((long)(((int)(0))));
        
        //#line 1315 .. "x10/regionarray/Array.x10"
        final long t$158940 = p.$apply$O((long)(t$158939));
        
        //#line 1315 .. "x10/regionarray/Array.x10"
        final long t$158941 = ((x10.regionarray.Array<$T>)this$158850).layout_min0;
        
        //#line 1315 .. "x10/regionarray/Array.x10"
        long offset$158853 = ((t$158940) - (((long)(t$158941))));
        
        //#line 1316 .. "x10/regionarray/Array.x10"
        final long t$158942 = p.rank;
        
        //#line 1316 .. "x10/regionarray/Array.x10"
        final boolean t$158970 = ((t$158942) > (((long)(1L))));
        
        //#line 1316 .. "x10/regionarray/Array.x10"
        if (t$158970) {
            
            //#line 1317 .. "x10/regionarray/Array.x10"
            final long t$158944 = ((x10.regionarray.Array<$T>)this$158850).layout_stride1;
            
            //#line 1317 .. "x10/regionarray/Array.x10"
            final long t$158945 = ((offset$158853) * (((long)(t$158944))));
            
            //#line 1317 .. "x10/regionarray/Array.x10"
            final long t$158946 = p.$apply$O((long)(1L));
            
            //#line 1317 .. "x10/regionarray/Array.x10"
            final long t$158947 = ((t$158945) + (((long)(t$158946))));
            
            //#line 1317 .. "x10/regionarray/Array.x10"
            final long t$158948 = ((x10.regionarray.Array<$T>)this$158850).layout_min1;
            
            //#line 1317 .. "x10/regionarray/Array.x10"
            final long t$158949 = ((t$158947) - (((long)(t$158948))));
            
            //#line 1317 .. "x10/regionarray/Array.x10"
            offset$158853 = t$158949;
            
            //#line 1318 .. "x10/regionarray/Array.x10"
            final long t$159037 = p.rank;
            
            //#line 1318 .. "x10/regionarray/Array.x10"
            final long i$138773max$159038 = ((t$159037) - (((long)(1L))));
            
            //#line 1318 .. "x10/regionarray/Array.x10"
            long i$159034 = 2L;
            
            //#line 1318 .. "x10/regionarray/Array.x10"
            for (;
                 true;
                 ) {
                
                //#line 1318 .. "x10/regionarray/Array.x10"
                final boolean t$159036 = ((i$159034) <= (((long)(i$138773max$159038))));
                
                //#line 1318 .. "x10/regionarray/Array.x10"
                if (!(t$159036)) {
                    
                    //#line 1318 .. "x10/regionarray/Array.x10"
                    break;
                }
                
                //#line 1319 .. "x10/regionarray/Array.x10"
                final x10.core.Rail t$159018 = ((x10.core.Rail)(((x10.regionarray.Array<$T>)this$158850).layout));
                
                //#line 1319 .. "x10/regionarray/Array.x10"
                final long t$159019 = ((i$159034) - (((long)(2L))));
                
                //#line 1319 .. "x10/regionarray/Array.x10"
                final long t$159020 = ((2L) * (((long)(t$159019))));
                
                //#line 1319 .. "x10/regionarray/Array.x10"
                final long t$159021 = ((long[])t$159018.value)[(int)t$159020];
                
                //#line 1319 .. "x10/regionarray/Array.x10"
                final long t$159022 = ((offset$158853) * (((long)(t$159021))));
                
                //#line 1319 .. "x10/regionarray/Array.x10"
                final long t$159023 = p.$apply$O((long)(i$159034));
                
                //#line 1319 .. "x10/regionarray/Array.x10"
                final long t$159024 = ((t$159022) + (((long)(t$159023))));
                
                //#line 1319 .. "x10/regionarray/Array.x10"
                final x10.core.Rail t$159025 = ((x10.core.Rail)(((x10.regionarray.Array<$T>)this$158850).layout));
                
                //#line 1319 .. "x10/regionarray/Array.x10"
                final long t$159026 = ((i$159034) - (((long)(2L))));
                
                //#line 1319 .. "x10/regionarray/Array.x10"
                final long t$159027 = ((2L) * (((long)(t$159026))));
                
                //#line 1319 .. "x10/regionarray/Array.x10"
                final long t$159028 = ((t$159027) + (((long)(1L))));
                
                //#line 1319 .. "x10/regionarray/Array.x10"
                final long t$159029 = ((long[])t$159025.value)[(int)t$159028];
                
                //#line 1319 .. "x10/regionarray/Array.x10"
                final long t$159030 = ((t$159024) - (((long)(t$159029))));
                
                //#line 1319 .. "x10/regionarray/Array.x10"
                offset$158853 = t$159030;
                
                //#line 1318 .. "x10/regionarray/Array.x10"
                final long t$159033 = ((i$159034) + (((long)(1L))));
                
                //#line 1318 .. "x10/regionarray/Array.x10"
                i$159034 = t$159033;
            }
        }
        
        //#line 640 . "x10/regionarray/Array.x10"
        ((x10.core.Rail<$T>)t$158971).$set__1x10$lang$Rail$$T$G((long)(offset$158853), (($T)(v)));
        
        //#line 121 "x10/regionarray/RemoteArray.x10"
        return (($T)
                 v);
    }
    
    
    //#line 128 "x10/regionarray/RemoteArray.x10"
    /**
     * Access the Array that is encapsulated by this RemoteArray. 
     * Can only  be called where <code>here == array.home</code>. 
     */
    public x10.regionarray.Array $apply() {
        
        //#line 128 "x10/regionarray/RemoteArray.x10"
        final x10.core.GlobalRef t$158975 = ((x10.core.GlobalRef)(this.array));
        
        //#line 128 "x10/regionarray/RemoteArray.x10"
        final x10.regionarray.Array t$158976 = (((x10.core.GlobalRef<x10.regionarray.Array<$T>>)(t$158975))).$apply$G();
        
        //#line 128 "x10/regionarray/RemoteArray.x10"
        final x10.regionarray.Array t$158818 = ((x10.regionarray.Array<$T>)
                                                 t$158976);
        
        //#line 128 "x10/regionarray/RemoteArray.x10"
        final long t$158978 = ((x10.regionarray.Array<$T>)t$158818).rank;
        
        //#line 128 "x10/regionarray/RemoteArray.x10"
        final x10.regionarray.Region t$158977 = ((x10.regionarray.Region)(x10.regionarray.RemoteArray.this.region));
        
        //#line 128 "x10/regionarray/RemoteArray.x10"
        final long t$158979 = t$158977.rank;
        
        //#line 128 "x10/regionarray/RemoteArray.x10"
        final boolean t$158980 = ((long) t$158978) == ((long) t$158979);
        
        //#line 128 "x10/regionarray/RemoteArray.x10"
        final boolean t$158982 = !(t$158980);
        
        //#line 128 "x10/regionarray/RemoteArray.x10"
        if (t$158982) {
            
            //#line 128 "x10/regionarray/RemoteArray.x10"
            final x10.lang.FailedDynamicCheckException t$158981 = new x10.lang.FailedDynamicCheckException("x10.regionarray.Array[T]{self.rank==this(:x10.regionarray.RemoteArray).region.rank}");
            
            //#line 128 "x10/regionarray/RemoteArray.x10"
            throw t$158981;
        }
        
        //#line 128 "x10/regionarray/RemoteArray.x10"
        return t$158818;
    }
    
    
    //#line 130 "x10/regionarray/RemoteArray.x10"
    public boolean equals(final java.lang.Object other) {
        
        //#line 131 "x10/regionarray/RemoteArray.x10"
        final boolean t$158983 = x10.regionarray.RemoteArray.$RTT.isInstance(other, $T);
        
        //#line 131 "x10/regionarray/RemoteArray.x10"
        final boolean t$158984 = !(t$158983);
        
        //#line 131 "x10/regionarray/RemoteArray.x10"
        if (t$158984) {
            
            //#line 131 "x10/regionarray/RemoteArray.x10"
            return false;
        }
        
        //#line 132 "x10/regionarray/RemoteArray.x10"
        final x10.regionarray.RemoteArray oRA = ((x10.regionarray.RemoteArray)(x10.rtt.Types.<x10.regionarray.RemoteArray<$T>> cast(other,x10.rtt.ParameterizedType.make(x10.regionarray.RemoteArray.$RTT, $T))));
        
        //#line 133 "x10/regionarray/RemoteArray.x10"
        final x10.core.GlobalRef t$158985 = ((x10.core.GlobalRef)(((x10.regionarray.RemoteArray<$T>)oRA).array));
        
        //#line 133 "x10/regionarray/RemoteArray.x10"
        final x10.core.GlobalRef t$158986 = ((x10.core.GlobalRef)(this.array));
        
        //#line 133 "x10/regionarray/RemoteArray.x10"
        final boolean t$158987 = (((x10.core.GlobalRef<x10.regionarray.Array<$T>>)(t$158985))).equals(t$158986);
        
        //#line 133 "x10/regionarray/RemoteArray.x10"
        return t$158987;
    }
    
    
    //#line 136 "x10/regionarray/RemoteArray.x10"
    public int hashCode() {
        
        //#line 136 "x10/regionarray/RemoteArray.x10"
        final x10.core.GlobalRef t$158988 = ((x10.core.GlobalRef)(this.array));
        
        //#line 136 "x10/regionarray/RemoteArray.x10"
        final int t$158989 = (((x10.core.GlobalRef<x10.regionarray.Array<$T>>)(t$158988))).hashCode();
        
        //#line 136 "x10/regionarray/RemoteArray.x10"
        return t$158989;
    }
    
    
    //#line 28 "x10/regionarray/RemoteArray.x10"
    final public x10.regionarray.RemoteArray x10$regionarray$RemoteArray$$this$x10$regionarray$RemoteArray() {
        
        //#line 28 "x10/regionarray/RemoteArray.x10"
        return x10.regionarray.RemoteArray.this;
    }
    
    
    //#line 28 "x10/regionarray/RemoteArray.x10"
    final public void __fieldInitializers_x10_regionarray_RemoteArray() {
        
    }
}

