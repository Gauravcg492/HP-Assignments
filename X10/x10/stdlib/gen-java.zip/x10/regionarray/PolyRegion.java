package x10.regionarray;


/**
 * A PolyRegion represents a polyhedral region represented as the
 * intersection of a list of PolyRows. The halfspaces are stored in
 * a PolyMat object, which is essentially a constraint matrix
 * that defines the region. The PolyRegion object wraps a
 * HalfpaceList, adding some static factory methods for PolyRegions
 * and some methods such as region algebra that operate on
 * PolyMat objects.
 */
@x10.runtime.impl.java.X10Generated
public class PolyRegion extends x10.regionarray.Region implements x10.serialization.X10JavaSerializable
{
    public static final x10.rtt.RuntimeType<PolyRegion> $RTT = 
        x10.rtt.NamedType.<PolyRegion> make("x10.regionarray.PolyRegion",
                                            PolyRegion.class,
                                            new x10.rtt.Type[] {
                                                x10.regionarray.Region.$RTT
                                            });
    
    public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
    
    public x10.rtt.Type<?> $getParam(int i) { return null; }
    
    private Object writeReplace() throws java.io.ObjectStreamException {
        return new x10.serialization.SerializationProxy(this);
    }
    
    public static x10.serialization.X10JavaSerializable $_deserialize_body(x10.regionarray.PolyRegion $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
        x10.regionarray.Region.$_deserialize_body($_obj, $deserializer);
        $_obj.mat = $deserializer.readObject();
        $_obj.size = $deserializer.readLong();
        return $_obj;
    }
    
    public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
        x10.regionarray.PolyRegion $_obj = new x10.regionarray.PolyRegion((java.lang.System[]) null);
        $deserializer.record_reference($_obj);
        return $_deserialize_body($_obj, $deserializer);
    }
    
    public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
        super.$_serialize($serializer);
        $serializer.write(this.mat);
        $serializer.write(this.size);
        
    }
    
    // constructor just for allocation
    public PolyRegion(final java.lang.System[] $dummy) {
        super($dummy);
        
    }
    
    

    
    //#line 28 "x10/regionarray/PolyRegion.x10"
    public x10.regionarray.PolyMat mat;
    
    
    //#line 30 "x10/regionarray/PolyRegion.x10"
    public boolean isConvex$O() {
        
        //#line 31 "x10/regionarray/PolyRegion.x10"
        return true;
    }
    
    
    //#line 34 "x10/regionarray/PolyRegion.x10"
    public long size;
    
    
    //#line 35 "x10/regionarray/PolyRegion.x10"
    public long size$O() {
        
        //#line 36 "x10/regionarray/PolyRegion.x10"
        final long t$155175 = this.size;
        
        //#line 36 "x10/regionarray/PolyRegion.x10"
        final boolean t$155182 = ((t$155175) < (((long)(0L))));
        
        //#line 36 "x10/regionarray/PolyRegion.x10"
        if (t$155182) {
            
            //#line 37 "x10/regionarray/PolyRegion.x10"
            long s = 0L;
            
            //#line 38 "x10/regionarray/PolyRegion.x10"
            this.iterator();
            
            //#line 39 "x10/regionarray/PolyRegion.x10"
            final x10.lang.Iterator p$155446 = this.iterator();
            
            //#line 39 "x10/regionarray/PolyRegion.x10"
            for (;
                 true;
                 ) {
                
                //#line 39 "x10/regionarray/PolyRegion.x10"
                final boolean t$155447 = ((x10.lang.Iterator<x10.lang.Point>)p$155446).hasNext$O();
                
                //#line 39 "x10/regionarray/PolyRegion.x10"
                if (!(t$155447)) {
                    
                    //#line 39 "x10/regionarray/PolyRegion.x10"
                    break;
                }
                
                //#line 39 "x10/regionarray/PolyRegion.x10"
                final x10.lang.Point t$155442 = ((x10.lang.Point)(((x10.lang.Iterator<x10.lang.Point>)p$155446).next$G()));
                
                //#line 39 "x10/regionarray/PolyRegion.x10"
                x10.runtime.impl.java.EvalUtils.eval(((x10.lang.Point)
                                                       t$155442));
                
                //#line 40 "x10/regionarray/PolyRegion.x10"
                final long t$155445 = ((s) + (((long)(1L))));
                
                //#line 40 "x10/regionarray/PolyRegion.x10"
                s = t$155445;
            }
            
            //#line 41 "x10/regionarray/PolyRegion.x10"
            this.size = s;
        }
        
        //#line 43 "x10/regionarray/PolyRegion.x10"
        final long t$155183 = this.size;
        
        //#line 43 "x10/regionarray/PolyRegion.x10"
        return t$155183;
    }
    
    
    //#line 46 "x10/regionarray/PolyRegion.x10"
    public long indexOf$O(final x10.lang.Point id$330) {
        
        //#line 47 "x10/regionarray/PolyRegion.x10"
        final java.lang.UnsupportedOperationException t$155184 = ((java.lang.UnsupportedOperationException)(new java.lang.UnsupportedOperationException()));
        
        //#line 47 "x10/regionarray/PolyRegion.x10"
        throw t$155184;
    }
    
    
    //#line 51 "x10/regionarray/PolyRegion.x10"
    public x10.lang.Iterator iterator() {
        
        //#line 52 "x10/regionarray/PolyRegion.x10"
        final x10.regionarray.PolyMat t$155185 = ((x10.regionarray.PolyMat)(this.mat));
        
        //#line 52 "x10/regionarray/PolyRegion.x10"
        final x10.regionarray.PolyScanner this$155156 = ((x10.regionarray.PolyScanner)(x10.regionarray.PolyScanner.make(((x10.regionarray.PolyMat)(t$155185)))));
        
        //#line 289 . "x10/regionarray/PolyScanner.x10"
        final x10.regionarray.PolyScanner.Anonymous$10018 alloc$155155 = ((x10.regionarray.PolyScanner.Anonymous$10018)(new x10.regionarray.PolyScanner.Anonymous$10018((java.lang.System[]) null)));
        
        //#line 289 . "x10/regionarray/PolyScanner.x10"
        alloc$155155.x10$regionarray$PolyScanner$Anonymous$10018$$init$S(((x10.regionarray.PolyScanner)(this$155156)));
        
        //#line 289 . "x10/regionarray/PolyScanner.x10"
        final x10.lang.Iterator t$155186 = ((x10.lang.Iterator<x10.lang.Point>)
                                             alloc$155155);
        
        //#line 52 "x10/regionarray/PolyRegion.x10"
        return t$155186;
    }
    
    
    //#line 59 "x10/regionarray/PolyRegion.x10"
    public x10.regionarray.Region intersection(final x10.regionarray.Region t) {
        
        //#line 61 "x10/regionarray/PolyRegion.x10"
        final boolean t$155212 = x10.regionarray.PolyRegion.$RTT.isInstance(t);
        
        //#line 61 "x10/regionarray/PolyRegion.x10"
        if (t$155212) {
            
            //#line 64 "x10/regionarray/PolyRegion.x10"
            final x10.regionarray.PolyRegion that = ((x10.regionarray.PolyRegion)(x10.rtt.Types.<x10.regionarray.PolyRegion> cast(t,x10.regionarray.PolyRegion.$RTT)));
            
            //#line 65 "x10/regionarray/PolyRegion.x10"
            final x10.regionarray.PolyMatBuilder pmb = ((x10.regionarray.PolyMatBuilder)(new x10.regionarray.PolyMatBuilder((java.lang.System[]) null)));
            
            //#line 65 "x10/regionarray/PolyRegion.x10"
            final long t$155450 = this.rank;
            
            //#line 65 "x10/regionarray/PolyRegion.x10"
            pmb.x10$regionarray$PolyMatBuilder$$init$S(((long)(t$155450)));
            
            //#line 68 "x10/regionarray/PolyRegion.x10"
            final x10.regionarray.PolyMat t$155451 = ((x10.regionarray.PolyMat)(this.mat));
            
            //#line 68 "x10/regionarray/PolyRegion.x10"
            final x10.lang.Iterator r$155452 = ((x10.regionarray.Mat<x10.regionarray.PolyRow>)t$155451).iterator();
            
            //#line 68 "x10/regionarray/PolyRegion.x10"
            for (;
                 true;
                 ) {
                
                //#line 68 "x10/regionarray/PolyRegion.x10"
                final boolean t$155453 = ((x10.lang.Iterator<x10.regionarray.PolyRow>)r$155452).hasNext$O();
                
                //#line 68 "x10/regionarray/PolyRegion.x10"
                if (!(t$155453)) {
                    
                    //#line 68 "x10/regionarray/PolyRegion.x10"
                    break;
                }
                
                //#line 68 "x10/regionarray/PolyRegion.x10"
                final x10.regionarray.PolyRow r$155448 = ((x10.lang.Iterator<x10.regionarray.PolyRow>)r$155452).next$G();
                
                //#line 69 "x10/regionarray/PolyRegion.x10"
                pmb.add(((x10.regionarray.Row)(r$155448)));
            }
            
            //#line 72 "x10/regionarray/PolyRegion.x10"
            final x10.regionarray.PolyMat t$155454 = ((x10.regionarray.PolyMat)(that.mat));
            
            //#line 72 "x10/regionarray/PolyRegion.x10"
            final x10.lang.Iterator r$155455 = ((x10.regionarray.Mat<x10.regionarray.PolyRow>)t$155454).iterator();
            
            //#line 72 "x10/regionarray/PolyRegion.x10"
            for (;
                 true;
                 ) {
                
                //#line 72 "x10/regionarray/PolyRegion.x10"
                final boolean t$155456 = ((x10.lang.Iterator<x10.regionarray.PolyRow>)r$155455).hasNext$O();
                
                //#line 72 "x10/regionarray/PolyRegion.x10"
                if (!(t$155456)) {
                    
                    //#line 72 "x10/regionarray/PolyRegion.x10"
                    break;
                }
                
                //#line 72 "x10/regionarray/PolyRegion.x10"
                final x10.regionarray.PolyRow r$155449 = ((x10.lang.Iterator<x10.regionarray.PolyRow>)r$155455).next$G();
                
                //#line 73 "x10/regionarray/PolyRegion.x10"
                pmb.add(((x10.regionarray.Row)(r$155449)));
            }
            
            //#line 76 "x10/regionarray/PolyRegion.x10"
            final x10.regionarray.PolyMat pm = ((x10.regionarray.PolyMat)(pmb.toSortedPolyMat((boolean)(false))));
            
            //#line 77 "x10/regionarray/PolyRegion.x10"
            final x10.regionarray.Region t$155194 = ((x10.regionarray.Region)(x10.regionarray.PolyRegion.make(((x10.regionarray.PolyMat)(pm)))));
            
            //#line 77 "x10/regionarray/PolyRegion.x10"
            return t$155194;
        } else {
            
            //#line 79 "x10/regionarray/PolyRegion.x10"
            final boolean t$155211 = x10.regionarray.RectRegion.$RTT.isInstance(t);
            
            //#line 79 "x10/regionarray/PolyRegion.x10"
            if (t$155211) {
                
                //#line 80 "x10/regionarray/PolyRegion.x10"
                final x10.regionarray.RectRegion t$155195 = ((x10.regionarray.RectRegion)(x10.rtt.Types.<x10.regionarray.RectRegion> cast(t,x10.regionarray.RectRegion.$RTT)));
                
                //#line 80 "x10/regionarray/PolyRegion.x10"
                final x10.regionarray.Region t$155196 = ((x10.regionarray.Region)(t$155195.toPolyRegion()));
                
                //#line 80 "x10/regionarray/PolyRegion.x10"
                final x10.regionarray.Region t$155197 = ((x10.regionarray.Region)(this.intersection(((x10.regionarray.Region)(t$155196)))));
                
                //#line 80 "x10/regionarray/PolyRegion.x10"
                return t$155197;
            } else {
                
                //#line 81 "x10/regionarray/PolyRegion.x10"
                final boolean t$155210 = x10.regionarray.RectRegion1D.$RTT.isInstance(t);
                
                //#line 81 "x10/regionarray/PolyRegion.x10"
                if (t$155210) {
                    
                    //#line 82 "x10/regionarray/PolyRegion.x10"
                    final x10.regionarray.RectRegion1D t$155198 = ((x10.regionarray.RectRegion1D)(x10.rtt.Types.<x10.regionarray.RectRegion1D> cast(t,x10.regionarray.RectRegion1D.$RTT)));
                    
                    //#line 82 "x10/regionarray/PolyRegion.x10"
                    final x10.regionarray.RectRegion t$155199 = ((x10.regionarray.RectRegion)(t$155198.toRectRegion()));
                    
                    //#line 82 "x10/regionarray/PolyRegion.x10"
                    final x10.regionarray.Region t$155200 = ((x10.regionarray.Region)(t$155199.toPolyRegion()));
                    
                    //#line 82 "x10/regionarray/PolyRegion.x10"
                    final x10.regionarray.Region t$154032 = ((x10.regionarray.Region)
                                                              t$155200);
                    
                    //#line 82 "x10/regionarray/PolyRegion.x10"
                    final long t$155201 = t$154032.rank;
                    
                    //#line 82 "x10/regionarray/PolyRegion.x10"
                    final long t$155202 = x10.regionarray.PolyRegion.this.rank;
                    
                    //#line 82 "x10/regionarray/PolyRegion.x10"
                    final boolean t$155203 = ((long) t$155201) == ((long) t$155202);
                    
                    //#line 82 "x10/regionarray/PolyRegion.x10"
                    final boolean t$155205 = !(t$155203);
                    
                    //#line 82 "x10/regionarray/PolyRegion.x10"
                    if (t$155205) {
                        
                        //#line 82 "x10/regionarray/PolyRegion.x10"
                        final x10.lang.FailedDynamicCheckException t$155204 = new x10.lang.FailedDynamicCheckException("x10.regionarray.Region{self.rank==this(:x10.regionarray.PolyRegion).rank}");
                        
                        //#line 82 "x10/regionarray/PolyRegion.x10"
                        throw t$155204;
                    }
                    
                    //#line 82 "x10/regionarray/PolyRegion.x10"
                    final x10.regionarray.Region t$155206 = ((x10.regionarray.Region)(this.intersection(((x10.regionarray.Region)(t$154032)))));
                    
                    //#line 82 "x10/regionarray/PolyRegion.x10"
                    return t$155206;
                } else {
                    
                    //#line 89 "x10/regionarray/PolyRegion.x10"
                    final java.lang.String t$155207 = (("intersection(") + (t));
                    
                    //#line 89 "x10/regionarray/PolyRegion.x10"
                    final java.lang.String t$155208 = ((t$155207) + (")"));
                    
                    //#line 89 "x10/regionarray/PolyRegion.x10"
                    final java.lang.UnsupportedOperationException t$155209 = ((java.lang.UnsupportedOperationException)(new java.lang.UnsupportedOperationException(t$155208)));
                    
                    //#line 89 "x10/regionarray/PolyRegion.x10"
                    throw t$155209;
                }
            }
        }
    }
    
    
    //#line 94 "x10/regionarray/PolyRegion.x10"
    public boolean contains$O(final x10.regionarray.Region that) {
        
        //#line 95 "x10/regionarray/PolyRegion.x10"
        final x10.regionarray.Region t$155213 = ((x10.regionarray.Region)(this.computeBoundingBox()));
        
        //#line 95 "x10/regionarray/PolyRegion.x10"
        final x10.regionarray.Region t$155214 = ((x10.regionarray.Region)(that.computeBoundingBox()));
        
        //#line 95 "x10/regionarray/PolyRegion.x10"
        final boolean t$155215 = t$155213.contains$O(((x10.regionarray.Region)(t$155214)));
        
        //#line 95 "x10/regionarray/PolyRegion.x10"
        return t$155215;
    }
    
    
    //#line 102 "x10/regionarray/PolyRegion.x10"
    /**
     * Projection is computed by using FME to eliminate variables on
     * all but the axis of interest.
     */
    public x10.regionarray.Region projection(final long axis) {
        
        //#line 103 "x10/regionarray/PolyRegion.x10"
        x10.regionarray.PolyMat pm = ((x10.regionarray.PolyMat)(this.mat));
        
        //#line 104 "x10/regionarray/PolyRegion.x10"
        int k$155465 = 0;
        
        //#line 104 "x10/regionarray/PolyRegion.x10"
        for (;
             true;
             ) {
            
            //#line 104 "x10/regionarray/PolyRegion.x10"
            final long t$155467 = ((long)(((int)(k$155465))));
            
            //#line 104 "x10/regionarray/PolyRegion.x10"
            final long t$155468 = this.rank;
            
            //#line 104 "x10/regionarray/PolyRegion.x10"
            final boolean t$155469 = ((t$155467) < (((long)(t$155468))));
            
            //#line 104 "x10/regionarray/PolyRegion.x10"
            if (!(t$155469)) {
                
                //#line 104 "x10/regionarray/PolyRegion.x10"
                break;
            }
            
            //#line 105 "x10/regionarray/PolyRegion.x10"
            final int t$155458 = ((int)(long)(((long)(axis))));
            
            //#line 105 "x10/regionarray/PolyRegion.x10"
            final boolean t$155459 = ((int) k$155465) != ((int) t$155458);
            
            //#line 105 "x10/regionarray/PolyRegion.x10"
            if (t$155459) {
                
                //#line 106 "x10/regionarray/PolyRegion.x10"
                final x10.regionarray.PolyMat t$155462 = ((x10.regionarray.PolyMat)(pm.eliminate((int)(k$155465), (boolean)(true))));
                
                //#line 106 "x10/regionarray/PolyRegion.x10"
                pm = ((x10.regionarray.PolyMat)(t$155462));
            }
            
            //#line 104 "x10/regionarray/PolyRegion.x10"
            final int t$155464 = ((k$155465) + (((int)(1))));
            
            //#line 104 "x10/regionarray/PolyRegion.x10"
            k$155465 = t$155464;
        }
        
        //#line 107 "x10/regionarray/PolyRegion.x10"
        final int t$155230 = ((int)(long)(((long)(axis))));
        
        //#line 107 "x10/regionarray/PolyRegion.x10"
        final int t$155231 = pm.rectMin$O((int)(t$155230));
        
        //#line 107 "x10/regionarray/PolyRegion.x10"
        final long min$155158 = ((long)(((int)(t$155231))));
        
        //#line 107 "x10/regionarray/PolyRegion.x10"
        final int t$155233 = ((int)(long)(((long)(axis))));
        
        //#line 107 "x10/regionarray/PolyRegion.x10"
        final int t$155234 = pm.rectMax$O((int)(t$155233));
        
        //#line 107 "x10/regionarray/PolyRegion.x10"
        final long max$155159 = ((long)(((int)(t$155234))));
        
        //#line 274 . "x10/regionarray/Region.x10"
        final x10.regionarray.RectRegion1D alloc$155160 = ((x10.regionarray.RectRegion1D)(new x10.regionarray.RectRegion1D((java.lang.System[]) null)));
        
        //#line 274 . "x10/regionarray/Region.x10"
        alloc$155160.x10$regionarray$RectRegion1D$$init$S(((long)(min$155158)), ((long)(max$155159)));
        
        //#line 274 . "x10/regionarray/Region.x10"
        final x10.regionarray.Region t$155235 = ((x10.regionarray.Region)(((x10.regionarray.Region)
                                                                            alloc$155160)));
        
        //#line 107 "x10/regionarray/PolyRegion.x10"
        return t$155235;
    }
    
    
    //#line 116 "x10/regionarray/PolyRegion.x10"
    /**
     * Eliminate the ith axis.
     */
    public x10.regionarray.Region eliminate(final long axis) {
        
        //#line 117 "x10/regionarray/PolyRegion.x10"
        final x10.regionarray.PolyMat t$155236 = ((x10.regionarray.PolyMat)(this.mat));
        
        //#line 117 "x10/regionarray/PolyRegion.x10"
        final int t$155237 = ((int)(long)(((long)(axis))));
        
        //#line 117 "x10/regionarray/PolyRegion.x10"
        final x10.regionarray.PolyMat pm = ((x10.regionarray.PolyMat)(t$155236.eliminate((int)(t$155237), (boolean)(true))));
        
        //#line 118 "x10/regionarray/PolyRegion.x10"
        final x10.regionarray.Region result = ((x10.regionarray.Region)(x10.regionarray.PolyRegion.make(((x10.regionarray.PolyMat)(pm)))));
        
        //#line 119 "x10/regionarray/PolyRegion.x10"
        return result;
    }
    
    
    //#line 127 "x10/regionarray/PolyRegion.x10"
    /**
     * Cartesian product requires copying the halfspace matrices into
     * the result blockwise
     */
    public x10.regionarray.Region product(final x10.regionarray.Region r) {
        
        //#line 128 "x10/regionarray/PolyRegion.x10"
        final boolean t$155238 = x10.regionarray.PolyRegion.$RTT.isInstance(r);
        
        //#line 128 "x10/regionarray/PolyRegion.x10"
        final boolean t$155242 = !(t$155238);
        
        //#line 128 "x10/regionarray/PolyRegion.x10"
        if (t$155242) {
            
            //#line 129 "x10/regionarray/PolyRegion.x10"
            final java.lang.String t$155239 = (("product(") + (r));
            
            //#line 129 "x10/regionarray/PolyRegion.x10"
            final java.lang.String t$155240 = ((t$155239) + (")"));
            
            //#line 129 "x10/regionarray/PolyRegion.x10"
            final java.lang.UnsupportedOperationException t$155241 = ((java.lang.UnsupportedOperationException)(new java.lang.UnsupportedOperationException(t$155240)));
            
            //#line 129 "x10/regionarray/PolyRegion.x10"
            throw t$155241;
        }
        
        //#line 130 "x10/regionarray/PolyRegion.x10"
        final x10.regionarray.PolyRegion that = ((x10.regionarray.PolyRegion)(x10.rtt.Types.<x10.regionarray.PolyRegion> cast(r,x10.regionarray.PolyRegion.$RTT)));
        
        //#line 131 "x10/regionarray/PolyRegion.x10"
        final x10.regionarray.PolyMatBuilder pmb = ((x10.regionarray.PolyMatBuilder)(new x10.regionarray.PolyMatBuilder((java.lang.System[]) null)));
        
        //#line 131 "x10/regionarray/PolyRegion.x10"
        final long t$155470 = this.rank;
        
        //#line 131 "x10/regionarray/PolyRegion.x10"
        final long t$155471 = that.rank;
        
        //#line 131 "x10/regionarray/PolyRegion.x10"
        final long t$155472 = ((t$155470) + (((long)(t$155471))));
        
        //#line 131 "x10/regionarray/PolyRegion.x10"
        pmb.x10$regionarray$PolyMatBuilder$$init$S(t$155472);
        
        //#line 132 "x10/regionarray/PolyRegion.x10"
        final x10.regionarray.PolyMat t$155246 = ((x10.regionarray.PolyMat)(this.mat));
        
        //#line 132 "x10/regionarray/PolyRegion.x10"
        x10.regionarray.PolyRegion.copy(((x10.regionarray.PolyMatBuilder)(pmb)), ((x10.regionarray.PolyMat)(t$155246)), (int)(0));
        
        //#line 133 "x10/regionarray/PolyRegion.x10"
        final x10.regionarray.PolyMat t$155248 = ((x10.regionarray.PolyMat)(that.mat));
        
        //#line 133 "x10/regionarray/PolyRegion.x10"
        final long t$155247 = this.rank;
        
        //#line 133 "x10/regionarray/PolyRegion.x10"
        final int t$155249 = ((int)(long)(((long)(t$155247))));
        
        //#line 133 "x10/regionarray/PolyRegion.x10"
        x10.regionarray.PolyRegion.copy(((x10.regionarray.PolyMatBuilder)(pmb)), ((x10.regionarray.PolyMat)(t$155248)), (int)(t$155249));
        
        //#line 134 "x10/regionarray/PolyRegion.x10"
        final x10.regionarray.PolyMat pm = ((x10.regionarray.PolyMat)(pmb.toSortedPolyMat((boolean)(false))));
        
        //#line 135 "x10/regionarray/PolyRegion.x10"
        final x10.regionarray.Region t$155250 = ((x10.regionarray.Region)(x10.regionarray.PolyRegion.make(((x10.regionarray.PolyMat)(pm)))));
        
        //#line 135 "x10/regionarray/PolyRegion.x10"
        return t$155250;
    }
    
    
    //#line 138 "x10/regionarray/PolyRegion.x10"
    private static void copy(final x10.regionarray.PolyMatBuilder tt, final x10.regionarray.PolyMat ff, final int offset) {
        
        //#line 139 "x10/regionarray/PolyRegion.x10"
        final x10.lang.Iterator r$154402 = ((x10.regionarray.Mat<x10.regionarray.PolyRow>)ff).iterator();
        
        //#line 139 "x10/regionarray/PolyRegion.x10"
        for (;
             true;
             ) {
            
            //#line 139 "x10/regionarray/PolyRegion.x10"
            final boolean t$155272 = ((x10.lang.Iterator<x10.regionarray.PolyRow>)r$154402).hasNext$O();
            
            //#line 139 "x10/regionarray/PolyRegion.x10"
            if (!(t$155272)) {
                
                //#line 139 "x10/regionarray/PolyRegion.x10"
                break;
            }
            
            //#line 139 "x10/regionarray/PolyRegion.x10"
            final x10.regionarray.PolyRow r$155487 = ((x10.lang.Iterator<x10.regionarray.PolyRow>)r$154402).next$G();
            
            //#line 141 "x10/regionarray/PolyRegion.x10"
            final long t$155489 = tt.rank;
            
            //#line 141 "x10/regionarray/PolyRegion.x10"
            final long t$155490 = ((t$155489) + (((long)(1L))));
            
            //#line 141 "x10/regionarray/PolyRegion.x10"
            final x10.core.Rail t$155491 = ((x10.core.Rail)(new x10.core.Rail<x10.core.Int>(x10.rtt.Types.INT, t$155490)));
            
            //#line 142 "x10/regionarray/PolyRegion.x10"
            int i$155480 = 0;
            {
                
                //#line 142 "x10/regionarray/PolyRegion.x10"
                final int[] t$155491$value$155585 = ((int[])t$155491.value);
                
                //#line 142 "x10/regionarray/PolyRegion.x10"
                for (;
                     true;
                     ) {
                    
                    //#line 142 "x10/regionarray/PolyRegion.x10"
                    final long t$155482 = ((long)(((int)(i$155480))));
                    
                    //#line 142 "x10/regionarray/PolyRegion.x10"
                    final long t$155483 = ff.rank;
                    
                    //#line 142 "x10/regionarray/PolyRegion.x10"
                    final boolean t$155484 = ((t$155482) < (((long)(t$155483))));
                    
                    //#line 142 "x10/regionarray/PolyRegion.x10"
                    if (!(t$155484)) {
                        
                        //#line 142 "x10/regionarray/PolyRegion.x10"
                        break;
                    }
                    
                    //#line 143 "x10/regionarray/PolyRegion.x10"
                    final int t$155474 = ((offset) + (((int)(i$155480))));
                    
                    //#line 143 "x10/regionarray/PolyRegion.x10"
                    final long t$155475 = ((long)(((int)(t$155474))));
                    
                    //#line 143 "x10/regionarray/PolyRegion.x10"
                    final int t$155477 = r$155487.$apply$O((int)(i$155480));
                    
                    //#line 143 "x10/regionarray/PolyRegion.x10"
                    t$155491$value$155585[(int)t$155475]=t$155477;
                    
                    //#line 142 "x10/regionarray/PolyRegion.x10"
                    final int t$155479 = ((i$155480) + (((int)(1))));
                    
                    //#line 142 "x10/regionarray/PolyRegion.x10"
                    i$155480 = t$155479;
                }
            }
            
            //#line 144 "x10/regionarray/PolyRegion.x10"
            final long t$155492 = tt.rank;
            
            //#line 144 "x10/regionarray/PolyRegion.x10"
            final long t$155493 = ff.rank;
            
            //#line 144 "x10/regionarray/PolyRegion.x10"
            final int t$155494 = ((int)(long)(((long)(t$155493))));
            
            //#line 144 "x10/regionarray/PolyRegion.x10"
            final int t$155495 = r$155487.$apply$O((int)(t$155494));
            
            //#line 144 "x10/regionarray/PolyRegion.x10"
            ((int[])t$155491.value)[(int)t$155492] = t$155495;
            
            //#line 145 "x10/regionarray/PolyRegion.x10"
            final x10.regionarray.PolyRow alloc$155496 = ((x10.regionarray.PolyRow)(new x10.regionarray.PolyRow((java.lang.System[]) null)));
            
            //#line 29 . "x10/regionarray/PolyRow.x10"
            final long t$155485 = ((x10.core.Rail<x10.core.Int>)t$155491).size;
            
            //#line 29 . "x10/regionarray/PolyRow.x10"
            final long t$155486 = ((t$155485) - (((long)(1L))));
            
            //#line 29 . "x10/regionarray/PolyRow.x10"
            alloc$155496.x10$regionarray$PolyRow$$init$S(((x10.core.Rail)(t$155491)), t$155486, (x10.regionarray.PolyRow.__0$1x10$lang$Int$2) null);
            
            //#line 145 "x10/regionarray/PolyRegion.x10"
            tt.add(((x10.regionarray.Row)(alloc$155496)));
        }
    }
    
    public static void copy$P(final x10.regionarray.PolyMatBuilder tt, final x10.regionarray.PolyMat ff, final int offset) {
        x10.regionarray.PolyRegion.copy(((x10.regionarray.PolyMatBuilder)(tt)), ((x10.regionarray.PolyMat)(ff)), (int)(offset));
    }
    
    
    //#line 150 "x10/regionarray/PolyRegion.x10"
    public x10.regionarray.Region translate(final x10.lang.Point v) {
        
        //#line 151 "x10/regionarray/PolyRegion.x10"
        final x10.regionarray.PolyMatBuilder pmb = ((x10.regionarray.PolyMatBuilder)(new x10.regionarray.PolyMatBuilder((java.lang.System[]) null)));
        
        //#line 151 "x10/regionarray/PolyRegion.x10"
        final long t$155498 = this.rank;
        
        //#line 151 "x10/regionarray/PolyRegion.x10"
        pmb.x10$regionarray$PolyMatBuilder$$init$S(((long)(t$155498)));
        
        //#line 152 "x10/regionarray/PolyRegion.x10"
        final x10.regionarray.PolyMat t$155274 = ((x10.regionarray.PolyMat)(this.mat));
        
        //#line 152 "x10/regionarray/PolyRegion.x10"
        x10.regionarray.PolyRegion.translate(((x10.regionarray.PolyMatBuilder)(pmb)), ((x10.regionarray.PolyMat)(t$155274)), ((x10.lang.Point)(v)));
        
        //#line 153 "x10/regionarray/PolyRegion.x10"
        final x10.regionarray.PolyMat pm = ((x10.regionarray.PolyMat)(pmb.toSortedPolyMat((boolean)(false))));
        
        //#line 154 "x10/regionarray/PolyRegion.x10"
        final x10.regionarray.Region t$155275 = ((x10.regionarray.Region)(x10.regionarray.PolyRegion.make(((x10.regionarray.PolyMat)(pm)))));
        
        //#line 154 "x10/regionarray/PolyRegion.x10"
        return t$155275;
    }
    
    
    //#line 157 "x10/regionarray/PolyRegion.x10"
    private static void translate(final x10.regionarray.PolyMatBuilder tt, final x10.regionarray.PolyMat ff, final x10.lang.Point v) {
        
        //#line 158 "x10/regionarray/PolyRegion.x10"
        final x10.lang.Iterator r$154404 = ((x10.regionarray.Mat<x10.regionarray.PolyRow>)ff).iterator();
        
        //#line 158 "x10/regionarray/PolyRegion.x10"
        for (;
             true;
             ) {
            
            //#line 158 "x10/regionarray/PolyRegion.x10"
            final boolean t$155308 = ((x10.lang.Iterator<x10.regionarray.PolyRow>)r$154404).hasNext$O();
            
            //#line 158 "x10/regionarray/PolyRegion.x10"
            if (!(t$155308)) {
                
                //#line 158 "x10/regionarray/PolyRegion.x10"
                break;
            }
            
            //#line 158 "x10/regionarray/PolyRegion.x10"
            final x10.regionarray.PolyRow r$155522 = ((x10.lang.Iterator<x10.regionarray.PolyRow>)r$154404).next$G();
            
            //#line 160 "x10/regionarray/PolyRegion.x10"
            final long t$155524 = ff.rank;
            
            //#line 160 "x10/regionarray/PolyRegion.x10"
            final long t$155525 = ((t$155524) + (((long)(1L))));
            
            //#line 160 "x10/regionarray/PolyRegion.x10"
            final x10.core.Rail t$155526 = ((x10.core.Rail)(new x10.core.Rail<x10.core.Int>(x10.rtt.Types.INT, t$155525)));
            
            //#line 161 "x10/regionarray/PolyRegion.x10"
            int s$155527 = 0;
            
            //#line 162 "x10/regionarray/PolyRegion.x10"
            int i$155515 = 0;
            {
                
                //#line 162 "x10/regionarray/PolyRegion.x10"
                final int[] t$155526$value$155586 = ((int[])t$155526.value);
                
                //#line 162 "x10/regionarray/PolyRegion.x10"
                for (;
                     true;
                     ) {
                    
                    //#line 162 "x10/regionarray/PolyRegion.x10"
                    final long t$155517 = ((long)(((int)(i$155515))));
                    
                    //#line 162 "x10/regionarray/PolyRegion.x10"
                    final long t$155518 = ff.rank;
                    
                    //#line 162 "x10/regionarray/PolyRegion.x10"
                    final boolean t$155519 = ((t$155517) < (((long)(t$155518))));
                    
                    //#line 162 "x10/regionarray/PolyRegion.x10"
                    if (!(t$155519)) {
                        
                        //#line 162 "x10/regionarray/PolyRegion.x10"
                        break;
                    }
                    
                    //#line 163 "x10/regionarray/PolyRegion.x10"
                    final long t$155500 = ((long)(((int)(i$155515))));
                    
                    //#line 163 "x10/regionarray/PolyRegion.x10"
                    final int t$155502 = r$155522.$apply$O((int)(i$155515));
                    
                    //#line 163 "x10/regionarray/PolyRegion.x10"
                    t$155526$value$155586[(int)t$155500]=t$155502;
                    
                    //#line 164 "x10/regionarray/PolyRegion.x10"
                    final long t$155504 = ((long)(((int)(s$155527))));
                    
                    //#line 164 "x10/regionarray/PolyRegion.x10"
                    final int t$155506 = r$155522.$apply$O((int)(i$155515));
                    
                    //#line 164 "x10/regionarray/PolyRegion.x10"
                    final long t$155507 = ((long)(((int)(t$155506))));
                    
                    //#line 164 "x10/regionarray/PolyRegion.x10"
                    final long t$155509 = ((long)(((int)(i$155515))));
                    
                    //#line 164 "x10/regionarray/PolyRegion.x10"
                    final long t$155510 = v.$apply$O((long)(t$155509));
                    
                    //#line 164 "x10/regionarray/PolyRegion.x10"
                    final long t$155511 = ((t$155507) * (((long)(t$155510))));
                    
                    //#line 164 "x10/regionarray/PolyRegion.x10"
                    final long t$155512 = ((t$155504) + (((long)(t$155511))));
                    
                    //#line 164 "x10/regionarray/PolyRegion.x10"
                    s$155527 = ((int)(((long)(t$155512))));
                    
                    //#line 162 "x10/regionarray/PolyRegion.x10"
                    final int t$155514 = ((i$155515) + (((int)(1))));
                    
                    //#line 162 "x10/regionarray/PolyRegion.x10"
                    i$155515 = t$155514;
                }
            }
            
            //#line 166 "x10/regionarray/PolyRegion.x10"
            final long t$155528 = ff.rank;
            
            //#line 166 "x10/regionarray/PolyRegion.x10"
            final long t$155529 = ff.rank;
            
            //#line 166 "x10/regionarray/PolyRegion.x10"
            final int t$155530 = ((int)(long)(((long)(t$155529))));
            
            //#line 166 "x10/regionarray/PolyRegion.x10"
            final int t$155531 = r$155522.$apply$O((int)(t$155530));
            
            //#line 166 "x10/regionarray/PolyRegion.x10"
            final int t$155533 = ((t$155531) - (((int)(s$155527))));
            
            //#line 166 "x10/regionarray/PolyRegion.x10"
            ((int[])t$155526.value)[(int)t$155528] = t$155533;
            
            //#line 167 "x10/regionarray/PolyRegion.x10"
            final x10.regionarray.PolyRow alloc$155534 = ((x10.regionarray.PolyRow)(new x10.regionarray.PolyRow((java.lang.System[]) null)));
            
            //#line 29 . "x10/regionarray/PolyRow.x10"
            final long t$155520 = ((x10.core.Rail<x10.core.Int>)t$155526).size;
            
            //#line 29 . "x10/regionarray/PolyRow.x10"
            final long t$155521 = ((t$155520) - (((long)(1L))));
            
            //#line 29 . "x10/regionarray/PolyRow.x10"
            alloc$155534.x10$regionarray$PolyRow$$init$S(((x10.core.Rail)(t$155526)), t$155521, (x10.regionarray.PolyRow.__0$1x10$lang$Int$2) null);
            
            //#line 167 "x10/regionarray/PolyRegion.x10"
            tt.add(((x10.regionarray.Row)(alloc$155534)));
        }
    }
    
    public static void translate$P(final x10.regionarray.PolyMatBuilder tt, final x10.regionarray.PolyMat ff, final x10.lang.Point v) {
        x10.regionarray.PolyRegion.translate(((x10.regionarray.PolyMatBuilder)(tt)), ((x10.regionarray.PolyMat)(ff)), ((x10.lang.Point)(v)));
    }
    
    
    //#line 196 "x10/regionarray/PolyRegion.x10"
    /**
     * -H0 || -H1 && H0 || -H2 && H1 && H0 || ...
     */
    public boolean isEmpty$O() {
        
        //#line 197 "x10/regionarray/PolyRegion.x10"
        final x10.regionarray.PolyMat t$155309 = ((x10.regionarray.PolyMat)(this.mat));
        
        //#line 197 "x10/regionarray/PolyRegion.x10"
        final boolean tmp = t$155309.isEmpty$O();
        
        //#line 198 "x10/regionarray/PolyRegion.x10"
        return tmp;
    }
    
    
    //#line 201 "x10/regionarray/PolyRegion.x10"
    public x10.regionarray.Region computeBoundingBox() {
        
        //#line 202 "x10/regionarray/PolyRegion.x10"
        final long t$155310 = this.rank;
        
        //#line 202 "x10/regionarray/PolyRegion.x10"
        final x10.core.Rail min = ((x10.core.Rail)(new x10.core.Rail<x10.core.Long>(x10.rtt.Types.LONG, ((long)(t$155310)))));
        
        //#line 203 "x10/regionarray/PolyRegion.x10"
        final long t$155311 = this.rank;
        
        //#line 203 "x10/regionarray/PolyRegion.x10"
        final x10.core.Rail max = ((x10.core.Rail)(new x10.core.Rail<x10.core.Long>(x10.rtt.Types.LONG, ((long)(t$155311)))));
        
        //#line 204 "x10/regionarray/PolyRegion.x10"
        x10.regionarray.PolyMat pm = ((x10.regionarray.PolyMat)(this.mat));
        
        //#line 205 "x10/regionarray/PolyRegion.x10"
        int axis$155565 = 0;
        {
            
            //#line 205 "x10/regionarray/PolyRegion.x10"
            final long[] min$value$155587 = ((long[])min.value);
            
            //#line 205 "x10/regionarray/PolyRegion.x10"
            final long[] max$value$155588 = ((long[])max.value);
            
            //#line 205 "x10/regionarray/PolyRegion.x10"
            for (;
                 true;
                 ) {
                
                //#line 205 "x10/regionarray/PolyRegion.x10"
                final long t$155567 = ((long)(((int)(axis$155565))));
                
                //#line 205 "x10/regionarray/PolyRegion.x10"
                final long t$155568 = this.rank;
                
                //#line 205 "x10/regionarray/PolyRegion.x10"
                final boolean t$155569 = ((t$155567) < (((long)(t$155568))));
                
                //#line 205 "x10/regionarray/PolyRegion.x10"
                if (!(t$155569)) {
                    
                    //#line 205 "x10/regionarray/PolyRegion.x10"
                    break;
                }
                
                //#line 206 "x10/regionarray/PolyRegion.x10"
                x10.regionarray.PolyMat x$155547 = pm;
                
                //#line 207 "x10/regionarray/PolyRegion.x10"
                int k$155542 = ((axis$155565) + (((int)(1))));
                
                //#line 207 "x10/regionarray/PolyRegion.x10"
                for (;
                     true;
                     ) {
                    
                    //#line 207 "x10/regionarray/PolyRegion.x10"
                    final long t$155544 = ((long)(((int)(k$155542))));
                    
                    //#line 207 "x10/regionarray/PolyRegion.x10"
                    final long t$155545 = this.rank;
                    
                    //#line 207 "x10/regionarray/PolyRegion.x10"
                    final boolean t$155546 = ((t$155544) < (((long)(t$155545))));
                    
                    //#line 207 "x10/regionarray/PolyRegion.x10"
                    if (!(t$155546)) {
                        
                        //#line 207 "x10/regionarray/PolyRegion.x10"
                        break;
                    }
                    
                    //#line 208 "x10/regionarray/PolyRegion.x10"
                    final x10.regionarray.PolyMat t$155538 = ((x10.regionarray.PolyMat)(x$155547.eliminate((int)(k$155542), (boolean)(true))));
                    
                    //#line 208 "x10/regionarray/PolyRegion.x10"
                    x$155547 = ((x10.regionarray.PolyMat)(t$155538));
                    
                    //#line 207 "x10/regionarray/PolyRegion.x10"
                    final int t$155540 = ((k$155542) + (((int)(1))));
                    
                    //#line 207 "x10/regionarray/PolyRegion.x10"
                    k$155542 = t$155540;
                }
                
                //#line 209 "x10/regionarray/PolyRegion.x10"
                final long t$155549 = ((long)(((int)(axis$155565))));
                
                //#line 209 "x10/regionarray/PolyRegion.x10"
                final int t$155552 = x$155547.rectMin$O((int)(axis$155565));
                
                //#line 209 "x10/regionarray/PolyRegion.x10"
                final long t$155553 = ((long)(((int)(t$155552))));
                
                //#line 209 "x10/regionarray/PolyRegion.x10"
                min$value$155587[(int)t$155549]=t$155553;
                
                //#line 210 "x10/regionarray/PolyRegion.x10"
                final long t$155555 = ((long)(((int)(axis$155565))));
                
                //#line 210 "x10/regionarray/PolyRegion.x10"
                final int t$155558 = x$155547.rectMax$O((int)(axis$155565));
                
                //#line 210 "x10/regionarray/PolyRegion.x10"
                final long t$155559 = ((long)(((int)(t$155558))));
                
                //#line 210 "x10/regionarray/PolyRegion.x10"
                max$value$155588[(int)t$155555]=t$155559;
                
                //#line 211 "x10/regionarray/PolyRegion.x10"
                final x10.regionarray.PolyMat t$155562 = ((x10.regionarray.PolyMat)(pm.eliminate((int)(axis$155565), (boolean)(true))));
                
                //#line 211 "x10/regionarray/PolyRegion.x10"
                pm = ((x10.regionarray.PolyMat)(t$155562));
                
                //#line 205 "x10/regionarray/PolyRegion.x10"
                final int t$155564 = ((axis$155565) + (((int)(1))));
                
                //#line 205 "x10/regionarray/PolyRegion.x10"
                axis$155565 = t$155564;
            }
        }
        
        //#line 213 "x10/regionarray/PolyRegion.x10"
        final x10.regionarray.Region t$155345 = ((x10.regionarray.Region)(x10.regionarray.Region.makeRectangular__0$1x10$lang$Long$2__1$1x10$lang$Long$2(((x10.core.Rail)(min)), ((x10.core.Rail)(max)))));
        
        //#line 213 "x10/regionarray/PolyRegion.x10"
        final x10.regionarray.Region t$154257 = ((x10.regionarray.Region)
                                                  t$155345);
        
        //#line 213 "x10/regionarray/PolyRegion.x10"
        final boolean t$155346 = t$154257.rect;
        
        //#line 213 "x10/regionarray/PolyRegion.x10"
        boolean t$155349 = ((boolean) t$155346) == ((boolean) true);
        
        //#line 213 "x10/regionarray/PolyRegion.x10"
        if (t$155349) {
            
            //#line 213 "x10/regionarray/PolyRegion.x10"
            final long t$155347 = t$154257.rank;
            
            //#line 213 "x10/regionarray/PolyRegion.x10"
            final long t$155348 = x10.regionarray.PolyRegion.this.rank;
            
            //#line 213 "x10/regionarray/PolyRegion.x10"
            t$155349 = ((long) t$155347) == ((long) t$155348);
        }
        
        //#line 213 "x10/regionarray/PolyRegion.x10"
        final boolean t$155352 = !(t$155349);
        
        //#line 213 "x10/regionarray/PolyRegion.x10"
        if (t$155352) {
            
            //#line 213 "x10/regionarray/PolyRegion.x10"
            final x10.lang.FailedDynamicCheckException t$155351 = new x10.lang.FailedDynamicCheckException("x10.regionarray.Region{self.rect==true, self.rank==this(:x10.regionarray.PolyRegion).rank}");
            
            //#line 213 "x10/regionarray/PolyRegion.x10"
            throw t$155351;
        }
        
        //#line 213 "x10/regionarray/PolyRegion.x10"
        return t$154257;
    }
    
    
    //#line 221 "x10/regionarray/PolyRegion.x10"
    /**
     * point
     */
    public boolean contains$O(final x10.lang.Point p) {
        
        //#line 223 "x10/regionarray/PolyRegion.x10"
        final x10.regionarray.PolyMat t$155573 = ((x10.regionarray.PolyMat)(this.mat));
        
        //#line 223 "x10/regionarray/PolyRegion.x10"
        final x10.lang.Iterator r$155574 = ((x10.regionarray.Mat<x10.regionarray.PolyRow>)t$155573).iterator();
        
        //#line 223 "x10/regionarray/PolyRegion.x10"
        for (;
             true;
             ) {
            
            //#line 223 "x10/regionarray/PolyRegion.x10"
            final boolean t$155575 = ((x10.lang.Iterator<x10.regionarray.PolyRow>)r$155574).hasNext$O();
            
            //#line 223 "x10/regionarray/PolyRegion.x10"
            if (!(t$155575)) {
                
                //#line 223 "x10/regionarray/PolyRegion.x10"
                break;
            }
            
            //#line 223 "x10/regionarray/PolyRegion.x10"
            final x10.regionarray.PolyRow r$155570 = ((x10.lang.Iterator<x10.regionarray.PolyRow>)r$155574).next$G();
            
            //#line 224 "x10/regionarray/PolyRegion.x10"
            final boolean t$155571 = r$155570.contains$O(((x10.lang.Point)(p)));
            
            //#line 224 "x10/regionarray/PolyRegion.x10"
            final boolean t$155572 = !(t$155571);
            
            //#line 224 "x10/regionarray/PolyRegion.x10"
            if (t$155572) {
                
                //#line 225 "x10/regionarray/PolyRegion.x10"
                return false;
            }
        }
        
        //#line 228 "x10/regionarray/PolyRegion.x10"
        return true;
    }
    
    
    //#line 244 "x10/regionarray/PolyRegion.x10"
    private static int ROW = 0;
    
    //#line 245 "x10/regionarray/PolyRegion.x10"
    private static int COL = 0;
    
    
    //#line 247 "x10/regionarray/PolyRegion.x10"
    public static x10.regionarray.Region makeBanded(final int rowMin, final int colMin, final int rowMax, final int colMax, final int upper, final int lower) {
        
        //#line 248 "x10/regionarray/PolyRegion.x10"
        final x10.regionarray.PolyMatBuilder pmb = ((x10.regionarray.PolyMatBuilder)(new x10.regionarray.PolyMatBuilder((java.lang.System[]) null)));
        
        //#line 248 "x10/regionarray/PolyRegion.x10"
        pmb.x10$regionarray$PolyMatBuilder$$init$S(((long)(2L)));
        
        //#line 249 "x10/regionarray/PolyRegion.x10"
        final int t$155358 = x10.regionarray.PolyRegion.get$ROW();
        
        //#line 249 "x10/regionarray/PolyRegion.x10"
        final int t$155359 = x10.regionarray.PolyMatBuilder.get$GE();
        
        //#line 249 "x10/regionarray/PolyRegion.x10"
        pmb.add((int)(t$155358), (int)(t$155359), (int)(rowMin));
        
        //#line 250 "x10/regionarray/PolyRegion.x10"
        final int t$155360 = x10.regionarray.PolyRegion.get$ROW();
        
        //#line 250 "x10/regionarray/PolyRegion.x10"
        final int t$155361 = x10.regionarray.PolyMatBuilder.get$LE();
        
        //#line 250 "x10/regionarray/PolyRegion.x10"
        pmb.add((int)(t$155360), (int)(t$155361), (int)(rowMax));
        
        //#line 251 "x10/regionarray/PolyRegion.x10"
        final int t$155362 = x10.regionarray.PolyRegion.get$COL();
        
        //#line 251 "x10/regionarray/PolyRegion.x10"
        final int t$155363 = x10.regionarray.PolyMatBuilder.get$GE();
        
        //#line 251 "x10/regionarray/PolyRegion.x10"
        pmb.add((int)(t$155362), (int)(t$155363), (int)(colMin));
        
        //#line 252 "x10/regionarray/PolyRegion.x10"
        final int t$155364 = x10.regionarray.PolyRegion.get$COL();
        
        //#line 252 "x10/regionarray/PolyRegion.x10"
        final int t$155365 = x10.regionarray.PolyMatBuilder.get$LE();
        
        //#line 252 "x10/regionarray/PolyRegion.x10"
        pmb.add((int)(t$155364), (int)(t$155365), (int)(colMax));
        
        //#line 253 "x10/regionarray/PolyRegion.x10"
        final int t$155366 = x10.regionarray.PolyRegion.get$COL();
        
        //#line 253 "x10/regionarray/PolyRegion.x10"
        final int t$155367 = x10.regionarray.PolyRegion.get$ROW();
        
        //#line 253 "x10/regionarray/PolyRegion.x10"
        final int t$155370 = ((t$155366) - (((int)(t$155367))));
        
        //#line 253 "x10/regionarray/PolyRegion.x10"
        final int t$155371 = x10.regionarray.PolyMatBuilder.get$GE();
        
        //#line 253 "x10/regionarray/PolyRegion.x10"
        final int t$155368 = ((colMin) - (((int)(rowMin))));
        
        //#line 253 "x10/regionarray/PolyRegion.x10"
        final int t$155369 = ((lower) - (((int)(1))));
        
        //#line 253 "x10/regionarray/PolyRegion.x10"
        final int t$155372 = ((t$155368) - (((int)(t$155369))));
        
        //#line 253 "x10/regionarray/PolyRegion.x10"
        pmb.add((int)(t$155370), (int)(t$155371), (int)(t$155372));
        
        //#line 254 "x10/regionarray/PolyRegion.x10"
        final int t$155373 = x10.regionarray.PolyRegion.get$COL();
        
        //#line 254 "x10/regionarray/PolyRegion.x10"
        final int t$155374 = x10.regionarray.PolyRegion.get$ROW();
        
        //#line 254 "x10/regionarray/PolyRegion.x10"
        final int t$155377 = ((t$155373) - (((int)(t$155374))));
        
        //#line 254 "x10/regionarray/PolyRegion.x10"
        final int t$155378 = x10.regionarray.PolyMatBuilder.get$LE();
        
        //#line 254 "x10/regionarray/PolyRegion.x10"
        final int t$155375 = ((colMin) - (((int)(rowMin))));
        
        //#line 254 "x10/regionarray/PolyRegion.x10"
        final int t$155376 = ((upper) - (((int)(1))));
        
        //#line 254 "x10/regionarray/PolyRegion.x10"
        final int t$155379 = ((t$155375) + (((int)(t$155376))));
        
        //#line 254 "x10/regionarray/PolyRegion.x10"
        pmb.add((int)(t$155377), (int)(t$155378), (int)(t$155379));
        
        //#line 255 "x10/regionarray/PolyRegion.x10"
        final x10.regionarray.PolyMat pm = ((x10.regionarray.PolyMat)(pmb.toSortedPolyMat((boolean)(false))));
        
        //#line 256 "x10/regionarray/PolyRegion.x10"
        final x10.regionarray.Region t$155380 = ((x10.regionarray.Region)(x10.regionarray.PolyRegion.make(((x10.regionarray.PolyMat)(pm)))));
        
        //#line 256 "x10/regionarray/PolyRegion.x10"
        return t$155380;
    }
    
    
    //#line 259 "x10/regionarray/PolyRegion.x10"
    public static x10.regionarray.Region makeBanded(final int size, final int upper, final int lower) {
        
        //#line 260 "x10/regionarray/PolyRegion.x10"
        final int t$155381 = ((size) - (((int)(1))));
        
        //#line 260 "x10/regionarray/PolyRegion.x10"
        final int t$155382 = ((size) - (((int)(1))));
        
        //#line 260 "x10/regionarray/PolyRegion.x10"
        final x10.regionarray.Region t$155383 = ((x10.regionarray.Region)(x10.regionarray.PolyRegion.makeBanded((int)(0), (int)(0), (int)(t$155381), (int)(t$155382), (int)(upper), (int)(lower))));
        
        //#line 260 "x10/regionarray/PolyRegion.x10"
        return t$155383;
    }
    
    
    //#line 263 "x10/regionarray/PolyRegion.x10"
    public static x10.regionarray.Region makeUpperTriangular2(final int rowMin, final int colMin, final int size) {
        
        //#line 264 "x10/regionarray/PolyRegion.x10"
        final x10.regionarray.PolyMatBuilder pmb = ((x10.regionarray.PolyMatBuilder)(new x10.regionarray.PolyMatBuilder((java.lang.System[]) null)));
        
        //#line 264 "x10/regionarray/PolyRegion.x10"
        final long t$155576 = ((long)(((int)(2))));
        
        //#line 264 "x10/regionarray/PolyRegion.x10"
        pmb.x10$regionarray$PolyMatBuilder$$init$S(t$155576);
        
        //#line 265 "x10/regionarray/PolyRegion.x10"
        final int t$155385 = x10.regionarray.PolyRegion.get$ROW();
        
        //#line 265 "x10/regionarray/PolyRegion.x10"
        final int t$155386 = x10.regionarray.PolyMatBuilder.get$GE();
        
        //#line 265 "x10/regionarray/PolyRegion.x10"
        pmb.add((int)(t$155385), (int)(t$155386), (int)(rowMin));
        
        //#line 266 "x10/regionarray/PolyRegion.x10"
        final int t$155388 = x10.regionarray.PolyRegion.get$COL();
        
        //#line 266 "x10/regionarray/PolyRegion.x10"
        final int t$155389 = x10.regionarray.PolyMatBuilder.get$LE();
        
        //#line 266 "x10/regionarray/PolyRegion.x10"
        final int t$155387 = ((colMin) + (((int)(size))));
        
        //#line 266 "x10/regionarray/PolyRegion.x10"
        final int t$155390 = ((t$155387) - (((int)(1))));
        
        //#line 266 "x10/regionarray/PolyRegion.x10"
        pmb.add((int)(t$155388), (int)(t$155389), (int)(t$155390));
        
        //#line 267 "x10/regionarray/PolyRegion.x10"
        final int t$155391 = x10.regionarray.PolyRegion.get$COL();
        
        //#line 267 "x10/regionarray/PolyRegion.x10"
        final int t$155392 = x10.regionarray.PolyRegion.get$ROW();
        
        //#line 267 "x10/regionarray/PolyRegion.x10"
        final int t$155393 = ((t$155391) - (((int)(t$155392))));
        
        //#line 267 "x10/regionarray/PolyRegion.x10"
        final int t$155394 = x10.regionarray.PolyMatBuilder.get$GE();
        
        //#line 267 "x10/regionarray/PolyRegion.x10"
        final int t$155395 = ((colMin) - (((int)(rowMin))));
        
        //#line 267 "x10/regionarray/PolyRegion.x10"
        pmb.add((int)(t$155393), (int)(t$155394), (int)(t$155395));
        
        //#line 268 "x10/regionarray/PolyRegion.x10"
        final x10.regionarray.PolyMat pm = ((x10.regionarray.PolyMat)(pmb.toSortedPolyMat((boolean)(true))));
        
        //#line 269 "x10/regionarray/PolyRegion.x10"
        final x10.regionarray.Region t$155396 = ((x10.regionarray.Region)(x10.regionarray.PolyRegion.make(((x10.regionarray.PolyMat)(pm)))));
        
        //#line 269 "x10/regionarray/PolyRegion.x10"
        final x10.regionarray.Region t$154357 = ((x10.regionarray.Region)
                                                  t$155396);
        
        //#line 269 "x10/regionarray/PolyRegion.x10"
        final long t$155397 = t$154357.rank;
        
        //#line 269 "x10/regionarray/PolyRegion.x10"
        final boolean t$155398 = ((long) t$155397) == ((long) 2L);
        
        //#line 269 "x10/regionarray/PolyRegion.x10"
        final boolean t$155400 = !(t$155398);
        
        //#line 269 "x10/regionarray/PolyRegion.x10"
        if (t$155400) {
            
            //#line 269 "x10/regionarray/PolyRegion.x10"
            final x10.lang.FailedDynamicCheckException t$155399 = new x10.lang.FailedDynamicCheckException("x10.regionarray.Region{self.rank==2L}");
            
            //#line 269 "x10/regionarray/PolyRegion.x10"
            throw t$155399;
        }
        
        //#line 269 "x10/regionarray/PolyRegion.x10"
        return t$154357;
    }
    
    
    //#line 272 "x10/regionarray/PolyRegion.x10"
    public static x10.regionarray.Region makeLowerTriangular2(final int rowMin, final int colMin, final int size) {
        
        //#line 273 "x10/regionarray/PolyRegion.x10"
        final x10.regionarray.PolyMatBuilder pmb = ((x10.regionarray.PolyMatBuilder)(new x10.regionarray.PolyMatBuilder((java.lang.System[]) null)));
        
        //#line 273 "x10/regionarray/PolyRegion.x10"
        final long t$155577 = ((long)(((int)(2))));
        
        //#line 273 "x10/regionarray/PolyRegion.x10"
        pmb.x10$regionarray$PolyMatBuilder$$init$S(t$155577);
        
        //#line 274 "x10/regionarray/PolyRegion.x10"
        final int t$155402 = x10.regionarray.PolyRegion.get$COL();
        
        //#line 274 "x10/regionarray/PolyRegion.x10"
        final int t$155403 = x10.regionarray.PolyMatBuilder.get$GE();
        
        //#line 274 "x10/regionarray/PolyRegion.x10"
        pmb.add((int)(t$155402), (int)(t$155403), (int)(colMin));
        
        //#line 275 "x10/regionarray/PolyRegion.x10"
        final int t$155405 = x10.regionarray.PolyRegion.get$ROW();
        
        //#line 275 "x10/regionarray/PolyRegion.x10"
        final int t$155406 = x10.regionarray.PolyMatBuilder.get$LE();
        
        //#line 275 "x10/regionarray/PolyRegion.x10"
        final int t$155404 = ((rowMin) + (((int)(size))));
        
        //#line 275 "x10/regionarray/PolyRegion.x10"
        final int t$155407 = ((t$155404) - (((int)(1))));
        
        //#line 275 "x10/regionarray/PolyRegion.x10"
        pmb.add((int)(t$155405), (int)(t$155406), (int)(t$155407));
        
        //#line 276 "x10/regionarray/PolyRegion.x10"
        final int t$155408 = x10.regionarray.PolyRegion.get$ROW();
        
        //#line 276 "x10/regionarray/PolyRegion.x10"
        final int t$155409 = x10.regionarray.PolyRegion.get$COL();
        
        //#line 276 "x10/regionarray/PolyRegion.x10"
        final int t$155410 = ((t$155408) - (((int)(t$155409))));
        
        //#line 276 "x10/regionarray/PolyRegion.x10"
        final int t$155411 = x10.regionarray.PolyMatBuilder.get$GE();
        
        //#line 276 "x10/regionarray/PolyRegion.x10"
        final int t$155412 = ((rowMin) - (((int)(colMin))));
        
        //#line 276 "x10/regionarray/PolyRegion.x10"
        pmb.add((int)(t$155410), (int)(t$155411), (int)(t$155412));
        
        //#line 277 "x10/regionarray/PolyRegion.x10"
        final x10.regionarray.PolyMat pm = ((x10.regionarray.PolyMat)(pmb.toSortedPolyMat((boolean)(true))));
        
        //#line 278 "x10/regionarray/PolyRegion.x10"
        final x10.regionarray.Region t$155413 = ((x10.regionarray.Region)(x10.regionarray.PolyRegion.make(((x10.regionarray.PolyMat)(pm)))));
        
        //#line 278 "x10/regionarray/PolyRegion.x10"
        final x10.regionarray.Region t$154387 = ((x10.regionarray.Region)
                                                  t$155413);
        
        //#line 278 "x10/regionarray/PolyRegion.x10"
        final long t$155414 = t$154387.rank;
        
        //#line 278 "x10/regionarray/PolyRegion.x10"
        final boolean t$155415 = ((long) t$155414) == ((long) 2L);
        
        //#line 278 "x10/regionarray/PolyRegion.x10"
        final boolean t$155417 = !(t$155415);
        
        //#line 278 "x10/regionarray/PolyRegion.x10"
        if (t$155417) {
            
            //#line 278 "x10/regionarray/PolyRegion.x10"
            final x10.lang.FailedDynamicCheckException t$155416 = new x10.lang.FailedDynamicCheckException("x10.regionarray.Region{self.rank==2L}");
            
            //#line 278 "x10/regionarray/PolyRegion.x10"
            throw t$155416;
        }
        
        //#line 278 "x10/regionarray/PolyRegion.x10"
        return t$154387;
    }
    
    
    //#line 288 "x10/regionarray/PolyRegion.x10"
    /**
     * here's where we examine the halfspaces and generate
     * special-case subclasses, such as RectRegion, for efficiency
     */
    public static x10.regionarray.Region make(final x10.regionarray.PolyMat pm) {
        
        //#line 289 "x10/regionarray/PolyRegion.x10"
        final boolean t$155419 = pm.isEmpty$O();
        
        //#line 289 "x10/regionarray/PolyRegion.x10"
        if (t$155419) {
            
            //#line 290 "x10/regionarray/PolyRegion.x10"
            final x10.regionarray.EmptyRegion alloc$154393 = ((x10.regionarray.EmptyRegion)(new x10.regionarray.EmptyRegion((java.lang.System[]) null)));
            
            //#line 290 "x10/regionarray/PolyRegion.x10"
            final long t$155578 = pm.rank;
            
            //#line 290 "x10/regionarray/PolyRegion.x10"
            alloc$154393.x10$regionarray$EmptyRegion$$init$S(((long)(t$155578)));
            
            //#line 290 "x10/regionarray/PolyRegion.x10"
            return alloc$154393;
        } else {
            
            //#line 292 "x10/regionarray/PolyRegion.x10"
            final x10.regionarray.PolyRegion alloc$154394 = ((x10.regionarray.PolyRegion)(new x10.regionarray.PolyRegion((java.lang.System[]) null)));
            
            //#line 292 "x10/regionarray/PolyRegion.x10"
            alloc$154394.x10$regionarray$PolyRegion$$init$S(((x10.regionarray.PolyMat)(pm)), ((boolean)(false)));
            
            //#line 292 "x10/regionarray/PolyRegion.x10"
            return alloc$154394;
        }
    }
    
    
    //#line 296 "x10/regionarray/PolyRegion.x10"
    // creation method for java code (1-phase java constructor)
    public PolyRegion(final x10.regionarray.PolyMat pm, final boolean hack198) {
        this((java.lang.System[]) null);
        x10$regionarray$PolyRegion$$init$S(pm, hack198);
    }
    
    // constructor for non-virtual call
    final public x10.regionarray.PolyRegion x10$regionarray$PolyRegion$$init$S(final x10.regionarray.PolyMat pm, final boolean hack198) {
         {
            
            //#line 298 "x10/regionarray/PolyRegion.x10"
            final x10.regionarray.Region this$155170 = ((x10.regionarray.Region)(this));
            
            //#line 298 "x10/regionarray/PolyRegion.x10"
            final long r$155166 = pm.rank;
            
            //#line 298 "x10/regionarray/PolyRegion.x10"
            final boolean t$155167 = pm.isRect$O();
            
            //#line 298 "x10/regionarray/PolyRegion.x10"
            final boolean z$155168 = pm.isZeroBased$O();
            
            //#line 557 . "x10/regionarray/Region.x10"
            boolean t$155579 = ((long) r$155166) == ((long) 1L);
            
            //#line 557 . "x10/regionarray/Region.x10"
            if (t$155579) {
                
                //#line 557 . "x10/regionarray/Region.x10"
                t$155579 = t$155167;
            }
            
            //#line 557 . "x10/regionarray/Region.x10"
            boolean t$155580 = t$155579;
            
            //#line 557 . "x10/regionarray/Region.x10"
            if (t$155579) {
                
                //#line 557 . "x10/regionarray/Region.x10"
                t$155580 = z$155168;
            }
            
            //#line 558 . "x10/regionarray/Region.x10"
            this$155170.rank = r$155166;
            
            //#line 558 . "x10/regionarray/Region.x10"
            this$155170.rect = t$155167;
            
            //#line 558 . "x10/regionarray/Region.x10"
            this$155170.zeroBased = z$155168;
            
            //#line 558 . "x10/regionarray/Region.x10"
            this$155170.rail = t$155580;
            
            //#line 296 "x10/regionarray/PolyRegion.x10"
            
            
            //#line 26 "x10/regionarray/PolyRegion.x10"
            final x10.regionarray.PolyRegion this$155582 = this;
            
            //#line 26 "x10/regionarray/PolyRegion.x10"
            this$155582.size = -1L;
            
            //#line 302 "x10/regionarray/PolyRegion.x10"
            final x10.regionarray.PolyMat t$155422 = ((x10.regionarray.PolyMat)(pm.simplifyAll()));
            
            //#line 302 "x10/regionarray/PolyRegion.x10"
            final x10.regionarray.PolyMat t$154389 = ((x10.regionarray.PolyMat)
                                                       t$155422);
            
            //#line 302 "x10/regionarray/PolyRegion.x10"
            final long t$155423 = t$154389.rank;
            
            //#line 302 "x10/regionarray/PolyRegion.x10"
            final long t$155424 = x10.regionarray.PolyRegion.this.rank;
            
            //#line 302 "x10/regionarray/PolyRegion.x10"
            final boolean t$155425 = ((long) t$155423) == ((long) t$155424);
            
            //#line 302 "x10/regionarray/PolyRegion.x10"
            final boolean t$155427 = !(t$155425);
            
            //#line 302 "x10/regionarray/PolyRegion.x10"
            if (t$155427) {
                
                //#line 302 "x10/regionarray/PolyRegion.x10"
                final x10.lang.FailedDynamicCheckException t$155426 = new x10.lang.FailedDynamicCheckException("x10.regionarray.PolyMat{self.rank==this(:x10.regionarray.PolyRegion).rank}");
                
                //#line 302 "x10/regionarray/PolyRegion.x10"
                throw t$155426;
            }
            
            //#line 302 "x10/regionarray/PolyRegion.x10"
            this.mat = ((x10.regionarray.PolyMat)(t$154389));
        }
        return this;
    }
    
    
    
    //#line 310 "x10/regionarray/PolyRegion.x10"
    public x10.core.fun.Fun_0_1 min() {
        
        //#line 311 "x10/regionarray/PolyRegion.x10"
        final x10.regionarray.Region t$155428 = ((x10.regionarray.Region)(this.boundingBox()));
        
        //#line 311 "x10/regionarray/PolyRegion.x10"
        final x10.core.fun.Fun_0_1 t = t$155428.min();
        
        //#line 312 "x10/regionarray/PolyRegion.x10"
        final x10.core.fun.Fun_0_1 t$155432 = ((x10.core.fun.Fun_0_1)(new x10.regionarray.PolyRegion.$Closure$256(t, (x10.regionarray.PolyRegion.$Closure$256.__0$1x10$lang$Long$3x10$lang$Long$2) null)));
        
        //#line 312 "x10/regionarray/PolyRegion.x10"
        return t$155432;
    }
    
    
    //#line 315 "x10/regionarray/PolyRegion.x10"
    public x10.core.fun.Fun_0_1 max() {
        
        //#line 316 "x10/regionarray/PolyRegion.x10"
        final x10.regionarray.Region t$155433 = ((x10.regionarray.Region)(this.boundingBox()));
        
        //#line 316 "x10/regionarray/PolyRegion.x10"
        final x10.core.fun.Fun_0_1 t = t$155433.max();
        
        //#line 317 "x10/regionarray/PolyRegion.x10"
        final x10.core.fun.Fun_0_1 t$155437 = ((x10.core.fun.Fun_0_1)(new x10.regionarray.PolyRegion.$Closure$257(t, (x10.regionarray.PolyRegion.$Closure$257.__0$1x10$lang$Long$3x10$lang$Long$2) null)));
        
        //#line 317 "x10/regionarray/PolyRegion.x10"
        return t$155437;
    }
    
    
    //#line 325 "x10/regionarray/PolyRegion.x10"
    public void printInfo(final x10.io.Printer out) {
        
        //#line 326 "x10/regionarray/PolyRegion.x10"
        final x10.regionarray.PolyMat t$155438 = ((x10.regionarray.PolyMat)(this.mat));
        
        //#line 326 "x10/regionarray/PolyRegion.x10"
        final java.lang.String t$155439 = this.toString();
        
        //#line 326 "x10/regionarray/PolyRegion.x10"
        ((x10.regionarray.Mat<x10.regionarray.PolyRow>)t$155438).printInfo(((x10.io.Printer)(out)), ((java.lang.String)(t$155439)));
    }
    
    
    //#line 329 "x10/regionarray/PolyRegion.x10"
    public java.lang.String toString() {
        
        //#line 330 "x10/regionarray/PolyRegion.x10"
        final x10.regionarray.PolyMat t$155440 = ((x10.regionarray.PolyMat)(this.mat));
        
        //#line 330 "x10/regionarray/PolyRegion.x10"
        final java.lang.String t$155441 = t$155440.toString();
        
        //#line 330 "x10/regionarray/PolyRegion.x10"
        return t$155441;
    }
    
    
    //#line 26 "x10/regionarray/PolyRegion.x10"
    final public x10.regionarray.PolyRegion x10$regionarray$PolyRegion$$this$x10$regionarray$PolyRegion() {
        
        //#line 26 "x10/regionarray/PolyRegion.x10"
        return x10.regionarray.PolyRegion.this;
    }
    
    
    //#line 26 "x10/regionarray/PolyRegion.x10"
    final public void __fieldInitializers_x10_regionarray_PolyRegion() {
        
        //#line 26 "x10/regionarray/PolyRegion.x10"
        this.size = -1L;
    }
    
    final private static x10.core.concurrent.AtomicInteger initStatus$COL = new x10.core.concurrent.AtomicInteger(x10.runtime.impl.java.InitDispatcher.UNINITIALIZED);
    private static x10.lang.ExceptionInInitializer exception$COL;
    final private static x10.core.concurrent.AtomicInteger initStatus$ROW = new x10.core.concurrent.AtomicInteger(x10.runtime.impl.java.InitDispatcher.UNINITIALIZED);
    private static x10.lang.ExceptionInInitializer exception$ROW;
    
    public static int get$ROW() {
        if (((int) x10.regionarray.PolyRegion.initStatus$ROW.get()) == ((int) x10.runtime.impl.java.InitDispatcher.INITIALIZED)) {
            return x10.regionarray.PolyRegion.ROW;
        }
        if (((int) x10.regionarray.PolyRegion.initStatus$ROW.get()) == ((int) x10.runtime.impl.java.InitDispatcher.EXCEPTION_RAISED)) {
            throw x10.regionarray.PolyRegion.exception$ROW;
        }
        if (x10.regionarray.PolyRegion.initStatus$ROW.compareAndSet((int)(x10.runtime.impl.java.InitDispatcher.UNINITIALIZED), (int)(x10.runtime.impl.java.InitDispatcher.INITIALIZING))) {
            try {{
                x10.regionarray.PolyRegion.ROW = x10.regionarray.PolyMatBuilder.X$O((int)(0));
            }}catch (java.lang.Throwable exc$155583) {
                x10.regionarray.PolyRegion.exception$ROW = new x10.lang.ExceptionInInitializer(exc$155583);
                x10.regionarray.PolyRegion.initStatus$ROW.set((int)(x10.runtime.impl.java.InitDispatcher.EXCEPTION_RAISED));
                x10.runtime.impl.java.InitDispatcher.lockInitialized();
                x10.runtime.impl.java.InitDispatcher.notifyInitialized();
                throw x10.regionarray.PolyRegion.exception$ROW;
            }
            x10.regionarray.PolyRegion.initStatus$ROW.set((int)(x10.runtime.impl.java.InitDispatcher.INITIALIZED));
            x10.runtime.impl.java.InitDispatcher.lockInitialized();
            x10.runtime.impl.java.InitDispatcher.notifyInitialized();
        } else {
            if (x10.regionarray.PolyRegion.initStatus$ROW.get() < x10.runtime.impl.java.InitDispatcher.INITIALIZED) {
                x10.runtime.impl.java.InitDispatcher.lockInitialized();
                while (x10.regionarray.PolyRegion.initStatus$ROW.get() < x10.runtime.impl.java.InitDispatcher.INITIALIZED) {
                    x10.runtime.impl.java.InitDispatcher.awaitInitialized();
                }
                x10.runtime.impl.java.InitDispatcher.unlockInitialized();
                if (((int) x10.regionarray.PolyRegion.initStatus$ROW.get()) == ((int) x10.runtime.impl.java.InitDispatcher.EXCEPTION_RAISED)) {
                    throw x10.regionarray.PolyRegion.exception$ROW;
                }
            }
        }
        return x10.regionarray.PolyRegion.ROW;
    }
    
    public static int get$COL() {
        if (((int) x10.regionarray.PolyRegion.initStatus$COL.get()) == ((int) x10.runtime.impl.java.InitDispatcher.INITIALIZED)) {
            return x10.regionarray.PolyRegion.COL;
        }
        if (((int) x10.regionarray.PolyRegion.initStatus$COL.get()) == ((int) x10.runtime.impl.java.InitDispatcher.EXCEPTION_RAISED)) {
            throw x10.regionarray.PolyRegion.exception$COL;
        }
        if (x10.regionarray.PolyRegion.initStatus$COL.compareAndSet((int)(x10.runtime.impl.java.InitDispatcher.UNINITIALIZED), (int)(x10.runtime.impl.java.InitDispatcher.INITIALIZING))) {
            try {{
                x10.regionarray.PolyRegion.COL = x10.regionarray.PolyMatBuilder.X$O((int)(1));
            }}catch (java.lang.Throwable exc$155584) {
                x10.regionarray.PolyRegion.exception$COL = new x10.lang.ExceptionInInitializer(exc$155584);
                x10.regionarray.PolyRegion.initStatus$COL.set((int)(x10.runtime.impl.java.InitDispatcher.EXCEPTION_RAISED));
                x10.runtime.impl.java.InitDispatcher.lockInitialized();
                x10.runtime.impl.java.InitDispatcher.notifyInitialized();
                throw x10.regionarray.PolyRegion.exception$COL;
            }
            x10.regionarray.PolyRegion.initStatus$COL.set((int)(x10.runtime.impl.java.InitDispatcher.INITIALIZED));
            x10.runtime.impl.java.InitDispatcher.lockInitialized();
            x10.runtime.impl.java.InitDispatcher.notifyInitialized();
        } else {
            if (x10.regionarray.PolyRegion.initStatus$COL.get() < x10.runtime.impl.java.InitDispatcher.INITIALIZED) {
                x10.runtime.impl.java.InitDispatcher.lockInitialized();
                while (x10.regionarray.PolyRegion.initStatus$COL.get() < x10.runtime.impl.java.InitDispatcher.INITIALIZED) {
                    x10.runtime.impl.java.InitDispatcher.awaitInitialized();
                }
                x10.runtime.impl.java.InitDispatcher.unlockInitialized();
                if (((int) x10.regionarray.PolyRegion.initStatus$COL.get()) == ((int) x10.runtime.impl.java.InitDispatcher.EXCEPTION_RAISED)) {
                    throw x10.regionarray.PolyRegion.exception$COL;
                }
            }
        }
        return x10.regionarray.PolyRegion.COL;
    }
    
    @x10.runtime.impl.java.X10Generated
    final public static class $Closure$256 extends x10.core.Ref implements x10.core.fun.Fun_0_1, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<$Closure$256> $RTT = 
            x10.rtt.StaticFunType.<$Closure$256> make($Closure$256.class,
                                                      new x10.rtt.Type[] {
                                                          x10.rtt.ParameterizedType.make(x10.core.fun.Fun_0_1.$RTT, x10.rtt.Types.LONG, x10.rtt.Types.LONG)
                                                      });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static x10.serialization.X10JavaSerializable $_deserialize_body(x10.regionarray.PolyRegion.$Closure$256 $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            $_obj.t = $deserializer.readObject();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.regionarray.PolyRegion.$Closure$256 $_obj = new x10.regionarray.PolyRegion.$Closure$256((java.lang.System[]) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            $serializer.write(this.t);
            
        }
        
        // constructor just for allocation
        public $Closure$256(final java.lang.System[] $dummy) {
            
        }
        
        // dispatcher for method abstract public (Z1)=>U.operator()(a1:Z1):U
        public java.lang.Object $apply(final java.lang.Object a1, final x10.rtt.Type t1) {
            return x10.core.Long.$box($apply$O(x10.core.Long.$unbox(a1)));
            
        }
        
        // dispatcher for method abstract public (Z1)=>U.operator()(a1:Z1):U
        public long $apply$J(final java.lang.Object a1, final x10.rtt.Type t1) {
            return $apply$O(x10.core.Long.$unbox(a1));
            
        }
        
        // synthetic type for parameter mangling
        public static final class __0$1x10$lang$Long$3x10$lang$Long$2 {}
        
    
        
        public long $apply$O(final long i) {
            
            //#line 312 "x10/regionarray/PolyRegion.x10"
            final int t$155429 = ((int)(long)(((long)(i))));
            
            //#line 312 "x10/regionarray/PolyRegion.x10"
            final long t$155430 = ((long)(((int)(t$155429))));
            
            //#line 312 "x10/regionarray/PolyRegion.x10"
            final long t$155431 = x10.core.Long.$unbox(((x10.core.fun.Fun_0_1<x10.core.Long,x10.core.Long>)this.t).$apply(x10.core.Long.$box(t$155430), x10.rtt.Types.LONG));
            
            //#line 312 "x10/regionarray/PolyRegion.x10"
            return t$155431;
        }
        
        public x10.core.fun.Fun_0_1<x10.core.Long,x10.core.Long> t;
        
        public $Closure$256(final x10.core.fun.Fun_0_1<x10.core.Long,x10.core.Long> t, __0$1x10$lang$Long$3x10$lang$Long$2 $dummy) {
             {
                this.t = ((x10.core.fun.Fun_0_1)(t));
            }
        }
        
    }
    
    @x10.runtime.impl.java.X10Generated
    final public static class $Closure$257 extends x10.core.Ref implements x10.core.fun.Fun_0_1, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<$Closure$257> $RTT = 
            x10.rtt.StaticFunType.<$Closure$257> make($Closure$257.class,
                                                      new x10.rtt.Type[] {
                                                          x10.rtt.ParameterizedType.make(x10.core.fun.Fun_0_1.$RTT, x10.rtt.Types.LONG, x10.rtt.Types.LONG)
                                                      });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static x10.serialization.X10JavaSerializable $_deserialize_body(x10.regionarray.PolyRegion.$Closure$257 $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            $_obj.t = $deserializer.readObject();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.regionarray.PolyRegion.$Closure$257 $_obj = new x10.regionarray.PolyRegion.$Closure$257((java.lang.System[]) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            $serializer.write(this.t);
            
        }
        
        // constructor just for allocation
        public $Closure$257(final java.lang.System[] $dummy) {
            
        }
        
        // dispatcher for method abstract public (Z1)=>U.operator()(a1:Z1):U
        public java.lang.Object $apply(final java.lang.Object a1, final x10.rtt.Type t1) {
            return x10.core.Long.$box($apply$O(x10.core.Long.$unbox(a1)));
            
        }
        
        // dispatcher for method abstract public (Z1)=>U.operator()(a1:Z1):U
        public long $apply$J(final java.lang.Object a1, final x10.rtt.Type t1) {
            return $apply$O(x10.core.Long.$unbox(a1));
            
        }
        
        // synthetic type for parameter mangling
        public static final class __0$1x10$lang$Long$3x10$lang$Long$2 {}
        
    
        
        public long $apply$O(final long i) {
            
            //#line 317 "x10/regionarray/PolyRegion.x10"
            final int t$155434 = ((int)(long)(((long)(i))));
            
            //#line 317 "x10/regionarray/PolyRegion.x10"
            final long t$155435 = ((long)(((int)(t$155434))));
            
            //#line 317 "x10/regionarray/PolyRegion.x10"
            final long t$155436 = x10.core.Long.$unbox(((x10.core.fun.Fun_0_1<x10.core.Long,x10.core.Long>)this.t).$apply(x10.core.Long.$box(t$155435), x10.rtt.Types.LONG));
            
            //#line 317 "x10/regionarray/PolyRegion.x10"
            return t$155436;
        }
        
        public x10.core.fun.Fun_0_1<x10.core.Long,x10.core.Long> t;
        
        public $Closure$257(final x10.core.fun.Fun_0_1<x10.core.Long,x10.core.Long> t, __0$1x10$lang$Long$3x10$lang$Long$2 $dummy) {
             {
                this.t = ((x10.core.fun.Fun_0_1)(t));
            }
        }
        
    }
    
}


