package x10.regionarray;

/**
 * Implements periodic boundary conditions, in which elements at each edge
 * of a region are considered to be neighbours, and indices that fall
 * outside the locally-held region in any dimension are wrapped around modulo 
 * the size of the full region in that dimension.
 */
@x10.runtime.impl.java.X10Generated
final public class PeriodicBoundaryConditions extends x10.core.Ref implements x10.serialization.X10JavaSerializable
{
    public static final x10.rtt.RuntimeType<PeriodicBoundaryConditions> $RTT = 
        x10.rtt.NamedType.<PeriodicBoundaryConditions> make("x10.regionarray.PeriodicBoundaryConditions",
                                                            PeriodicBoundaryConditions.class);
    
    public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
    
    public x10.rtt.Type<?> $getParam(int i) { return null; }
    
    private Object writeReplace() throws java.io.ObjectStreamException {
        return new x10.serialization.SerializationProxy(this);
    }
    
    public static x10.serialization.X10JavaSerializable $_deserialize_body(x10.regionarray.PeriodicBoundaryConditions $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
        return $_obj;
    }
    
    public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
        x10.regionarray.PeriodicBoundaryConditions $_obj = new x10.regionarray.PeriodicBoundaryConditions((java.lang.System[]) null);
        $deserializer.record_reference($_obj);
        return $_deserialize_body($_obj, $deserializer);
    }
    
    public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
        
    }
    
    // constructor just for allocation
    public PeriodicBoundaryConditions(final java.lang.System[] $dummy) {
        
    }
    
    

    
    
    //#line 33 "x10/regionarray/PeriodicBoundaryConditions.x10"
    /**
     * Wrap the given index if it falls outside of [min,max], by adding
     * or subtracting multiples of <code>wrap</code>.
     * @param index the given index into a single dimension of a region
     * @param min the minimum index of the region in the given dimension
     * @param max the maximum index of the region in the given dimension
     * @param wrap the offset to add or subtract from the index when wrapping.
     *   For a region that is entirely held at a single place, wrap==(max-min+1).
     *   For the case of a block distribution over the given dimension,
     *   wrap==(fullRegion.max(dim)-fullRegion.min(dim)+1).
     */
    public static long getPeriodicIndex$O(final long index, final long min, final long max, final long wrap) {
        
        //#line 34 "x10/regionarray/PeriodicBoundaryConditions.x10"
        long actualIndex = index;
        
        //#line 35 "x10/regionarray/PeriodicBoundaryConditions.x10"
        while (true) {
            
            //#line 35 "x10/regionarray/PeriodicBoundaryConditions.x10"
            final boolean t$152336 = ((actualIndex) < (((long)(min))));
            
            //#line 35 "x10/regionarray/PeriodicBoundaryConditions.x10"
            if (!(t$152336)) {
                
                //#line 35 "x10/regionarray/PeriodicBoundaryConditions.x10"
                break;
            }
            
            //#line 35 "x10/regionarray/PeriodicBoundaryConditions.x10"
            final long t$152365 = ((actualIndex) + (((long)(wrap))));
            
            //#line 35 "x10/regionarray/PeriodicBoundaryConditions.x10"
            actualIndex = t$152365;
        }
        
        //#line 36 "x10/regionarray/PeriodicBoundaryConditions.x10"
        while (true) {
            
            //#line 36 "x10/regionarray/PeriodicBoundaryConditions.x10"
            final boolean t$152340 = ((actualIndex) > (((long)(max))));
            
            //#line 36 "x10/regionarray/PeriodicBoundaryConditions.x10"
            if (!(t$152340)) {
                
                //#line 36 "x10/regionarray/PeriodicBoundaryConditions.x10"
                break;
            }
            
            //#line 36 "x10/regionarray/PeriodicBoundaryConditions.x10"
            final long t$152367 = ((actualIndex) - (((long)(wrap))));
            
            //#line 36 "x10/regionarray/PeriodicBoundaryConditions.x10"
            actualIndex = t$152367;
        }
        
        //#line 37 "x10/regionarray/PeriodicBoundaryConditions.x10"
        return actualIndex;
    }
    
    
    //#line 50 "x10/regionarray/PeriodicBoundaryConditions.x10"
    /**
     * If <code>pt</code> falls outside of <code>localRegion</code>, wrap
     * the indices by adding or subtracting multiples of the size of
     * <code>fullRegion</code> in each dimension.
     * For example,
     * getPeriodic(Point([-2,2]),
     *             Region.makeRectangular(1..4, 0..7),
     *             Region.makeRectangular(1..8, 0..7))
     * returns: Point(6,2).
     */
    public static x10.lang.Point wrapPeriodic(final x10.lang.Point pt, final x10.regionarray.Region localRegion, final x10.regionarray.Region fullRegion) {
        
        //#line 53 "x10/regionarray/PeriodicBoundaryConditions.x10"
        final long t$152350 = pt.rank;
        
        //#line 53 "x10/regionarray/PeriodicBoundaryConditions.x10"
        final x10.core.fun.Fun_0_1 t$152351 = ((x10.core.fun.Fun_0_1)(new x10.regionarray.PeriodicBoundaryConditions.$Closure$246(pt, localRegion, fullRegion)));
        
        //#line 53 "x10/regionarray/PeriodicBoundaryConditions.x10"
        final x10.lang.Point t$152352 = ((x10.lang.Point)(x10.lang.Point.make__1$1x10$lang$Long$3x10$lang$Long$2((long)(t$152350), ((x10.core.fun.Fun_0_1)(t$152351)))));
        
        //#line 53 "x10/regionarray/PeriodicBoundaryConditions.x10"
        return t$152352;
    }
    
    
    //#line 66 "x10/regionarray/PeriodicBoundaryConditions.x10"
    /**
     * If <code>pt</code> falls outside of <code>region</code>, wrap
     * the indices by adding or subtracting multiples of the size of
     * <code>region</code> in each dimension.
     * For example,
     * getPeriodic(Point([-2,2]),
     *             Region.makeRectangular(1..4, 0..7))
     * returns: Point(2,2).
     */
    public static x10.lang.Point wrapPeriodic(final x10.lang.Point pt, final x10.regionarray.Region region) {
        
        //#line 67 "x10/regionarray/PeriodicBoundaryConditions.x10"
        final long t$152361 = pt.rank;
        
        //#line 67 "x10/regionarray/PeriodicBoundaryConditions.x10"
        final x10.core.fun.Fun_0_1 t$152362 = ((x10.core.fun.Fun_0_1)(new x10.regionarray.PeriodicBoundaryConditions.$Closure$247(pt, region)));
        
        //#line 67 "x10/regionarray/PeriodicBoundaryConditions.x10"
        final x10.lang.Point t$152363 = ((x10.lang.Point)(x10.lang.Point.make__1$1x10$lang$Long$3x10$lang$Long$2((long)(t$152361), ((x10.core.fun.Fun_0_1)(t$152362)))));
        
        //#line 67 "x10/regionarray/PeriodicBoundaryConditions.x10"
        return t$152363;
    }
    
    
    //#line 21 "x10/regionarray/PeriodicBoundaryConditions.x10"
    final public x10.regionarray.PeriodicBoundaryConditions x10$regionarray$PeriodicBoundaryConditions$$this$x10$regionarray$PeriodicBoundaryConditions() {
        
        //#line 21 "x10/regionarray/PeriodicBoundaryConditions.x10"
        return x10.regionarray.PeriodicBoundaryConditions.this;
    }
    
    
    //#line 21 "x10/regionarray/PeriodicBoundaryConditions.x10"
    // creation method for java code (1-phase java constructor)
    public PeriodicBoundaryConditions() {
        this((java.lang.System[]) null);
        x10$regionarray$PeriodicBoundaryConditions$$init$S();
    }
    
    // constructor for non-virtual call
    final public x10.regionarray.PeriodicBoundaryConditions x10$regionarray$PeriodicBoundaryConditions$$init$S() {
         {
            
            //#line 21 "x10/regionarray/PeriodicBoundaryConditions.x10"
            
        }
        return this;
    }
    
    
    
    //#line 21 "x10/regionarray/PeriodicBoundaryConditions.x10"
    final public void __fieldInitializers_x10_regionarray_PeriodicBoundaryConditions() {
        
    }
    
    @x10.runtime.impl.java.X10Generated
    final public static class $Closure$246 extends x10.core.Ref implements x10.core.fun.Fun_0_1, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<$Closure$246> $RTT = 
            x10.rtt.StaticFunType.<$Closure$246> make($Closure$246.class,
                                                      new x10.rtt.Type[] {
                                                          x10.rtt.ParameterizedType.make(x10.core.fun.Fun_0_1.$RTT, x10.rtt.Types.LONG, x10.rtt.Types.LONG)
                                                      });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static x10.serialization.X10JavaSerializable $_deserialize_body(x10.regionarray.PeriodicBoundaryConditions.$Closure$246 $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            $_obj.fullRegion = $deserializer.readObject();
            $_obj.localRegion = $deserializer.readObject();
            $_obj.pt = $deserializer.readObject();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.regionarray.PeriodicBoundaryConditions.$Closure$246 $_obj = new x10.regionarray.PeriodicBoundaryConditions.$Closure$246((java.lang.System[]) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            $serializer.write(this.fullRegion);
            $serializer.write(this.localRegion);
            $serializer.write(this.pt);
            
        }
        
        // constructor just for allocation
        public $Closure$246(final java.lang.System[] $dummy) {
            
        }
        
        // dispatcher for method abstract public (Z1)=>U.operator()(a1:Z1):U
        public java.lang.Object $apply(final java.lang.Object a1, final x10.rtt.Type t1) {
            return x10.core.Long.$box($apply$O(x10.core.Long.$unbox(a1)));
            
        }
        
        // dispatcher for method abstract public (Z1)=>U.operator()(a1:Z1):U
        public long $apply$J(final java.lang.Object a1, final x10.rtt.Type t1) {
            return $apply$O(x10.core.Long.$unbox(a1));
            
        }
        
        
    
        
        public long $apply$O(final long i) {
            
            //#line 54 "x10/regionarray/PeriodicBoundaryConditions.x10"
            final long t$152345 = this.pt.$apply$O((long)(i));
            
            //#line 54 "x10/regionarray/PeriodicBoundaryConditions.x10"
            final long t$152346 = this.localRegion.min$O((long)(i));
            
            //#line 54 "x10/regionarray/PeriodicBoundaryConditions.x10"
            final long t$152347 = this.localRegion.max$O((long)(i));
            
            //#line 54 "x10/regionarray/PeriodicBoundaryConditions.x10"
            final long t$152342 = this.fullRegion.max$O((long)(i));
            
            //#line 54 "x10/regionarray/PeriodicBoundaryConditions.x10"
            final long t$152343 = this.fullRegion.min$O((long)(i));
            
            //#line 54 "x10/regionarray/PeriodicBoundaryConditions.x10"
            final long t$152344 = ((t$152342) - (((long)(t$152343))));
            
            //#line 54 "x10/regionarray/PeriodicBoundaryConditions.x10"
            final long t$152348 = ((t$152344) + (((long)(1L))));
            
            //#line 54 "x10/regionarray/PeriodicBoundaryConditions.x10"
            final long t$152349 = x10.regionarray.PeriodicBoundaryConditions.getPeriodicIndex$O((long)(t$152345), (long)(t$152346), (long)(t$152347), (long)(t$152348));
            
            //#line 54 "x10/regionarray/PeriodicBoundaryConditions.x10"
            return t$152349;
        }
        
        public x10.lang.Point pt;
        public x10.regionarray.Region localRegion;
        public x10.regionarray.Region fullRegion;
        
        public $Closure$246(final x10.lang.Point pt, final x10.regionarray.Region localRegion, final x10.regionarray.Region fullRegion) {
             {
                this.pt = ((x10.lang.Point)(pt));
                this.localRegion = ((x10.regionarray.Region)(localRegion));
                this.fullRegion = ((x10.regionarray.Region)(fullRegion));
            }
        }
        
    }
    
    @x10.runtime.impl.java.X10Generated
    final public static class $Closure$247 extends x10.core.Ref implements x10.core.fun.Fun_0_1, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<$Closure$247> $RTT = 
            x10.rtt.StaticFunType.<$Closure$247> make($Closure$247.class,
                                                      new x10.rtt.Type[] {
                                                          x10.rtt.ParameterizedType.make(x10.core.fun.Fun_0_1.$RTT, x10.rtt.Types.LONG, x10.rtt.Types.LONG)
                                                      });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static x10.serialization.X10JavaSerializable $_deserialize_body(x10.regionarray.PeriodicBoundaryConditions.$Closure$247 $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            $_obj.pt = $deserializer.readObject();
            $_obj.region = $deserializer.readObject();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.regionarray.PeriodicBoundaryConditions.$Closure$247 $_obj = new x10.regionarray.PeriodicBoundaryConditions.$Closure$247((java.lang.System[]) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            $serializer.write(this.pt);
            $serializer.write(this.region);
            
        }
        
        // constructor just for allocation
        public $Closure$247(final java.lang.System[] $dummy) {
            
        }
        
        // dispatcher for method abstract public (Z1)=>U.operator()(a1:Z1):U
        public java.lang.Object $apply(final java.lang.Object a1, final x10.rtt.Type t1) {
            return x10.core.Long.$box($apply$O(x10.core.Long.$unbox(a1)));
            
        }
        
        // dispatcher for method abstract public (Z1)=>U.operator()(a1:Z1):U
        public long $apply$J(final java.lang.Object a1, final x10.rtt.Type t1) {
            return $apply$O(x10.core.Long.$unbox(a1));
            
        }
        
        
    
        
        public long $apply$O(final long i) {
            
            //#line 68 "x10/regionarray/PeriodicBoundaryConditions.x10"
            final long t$152356 = this.pt.$apply$O((long)(i));
            
            //#line 68 "x10/regionarray/PeriodicBoundaryConditions.x10"
            final long t$152357 = this.region.min$O((long)(i));
            
            //#line 68 "x10/regionarray/PeriodicBoundaryConditions.x10"
            final long t$152358 = this.region.max$O((long)(i));
            
            //#line 68 "x10/regionarray/PeriodicBoundaryConditions.x10"
            final long t$152353 = this.region.max$O((long)(i));
            
            //#line 68 "x10/regionarray/PeriodicBoundaryConditions.x10"
            final long t$152354 = this.region.min$O((long)(i));
            
            //#line 68 "x10/regionarray/PeriodicBoundaryConditions.x10"
            final long t$152355 = ((t$152353) - (((long)(t$152354))));
            
            //#line 68 "x10/regionarray/PeriodicBoundaryConditions.x10"
            final long t$152359 = ((t$152355) + (((long)(1L))));
            
            //#line 68 "x10/regionarray/PeriodicBoundaryConditions.x10"
            final long t$152360 = x10.regionarray.PeriodicBoundaryConditions.getPeriodicIndex$O((long)(t$152356), (long)(t$152357), (long)(t$152358), (long)(t$152359));
            
            //#line 68 "x10/regionarray/PeriodicBoundaryConditions.x10"
            return t$152360;
        }
        
        public x10.lang.Point pt;
        public x10.regionarray.Region region;
        
        public $Closure$247(final x10.lang.Point pt, final x10.regionarray.Region region) {
             {
                this.pt = ((x10.lang.Point)(pt));
                this.region = ((x10.regionarray.Region)(region));
            }
        }
        
    }
    
}

