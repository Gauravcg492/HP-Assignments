package x10.regionarray;


/**
 * A RectRegion1D is a finite dense rectangular region of rank 1.
 * This is a space-optimized implementation of the more general
 * RectRegion class intended primarily to reduce the memory
 * overhead and serialization cost of Array meta-data.
 */
@x10.runtime.impl.java.X10Generated
final public class RectRegion1D extends x10.regionarray.Region implements x10.serialization.X10JavaSerializable
{
    public static final x10.rtt.RuntimeType<RectRegion1D> $RTT = 
        x10.rtt.NamedType.<RectRegion1D> make("x10.regionarray.RectRegion1D",
                                              RectRegion1D.class,
                                              new x10.rtt.Type[] {
                                                  x10.regionarray.Region.$RTT
                                              });
    
    public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
    
    public x10.rtt.Type<?> $getParam(int i) { return null; }
    
    private Object writeReplace() throws java.io.ObjectStreamException {
        return new x10.serialization.SerializationProxy(this);
    }
    
    public static x10.serialization.X10JavaSerializable $_deserialize_body(x10.regionarray.RectRegion1D $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
        x10.regionarray.Region.$_deserialize_body($_obj, $deserializer);
        $_obj.max = $deserializer.readLong();
        $_obj.min = $deserializer.readLong();
        $_obj.size = $deserializer.readLong();
        return $_obj;
    }
    
    public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
        x10.regionarray.RectRegion1D $_obj = new x10.regionarray.RectRegion1D((java.lang.System[]) null);
        $deserializer.record_reference($_obj);
        return $_deserialize_body($_obj, $deserializer);
    }
    
    public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
        super.$_serialize($serializer);
        $serializer.write(this.max);
        $serializer.write(this.min);
        $serializer.write(this.size);
        
    }
    
    // constructor just for allocation
    public RectRegion1D(final java.lang.System[] $dummy) {
        super($dummy);
        
    }
    
    

    
    //#line 23 "x10/regionarray/RectRegion1D.x10"
    public long size;
    
    //#line 24 "x10/regionarray/RectRegion1D.x10"
    public long min;
    
    //#line 25 "x10/regionarray/RectRegion1D.x10"
    public long max;
    
    
    //#line 30 "x10/regionarray/RectRegion1D.x10"
    /**
     * Create a 1-dim region min..max.
     */
    // creation method for java code (1-phase java constructor)
    public RectRegion1D(final long minArg, final long maxArg) {
        this((java.lang.System[]) null);
        x10$regionarray$RectRegion1D$$init$S(minArg, maxArg);
    }
    
    // constructor for non-virtual call
    final public x10.regionarray.RectRegion1D x10$regionarray$RectRegion1D$$init$S(final long minArg, final long maxArg) {
         {
            
            //#line 31 "x10/regionarray/RectRegion1D.x10"
            final x10.regionarray.Region this$158183 = ((x10.regionarray.Region)(this));
            
            //#line 31 "x10/regionarray/RectRegion1D.x10"
            final boolean z$158181 = ((long) minArg) == ((long) 0L);
            
            //#line 558 . "x10/regionarray/Region.x10"
            this$158183.rank = 1L;
            
            //#line 558 . "x10/regionarray/Region.x10"
            this$158183.rect = true;
            
            //#line 558 . "x10/regionarray/Region.x10"
            this$158183.zeroBased = z$158181;
            
            //#line 558 . "x10/regionarray/Region.x10"
            this$158183.rail = z$158181;
            
            //#line 30 "x10/regionarray/RectRegion1D.x10"
            
            
            //#line 34 "x10/regionarray/RectRegion1D.x10"
            final long t$158218 = ((maxArg) - (((long)(minArg))));
            
            //#line 34 "x10/regionarray/RectRegion1D.x10"
            final long s = ((t$158218) + (((long)(1L))));
            
            //#line 35 "x10/regionarray/RectRegion1D.x10"
            final long t$158219 = java.lang.Long.MIN_VALUE;
            
            //#line 35 "x10/regionarray/RectRegion1D.x10"
            boolean t$158221 = ((long) minArg) == ((long) t$158219);
            
            //#line 35 "x10/regionarray/RectRegion1D.x10"
            if (t$158221) {
                
                //#line 35 "x10/regionarray/RectRegion1D.x10"
                final long t$158220 = java.lang.Long.MAX_VALUE;
                
                //#line 35 "x10/regionarray/RectRegion1D.x10"
                t$158221 = ((long) maxArg) == ((long) t$158220);
            }
            
            //#line 35 "x10/regionarray/RectRegion1D.x10"
            if (t$158221) {
                
                //#line 36 "x10/regionarray/RectRegion1D.x10"
                this.size = -1L;
            } else {
                
                //#line 38 "x10/regionarray/RectRegion1D.x10"
                final boolean t$158222 = ((s) > (((long)(0L))));
                
                //#line 38 "x10/regionarray/RectRegion1D.x10"
                long t$158223 =  0;
                
                //#line 38 "x10/regionarray/RectRegion1D.x10"
                if (t$158222) {
                    
                    //#line 38 "x10/regionarray/RectRegion1D.x10"
                    t$158223 = s;
                } else {
                    
                    //#line 38 "x10/regionarray/RectRegion1D.x10"
                    t$158223 = 0L;
                }
                
                //#line 38 "x10/regionarray/RectRegion1D.x10"
                this.size = t$158223;
            }
            
            //#line 40 "x10/regionarray/RectRegion1D.x10"
            this.min = minArg;
            
            //#line 41 "x10/regionarray/RectRegion1D.x10"
            this.max = maxArg;
        }
        return this;
    }
    
    
    
    //#line 50 "x10/regionarray/RectRegion1D.x10"
    /**
     * Create a 1-dim region 0..max.
     * Separate constructor so the constraint solver can correctly determine
     * statically that the zeroBased and rail properties are true for all regions
     * made via this constructor.
     */
    // creation method for java code (1-phase java constructor)
    public RectRegion1D(final long maxArg) {
        this((java.lang.System[]) null);
        x10$regionarray$RectRegion1D$$init$S(maxArg);
    }
    
    // constructor for non-virtual call
    final public x10.regionarray.RectRegion1D x10$regionarray$RectRegion1D$$init$S(final long maxArg) {
         {
            
            //#line 51 "x10/regionarray/RectRegion1D.x10"
            final x10.regionarray.Region this$158189 = ((x10.regionarray.Region)(this));
            
            //#line 51 "x10/regionarray/RectRegion1D.x10"
            final long t$158226 = ((long)(((int)(1))));
            
            //#line 51 "x10/regionarray/RectRegion1D.x10"
            final long t$139037 = t$158226;
            
            //#line 51 "x10/regionarray/RectRegion1D.x10"
            final boolean t$158227 = ((long) t$139037) == ((long) 1L);
            
            //#line 51 "x10/regionarray/RectRegion1D.x10"
            final boolean t$158229 = !(t$158227);
            
            //#line 51 "x10/regionarray/RectRegion1D.x10"
            if (t$158229) {
                
                //#line 51 "x10/regionarray/RectRegion1D.x10"
                final x10.lang.FailedDynamicCheckException t$158228 = new x10.lang.FailedDynamicCheckException("x10.lang.Long{self==1L}");
                
                //#line 51 "x10/regionarray/RectRegion1D.x10"
                throw t$158228;
            }
            
            //#line 566 . "x10/regionarray/Region.x10"
            this$158189.rank = t$139037;
            
            //#line 566 . "x10/regionarray/Region.x10"
            this$158189.rect = true;
            
            //#line 566 . "x10/regionarray/Region.x10"
            this$158189.zeroBased = true;
            
            //#line 566 . "x10/regionarray/Region.x10"
            this$158189.rail = true;
            
            //#line 50 "x10/regionarray/RectRegion1D.x10"
            
            
            //#line 53 "x10/regionarray/RectRegion1D.x10"
            final long t$158230 = ((maxArg) + (((long)(1L))));
            
            //#line 53 "x10/regionarray/RectRegion1D.x10"
            this.size = t$158230;
            
            //#line 54 "x10/regionarray/RectRegion1D.x10"
            this.min = 0L;
            
            //#line 55 "x10/regionarray/RectRegion1D.x10"
            this.max = maxArg;
        }
        return this;
    }
    
    
    
    //#line 58 "x10/regionarray/RectRegion1D.x10"
    public long size$O() {
        
        //#line 59 "x10/regionarray/RectRegion1D.x10"
        final long t$158231 = this.size;
        
        //#line 59 "x10/regionarray/RectRegion1D.x10"
        final boolean t$158233 = ((t$158231) < (((long)(0L))));
        
        //#line 59 "x10/regionarray/RectRegion1D.x10"
        if (t$158233) {
            
            //#line 59 "x10/regionarray/RectRegion1D.x10"
            final x10.regionarray.UnboundedRegionException t$158232 = ((x10.regionarray.UnboundedRegionException)(new x10.regionarray.UnboundedRegionException(((java.lang.String)("size exceeds capacity of long")))));
            
            //#line 59 "x10/regionarray/RectRegion1D.x10"
            throw t$158232;
        }
        
        //#line 60 "x10/regionarray/RectRegion1D.x10"
        final long t$158234 = this.size;
        
        //#line 60 "x10/regionarray/RectRegion1D.x10"
        return t$158234;
    }
    
    
    //#line 63 "x10/regionarray/RectRegion1D.x10"
    public boolean isConvex$O() {
        
        //#line 63 "x10/regionarray/RectRegion1D.x10"
        return true;
    }
    
    
    //#line 65 "x10/regionarray/RectRegion1D.x10"
    public boolean isEmpty$O() {
        
        //#line 65 "x10/regionarray/RectRegion1D.x10"
        final long t$158235 = this.size;
        
        //#line 65 "x10/regionarray/RectRegion1D.x10"
        final boolean t$158236 = ((long) t$158235) == ((long) 0L);
        
        //#line 65 "x10/regionarray/RectRegion1D.x10"
        return t$158236;
    }
    
    
    //#line 67 "x10/regionarray/RectRegion1D.x10"
    public long indexOf$O(final x10.lang.Point pt) {
        
        //#line 68 "x10/regionarray/RectRegion1D.x10"
        final boolean t$158237 = this.contains$O(((x10.lang.Point)(pt)));
        
        //#line 68 "x10/regionarray/RectRegion1D.x10"
        final boolean t$158238 = !(t$158237);
        
        //#line 68 "x10/regionarray/RectRegion1D.x10"
        if (t$158238) {
            
            //#line 68 "x10/regionarray/RectRegion1D.x10"
            return -1L;
        }
        
        //#line 69 "x10/regionarray/RectRegion1D.x10"
        final long t$158239 = pt.$apply$O((long)(0L));
        
        //#line 69 "x10/regionarray/RectRegion1D.x10"
        final long t$158240 = this.min;
        
        //#line 69 "x10/regionarray/RectRegion1D.x10"
        final long t$158241 = ((t$158239) - (((long)(t$158240))));
        
        //#line 69 "x10/regionarray/RectRegion1D.x10"
        return t$158241;
    }
    
    
    //#line 72 "x10/regionarray/RectRegion1D.x10"
    public long indexOf$O(final long i0) {
        
        //#line 73 "x10/regionarray/RectRegion1D.x10"
        final boolean t$158254 = this.zeroBased;
        
        //#line 73 "x10/regionarray/RectRegion1D.x10"
        if (t$158254) {
            
            //#line 74 "x10/regionarray/RectRegion1D.x10"
            final x10.regionarray.RectRegion1D this$158195 = ((x10.regionarray.RectRegion1D)(this));
            
            //#line 122 . "x10/regionarray/RectRegion1D.x10"
            final long t$158242 = this$158195.min;
            
            //#line 122 . "x10/regionarray/RectRegion1D.x10"
            boolean t$158244 = ((i0) >= (((long)(t$158242))));
            
            //#line 122 . "x10/regionarray/RectRegion1D.x10"
            if (t$158244) {
                
                //#line 122 . "x10/regionarray/RectRegion1D.x10"
                final long t$158243 = this$158195.max;
                
                //#line 122 . "x10/regionarray/RectRegion1D.x10"
                t$158244 = ((i0) <= (((long)(t$158243))));
            }
            
            //#line 74 "x10/regionarray/RectRegion1D.x10"
            final boolean t$158246 = !(t$158244);
            
            //#line 74 "x10/regionarray/RectRegion1D.x10"
            if (t$158246) {
                
                //#line 74 "x10/regionarray/RectRegion1D.x10"
                return -1L;
            }
            
            //#line 75 "x10/regionarray/RectRegion1D.x10"
            return i0;
        } else {
            
            //#line 77 "x10/regionarray/RectRegion1D.x10"
            final x10.regionarray.RectRegion1D this$158198 = ((x10.regionarray.RectRegion1D)(this));
            
            //#line 122 . "x10/regionarray/RectRegion1D.x10"
            final long t$158247 = this$158198.min;
            
            //#line 122 . "x10/regionarray/RectRegion1D.x10"
            boolean t$158249 = ((i0) >= (((long)(t$158247))));
            
            //#line 122 . "x10/regionarray/RectRegion1D.x10"
            if (t$158249) {
                
                //#line 122 . "x10/regionarray/RectRegion1D.x10"
                final long t$158248 = this$158198.max;
                
                //#line 122 . "x10/regionarray/RectRegion1D.x10"
                t$158249 = ((i0) <= (((long)(t$158248))));
            }
            
            //#line 77 "x10/regionarray/RectRegion1D.x10"
            final boolean t$158251 = !(t$158249);
            
            //#line 77 "x10/regionarray/RectRegion1D.x10"
            if (t$158251) {
                
                //#line 77 "x10/regionarray/RectRegion1D.x10"
                return -1L;
            }
            
            //#line 78 "x10/regionarray/RectRegion1D.x10"
            final long t$158252 = this.min;
            
            //#line 78 "x10/regionarray/RectRegion1D.x10"
            final long t$158253 = ((i0) - (((long)(t$158252))));
            
            //#line 78 "x10/regionarray/RectRegion1D.x10"
            return t$158253;
        }
    }
    
    
    //#line 82 "x10/regionarray/RectRegion1D.x10"
    public long indexOf$O(final long i0, final long i1) {
        
        //#line 82 "x10/regionarray/RectRegion1D.x10"
        return -1L;
    }
    
    
    //#line 84 "x10/regionarray/RectRegion1D.x10"
    public long indexOf$O(final long i0, final long i1, final long i2) {
        
        //#line 84 "x10/regionarray/RectRegion1D.x10"
        return -1L;
    }
    
    
    //#line 86 "x10/regionarray/RectRegion1D.x10"
    public long indexOf$O(final long i0, final long i1, final long i2, final long i3) {
        
        //#line 86 "x10/regionarray/RectRegion1D.x10"
        return -1L;
    }
    
    
    //#line 89 "x10/regionarray/RectRegion1D.x10"
    public long min$O(final long i) {
        
        //#line 90 "x10/regionarray/RectRegion1D.x10"
        final boolean t$158259 = ((long) i) != ((long) 0L);
        
        //#line 90 "x10/regionarray/RectRegion1D.x10"
        if (t$158259) {
            
            //#line 90 "x10/regionarray/RectRegion1D.x10"
            final java.lang.String t$158255 = (("min: ") + ((x10.core.Long.$box(i))));
            
            //#line 90 "x10/regionarray/RectRegion1D.x10"
            final java.lang.String t$158256 = ((t$158255) + (" is not a valid rank for "));
            
            //#line 90 "x10/regionarray/RectRegion1D.x10"
            final java.lang.String t$158257 = ((t$158256) + (this));
            
            //#line 90 "x10/regionarray/RectRegion1D.x10"
            final java.lang.ArrayIndexOutOfBoundsException t$158258 = ((java.lang.ArrayIndexOutOfBoundsException)(new java.lang.ArrayIndexOutOfBoundsException(t$158257)));
            
            //#line 90 "x10/regionarray/RectRegion1D.x10"
            throw t$158258;
        }
        
        //#line 91 "x10/regionarray/RectRegion1D.x10"
        final long t$158260 = this.min;
        
        //#line 91 "x10/regionarray/RectRegion1D.x10"
        return t$158260;
    }
    
    
    //#line 94 "x10/regionarray/RectRegion1D.x10"
    public long max$O(final long i) {
        
        //#line 95 "x10/regionarray/RectRegion1D.x10"
        final boolean t$158265 = ((long) i) != ((long) 0L);
        
        //#line 95 "x10/regionarray/RectRegion1D.x10"
        if (t$158265) {
            
            //#line 95 "x10/regionarray/RectRegion1D.x10"
            final java.lang.String t$158261 = (("max: ") + ((x10.core.Long.$box(i))));
            
            //#line 95 "x10/regionarray/RectRegion1D.x10"
            final java.lang.String t$158262 = ((t$158261) + (" is not a valid rank for "));
            
            //#line 95 "x10/regionarray/RectRegion1D.x10"
            final java.lang.String t$158263 = ((t$158262) + (this));
            
            //#line 95 "x10/regionarray/RectRegion1D.x10"
            final java.lang.ArrayIndexOutOfBoundsException t$158264 = ((java.lang.ArrayIndexOutOfBoundsException)(new java.lang.ArrayIndexOutOfBoundsException(t$158263)));
            
            //#line 95 "x10/regionarray/RectRegion1D.x10"
            throw t$158264;
        }
        
        //#line 96 "x10/regionarray/RectRegion1D.x10"
        final long t$158266 = this.max;
        
        //#line 96 "x10/regionarray/RectRegion1D.x10"
        return t$158266;
    }
    
    
    //#line 104 "x10/regionarray/RectRegion1D.x10"
    public x10.regionarray.Region computeBoundingBox() {
        
        //#line 104 "x10/regionarray/RectRegion1D.x10"
        return this;
    }
    
    
    //#line 106 "x10/regionarray/RectRegion1D.x10"
    public x10.regionarray.RectRegion toRectRegion() {
        
        //#line 106 "x10/regionarray/RectRegion1D.x10"
        final x10.regionarray.RectRegion alloc$139364 = ((x10.regionarray.RectRegion)(new x10.regionarray.RectRegion((java.lang.System[]) null)));
        
        //#line 106 "x10/regionarray/RectRegion1D.x10"
        final long min$158200 = this.min;
        
        //#line 106 "x10/regionarray/RectRegion1D.x10"
        final long max$158201 = this.max;
        
        //#line 105 . "x10/regionarray/RectRegion.x10"
        final boolean z$158332 = ((long) min$158200) == ((long) 0L);
        
        //#line 558 .. "x10/regionarray/Region.x10"
        alloc$139364.rank = 1L;
        
        //#line 558 .. "x10/regionarray/Region.x10"
        alloc$139364.rect = true;
        
        //#line 558 .. "x10/regionarray/Region.x10"
        alloc$139364.zeroBased = z$158332;
        
        //#line 558 .. "x10/regionarray/Region.x10"
        alloc$139364.rail = z$158332;
        
        //#line 21 .. "x10/regionarray/RectRegion.x10"
        alloc$139364.polyRep = null;
        
        //#line 107 . "x10/regionarray/RectRegion.x10"
        final long t$158333 = java.lang.Long.MIN_VALUE;
        
        //#line 107 . "x10/regionarray/RectRegion.x10"
        boolean t$158334 = ((long) min$158200) == ((long) t$158333);
        
        //#line 107 . "x10/regionarray/RectRegion.x10"
        if (t$158334) {
            
            //#line 107 . "x10/regionarray/RectRegion.x10"
            final long t$158335 = java.lang.Long.MAX_VALUE;
            
            //#line 107 . "x10/regionarray/RectRegion.x10"
            t$158334 = ((long) max$158201) == ((long) t$158335);
        }
        
        //#line 107 . "x10/regionarray/RectRegion.x10"
        long t$158337 =  0;
        
        //#line 107 . "x10/regionarray/RectRegion.x10"
        if (t$158334) {
            
            //#line 107 . "x10/regionarray/RectRegion.x10"
            t$158337 = -1L;
        } else {
            
            //#line 107 . "x10/regionarray/RectRegion.x10"
            final long t$158338 = ((max$158201) - (((long)(min$158200))));
            
            //#line 107 . "x10/regionarray/RectRegion.x10"
            t$158337 = ((t$158338) + (((long)(1L))));
        }
        
        //#line 107 . "x10/regionarray/RectRegion.x10"
        alloc$139364.size = t$158337;
        
        //#line 108 . "x10/regionarray/RectRegion.x10"
        alloc$139364.min0 = min$158200;
        
        //#line 109 . "x10/regionarray/RectRegion.x10"
        alloc$139364.max0 = max$158201;
        
        //#line 111 . "x10/regionarray/RectRegion.x10"
        final long t$158340 = alloc$139364.min3 = 0L;
        
        //#line 111 . "x10/regionarray/RectRegion.x10"
        final long t$158341 = alloc$139364.min2 = t$158340;
        
        //#line 111 . "x10/regionarray/RectRegion.x10"
        alloc$139364.min1 = t$158341;
        
        //#line 112 . "x10/regionarray/RectRegion.x10"
        final long t$158342 = alloc$139364.max3 = 0L;
        
        //#line 112 . "x10/regionarray/RectRegion.x10"
        final long t$158343 = alloc$139364.max2 = t$158342;
        
        //#line 112 . "x10/regionarray/RectRegion.x10"
        alloc$139364.max1 = t$158343;
        
        //#line 113 . "x10/regionarray/RectRegion.x10"
        alloc$139364.mins = null;
        
        //#line 114 . "x10/regionarray/RectRegion.x10"
        alloc$139364.maxs = null;
        
        //#line 106 "x10/regionarray/RectRegion1D.x10"
        return alloc$139364;
    }
    
    
    //#line 108 "x10/regionarray/RectRegion1D.x10"
    public x10.core.fun.Fun_0_1 min() {
        
        //#line 108 "x10/regionarray/RectRegion1D.x10"
        final x10.core.fun.Fun_0_1 t$158279 = ((x10.core.fun.Fun_0_1)(new x10.regionarray.RectRegion1D.$Closure$292(this)));
        
        //#line 108 "x10/regionarray/RectRegion1D.x10"
        return t$158279;
    }
    
    
    //#line 109 "x10/regionarray/RectRegion1D.x10"
    public x10.core.fun.Fun_0_1 max() {
        
        //#line 109 "x10/regionarray/RectRegion1D.x10"
        final x10.core.fun.Fun_0_1 t$158281 = ((x10.core.fun.Fun_0_1)(new x10.regionarray.RectRegion1D.$Closure$293(this)));
        
        //#line 109 "x10/regionarray/RectRegion1D.x10"
        return t$158281;
    }
    
    
    //#line 111 "x10/regionarray/RectRegion1D.x10"
    public boolean contains$O(final x10.regionarray.Region that) {
        
        //#line 112 "x10/regionarray/RectRegion1D.x10"
        final x10.regionarray.RectRegion t$158282 = ((x10.regionarray.RectRegion)(this.toRectRegion()));
        
        //#line 112 "x10/regionarray/RectRegion1D.x10"
        final boolean t$158283 = t$158282.contains$O(((x10.regionarray.Region)(that)));
        
        //#line 112 "x10/regionarray/RectRegion1D.x10"
        return t$158283;
    }
    
    
    //#line 115 "x10/regionarray/RectRegion1D.x10"
    public boolean contains$O(final x10.lang.Point p) {
        
        //#line 116 "x10/regionarray/RectRegion1D.x10"
        final x10.regionarray.RectRegion t$158284 = ((x10.regionarray.RectRegion)(this.toRectRegion()));
        
        //#line 116 "x10/regionarray/RectRegion1D.x10"
        final boolean t$158285 = t$158284.contains$O(((x10.lang.Point)(p)));
        
        //#line 116 "x10/regionarray/RectRegion1D.x10"
        return t$158285;
    }
    
    
    //#line 119 "x10/regionarray/RectRegion1D.x10"
    public boolean contains$O(final long i0) {
        
        //#line 119 "x10/regionarray/RectRegion1D.x10"
        final x10.regionarray.RectRegion1D this$158211 = ((x10.regionarray.RectRegion1D)(this));
        
        //#line 122 . "x10/regionarray/RectRegion1D.x10"
        final long t$158286 = this$158211.min;
        
        //#line 122 . "x10/regionarray/RectRegion1D.x10"
        boolean t$158288 = ((i0) >= (((long)(t$158286))));
        
        //#line 122 . "x10/regionarray/RectRegion1D.x10"
        if (t$158288) {
            
            //#line 122 . "x10/regionarray/RectRegion1D.x10"
            final long t$158287 = this$158211.max;
            
            //#line 122 . "x10/regionarray/RectRegion1D.x10"
            t$158288 = ((i0) <= (((long)(t$158287))));
        }
        
        //#line 119 "x10/regionarray/RectRegion1D.x10"
        return t$158288;
    }
    
    
    //#line 121 "x10/regionarray/RectRegion1D.x10"
    private boolean containsInternal$O(final long i0) {
        
        //#line 122 "x10/regionarray/RectRegion1D.x10"
        final long t$158290 = this.min;
        
        //#line 122 "x10/regionarray/RectRegion1D.x10"
        boolean t$158292 = ((i0) >= (((long)(t$158290))));
        
        //#line 122 "x10/regionarray/RectRegion1D.x10"
        if (t$158292) {
            
            //#line 122 "x10/regionarray/RectRegion1D.x10"
            final long t$158291 = this.max;
            
            //#line 122 "x10/regionarray/RectRegion1D.x10"
            t$158292 = ((i0) <= (((long)(t$158291))));
        }
        
        //#line 122 "x10/regionarray/RectRegion1D.x10"
        return t$158292;
    }
    
    public static boolean containsInternal$P$O(final long i0, final x10.regionarray.RectRegion1D RectRegion1D) {
        return RectRegion1D.containsInternal$O((long)(i0));
    }
    
    
    //#line 125 "x10/regionarray/RectRegion1D.x10"
    public x10.regionarray.Region toPolyRegion() {
        
        //#line 126 "x10/regionarray/RectRegion1D.x10"
        final x10.regionarray.RectRegion t$158294 = ((x10.regionarray.RectRegion)(this.toRectRegion()));
        
        //#line 126 "x10/regionarray/RectRegion1D.x10"
        final x10.regionarray.Region t$158295 = ((x10.regionarray.Region)(t$158294.toPolyRegion()));
        
        //#line 126 "x10/regionarray/RectRegion1D.x10"
        return t$158295;
    }
    
    
    //#line 129 "x10/regionarray/RectRegion1D.x10"
    public x10.regionarray.Region intersection(final x10.regionarray.Region that) {
        
        //#line 130 "x10/regionarray/RectRegion1D.x10"
        final x10.regionarray.RectRegion t$158296 = ((x10.regionarray.RectRegion)(this.toRectRegion()));
        
        //#line 130 "x10/regionarray/RectRegion1D.x10"
        final x10.regionarray.Region t$158297 = ((x10.regionarray.Region)(t$158296.intersection(((x10.regionarray.Region)(that)))));
        
        //#line 130 "x10/regionarray/RectRegion1D.x10"
        return t$158297;
    }
    
    
    //#line 134 "x10/regionarray/RectRegion1D.x10"
    public x10.regionarray.Region product(final x10.regionarray.Region that) {
        
        //#line 135 "x10/regionarray/RectRegion1D.x10"
        final x10.regionarray.RectRegion t$158298 = ((x10.regionarray.RectRegion)(this.toRectRegion()));
        
        //#line 135 "x10/regionarray/RectRegion1D.x10"
        final x10.regionarray.Region t$158299 = ((x10.regionarray.Region)(t$158298.product(((x10.regionarray.Region)(that)))));
        
        //#line 135 "x10/regionarray/RectRegion1D.x10"
        return t$158299;
    }
    
    
    //#line 138 "x10/regionarray/RectRegion1D.x10"
    public x10.regionarray.Region translate(final x10.lang.Point v) {
        
        //#line 139 "x10/regionarray/RectRegion1D.x10"
        final x10.regionarray.RectRegion1D alloc$139365 = ((x10.regionarray.RectRegion1D)(new x10.regionarray.RectRegion1D((java.lang.System[]) null)));
        
        //#line 139 "x10/regionarray/RectRegion1D.x10"
        final long t$158344 = this.min;
        
        //#line 139 "x10/regionarray/RectRegion1D.x10"
        final long t$158345 = v.$apply$O((long)(0L));
        
        //#line 139 "x10/regionarray/RectRegion1D.x10"
        final long t$158346 = ((t$158344) + (((long)(t$158345))));
        
        //#line 139 "x10/regionarray/RectRegion1D.x10"
        final long t$158347 = this.max;
        
        //#line 139 "x10/regionarray/RectRegion1D.x10"
        final long t$158348 = v.$apply$O((long)(0L));
        
        //#line 139 "x10/regionarray/RectRegion1D.x10"
        final long t$158349 = ((t$158347) + (((long)(t$158348))));
        
        //#line 139 "x10/regionarray/RectRegion1D.x10"
        alloc$139365.x10$regionarray$RectRegion1D$$init$S(t$158346, t$158349);
        
        //#line 139 "x10/regionarray/RectRegion1D.x10"
        return alloc$139365;
    }
    
    
    //#line 142 "x10/regionarray/RectRegion1D.x10"
    public x10.regionarray.Region projection(final long axis) {
        
        //#line 143 "x10/regionarray/RectRegion1D.x10"
        final boolean t$158306 = ((long) axis) == ((long) 0L);
        
        //#line 143 "x10/regionarray/RectRegion1D.x10"
        if (t$158306) {
            
            //#line 143 "x10/regionarray/RectRegion1D.x10"
            return this;
        }
        
        //#line 144 "x10/regionarray/RectRegion1D.x10"
        final java.lang.String t$158307 = (("projection: ") + ((x10.core.Long.$box(axis))));
        
        //#line 144 "x10/regionarray/RectRegion1D.x10"
        final java.lang.String t$158308 = ((t$158307) + (" is not a valid rank for "));
        
        //#line 144 "x10/regionarray/RectRegion1D.x10"
        final java.lang.String t$158309 = ((t$158308) + (this));
        
        //#line 144 "x10/regionarray/RectRegion1D.x10"
        final java.lang.ArrayIndexOutOfBoundsException t$158310 = ((java.lang.ArrayIndexOutOfBoundsException)(new java.lang.ArrayIndexOutOfBoundsException(t$158309)));
        
        //#line 144 "x10/regionarray/RectRegion1D.x10"
        throw t$158310;
    }
    
    
    //#line 147 "x10/regionarray/RectRegion1D.x10"
    public x10.regionarray.Region eliminate(final long axis) {
        
        //#line 148 "x10/regionarray/RectRegion1D.x10"
        final x10.regionarray.RectRegion t$158311 = ((x10.regionarray.RectRegion)(this.toRectRegion()));
        
        //#line 148 "x10/regionarray/RectRegion1D.x10"
        final x10.regionarray.Region t$158312 = ((x10.regionarray.Region)(t$158311.eliminate((long)(axis))));
        
        //#line 148 "x10/regionarray/RectRegion1D.x10"
        return t$158312;
    }
    
    
    //#line 151 "x10/regionarray/RectRegion1D.x10"
    @x10.runtime.impl.java.X10Generated
    public static class RRIterator extends x10.core.Ref implements x10.lang.Iterator, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<RRIterator> $RTT = 
            x10.rtt.NamedType.<RRIterator> make("x10.regionarray.RectRegion1D.RRIterator",
                                                RRIterator.class,
                                                new x10.rtt.Type[] {
                                                    x10.rtt.ParameterizedType.make(x10.lang.Iterator.$RTT, x10.lang.Point.$RTT)
                                                });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static x10.serialization.X10JavaSerializable $_deserialize_body(x10.regionarray.RectRegion1D.RRIterator $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            $_obj.cur = $deserializer.readLong();
            $_obj.max = $deserializer.readLong();
            $_obj.min = $deserializer.readLong();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.regionarray.RectRegion1D.RRIterator $_obj = new x10.regionarray.RectRegion1D.RRIterator((java.lang.System[]) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            $serializer.write(this.cur);
            $serializer.write(this.max);
            $serializer.write(this.min);
            
        }
        
        // constructor just for allocation
        public RRIterator(final java.lang.System[] $dummy) {
            
        }
        
        // bridge for method abstract public x10.lang.Iterator[T].next(){}:T
        public x10.lang.Point next$G() {
            return next();
        }
        
        
    
        
        //#line 152 "x10/regionarray/RectRegion1D.x10"
        public long min;
        
        //#line 153 "x10/regionarray/RectRegion1D.x10"
        public long max;
        
        //#line 154 "x10/regionarray/RectRegion1D.x10"
        public long cur;
        
        
        //#line 156 "x10/regionarray/RectRegion1D.x10"
        // creation method for java code (1-phase java constructor)
        public RRIterator(final x10.regionarray.RectRegion1D rr) {
            this((java.lang.System[]) null);
            x10$regionarray$RectRegion1D$RRIterator$$init$S(rr);
        }
        
        // constructor for non-virtual call
        final public x10.regionarray.RectRegion1D.RRIterator x10$regionarray$RectRegion1D$RRIterator$$init$S(final x10.regionarray.RectRegion1D rr) {
             {
                
                //#line 156 "x10/regionarray/RectRegion1D.x10"
                
                
                //#line 151 "x10/regionarray/RectRegion1D.x10"
                final x10.regionarray.RectRegion1D.RRIterator this$158350 = this;
                
                //#line 151 "x10/regionarray/RectRegion1D.x10"
                this$158350.cur = 0L;
                
                //#line 157 "x10/regionarray/RectRegion1D.x10"
                final long t$158313 = rr.min;
                
                //#line 157 "x10/regionarray/RectRegion1D.x10"
                this.min = t$158313;
                
                //#line 158 "x10/regionarray/RectRegion1D.x10"
                final long t$158314 = rr.max;
                
                //#line 158 "x10/regionarray/RectRegion1D.x10"
                this.max = t$158314;
                
                //#line 159 "x10/regionarray/RectRegion1D.x10"
                final long t$158315 = this.min;
                
                //#line 159 "x10/regionarray/RectRegion1D.x10"
                this.cur = t$158315;
            }
            return this;
        }
        
        
        
        //#line 162 "x10/regionarray/RectRegion1D.x10"
        public boolean hasNext$O() {
            
            //#line 162 "x10/regionarray/RectRegion1D.x10"
            final long t$158316 = this.cur;
            
            //#line 162 "x10/regionarray/RectRegion1D.x10"
            final long t$158317 = this.max;
            
            //#line 162 "x10/regionarray/RectRegion1D.x10"
            final boolean t$158318 = ((t$158316) <= (((long)(t$158317))));
            
            //#line 162 "x10/regionarray/RectRegion1D.x10"
            return t$158318;
        }
        
        
        //#line 164 "x10/regionarray/RectRegion1D.x10"
        public x10.lang.Point next() {
            
            //#line 165 "x10/regionarray/RectRegion1D.x10"
            final long t$158319 = this.cur;
            
            //#line 165 "x10/regionarray/RectRegion1D.x10"
            final long t$158320 = ((t$158319) + (((long)(1L))));
            
            //#line 165 "x10/regionarray/RectRegion1D.x10"
            final long t$158321 = this.cur = t$158320;
            
            //#line 165 "x10/regionarray/RectRegion1D.x10"
            final long i$158215 = ((t$158321) - (((long)(1L))));
            
            //#line 151 . "x10/lang/Point.x10"
            final x10.lang.Point alloc$158216 = ((x10.lang.Point)(new x10.lang.Point((java.lang.System[]) null)));
            
            //#line 151 . "x10/lang/Point.x10"
            alloc$158216.x10$lang$Point$$init$S(((long)(i$158215)));
            
            //#line 165 "x10/regionarray/RectRegion1D.x10"
            return alloc$158216;
        }
        
        
        //#line 151 "x10/regionarray/RectRegion1D.x10"
        final public x10.regionarray.RectRegion1D.RRIterator x10$regionarray$RectRegion1D$RRIterator$$this$x10$regionarray$RectRegion1D$RRIterator() {
            
            //#line 151 "x10/regionarray/RectRegion1D.x10"
            return x10.regionarray.RectRegion1D.RRIterator.this;
        }
        
        
        //#line 151 "x10/regionarray/RectRegion1D.x10"
        final public void __fieldInitializers_x10_regionarray_RectRegion1D_RRIterator() {
            
            //#line 151 "x10/regionarray/RectRegion1D.x10"
            this.cur = 0L;
        }
    }
    
    
    
    //#line 169 "x10/regionarray/RectRegion1D.x10"
    public x10.lang.Iterator iterator() {
        
        //#line 170 "x10/regionarray/RectRegion1D.x10"
        final x10.regionarray.RectRegion1D.RRIterator alloc$139366 = ((x10.regionarray.RectRegion1D.RRIterator)(new x10.regionarray.RectRegion1D.RRIterator((java.lang.System[]) null)));
        
        //#line 170 "x10/regionarray/RectRegion1D.x10"
        alloc$139366.x10$regionarray$RectRegion1D$RRIterator$$init$S(((x10.regionarray.RectRegion1D)(this)));
        
        //#line 170 "x10/regionarray/RectRegion1D.x10"
        return alloc$139366;
    }
    
    
    //#line 173 "x10/regionarray/RectRegion1D.x10"
    public java.lang.String toString() {
        
        //#line 174 "x10/regionarray/RectRegion1D.x10"
        final long t$158322 = this.min;
        
        //#line 174 "x10/regionarray/RectRegion1D.x10"
        final java.lang.String t$158323 = (("[") + ((x10.core.Long.$box(t$158322))));
        
        //#line 174 "x10/regionarray/RectRegion1D.x10"
        final java.lang.String t$158324 = ((t$158323) + (".."));
        
        //#line 174 "x10/regionarray/RectRegion1D.x10"
        final long t$158325 = this.max;
        
        //#line 174 "x10/regionarray/RectRegion1D.x10"
        final java.lang.String t$158326 = ((t$158324) + ((x10.core.Long.$box(t$158325))));
        
        //#line 174 "x10/regionarray/RectRegion1D.x10"
        final java.lang.String t$158327 = ((t$158326) + ("]"));
        
        //#line 174 "x10/regionarray/RectRegion1D.x10"
        return t$158327;
    }
    
    
    //#line 22 "x10/regionarray/RectRegion1D.x10"
    final public x10.regionarray.RectRegion1D x10$regionarray$RectRegion1D$$this$x10$regionarray$RectRegion1D() {
        
        //#line 22 "x10/regionarray/RectRegion1D.x10"
        return x10.regionarray.RectRegion1D.this;
    }
    
    
    //#line 22 "x10/regionarray/RectRegion1D.x10"
    final public void __fieldInitializers_x10_regionarray_RectRegion1D() {
        
    }
    
    @x10.runtime.impl.java.X10Generated
    final public static class $Closure$292 extends x10.core.Ref implements x10.core.fun.Fun_0_1, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<$Closure$292> $RTT = 
            x10.rtt.StaticFunType.<$Closure$292> make($Closure$292.class,
                                                      new x10.rtt.Type[] {
                                                          x10.rtt.ParameterizedType.make(x10.core.fun.Fun_0_1.$RTT, x10.rtt.Types.LONG, x10.rtt.Types.LONG)
                                                      });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static x10.serialization.X10JavaSerializable $_deserialize_body(x10.regionarray.RectRegion1D.$Closure$292 $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            $_obj.out$$ = $deserializer.readObject();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.regionarray.RectRegion1D.$Closure$292 $_obj = new x10.regionarray.RectRegion1D.$Closure$292((java.lang.System[]) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            $serializer.write(this.out$$);
            
        }
        
        // constructor just for allocation
        public $Closure$292(final java.lang.System[] $dummy) {
            
        }
        
        // dispatcher for method abstract public (Z1)=>U.operator()(a1:Z1):U
        public java.lang.Object $apply(final java.lang.Object a1, final x10.rtt.Type t1) {
            return x10.core.Long.$box($apply$O(x10.core.Long.$unbox(a1)));
            
        }
        
        // dispatcher for method abstract public (Z1)=>U.operator()(a1:Z1):U
        public long $apply$J(final java.lang.Object a1, final x10.rtt.Type t1) {
            return $apply$O(x10.core.Long.$unbox(a1));
            
        }
        
        
    
        
        public long $apply$O(final long i) {
            
            //#line 108 "x10/regionarray/RectRegion1D.x10"
            final long t$158278 = this.out$$.min$O((long)(i));
            
            //#line 108 "x10/regionarray/RectRegion1D.x10"
            return t$158278;
        }
        
        public x10.regionarray.RectRegion1D out$$;
        
        public $Closure$292(final x10.regionarray.RectRegion1D out$$) {
             {
                this.out$$ = out$$;
            }
        }
        
    }
    
    @x10.runtime.impl.java.X10Generated
    final public static class $Closure$293 extends x10.core.Ref implements x10.core.fun.Fun_0_1, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<$Closure$293> $RTT = 
            x10.rtt.StaticFunType.<$Closure$293> make($Closure$293.class,
                                                      new x10.rtt.Type[] {
                                                          x10.rtt.ParameterizedType.make(x10.core.fun.Fun_0_1.$RTT, x10.rtt.Types.LONG, x10.rtt.Types.LONG)
                                                      });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static x10.serialization.X10JavaSerializable $_deserialize_body(x10.regionarray.RectRegion1D.$Closure$293 $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            $_obj.out$$ = $deserializer.readObject();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.regionarray.RectRegion1D.$Closure$293 $_obj = new x10.regionarray.RectRegion1D.$Closure$293((java.lang.System[]) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            $serializer.write(this.out$$);
            
        }
        
        // constructor just for allocation
        public $Closure$293(final java.lang.System[] $dummy) {
            
        }
        
        // dispatcher for method abstract public (Z1)=>U.operator()(a1:Z1):U
        public java.lang.Object $apply(final java.lang.Object a1, final x10.rtt.Type t1) {
            return x10.core.Long.$box($apply$O(x10.core.Long.$unbox(a1)));
            
        }
        
        // dispatcher for method abstract public (Z1)=>U.operator()(a1:Z1):U
        public long $apply$J(final java.lang.Object a1, final x10.rtt.Type t1) {
            return $apply$O(x10.core.Long.$unbox(a1));
            
        }
        
        
    
        
        public long $apply$O(final long i) {
            
            //#line 109 "x10/regionarray/RectRegion1D.x10"
            final long t$158280 = this.out$$.max$O((long)(i));
            
            //#line 109 "x10/regionarray/RectRegion1D.x10"
            return t$158280;
        }
        
        public x10.regionarray.RectRegion1D out$$;
        
        public $Closure$293(final x10.regionarray.RectRegion1D out$$) {
             {
                this.out$$ = out$$;
            }
        }
        
    }
    
}

