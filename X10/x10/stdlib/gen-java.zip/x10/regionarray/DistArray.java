package x10.regionarray;


/**
 * <p>A distributed array (DistArray) defines a mapping from {@link Point}s to data 
 * values of some type T. The Points in the DistArray's domain are defined by
 * specifying a {@link Region} over which the Array is defined.  Attempting to access 
 * a data value at a Point not included in the Array's Region will result in a 
 * {@link ArrayIndexOutOfBoundsException} being raised. The array's distribution ({@link Dist})
 * defines a mapping for the Points in the DistArray's region to Places. This defines
 * the Place where the data element for each Point is actually stored. Attempting to access
 * a data element from any other place will result in a {@link BadPlaceException} being
 * raised.</p>
 *
 * <p>The closely related class {@link Array} is used to define 
 * non-distributed arrays where the data values for the Points in the 
 * array's domain are all stored in a single place.  Although it is possible to
 * use a DistArray to store data in only a single place by creating a "constant distribution",
 * an Array will significantly outperform a DistArray with a constant distribution.</p>
 *
 * @see Point
 * @see Region
 * @see Dist
 * @see Array
 */
@x10.runtime.impl.java.X10Generated
final public class DistArray<$T> extends x10.core.Ref implements x10.core.fun.Fun_0_1, x10.lang.Iterable, x10.regionarray.Ghostable, x10.serialization.X10JavaSerializable
{
    public static final x10.rtt.RuntimeType<DistArray> $RTT = 
        x10.rtt.NamedType.<DistArray> make("x10.regionarray.DistArray",
                                           DistArray.class,
                                           1,
                                           new x10.rtt.Type[] {
                                               x10.rtt.ParameterizedType.make(x10.core.fun.Fun_0_1.$RTT, x10.lang.Point.$RTT, x10.rtt.UnresolvedType.PARAM(0)),
                                               x10.rtt.ParameterizedType.make(x10.lang.Iterable.$RTT, x10.lang.Point.$RTT),
                                               x10.regionarray.Ghostable.$RTT
                                           });
    
    public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
    
    public x10.rtt.Type<?> $getParam(int i) { if (i == 0) return $T; return null; }
    
    private Object writeReplace() throws java.io.ObjectStreamException {
        return new x10.serialization.SerializationProxy(this);
    }
    
    public static <$T> x10.serialization.X10JavaSerializable $_deserialize_body(x10.regionarray.DistArray<$T> $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
        $_obj.$T = (x10.rtt.Type) $deserializer.readObject();
        $_obj.dist = $deserializer.readObject();
        $_obj.localHandle = $deserializer.readObject();
        
        /* fields with @TransientInitExpr annotations */
        $_obj.localRegion = $_obj.getLocalRegionFromLocalHandle();
        $_obj.raw = $_obj.getRawFromLocalHandle();
        
        return $_obj;
    }
    
    public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
        x10.regionarray.DistArray $_obj = new x10.regionarray.DistArray((java.lang.System[]) null, (x10.rtt.Type) null);
        $deserializer.record_reference($_obj);
        return $_deserialize_body($_obj, $deserializer);
    }
    
    public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
        $serializer.write(this.$T);
        $serializer.write(this.dist);
        $serializer.write(this.localHandle);
        
    }
    
    // constructor just for allocation
    public DistArray(final java.lang.System[] $dummy, final x10.rtt.Type $T) {
        x10.regionarray.DistArray.$initParams(this, $T);
        
    }
    
    // dispatcher for method abstract public (Z1)=>U.operator()(a1:Z1){}:U
    public java.lang.Object $apply(final java.lang.Object a1, final x10.rtt.Type t1) {
        return $apply$G((x10.lang.Point)a1);
        
    }
    
    private x10.rtt.Type $T;
    
    // initializer of type parameters
    public static void $initParams(final DistArray $this, final x10.rtt.Type $T) {
        $this.$T = $T;
        
    }
    // synthetic type for parameter mangling
    public static final class __1$1x10$lang$Point$3x10$regionarray$DistArray$$T$2 {}
    // synthetic type for parameter mangling
    public static final class __1x10$regionarray$DistArray$$T {}
    // synthetic type for parameter mangling
    public static final class __0$1x10$regionarray$DistArray$$T$2 {}
    // synthetic type for parameter mangling
    public static final class __1$1x10$regionarray$DistArray$LocalState$1x10$regionarray$DistArray$$T$2$2 {}
    
    // properties
    
    //#line 49 "x10/regionarray/DistArray.x10"
    /**
     * The distribution of this array.
     */
    public x10.regionarray.Dist dist;
    

    
    
    //#line 62 "x10/regionarray/DistArray.x10"
    /**
     * The region this array is defined over.
     */
    final public x10.regionarray.Region region() {
        
        //#line 62 "x10/regionarray/DistArray.x10"
        final x10.regionarray.Dist t$150761 = ((x10.regionarray.Dist)(this.dist));
        
        //#line 62 "x10/regionarray/DistArray.x10"
        final x10.regionarray.Region t$150762 = ((x10.regionarray.Region)(t$150761.region));
        
        //#line 62 "x10/regionarray/DistArray.x10"
        return t$150762;
    }
    
    
    //#line 67 "x10/regionarray/DistArray.x10"
    /**
     * The rank of this array.
     */
    final public long rank$O() {
        
        //#line 67 "x10/regionarray/DistArray.x10"
        final x10.regionarray.Dist this$150508 = ((x10.regionarray.Dist)(this.dist));
        
        //#line 38 . "x10/regionarray/Dist.x10"
        final x10.regionarray.Region t$150763 = ((x10.regionarray.Region)(this$150508.region));
        
        //#line 38 . "x10/regionarray/Dist.x10"
        final long t$150764 = t$150763.rank;
        
        //#line 67 "x10/regionarray/DistArray.x10"
        return t$150764;
    }
    
    
    //#line 69 "x10/regionarray/DistArray.x10"
    public x10.regionarray.Dist getDist() {
        
        //#line 69 "x10/regionarray/DistArray.x10"
        final x10.regionarray.Dist t$150765 = ((x10.regionarray.Dist)(this.dist));
        
        //#line 69 "x10/regionarray/DistArray.x10"
        return t$150765;
    }
    
    
    //#line 71 "x10/regionarray/DistArray.x10"
    @x10.runtime.impl.java.X10Generated
    public static class LocalState<$T> extends x10.core.Ref implements x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<LocalState> $RTT = 
            x10.rtt.NamedType.<LocalState> make("x10.regionarray.DistArray.LocalState",
                                                LocalState.class,
                                                1);
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { if (i == 0) return $T; return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static <$T> x10.serialization.X10JavaSerializable $_deserialize_body(x10.regionarray.DistArray.LocalState<$T> $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            $_obj.$T = (x10.rtt.Type) $deserializer.readObject();
            $_obj.data = $deserializer.readObject();
            $_obj.dist = $deserializer.readObject();
            $_obj.ghostManager = $deserializer.readObject();
            $_obj.localRegion = $deserializer.readObject();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.regionarray.DistArray.LocalState $_obj = new x10.regionarray.DistArray.LocalState((java.lang.System[]) null, (x10.rtt.Type) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            $serializer.write(this.$T);
            $serializer.write(this.data);
            $serializer.write(this.dist);
            $serializer.write(this.ghostManager);
            $serializer.write(this.localRegion);
            
        }
        
        // constructor just for allocation
        public LocalState(final java.lang.System[] $dummy, final x10.rtt.Type $T) {
            x10.regionarray.DistArray.LocalState.$initParams(this, $T);
            
        }
        
        private x10.rtt.Type $T;
        
        // initializer of type parameters
        public static void $initParams(final LocalState $this, final x10.rtt.Type $T) {
            $this.$T = $T;
            
        }
        // synthetic type for parameter mangling
        public static final class __1$1x10$regionarray$DistArray$LocalState$$T$2 {}
        
        // properties
        
        //#line 71 "x10/regionarray/DistArray.x10"
        public x10.regionarray.Dist dist;
        
        //#line 71 "x10/regionarray/DistArray.x10"
        public x10.core.Rail<$T> data;
        
        //#line 71 "x10/regionarray/DistArray.x10"
        public x10.regionarray.Region localRegion;
        
    
        
        //#line 72 "x10/regionarray/DistArray.x10"
        public x10.regionarray.GhostManager ghostManager;
        
        
        //#line 73 "x10/regionarray/DistArray.x10"
        // creation method for java code (1-phase java constructor)
        public LocalState(final x10.rtt.Type $T, final x10.regionarray.Dist d, final x10.core.Rail<$T> c, final x10.regionarray.Region r, final x10.regionarray.GhostManager ghostManager, __1$1x10$regionarray$DistArray$LocalState$$T$2 $dummy) {
            this((java.lang.System[]) null, $T);
            x10$regionarray$DistArray$LocalState$$init$S(d, c, r, ghostManager, (x10.regionarray.DistArray.LocalState.__1$1x10$regionarray$DistArray$LocalState$$T$2) null);
        }
        
        // constructor for non-virtual call
        final public x10.regionarray.DistArray.LocalState<$T> x10$regionarray$DistArray$LocalState$$init$S(final x10.regionarray.Dist d, final x10.core.Rail<$T> c, final x10.regionarray.Region r, final x10.regionarray.GhostManager ghostManager, __1$1x10$regionarray$DistArray$LocalState$$T$2 $dummy) {
             {
                
                //#line 74 "x10/regionarray/DistArray.x10"
                this.dist = d;
                this.data = ((x10.core.Rail)(c));
                this.localRegion = ((x10.regionarray.Region)(r));
                
                
                //#line 75 "x10/regionarray/DistArray.x10"
                ((x10.regionarray.DistArray.LocalState<$T>)this).ghostManager = ((x10.regionarray.GhostManager)(ghostManager));
                
                //#line 81 "x10/regionarray/DistArray.x10"
                d.$apply(((x10.lang.Place)(x10.x10rt.X10RT.here())));
            }
            return this;
        }
        
        
        
        //#line 84 "x10/regionarray/DistArray.x10"
        // creation method for java code (1-phase java constructor)
        public LocalState(final x10.rtt.Type $T, final x10.regionarray.Dist d, final x10.core.Rail<$T> c, __1$1x10$regionarray$DistArray$LocalState$$T$2 $dummy) {
            this((java.lang.System[]) null, $T);
            x10$regionarray$DistArray$LocalState$$init$S(d, c, (x10.regionarray.DistArray.LocalState.__1$1x10$regionarray$DistArray$LocalState$$T$2) null);
        }
        
        // constructor for non-virtual call
        final public x10.regionarray.DistArray.LocalState<$T> x10$regionarray$DistArray$LocalState$$init$S(final x10.regionarray.Dist d, final x10.core.Rail<$T> c, __1$1x10$regionarray$DistArray$LocalState$$T$2 $dummy) {
             {
                
                //#line 85 "x10/regionarray/DistArray.x10"
                final x10.regionarray.Region t$151344 = ((x10.regionarray.Region)(d.$apply(((x10.lang.Place)(x10.x10rt.X10RT.here())))));
                
                //#line 85 "x10/regionarray/DistArray.x10"
                this.dist = d;
                this.data = ((x10.core.Rail)(c));
                this.localRegion = ((x10.regionarray.Region)(t$151344));
                
                
                //#line 86 "x10/regionarray/DistArray.x10"
                ((x10.regionarray.DistArray.LocalState<$T>)this).ghostManager = null;
                
                //#line 87 "x10/regionarray/DistArray.x10"
                d.$apply(((x10.lang.Place)(x10.x10rt.X10RT.here())));
            }
            return this;
        }
        
        
        
        //#line 71 "x10/regionarray/DistArray.x10"
        final public x10.regionarray.DistArray.LocalState x10$regionarray$DistArray$LocalState$$this$x10$regionarray$DistArray$LocalState() {
            
            //#line 71 "x10/regionarray/DistArray.x10"
            return x10.regionarray.DistArray.LocalState.this;
        }
        
        
        //#line 71 "x10/regionarray/DistArray.x10"
        final public void __fieldInitializers_x10_regionarray_DistArray_LocalState() {
            
        }
    }
    
    
    
    //#line 91 "x10/regionarray/DistArray.x10"
    private static x10.regionarray.GhostManager getGhostManager(final x10.regionarray.Dist d, final long ghostWidth, final boolean periodic) {
        
        //#line 92 "x10/regionarray/DistArray.x10"
        final boolean t$150767 = ((ghostWidth) < (((long)(1L))));
        
        //#line 92 "x10/regionarray/DistArray.x10"
        if (t$150767) {
            
            //#line 92 "x10/regionarray/DistArray.x10"
            return null;
        }
        
        //#line 94 "x10/regionarray/DistArray.x10"
        boolean t$150769 = !(periodic);
        
        //#line 94 "x10/regionarray/DistArray.x10"
        if (t$150769) {
            
            //#line 94 "x10/regionarray/DistArray.x10"
            final long t$150768 = d.numPlaces$O();
            
            //#line 94 "x10/regionarray/DistArray.x10"
            t$150769 = ((long) t$150768) == ((long) 1L);
        }
        
        //#line 94 "x10/regionarray/DistArray.x10"
        if (t$150769) {
            
            //#line 94 "x10/regionarray/DistArray.x10"
            return null;
        }
        
        //#line 96 "x10/regionarray/DistArray.x10"
        final x10.regionarray.GhostManager t$150771 = d.getLocalGhostManager((long)(ghostWidth), (boolean)(periodic));
        
        //#line 96 "x10/regionarray/DistArray.x10"
        return t$150771;
    }
    
    public static x10.regionarray.GhostManager getGhostManager$P(final x10.regionarray.Dist d, final long ghostWidth, final boolean periodic) {
        return x10.regionarray.DistArray.getGhostManager(((x10.regionarray.Dist)(d)), (long)(ghostWidth), (boolean)(periodic));
    }
    
    
    //#line 100 "x10/regionarray/DistArray.x10"
    /** The place-local state for the DistArray */
    public x10.lang.PlaceLocalHandle<x10.regionarray.DistArray.LocalState<$T>> localHandle;
    
    //#line 106 "x10/regionarray/DistArray.x10"
    /** 
     * The place-local backing storage for elements of the DistArray.
     */
    public transient x10.core.Rail<$T> raw;
    
    
    //#line 107 "x10/regionarray/DistArray.x10"
    public x10.core.Rail getRawFromLocalHandle() {
        
        //#line 108 "x10/regionarray/DistArray.x10"
        final x10.lang.PlaceLocalHandle t$150772 = ((x10.lang.PlaceLocalHandle)(this.localHandle));
        
        //#line 108 "x10/regionarray/DistArray.x10"
        final x10.regionarray.DistArray.LocalState ls = ((x10.regionarray.DistArray.LocalState)(((x10.lang.PlaceLocalHandle<x10.regionarray.DistArray.LocalState<$T>>)t$150772).$apply$G()));
        
        //#line 109 "x10/regionarray/DistArray.x10"
        final boolean t$150773 = ((ls) != (null));
        
        //#line 109 "x10/regionarray/DistArray.x10"
        x10.core.Rail t$150774 =  null;
        
        //#line 109 "x10/regionarray/DistArray.x10"
        if (t$150773) {
            
            //#line 109 "x10/regionarray/DistArray.x10"
            t$150774 = ((x10.core.Rail)(((x10.regionarray.DistArray.LocalState<$T>)ls).data));
        } else {
            
            //#line 109 "x10/regionarray/DistArray.x10"
            t$150774 = ((x10.core.Rail)(new x10.core.Rail<$T>($T)));
        }
        
        //#line 109 "x10/regionarray/DistArray.x10"
        return t$150774;
    }
    
    
    //#line 117 "x10/regionarray/DistArray.x10"
    /**
     * Method to acquire a pointer to the backing storage for the 
     * array's data in the current place.
     */
    final public x10.core.Rail raw() {
        
        //#line 117 "x10/regionarray/DistArray.x10"
        final x10.core.Rail t$150776 = ((x10.core.Rail)(this.raw));
        
        //#line 117 "x10/regionarray/DistArray.x10"
        return t$150776;
    }
    
    
    //#line 123 "x10/regionarray/DistArray.x10"
    /**
     * The region for which backing storage is allocated at this place.
     */
    public transient x10.regionarray.Region localRegion;
    
    
    //#line 124 "x10/regionarray/DistArray.x10"
    public x10.regionarray.Region getLocalRegionFromLocalHandle() {
        
        //#line 125 "x10/regionarray/DistArray.x10"
        final x10.lang.PlaceLocalHandle t$150777 = ((x10.lang.PlaceLocalHandle)(this.localHandle));
        
        //#line 125 "x10/regionarray/DistArray.x10"
        final x10.regionarray.DistArray.LocalState ls = ((x10.regionarray.DistArray.LocalState)(((x10.lang.PlaceLocalHandle<x10.regionarray.DistArray.LocalState<$T>>)t$150777).$apply$G()));
        
        //#line 126 "x10/regionarray/DistArray.x10"
        x10.regionarray.Region r =  null;
        
        //#line 127 "x10/regionarray/DistArray.x10"
        final boolean t$150781 = ((ls) != (null));
        
        //#line 127 "x10/regionarray/DistArray.x10"
        if (t$150781) {
            
            //#line 127 "x10/regionarray/DistArray.x10"
            final x10.regionarray.Region t$150778 = ((x10.regionarray.Region)(((x10.regionarray.DistArray.LocalState<$T>)ls).localRegion));
            
            //#line 127 "x10/regionarray/DistArray.x10"
            r = ((x10.regionarray.Region)(t$150778));
        } else {
            
            //#line 128 "x10/regionarray/DistArray.x10"
            final x10.regionarray.DistArray this$150514 = ((x10.regionarray.DistArray)(this));
            
            //#line 67 . "x10/regionarray/DistArray.x10"
            final x10.regionarray.Dist this$150516 = ((x10.regionarray.Dist)(((x10.regionarray.DistArray<$T>)this$150514).dist));
            
            //#line 38 .. "x10/regionarray/Dist.x10"
            final x10.regionarray.Region t$150779 = ((x10.regionarray.Region)(this$150516.region));
            
            //#line 128 "x10/regionarray/DistArray.x10"
            final long rank$150518 = t$150779.rank;
            
            //#line 60 . "x10/regionarray/Region.x10"
            final x10.regionarray.EmptyRegion alloc$150519 = ((x10.regionarray.EmptyRegion)(new x10.regionarray.EmptyRegion((java.lang.System[]) null)));
            
            //#line 60 . "x10/regionarray/Region.x10"
            alloc$150519.x10$regionarray$EmptyRegion$$init$S(((long)(rank$150518)));
            
            //#line 60 . "x10/regionarray/Region.x10"
            final x10.regionarray.Region t$150780 = ((x10.regionarray.Region)(((x10.regionarray.Region)
                                                                                alloc$150519)));
            
            //#line 128 "x10/regionarray/DistArray.x10"
            r = ((x10.regionarray.Region)(t$150780));
        }
        
        //#line 129 "x10/regionarray/DistArray.x10"
        return r;
    }
    
    
    //#line 138 "x10/regionarray/DistArray.x10"
    final public x10.regionarray.Region localRegion() {
        
        //#line 138 "x10/regionarray/DistArray.x10"
        final x10.regionarray.Region t$150783 = ((x10.regionarray.Region)(this.localRegion));
        
        //#line 138 "x10/regionarray/DistArray.x10"
        return t$150783;
    }
    
    
    //#line 144 "x10/regionarray/DistArray.x10"
    /**
     * @return the portion of the DistArray (including ghosts) that is stored 
     *   locally at the current place, as an Array
     */
    public x10.regionarray.Array getLocalPortion() {
        
        //#line 145 "x10/regionarray/DistArray.x10"
        final x10.regionarray.DistArray this$150521 = ((x10.regionarray.DistArray)(this));
        
        //#line 145 "x10/regionarray/DistArray.x10"
        final x10.regionarray.Region regionForHere = ((x10.regionarray.Region)(((x10.regionarray.DistArray<$T>)this$150521).localRegion));
        
        //#line 146 "x10/regionarray/DistArray.x10"
        final boolean t$150784 = regionForHere.rect;
        
        //#line 146 "x10/regionarray/DistArray.x10"
        final boolean t$150788 = !(t$150784);
        
        //#line 146 "x10/regionarray/DistArray.x10"
        if (t$150788) {
            
            //#line 146 "x10/regionarray/DistArray.x10"
            final java.lang.String t$150785 = x10.rtt.Types.typeName(((java.lang.Object)(this)));
            
            //#line 146 "x10/regionarray/DistArray.x10"
            final java.lang.String t$150786 = ((t$150785) + (".getLocalPortion(): local portion is not rectangular!"));
            
            //#line 146 "x10/regionarray/DistArray.x10"
            final java.lang.UnsupportedOperationException t$150787 = ((java.lang.UnsupportedOperationException)(new java.lang.UnsupportedOperationException(t$150786)));
            
            //#line 146 "x10/regionarray/DistArray.x10"
            throw t$150787;
        }
        
        //#line 147 "x10/regionarray/DistArray.x10"
        final x10.regionarray.Array alloc$150398 = ((x10.regionarray.Array)(new x10.regionarray.Array<$T>((java.lang.System[]) null, $T)));
        
        //#line 147 "x10/regionarray/DistArray.x10"
        final x10.core.Rail backingStore$150524 = ((x10.core.Rail)(this.raw));
        
        //#line 233 . "x10/regionarray/Array.x10"
        final x10.regionarray.Region t$151346 = ((x10.regionarray.Region)
                                                  regionForHere);
        
        //#line 233 . "x10/regionarray/Array.x10"
        final boolean t$151347 = ((t$151346) != (null));
        
        //#line 233 . "x10/regionarray/Array.x10"
        final boolean t$151348 = !(t$151347);
        
        //#line 233 . "x10/regionarray/Array.x10"
        if (t$151348) {
            
            //#line 233 . "x10/regionarray/Array.x10"
            final boolean t$151349 = true;
            
            //#line 233 . "x10/regionarray/Array.x10"
            if (t$151349) {
                
                //#line 233 . "x10/regionarray/Array.x10"
                final x10.lang.FailedDynamicCheckException t$151350 = new x10.lang.FailedDynamicCheckException("x10.regionarray.Region{self!=null}");
                
                //#line 233 . "x10/regionarray/Array.x10"
                throw t$151350;
            }
        }
        
        //#line 233 . "x10/regionarray/Array.x10"
        ((x10.regionarray.Array<$T>)alloc$150398).region = ((x10.regionarray.Region)(t$151346));
        
        //#line 233 . "x10/regionarray/Array.x10"
        final long t$151351 = regionForHere.rank;
        
        //#line 233 . "x10/regionarray/Array.x10"
        ((x10.regionarray.Array<$T>)alloc$150398).rank = t$151351;
        
        //#line 233 . "x10/regionarray/Array.x10"
        final boolean t$151352 = regionForHere.rect;
        
        //#line 233 . "x10/regionarray/Array.x10"
        ((x10.regionarray.Array<$T>)alloc$150398).rect = t$151352;
        
        //#line 233 . "x10/regionarray/Array.x10"
        final boolean t$151353 = regionForHere.zeroBased;
        
        //#line 233 . "x10/regionarray/Array.x10"
        ((x10.regionarray.Array<$T>)alloc$150398).zeroBased = t$151353;
        
        //#line 233 . "x10/regionarray/Array.x10"
        final boolean t$151354 = regionForHere.rail;
        
        //#line 233 . "x10/regionarray/Array.x10"
        ((x10.regionarray.Array<$T>)alloc$150398).rail = t$151354;
        
        //#line 233 . "x10/regionarray/Array.x10"
        final long t$151355 = regionForHere.size$O();
        
        //#line 233 . "x10/regionarray/Array.x10"
        ((x10.regionarray.Array<$T>)alloc$150398).size = t$151355;
        
        //#line 235 . "x10/regionarray/Array.x10"
        final x10.regionarray.Array.LayoutHelper crh$151356 = new x10.regionarray.Array.LayoutHelper((java.lang.System[]) null);
        
        //#line 235 . "x10/regionarray/Array.x10"
        crh$151356.x10$regionarray$Array$LayoutHelper$$init$S(((x10.regionarray.Region)(regionForHere)));
        
        //#line 236 . "x10/regionarray/Array.x10"
        final long t$151357 = crh$151356.min0;
        
        //#line 236 . "x10/regionarray/Array.x10"
        ((x10.regionarray.Array<$T>)alloc$150398).layout_min0 = t$151357;
        
        //#line 237 . "x10/regionarray/Array.x10"
        final long t$151358 = crh$151356.stride1;
        
        //#line 237 . "x10/regionarray/Array.x10"
        ((x10.regionarray.Array<$T>)alloc$150398).layout_stride1 = t$151358;
        
        //#line 238 . "x10/regionarray/Array.x10"
        final long t$151359 = crh$151356.min1;
        
        //#line 238 . "x10/regionarray/Array.x10"
        ((x10.regionarray.Array<$T>)alloc$150398).layout_min1 = t$151359;
        
        //#line 239 . "x10/regionarray/Array.x10"
        final x10.core.Rail t$151360 = ((x10.core.Rail)(crh$151356.layout));
        
        //#line 239 . "x10/regionarray/Array.x10"
        ((x10.regionarray.Array<$T>)alloc$150398).layout = ((x10.core.Rail)(t$151360));
        
        //#line 240 . "x10/regionarray/Array.x10"
        final long n$151361 = crh$151356.size;
        
        //#line 241 . "x10/regionarray/Array.x10"
        final long t$151362 = ((x10.core.Rail<$T>)backingStore$150524).size;
        
        //#line 241 . "x10/regionarray/Array.x10"
        final boolean t$151363 = ((n$151361) > (((long)(t$151362))));
        
        //#line 241 . "x10/regionarray/Array.x10"
        if (t$151363) {
            
            //#line 242 . "x10/regionarray/Array.x10"
            final boolean t$151364 = true;
            
            //#line 242 . "x10/regionarray/Array.x10"
            if (t$151364) {
                
                //#line 242 . "x10/regionarray/Array.x10"
                final java.lang.IllegalArgumentException t$151365 = ((java.lang.IllegalArgumentException)(new java.lang.IllegalArgumentException("backingStore too small")));
                
                //#line 242 . "x10/regionarray/Array.x10"
                throw t$151365;
            }
        }
        
        //#line 244 . "x10/regionarray/Array.x10"
        final x10.core.Rail t$151366 = ((x10.core.Rail<$T>)
                                         backingStore$150524);
        
        //#line 244 . "x10/regionarray/Array.x10"
        final boolean t$151367 = ((t$151366) != (null));
        
        //#line 244 . "x10/regionarray/Array.x10"
        final boolean t$151368 = !(t$151367);
        
        //#line 244 . "x10/regionarray/Array.x10"
        if (t$151368) {
            
            //#line 244 . "x10/regionarray/Array.x10"
            final boolean t$151369 = true;
            
            //#line 244 . "x10/regionarray/Array.x10"
            if (t$151369) {
                
                //#line 244 . "x10/regionarray/Array.x10"
                final x10.lang.FailedDynamicCheckException t$151370 = new x10.lang.FailedDynamicCheckException("x10.lang.Rail[T]{self!=null}");
                
                //#line 244 . "x10/regionarray/Array.x10"
                throw t$151370;
            }
        }
        
        //#line 244 . "x10/regionarray/Array.x10"
        ((x10.regionarray.Array<$T>)alloc$150398).raw = ((x10.core.Rail)(t$151366));
        
        //#line 147 "x10/regionarray/DistArray.x10"
        return alloc$150398;
    }
    
    
    //#line 156 "x10/regionarray/DistArray.x10"
    /**
     * Create a zero-initialized distributed array over the argument distribution.
     *
     * @param dist the given distribution
     * @return the newly created DistArray
     */
    public static <$T>x10.regionarray.DistArray make(final x10.rtt.Type $T, final x10.regionarray.Dist dist) {
        
        //#line 156 "x10/regionarray/DistArray.x10"
        final x10.regionarray.DistArray alloc$150399 = ((x10.regionarray.DistArray)(new x10.regionarray.DistArray<$T>((java.lang.System[]) null, $T)));
        
        //#line 169 . "x10/regionarray/DistArray.x10"
        alloc$150399.x10$regionarray$DistArray$$init$S(dist, ((long)(0L)), ((boolean)(false)));
        
        //#line 156 "x10/regionarray/DistArray.x10"
        return alloc$150399;
    }
    
    
    //#line 166 "x10/regionarray/DistArray.x10"
    /**
     * Create a zero-initialized distributed array over the argument distribution.
     *
     * @param dist the given distribution
     * @param ghostWidth the width of the ghost region in every dimension
     * @param periodic whether to apply periodic boundary conditions
     * @return the newly created DistArray
     */
    public static <$T>x10.regionarray.DistArray make(final x10.rtt.Type $T, final x10.regionarray.Dist dist, final long ghostWidth, final boolean periodic) {
        
        //#line 166 "x10/regionarray/DistArray.x10"
        final x10.regionarray.DistArray alloc$150400 = ((x10.regionarray.DistArray)(new x10.regionarray.DistArray<$T>((java.lang.System[]) null, $T)));
        
        //#line 166 "x10/regionarray/DistArray.x10"
        alloc$150400.x10$regionarray$DistArray$$init$S(((x10.regionarray.Dist)(dist)), ((long)(ghostWidth)), ((boolean)(periodic)));
        
        //#line 166 "x10/regionarray/DistArray.x10"
        return alloc$150400;
    }
    
    
    //#line 168 "x10/regionarray/DistArray.x10"
    // creation method for java code (1-phase java constructor)
    public DistArray(final x10.rtt.Type $T, final x10.regionarray.Dist dist) {
        this((java.lang.System[]) null, $T);
        x10$regionarray$DistArray$$init$S(dist);
    }
    
    // constructor for non-virtual call
    final public x10.regionarray.DistArray<$T> x10$regionarray$DistArray$$init$S(final x10.regionarray.Dist dist) {
         {
            
            //#line 169 "x10/regionarray/DistArray.x10"
            /*this.*/x10$regionarray$DistArray$$init$S(((x10.regionarray.Dist)(dist)), ((long)(0L)), ((boolean)(false)));
        }
        return this;
    }
    
    
    
    //#line 172 "x10/regionarray/DistArray.x10"
    // creation method for java code (1-phase java constructor)
    public DistArray(final x10.rtt.Type $T, final x10.regionarray.Dist dist, final long ghostWidth, final boolean periodic) {
        this((java.lang.System[]) null, $T);
        x10$regionarray$DistArray$$init$S(dist, ghostWidth, periodic);
    }
    
    // constructor for non-virtual call
    final public x10.regionarray.DistArray<$T> x10$regionarray$DistArray$$init$S(final x10.regionarray.Dist dist, final long ghostWidth, final boolean periodic) {
         {
            
            //#line 173 "x10/regionarray/DistArray.x10"
            this.dist = dist;
            
            
            //#line 187 "x10/regionarray/DistArray.x10"
            final x10.lang.PlaceGroup t$150820 = dist.places();
            
            //#line 175 "x10/regionarray/DistArray.x10"
            final x10.core.fun.Fun_0_0 t$150821 = ((x10.core.fun.Fun_0_0)(new x10.regionarray.DistArray.$Closure$223<$T>($T, dist, ghostWidth, periodic)));
            
            //#line 187 "x10/regionarray/DistArray.x10"
            final x10.lang.PlaceLocalHandle t$150822 = x10.lang.PlaceLocalHandle.<x10.regionarray.DistArray.LocalState<$T>> makeFlat__1$1x10$lang$PlaceLocalHandle$$T$2(x10.rtt.ParameterizedType.make(x10.regionarray.DistArray.LocalState.$RTT, $T), ((x10.lang.PlaceGroup)(t$150820)), ((x10.core.fun.Fun_0_0)(t$150821)));
            
            //#line 187 "x10/regionarray/DistArray.x10"
            ((x10.regionarray.DistArray<$T>)this).localHandle = ((x10.lang.PlaceLocalHandle)(t$150822));
            
            //#line 188 "x10/regionarray/DistArray.x10"
            final x10.core.Rail t$150823 = ((x10.core.Rail)(((x10.core.Rail<$T>)
                                                              this.getRawFromLocalHandle())));
            
            //#line 188 "x10/regionarray/DistArray.x10"
            ((x10.regionarray.DistArray<$T>)this).raw = ((x10.core.Rail)(t$150823));
            
            //#line 189 "x10/regionarray/DistArray.x10"
            final x10.regionarray.Region t$150824 = ((x10.regionarray.Region)(this.getLocalRegionFromLocalHandle()));
            
            //#line 189 "x10/regionarray/DistArray.x10"
            ((x10.regionarray.DistArray<$T>)this).localRegion = ((x10.regionarray.Region)(t$150824));
        }
        return this;
    }
    
    
    
    //#line 208 "x10/regionarray/DistArray.x10"
    /**
     * Create a distributed array over the argument distribution whose elements
     * are initialized by executing the given initializer function for each 
     * element of the array in the place where the argument Point is mapped. 
     * The function will be evaluated exactly once for each point
     * in dist in an arbitrary order to compute the initial value for each array element.</p>
     * 
     * Within each place, it is unspecified whether the function evaluations will
     * be done sequentially by a single activity for each point or concurrently for disjoint sets 
     * of points by one or more child activities. 
     * 
     * @param dist the given distribution
     * @param init the initializer function
     * @return the newly created DistArray
     * @see #make[T](Dist)
     */
    public static <$T>x10.regionarray.DistArray make__1$1x10$lang$Point$3x10$regionarray$DistArray$$T$2(final x10.rtt.Type $T, final x10.regionarray.Dist dist, final x10.core.fun.Fun_0_1<x10.lang.Point,$T> init) {
        
        //#line 208 "x10/regionarray/DistArray.x10"
        final x10.regionarray.DistArray alloc$150402 = ((x10.regionarray.DistArray)(new x10.regionarray.DistArray<$T>((java.lang.System[]) null, $T)));
        
        //#line 208 "x10/regionarray/DistArray.x10"
        alloc$150402.x10$regionarray$DistArray$$init$S(((x10.regionarray.Dist)(dist)), ((x10.core.fun.Fun_0_1)(init)), ((long)(0L)), ((boolean)(false)), (x10.regionarray.DistArray.__1$1x10$lang$Point$3x10$regionarray$DistArray$$T$2) null);
        
        //#line 208 "x10/regionarray/DistArray.x10"
        return alloc$150402;
    }
    
    
    //#line 228 "x10/regionarray/DistArray.x10"
    /**
     * Create a distributed array over the argument distribution whose elements
     * are initialized by executing the given initializer function for each 
     * element of the array in the place where the argument Point is mapped. 
     * The function will be evaluated exactly once for each point in dist in an
     * arbitrary order to compute the initial value for each array element.</p>
     * 
     * Within each place, it is unspecified whether the function evaluations will
     * be done sequentially by a single activity for each point or concurrently for disjoint sets 
     * of points by one or more child activities. 
     * 
     * @param dist the given distribution
     * @param init the initializer function
     * @param ghostWidth the width of the ghost region in every dimension
     * @param periodic whether to apply periodic boundary conditions
     * @return the newly created DistArray
     * @see #make[T](Dist)
     */
    public static <$T>x10.regionarray.DistArray make__1$1x10$lang$Point$3x10$regionarray$DistArray$$T$2(final x10.rtt.Type $T, final x10.regionarray.Dist dist, final x10.core.fun.Fun_0_1<x10.lang.Point,$T> init, final long ghostWidth, final boolean periodic) {
        
        //#line 228 "x10/regionarray/DistArray.x10"
        final x10.regionarray.DistArray alloc$150403 = ((x10.regionarray.DistArray)(new x10.regionarray.DistArray<$T>((java.lang.System[]) null, $T)));
        
        //#line 228 "x10/regionarray/DistArray.x10"
        alloc$150403.x10$regionarray$DistArray$$init$S(((x10.regionarray.Dist)(dist)), ((x10.core.fun.Fun_0_1)(init)), ((long)(ghostWidth)), ((boolean)(periodic)), (x10.regionarray.DistArray.__1$1x10$lang$Point$3x10$regionarray$DistArray$$T$2) null);
        
        //#line 228 "x10/regionarray/DistArray.x10"
        return alloc$150403;
    }
    
    
    //#line 230 "x10/regionarray/DistArray.x10"
    // creation method for java code (1-phase java constructor)
    public DistArray(final x10.rtt.Type $T, final x10.regionarray.Dist dist, final x10.core.fun.Fun_0_1<x10.lang.Point,$T> init, final long ghostWidth, final boolean periodic, __1$1x10$lang$Point$3x10$regionarray$DistArray$$T$2 $dummy) {
        this((java.lang.System[]) null, $T);
        x10$regionarray$DistArray$$init$S(dist, init, ghostWidth, periodic, (x10.regionarray.DistArray.__1$1x10$lang$Point$3x10$regionarray$DistArray$$T$2) null);
    }
    
    // constructor for non-virtual call
    final public x10.regionarray.DistArray<$T> x10$regionarray$DistArray$$init$S(final x10.regionarray.Dist dist, final x10.core.fun.Fun_0_1<x10.lang.Point,$T> init, final long ghostWidth, final boolean periodic, __1$1x10$lang$Point$3x10$regionarray$DistArray$$T$2 $dummy) {
         {
            
            //#line 231 "x10/regionarray/DistArray.x10"
            this.dist = dist;
            
            
            //#line 249 "x10/regionarray/DistArray.x10"
            final x10.lang.PlaceGroup t$150839 = dist.places();
            
            //#line 233 "x10/regionarray/DistArray.x10"
            final x10.core.fun.Fun_0_0 t$150840 = ((x10.core.fun.Fun_0_0)(new x10.regionarray.DistArray.$Closure$224<$T>($T, dist, ghostWidth, periodic, init, (x10.regionarray.DistArray.$Closure$224.__3$1x10$lang$Point$3x10$regionarray$DistArray$$Closure$224$$T$2) null)));
            
            //#line 249 "x10/regionarray/DistArray.x10"
            final x10.lang.PlaceLocalHandle t$150841 = x10.lang.PlaceLocalHandle.<x10.regionarray.DistArray.LocalState<$T>> make__1$1x10$lang$PlaceLocalHandle$$T$2(x10.rtt.ParameterizedType.make(x10.regionarray.DistArray.LocalState.$RTT, $T), ((x10.lang.PlaceGroup)(t$150839)), ((x10.core.fun.Fun_0_0)(t$150840)));
            
            //#line 249 "x10/regionarray/DistArray.x10"
            ((x10.regionarray.DistArray<$T>)this).localHandle = ((x10.lang.PlaceLocalHandle)(t$150841));
            
            //#line 250 "x10/regionarray/DistArray.x10"
            final x10.core.Rail t$150842 = ((x10.core.Rail)(((x10.core.Rail<$T>)
                                                              this.getRawFromLocalHandle())));
            
            //#line 250 "x10/regionarray/DistArray.x10"
            ((x10.regionarray.DistArray<$T>)this).raw = ((x10.core.Rail)(t$150842));
            
            //#line 251 "x10/regionarray/DistArray.x10"
            final x10.regionarray.Region t$150843 = ((x10.regionarray.Region)(this.getLocalRegionFromLocalHandle()));
            
            //#line 251 "x10/regionarray/DistArray.x10"
            ((x10.regionarray.DistArray<$T>)this).localRegion = ((x10.regionarray.Region)(t$150843));
        }
        return this;
    }
    
    
    
    //#line 264 "x10/regionarray/DistArray.x10"
    /**
     * Create a distributed array over the argument distribution whose elements
     * are initialized to the given initial value.
     *
     * @param dist the given distribution
     * @param init the initial value
     * @return the newly created DistArray
     * @see #make[T](Dist)
     */
    public static <$T>x10.regionarray.DistArray make__1x10$regionarray$DistArray$$T(final x10.rtt.Type $T, final x10.regionarray.Dist dist, final $T init) {
        
        //#line 264 "x10/regionarray/DistArray.x10"
        final x10.regionarray.DistArray alloc$150405 = ((x10.regionarray.DistArray)(new x10.regionarray.DistArray<$T>((java.lang.System[]) null, $T)));
        
        //#line 264 "x10/regionarray/DistArray.x10"
        alloc$150405.x10$regionarray$DistArray$$init$S(((x10.regionarray.Dist)(dist)), (($T)(init)), ((long)(0L)), ((boolean)(false)), (x10.regionarray.DistArray.__1x10$regionarray$DistArray$$T) null);
        
        //#line 264 "x10/regionarray/DistArray.x10"
        return alloc$150405;
    }
    
    
    //#line 277 "x10/regionarray/DistArray.x10"
    /**
     * Create a distributed array over the argument distribution whose elements
     * are initialized to the given initial value.
     *
     * @param dist the given distribution
     * @param init the initial value
     * @param ghostWidth the width of the ghost region in every dimension
     * @param periodic whether to apply periodic boundary conditions
     * @return the newly created DistArray
     * @see #make[T](Dist)
     */
    public static <$T>x10.regionarray.DistArray make__1x10$regionarray$DistArray$$T(final x10.rtt.Type $T, final x10.regionarray.Dist dist, final $T init, final long ghostWidth, final boolean periodic) {
        
        //#line 277 "x10/regionarray/DistArray.x10"
        final x10.regionarray.DistArray alloc$150406 = ((x10.regionarray.DistArray)(new x10.regionarray.DistArray<$T>((java.lang.System[]) null, $T)));
        
        //#line 277 "x10/regionarray/DistArray.x10"
        alloc$150406.x10$regionarray$DistArray$$init$S(((x10.regionarray.Dist)(dist)), (($T)(init)), ((long)(ghostWidth)), ((boolean)(periodic)), (x10.regionarray.DistArray.__1x10$regionarray$DistArray$$T) null);
        
        //#line 277 "x10/regionarray/DistArray.x10"
        return alloc$150406;
    }
    
    
    //#line 279 "x10/regionarray/DistArray.x10"
    // creation method for java code (1-phase java constructor)
    public DistArray(final x10.rtt.Type $T, final x10.regionarray.Dist dist, final $T init, final long ghostWidth, final boolean periodic, __1x10$regionarray$DistArray$$T $dummy) {
        this((java.lang.System[]) null, $T);
        x10$regionarray$DistArray$$init$S(dist, init, ghostWidth, periodic, (x10.regionarray.DistArray.__1x10$regionarray$DistArray$$T) null);
    }
    
    // constructor for non-virtual call
    final public x10.regionarray.DistArray<$T> x10$regionarray$DistArray$$init$S(final x10.regionarray.Dist dist, final $T init, final long ghostWidth, final boolean periodic, __1x10$regionarray$DistArray$$T $dummy) {
         {
            
            //#line 280 "x10/regionarray/DistArray.x10"
            this.dist = dist;
            
            
            //#line 294 "x10/regionarray/DistArray.x10"
            final x10.lang.PlaceGroup t$150854 = dist.places();
            
            //#line 282 "x10/regionarray/DistArray.x10"
            final x10.core.fun.Fun_0_0 t$150855 = ((x10.core.fun.Fun_0_0)(new x10.regionarray.DistArray.$Closure$225<$T>($T, dist, ghostWidth, periodic, init, (x10.regionarray.DistArray.$Closure$225.__3x10$regionarray$DistArray$$Closure$225$$T) null)));
            
            //#line 294 "x10/regionarray/DistArray.x10"
            final x10.lang.PlaceLocalHandle t$150856 = x10.lang.PlaceLocalHandle.<x10.regionarray.DistArray.LocalState<$T>> make__1$1x10$lang$PlaceLocalHandle$$T$2(x10.rtt.ParameterizedType.make(x10.regionarray.DistArray.LocalState.$RTT, $T), ((x10.lang.PlaceGroup)(t$150854)), ((x10.core.fun.Fun_0_0)(t$150855)));
            
            //#line 294 "x10/regionarray/DistArray.x10"
            ((x10.regionarray.DistArray<$T>)this).localHandle = ((x10.lang.PlaceLocalHandle)(t$150856));
            
            //#line 295 "x10/regionarray/DistArray.x10"
            final x10.core.Rail t$150857 = ((x10.core.Rail)(((x10.core.Rail<$T>)
                                                              this.getRawFromLocalHandle())));
            
            //#line 295 "x10/regionarray/DistArray.x10"
            ((x10.regionarray.DistArray<$T>)this).raw = ((x10.core.Rail)(t$150857));
            
            //#line 296 "x10/regionarray/DistArray.x10"
            final x10.regionarray.Region t$150858 = ((x10.regionarray.Region)(this.getLocalRegionFromLocalHandle()));
            
            //#line 296 "x10/regionarray/DistArray.x10"
            ((x10.regionarray.DistArray<$T>)this).localRegion = ((x10.regionarray.Region)(t$150858));
        }
        return this;
    }
    
    
    
    //#line 308 "x10/regionarray/DistArray.x10"
    /**
     * Create a DistArray that views the same backing data
     * as the argument DistArray using a different distribution.</p>
     * 
     * An unchecked invariant for this to be correct is that for each place in
     * d.places, local storage must be allocated for each point p in d(place).
     * This invariant is too expensive to be checked dynamically, so it simply must
     * be respected by the DistArray code that calls this constructor.
     */
    // creation method for java code (1-phase java constructor)
    public DistArray(final x10.rtt.Type $T, final x10.regionarray.DistArray<$T> a, final x10.regionarray.Dist d, __0$1x10$regionarray$DistArray$$T$2 $dummy) {
        this((java.lang.System[]) null, $T);
        x10$regionarray$DistArray$$init$S(a, d, (x10.regionarray.DistArray.__0$1x10$regionarray$DistArray$$T$2) null);
    }
    
    // constructor for non-virtual call
    final public x10.regionarray.DistArray<$T> x10$regionarray$DistArray$$init$S(final x10.regionarray.DistArray<$T> a, final x10.regionarray.Dist d, __0$1x10$regionarray$DistArray$$T$2 $dummy) {
         {
            
            //#line 309 "x10/regionarray/DistArray.x10"
            this.dist = d;
            
            
            //#line 316 "x10/regionarray/DistArray.x10"
            final x10.lang.PlaceGroup t$150868 = d.places();
            
            //#line 312 "x10/regionarray/DistArray.x10"
            final x10.core.fun.Fun_0_0 t$150869 = ((x10.core.fun.Fun_0_0)(new x10.regionarray.DistArray.$Closure$226<$T>($T, a, d, (x10.regionarray.DistArray.$Closure$226.__0$1x10$regionarray$DistArray$$Closure$226$$T$2) null)));
            
            //#line 316 "x10/regionarray/DistArray.x10"
            final x10.lang.PlaceLocalHandle t$150870 = x10.lang.PlaceLocalHandle.<x10.regionarray.DistArray.LocalState<$T>> makeFlat__1$1x10$lang$PlaceLocalHandle$$T$2(x10.rtt.ParameterizedType.make(x10.regionarray.DistArray.LocalState.$RTT, $T), ((x10.lang.PlaceGroup)(t$150868)), ((x10.core.fun.Fun_0_0)(t$150869)));
            
            //#line 316 "x10/regionarray/DistArray.x10"
            ((x10.regionarray.DistArray<$T>)this).localHandle = ((x10.lang.PlaceLocalHandle)(t$150870));
            
            //#line 317 "x10/regionarray/DistArray.x10"
            final x10.core.Rail t$150871 = ((x10.core.Rail)(((x10.core.Rail<$T>)
                                                              this.getRawFromLocalHandle())));
            
            //#line 317 "x10/regionarray/DistArray.x10"
            ((x10.regionarray.DistArray<$T>)this).raw = ((x10.core.Rail)(t$150871));
            
            //#line 318 "x10/regionarray/DistArray.x10"
            final x10.regionarray.Region t$150872 = ((x10.regionarray.Region)(this.getLocalRegionFromLocalHandle()));
            
            //#line 318 "x10/regionarray/DistArray.x10"
            ((x10.regionarray.DistArray<$T>)this).localRegion = ((x10.regionarray.Region)(t$150872));
        }
        return this;
    }
    
    
    
    //#line 326 "x10/regionarray/DistArray.x10"
    /**
     * Create a DistArray from a distribution and a PlaceLocalHandle[LocalState[T]]
     * This constructor is intended for internal use only by operations such as 
     * map to enable them to complete with only 1 collective operation instead of 2.
     */
    // creation method for java code (1-phase java constructor)
    public DistArray(final x10.rtt.Type $T, final x10.regionarray.Dist d, final x10.lang.PlaceLocalHandle<x10.regionarray.DistArray.LocalState<$T>> pls, __1$1x10$regionarray$DistArray$LocalState$1x10$regionarray$DistArray$$T$2$2 $dummy) {
        this((java.lang.System[]) null, $T);
        x10$regionarray$DistArray$$init$S(d, pls, (x10.regionarray.DistArray.__1$1x10$regionarray$DistArray$LocalState$1x10$regionarray$DistArray$$T$2$2) null);
    }
    
    // constructor for non-virtual call
    final public x10.regionarray.DistArray<$T> x10$regionarray$DistArray$$init$S(final x10.regionarray.Dist d, final x10.lang.PlaceLocalHandle<x10.regionarray.DistArray.LocalState<$T>> pls, __1$1x10$regionarray$DistArray$LocalState$1x10$regionarray$DistArray$$T$2$2 $dummy) {
         {
            
            //#line 327 "x10/regionarray/DistArray.x10"
            this.dist = d;
            
            
            //#line 328 "x10/regionarray/DistArray.x10"
            ((x10.regionarray.DistArray<$T>)this).localHandle = ((x10.lang.PlaceLocalHandle)(pls));
            
            //#line 329 "x10/regionarray/DistArray.x10"
            final x10.core.Rail t$150873 = ((x10.core.Rail)(((x10.core.Rail<$T>)
                                                              this.getRawFromLocalHandle())));
            
            //#line 329 "x10/regionarray/DistArray.x10"
            ((x10.regionarray.DistArray<$T>)this).raw = ((x10.core.Rail)(t$150873));
            
            //#line 330 "x10/regionarray/DistArray.x10"
            final x10.regionarray.Region t$150874 = ((x10.regionarray.Region)(this.getLocalRegionFromLocalHandle()));
            
            //#line 330 "x10/regionarray/DistArray.x10"
            ((x10.regionarray.DistArray<$T>)this).localRegion = ((x10.regionarray.Region)(t$150874));
        }
        return this;
    }
    
    
    
    //#line 345 "x10/regionarray/DistArray.x10"
    /**
     * Return the element of this array corresponding to the given point.
     * The rank of the given point has to be the same as the rank of this array.
     * If the distribution does not map the given Point to the current place,
     * then a BadPlaceException will be raised.
     * 
     * @param pt the given point
     * @return the element of this array corresponding to the given point.
     * @see #operator(Long)
     * @see #set(T, Point)
     */
    final public $T $apply$G(final x10.lang.Point pt) {
        
        //#line 346 "x10/regionarray/DistArray.x10"
        final x10.regionarray.DistArray this$150543 = ((x10.regionarray.DistArray)(this));
        
        //#line 138 . "x10/regionarray/DistArray.x10"
        final x10.regionarray.Region t$150875 = ((x10.regionarray.Region)(((x10.regionarray.DistArray<$T>)this$150543).localRegion));
        
        //#line 346 "x10/regionarray/DistArray.x10"
        final long offset = t$150875.indexOf$O(((x10.lang.Point)(pt)));
        
        //#line 347 "x10/regionarray/DistArray.x10"
        final boolean t$150876 = ((long) offset) == ((long) -1L);
        
        //#line 347 "x10/regionarray/DistArray.x10"
        if (t$150876) {
            
            //#line 347 "x10/regionarray/DistArray.x10"
            x10.regionarray.DistArray.raisePlaceError(((x10.lang.Point)(pt)));
        }
        
        //#line 348 "x10/regionarray/DistArray.x10"
        final x10.core.Rail t$150877 = ((x10.core.Rail)(this.raw));
        
        //#line 348 "x10/regionarray/DistArray.x10"
        final $T t$150878 = (($T)(((x10.core.Rail<$T>)t$150877).$apply$G((long)(offset))));
        
        //#line 348 "x10/regionarray/DistArray.x10"
        return t$150878;
    }
    
    
    //#line 363 "x10/regionarray/DistArray.x10"
    /**
     * Return the element of this array corresponding to the given index.
     * Only applies to one-dimensional arrays.
     * Functionally equivalent to indexing the array via a one-dimensional point.
     * If the distribution does not map the specified index to the current place,
     * then a BadPlaceException will be raised.
     * 
     * @param i0 the given index in the first dimension
     * @return the element of this array corresponding to the given index.
     * @see #operator(Point)
     * @see #set(T, Long)
     */
    final public $T $apply$G(final long i0) {
        
        //#line 364 "x10/regionarray/DistArray.x10"
        final x10.regionarray.DistArray this$150549 = ((x10.regionarray.DistArray)(this));
        
        //#line 138 . "x10/regionarray/DistArray.x10"
        final x10.regionarray.Region t$150881 = ((x10.regionarray.Region)(((x10.regionarray.DistArray<$T>)this$150549).localRegion));
        
        //#line 364 "x10/regionarray/DistArray.x10"
        final long offset = t$150881.indexOf$O((long)(i0));
        
        //#line 365 "x10/regionarray/DistArray.x10"
        final boolean t$150882 = ((long) offset) == ((long) -1L);
        
        //#line 365 "x10/regionarray/DistArray.x10"
        if (t$150882) {
            
            //#line 365 "x10/regionarray/DistArray.x10"
            x10.regionarray.DistArray.raisePlaceError((long)(i0));
        }
        
        //#line 366 "x10/regionarray/DistArray.x10"
        final x10.core.Rail t$150883 = ((x10.core.Rail)(this.raw));
        
        //#line 366 "x10/regionarray/DistArray.x10"
        final $T t$150884 = (($T)(((x10.core.Rail<$T>)t$150883).$apply$G((long)(offset))));
        
        //#line 366 "x10/regionarray/DistArray.x10"
        return t$150884;
    }
    
    
    //#line 382 "x10/regionarray/DistArray.x10"
    /**
     * Return the element of this array corresponding to the given pair of indices.
     * Only applies to two-dimensional arrays.
     * Functionally equivalent to indexing the array via a two-dimensional point.
     * If the distribution does not map the specified index to the current place,
     * then a BadPlaceException will be raised.
     * 
     * @param i0 the given index in the first dimension
     * @param i1 the given index in the second dimension
     * @return the element of this array corresponding to the given pair of indices.
     * @see #operator(Point)
     * @see #set(T, Long, Long)
     */
    final public $T $apply$G(final long i0, final long i1) {
        
        //#line 383 "x10/regionarray/DistArray.x10"
        final x10.regionarray.DistArray this$150555 = ((x10.regionarray.DistArray)(this));
        
        //#line 138 . "x10/regionarray/DistArray.x10"
        final x10.regionarray.Region t$150887 = ((x10.regionarray.Region)(((x10.regionarray.DistArray<$T>)this$150555).localRegion));
        
        //#line 383 "x10/regionarray/DistArray.x10"
        final long offset = t$150887.indexOf$O((long)(i0), (long)(i1));
        
        //#line 384 "x10/regionarray/DistArray.x10"
        final boolean t$150888 = ((long) offset) == ((long) -1L);
        
        //#line 384 "x10/regionarray/DistArray.x10"
        if (t$150888) {
            
            //#line 384 "x10/regionarray/DistArray.x10"
            x10.regionarray.DistArray.raisePlaceError((long)(i0), (long)(i1));
        }
        
        //#line 385 "x10/regionarray/DistArray.x10"
        final x10.core.Rail t$150889 = ((x10.core.Rail)(this.raw));
        
        //#line 385 "x10/regionarray/DistArray.x10"
        final $T t$150890 = (($T)(((x10.core.Rail<$T>)t$150889).$apply$G((long)(offset))));
        
        //#line 385 "x10/regionarray/DistArray.x10"
        return t$150890;
    }
    
    
    //#line 402 "x10/regionarray/DistArray.x10"
    /**
     * Return the element of this array corresponding to the given triple of indices.
     * Only applies to three-dimensional arrays.
     * Functionally equivalent to indexing the array via a three-dimensional point.
     * If the distribution does not map the specified index to the current place,
     * then a BadPlaceException will be raised.
     *
     * @param i0 the given index in the first dimension
     * @param i1 the given index in the second dimension
     * @param i2 the given index in the third dimension
     * @return the element of this array corresponding to the given triple of indices.
     * @see #operator(Point)
     * @see #set(T, Long, Long, Long)
     */
    final public $T $apply$G(final long i0, final long i1, final long i2) {
        
        //#line 403 "x10/regionarray/DistArray.x10"
        final x10.regionarray.DistArray this$150561 = ((x10.regionarray.DistArray)(this));
        
        //#line 138 . "x10/regionarray/DistArray.x10"
        final x10.regionarray.Region t$150893 = ((x10.regionarray.Region)(((x10.regionarray.DistArray<$T>)this$150561).localRegion));
        
        //#line 403 "x10/regionarray/DistArray.x10"
        final long offset = t$150893.indexOf$O((long)(i0), (long)(i1), (long)(i2));
        
        //#line 404 "x10/regionarray/DistArray.x10"
        final boolean t$150894 = ((long) offset) == ((long) -1L);
        
        //#line 404 "x10/regionarray/DistArray.x10"
        if (t$150894) {
            
            //#line 404 "x10/regionarray/DistArray.x10"
            x10.regionarray.DistArray.raisePlaceError((long)(i0), (long)(i1), (long)(i2));
        }
        
        //#line 405 "x10/regionarray/DistArray.x10"
        final x10.core.Rail t$150895 = ((x10.core.Rail)(this.raw));
        
        //#line 405 "x10/regionarray/DistArray.x10"
        final $T t$150896 = (($T)(((x10.core.Rail<$T>)t$150895).$apply$G((long)(offset))));
        
        //#line 405 "x10/regionarray/DistArray.x10"
        return t$150896;
    }
    
    
    //#line 423 "x10/regionarray/DistArray.x10"
    /**
     * Return the element of this array corresponding to the given quartet of indices.
     * Only applies to four-dimensional arrays.
     * Functionally equivalent to indexing the array via a four-dimensional point.
     * If the distribution does not map the specified index to the current place,
     * then a BadPlaceException will be raised.
     * 
     * @param i0 the given index in the first dimension
     * @param i1 the given index in the second dimension
     * @param i2 the given index in the third dimension
     * @param i3 the given index in the fourth dimension
     * @return the element of this array corresponding to the given quartet of indices.
     * @see #operator(Point)
     * @see #set(T, Long, Long, Long, Long)
     */
    final public $T $apply$G(final long i0, final long i1, final long i2, final long i3) {
        
        //#line 424 "x10/regionarray/DistArray.x10"
        final x10.regionarray.DistArray this$150567 = ((x10.regionarray.DistArray)(this));
        
        //#line 138 . "x10/regionarray/DistArray.x10"
        final x10.regionarray.Region t$150899 = ((x10.regionarray.Region)(((x10.regionarray.DistArray<$T>)this$150567).localRegion));
        
        //#line 424 "x10/regionarray/DistArray.x10"
        final long offset = t$150899.indexOf$O((long)(i0), (long)(i1), (long)(i2), (long)(i3));
        
        //#line 425 "x10/regionarray/DistArray.x10"
        final boolean t$150900 = ((long) offset) == ((long) -1L);
        
        //#line 425 "x10/regionarray/DistArray.x10"
        if (t$150900) {
            
            //#line 425 "x10/regionarray/DistArray.x10"
            x10.regionarray.DistArray.raisePlaceError((long)(i0), (long)(i1), (long)(i2), (long)(i3));
        }
        
        //#line 426 "x10/regionarray/DistArray.x10"
        final x10.core.Rail t$150901 = ((x10.core.Rail)(this.raw));
        
        //#line 426 "x10/regionarray/DistArray.x10"
        final $T t$150902 = (($T)(((x10.core.Rail<$T>)t$150901).$apply$G((long)(offset))));
        
        //#line 426 "x10/regionarray/DistArray.x10"
        return t$150902;
    }
    
    
    //#line 441 "x10/regionarray/DistArray.x10"
    /**
     * Return the element of this array corresponding to the given point,
     * wrapped for periodic boundary conditions.
     * The rank of the given point must be the same as the rank of this array.
     * If the distribution does not map the given Point to the current place,
     * then a BadPlaceException will be raised.
     * 
     * @param pt the given point
     * @return the element of this array corresponding to the given point,
     *   wrapped for periodic boundary conditions.
     * @see #setPeriodic(T, Point)
     */
    final public $T getPeriodic$G(final x10.lang.Point pt) {
        
        //#line 442 "x10/regionarray/DistArray.x10"
        final x10.regionarray.DistArray this$150569 = ((x10.regionarray.DistArray)(this));
        
        //#line 442 "x10/regionarray/DistArray.x10"
        final x10.regionarray.Region l = ((x10.regionarray.Region)(((x10.regionarray.DistArray<$T>)this$150569).localRegion));
        
        //#line 443 "x10/regionarray/DistArray.x10"
        final x10.lang.Point actualPt;
        
        //#line 444 "x10/regionarray/DistArray.x10"
        final boolean t$150906 = l.contains$O(((x10.lang.Point)(pt)));
        
        //#line 444 "x10/regionarray/DistArray.x10"
        if (t$150906) {
            
            //#line 445 "x10/regionarray/DistArray.x10"
            actualPt = ((x10.lang.Point)(pt));
        } else {
            
            //#line 447 "x10/regionarray/DistArray.x10"
            final x10.regionarray.DistArray this$150571 = ((x10.regionarray.DistArray)(this));
            
            //#line 62 . "x10/regionarray/DistArray.x10"
            final x10.regionarray.Dist t$150903 = ((x10.regionarray.Dist)(((x10.regionarray.DistArray<$T>)this$150571).dist));
            
            //#line 62 . "x10/regionarray/DistArray.x10"
            final x10.regionarray.Region t$150904 = ((x10.regionarray.Region)(t$150903.region));
            
            //#line 447 "x10/regionarray/DistArray.x10"
            final x10.lang.Point t$150905 = ((x10.lang.Point)(x10.regionarray.PeriodicBoundaryConditions.wrapPeriodic(((x10.lang.Point)(pt)), ((x10.regionarray.Region)(l)), ((x10.regionarray.Region)(t$150904)))));
            
            //#line 447 "x10/regionarray/DistArray.x10"
            actualPt = ((x10.lang.Point)(t$150905));
        }
        
        //#line 449 "x10/regionarray/DistArray.x10"
        final long offset = l.indexOf$O(((x10.lang.Point)(actualPt)));
        
        //#line 450 "x10/regionarray/DistArray.x10"
        final boolean t$150907 = ((long) offset) == ((long) -1L);
        
        //#line 450 "x10/regionarray/DistArray.x10"
        if (t$150907) {
            
            //#line 450 "x10/regionarray/DistArray.x10"
            x10.regionarray.DistArray.raisePlaceError(((x10.lang.Point)(pt)));
        }
        
        //#line 451 "x10/regionarray/DistArray.x10"
        final x10.regionarray.DistArray this$150629 = ((x10.regionarray.DistArray)(this));
        
        //#line 117 . "x10/regionarray/DistArray.x10"
        final x10.core.Rail t$150908 = ((x10.core.Rail)(((x10.regionarray.DistArray<$T>)this$150629).raw));
        
        //#line 451 "x10/regionarray/DistArray.x10"
        final $T t$150909 = (($T)(((x10.core.Rail<$T>)t$150908).$apply$G((long)(offset))));
        
        //#line 451 "x10/regionarray/DistArray.x10"
        return t$150909;
    }
    
    
    //#line 468 "x10/regionarray/DistArray.x10"
    /**
     * Return the element of this three-dimensional array according to the given
     * indices, wrapped for periodic boundary conditions.
     * Only applies to three-dimensional arrays.
     * Functionally equivalent to getPeriodic(Point{rank==3}).
     * If the distribution does not map the given indices to the current place,
     * then a BadPlaceException will be raised.
     * 
     * @param i0 the index in the first dimension
     * @param i1 the index in the second dimension
     * @param i2 the index in the third dimension
     * @return the element of this array corresponding to the given triple of indices.
     * @see #setPeriodic(T, Point)
     */
    final public $T getPeriodic$G(final long i0, final long i1, final long i2) {
        
        //#line 469 "x10/regionarray/DistArray.x10"
        final x10.regionarray.DistArray this$150635 = ((x10.regionarray.DistArray)(this));
        
        //#line 469 "x10/regionarray/DistArray.x10"
        final x10.regionarray.Region l = ((x10.regionarray.Region)(((x10.regionarray.DistArray<$T>)this$150635).localRegion));
        
        //#line 470 "x10/regionarray/DistArray.x10"
        final long offset;
        
        //#line 471 "x10/regionarray/DistArray.x10"
        final boolean t$150933 = l.contains$O((long)(i0), (long)(i1), (long)(i2));
        
        //#line 471 "x10/regionarray/DistArray.x10"
        if (t$150933) {
            
            //#line 472 "x10/regionarray/DistArray.x10"
            final long t$150912 = l.indexOf$O((long)(i0), (long)(i1), (long)(i2));
            
            //#line 472 "x10/regionarray/DistArray.x10"
            offset = t$150912;
        } else {
            
            //#line 474 "x10/regionarray/DistArray.x10"
            final x10.regionarray.DistArray this$150637 = ((x10.regionarray.DistArray)(this));
            
            //#line 62 . "x10/regionarray/DistArray.x10"
            final x10.regionarray.Dist t$150913 = ((x10.regionarray.Dist)(((x10.regionarray.DistArray<$T>)this$150637).dist));
            
            //#line 474 "x10/regionarray/DistArray.x10"
            final x10.regionarray.Region r = ((x10.regionarray.Region)(t$150913.region));
            
            //#line 475 "x10/regionarray/DistArray.x10"
            final long t$150917 = l.min$O((long)(0L));
            
            //#line 475 "x10/regionarray/DistArray.x10"
            final long t$150918 = l.max$O((long)(0L));
            
            //#line 475 "x10/regionarray/DistArray.x10"
            final long t$150914 = r.max$O((long)(0L));
            
            //#line 475 "x10/regionarray/DistArray.x10"
            final long t$150915 = r.min$O((long)(0L));
            
            //#line 475 "x10/regionarray/DistArray.x10"
            final long t$150916 = ((t$150914) - (((long)(t$150915))));
            
            //#line 475 "x10/regionarray/DistArray.x10"
            final long t$150919 = ((t$150916) + (((long)(1L))));
            
            //#line 475 "x10/regionarray/DistArray.x10"
            final long a0 = x10.regionarray.PeriodicBoundaryConditions.getPeriodicIndex$O((long)(i0), (long)(t$150917), (long)(t$150918), (long)(t$150919));
            
            //#line 476 "x10/regionarray/DistArray.x10"
            final long t$150923 = l.min$O((long)(1L));
            
            //#line 476 "x10/regionarray/DistArray.x10"
            final long t$150924 = l.max$O((long)(1L));
            
            //#line 476 "x10/regionarray/DistArray.x10"
            final long t$150920 = r.max$O((long)(1L));
            
            //#line 476 "x10/regionarray/DistArray.x10"
            final long t$150921 = r.min$O((long)(1L));
            
            //#line 476 "x10/regionarray/DistArray.x10"
            final long t$150922 = ((t$150920) - (((long)(t$150921))));
            
            //#line 476 "x10/regionarray/DistArray.x10"
            final long t$150925 = ((t$150922) + (((long)(1L))));
            
            //#line 476 "x10/regionarray/DistArray.x10"
            final long a1 = x10.regionarray.PeriodicBoundaryConditions.getPeriodicIndex$O((long)(i1), (long)(t$150923), (long)(t$150924), (long)(t$150925));
            
            //#line 477 "x10/regionarray/DistArray.x10"
            final long t$150929 = l.min$O((long)(2L));
            
            //#line 477 "x10/regionarray/DistArray.x10"
            final long t$150930 = l.max$O((long)(2L));
            
            //#line 477 "x10/regionarray/DistArray.x10"
            final long t$150926 = r.max$O((long)(2L));
            
            //#line 477 "x10/regionarray/DistArray.x10"
            final long t$150927 = r.min$O((long)(2L));
            
            //#line 477 "x10/regionarray/DistArray.x10"
            final long t$150928 = ((t$150926) - (((long)(t$150927))));
            
            //#line 477 "x10/regionarray/DistArray.x10"
            final long t$150931 = ((t$150928) + (((long)(1L))));
            
            //#line 477 "x10/regionarray/DistArray.x10"
            final long a2 = x10.regionarray.PeriodicBoundaryConditions.getPeriodicIndex$O((long)(i2), (long)(t$150929), (long)(t$150930), (long)(t$150931));
            
            //#line 478 "x10/regionarray/DistArray.x10"
            final long t$150932 = l.indexOf$O((long)(a0), (long)(a1), (long)(a2));
            
            //#line 478 "x10/regionarray/DistArray.x10"
            offset = t$150932;
        }
        
        //#line 480 "x10/regionarray/DistArray.x10"
        final boolean t$150934 = ((long) offset) == ((long) -1L);
        
        //#line 480 "x10/regionarray/DistArray.x10"
        if (t$150934) {
            
            //#line 480 "x10/regionarray/DistArray.x10"
            x10.regionarray.DistArray.raisePlaceError((long)(i0), (long)(i1), (long)(i2));
        }
        
        //#line 481 "x10/regionarray/DistArray.x10"
        final x10.regionarray.DistArray this$150639 = ((x10.regionarray.DistArray)(this));
        
        //#line 117 . "x10/regionarray/DistArray.x10"
        final x10.core.Rail t$150935 = ((x10.core.Rail)(((x10.regionarray.DistArray<$T>)this$150639).raw));
        
        //#line 481 "x10/regionarray/DistArray.x10"
        final $T t$150936 = (($T)(((x10.core.Rail<$T>)t$150935).$apply$G((long)(offset))));
        
        //#line 481 "x10/regionarray/DistArray.x10"
        return t$150936;
    }
    
    
    //#line 497 "x10/regionarray/DistArray.x10"
    /**
     * Set the element of this array corresponding to the given point to the given value.
     * Return the new value of the element.
     * The rank of the given point has to be the same as the rank of this array.
     * If the distribution does not map the specified index to the current place,
     * then a BadPlaceException will be raised.
     * 
     * @param v the given value
     * @param pt the given point
     * @return the new value of the element of this array corresponding to the given point.
     * @see #operator(Point)
     * @see #set(T, Long)
     */
    final public $T $set__1x10$regionarray$DistArray$$T$G(final x10.lang.Point pt, final $T v) {
        
        //#line 498 "x10/regionarray/DistArray.x10"
        final x10.regionarray.Dist t$150937 = ((x10.regionarray.Dist)(this.dist));
        
        //#line 498 "x10/regionarray/DistArray.x10"
        final x10.lang.Place t$150938 = t$150937.$apply(((x10.lang.Point)(pt)));
        
        //#line 498 "x10/regionarray/DistArray.x10"
        final boolean t$150939 = (!x10.rtt.Equality.equalsequals((t$150938),(x10.x10rt.X10RT.here())));
        
        //#line 498 "x10/regionarray/DistArray.x10"
        if (t$150939) {
            
            //#line 498 "x10/regionarray/DistArray.x10"
            x10.regionarray.DistArray.raisePlaceError(((x10.lang.Point)(pt)));
        }
        
        //#line 499 "x10/regionarray/DistArray.x10"
        final x10.regionarray.DistArray this$150641 = ((x10.regionarray.DistArray)(this));
        
        //#line 138 . "x10/regionarray/DistArray.x10"
        final x10.regionarray.Region t$150940 = ((x10.regionarray.Region)(((x10.regionarray.DistArray<$T>)this$150641).localRegion));
        
        //#line 499 "x10/regionarray/DistArray.x10"
        final long offset = t$150940.indexOf$O(((x10.lang.Point)(pt)));
        
        //#line 500 "x10/regionarray/DistArray.x10"
        final x10.core.Rail t$150941 = ((x10.core.Rail)(this.raw));
        
        //#line 500 "x10/regionarray/DistArray.x10"
        ((x10.core.Rail<$T>)t$150941).$set__1x10$lang$Rail$$T$G((long)(offset), (($T)(v)));
        
        //#line 501 "x10/regionarray/DistArray.x10"
        return v;
    }
    
    
    //#line 518 "x10/regionarray/DistArray.x10"
    /**
     * Set the element of this array corresponding to the given index to the given value.
     * Return the new value of the element.
     * Only applies to one-dimensional arrays.
     * Functionally equivalent to setting the array via a one-dimensional point.
     * If the distribution does not map the specified index to the current place,
     * then a BadPlaceException will be raised.
     * 
     * @param v the given value
     * @param i0 the given index in the first dimension
     * @return the new value of the element of this array corresponding to the given index.
     * @see #operator(Long)
     * @see #set(T, Point)
     */
    final public $T $set__1x10$regionarray$DistArray$$T$G(final long i0, final $T v) {
        
        //#line 519 "x10/regionarray/DistArray.x10"
        final x10.regionarray.Dist t$150944 = ((x10.regionarray.Dist)(this.dist));
        
        //#line 519 "x10/regionarray/DistArray.x10"
        final x10.lang.Place t$150945 = t$150944.$apply((long)(i0));
        
        //#line 519 "x10/regionarray/DistArray.x10"
        final boolean t$150946 = (!x10.rtt.Equality.equalsequals((t$150945),(x10.x10rt.X10RT.here())));
        
        //#line 519 "x10/regionarray/DistArray.x10"
        if (t$150946) {
            
            //#line 519 "x10/regionarray/DistArray.x10"
            x10.regionarray.DistArray.raisePlaceError((long)(i0));
        }
        
        //#line 520 "x10/regionarray/DistArray.x10"
        final x10.regionarray.DistArray this$150647 = ((x10.regionarray.DistArray)(this));
        
        //#line 138 . "x10/regionarray/DistArray.x10"
        final x10.regionarray.Region t$150947 = ((x10.regionarray.Region)(((x10.regionarray.DistArray<$T>)this$150647).localRegion));
        
        //#line 520 "x10/regionarray/DistArray.x10"
        final long offset = t$150947.indexOf$O((long)(i0));
        
        //#line 521 "x10/regionarray/DistArray.x10"
        final x10.core.Rail t$150948 = ((x10.core.Rail)(this.raw));
        
        //#line 521 "x10/regionarray/DistArray.x10"
        ((x10.core.Rail<$T>)t$150948).$set__1x10$lang$Rail$$T$G((long)(offset), (($T)(v)));
        
        //#line 522 "x10/regionarray/DistArray.x10"
        return v;
    }
    
    
    //#line 540 "x10/regionarray/DistArray.x10"
    /**
     * Set the element of this array corresponding to the given pair of indices to the given value.
     * Return the new value of the element.
     * Only applies to two-dimensional arrays.
     * Functionally equivalent to setting the array via a two-dimensional point.
     * If the distribution does not map the specified index to the current place,
     * then a BadPlaceException will be raised.
     * 
     * @param v the given value
     * @param i0 the given index in the first dimension
     * @param i1 the given index in the second dimension
     * @return the new value of the element of this array corresponding to the given pair of indices.
     * @see #operator(Long, Long)
     * @see #set(T, Point)
     */
    final public $T $set__2x10$regionarray$DistArray$$T$G(final long i0, final long i1, final $T v) {
        
        //#line 541 "x10/regionarray/DistArray.x10"
        final x10.regionarray.Dist t$150951 = ((x10.regionarray.Dist)(this.dist));
        
        //#line 541 "x10/regionarray/DistArray.x10"
        final x10.lang.Place t$150952 = t$150951.$apply((long)(i0), (long)(i1));
        
        //#line 541 "x10/regionarray/DistArray.x10"
        final boolean t$150953 = (!x10.rtt.Equality.equalsequals((t$150952),(x10.x10rt.X10RT.here())));
        
        //#line 541 "x10/regionarray/DistArray.x10"
        if (t$150953) {
            
            //#line 541 "x10/regionarray/DistArray.x10"
            x10.regionarray.DistArray.raisePlaceError((long)(i0), (long)(i1));
        }
        
        //#line 542 "x10/regionarray/DistArray.x10"
        final x10.regionarray.DistArray this$150653 = ((x10.regionarray.DistArray)(this));
        
        //#line 138 . "x10/regionarray/DistArray.x10"
        final x10.regionarray.Region t$150954 = ((x10.regionarray.Region)(((x10.regionarray.DistArray<$T>)this$150653).localRegion));
        
        //#line 542 "x10/regionarray/DistArray.x10"
        final long offset = t$150954.indexOf$O((long)(i0), (long)(i1));
        
        //#line 543 "x10/regionarray/DistArray.x10"
        final x10.core.Rail t$150955 = ((x10.core.Rail)(this.raw));
        
        //#line 543 "x10/regionarray/DistArray.x10"
        ((x10.core.Rail<$T>)t$150955).$set__1x10$lang$Rail$$T$G((long)(offset), (($T)(v)));
        
        //#line 544 "x10/regionarray/DistArray.x10"
        return v;
    }
    
    
    //#line 563 "x10/regionarray/DistArray.x10"
    /**
     * Set the element of this array corresponding to the given triple of indices to the given value.
     * Return the new value of the element.
     * Only applies to three-dimensional arrays.
     * Functionally equivalent to setting the array via a three-dimensional point.
     * If the distribution does not map the specified index to the current place,
     * then a BadPlaceException will be raised.
     * 
     * @param v the given value
     * @param i0 the given index in the first dimension
     * @param i1 the given index in the second dimension
     * @param i2 the given index in the third dimension
     * @return the new value of the element of this array corresponding to the given triple of indices.
     * @see #operator(Long, Long, Long)
     * @see #set(T, Point)
     */
    final public $T $set__3x10$regionarray$DistArray$$T$G(final long i0, final long i1, final long i2, final $T v) {
        
        //#line 564 "x10/regionarray/DistArray.x10"
        final x10.regionarray.Dist t$150958 = ((x10.regionarray.Dist)(this.dist));
        
        //#line 564 "x10/regionarray/DistArray.x10"
        final x10.lang.Place t$150959 = t$150958.$apply((long)(i0), (long)(i1), (long)(i2));
        
        //#line 564 "x10/regionarray/DistArray.x10"
        final boolean t$150960 = (!x10.rtt.Equality.equalsequals((t$150959),(x10.x10rt.X10RT.here())));
        
        //#line 564 "x10/regionarray/DistArray.x10"
        if (t$150960) {
            
            //#line 564 "x10/regionarray/DistArray.x10"
            x10.regionarray.DistArray.raisePlaceError((long)(i0), (long)(i1), (long)(i2));
        }
        
        //#line 565 "x10/regionarray/DistArray.x10"
        final x10.regionarray.DistArray this$150659 = ((x10.regionarray.DistArray)(this));
        
        //#line 138 . "x10/regionarray/DistArray.x10"
        final x10.regionarray.Region t$150961 = ((x10.regionarray.Region)(((x10.regionarray.DistArray<$T>)this$150659).localRegion));
        
        //#line 565 "x10/regionarray/DistArray.x10"
        final long offset = t$150961.indexOf$O((long)(i0), (long)(i1), (long)(i2));
        
        //#line 566 "x10/regionarray/DistArray.x10"
        final x10.core.Rail t$150962 = ((x10.core.Rail)(this.raw));
        
        //#line 566 "x10/regionarray/DistArray.x10"
        ((x10.core.Rail<$T>)t$150962).$set__1x10$lang$Rail$$T$G((long)(offset), (($T)(v)));
        
        //#line 567 "x10/regionarray/DistArray.x10"
        return v;
    }
    
    
    //#line 588 "x10/regionarray/DistArray.x10"
    /**
     * Set the element of this array corresponding to the given quartet of indices to the given value.
     * Return the new value of the element.
     * Only applies to four-dimensional arrays.
     * Functionally equivalent to setting the array via a four-dimensional point.
     * If the distribution does not map the specified index to the current place,
     * then a BadPlaceException will be raised.
     * 
     * 
     * @param v the given value
     * @param i0 the given index in the first dimension
     * @param i1 the given index in the second dimension
     * @param i2 the given index in the third dimension
     * @param i3 the given index in the fourth dimension
     * @return the new value of the element of this array corresponding to the given quartet of indices.
     * @see #operator(Long, Long, Long, Long)
     * @see #set(T, Point)
     */
    final public $T $set__4x10$regionarray$DistArray$$T$G(final long i0, final long i1, final long i2, final long i3, final $T v) {
        
        //#line 589 "x10/regionarray/DistArray.x10"
        final x10.regionarray.Dist t$150965 = ((x10.regionarray.Dist)(this.dist));
        
        //#line 589 "x10/regionarray/DistArray.x10"
        final x10.lang.Place t$150966 = t$150965.$apply((long)(i0), (long)(i1), (long)(i2), (long)(i3));
        
        //#line 589 "x10/regionarray/DistArray.x10"
        final boolean t$150967 = (!x10.rtt.Equality.equalsequals((t$150966),(x10.x10rt.X10RT.here())));
        
        //#line 589 "x10/regionarray/DistArray.x10"
        if (t$150967) {
            
            //#line 589 "x10/regionarray/DistArray.x10"
            x10.regionarray.DistArray.raisePlaceError((long)(i0), (long)(i1), (long)(i2), (long)(i3));
        }
        
        //#line 590 "x10/regionarray/DistArray.x10"
        final x10.regionarray.DistArray this$150665 = ((x10.regionarray.DistArray)(this));
        
        //#line 138 . "x10/regionarray/DistArray.x10"
        final x10.regionarray.Region t$150968 = ((x10.regionarray.Region)(((x10.regionarray.DistArray<$T>)this$150665).localRegion));
        
        //#line 590 "x10/regionarray/DistArray.x10"
        final long offset = t$150968.indexOf$O((long)(i0), (long)(i1), (long)(i2), (long)(i3));
        
        //#line 591 "x10/regionarray/DistArray.x10"
        final x10.core.Rail t$150969 = ((x10.core.Rail)(this.raw));
        
        //#line 591 "x10/regionarray/DistArray.x10"
        ((x10.core.Rail<$T>)t$150969).$set__1x10$lang$Rail$$T$G((long)(offset), (($T)(v)));
        
        //#line 592 "x10/regionarray/DistArray.x10"
        return v;
    }
    
    
    //#line 609 "x10/regionarray/DistArray.x10"
    /**
     * Set the element of this array corresponding to the given point (wrapped
     * for periodic boundary conditions) to the given value.
     * Return the new value of the element.
     * The rank of the given point must be the same as the rank of this array.
     * If the dist does not map the specified index to the current place,
     * then a BadPlaceException will be raised.
     * 
     * @param v the given value
     * @param pt the given point
     * @return the new value of the element of this array corresponding to the
     *   given point
     * @see #getPeriodic(Point)
     */
    final public $T setPeriodic__1x10$regionarray$DistArray$$T$G(final x10.lang.Point pt, final $T v) {
        
        //#line 610 "x10/regionarray/DistArray.x10"
        final x10.regionarray.DistArray this$150667 = ((x10.regionarray.DistArray)(this));
        
        //#line 610 "x10/regionarray/DistArray.x10"
        final x10.regionarray.Region l = ((x10.regionarray.Region)(((x10.regionarray.DistArray<$T>)this$150667).localRegion));
        
        //#line 611 "x10/regionarray/DistArray.x10"
        final x10.lang.Point actualPt;
        
        //#line 612 "x10/regionarray/DistArray.x10"
        final boolean t$150973 = l.contains$O(((x10.lang.Point)(pt)));
        
        //#line 612 "x10/regionarray/DistArray.x10"
        if (t$150973) {
            
            //#line 613 "x10/regionarray/DistArray.x10"
            actualPt = ((x10.lang.Point)(pt));
        } else {
            
            //#line 615 "x10/regionarray/DistArray.x10"
            final x10.regionarray.DistArray this$150669 = ((x10.regionarray.DistArray)(this));
            
            //#line 62 . "x10/regionarray/DistArray.x10"
            final x10.regionarray.Dist t$150970 = ((x10.regionarray.Dist)(((x10.regionarray.DistArray<$T>)this$150669).dist));
            
            //#line 62 . "x10/regionarray/DistArray.x10"
            final x10.regionarray.Region t$150971 = ((x10.regionarray.Region)(t$150970.region));
            
            //#line 615 "x10/regionarray/DistArray.x10"
            final x10.lang.Point t$150972 = ((x10.lang.Point)(x10.regionarray.PeriodicBoundaryConditions.wrapPeriodic(((x10.lang.Point)(pt)), ((x10.regionarray.Region)(l)), ((x10.regionarray.Region)(t$150971)))));
            
            //#line 615 "x10/regionarray/DistArray.x10"
            actualPt = ((x10.lang.Point)(t$150972));
        }
        
        //#line 617 "x10/regionarray/DistArray.x10"
        final x10.regionarray.Dist t$150974 = ((x10.regionarray.Dist)(this.dist));
        
        //#line 617 "x10/regionarray/DistArray.x10"
        final x10.lang.Place t$150975 = t$150974.$apply(((x10.lang.Point)(actualPt)));
        
        //#line 617 "x10/regionarray/DistArray.x10"
        final boolean t$150976 = (!x10.rtt.Equality.equalsequals((t$150975),(x10.x10rt.X10RT.here())));
        
        //#line 617 "x10/regionarray/DistArray.x10"
        if (t$150976) {
            
            //#line 617 "x10/regionarray/DistArray.x10"
            x10.regionarray.DistArray.raisePlaceError(((x10.lang.Point)(pt)));
        }
        
        //#line 618 "x10/regionarray/DistArray.x10"
        final long offset = l.indexOf$O(((x10.lang.Point)(actualPt)));
        
        //#line 619 "x10/regionarray/DistArray.x10"
        final x10.regionarray.DistArray this$150671 = ((x10.regionarray.DistArray)(this));
        
        //#line 117 . "x10/regionarray/DistArray.x10"
        final x10.core.Rail t$150977 = ((x10.core.Rail)(((x10.regionarray.DistArray<$T>)this$150671).raw));
        
        //#line 619 "x10/regionarray/DistArray.x10"
        ((x10.core.Rail<$T>)t$150977).$set__1x10$lang$Rail$$T$G((long)(offset), (($T)(v)));
        
        //#line 620 "x10/regionarray/DistArray.x10"
        return v;
    }
    
    
    //#line 636 "x10/regionarray/DistArray.x10"
    /**
     * Return a DistArray that accesses the same backing storage
     * as this array, but only over the Points in the argument
     * distribution.</p>
     * 
     * For this operation to be semantically sound, it should
     * be the case that for every point p in d, 
     * <code>this.dist(here).indexOf(p) == d(here).indexOf(p)</code>.
     * This invariant is not statically or dynamically checked;
     * but must be ensured by the callers of this API. 
     * 
     * @param d the Dist to use as the restriction
     */
    public x10.regionarray.DistArray restriction(final x10.regionarray.Dist d) {
        
        //#line 637 "x10/regionarray/DistArray.x10"
        final x10.regionarray.DistArray alloc$150409 = ((x10.regionarray.DistArray)(new x10.regionarray.DistArray<$T>((java.lang.System[]) null, $T)));
        
        //#line 637 "x10/regionarray/DistArray.x10"
        alloc$150409.x10$regionarray$DistArray$$init$S(((x10.regionarray.DistArray)(this)), ((x10.regionarray.Dist)(d)), (x10.regionarray.DistArray.__0$1x10$regionarray$DistArray$$T$2) null);
        
        //#line 637 "x10/regionarray/DistArray.x10"
        final x10.regionarray.DistArray t$149607 = ((x10.regionarray.DistArray<$T>)
                                                     alloc$150409);
        
        //#line 637 "x10/regionarray/DistArray.x10"
        final x10.regionarray.Dist t$150978 = ((x10.regionarray.Dist)(((x10.regionarray.DistArray<$T>)t$149607).dist));
        
        //#line 637 "x10/regionarray/DistArray.x10"
        final x10.regionarray.Region t$150979 = ((x10.regionarray.Region)(t$150978.region));
        
        //#line 637 "x10/regionarray/DistArray.x10"
        final long t$150982 = t$150979.rank;
        
        //#line 637 "x10/regionarray/DistArray.x10"
        final x10.regionarray.Dist t$150980 = ((x10.regionarray.Dist)(x10.regionarray.DistArray.this.dist));
        
        //#line 637 "x10/regionarray/DistArray.x10"
        final x10.regionarray.Region t$150981 = ((x10.regionarray.Region)(t$150980.region));
        
        //#line 637 "x10/regionarray/DistArray.x10"
        final long t$150983 = t$150981.rank;
        
        //#line 637 "x10/regionarray/DistArray.x10"
        final boolean t$150984 = ((long) t$150982) == ((long) t$150983);
        
        //#line 637 "x10/regionarray/DistArray.x10"
        final boolean t$150986 = !(t$150984);
        
        //#line 637 "x10/regionarray/DistArray.x10"
        if (t$150986) {
            
            //#line 637 "x10/regionarray/DistArray.x10"
            final x10.lang.FailedDynamicCheckException t$150985 = new x10.lang.FailedDynamicCheckException("x10.regionarray.DistArray[T]{self.dist.region.rank==this(:x10.regionarray.DistArray).dist.region.rank}");
            
            //#line 637 "x10/regionarray/DistArray.x10"
            throw t$150985;
        }
        
        //#line 637 "x10/regionarray/DistArray.x10"
        return t$149607;
    }
    
    
    //#line 648 "x10/regionarray/DistArray.x10"
    /**
     * Return a DistArray that is defined over the same distribution
     * and backing storage as this DistArray instance, but is 
     * restricted to only allowing access to those points that are
     * contained in the argument region r.
     * 
     * @param r the Region to which to restrict the array
     */
    public x10.regionarray.DistArray restriction(final x10.regionarray.Region r) {
        
        //#line 649 "x10/regionarray/DistArray.x10"
        final x10.regionarray.Dist t$150987 = ((x10.regionarray.Dist)(this.dist));
        
        //#line 649 "x10/regionarray/DistArray.x10"
        final x10.regionarray.Dist t$150988 = ((x10.regionarray.Dist)(t$150987.restriction(((x10.regionarray.Region)(r)))));
        
        //#line 649 "x10/regionarray/DistArray.x10"
        final x10.regionarray.Dist t$149609 = ((x10.regionarray.Dist)
                                                t$150988);
        
        //#line 649 "x10/regionarray/DistArray.x10"
        final x10.regionarray.Region t$150989 = ((x10.regionarray.Region)(t$149609.region));
        
        //#line 649 "x10/regionarray/DistArray.x10"
        final long t$150992 = t$150989.rank;
        
        //#line 649 "x10/regionarray/DistArray.x10"
        final x10.regionarray.Dist t$150990 = ((x10.regionarray.Dist)(x10.regionarray.DistArray.this.dist));
        
        //#line 649 "x10/regionarray/DistArray.x10"
        final x10.regionarray.Region t$150991 = ((x10.regionarray.Region)(t$150990.region));
        
        //#line 649 "x10/regionarray/DistArray.x10"
        final long t$150993 = t$150991.rank;
        
        //#line 649 "x10/regionarray/DistArray.x10"
        final boolean t$150994 = ((long) t$150992) == ((long) t$150993);
        
        //#line 649 "x10/regionarray/DistArray.x10"
        final boolean t$150996 = !(t$150994);
        
        //#line 649 "x10/regionarray/DistArray.x10"
        if (t$150996) {
            
            //#line 649 "x10/regionarray/DistArray.x10"
            final x10.lang.FailedDynamicCheckException t$150995 = new x10.lang.FailedDynamicCheckException("x10.regionarray.Dist{self.region.rank==this(:x10.regionarray.DistArray).dist.region.rank}");
            
            //#line 649 "x10/regionarray/DistArray.x10"
            throw t$150995;
        }
        
        //#line 649 "x10/regionarray/DistArray.x10"
        final x10.regionarray.DistArray t$150997 = ((x10.regionarray.DistArray)(((x10.regionarray.DistArray<$T>)
                                                                                  this.restriction(((x10.regionarray.Dist)(t$149609))))));
        
        //#line 649 "x10/regionarray/DistArray.x10"
        return t$150997;
    }
    
    
    //#line 660 "x10/regionarray/DistArray.x10"
    /**
     * Return a DistArray that is defined over the same distribution
     * and backing storage as this DistArray instance, but is 
     * restricted to only allowing access to those points that are
     * mapped by the defining distripution to the argument Place. 
     * 
     * @param p the Place to which to restrict the array
     */
    public x10.regionarray.DistArray restriction(final x10.lang.Place p) {
        
        //#line 661 "x10/regionarray/DistArray.x10"
        final x10.regionarray.Dist t$150998 = ((x10.regionarray.Dist)(this.dist));
        
        //#line 661 "x10/regionarray/DistArray.x10"
        final x10.regionarray.Dist t$150999 = ((x10.regionarray.Dist)(t$150998.restriction(((x10.lang.Place)(p)))));
        
        //#line 661 "x10/regionarray/DistArray.x10"
        final x10.regionarray.Dist t$149611 = ((x10.regionarray.Dist)
                                                t$150999);
        
        //#line 661 "x10/regionarray/DistArray.x10"
        final x10.regionarray.Region t$151000 = ((x10.regionarray.Region)(t$149611.region));
        
        //#line 661 "x10/regionarray/DistArray.x10"
        final long t$151003 = t$151000.rank;
        
        //#line 661 "x10/regionarray/DistArray.x10"
        final x10.regionarray.Dist t$151001 = ((x10.regionarray.Dist)(x10.regionarray.DistArray.this.dist));
        
        //#line 661 "x10/regionarray/DistArray.x10"
        final x10.regionarray.Region t$151002 = ((x10.regionarray.Region)(t$151001.region));
        
        //#line 661 "x10/regionarray/DistArray.x10"
        final long t$151004 = t$151002.rank;
        
        //#line 661 "x10/regionarray/DistArray.x10"
        final boolean t$151005 = ((long) t$151003) == ((long) t$151004);
        
        //#line 661 "x10/regionarray/DistArray.x10"
        final boolean t$151007 = !(t$151005);
        
        //#line 661 "x10/regionarray/DistArray.x10"
        if (t$151007) {
            
            //#line 661 "x10/regionarray/DistArray.x10"
            final x10.lang.FailedDynamicCheckException t$151006 = new x10.lang.FailedDynamicCheckException("x10.regionarray.Dist{self.region.rank==this(:x10.regionarray.DistArray).dist.region.rank}");
            
            //#line 661 "x10/regionarray/DistArray.x10"
            throw t$151006;
        }
        
        //#line 661 "x10/regionarray/DistArray.x10"
        final x10.regionarray.DistArray t$151008 = ((x10.regionarray.DistArray)(((x10.regionarray.DistArray<$T>)
                                                                                  this.restriction(((x10.regionarray.Dist)(t$149611))))));
        
        //#line 661 "x10/regionarray/DistArray.x10"
        return t$151008;
    }
    
    
    //#line 672 "x10/regionarray/DistArray.x10"
    /**
     * Return a DistArray that is defined over the same distribution
     * and backing storage as this DistArray instance, but is 
     * restricted to only allowing access to those points that are
     * contained in the argument region r.
     * 
     * @param r the Region to which to restrict the array
     */
    public x10.regionarray.DistArray $bar(final x10.regionarray.Region r) {
        
        //#line 672 "x10/regionarray/DistArray.x10"
        final x10.regionarray.DistArray t$151009 = ((x10.regionarray.DistArray)(((x10.regionarray.DistArray<$T>)
                                                                                  this.restriction(((x10.regionarray.Region)(r))))));
        
        //#line 672 "x10/regionarray/DistArray.x10"
        return t$151009;
    }
    
    
    //#line 682 "x10/regionarray/DistArray.x10"
    /**
     * Return a DistArray that is defined over the same distribution
     * and backing storage as this DistArray instance, but is 
     * restricted to only allowing access to those points that are
     * mapped by the defining distripution to the argument Place. 
     * 
     * @param p the Place to which to restrict the array
     */
    public x10.regionarray.DistArray $bar(final x10.lang.Place p) {
        
        //#line 682 "x10/regionarray/DistArray.x10"
        final x10.regionarray.DistArray t$151010 = ((x10.regionarray.DistArray)(((x10.regionarray.DistArray<$T>)
                                                                                  this.restriction(((x10.lang.Place)(p))))));
        
        //#line 682 "x10/regionarray/DistArray.x10"
        return t$151010;
    }
    
    
    //#line 696 "x10/regionarray/DistArray.x10"
    /**
     * Returns the specified region of this array as a new Array object.
     * 
     * @param region the region of the array to copy to this array
     * @see Region#indexOf
     * @throws ArrayIndexOutOfBoundsException if the specified region is not
     *        contained in this array
     */
    public x10.regionarray.Array getPatch(final x10.regionarray.Region r) {
        
        //#line 697 "x10/regionarray/DistArray.x10"
        final x10.regionarray.Dist t$151011 = ((x10.regionarray.Dist)(this.dist));
        
        //#line 697 "x10/regionarray/DistArray.x10"
        final x10.regionarray.Region regionHere = ((x10.regionarray.Region)(t$151011.get(((x10.lang.Place)(x10.x10rt.X10RT.here())))));
        
        //#line 48 . "x10/regionarray/Region.x10"
        final boolean t$151012 = regionHere.rect;
        
        //#line 698 "x10/regionarray/DistArray.x10"
        final boolean t$151015 = !(t$151012);
        
        //#line 698 "x10/regionarray/DistArray.x10"
        if (t$151015) {
            
            //#line 699 "x10/regionarray/DistArray.x10"
            final java.lang.String t$151013 = (("DistArray.getPatch not supported for non-rectangular region: ") + (regionHere));
            
            //#line 699 "x10/regionarray/DistArray.x10"
            final java.lang.UnsupportedOperationException t$151014 = ((java.lang.UnsupportedOperationException)(new java.lang.UnsupportedOperationException(t$151013)));
            
            //#line 699 "x10/regionarray/DistArray.x10"
            throw t$151014;
        }
        
        //#line 701 "x10/regionarray/DistArray.x10"
        final boolean t$151016 = regionHere.contains$O(((x10.regionarray.Region)(r)));
        
        //#line 701 "x10/regionarray/DistArray.x10"
        final boolean t$151021 = !(t$151016);
        
        //#line 701 "x10/regionarray/DistArray.x10"
        if (t$151021) {
            
            //#line 702 "x10/regionarray/DistArray.x10"
            final java.lang.String t$151017 = (("region to copy: ") + (r));
            
            //#line 702 "x10/regionarray/DistArray.x10"
            final java.lang.String t$151018 = ((t$151017) + (" not contained in local region: "));
            
            //#line 702 "x10/regionarray/DistArray.x10"
            final java.lang.String t$151019 = ((t$151018) + (regionHere));
            
            //#line 702 "x10/regionarray/DistArray.x10"
            final java.lang.ArrayIndexOutOfBoundsException t$151020 = ((java.lang.ArrayIndexOutOfBoundsException)(new java.lang.ArrayIndexOutOfBoundsException(t$151019)));
            
            //#line 702 "x10/regionarray/DistArray.x10"
            throw t$151020;
        }
        
        //#line 705 "x10/regionarray/DistArray.x10"
        final x10.core.fun.Fun_0_1 min = regionHere.min();
        
        //#line 706 "x10/regionarray/DistArray.x10"
        regionHere.max();
        
        //#line 707 "x10/regionarray/DistArray.x10"
        final x10.regionarray.DistArray this$150674 = ((x10.regionarray.DistArray)(this));
        
        //#line 67 . "x10/regionarray/DistArray.x10"
        final x10.regionarray.Dist this$150676 = ((x10.regionarray.Dist)(((x10.regionarray.DistArray<$T>)this$150674).dist));
        
        //#line 38 .. "x10/regionarray/Dist.x10"
        final x10.regionarray.Region t$151022 = ((x10.regionarray.Region)(this$150676.region));
        
        //#line 38 .. "x10/regionarray/Dist.x10"
        final long t$151027 = t$151022.rank;
        
        //#line 707 "x10/regionarray/DistArray.x10"
        final x10.core.fun.Fun_0_1 t$151028 = ((x10.core.fun.Fun_0_1)(new x10.regionarray.DistArray.$Closure$227<$T>($T, regionHere)));
        
        //#line 707 "x10/regionarray/DistArray.x10"
        final x10.core.Rail delta = ((x10.core.Rail)(new x10.core.Rail<x10.core.Long>(x10.rtt.Types.LONG, ((long)(t$151027)), ((x10.core.fun.Fun_0_1)(t$151028)), (x10.core.Rail.__1$1x10$lang$Long$3x10$lang$Rail$$T$2) null)));
        
        //#line 708 "x10/regionarray/DistArray.x10"
        final long t$151029 = r.size$O();
        
        //#line 708 "x10/regionarray/DistArray.x10"
        final x10.core.Rail patchRaw = ((x10.core.Rail)(x10.core.Rail.<$T>makeUnsafe($T, ((long)(t$151029)), false)));
        
        //#line 709 "x10/regionarray/DistArray.x10"
        long patchIndex = 0L;
        
        //#line 710 "x10/regionarray/DistArray.x10"
        final x10.lang.Iterator p$151427 = r.iterator();
        {
            
            //#line 710 "x10/regionarray/DistArray.x10"
            final long[] delta$value$151713 = ((long[])delta.value);
            
            //#line 710 "x10/regionarray/DistArray.x10"
            for (;
                 true;
                 ) {
                
                //#line 710 "x10/regionarray/DistArray.x10"
                final boolean t$151428 = ((x10.lang.Iterator<x10.lang.Point>)p$151427).hasNext$O();
                
                //#line 710 "x10/regionarray/DistArray.x10"
                if (!(t$151428)) {
                    
                    //#line 710 "x10/regionarray/DistArray.x10"
                    break;
                }
                
                //#line 710 "x10/regionarray/DistArray.x10"
                final x10.lang.Point p$151409 = ((x10.lang.Point)(((x10.lang.Iterator<x10.lang.Point>)p$151427).next$G()));
                
                //#line 711 "x10/regionarray/DistArray.x10"
                final long t$151410 = p$151409.$apply$O((long)(0L));
                
                //#line 711 "x10/regionarray/DistArray.x10"
                final long t$151411 = x10.core.Long.$unbox(((x10.core.fun.Fun_0_1<x10.core.Long,x10.core.Long>)min).$apply(x10.core.Long.$box(0L), x10.rtt.Types.LONG));
                
                //#line 711 "x10/regionarray/DistArray.x10"
                long offset$151412 = ((t$151410) - (((long)(t$151411))));
                
                //#line 712 "x10/regionarray/DistArray.x10"
                long i$151402 = 1L;
                {
                    
                    //#line 712 "x10/regionarray/DistArray.x10"
                    for (;
                         true;
                         ) {
                        
                        //#line 712 "x10/regionarray/DistArray.x10"
                        final x10.regionarray.DistArray this$151404 = ((x10.regionarray.DistArray)(this));
                        
                        //#line 67 . "x10/regionarray/DistArray.x10"
                        final x10.regionarray.Dist this$151405 = ((x10.regionarray.Dist)(((x10.regionarray.DistArray<$T>)this$151404).dist));
                        
                        //#line 38 .. "x10/regionarray/Dist.x10"
                        final x10.regionarray.Region t$151406 = ((x10.regionarray.Region)(this$151405.region));
                        
                        //#line 38 .. "x10/regionarray/Dist.x10"
                        final long t$151407 = t$151406.rank;
                        
                        //#line 712 "x10/regionarray/DistArray.x10"
                        final boolean t$151408 = ((i$151402) < (((long)(t$151407))));
                        
                        //#line 712 "x10/regionarray/DistArray.x10"
                        if (!(t$151408)) {
                            
                            //#line 712 "x10/regionarray/DistArray.x10"
                            break;
                        }
                        
                        //#line 713 "x10/regionarray/DistArray.x10"
                        final long t$151392 = ((long)delta$value$151713[(int)i$151402]);
                        
                        //#line 713 "x10/regionarray/DistArray.x10"
                        final long t$151393 = ((offset$151412) * (((long)(t$151392))));
                        
                        //#line 713 "x10/regionarray/DistArray.x10"
                        final long t$151395 = p$151409.$apply$O((long)(i$151402));
                        
                        //#line 713 "x10/regionarray/DistArray.x10"
                        final long t$151396 = ((t$151393) + (((long)(t$151395))));
                        
                        //#line 713 "x10/regionarray/DistArray.x10"
                        final long t$151398 = x10.core.Long.$unbox(((x10.core.fun.Fun_0_1<x10.core.Long,x10.core.Long>)min).$apply(x10.core.Long.$box(i$151402), x10.rtt.Types.LONG));
                        
                        //#line 713 "x10/regionarray/DistArray.x10"
                        final long t$151399 = ((t$151396) - (((long)(t$151398))));
                        
                        //#line 713 "x10/regionarray/DistArray.x10"
                        offset$151412 = t$151399;
                        
                        //#line 712 "x10/regionarray/DistArray.x10"
                        final long t$151401 = ((i$151402) + (((long)(1L))));
                        
                        //#line 712 "x10/regionarray/DistArray.x10"
                        i$151402 = t$151401;
                    }
                }
                
                //#line 715 "x10/regionarray/DistArray.x10"
                final long pre$151413 = patchIndex;
                
                //#line 715 "x10/regionarray/DistArray.x10"
                final long t$151415 = ((patchIndex) + (((long)(1L))));
                
                //#line 715 "x10/regionarray/DistArray.x10"
                patchIndex = t$151415;
                
                //#line 715 "x10/regionarray/DistArray.x10"
                final $T t$151416 = (($T)(this.$apply$G(((x10.lang.Point)(p$151409)))));
                
                //#line 715 "x10/regionarray/DistArray.x10"
                ((x10.core.Rail<$T>)patchRaw).$set__1x10$lang$Rail$$T$G((long)(pre$151413), (($T)(t$151416)));
            }
        }
        
        //#line 717 "x10/regionarray/DistArray.x10"
        final x10.regionarray.Array alloc$150410 = ((x10.regionarray.Array)(new x10.regionarray.Array<$T>((java.lang.System[]) null, $T)));
        
        //#line 233 . "x10/regionarray/Array.x10"
        final x10.regionarray.Region t$151417 = ((x10.regionarray.Region)
                                                  r);
        
        //#line 233 . "x10/regionarray/Array.x10"
        final boolean t$151418 = ((t$151417) != (null));
        
        //#line 233 . "x10/regionarray/Array.x10"
        final boolean t$151419 = !(t$151418);
        
        //#line 233 . "x10/regionarray/Array.x10"
        if (t$151419) {
            
            //#line 233 . "x10/regionarray/Array.x10"
            final boolean t$151420 = true;
            
            //#line 233 . "x10/regionarray/Array.x10"
            if (t$151420) {
                
                //#line 233 . "x10/regionarray/Array.x10"
                final x10.lang.FailedDynamicCheckException t$151421 = new x10.lang.FailedDynamicCheckException("x10.regionarray.Region{self!=null}");
                
                //#line 233 . "x10/regionarray/Array.x10"
                throw t$151421;
            }
        }
        
        //#line 233 . "x10/regionarray/Array.x10"
        ((x10.regionarray.Array<$T>)alloc$150410).region = ((x10.regionarray.Region)(t$151417));
        
        //#line 233 . "x10/regionarray/Array.x10"
        final long t$151422 = r.rank;
        
        //#line 233 . "x10/regionarray/Array.x10"
        ((x10.regionarray.Array<$T>)alloc$150410).rank = t$151422;
        
        //#line 233 . "x10/regionarray/Array.x10"
        final boolean t$151423 = r.rect;
        
        //#line 233 . "x10/regionarray/Array.x10"
        ((x10.regionarray.Array<$T>)alloc$150410).rect = t$151423;
        
        //#line 233 . "x10/regionarray/Array.x10"
        final boolean t$151424 = r.zeroBased;
        
        //#line 233 . "x10/regionarray/Array.x10"
        ((x10.regionarray.Array<$T>)alloc$150410).zeroBased = t$151424;
        
        //#line 233 . "x10/regionarray/Array.x10"
        final boolean t$151425 = r.rail;
        
        //#line 233 . "x10/regionarray/Array.x10"
        ((x10.regionarray.Array<$T>)alloc$150410).rail = t$151425;
        
        //#line 233 . "x10/regionarray/Array.x10"
        final long t$151426 = r.size$O();
        
        //#line 233 . "x10/regionarray/Array.x10"
        ((x10.regionarray.Array<$T>)alloc$150410).size = t$151426;
        
        //#line 235 . "x10/regionarray/Array.x10"
        final x10.regionarray.Array.LayoutHelper crh$151429 = new x10.regionarray.Array.LayoutHelper((java.lang.System[]) null);
        
        //#line 235 . "x10/regionarray/Array.x10"
        crh$151429.x10$regionarray$Array$LayoutHelper$$init$S(((x10.regionarray.Region)(r)));
        
        //#line 236 . "x10/regionarray/Array.x10"
        final long t$151430 = crh$151429.min0;
        
        //#line 236 . "x10/regionarray/Array.x10"
        ((x10.regionarray.Array<$T>)alloc$150410).layout_min0 = t$151430;
        
        //#line 237 . "x10/regionarray/Array.x10"
        final long t$151431 = crh$151429.stride1;
        
        //#line 237 . "x10/regionarray/Array.x10"
        ((x10.regionarray.Array<$T>)alloc$150410).layout_stride1 = t$151431;
        
        //#line 238 . "x10/regionarray/Array.x10"
        final long t$151432 = crh$151429.min1;
        
        //#line 238 . "x10/regionarray/Array.x10"
        ((x10.regionarray.Array<$T>)alloc$150410).layout_min1 = t$151432;
        
        //#line 239 . "x10/regionarray/Array.x10"
        final x10.core.Rail t$151433 = ((x10.core.Rail)(crh$151429.layout));
        
        //#line 239 . "x10/regionarray/Array.x10"
        ((x10.regionarray.Array<$T>)alloc$150410).layout = ((x10.core.Rail)(t$151433));
        
        //#line 240 . "x10/regionarray/Array.x10"
        final long n$151434 = crh$151429.size;
        
        //#line 241 . "x10/regionarray/Array.x10"
        final long t$151435 = ((x10.core.Rail<$T>)patchRaw).size;
        
        //#line 241 . "x10/regionarray/Array.x10"
        final boolean t$151436 = ((n$151434) > (((long)(t$151435))));
        
        //#line 241 . "x10/regionarray/Array.x10"
        if (t$151436) {
            
            //#line 242 . "x10/regionarray/Array.x10"
            final boolean t$151437 = true;
            
            //#line 242 . "x10/regionarray/Array.x10"
            if (t$151437) {
                
                //#line 242 . "x10/regionarray/Array.x10"
                final java.lang.IllegalArgumentException t$151438 = ((java.lang.IllegalArgumentException)(new java.lang.IllegalArgumentException("backingStore too small")));
                
                //#line 242 . "x10/regionarray/Array.x10"
                throw t$151438;
            }
        }
        
        //#line 244 . "x10/regionarray/Array.x10"
        final x10.core.Rail t$151439 = ((x10.core.Rail<$T>)
                                         patchRaw);
        
        //#line 244 . "x10/regionarray/Array.x10"
        final boolean t$151440 = ((t$151439) != (null));
        
        //#line 244 . "x10/regionarray/Array.x10"
        final boolean t$151441 = !(t$151440);
        
        //#line 244 . "x10/regionarray/Array.x10"
        if (t$151441) {
            
            //#line 244 . "x10/regionarray/Array.x10"
            final boolean t$151442 = true;
            
            //#line 244 . "x10/regionarray/Array.x10"
            if (t$151442) {
                
                //#line 244 . "x10/regionarray/Array.x10"
                final x10.lang.FailedDynamicCheckException t$151443 = new x10.lang.FailedDynamicCheckException("x10.lang.Rail[T]{self!=null}");
                
                //#line 244 . "x10/regionarray/Array.x10"
                throw t$151443;
            }
        }
        
        //#line 244 . "x10/regionarray/Array.x10"
        ((x10.regionarray.Array<$T>)alloc$150410).raw = ((x10.core.Rail)(t$151439));
        
        //#line 717 "x10/regionarray/DistArray.x10"
        return alloc$150410;
    }
    
    
    //#line 725 "x10/regionarray/DistArray.x10"
    /**
     * Fill all elements of the array to contain the argument value.
     * 
     * @param v the value with which to fill the array
     */
    public void fill__0x10$regionarray$DistArray$$T(final $T v) {
        {
            
            //#line 726 "x10/regionarray/DistArray.x10"
            x10.xrx.Runtime.ensureNotInAtomic();
            
            //#line 726 "x10/regionarray/DistArray.x10"
            final x10.xrx.FinishState fs$151643 = x10.xrx.Runtime.startFinish();
            
            //#line 726 "x10/regionarray/DistArray.x10"
            try {{
                {
                    
                    //#line 726 "x10/regionarray/DistArray.x10"
                    final x10.regionarray.Dist t$151076 = ((x10.regionarray.Dist)(this.dist));
                    
                    //#line 726 "x10/regionarray/DistArray.x10"
                    final x10.lang.PlaceGroup t$151077 = t$151076.places();
                    
                    //#line 726 "x10/regionarray/DistArray.x10"
                    final x10.lang.Iterator where$150422 = t$151077.iterator();
                    
                    //#line 726 "x10/regionarray/DistArray.x10"
                    for (;
                         true;
                         ) {
                        
                        //#line 726 "x10/regionarray/DistArray.x10"
                        final boolean t$151082 = ((x10.lang.Iterator<x10.lang.Place>)where$150422).hasNext$O();
                        
                        //#line 726 "x10/regionarray/DistArray.x10"
                        if (!(t$151082)) {
                            
                            //#line 726 "x10/regionarray/DistArray.x10"
                            break;
                        }
                        
                        //#line 726 "x10/regionarray/DistArray.x10"
                        final x10.lang.Place where$151448 = ((x10.lang.Place)(((x10.lang.Iterator<x10.lang.Place>)where$150422).next$G()));
                        
                        //#line 727 "x10/regionarray/DistArray.x10"
                        x10.xrx.Runtime.runAsync(((x10.lang.Place)(where$151448)), ((x10.core.fun.VoidFun_0_0)(new x10.regionarray.DistArray.$Closure$228<$T>($T, ((x10.regionarray.DistArray)(this)), this.dist, v, (x10.regionarray.DistArray.$Closure$228.__0$1x10$regionarray$DistArray$$Closure$228$$T$2__2x10$regionarray$DistArray$$Closure$228$$T) null))), ((x10.xrx.Runtime.Profile)(null)));
                    }
                }
            }}catch (java.lang.Throwable ct$151641) {
                
                //#line 726 "x10/regionarray/DistArray.x10"
                x10.xrx.Runtime.pushException(((java.lang.Throwable)(ct$151641)));
                
                //#line 726 "x10/regionarray/DistArray.x10"
                throw new java.lang.RuntimeException();
            }finally {{
                 
                 //#line 726 "x10/regionarray/DistArray.x10"
                 x10.xrx.Runtime.stopFinish(((x10.xrx.FinishState)(fs$151643)));
             }}
            }
        }
    
    
    //#line 747 "x10/regionarray/DistArray.x10"
    /**
     * Map the function onto the elements of this array
     * constructing a new result array such that for all points <code>p</code>
     * in <code>this.dist</code>,
     * <code>result(p) == op(this(p))</code>.<p>
     * 
     * @param op the function to apply to each element of the array
     * @return a new array with the same distribution as this array where <code>result(p) == op(this(p))</code>
     */
    final public <$U>x10.regionarray.DistArray map__0$1x10$regionarray$DistArray$$T$3x10$regionarray$DistArray$$U$2(final x10.rtt.Type $U, final x10.core.fun.Fun_0_1 op) {
        
        //#line 749 "x10/regionarray/DistArray.x10"
        final x10.regionarray.Dist t$151083 = ((x10.regionarray.Dist)(this.dist));
        
        //#line 749 "x10/regionarray/DistArray.x10"
        final x10.lang.PlaceGroup t$151091 = t$151083.places();
        
        //#line 750 "x10/regionarray/DistArray.x10"
        final x10.core.fun.Fun_0_0 t$151092 = ((x10.core.fun.Fun_0_0)(new x10.regionarray.DistArray.$Closure$229<$T, $U>($T, $U, ((x10.regionarray.DistArray)(this)), this.dist, op, (x10.regionarray.DistArray.$Closure$229.__0$1x10$regionarray$DistArray$$Closure$229$$T$2__2$1x10$regionarray$DistArray$$Closure$229$$T$3x10$regionarray$DistArray$$Closure$229$$U$2) null)));
        
        //#line 748 "x10/regionarray/DistArray.x10"
        final x10.lang.PlaceLocalHandle plh = x10.lang.PlaceLocalHandle.<x10.regionarray.DistArray.LocalState<$U>> make__1$1x10$lang$PlaceLocalHandle$$T$2(x10.rtt.ParameterizedType.make(x10.regionarray.DistArray.LocalState.$RTT, $U), ((x10.lang.PlaceGroup)(t$151091)), ((x10.core.fun.Fun_0_0)(t$151092)));
        
        //#line 761 "x10/regionarray/DistArray.x10"
        final x10.regionarray.DistArray alloc$150412 = ((x10.regionarray.DistArray)(new x10.regionarray.DistArray<$U>((java.lang.System[]) null, $U)));
        
        //#line 761 "x10/regionarray/DistArray.x10"
        final x10.regionarray.Dist t$151461 = ((x10.regionarray.Dist)(this.dist));
        
        //#line 761 "x10/regionarray/DistArray.x10"
        alloc$150412.x10$regionarray$DistArray$$init$S(((x10.regionarray.Dist)(t$151461)), ((x10.lang.PlaceLocalHandle<x10.regionarray.DistArray.LocalState<$U>>)(plh)), (x10.regionarray.DistArray.__1$1x10$regionarray$DistArray$LocalState$1x10$regionarray$DistArray$$T$2$2) null);
        
        //#line 761 "x10/regionarray/DistArray.x10"
        return alloc$150412;
    }
    
    
    //#line 774 "x10/regionarray/DistArray.x10"
    /**
     * Map the given function onto the elements of this array
     * storing the results in the dst array such that for all points <code>p</code>
     * in <code>this.dist</code>,
     * <code>dst(p) == op(this(p))</code>.<p>
     * 
     * @param dst the destination array for the results of the map operation
     * @param op the function to apply to each element of the array
     * @return dst after applying the map operation.
     */
    final public <$U>x10.regionarray.DistArray map__0$1x10$regionarray$DistArray$$U$2__1$1x10$regionarray$DistArray$$T$3x10$regionarray$DistArray$$U$2(final x10.rtt.Type $U, final x10.regionarray.DistArray dst, final x10.core.fun.Fun_0_1 op) {
        {
            
            //#line 775 "x10/regionarray/DistArray.x10"
            x10.xrx.Runtime.ensureNotInAtomic();
            
            //#line 775 "x10/regionarray/DistArray.x10"
            final x10.xrx.FinishState fs$151651 = x10.xrx.Runtime.startFinish();
            
            //#line 775 "x10/regionarray/DistArray.x10"
            try {{
                {
                    
                    //#line 776 "x10/regionarray/DistArray.x10"
                    final x10.regionarray.Dist t$151095 = ((x10.regionarray.Dist)(this.dist));
                    
                    //#line 776 "x10/regionarray/DistArray.x10"
                    final x10.lang.PlaceGroup t$151096 = t$151095.places();
                    
                    //#line 776 "x10/regionarray/DistArray.x10"
                    final x10.lang.Iterator where$150428 = t$151096.iterator();
                    
                    //#line 776 "x10/regionarray/DistArray.x10"
                    for (;
                         true;
                         ) {
                        
                        //#line 776 "x10/regionarray/DistArray.x10"
                        final boolean t$151102 = ((x10.lang.Iterator<x10.lang.Place>)where$150428).hasNext$O();
                        
                        //#line 776 "x10/regionarray/DistArray.x10"
                        if (!(t$151102)) {
                            
                            //#line 776 "x10/regionarray/DistArray.x10"
                            break;
                        }
                        
                        //#line 776 "x10/regionarray/DistArray.x10"
                        final x10.lang.Place where$151468 = ((x10.lang.Place)(((x10.lang.Iterator<x10.lang.Place>)where$150428).next$G()));
                        
                        //#line 777 "x10/regionarray/DistArray.x10"
                        x10.xrx.Runtime.runAsync(((x10.lang.Place)(where$151468)), ((x10.core.fun.VoidFun_0_0)(new x10.regionarray.DistArray.$Closure$230<$T, $U>($T, $U, ((x10.regionarray.DistArray)(this)), this.dist, dst, op, (x10.regionarray.DistArray.$Closure$230.__0$1x10$regionarray$DistArray$$Closure$230$$T$2__2$1x10$regionarray$DistArray$$Closure$230$$U$2__3$1x10$regionarray$DistArray$$Closure$230$$T$3x10$regionarray$DistArray$$Closure$230$$U$2) null))), ((x10.xrx.Runtime.Profile)(null)));
                    }
                }
            }}catch (java.lang.Throwable ct$151649) {
                
                //#line 775 "x10/regionarray/DistArray.x10"
                x10.xrx.Runtime.pushException(((java.lang.Throwable)(ct$151649)));
                
                //#line 775 "x10/regionarray/DistArray.x10"
                throw new java.lang.RuntimeException();
            }finally {{
                 
                 //#line 775 "x10/regionarray/DistArray.x10"
                 x10.xrx.Runtime.stopFinish(((x10.xrx.FinishState)(fs$151651)));
             }}
            }
        
        //#line 789 "x10/regionarray/DistArray.x10"
        return dst;
        }
    
    
    //#line 804 "x10/regionarray/DistArray.x10"
    /**
     * Map the given function onto the elements of this array
     * storing the results in the dst array for the subset of points included
     * in the filter region such that for all points <code>p</code>
     * in <code>filter</code>,
     * <code>dst(p) == op(this(p))</code>.<p>
     * 
     * @param dst the destination array for the results of the map operation
     * @param op the function to apply to each element of the array
     * @param filter the region to use as a filter on the map operation
     * @return dst after applying the map operation.
     */
    final public <$U>x10.regionarray.DistArray map__0$1x10$regionarray$DistArray$$U$2__2$1x10$regionarray$DistArray$$T$3x10$regionarray$DistArray$$U$2(final x10.rtt.Type $U, final x10.regionarray.DistArray dst, final x10.regionarray.Region filter, final x10.core.fun.Fun_0_1 op) {
        {
            
            //#line 805 "x10/regionarray/DistArray.x10"
            x10.xrx.Runtime.ensureNotInAtomic();
            
            //#line 805 "x10/regionarray/DistArray.x10"
            final x10.xrx.FinishState fs$151659 = x10.xrx.Runtime.startFinish();
            
            //#line 805 "x10/regionarray/DistArray.x10"
            try {{
                {
                    
                    //#line 806 "x10/regionarray/DistArray.x10"
                    final x10.regionarray.Dist t$151104 = ((x10.regionarray.Dist)(this.dist));
                    
                    //#line 806 "x10/regionarray/DistArray.x10"
                    final x10.lang.PlaceGroup t$151105 = t$151104.places();
                    
                    //#line 806 "x10/regionarray/DistArray.x10"
                    final x10.lang.Iterator where$150432 = t$151105.iterator();
                    
                    //#line 806 "x10/regionarray/DistArray.x10"
                    for (;
                         true;
                         ) {
                        
                        //#line 806 "x10/regionarray/DistArray.x10"
                        final boolean t$151111 = ((x10.lang.Iterator<x10.lang.Place>)where$150432).hasNext$O();
                        
                        //#line 806 "x10/regionarray/DistArray.x10"
                        if (!(t$151111)) {
                            
                            //#line 806 "x10/regionarray/DistArray.x10"
                            break;
                        }
                        
                        //#line 806 "x10/regionarray/DistArray.x10"
                        final x10.lang.Place where$151482 = ((x10.lang.Place)(((x10.lang.Iterator<x10.lang.Place>)where$150432).next$G()));
                        
                        //#line 807 "x10/regionarray/DistArray.x10"
                        x10.xrx.Runtime.runAsync(((x10.lang.Place)(where$151482)), ((x10.core.fun.VoidFun_0_0)(new x10.regionarray.DistArray.$Closure$231<$T, $U>($T, $U, ((x10.regionarray.DistArray)(this)), this.dist, filter, dst, op, (x10.regionarray.DistArray.$Closure$231.__0$1x10$regionarray$DistArray$$Closure$231$$T$2__3$1x10$regionarray$DistArray$$Closure$231$$U$2__4$1x10$regionarray$DistArray$$Closure$231$$T$3x10$regionarray$DistArray$$Closure$231$$U$2) null))), ((x10.xrx.Runtime.Profile)(null)));
                    }
                }
            }}catch (java.lang.Throwable ct$151657) {
                
                //#line 805 "x10/regionarray/DistArray.x10"
                x10.xrx.Runtime.pushException(((java.lang.Throwable)(ct$151657)));
                
                //#line 805 "x10/regionarray/DistArray.x10"
                throw new java.lang.RuntimeException();
            }finally {{
                 
                 //#line 805 "x10/regionarray/DistArray.x10"
                 x10.xrx.Runtime.stopFinish(((x10.xrx.FinishState)(fs$151659)));
             }}
            }
        
        //#line 820 "x10/regionarray/DistArray.x10"
        return dst;
        }
    
    
    //#line 833 "x10/regionarray/DistArray.x10"
    /**
     * Map the given function onto the elements of this array
     * and the other src array, storing the results in a new result array 
     * such that for all points <code>p</code> in <code>this.dist</code>,
     * <code>result(p) == op(this(p), src(p))</code>.<p>
     * 
     * @param src the other src array
     * @param op the function to apply to each element of the array
     * @return a new array with the same distribution as this array containing the result of the map
     */
    final public <$S, $U>x10.regionarray.DistArray map__0$1x10$regionarray$DistArray$$U$2__1$1x10$regionarray$DistArray$$T$3x10$regionarray$DistArray$$U$3x10$regionarray$DistArray$$S$2(final x10.rtt.Type $S, final x10.rtt.Type $U, final x10.regionarray.DistArray src, final x10.core.fun.Fun_0_2 op) {
        
        //#line 835 "x10/regionarray/DistArray.x10"
        final x10.regionarray.Dist t$151112 = ((x10.regionarray.Dist)(this.dist));
        
        //#line 835 "x10/regionarray/DistArray.x10"
        final x10.lang.PlaceGroup t$151121 = t$151112.places();
        
        //#line 836 "x10/regionarray/DistArray.x10"
        final x10.core.fun.Fun_0_0 t$151122 = ((x10.core.fun.Fun_0_0)(new x10.regionarray.DistArray.$Closure$232<$T, $S, $U>($T, $S, $U, ((x10.regionarray.DistArray)(this)), src, this.dist, op, (x10.regionarray.DistArray.$Closure$232.$_8b30f567) null)));
        
        //#line 834 "x10/regionarray/DistArray.x10"
        final x10.lang.PlaceLocalHandle plh = x10.lang.PlaceLocalHandle.<x10.regionarray.DistArray.LocalState<$S>> make__1$1x10$lang$PlaceLocalHandle$$T$2(x10.rtt.ParameterizedType.make(x10.regionarray.DistArray.LocalState.$RTT, $S), ((x10.lang.PlaceGroup)(t$151121)), ((x10.core.fun.Fun_0_0)(t$151122)));
        
        //#line 848 "x10/regionarray/DistArray.x10"
        final x10.regionarray.DistArray alloc$150414 = ((x10.regionarray.DistArray)(new x10.regionarray.DistArray<$S>((java.lang.System[]) null, $S)));
        
        //#line 848 "x10/regionarray/DistArray.x10"
        final x10.regionarray.Dist t$151499 = ((x10.regionarray.Dist)(this.dist));
        
        //#line 848 "x10/regionarray/DistArray.x10"
        alloc$150414.x10$regionarray$DistArray$$init$S(((x10.regionarray.Dist)(t$151499)), ((x10.lang.PlaceLocalHandle<x10.regionarray.DistArray.LocalState<$S>>)(plh)), (x10.regionarray.DistArray.__1$1x10$regionarray$DistArray$LocalState$1x10$regionarray$DistArray$$T$2$2) null);
        
        //#line 848 "x10/regionarray/DistArray.x10"
        return alloc$150414;
    }
    
    
    //#line 862 "x10/regionarray/DistArray.x10"
    /**
     * Map the given function onto the elements of this array
     * and the other src array, storing the results in the given dst array 
     * such that for all points <code>p</code> in <code>this.dist</code>,
     * <code>dst(p) == op(this(p), src(p))</code>.<p>
     * 
     * @param dst the destination array for the map operation
     * @param src the second source array for the map operation
     * @param op the function to apply to each element of the array
     * @return destination after applying the map operation.
     */
    final public <$S, $U>x10.regionarray.DistArray map__0$1x10$regionarray$DistArray$$S$2__1$1x10$regionarray$DistArray$$U$2__2$1x10$regionarray$DistArray$$T$3x10$regionarray$DistArray$$U$3x10$regionarray$DistArray$$S$2(final x10.rtt.Type $S, final x10.rtt.Type $U, final x10.regionarray.DistArray dst, final x10.regionarray.DistArray src, final x10.core.fun.Fun_0_2 op) {
        {
            
            //#line 863 "x10/regionarray/DistArray.x10"
            x10.xrx.Runtime.ensureNotInAtomic();
            
            //#line 863 "x10/regionarray/DistArray.x10"
            final x10.xrx.FinishState fs$151667 = x10.xrx.Runtime.startFinish();
            
            //#line 863 "x10/regionarray/DistArray.x10"
            try {{
                {
                    
                    //#line 864 "x10/regionarray/DistArray.x10"
                    final x10.regionarray.Dist t$151125 = ((x10.regionarray.Dist)(this.dist));
                    
                    //#line 864 "x10/regionarray/DistArray.x10"
                    final x10.lang.PlaceGroup t$151126 = t$151125.places();
                    
                    //#line 864 "x10/regionarray/DistArray.x10"
                    final x10.lang.Iterator where$150438 = t$151126.iterator();
                    
                    //#line 864 "x10/regionarray/DistArray.x10"
                    for (;
                         true;
                         ) {
                        
                        //#line 864 "x10/regionarray/DistArray.x10"
                        final boolean t$151133 = ((x10.lang.Iterator<x10.lang.Place>)where$150438).hasNext$O();
                        
                        //#line 864 "x10/regionarray/DistArray.x10"
                        if (!(t$151133)) {
                            
                            //#line 864 "x10/regionarray/DistArray.x10"
                            break;
                        }
                        
                        //#line 864 "x10/regionarray/DistArray.x10"
                        final x10.lang.Place where$151507 = ((x10.lang.Place)(((x10.lang.Iterator<x10.lang.Place>)where$150438).next$G()));
                        
                        //#line 865 "x10/regionarray/DistArray.x10"
                        x10.xrx.Runtime.runAsync(((x10.lang.Place)(where$151507)), ((x10.core.fun.VoidFun_0_0)(new x10.regionarray.DistArray.$Closure$233<$T, $S, $U>($T, $S, $U, ((x10.regionarray.DistArray)(this)), this.dist, src, dst, op, (x10.regionarray.DistArray.$Closure$233.$_d69e2961) null))), ((x10.xrx.Runtime.Profile)(null)));
                    }
                }
            }}catch (java.lang.Throwable ct$151665) {
                
                //#line 863 "x10/regionarray/DistArray.x10"
                x10.xrx.Runtime.pushException(((java.lang.Throwable)(ct$151665)));
                
                //#line 863 "x10/regionarray/DistArray.x10"
                throw new java.lang.RuntimeException();
            }finally {{
                 
                 //#line 863 "x10/regionarray/DistArray.x10"
                 x10.xrx.Runtime.stopFinish(((x10.xrx.FinishState)(fs$151667)));
             }}
            }
        
        //#line 878 "x10/regionarray/DistArray.x10"
        return dst;
        }
    
    
    //#line 893 "x10/regionarray/DistArray.x10"
    /**
     * Map the given function onto the elements of this array
     * and the other src array, storing the results in the given dst array 
     * such that for all points in the filter region <code>p</code> in <code>filter</code>,
     * <code>dst(p) == op(this(p), src(p))</code>.<p>
     * 
     * @param dst the destination array for the map operation
     * @param src the second source array for the map operation
     * @param op the function to apply to each element of the array
     * @param filter the region to use to select the subset of points to include in the map
     * @return destination after applying the map operation.
     */
    final public <$S, $U>x10.regionarray.DistArray map__0$1x10$regionarray$DistArray$$S$2__1$1x10$regionarray$DistArray$$U$2__3$1x10$regionarray$DistArray$$T$3x10$regionarray$DistArray$$U$3x10$regionarray$DistArray$$S$2(final x10.rtt.Type $S, final x10.rtt.Type $U, final x10.regionarray.DistArray dst, final x10.regionarray.DistArray src, final x10.regionarray.Region filter, final x10.core.fun.Fun_0_2 op) {
        {
            
            //#line 894 "x10/regionarray/DistArray.x10"
            x10.xrx.Runtime.ensureNotInAtomic();
            
            //#line 894 "x10/regionarray/DistArray.x10"
            final x10.xrx.FinishState fs$151675 = x10.xrx.Runtime.startFinish();
            
            //#line 894 "x10/regionarray/DistArray.x10"
            try {{
                {
                    
                    //#line 895 "x10/regionarray/DistArray.x10"
                    final x10.regionarray.Dist t$151135 = ((x10.regionarray.Dist)(this.dist));
                    
                    //#line 895 "x10/regionarray/DistArray.x10"
                    final x10.lang.PlaceGroup t$151136 = t$151135.places();
                    
                    //#line 895 "x10/regionarray/DistArray.x10"
                    final x10.lang.Iterator where$150442 = t$151136.iterator();
                    
                    //#line 895 "x10/regionarray/DistArray.x10"
                    for (;
                         true;
                         ) {
                        
                        //#line 895 "x10/regionarray/DistArray.x10"
                        final boolean t$151143 = ((x10.lang.Iterator<x10.lang.Place>)where$150442).hasNext$O();
                        
                        //#line 895 "x10/regionarray/DistArray.x10"
                        if (!(t$151143)) {
                            
                            //#line 895 "x10/regionarray/DistArray.x10"
                            break;
                        }
                        
                        //#line 895 "x10/regionarray/DistArray.x10"
                        final x10.lang.Place where$151523 = ((x10.lang.Place)(((x10.lang.Iterator<x10.lang.Place>)where$150442).next$G()));
                        
                        //#line 896 "x10/regionarray/DistArray.x10"
                        x10.xrx.Runtime.runAsync(((x10.lang.Place)(where$151523)), ((x10.core.fun.VoidFun_0_0)(new x10.regionarray.DistArray.$Closure$234<$T, $S, $U>($T, $S, $U, ((x10.regionarray.DistArray)(this)), this.dist, filter, src, dst, op, (x10.regionarray.DistArray.$Closure$234.$_e582bc9a) null))), ((x10.xrx.Runtime.Profile)(null)));
                    }
                }
            }}catch (java.lang.Throwable ct$151673) {
                
                //#line 894 "x10/regionarray/DistArray.x10"
                x10.xrx.Runtime.pushException(((java.lang.Throwable)(ct$151673)));
                
                //#line 894 "x10/regionarray/DistArray.x10"
                throw new java.lang.RuntimeException();
            }finally {{
                 
                 //#line 894 "x10/regionarray/DistArray.x10"
                 x10.xrx.Runtime.stopFinish(((x10.xrx.FinishState)(fs$151675)));
             }}
            }
        
        //#line 910 "x10/regionarray/DistArray.x10"
        return dst;
        }
    
    
    //#line 925 "x10/regionarray/DistArray.x10"
    /**
     * Reduce this array using the given function and the given initial value.
     * Each element of the array will be given as an argument to the reduction
     * function exactly once, but in an arbitrary order.  The reduction function
     * may be applied concurrently to implement a parallel reduction.
     * 
     * @param op the reduction function
     * @param unit the given initial value
     * @return the final result of the reduction.
     * @see #map((T)=>S)
     * @see #reduce((U,T)=>U,(U,U)=>U,U)
     */
    final public $T reduce__0$1x10$regionarray$DistArray$$T$3x10$regionarray$DistArray$$T$3x10$regionarray$DistArray$$T$2__1x10$regionarray$DistArray$$T$G(final x10.core.fun.Fun_0_2 op, final $T unit) {
        
        //#line 925 "x10/regionarray/DistArray.x10"
        final $T t$151144 = (($T)(this.<$T> reduce__0$1x10$regionarray$DistArray$$U$3x10$regionarray$DistArray$$T$3x10$regionarray$DistArray$$U$2__1$1x10$regionarray$DistArray$$U$3x10$regionarray$DistArray$$U$3x10$regionarray$DistArray$$U$2__2x10$regionarray$DistArray$$U$G($T, ((x10.core.fun.Fun_0_2)(op)), ((x10.core.fun.Fun_0_2)(op)), (($T)(unit)))));
        
        //#line 925 "x10/regionarray/DistArray.x10"
        return t$151144;
    }
    
    
    //#line 939 "x10/regionarray/DistArray.x10"
    /**
     * Reduce this array using the given function and the given initial value.
     * Each element of the array will be given as an argument to the reduction
     * function exactly once, but in an arbitrary order.  The reduction function
     * may be applied concurrently to implement a parallel reduction.
     * 
     * @param lop the local reduction function
     * @param gop the global reduction function
     * @param unit the given initial value
     * @return the final result of the reduction.
     * @see #map((T)=>S)
     */
    final public <$U>$U reduce__0$1x10$regionarray$DistArray$$U$3x10$regionarray$DistArray$$T$3x10$regionarray$DistArray$$U$2__1$1x10$regionarray$DistArray$$U$3x10$regionarray$DistArray$$U$3x10$regionarray$DistArray$$U$2__2x10$regionarray$DistArray$$U$G(final x10.rtt.Type $U, final x10.core.fun.Fun_0_2 lop, final x10.core.fun.Fun_0_2 gop, final $U unit) {
        
        //#line 940 "x10/regionarray/DistArray.x10"
        final x10.regionarray.DistArray.Anonymous$39192 reducer = ((x10.regionarray.DistArray.Anonymous$39192)(new x10.regionarray.DistArray.Anonymous$39192<$U, $T>((java.lang.System[]) null, $U, $T)));
        
        //#line 940 "x10/regionarray/DistArray.x10"
        final x10.regionarray.DistArray out$150723 = ((x10.regionarray.DistArray)(this));
        
        //#line 45 . "x10/regionarray/DistArray.x10"
        ((x10.regionarray.DistArray.Anonymous$39192<$U, $T>)reducer).out$ = out$150723;
        
        //#line 939 . "x10/regionarray/DistArray.x10"
        ((x10.regionarray.DistArray.Anonymous$39192<$U, $T>)reducer).unit = (($U)(unit));
        
        //#line 939 . "x10/regionarray/DistArray.x10"
        ((x10.regionarray.DistArray.Anonymous$39192<$U, $T>)reducer).gop = gop;
        
        //#line 945 "x10/regionarray/DistArray.x10"
        final $U result;
        {
            
            //#line 945 "x10/regionarray/DistArray.x10"
            final x10.xrx.FinishState fs$151685 = ((x10.xrx.FinishState)(x10.xrx.Runtime.<$U> startCollectingFinish__0$1x10$xrx$Runtime$$T$2($U, ((x10.lang.Reducible)(reducer)))));
            
            //#line 945 "x10/regionarray/DistArray.x10"
            try {{
                {
                    
                    //#line 946 "x10/regionarray/DistArray.x10"
                    final x10.regionarray.Dist t$151146 = ((x10.regionarray.Dist)(this.dist));
                    
                    //#line 946 "x10/regionarray/DistArray.x10"
                    final x10.lang.PlaceGroup t$151147 = t$151146.places();
                    
                    //#line 946 "x10/regionarray/DistArray.x10"
                    final x10.lang.Iterator where$150446 = t$151147.iterator();
                    
                    //#line 946 "x10/regionarray/DistArray.x10"
                    for (;
                         true;
                         ) {
                        
                        //#line 946 "x10/regionarray/DistArray.x10"
                        final boolean t$151156 = ((x10.lang.Iterator<x10.lang.Place>)where$150446).hasNext$O();
                        
                        //#line 946 "x10/regionarray/DistArray.x10"
                        if (!(t$151156)) {
                            
                            //#line 946 "x10/regionarray/DistArray.x10"
                            break;
                        }
                        
                        //#line 946 "x10/regionarray/DistArray.x10"
                        final x10.lang.Place where$151540 = ((x10.lang.Place)(((x10.lang.Iterator<x10.lang.Place>)where$150446).next$G()));
                        
                        //#line 947 "x10/regionarray/DistArray.x10"
                        x10.xrx.Runtime.runAsync(((x10.lang.Place)(where$151540)), ((x10.core.fun.VoidFun_0_0)(new x10.regionarray.DistArray.$Closure$235<$T, $U>($T, $U, ((x10.regionarray.DistArray)(this)), this.dist, unit, lop, (x10.regionarray.DistArray.$Closure$235.__0$1x10$regionarray$DistArray$$Closure$235$$T$2__2x10$regionarray$DistArray$$Closure$235$$U__3$1x10$regionarray$DistArray$$Closure$235$$U$3x10$regionarray$DistArray$$Closure$235$$T$3x10$regionarray$DistArray$$Closure$235$$U$2) null))), ((x10.xrx.Runtime.Profile)(null)));
                    }
                }
            }}catch (java.lang.Throwable __lowerer__var__0__) {
                
                //#line 945 "x10/regionarray/DistArray.x10"
                x10.xrx.Runtime.pushException(((java.lang.Throwable)(__lowerer__var__0__)));
                
                //#line 945 "x10/regionarray/DistArray.x10"
                throw new java.lang.RuntimeException();
            }finally {{
                 
                 //#line 945 "x10/regionarray/DistArray.x10"
                 result = (($U)(x10.xrx.Runtime.<$U> stopCollectingFinish$G($U, ((x10.xrx.FinishState)(fs$151685)))));
             }}
            }
        
        //#line 960 "x10/regionarray/DistArray.x10"
        return result;
        }
    
    
    //#line 967 "x10/regionarray/DistArray.x10"
    /**
     * Update ghost data for every place in this DistArray.
     * This includes synchronization before and after the update.
     */
    public void updateGhosts() {
        
        //#line 968 "x10/regionarray/DistArray.x10"
        final x10.lang.PlaceLocalHandle t$151157 = ((x10.lang.PlaceLocalHandle)(this.localHandle));
        
        //#line 968 "x10/regionarray/DistArray.x10"
        final x10.regionarray.DistArray.LocalState t$151158 = ((x10.regionarray.DistArray.LocalState)(((x10.lang.PlaceLocalHandle<x10.regionarray.DistArray.LocalState<$T>>)t$151157).$apply$G()));
        
        //#line 968 "x10/regionarray/DistArray.x10"
        final x10.regionarray.GhostManager t$151159 = ((x10.regionarray.GhostManager)(((x10.regionarray.DistArray.LocalState<$T>)t$151158).ghostManager));
        
        //#line 968 "x10/regionarray/DistArray.x10"
        final boolean t$151165 = ((t$151159) != (null));
        
        //#line 968 "x10/regionarray/DistArray.x10"
        if (t$151165) {
            {
                
                //#line 969 "x10/regionarray/DistArray.x10"
                x10.xrx.Runtime.ensureNotInAtomic();
                
                //#line 969 "x10/regionarray/DistArray.x10"
                final x10.xrx.FinishState fs$151703 = x10.xrx.Runtime.startFinish();
                
                //#line 969 "x10/regionarray/DistArray.x10"
                try {{
                    {
                        
                        //#line 969 "x10/regionarray/DistArray.x10"
                        final x10.regionarray.Dist t$151160 = ((x10.regionarray.Dist)(this.dist));
                        
                        //#line 969 "x10/regionarray/DistArray.x10"
                        final x10.lang.PlaceGroup t$151161 = t$151160.places();
                        
                        //#line 969 "x10/regionarray/DistArray.x10"
                        final x10.regionarray.Dist t$151164 = ((x10.regionarray.Dist)(x10.regionarray.Dist.makeUnique(((x10.lang.PlaceGroup)(t$151161)))));
                        {
                            
                            //#line 969 "x10/regionarray/DistArray.x10"
                            x10.xrx.Runtime.ensureNotInAtomic();
                            
                            //#line 969 "x10/regionarray/DistArray.x10"
                            final x10.regionarray.Dist __lowerer__var__0__ = ((x10.regionarray.Dist)(t$151164));
                            
                            //#line 969 "x10/regionarray/DistArray.x10"
                            for (
                                 //#line 969 "x10/regionarray/DistArray.x10"
                                 final x10.lang.Iterator __lowerer__var__3__$151700 = __lowerer__var__0__.places().iterator();
                                 ((x10.lang.Iterator<x10.lang.Place>)__lowerer__var__3__$151700).hasNext$O();
                                 ) {
                                
                                //#line 969 "x10/regionarray/DistArray.x10"
                                final x10.lang.Place __lowerer__var__3__ = ((x10.lang.Iterator<x10.lang.Place>)__lowerer__var__3__$151700).next$G();
                                
                                //#line 969 "x10/regionarray/DistArray.x10"
                                x10.xrx.Runtime.runAsync(((x10.lang.Place)(__lowerer__var__3__)), ((x10.core.fun.VoidFun_0_0)(new x10.regionarray.DistArray.$Closure$237<$T>($T, ((x10.regionarray.DistArray)(this)), __lowerer__var__0__, this.localHandle, (x10.regionarray.DistArray.$Closure$237.__0$1x10$regionarray$DistArray$$Closure$237$$T$2__2$1x10$regionarray$DistArray$LocalState$1x10$regionarray$DistArray$$Closure$237$$T$2$2) null))), ((x10.xrx.Runtime.Profile)(null)));
                            }
                        }
                    }
                }}catch (java.lang.Throwable ct$151701) {
                    
                    //#line 969 "x10/regionarray/DistArray.x10"
                    x10.xrx.Runtime.pushException(((java.lang.Throwable)(ct$151701)));
                    
                    //#line 969 "x10/regionarray/DistArray.x10"
                    throw new java.lang.RuntimeException();
                }finally {{
                     
                     //#line 969 "x10/regionarray/DistArray.x10"
                     x10.xrx.Runtime.stopFinish(((x10.xrx.FinishState)(fs$151703)));
                 }}
                }
            }
        }
    
    
    //#line 981 "x10/regionarray/DistArray.x10"
    public void sendGhostsLocal() {
        
        //#line 982 "x10/regionarray/DistArray.x10"
        final x10.lang.PlaceLocalHandle t$151166 = ((x10.lang.PlaceLocalHandle)(this.localHandle));
        
        //#line 982 "x10/regionarray/DistArray.x10"
        final x10.regionarray.DistArray.LocalState t$151167 = ((x10.regionarray.DistArray.LocalState)(((x10.lang.PlaceLocalHandle<x10.regionarray.DistArray.LocalState<$T>>)t$151166).$apply$G()));
        
        //#line 982 "x10/regionarray/DistArray.x10"
        final x10.regionarray.GhostManager ghostManager = ((x10.regionarray.GhostManager)(((x10.regionarray.DistArray.LocalState<$T>)t$151167).ghostManager));
        
        //#line 983 "x10/regionarray/DistArray.x10"
        final boolean t$151168 = ((ghostManager) != (null));
        
        //#line 983 "x10/regionarray/DistArray.x10"
        if (t$151168) {
            
            //#line 984 "x10/regionarray/DistArray.x10"
            ghostManager.sendGhosts(((x10.regionarray.Ghostable)(this)));
        }
    }
    
    
    //#line 992 "x10/regionarray/DistArray.x10"
    public void waitForGhostsLocal() {
        
        //#line 993 "x10/regionarray/DistArray.x10"
        final x10.lang.PlaceLocalHandle t$151169 = ((x10.lang.PlaceLocalHandle)(this.localHandle));
        
        //#line 993 "x10/regionarray/DistArray.x10"
        final x10.regionarray.DistArray.LocalState t$151170 = ((x10.regionarray.DistArray.LocalState)(((x10.lang.PlaceLocalHandle<x10.regionarray.DistArray.LocalState<$T>>)t$151169).$apply$G()));
        
        //#line 993 "x10/regionarray/DistArray.x10"
        final x10.regionarray.GhostManager ghostManager = ((x10.regionarray.GhostManager)(((x10.regionarray.DistArray.LocalState<$T>)t$151170).ghostManager));
        
        //#line 994 "x10/regionarray/DistArray.x10"
        final boolean t$151171 = ((ghostManager) != (null));
        
        //#line 994 "x10/regionarray/DistArray.x10"
        if (t$151171) {
            
            //#line 995 "x10/regionarray/DistArray.x10"
            ghostManager.waitOnGhosts();
        }
    }
    
    
    //#line 999 "x10/regionarray/DistArray.x10"
    public void putOverlap(final x10.regionarray.Region overlap, final x10.lang.Place neighborPlace, final x10.lang.Point shift, final byte phase) {
        
        //#line 1000 "x10/regionarray/DistArray.x10"
        final x10.regionarray.DistArray this$150731 = ((x10.regionarray.DistArray)(this));
        
        //#line 67 . "x10/regionarray/DistArray.x10"
        final x10.regionarray.Dist this$150733 = ((x10.regionarray.Dist)(((x10.regionarray.DistArray<$T>)this$150731).dist));
        
        //#line 38 .. "x10/regionarray/Dist.x10"
        final x10.regionarray.Region t$151172 = ((x10.regionarray.Region)(this$150733.region));
        
        //#line 38 .. "x10/regionarray/Dist.x10"
        final long t$151173 = t$151172.rank;
        
        //#line 1000 "x10/regionarray/DistArray.x10"
        final boolean t$151235 = ((long) t$151173) == ((long) 3L);
        
        //#line 1000 "x10/regionarray/DistArray.x10"
        if (t$151235) {
            
            //#line 1001 "x10/regionarray/DistArray.x10"
            final x10.regionarray.Region t$149738 = ((x10.regionarray.Region)
                                                      overlap);
            
            //#line 1001 "x10/regionarray/DistArray.x10"
            final boolean t$151174 = t$149738.rect;
            
            //#line 1001 "x10/regionarray/DistArray.x10"
            boolean t$151176 = ((boolean) t$151174) == ((boolean) true);
            
            //#line 1001 "x10/regionarray/DistArray.x10"
            if (t$151176) {
                
                //#line 1001 "x10/regionarray/DistArray.x10"
                final long t$151175 = t$149738.rank;
                
                //#line 1001 "x10/regionarray/DistArray.x10"
                t$151176 = ((long) t$151175) == ((long) 3L);
            }
            
            //#line 1001 "x10/regionarray/DistArray.x10"
            boolean t$151180 = t$151176;
            
            //#line 1001 "x10/regionarray/DistArray.x10"
            if (t$151176) {
                
                //#line 1001 "x10/regionarray/DistArray.x10"
                final x10.regionarray.Dist t$151177 = ((x10.regionarray.Dist)(x10.regionarray.DistArray.this.dist));
                
                //#line 1001 "x10/regionarray/DistArray.x10"
                final x10.regionarray.Region t$151178 = ((x10.regionarray.Region)(t$151177.region));
                
                //#line 1001 "x10/regionarray/DistArray.x10"
                final long t$151179 = t$151178.rank;
                
                //#line 1001 "x10/regionarray/DistArray.x10"
                t$151180 = ((long) t$151179) == ((long) 3L);
            }
            
            //#line 1001 "x10/regionarray/DistArray.x10"
            final boolean t$151183 = !(t$151180);
            
            //#line 1001 "x10/regionarray/DistArray.x10"
            if (t$151183) {
                
                //#line 1001 "x10/regionarray/DistArray.x10"
                final x10.lang.FailedDynamicCheckException t$151182 = new x10.lang.FailedDynamicCheckException("x10.regionarray.Region{self.rect==true, self.rank==3L, this(:x10.regionarray.DistArray).dist.region.rank==3L}");
                
                //#line 1001 "x10/regionarray/DistArray.x10"
                throw t$151182;
            }
            
            //#line 1001 "x10/regionarray/DistArray.x10"
            this.putOverlap3(((x10.regionarray.Region)(t$149738)), ((x10.lang.Place)(neighborPlace)), ((x10.lang.Point)(shift)), (byte)(phase));
        } else {
            
            //#line 1003 "x10/regionarray/DistArray.x10"
            final boolean t$151184 = overlap.isEmpty$O();
            
            //#line 1003 "x10/regionarray/DistArray.x10"
            final boolean t$151234 = !(t$151184);
            
            //#line 1003 "x10/regionarray/DistArray.x10"
            if (t$151234) {
                
                //#line 1004 "x10/regionarray/DistArray.x10"
                final x10.lang.Place sourcePlace = ((x10.lang.Place)(x10.x10rt.X10RT.here()));
                
                //#line 1005 "x10/regionarray/DistArray.x10"
                final x10.regionarray.DistArray this$150735 = ((x10.regionarray.DistArray)(this));
                
                //#line 1005 "x10/regionarray/DistArray.x10"
                final x10.core.Rail localRaw = ((x10.core.Rail)(((x10.regionarray.DistArray<$T>)this$150735).raw));
                
                //#line 1006 "x10/regionarray/DistArray.x10"
                final x10.regionarray.DistArray this$150737 = ((x10.regionarray.DistArray)(this));
                
                //#line 1006 "x10/regionarray/DistArray.x10"
                final x10.regionarray.Region g = ((x10.regionarray.Region)(((x10.regionarray.DistArray<$T>)this$150737).localRegion));
                
                //#line 1007 "x10/regionarray/DistArray.x10"
                final x10.regionarray.Region t$151185 = ((x10.regionarray.Region)(overlap.$plus(((x10.lang.Point)(shift)))));
                
                //#line 1007 "x10/regionarray/DistArray.x10"
                final x10.regionarray.Region t$149742 = ((x10.regionarray.Region)
                                                          t$151185);
                
                //#line 1007 "x10/regionarray/DistArray.x10"
                final boolean t$151186 = t$149742.rect;
                
                //#line 1007 "x10/regionarray/DistArray.x10"
                boolean t$151189 = ((boolean) t$151186) == ((boolean) true);
                
                //#line 1007 "x10/regionarray/DistArray.x10"
                if (t$151189) {
                    
                    //#line 1007 "x10/regionarray/DistArray.x10"
                    final long t$151187 = t$149742.rank;
                    
                    //#line 1007 "x10/regionarray/DistArray.x10"
                    final long t$151188 = overlap.rank;
                    
                    //#line 1007 "x10/regionarray/DistArray.x10"
                    t$151189 = ((long) t$151187) == ((long) t$151188);
                }
                
                //#line 1007 "x10/regionarray/DistArray.x10"
                final boolean t$151192 = !(t$151189);
                
                //#line 1007 "x10/regionarray/DistArray.x10"
                if (t$151192) {
                    
                    //#line 1007 "x10/regionarray/DistArray.x10"
                    final x10.lang.FailedDynamicCheckException t$151191 = new x10.lang.FailedDynamicCheckException("x10.regionarray.Region{self.rect==true, self.rank==overlap.rank}");
                    
                    //#line 1007 "x10/regionarray/DistArray.x10"
                    throw t$151191;
                }
                
                //#line 1008 "x10/regionarray/DistArray.x10"
                final long t$151193 = t$149742.size$O();
                
                //#line 1008 "x10/regionarray/DistArray.x10"
                final x10.core.Rail neighborPortionRaw = ((x10.core.Rail)(x10.core.Rail.<$T>makeUnsafe($T, ((long)(t$151193)), false)));
                
                //#line 1009 "x10/regionarray/DistArray.x10"
                long offset = 0L;
                
                //#line 1010 "x10/regionarray/DistArray.x10"
                final x10.lang.Iterator p$151565 = overlap.iterator();
                
                //#line 1010 "x10/regionarray/DistArray.x10"
                for (;
                     true;
                     ) {
                    
                    //#line 1010 "x10/regionarray/DistArray.x10"
                    final boolean t$151566 = ((x10.lang.Iterator<x10.lang.Point>)p$151565).hasNext$O();
                    
                    //#line 1010 "x10/regionarray/DistArray.x10"
                    if (!(t$151566)) {
                        
                        //#line 1010 "x10/regionarray/DistArray.x10"
                        break;
                    }
                    
                    //#line 1010 "x10/regionarray/DistArray.x10"
                    final x10.lang.Point p$151549 = ((x10.lang.Point)(((x10.lang.Iterator<x10.lang.Point>)p$151565).next$G()));
                    
                    //#line 1011 "x10/regionarray/DistArray.x10"
                    final long pre$151550 = offset;
                    
                    //#line 1011 "x10/regionarray/DistArray.x10"
                    final long t$151552 = ((offset) + (((long)(1L))));
                    
                    //#line 1011 "x10/regionarray/DistArray.x10"
                    offset = t$151552;
                    
                    //#line 1011 "x10/regionarray/DistArray.x10"
                    final long t$151553 = g.indexOf$O(((x10.lang.Point)(p$151549)));
                    
                    //#line 1011 "x10/regionarray/DistArray.x10"
                    final $T t$151554 = (($T)(((x10.core.Rail<$T>)localRaw).$apply$G((long)(t$151553))));
                    
                    //#line 1011 "x10/regionarray/DistArray.x10"
                    ((x10.core.Rail<$T>)neighborPortionRaw).$set__1x10$lang$Rail$$T$G((long)(pre$151550), (($T)(t$151554)));
                }
                
                //#line 1013 "x10/regionarray/DistArray.x10"
                final x10.regionarray.Array neighborPortion = ((x10.regionarray.Array)(new x10.regionarray.Array<$T>((java.lang.System[]) null, $T)));
                
                //#line 233 . "x10/regionarray/Array.x10"
                final x10.regionarray.Region t$151555 = ((x10.regionarray.Region)
                                                          t$149742);
                
                //#line 233 . "x10/regionarray/Array.x10"
                final boolean t$151556 = ((t$151555) != (null));
                
                //#line 233 . "x10/regionarray/Array.x10"
                final boolean t$151557 = !(t$151556);
                
                //#line 233 . "x10/regionarray/Array.x10"
                if (t$151557) {
                    
                    //#line 233 . "x10/regionarray/Array.x10"
                    final boolean t$151558 = true;
                    
                    //#line 233 . "x10/regionarray/Array.x10"
                    if (t$151558) {
                        
                        //#line 233 . "x10/regionarray/Array.x10"
                        final x10.lang.FailedDynamicCheckException t$151559 = new x10.lang.FailedDynamicCheckException("x10.regionarray.Region{self!=null}");
                        
                        //#line 233 . "x10/regionarray/Array.x10"
                        throw t$151559;
                    }
                }
                
                //#line 233 . "x10/regionarray/Array.x10"
                ((x10.regionarray.Array<$T>)neighborPortion).region = ((x10.regionarray.Region)(t$151555));
                
                //#line 233 . "x10/regionarray/Array.x10"
                final long t$151560 = t$149742.rank;
                
                //#line 233 . "x10/regionarray/Array.x10"
                ((x10.regionarray.Array<$T>)neighborPortion).rank = t$151560;
                
                //#line 233 . "x10/regionarray/Array.x10"
                final boolean t$151561 = t$149742.rect;
                
                //#line 233 . "x10/regionarray/Array.x10"
                ((x10.regionarray.Array<$T>)neighborPortion).rect = t$151561;
                
                //#line 233 . "x10/regionarray/Array.x10"
                final boolean t$151562 = t$149742.zeroBased;
                
                //#line 233 . "x10/regionarray/Array.x10"
                ((x10.regionarray.Array<$T>)neighborPortion).zeroBased = t$151562;
                
                //#line 233 . "x10/regionarray/Array.x10"
                final boolean t$151563 = t$149742.rail;
                
                //#line 233 . "x10/regionarray/Array.x10"
                ((x10.regionarray.Array<$T>)neighborPortion).rail = t$151563;
                
                //#line 233 . "x10/regionarray/Array.x10"
                final long t$151564 = t$149742.size$O();
                
                //#line 233 . "x10/regionarray/Array.x10"
                ((x10.regionarray.Array<$T>)neighborPortion).size = t$151564;
                
                //#line 235 . "x10/regionarray/Array.x10"
                final x10.regionarray.Array.LayoutHelper crh$151567 = new x10.regionarray.Array.LayoutHelper((java.lang.System[]) null);
                
                //#line 235 . "x10/regionarray/Array.x10"
                crh$151567.x10$regionarray$Array$LayoutHelper$$init$S(t$149742);
                
                //#line 236 . "x10/regionarray/Array.x10"
                final long t$151568 = crh$151567.min0;
                
                //#line 236 . "x10/regionarray/Array.x10"
                ((x10.regionarray.Array<$T>)neighborPortion).layout_min0 = t$151568;
                
                //#line 237 . "x10/regionarray/Array.x10"
                final long t$151569 = crh$151567.stride1;
                
                //#line 237 . "x10/regionarray/Array.x10"
                ((x10.regionarray.Array<$T>)neighborPortion).layout_stride1 = t$151569;
                
                //#line 238 . "x10/regionarray/Array.x10"
                final long t$151570 = crh$151567.min1;
                
                //#line 238 . "x10/regionarray/Array.x10"
                ((x10.regionarray.Array<$T>)neighborPortion).layout_min1 = t$151570;
                
                //#line 239 . "x10/regionarray/Array.x10"
                final x10.core.Rail t$151571 = ((x10.core.Rail)(crh$151567.layout));
                
                //#line 239 . "x10/regionarray/Array.x10"
                ((x10.regionarray.Array<$T>)neighborPortion).layout = ((x10.core.Rail)(t$151571));
                
                //#line 240 . "x10/regionarray/Array.x10"
                final long n$151572 = crh$151567.size;
                
                //#line 241 . "x10/regionarray/Array.x10"
                final long t$151573 = ((x10.core.Rail<$T>)neighborPortionRaw).size;
                
                //#line 241 . "x10/regionarray/Array.x10"
                final boolean t$151574 = ((n$151572) > (((long)(t$151573))));
                
                //#line 241 . "x10/regionarray/Array.x10"
                if (t$151574) {
                    
                    //#line 242 . "x10/regionarray/Array.x10"
                    final boolean t$151575 = true;
                    
                    //#line 242 . "x10/regionarray/Array.x10"
                    if (t$151575) {
                        
                        //#line 242 . "x10/regionarray/Array.x10"
                        final java.lang.IllegalArgumentException t$151576 = ((java.lang.IllegalArgumentException)(new java.lang.IllegalArgumentException("backingStore too small")));
                        
                        //#line 242 . "x10/regionarray/Array.x10"
                        throw t$151576;
                    }
                }
                
                //#line 244 . "x10/regionarray/Array.x10"
                final x10.core.Rail t$151577 = ((x10.core.Rail<$T>)
                                                 neighborPortionRaw);
                
                //#line 244 . "x10/regionarray/Array.x10"
                final boolean t$151578 = ((t$151577) != (null));
                
                //#line 244 . "x10/regionarray/Array.x10"
                final boolean t$151579 = !(t$151578);
                
                //#line 244 . "x10/regionarray/Array.x10"
                if (t$151579) {
                    
                    //#line 244 . "x10/regionarray/Array.x10"
                    final boolean t$151580 = true;
                    
                    //#line 244 . "x10/regionarray/Array.x10"
                    if (t$151580) {
                        
                        //#line 244 . "x10/regionarray/Array.x10"
                        final x10.lang.FailedDynamicCheckException t$151581 = new x10.lang.FailedDynamicCheckException("x10.lang.Rail[T]{self!=null}");
                        
                        //#line 244 . "x10/regionarray/Array.x10"
                        throw t$151581;
                    }
                }
                
                //#line 244 . "x10/regionarray/Array.x10"
                ((x10.regionarray.Array<$T>)neighborPortion).raw = ((x10.core.Rail)(t$151577));
                
                //#line 1014 "x10/regionarray/DistArray.x10"
                x10.xrx.Runtime.runAsync(((x10.lang.Place)(neighborPlace)), ((x10.core.fun.VoidFun_0_0)(new x10.regionarray.DistArray.$Closure$238<$T>($T, ((x10.regionarray.DistArray)(this)), this.localHandle, phase, neighborPortion, shift, sourcePlace, (x10.regionarray.DistArray.$Closure$238.__0$1x10$regionarray$DistArray$$Closure$238$$T$2__1$1x10$regionarray$DistArray$LocalState$1x10$regionarray$DistArray$$Closure$238$$T$2$2__3$1x10$regionarray$DistArray$$Closure$238$$T$2) null))), ((x10.xrx.Runtime.Profile)(null)));
            }
        }
    }
    
    
    //#line 1025 "x10/regionarray/DistArray.x10"
    private void putOverlap3(final x10.regionarray.Region overlap, final x10.lang.Place neighborPlace, final x10.lang.Point shift, final byte phase) {
        
        //#line 1026 "x10/regionarray/DistArray.x10"
        final boolean t$151236 = overlap.isEmpty$O();
        
        //#line 1026 "x10/regionarray/DistArray.x10"
        final boolean t$151300 = !(t$151236);
        
        //#line 1026 "x10/regionarray/DistArray.x10"
        if (t$151300) {
            
            //#line 1027 "x10/regionarray/DistArray.x10"
            final x10.lang.Place sourcePlace = ((x10.lang.Place)(x10.x10rt.X10RT.here()));
            
            //#line 1028 "x10/regionarray/DistArray.x10"
            final x10.regionarray.DistArray this$150747 = ((x10.regionarray.DistArray)(this));
            
            //#line 1028 "x10/regionarray/DistArray.x10"
            final x10.core.Rail localRaw = ((x10.core.Rail)(((x10.regionarray.DistArray<$T>)this$150747).raw));
            
            //#line 1029 "x10/regionarray/DistArray.x10"
            final x10.regionarray.DistArray this$150749 = ((x10.regionarray.DistArray)(this));
            
            //#line 1029 "x10/regionarray/DistArray.x10"
            final x10.regionarray.Region g = ((x10.regionarray.Region)(((x10.regionarray.DistArray<$T>)this$150749).localRegion));
            
            //#line 1030 "x10/regionarray/DistArray.x10"
            final x10.regionarray.Region t$151237 = ((x10.regionarray.Region)(overlap.$plus(((x10.lang.Point)(shift)))));
            
            //#line 1030 "x10/regionarray/DistArray.x10"
            final x10.regionarray.Region t$149757 = ((x10.regionarray.Region)
                                                      t$151237);
            
            //#line 1030 "x10/regionarray/DistArray.x10"
            final boolean t$151238 = t$149757.rect;
            
            //#line 1030 "x10/regionarray/DistArray.x10"
            boolean t$151240 = ((boolean) t$151238) == ((boolean) true);
            
            //#line 1030 "x10/regionarray/DistArray.x10"
            if (t$151240) {
                
                //#line 1030 "x10/regionarray/DistArray.x10"
                final long t$151239 = t$149757.rank;
                
                //#line 1030 "x10/regionarray/DistArray.x10"
                t$151240 = ((long) t$151239) == ((long) 3L);
            }
            
            //#line 1030 "x10/regionarray/DistArray.x10"
            boolean t$151244 = t$151240;
            
            //#line 1030 "x10/regionarray/DistArray.x10"
            if (t$151240) {
                
                //#line 1030 "x10/regionarray/DistArray.x10"
                final x10.regionarray.Dist t$151241 = ((x10.regionarray.Dist)(x10.regionarray.DistArray.this.dist));
                
                //#line 1030 "x10/regionarray/DistArray.x10"
                final x10.regionarray.Region t$151242 = ((x10.regionarray.Region)(t$151241.region));
                
                //#line 1030 "x10/regionarray/DistArray.x10"
                final long t$151243 = t$151242.rank;
                
                //#line 1030 "x10/regionarray/DistArray.x10"
                t$151244 = ((long) t$151243) == ((long) 3L);
            }
            
            //#line 1030 "x10/regionarray/DistArray.x10"
            final boolean t$151247 = !(t$151244);
            
            //#line 1030 "x10/regionarray/DistArray.x10"
            if (t$151247) {
                
                //#line 1030 "x10/regionarray/DistArray.x10"
                final x10.lang.FailedDynamicCheckException t$151246 = new x10.lang.FailedDynamicCheckException("x10.regionarray.Region{self.rect==true, self.rank==3L, this(:x10.regionarray.DistArray).dist.region.rank==3L}");
                
                //#line 1030 "x10/regionarray/DistArray.x10"
                throw t$151246;
            }
            
            //#line 1031 "x10/regionarray/DistArray.x10"
            final long t$151248 = t$149757.size$O();
            
            //#line 1031 "x10/regionarray/DistArray.x10"
            final x10.core.Rail neighborPortionRaw = ((x10.core.Rail)(x10.core.Rail.<$T>makeUnsafe($T, ((long)(t$151248)), false)));
            
            //#line 1032 "x10/regionarray/DistArray.x10"
            long offset = 0L;
            
            //#line 1033 "x10/regionarray/DistArray.x10"
            final long k$150451min$151616 = overlap.min$O((long)(2L));
            
            //#line 1033 "x10/regionarray/DistArray.x10"
            final long k$150451max$151617 = overlap.max$O((long)(2L));
            
            //#line 1033 "x10/regionarray/DistArray.x10"
            final long j$150470min$151618 = overlap.min$O((long)(1L));
            
            //#line 1033 "x10/regionarray/DistArray.x10"
            final long j$150470max$151619 = overlap.max$O((long)(1L));
            
            //#line 1033 "x10/regionarray/DistArray.x10"
            final long i$150489min$151620 = overlap.min$O((long)(0L));
            
            //#line 1033 "x10/regionarray/DistArray.x10"
            final long i$150489max$151621 = overlap.max$O((long)(0L));
            
            //#line 1033 "x10/regionarray/DistArray.x10"
            long i$151602 = i$150489min$151620;
            
            //#line 1033 "x10/regionarray/DistArray.x10"
            for (;
                 true;
                 ) {
                
                //#line 1033 "x10/regionarray/DistArray.x10"
                final boolean t$151604 = ((i$151602) <= (((long)(i$150489max$151621))));
                
                //#line 1033 "x10/regionarray/DistArray.x10"
                if (!(t$151604)) {
                    
                    //#line 1033 "x10/regionarray/DistArray.x10"
                    break;
                }
                
                //#line 1033 "x10/regionarray/DistArray.x10"
                long j$151596 = j$150470min$151618;
                
                //#line 1033 "x10/regionarray/DistArray.x10"
                for (;
                     true;
                     ) {
                    
                    //#line 1033 "x10/regionarray/DistArray.x10"
                    final boolean t$151598 = ((j$151596) <= (((long)(j$150470max$151619))));
                    
                    //#line 1033 "x10/regionarray/DistArray.x10"
                    if (!(t$151598)) {
                        
                        //#line 1033 "x10/regionarray/DistArray.x10"
                        break;
                    }
                    
                    //#line 1033 "x10/regionarray/DistArray.x10"
                    long k$151590 = k$150451min$151616;
                    
                    //#line 1033 "x10/regionarray/DistArray.x10"
                    for (;
                         true;
                         ) {
                        
                        //#line 1033 "x10/regionarray/DistArray.x10"
                        final boolean t$151592 = ((k$151590) <= (((long)(k$150451max$151617))));
                        
                        //#line 1033 "x10/regionarray/DistArray.x10"
                        if (!(t$151592)) {
                            
                            //#line 1033 "x10/regionarray/DistArray.x10"
                            break;
                        }
                        
                        //#line 1034 "x10/regionarray/DistArray.x10"
                        final long pre$151582 = offset;
                        
                        //#line 1034 "x10/regionarray/DistArray.x10"
                        final long t$151584 = ((offset) + (((long)(1L))));
                        
                        //#line 1034 "x10/regionarray/DistArray.x10"
                        offset = t$151584;
                        
                        //#line 1034 "x10/regionarray/DistArray.x10"
                        final long t$151585 = g.indexOf$O((long)(i$151602), (long)(j$151596), (long)(k$151590));
                        
                        //#line 1034 "x10/regionarray/DistArray.x10"
                        final $T t$151586 = (($T)(((x10.core.Rail<$T>)localRaw).$apply$G((long)(t$151585))));
                        
                        //#line 1034 "x10/regionarray/DistArray.x10"
                        ((x10.core.Rail<$T>)neighborPortionRaw).$set__1x10$lang$Rail$$T$G((long)(pre$151582), (($T)(t$151586)));
                        
                        //#line 1033 "x10/regionarray/DistArray.x10"
                        final long t$151589 = ((k$151590) + (((long)(1L))));
                        
                        //#line 1033 "x10/regionarray/DistArray.x10"
                        k$151590 = t$151589;
                    }
                    
                    //#line 1033 "x10/regionarray/DistArray.x10"
                    final long t$151595 = ((j$151596) + (((long)(1L))));
                    
                    //#line 1033 "x10/regionarray/DistArray.x10"
                    j$151596 = t$151595;
                }
                
                //#line 1033 "x10/regionarray/DistArray.x10"
                final long t$151601 = ((i$151602) + (((long)(1L))));
                
                //#line 1033 "x10/regionarray/DistArray.x10"
                i$151602 = t$151601;
            }
            
            //#line 1036 "x10/regionarray/DistArray.x10"
            final x10.regionarray.Array neighborPortion = ((x10.regionarray.Array)(new x10.regionarray.Array<$T>((java.lang.System[]) null, $T)));
            
            //#line 233 . "x10/regionarray/Array.x10"
            final x10.regionarray.Region t$151605 = ((x10.regionarray.Region)
                                                      t$149757);
            
            //#line 233 . "x10/regionarray/Array.x10"
            final boolean t$151606 = ((t$151605) != (null));
            
            //#line 233 . "x10/regionarray/Array.x10"
            final boolean t$151607 = !(t$151606);
            
            //#line 233 . "x10/regionarray/Array.x10"
            if (t$151607) {
                
                //#line 233 . "x10/regionarray/Array.x10"
                final boolean t$151608 = true;
                
                //#line 233 . "x10/regionarray/Array.x10"
                if (t$151608) {
                    
                    //#line 233 . "x10/regionarray/Array.x10"
                    final x10.lang.FailedDynamicCheckException t$151609 = new x10.lang.FailedDynamicCheckException("x10.regionarray.Region{self!=null}");
                    
                    //#line 233 . "x10/regionarray/Array.x10"
                    throw t$151609;
                }
            }
            
            //#line 233 . "x10/regionarray/Array.x10"
            ((x10.regionarray.Array<$T>)neighborPortion).region = ((x10.regionarray.Region)(t$151605));
            
            //#line 233 . "x10/regionarray/Array.x10"
            final long t$151610 = t$149757.rank;
            
            //#line 233 . "x10/regionarray/Array.x10"
            ((x10.regionarray.Array<$T>)neighborPortion).rank = t$151610;
            
            //#line 233 . "x10/regionarray/Array.x10"
            final boolean t$151611 = t$149757.rect;
            
            //#line 233 . "x10/regionarray/Array.x10"
            ((x10.regionarray.Array<$T>)neighborPortion).rect = t$151611;
            
            //#line 233 . "x10/regionarray/Array.x10"
            final boolean t$151612 = t$149757.zeroBased;
            
            //#line 233 . "x10/regionarray/Array.x10"
            ((x10.regionarray.Array<$T>)neighborPortion).zeroBased = t$151612;
            
            //#line 233 . "x10/regionarray/Array.x10"
            final boolean t$151613 = t$149757.rail;
            
            //#line 233 . "x10/regionarray/Array.x10"
            ((x10.regionarray.Array<$T>)neighborPortion).rail = t$151613;
            
            //#line 233 . "x10/regionarray/Array.x10"
            final long t$151614 = t$149757.size$O();
            
            //#line 233 . "x10/regionarray/Array.x10"
            ((x10.regionarray.Array<$T>)neighborPortion).size = t$151614;
            
            //#line 235 . "x10/regionarray/Array.x10"
            final x10.regionarray.Array.LayoutHelper crh$151622 = new x10.regionarray.Array.LayoutHelper((java.lang.System[]) null);
            
            //#line 235 . "x10/regionarray/Array.x10"
            crh$151622.x10$regionarray$Array$LayoutHelper$$init$S(t$149757);
            
            //#line 236 . "x10/regionarray/Array.x10"
            final long t$151623 = crh$151622.min0;
            
            //#line 236 . "x10/regionarray/Array.x10"
            ((x10.regionarray.Array<$T>)neighborPortion).layout_min0 = t$151623;
            
            //#line 237 . "x10/regionarray/Array.x10"
            final long t$151624 = crh$151622.stride1;
            
            //#line 237 . "x10/regionarray/Array.x10"
            ((x10.regionarray.Array<$T>)neighborPortion).layout_stride1 = t$151624;
            
            //#line 238 . "x10/regionarray/Array.x10"
            final long t$151625 = crh$151622.min1;
            
            //#line 238 . "x10/regionarray/Array.x10"
            ((x10.regionarray.Array<$T>)neighborPortion).layout_min1 = t$151625;
            
            //#line 239 . "x10/regionarray/Array.x10"
            final x10.core.Rail t$151626 = ((x10.core.Rail)(crh$151622.layout));
            
            //#line 239 . "x10/regionarray/Array.x10"
            ((x10.regionarray.Array<$T>)neighborPortion).layout = ((x10.core.Rail)(t$151626));
            
            //#line 240 . "x10/regionarray/Array.x10"
            final long n$151627 = crh$151622.size;
            
            //#line 241 . "x10/regionarray/Array.x10"
            final long t$151628 = ((x10.core.Rail<$T>)neighborPortionRaw).size;
            
            //#line 241 . "x10/regionarray/Array.x10"
            final boolean t$151629 = ((n$151627) > (((long)(t$151628))));
            
            //#line 241 . "x10/regionarray/Array.x10"
            if (t$151629) {
                
                //#line 242 . "x10/regionarray/Array.x10"
                final boolean t$151630 = true;
                
                //#line 242 . "x10/regionarray/Array.x10"
                if (t$151630) {
                    
                    //#line 242 . "x10/regionarray/Array.x10"
                    final java.lang.IllegalArgumentException t$151631 = ((java.lang.IllegalArgumentException)(new java.lang.IllegalArgumentException("backingStore too small")));
                    
                    //#line 242 . "x10/regionarray/Array.x10"
                    throw t$151631;
                }
            }
            
            //#line 244 . "x10/regionarray/Array.x10"
            final x10.core.Rail t$151632 = ((x10.core.Rail<$T>)
                                             neighborPortionRaw);
            
            //#line 244 . "x10/regionarray/Array.x10"
            final boolean t$151633 = ((t$151632) != (null));
            
            //#line 244 . "x10/regionarray/Array.x10"
            final boolean t$151634 = !(t$151633);
            
            //#line 244 . "x10/regionarray/Array.x10"
            if (t$151634) {
                
                //#line 244 . "x10/regionarray/Array.x10"
                final boolean t$151635 = true;
                
                //#line 244 . "x10/regionarray/Array.x10"
                if (t$151635) {
                    
                    //#line 244 . "x10/regionarray/Array.x10"
                    final x10.lang.FailedDynamicCheckException t$151636 = new x10.lang.FailedDynamicCheckException("x10.lang.Rail[T]{self!=null}");
                    
                    //#line 244 . "x10/regionarray/Array.x10"
                    throw t$151636;
                }
            }
            
            //#line 244 . "x10/regionarray/Array.x10"
            ((x10.regionarray.Array<$T>)neighborPortion).raw = ((x10.core.Rail)(t$151632));
            
            //#line 1037 "x10/regionarray/DistArray.x10"
            x10.xrx.Runtime.runAsync(((x10.lang.Place)(neighborPlace)), ((x10.core.fun.VoidFun_0_0)(new x10.regionarray.DistArray.$Closure$239<$T>($T, ((x10.regionarray.DistArray)(this)), this.localHandle, phase, neighborPortion, shift, sourcePlace, (x10.regionarray.DistArray.$Closure$239.__0$1x10$regionarray$DistArray$$Closure$239$$T$2__1$1x10$regionarray$DistArray$LocalState$1x10$regionarray$DistArray$$Closure$239$$T$2$2__3$1x10$regionarray$DistArray$$Closure$239$$T$2) null))), ((x10.xrx.Runtime.Profile)(null)));
        }
    }
    
    public static <$T>void putOverlap3$P__4$1x10$regionarray$DistArray$$T$2(final x10.rtt.Type $T, final x10.regionarray.Region overlap, final x10.lang.Place neighborPlace, final x10.lang.Point shift, final byte phase, final x10.regionarray.DistArray<$T> DistArray) {
        ((x10.regionarray.DistArray<$T>)DistArray).putOverlap3(((x10.regionarray.Region)(overlap)), ((x10.lang.Place)(neighborPlace)), ((x10.lang.Point)(shift)), (byte)(phase));
    }
    
    
    //#line 1048 "x10/regionarray/DistArray.x10"
    public java.lang.String toString() {
        
        //#line 1049 "x10/regionarray/DistArray.x10"
        final x10.regionarray.Dist t$151301 = ((x10.regionarray.Dist)(this.dist));
        
        //#line 1049 "x10/regionarray/DistArray.x10"
        final java.lang.String t$151302 = (("DistArray(") + (t$151301));
        
        //#line 1049 "x10/regionarray/DistArray.x10"
        final java.lang.String t$151303 = ((t$151302) + (")"));
        
        //#line 1049 "x10/regionarray/DistArray.x10"
        return t$151303;
    }
    
    
    //#line 1058 "x10/regionarray/DistArray.x10"
    /**
     * Return an iterator over the points in the region of this array.
     *
     * @return an iterator over the points in the region of this array.
     * @see x10.lang.Iterable[T]#iterator()
     */
    public x10.lang.Iterator iterator() {
        
        //#line 1058 "x10/regionarray/DistArray.x10"
        final x10.regionarray.DistArray this$150759 = ((x10.regionarray.DistArray)(this));
        
        //#line 62 . "x10/regionarray/DistArray.x10"
        final x10.regionarray.Dist t$151304 = ((x10.regionarray.Dist)(((x10.regionarray.DistArray<$T>)this$150759).dist));
        
        //#line 62 . "x10/regionarray/DistArray.x10"
        final x10.regionarray.Region t$151305 = ((x10.regionarray.Region)(t$151304.region));
        
        //#line 1058 "x10/regionarray/DistArray.x10"
        final x10.lang.Iterator t$151306 = t$151305.iterator();
        
        //#line 1058 "x10/regionarray/DistArray.x10"
        final x10.lang.Iterator t$151307 = ((x10.lang.Iterator<x10.lang.Point>)
                                             t$151306);
        
        //#line 1058 "x10/regionarray/DistArray.x10"
        return t$151307;
    }
    
    
    //#line 1060 "x10/regionarray/DistArray.x10"
    public static void raisePlaceError(final long i0) {
        
        //#line 1061 "x10/regionarray/DistArray.x10"
        final java.lang.String t$151308 = (("point (") + ((x10.core.Long.$box(i0))));
        
        //#line 1061 "x10/regionarray/DistArray.x10"
        final java.lang.String t$151309 = ((t$151308) + (") not defined at "));
        
        //#line 1061 "x10/regionarray/DistArray.x10"
        final java.lang.String t$151310 = ((t$151309) + (x10.x10rt.X10RT.here()));
        
        //#line 1061 "x10/regionarray/DistArray.x10"
        final x10.lang.BadPlaceException t$151311 = ((x10.lang.BadPlaceException)(new x10.lang.BadPlaceException(t$151310)));
        
        //#line 1061 "x10/regionarray/DistArray.x10"
        throw t$151311;
    }
    
    
    //#line 1063 "x10/regionarray/DistArray.x10"
    public static void raisePlaceError(final long i0, final long i1) {
        
        //#line 1064 "x10/regionarray/DistArray.x10"
        final java.lang.String t$151312 = (("point (") + ((x10.core.Long.$box(i0))));
        
        //#line 1064 "x10/regionarray/DistArray.x10"
        final java.lang.String t$151313 = ((t$151312) + (", "));
        
        //#line 1064 "x10/regionarray/DistArray.x10"
        final java.lang.String t$151314 = ((t$151313) + ((x10.core.Long.$box(i1))));
        
        //#line 1064 "x10/regionarray/DistArray.x10"
        final java.lang.String t$151315 = ((t$151314) + (") not defined at "));
        
        //#line 1064 "x10/regionarray/DistArray.x10"
        final java.lang.String t$151316 = ((t$151315) + (x10.x10rt.X10RT.here()));
        
        //#line 1064 "x10/regionarray/DistArray.x10"
        final x10.lang.BadPlaceException t$151317 = ((x10.lang.BadPlaceException)(new x10.lang.BadPlaceException(t$151316)));
        
        //#line 1064 "x10/regionarray/DistArray.x10"
        throw t$151317;
    }
    
    
    //#line 1066 "x10/regionarray/DistArray.x10"
    public static void raisePlaceError(final long i0, final long i1, final long i2) {
        
        //#line 1067 "x10/regionarray/DistArray.x10"
        final java.lang.String t$151318 = (("point (") + ((x10.core.Long.$box(i0))));
        
        //#line 1067 "x10/regionarray/DistArray.x10"
        final java.lang.String t$151319 = ((t$151318) + (", "));
        
        //#line 1067 "x10/regionarray/DistArray.x10"
        final java.lang.String t$151320 = ((t$151319) + ((x10.core.Long.$box(i1))));
        
        //#line 1067 "x10/regionarray/DistArray.x10"
        final java.lang.String t$151321 = ((t$151320) + (", "));
        
        //#line 1067 "x10/regionarray/DistArray.x10"
        final java.lang.String t$151322 = ((t$151321) + ((x10.core.Long.$box(i2))));
        
        //#line 1067 "x10/regionarray/DistArray.x10"
        final java.lang.String t$151323 = ((t$151322) + (") not defined at "));
        
        //#line 1067 "x10/regionarray/DistArray.x10"
        final java.lang.String t$151324 = ((t$151323) + (x10.x10rt.X10RT.here()));
        
        //#line 1067 "x10/regionarray/DistArray.x10"
        final x10.lang.BadPlaceException t$151325 = ((x10.lang.BadPlaceException)(new x10.lang.BadPlaceException(t$151324)));
        
        //#line 1067 "x10/regionarray/DistArray.x10"
        throw t$151325;
    }
    
    
    //#line 1069 "x10/regionarray/DistArray.x10"
    public static void raisePlaceError(final long i0, final long i1, final long i2, final long i3) {
        
        //#line 1070 "x10/regionarray/DistArray.x10"
        final java.lang.String t$151326 = (("point (") + ((x10.core.Long.$box(i0))));
        
        //#line 1070 "x10/regionarray/DistArray.x10"
        final java.lang.String t$151327 = ((t$151326) + (", "));
        
        //#line 1070 "x10/regionarray/DistArray.x10"
        final java.lang.String t$151328 = ((t$151327) + ((x10.core.Long.$box(i1))));
        
        //#line 1070 "x10/regionarray/DistArray.x10"
        final java.lang.String t$151329 = ((t$151328) + (", "));
        
        //#line 1070 "x10/regionarray/DistArray.x10"
        final java.lang.String t$151330 = ((t$151329) + ((x10.core.Long.$box(i2))));
        
        //#line 1070 "x10/regionarray/DistArray.x10"
        final java.lang.String t$151331 = ((t$151330) + (", "));
        
        //#line 1070 "x10/regionarray/DistArray.x10"
        final java.lang.String t$151332 = ((t$151331) + ((x10.core.Long.$box(i3))));
        
        //#line 1070 "x10/regionarray/DistArray.x10"
        final java.lang.String t$151333 = ((t$151332) + (") not defined at "));
        
        //#line 1070 "x10/regionarray/DistArray.x10"
        final java.lang.String t$151334 = ((t$151333) + (x10.x10rt.X10RT.here()));
        
        //#line 1070 "x10/regionarray/DistArray.x10"
        final x10.lang.BadPlaceException t$151335 = ((x10.lang.BadPlaceException)(new x10.lang.BadPlaceException(t$151334)));
        
        //#line 1070 "x10/regionarray/DistArray.x10"
        throw t$151335;
    }
    
    
    //#line 1072 "x10/regionarray/DistArray.x10"
    public static void raisePlaceError(final x10.lang.Point pt) {
        
        //#line 1073 "x10/regionarray/DistArray.x10"
        final java.lang.String t$151336 = (("point ") + (pt));
        
        //#line 1073 "x10/regionarray/DistArray.x10"
        final java.lang.String t$151337 = ((t$151336) + (" not defined at "));
        
        //#line 1073 "x10/regionarray/DistArray.x10"
        final java.lang.String t$151338 = ((t$151337) + (x10.x10rt.X10RT.here()));
        
        //#line 1073 "x10/regionarray/DistArray.x10"
        final x10.lang.BadPlaceException t$151339 = ((x10.lang.BadPlaceException)(new x10.lang.BadPlaceException(t$151338)));
        
        //#line 1073 "x10/regionarray/DistArray.x10"
        throw t$151339;
    }
    
    
    //#line 45 "x10/regionarray/DistArray.x10"
    final public x10.regionarray.DistArray x10$regionarray$DistArray$$this$x10$regionarray$DistArray() {
        
        //#line 45 "x10/regionarray/DistArray.x10"
        return x10.regionarray.DistArray.this;
    }
    
    
    //#line 45 "x10/regionarray/DistArray.x10"
    final public void __fieldInitializers_x10_regionarray_DistArray() {
        
    }
    
    
    //#line 940 "x10/regionarray/DistArray.x10"
    @x10.runtime.impl.java.X10Generated
    final public static class Anonymous$39192<$U, $T> extends x10.core.Ref implements x10.lang.Reducible, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<Anonymous$39192> $RTT = 
            x10.rtt.NamedType.<Anonymous$39192> make("x10.regionarray.DistArray.Anonymous$39192",
                                                     Anonymous$39192.class,
                                                     2,
                                                     new x10.rtt.Type[] {
                                                         x10.rtt.ParameterizedType.make(x10.lang.Reducible.$RTT, x10.rtt.UnresolvedType.PARAM(0))
                                                     });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { if (i == 0) return $U; if (i == 1) return $T; return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static <$U, $T> x10.serialization.X10JavaSerializable $_deserialize_body(x10.regionarray.DistArray.Anonymous$39192<$U, $T> $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            $_obj.$U = (x10.rtt.Type) $deserializer.readObject();
            $_obj.$T = (x10.rtt.Type) $deserializer.readObject();
            $_obj.gop = $deserializer.readObject();
            $_obj.out$ = $deserializer.readObject();
            $_obj.unit = $deserializer.readObject();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.regionarray.DistArray.Anonymous$39192 $_obj = new x10.regionarray.DistArray.Anonymous$39192((java.lang.System[]) null, (x10.rtt.Type) null, (x10.rtt.Type) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            $serializer.write(this.$U);
            $serializer.write(this.$T);
            $serializer.write(this.gop);
            $serializer.write(this.out$);
            $serializer.write(this.unit);
            
        }
        
        // constructor just for allocation
        public Anonymous$39192(final java.lang.System[] $dummy, final x10.rtt.Type $U, final x10.rtt.Type $T) {
            x10.regionarray.DistArray.Anonymous$39192.$initParams(this, $U, $T);
            
        }
        
        // dispatcher for method abstract public x10.lang.Reducible[T].operator()(a:T, b:T){}:T
        public java.lang.Object $apply(final java.lang.Object a1, final x10.rtt.Type t1, final java.lang.Object a2, final x10.rtt.Type t2) {
            return $apply__0x10$regionarray$DistArray$Anonymous$39192$$U__1x10$regionarray$DistArray$Anonymous$39192$$U$G(($U)a1, ($U)a2);
            
        }
        
        private x10.rtt.Type $U;
        private x10.rtt.Type $T;
        
        // initializer of type parameters
        public static void $initParams(final Anonymous$39192 $this, final x10.rtt.Type $U, final x10.rtt.Type $T) {
            $this.$U = $U;
            $this.$T = $T;
            
        }
        // synthetic type for parameter mangling for __0$1x10$regionarray$DistArray$Anonymous$39192$$T$2__1x10$regionarray$DistArray$Anonymous$39192$$U__2$1x10$regionarray$DistArray$Anonymous$39192$$U$3x10$regionarray$DistArray$Anonymous$39192$$U$3x10$regionarray$DistArray$Anonymous$39192$$U$2
        public static final class $_d5f1deb3 {}
        
    
        
        //#line 45 "x10/regionarray/DistArray.x10"
        public x10.regionarray.DistArray<$T> out$;
        
        //#line 939 "x10/regionarray/DistArray.x10"
        public $U unit;
        
        //#line 939 "x10/regionarray/DistArray.x10"
        public x10.core.fun.Fun_0_2<$U,$U,$U> gop;
        
        
        //#line 941 "x10/regionarray/DistArray.x10"
        public $U zero$G() {
            
            //#line 941 "x10/regionarray/DistArray.x10"
            final $U t$151340 = (($U)(x10.regionarray.DistArray.Anonymous$39192.this.unit));
            
            //#line 941 "x10/regionarray/DistArray.x10"
            return t$151340;
        }
        
        
        //#line 942 "x10/regionarray/DistArray.x10"
        public $U $apply__0x10$regionarray$DistArray$Anonymous$39192$$U__1x10$regionarray$DistArray$Anonymous$39192$$U$G(final $U a, final $U b) {
            
            //#line 942 "x10/regionarray/DistArray.x10"
            final x10.core.fun.Fun_0_2 t$151341 = x10.regionarray.DistArray.Anonymous$39192.this.gop;
            
            //#line 942 "x10/regionarray/DistArray.x10"
            final $U t$151342 = (($U)((($U)
                                        ((x10.core.fun.Fun_0_2<$U,$U,$U>)t$151341).$apply(a, $U, b, $U))));
            
            //#line 942 "x10/regionarray/DistArray.x10"
            return t$151342;
        }
        
        
        //#line 940 "x10/regionarray/DistArray.x10"
        // creation method for java code (1-phase java constructor)
        public Anonymous$39192(final x10.rtt.Type $U, final x10.rtt.Type $T, final x10.regionarray.DistArray<$T> out$, final $U unit, final x10.core.fun.Fun_0_2<$U,$U,$U> gop, $_d5f1deb3 $dummy) {
            this((java.lang.System[]) null, $U, $T);
            x10$regionarray$DistArray$Anonymous$39192$$init$S(out$, unit, gop, (x10.regionarray.DistArray.Anonymous$39192.$_d5f1deb3) null);
        }
        
        // constructor for non-virtual call
        final public x10.regionarray.DistArray.Anonymous$39192<$U, $T> x10$regionarray$DistArray$Anonymous$39192$$init$S(final x10.regionarray.DistArray<$T> out$, final $U unit, final x10.core.fun.Fun_0_2<$U,$U,$U> gop, $_d5f1deb3 $dummy) {
             {
                
                //#line 45 "x10/regionarray/DistArray.x10"
                ((x10.regionarray.DistArray.Anonymous$39192<$U, $T>)this).out$ = out$;
                
                //#line 939 "x10/regionarray/DistArray.x10"
                ((x10.regionarray.DistArray.Anonymous$39192<$U, $T>)this).unit = (($U)(unit));
                
                //#line 939 "x10/regionarray/DistArray.x10"
                ((x10.regionarray.DistArray.Anonymous$39192<$U, $T>)this).gop = gop;
            }
            return this;
        }
        
    }
    
    @x10.runtime.impl.java.X10Generated
    final public static class $Closure$223<$T> extends x10.core.Ref implements x10.core.fun.Fun_0_0, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<$Closure$223> $RTT = 
            x10.rtt.StaticFunType.<$Closure$223> make($Closure$223.class,
                                                      1,
                                                      new x10.rtt.Type[] {
                                                          x10.rtt.ParameterizedType.make(x10.core.fun.Fun_0_0.$RTT, x10.rtt.ParameterizedType.make(x10.regionarray.DistArray.LocalState.$RTT, x10.rtt.UnresolvedType.PARAM(0)))
                                                      });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { if (i == 0) return $T; return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static <$T> x10.serialization.X10JavaSerializable $_deserialize_body(x10.regionarray.DistArray.$Closure$223<$T> $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            $_obj.$T = (x10.rtt.Type) $deserializer.readObject();
            $_obj.dist = $deserializer.readObject();
            $_obj.ghostWidth = $deserializer.readLong();
            $_obj.periodic = $deserializer.readBoolean();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.regionarray.DistArray.$Closure$223 $_obj = new x10.regionarray.DistArray.$Closure$223((java.lang.System[]) null, (x10.rtt.Type) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            $serializer.write(this.$T);
            $serializer.write(this.dist);
            $serializer.write(this.ghostWidth);
            $serializer.write(this.periodic);
            
        }
        
        // constructor just for allocation
        public $Closure$223(final java.lang.System[] $dummy, final x10.rtt.Type $T) {
            x10.regionarray.DistArray.$Closure$223.$initParams(this, $T);
            
        }
        
        // bridge for method abstract public ()=>U.operator()():U
        public x10.regionarray.DistArray.LocalState $apply$G() {
            return $apply();
        }
        
        private x10.rtt.Type $T;
        
        // initializer of type parameters
        public static void $initParams(final $Closure$223 $this, final x10.rtt.Type $T) {
            $this.$T = $T;
            
        }
        
    
        
        public x10.regionarray.DistArray.LocalState $apply() {
            
            //#line 176 "x10/regionarray/DistArray.x10"
            final x10.regionarray.Region localRegion;
            
            //#line 177 "x10/regionarray/DistArray.x10"
            final x10.regionarray.GhostManager ghostManager = x10.regionarray.DistArray.getGhostManager(((x10.regionarray.Dist)(this.dist)), (long)(this.ghostWidth), (boolean)(this.periodic));
            
            //#line 178 "x10/regionarray/DistArray.x10"
            final boolean t$150818 = ((ghostManager) != (null));
            
            //#line 178 "x10/regionarray/DistArray.x10"
            if (t$150818) {
                
                //#line 179 "x10/regionarray/DistArray.x10"
                final x10.regionarray.Region t$150810 = ghostManager.getGhostRegion(((x10.lang.Place)(x10.x10rt.X10RT.here())));
                
                //#line 179 "x10/regionarray/DistArray.x10"
                final x10.regionarray.Region t$149557 = ((x10.regionarray.Region)
                                                          t$150810);
                
                //#line 179 "x10/regionarray/DistArray.x10"
                final long t$150812 = t$149557.rank;
                
                //#line 179 "x10/regionarray/DistArray.x10"
                final x10.regionarray.Region t$150811 = ((x10.regionarray.Region)(this.dist.region));
                
                //#line 179 "x10/regionarray/DistArray.x10"
                final long t$150813 = t$150811.rank;
                
                //#line 179 "x10/regionarray/DistArray.x10"
                final boolean t$150814 = ((long) t$150812) == ((long) t$150813);
                
                //#line 179 "x10/regionarray/DistArray.x10"
                final boolean t$150816 = !(t$150814);
                
                //#line 179 "x10/regionarray/DistArray.x10"
                if (t$150816) {
                    
                    //#line 179 "x10/regionarray/DistArray.x10"
                    final x10.lang.FailedDynamicCheckException t$150815 = new x10.lang.FailedDynamicCheckException("x10.regionarray.Region{self.rank==dist.region.rank}");
                    
                    //#line 179 "x10/regionarray/DistArray.x10"
                    throw t$150815;
                }
                
                //#line 179 "x10/regionarray/DistArray.x10"
                localRegion = ((x10.regionarray.Region)(t$149557));
            } else {
                
                //#line 181 "x10/regionarray/DistArray.x10"
                final x10.regionarray.Region t$150817 = ((x10.regionarray.Region)(this.dist.$apply(((x10.lang.Place)(x10.x10rt.X10RT.here())))));
                
                //#line 181 "x10/regionarray/DistArray.x10"
                localRegion = ((x10.regionarray.Region)(t$150817));
            }
            
            //#line 183 "x10/regionarray/DistArray.x10"
            final long t$150819 = localRegion.size$O();
            
            //#line 183 "x10/regionarray/DistArray.x10"
            final x10.core.Rail localRaw = ((x10.core.Rail)(new x10.core.Rail<$T>($T, t$150819)));
            
            //#line 184 "x10/regionarray/DistArray.x10"
            final x10.regionarray.DistArray.LocalState alloc$150401 = ((x10.regionarray.DistArray.LocalState)(new x10.regionarray.DistArray.LocalState<$T>((java.lang.System[]) null, $T)));
            
            //#line 184 "x10/regionarray/DistArray.x10"
            alloc$150401.x10$regionarray$DistArray$LocalState$$init$S(this.dist, ((x10.core.Rail)(localRaw)), ((x10.regionarray.Region)(localRegion)), ((x10.regionarray.GhostManager)(ghostManager)), (x10.regionarray.DistArray.LocalState.__1$1x10$regionarray$DistArray$LocalState$$T$2) null);
            
            //#line 184 "x10/regionarray/DistArray.x10"
            return alloc$150401;
        }
        
        public x10.regionarray.Dist dist;
        public long ghostWidth;
        public boolean periodic;
        
        public $Closure$223(final x10.rtt.Type $T, final x10.regionarray.Dist dist, final long ghostWidth, final boolean periodic) {
            x10.regionarray.DistArray.$Closure$223.$initParams(this, $T);
             {
                ((x10.regionarray.DistArray.$Closure$223<$T>)this).dist = ((x10.regionarray.Dist)(dist));
                ((x10.regionarray.DistArray.$Closure$223<$T>)this).ghostWidth = ghostWidth;
                ((x10.regionarray.DistArray.$Closure$223<$T>)this).periodic = periodic;
            }
        }
        
    }
    
    @x10.runtime.impl.java.X10Generated
    final public static class $Closure$224<$T> extends x10.core.Ref implements x10.core.fun.Fun_0_0, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<$Closure$224> $RTT = 
            x10.rtt.StaticFunType.<$Closure$224> make($Closure$224.class,
                                                      1,
                                                      new x10.rtt.Type[] {
                                                          x10.rtt.ParameterizedType.make(x10.core.fun.Fun_0_0.$RTT, x10.rtt.ParameterizedType.make(x10.regionarray.DistArray.LocalState.$RTT, x10.rtt.UnresolvedType.PARAM(0)))
                                                      });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { if (i == 0) return $T; return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static <$T> x10.serialization.X10JavaSerializable $_deserialize_body(x10.regionarray.DistArray.$Closure$224<$T> $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            $_obj.$T = (x10.rtt.Type) $deserializer.readObject();
            $_obj.dist = $deserializer.readObject();
            $_obj.ghostWidth = $deserializer.readLong();
            $_obj.init = $deserializer.readObject();
            $_obj.periodic = $deserializer.readBoolean();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.regionarray.DistArray.$Closure$224 $_obj = new x10.regionarray.DistArray.$Closure$224((java.lang.System[]) null, (x10.rtt.Type) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            $serializer.write(this.$T);
            $serializer.write(this.dist);
            $serializer.write(this.ghostWidth);
            $serializer.write(this.init);
            $serializer.write(this.periodic);
            
        }
        
        // constructor just for allocation
        public $Closure$224(final java.lang.System[] $dummy, final x10.rtt.Type $T) {
            x10.regionarray.DistArray.$Closure$224.$initParams(this, $T);
            
        }
        
        // bridge for method abstract public ()=>U.operator()():U
        public x10.regionarray.DistArray.LocalState $apply$G() {
            return $apply();
        }
        
        private x10.rtt.Type $T;
        
        // initializer of type parameters
        public static void $initParams(final $Closure$224 $this, final x10.rtt.Type $T) {
            $this.$T = $T;
            
        }
        // synthetic type for parameter mangling
        public static final class __3$1x10$lang$Point$3x10$regionarray$DistArray$$Closure$224$$T$2 {}
        
    
        
        public x10.regionarray.DistArray.LocalState $apply() {
            
            //#line 234 "x10/regionarray/DistArray.x10"
            final x10.regionarray.Region localRegion;
            
            //#line 235 "x10/regionarray/DistArray.x10"
            final x10.regionarray.GhostManager ghostManager = x10.regionarray.DistArray.getGhostManager(((x10.regionarray.Dist)(this.dist)), (long)(this.ghostWidth), (boolean)(this.periodic));
            
            //#line 236 "x10/regionarray/DistArray.x10"
            final boolean t$150833 = ((ghostManager) != (null));
            
            //#line 236 "x10/regionarray/DistArray.x10"
            if (t$150833) {
                
                //#line 237 "x10/regionarray/DistArray.x10"
                final x10.regionarray.Region t$150825 = ghostManager.getGhostRegion(((x10.lang.Place)(x10.x10rt.X10RT.here())));
                
                //#line 237 "x10/regionarray/DistArray.x10"
                final x10.regionarray.Region t$149559 = ((x10.regionarray.Region)
                                                          t$150825);
                
                //#line 237 "x10/regionarray/DistArray.x10"
                final long t$150827 = t$149559.rank;
                
                //#line 237 "x10/regionarray/DistArray.x10"
                final x10.regionarray.Region t$150826 = ((x10.regionarray.Region)(this.dist.region));
                
                //#line 237 "x10/regionarray/DistArray.x10"
                final long t$150828 = t$150826.rank;
                
                //#line 237 "x10/regionarray/DistArray.x10"
                final boolean t$150829 = ((long) t$150827) == ((long) t$150828);
                
                //#line 237 "x10/regionarray/DistArray.x10"
                final boolean t$150831 = !(t$150829);
                
                //#line 237 "x10/regionarray/DistArray.x10"
                if (t$150831) {
                    
                    //#line 237 "x10/regionarray/DistArray.x10"
                    final x10.lang.FailedDynamicCheckException t$150830 = new x10.lang.FailedDynamicCheckException("x10.regionarray.Region{self.rank==dist.region.rank}");
                    
                    //#line 237 "x10/regionarray/DistArray.x10"
                    throw t$150830;
                }
                
                //#line 237 "x10/regionarray/DistArray.x10"
                localRegion = ((x10.regionarray.Region)(t$149559));
            } else {
                
                //#line 239 "x10/regionarray/DistArray.x10"
                final x10.regionarray.Region t$150832 = ((x10.regionarray.Region)(this.dist.$apply(((x10.lang.Place)(x10.x10rt.X10RT.here())))));
                
                //#line 239 "x10/regionarray/DistArray.x10"
                localRegion = ((x10.regionarray.Region)(t$150832));
            }
            
            //#line 241 "x10/regionarray/DistArray.x10"
            final long t$150834 = localRegion.size$O();
            
            //#line 241 "x10/regionarray/DistArray.x10"
            final x10.core.Rail localRaw = ((x10.core.Rail)(x10.core.Rail.<$T>makeUnsafe($T, ((long)(t$150834)), false)));
            
            //#line 242 "x10/regionarray/DistArray.x10"
            final x10.regionarray.Region reg = ((x10.regionarray.Region)(this.dist.$apply(((x10.lang.Place)(x10.x10rt.X10RT.here())))));
            
            //#line 243 "x10/regionarray/DistArray.x10"
            final x10.lang.Iterator pt$151375 = reg.iterator();
            
            //#line 243 "x10/regionarray/DistArray.x10"
            for (;
                 true;
                 ) {
                
                //#line 243 "x10/regionarray/DistArray.x10"
                final boolean t$151376 = ((x10.lang.Iterator<x10.lang.Point>)pt$151375).hasNext$O();
                
                //#line 243 "x10/regionarray/DistArray.x10"
                if (!(t$151376)) {
                    
                    //#line 243 "x10/regionarray/DistArray.x10"
                    break;
                }
                
                //#line 243 "x10/regionarray/DistArray.x10"
                final x10.lang.Point pt$151372 = ((x10.lang.Point)(((x10.lang.Iterator<x10.lang.Point>)pt$151375).next$G()));
                
                //#line 244 "x10/regionarray/DistArray.x10"
                final long t$151373 = localRegion.indexOf$O(((x10.lang.Point)(pt$151372)));
                
                //#line 244 "x10/regionarray/DistArray.x10"
                final $T t$151374 = (($T)((($T)
                                            ((x10.core.fun.Fun_0_1<x10.lang.Point,$T>)this.init).$apply(pt$151372, x10.lang.Point.$RTT))));
                
                //#line 244 "x10/regionarray/DistArray.x10"
                ((x10.core.Rail<$T>)localRaw).$set__1x10$lang$Rail$$T$G((long)(t$151373), (($T)(t$151374)));
            }
            
            //#line 246 "x10/regionarray/DistArray.x10"
            final x10.regionarray.DistArray.LocalState alloc$150404 = ((x10.regionarray.DistArray.LocalState)(new x10.regionarray.DistArray.LocalState<$T>((java.lang.System[]) null, $T)));
            
            //#line 246 "x10/regionarray/DistArray.x10"
            alloc$150404.x10$regionarray$DistArray$LocalState$$init$S(this.dist, ((x10.core.Rail)(localRaw)), ((x10.regionarray.Region)(localRegion)), ((x10.regionarray.GhostManager)(ghostManager)), (x10.regionarray.DistArray.LocalState.__1$1x10$regionarray$DistArray$LocalState$$T$2) null);
            
            //#line 246 "x10/regionarray/DistArray.x10"
            return alloc$150404;
        }
        
        public x10.regionarray.Dist dist;
        public long ghostWidth;
        public boolean periodic;
        public x10.core.fun.Fun_0_1<x10.lang.Point,$T> init;
        
        public $Closure$224(final x10.rtt.Type $T, final x10.regionarray.Dist dist, final long ghostWidth, final boolean periodic, final x10.core.fun.Fun_0_1<x10.lang.Point,$T> init, __3$1x10$lang$Point$3x10$regionarray$DistArray$$Closure$224$$T$2 $dummy) {
            x10.regionarray.DistArray.$Closure$224.$initParams(this, $T);
             {
                ((x10.regionarray.DistArray.$Closure$224<$T>)this).dist = ((x10.regionarray.Dist)(dist));
                ((x10.regionarray.DistArray.$Closure$224<$T>)this).ghostWidth = ghostWidth;
                ((x10.regionarray.DistArray.$Closure$224<$T>)this).periodic = periodic;
                ((x10.regionarray.DistArray.$Closure$224<$T>)this).init = ((x10.core.fun.Fun_0_1)(init));
            }
        }
        
    }
    
    @x10.runtime.impl.java.X10Generated
    final public static class $Closure$225<$T> extends x10.core.Ref implements x10.core.fun.Fun_0_0, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<$Closure$225> $RTT = 
            x10.rtt.StaticFunType.<$Closure$225> make($Closure$225.class,
                                                      1,
                                                      new x10.rtt.Type[] {
                                                          x10.rtt.ParameterizedType.make(x10.core.fun.Fun_0_0.$RTT, x10.rtt.ParameterizedType.make(x10.regionarray.DistArray.LocalState.$RTT, x10.rtt.UnresolvedType.PARAM(0)))
                                                      });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { if (i == 0) return $T; return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static <$T> x10.serialization.X10JavaSerializable $_deserialize_body(x10.regionarray.DistArray.$Closure$225<$T> $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            $_obj.$T = (x10.rtt.Type) $deserializer.readObject();
            $_obj.dist = $deserializer.readObject();
            $_obj.ghostWidth = $deserializer.readLong();
            $_obj.init = $deserializer.readObject();
            $_obj.periodic = $deserializer.readBoolean();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.regionarray.DistArray.$Closure$225 $_obj = new x10.regionarray.DistArray.$Closure$225((java.lang.System[]) null, (x10.rtt.Type) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            $serializer.write(this.$T);
            $serializer.write(this.dist);
            $serializer.write(this.ghostWidth);
            $serializer.write(this.init);
            $serializer.write(this.periodic);
            
        }
        
        // constructor just for allocation
        public $Closure$225(final java.lang.System[] $dummy, final x10.rtt.Type $T) {
            x10.regionarray.DistArray.$Closure$225.$initParams(this, $T);
            
        }
        
        // bridge for method abstract public ()=>U.operator()():U
        public x10.regionarray.DistArray.LocalState $apply$G() {
            return $apply();
        }
        
        private x10.rtt.Type $T;
        
        // initializer of type parameters
        public static void $initParams(final $Closure$225 $this, final x10.rtt.Type $T) {
            $this.$T = $T;
            
        }
        // synthetic type for parameter mangling
        public static final class __3x10$regionarray$DistArray$$Closure$225$$T {}
        
    
        
        public x10.regionarray.DistArray.LocalState $apply() {
            
            //#line 283 "x10/regionarray/DistArray.x10"
            final x10.regionarray.Region localRegion;
            
            //#line 284 "x10/regionarray/DistArray.x10"
            final x10.regionarray.GhostManager ghostManager = x10.regionarray.DistArray.getGhostManager(((x10.regionarray.Dist)(this.dist)), (long)(this.ghostWidth), (boolean)(this.periodic));
            
            //#line 285 "x10/regionarray/DistArray.x10"
            final boolean t$150852 = ((ghostManager) != (null));
            
            //#line 285 "x10/regionarray/DistArray.x10"
            if (t$150852) {
                
                //#line 286 "x10/regionarray/DistArray.x10"
                final x10.regionarray.Region t$150844 = ghostManager.getGhostRegion(((x10.lang.Place)(x10.x10rt.X10RT.here())));
                
                //#line 286 "x10/regionarray/DistArray.x10"
                final x10.regionarray.Region t$149561 = ((x10.regionarray.Region)
                                                          t$150844);
                
                //#line 286 "x10/regionarray/DistArray.x10"
                final long t$150846 = t$149561.rank;
                
                //#line 286 "x10/regionarray/DistArray.x10"
                final x10.regionarray.Region t$150845 = ((x10.regionarray.Region)(this.dist.region));
                
                //#line 286 "x10/regionarray/DistArray.x10"
                final long t$150847 = t$150845.rank;
                
                //#line 286 "x10/regionarray/DistArray.x10"
                final boolean t$150848 = ((long) t$150846) == ((long) t$150847);
                
                //#line 286 "x10/regionarray/DistArray.x10"
                final boolean t$150850 = !(t$150848);
                
                //#line 286 "x10/regionarray/DistArray.x10"
                if (t$150850) {
                    
                    //#line 286 "x10/regionarray/DistArray.x10"
                    final x10.lang.FailedDynamicCheckException t$150849 = new x10.lang.FailedDynamicCheckException("x10.regionarray.Region{self.rank==dist.region.rank}");
                    
                    //#line 286 "x10/regionarray/DistArray.x10"
                    throw t$150849;
                }
                
                //#line 286 "x10/regionarray/DistArray.x10"
                localRegion = ((x10.regionarray.Region)(t$149561));
            } else {
                
                //#line 288 "x10/regionarray/DistArray.x10"
                final x10.regionarray.Region t$150851 = ((x10.regionarray.Region)(this.dist.$apply(((x10.lang.Place)(x10.x10rt.X10RT.here())))));
                
                //#line 288 "x10/regionarray/DistArray.x10"
                localRegion = ((x10.regionarray.Region)(t$150851));
            }
            
            //#line 290 "x10/regionarray/DistArray.x10"
            final long t$150853 = localRegion.size$O();
            
            //#line 290 "x10/regionarray/DistArray.x10"
            final x10.core.Rail localRaw = ((x10.core.Rail)(new x10.core.Rail<$T>($T, t$150853, this.init, (x10.core.Rail.__1x10$lang$Rail$$T) null)));
            
            //#line 291 "x10/regionarray/DistArray.x10"
            final x10.regionarray.DistArray.LocalState alloc$150407 = ((x10.regionarray.DistArray.LocalState)(new x10.regionarray.DistArray.LocalState<$T>((java.lang.System[]) null, $T)));
            
            //#line 291 "x10/regionarray/DistArray.x10"
            alloc$150407.x10$regionarray$DistArray$LocalState$$init$S(this.dist, ((x10.core.Rail)(localRaw)), ((x10.regionarray.Region)(localRegion)), ((x10.regionarray.GhostManager)(ghostManager)), (x10.regionarray.DistArray.LocalState.__1$1x10$regionarray$DistArray$LocalState$$T$2) null);
            
            //#line 291 "x10/regionarray/DistArray.x10"
            return alloc$150407;
        }
        
        public x10.regionarray.Dist dist;
        public long ghostWidth;
        public boolean periodic;
        public $T init;
        
        public $Closure$225(final x10.rtt.Type $T, final x10.regionarray.Dist dist, final long ghostWidth, final boolean periodic, final $T init, __3x10$regionarray$DistArray$$Closure$225$$T $dummy) {
            x10.regionarray.DistArray.$Closure$225.$initParams(this, $T);
             {
                ((x10.regionarray.DistArray.$Closure$225<$T>)this).dist = ((x10.regionarray.Dist)(dist));
                ((x10.regionarray.DistArray.$Closure$225<$T>)this).ghostWidth = ghostWidth;
                ((x10.regionarray.DistArray.$Closure$225<$T>)this).periodic = periodic;
                ((x10.regionarray.DistArray.$Closure$225<$T>)this).init = (($T)(init));
            }
        }
        
    }
    
    @x10.runtime.impl.java.X10Generated
    final public static class $Closure$226<$T> extends x10.core.Ref implements x10.core.fun.Fun_0_0, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<$Closure$226> $RTT = 
            x10.rtt.StaticFunType.<$Closure$226> make($Closure$226.class,
                                                      1,
                                                      new x10.rtt.Type[] {
                                                          x10.rtt.ParameterizedType.make(x10.core.fun.Fun_0_0.$RTT, x10.rtt.ParameterizedType.make(x10.regionarray.DistArray.LocalState.$RTT, x10.rtt.UnresolvedType.PARAM(0)))
                                                      });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { if (i == 0) return $T; return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static <$T> x10.serialization.X10JavaSerializable $_deserialize_body(x10.regionarray.DistArray.$Closure$226<$T> $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            $_obj.$T = (x10.rtt.Type) $deserializer.readObject();
            $_obj.a = $deserializer.readObject();
            $_obj.d = $deserializer.readObject();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.regionarray.DistArray.$Closure$226 $_obj = new x10.regionarray.DistArray.$Closure$226((java.lang.System[]) null, (x10.rtt.Type) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            $serializer.write(this.$T);
            $serializer.write(this.a);
            $serializer.write(this.d);
            
        }
        
        // constructor just for allocation
        public $Closure$226(final java.lang.System[] $dummy, final x10.rtt.Type $T) {
            x10.regionarray.DistArray.$Closure$226.$initParams(this, $T);
            
        }
        
        // bridge for method abstract public ()=>U.operator()():U
        public x10.regionarray.DistArray.LocalState $apply$G() {
            return $apply();
        }
        
        private x10.rtt.Type $T;
        
        // initializer of type parameters
        public static void $initParams(final $Closure$226 $this, final x10.rtt.Type $T) {
            $this.$T = $T;
            
        }
        // synthetic type for parameter mangling
        public static final class __0$1x10$regionarray$DistArray$$Closure$226$$T$2 {}
        
    
        
        public x10.regionarray.DistArray.LocalState $apply() {
            
            //#line 313 "x10/regionarray/DistArray.x10"
            final x10.lang.PlaceLocalHandle t$150859 = ((x10.lang.PlaceLocalHandle)(((x10.regionarray.DistArray<$T>)this.a).localHandle));
            
            //#line 313 "x10/regionarray/DistArray.x10"
            final x10.regionarray.DistArray.LocalState local = ((x10.regionarray.DistArray.LocalState)(((x10.lang.PlaceLocalHandle<x10.regionarray.DistArray.LocalState<$T>>)t$150859).$apply$G()));
            
            //#line 314 "x10/regionarray/DistArray.x10"
            final x10.regionarray.DistArray.LocalState alloc$150408 = ((x10.regionarray.DistArray.LocalState)(new x10.regionarray.DistArray.LocalState<$T>((java.lang.System[]) null, $T)));
            
            //#line 314 "x10/regionarray/DistArray.x10"
            final x10.core.Rail t$151379 = ((x10.core.Rail)(((x10.regionarray.DistArray.LocalState<$T>)local).data));
            
            //#line 314 "x10/regionarray/DistArray.x10"
            final x10.regionarray.Region t$151380 = ((x10.regionarray.Region)(((x10.regionarray.DistArray.LocalState<$T>)local).localRegion));
            
            //#line 314 "x10/regionarray/DistArray.x10"
            final x10.regionarray.Region t$151381 = ((x10.regionarray.Region)
                                                      t$151380);
            
            //#line 314 "x10/regionarray/DistArray.x10"
            final long t$151382 = t$151381.rank;
            
            //#line 314 "x10/regionarray/DistArray.x10"
            final x10.regionarray.Region t$151383 = ((x10.regionarray.Region)(this.d.region));
            
            //#line 314 "x10/regionarray/DistArray.x10"
            final long t$151384 = t$151383.rank;
            
            //#line 314 "x10/regionarray/DistArray.x10"
            final boolean t$151385 = ((long) t$151382) == ((long) t$151384);
            
            //#line 314 "x10/regionarray/DistArray.x10"
            final boolean t$151386 = !(t$151385);
            
            //#line 314 "x10/regionarray/DistArray.x10"
            if (t$151386) {
                
                //#line 314 "x10/regionarray/DistArray.x10"
                final x10.lang.FailedDynamicCheckException t$151387 = new x10.lang.FailedDynamicCheckException("x10.regionarray.Region{self.rank==d.region.rank}");
                
                //#line 314 "x10/regionarray/DistArray.x10"
                throw t$151387;
            }
            
            //#line 314 "x10/regionarray/DistArray.x10"
            alloc$150408.x10$regionarray$DistArray$LocalState$$init$S(this.d, ((x10.core.Rail)(t$151379)), ((x10.regionarray.Region)(t$151381)), ((x10.regionarray.GhostManager)(null)), (x10.regionarray.DistArray.LocalState.__1$1x10$regionarray$DistArray$LocalState$$T$2) null);
            
            //#line 314 "x10/regionarray/DistArray.x10"
            return alloc$150408;
        }
        
        public x10.regionarray.DistArray<$T> a;
        public x10.regionarray.Dist d;
        
        public $Closure$226(final x10.rtt.Type $T, final x10.regionarray.DistArray<$T> a, final x10.regionarray.Dist d, __0$1x10$regionarray$DistArray$$Closure$226$$T$2 $dummy) {
            x10.regionarray.DistArray.$Closure$226.$initParams(this, $T);
             {
                ((x10.regionarray.DistArray.$Closure$226<$T>)this).a = ((x10.regionarray.DistArray)(a));
                ((x10.regionarray.DistArray.$Closure$226<$T>)this).d = ((x10.regionarray.Dist)(d));
            }
        }
        
    }
    
    @x10.runtime.impl.java.X10Generated
    final public static class $Closure$227<$T> extends x10.core.Ref implements x10.core.fun.Fun_0_1, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<$Closure$227> $RTT = 
            x10.rtt.StaticFunType.<$Closure$227> make($Closure$227.class,
                                                      1,
                                                      new x10.rtt.Type[] {
                                                          x10.rtt.ParameterizedType.make(x10.core.fun.Fun_0_1.$RTT, x10.rtt.Types.LONG, x10.rtt.Types.LONG)
                                                      });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { if (i == 0) return $T; return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static <$T> x10.serialization.X10JavaSerializable $_deserialize_body(x10.regionarray.DistArray.$Closure$227<$T> $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            $_obj.$T = (x10.rtt.Type) $deserializer.readObject();
            $_obj.regionHere = $deserializer.readObject();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.regionarray.DistArray.$Closure$227 $_obj = new x10.regionarray.DistArray.$Closure$227((java.lang.System[]) null, (x10.rtt.Type) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            $serializer.write(this.$T);
            $serializer.write(this.regionHere);
            
        }
        
        // constructor just for allocation
        public $Closure$227(final java.lang.System[] $dummy, final x10.rtt.Type $T) {
            x10.regionarray.DistArray.$Closure$227.$initParams(this, $T);
            
        }
        
        // dispatcher for method abstract public (Z1)=>U.operator()(a1:Z1):U
        public java.lang.Object $apply(final java.lang.Object a1, final x10.rtt.Type t1) {
            return x10.core.Long.$box($apply$O(x10.core.Long.$unbox(a1)));
            
        }
        
        // dispatcher for method abstract public (Z1)=>U.operator()(a1:Z1):U
        public long $apply$J(final java.lang.Object a1, final x10.rtt.Type t1) {
            return $apply$O(x10.core.Long.$unbox(a1));
            
        }
        
        private x10.rtt.Type $T;
        
        // initializer of type parameters
        public static void $initParams(final $Closure$227 $this, final x10.rtt.Type $T) {
            $this.$T = $T;
            
        }
        
    
        
        public long $apply$O(final long i) {
            
            //#line 707 "x10/regionarray/DistArray.x10"
            final long t$151023 = this.regionHere.max$O((long)(i));
            
            //#line 707 "x10/regionarray/DistArray.x10"
            final long t$151024 = this.regionHere.min$O((long)(i));
            
            //#line 707 "x10/regionarray/DistArray.x10"
            final long t$151025 = ((t$151023) - (((long)(t$151024))));
            
            //#line 707 "x10/regionarray/DistArray.x10"
            final long t$151026 = ((t$151025) + (((long)(1L))));
            
            //#line 707 "x10/regionarray/DistArray.x10"
            return t$151026;
        }
        
        public x10.regionarray.Region regionHere;
        
        public $Closure$227(final x10.rtt.Type $T, final x10.regionarray.Region regionHere) {
            x10.regionarray.DistArray.$Closure$227.$initParams(this, $T);
             {
                ((x10.regionarray.DistArray.$Closure$227<$T>)this).regionHere = ((x10.regionarray.Region)(regionHere));
            }
        }
        
    }
    
    @x10.runtime.impl.java.X10Generated
    final public static class $Closure$228<$T> extends x10.core.Ref implements x10.core.fun.VoidFun_0_0, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<$Closure$228> $RTT = 
            x10.rtt.StaticVoidFunType.<$Closure$228> make($Closure$228.class,
                                                          1,
                                                          new x10.rtt.Type[] {
                                                              x10.core.fun.VoidFun_0_0.$RTT
                                                          });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { if (i == 0) return $T; return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static <$T> x10.serialization.X10JavaSerializable $_deserialize_body(x10.regionarray.DistArray.$Closure$228<$T> $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            $_obj.$T = (x10.rtt.Type) $deserializer.readObject();
            $_obj.dist = $deserializer.readObject();
            $_obj.out$$ = $deserializer.readObject();
            $_obj.v = $deserializer.readObject();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.regionarray.DistArray.$Closure$228 $_obj = new x10.regionarray.DistArray.$Closure$228((java.lang.System[]) null, (x10.rtt.Type) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            $serializer.write(this.$T);
            $serializer.write(this.dist);
            $serializer.write(this.out$$);
            $serializer.write(this.v);
            
        }
        
        // constructor just for allocation
        public $Closure$228(final java.lang.System[] $dummy, final x10.rtt.Type $T) {
            x10.regionarray.DistArray.$Closure$228.$initParams(this, $T);
            
        }
        
        private x10.rtt.Type $T;
        
        // initializer of type parameters
        public static void $initParams(final $Closure$228 $this, final x10.rtt.Type $T) {
            $this.$T = $T;
            
        }
        // synthetic type for parameter mangling
        public static final class __0$1x10$regionarray$DistArray$$Closure$228$$T$2__2x10$regionarray$DistArray$$Closure$228$$T {}
        
    
        
        public void $apply() {
            
            //#line 727 "x10/regionarray/DistArray.x10"
            try {{
                
                //#line 728 "x10/regionarray/DistArray.x10"
                final x10.regionarray.Dist t$151449 = ((x10.regionarray.Dist)(this.dist));
                
                //#line 728 "x10/regionarray/DistArray.x10"
                final x10.regionarray.Region reg$151450 = ((x10.regionarray.Region)(t$151449.$apply(((x10.lang.Place)(x10.x10rt.X10RT.here())))));
                
                //#line 729 "x10/regionarray/DistArray.x10"
                final x10.regionarray.DistArray this$151451 = ((x10.regionarray.DistArray)(this.out$$));
                
                //#line 729 "x10/regionarray/DistArray.x10"
                final x10.regionarray.Region localRegion$151452 = ((x10.regionarray.Region)(((x10.regionarray.DistArray<$T>)this$151451).localRegion));
                
                //#line 730 "x10/regionarray/DistArray.x10"
                final x10.core.Rail rail$151453 = ((x10.core.Rail)(((x10.regionarray.DistArray<$T>)this.out$$).raw));
                
                //#line 731 "x10/regionarray/DistArray.x10"
                final x10.lang.Iterator pt$151446 = reg$151450.iterator();
                
                //#line 731 "x10/regionarray/DistArray.x10"
                for (;
                     true;
                     ) {
                    
                    //#line 731 "x10/regionarray/DistArray.x10"
                    final boolean t$151447 = ((x10.lang.Iterator<x10.lang.Point>)pt$151446).hasNext$O();
                    
                    //#line 731 "x10/regionarray/DistArray.x10"
                    if (!(t$151447)) {
                        
                        //#line 731 "x10/regionarray/DistArray.x10"
                        break;
                    }
                    
                    //#line 731 "x10/regionarray/DistArray.x10"
                    final x10.lang.Point pt$151444 = ((x10.lang.Point)(((x10.lang.Iterator<x10.lang.Point>)pt$151446).next$G()));
                    
                    //#line 732 "x10/regionarray/DistArray.x10"
                    final long t$151445 = localRegion$151452.indexOf$O(((x10.lang.Point)(pt$151444)));
                    
                    //#line 732 "x10/regionarray/DistArray.x10"
                    ((x10.core.Rail<$T>)rail$151453).$set__1x10$lang$Rail$$T$G((long)(t$151445), (($T)(this.v)));
                }
            }}catch (java.lang.Error __lowerer__var__0__) {
                
                //#line 727 "x10/regionarray/DistArray.x10"
                throw __lowerer__var__0__;
            }catch (java.lang.Throwable __lowerer__var__1__) {
                
                //#line 727 "x10/regionarray/DistArray.x10"
                throw x10.rtt.Types.EXCEPTION.isInstance(__lowerer__var__1__) ? (java.lang.RuntimeException)(__lowerer__var__1__) : new x10.lang.WrappedThrowable(__lowerer__var__1__);
            }
        }
        
        public x10.regionarray.DistArray<$T> out$$;
        public x10.regionarray.Dist dist;
        public $T v;
        
        public $Closure$228(final x10.rtt.Type $T, final x10.regionarray.DistArray<$T> out$$, final x10.regionarray.Dist dist, final $T v, __0$1x10$regionarray$DistArray$$Closure$228$$T$2__2x10$regionarray$DistArray$$Closure$228$$T $dummy) {
            x10.regionarray.DistArray.$Closure$228.$initParams(this, $T);
             {
                ((x10.regionarray.DistArray.$Closure$228<$T>)this).out$$ = out$$;
                ((x10.regionarray.DistArray.$Closure$228<$T>)this).dist = ((x10.regionarray.Dist)(dist));
                ((x10.regionarray.DistArray.$Closure$228<$T>)this).v = (($T)(v));
            }
        }
        
    }
    
    @x10.runtime.impl.java.X10Generated
    final public static class $Closure$229<$T, $U> extends x10.core.Ref implements x10.core.fun.Fun_0_0, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<$Closure$229> $RTT = 
            x10.rtt.StaticFunType.<$Closure$229> make($Closure$229.class,
                                                      2,
                                                      new x10.rtt.Type[] {
                                                          x10.rtt.ParameterizedType.make(x10.core.fun.Fun_0_0.$RTT, x10.rtt.ParameterizedType.make(x10.regionarray.DistArray.LocalState.$RTT, x10.rtt.UnresolvedType.PARAM(1)))
                                                      });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { if (i == 0) return $T; if (i == 1) return $U; return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static <$T, $U> x10.serialization.X10JavaSerializable $_deserialize_body(x10.regionarray.DistArray.$Closure$229<$T, $U> $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            $_obj.$T = (x10.rtt.Type) $deserializer.readObject();
            $_obj.$U = (x10.rtt.Type) $deserializer.readObject();
            $_obj.dist = $deserializer.readObject();
            $_obj.op = $deserializer.readObject();
            $_obj.out$$ = $deserializer.readObject();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.regionarray.DistArray.$Closure$229 $_obj = new x10.regionarray.DistArray.$Closure$229((java.lang.System[]) null, (x10.rtt.Type) null, (x10.rtt.Type) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            $serializer.write(this.$T);
            $serializer.write(this.$U);
            $serializer.write(this.dist);
            $serializer.write(this.op);
            $serializer.write(this.out$$);
            
        }
        
        // constructor just for allocation
        public $Closure$229(final java.lang.System[] $dummy, final x10.rtt.Type $T, final x10.rtt.Type $U) {
            x10.regionarray.DistArray.$Closure$229.$initParams(this, $T, $U);
            
        }
        
        // bridge for method abstract public ()=>U.operator()():U
        public x10.regionarray.DistArray.LocalState $apply$G() {
            return $apply();
        }
        
        private x10.rtt.Type $T;
        private x10.rtt.Type $U;
        
        // initializer of type parameters
        public static void $initParams(final $Closure$229 $this, final x10.rtt.Type $T, final x10.rtt.Type $U) {
            $this.$T = $T;
            $this.$U = $U;
            
        }
        // synthetic type for parameter mangling
        public static final class __0$1x10$regionarray$DistArray$$Closure$229$$T$2__2$1x10$regionarray$DistArray$$Closure$229$$T$3x10$regionarray$DistArray$$Closure$229$$U$2 {}
        
    
        
        public x10.regionarray.DistArray.LocalState $apply() {
            
            //#line 751 "x10/regionarray/DistArray.x10"
            final x10.regionarray.DistArray this$150692 = ((x10.regionarray.DistArray)(this.out$$));
            
            //#line 751 "x10/regionarray/DistArray.x10"
            final x10.core.Rail srcRail = ((x10.core.Rail)(((x10.regionarray.DistArray<$T>)this$150692).raw));
            
            //#line 752 "x10/regionarray/DistArray.x10"
            final x10.regionarray.DistArray this$150694 = ((x10.regionarray.DistArray)(this.out$$));
            
            //#line 752 "x10/regionarray/DistArray.x10"
            final x10.regionarray.Region localRegion = ((x10.regionarray.Region)(((x10.regionarray.DistArray<$T>)this$150694).localRegion));
            
            //#line 753 "x10/regionarray/DistArray.x10"
            final long t$151084 = localRegion.size$O();
            
            //#line 753 "x10/regionarray/DistArray.x10"
            final x10.core.Rail newRail = ((x10.core.Rail)(x10.core.Rail.<$U>makeUnsafe($U, ((long)(t$151084)), false)));
            
            //#line 754 "x10/regionarray/DistArray.x10"
            final x10.regionarray.Dist t$151085 = ((x10.regionarray.Dist)(this.dist));
            
            //#line 754 "x10/regionarray/DistArray.x10"
            final x10.regionarray.Region reg = ((x10.regionarray.Region)(t$151085.$apply(((x10.lang.Place)(x10.x10rt.X10RT.here())))));
            
            //#line 755 "x10/regionarray/DistArray.x10"
            final x10.lang.Iterator pt$151458 = reg.iterator();
            
            //#line 755 "x10/regionarray/DistArray.x10"
            for (;
                 true;
                 ) {
                
                //#line 755 "x10/regionarray/DistArray.x10"
                final boolean t$151459 = ((x10.lang.Iterator<x10.lang.Point>)pt$151458).hasNext$O();
                
                //#line 755 "x10/regionarray/DistArray.x10"
                if (!(t$151459)) {
                    
                    //#line 755 "x10/regionarray/DistArray.x10"
                    break;
                }
                
                //#line 755 "x10/regionarray/DistArray.x10"
                final x10.lang.Point pt$151454 = ((x10.lang.Point)(((x10.lang.Iterator<x10.lang.Point>)pt$151458).next$G()));
                
                //#line 756 "x10/regionarray/DistArray.x10"
                final long offset$151455 = localRegion.indexOf$O(((x10.lang.Point)(pt$151454)));
                
                //#line 757 "x10/regionarray/DistArray.x10"
                final $T t$151456 = (($T)(((x10.core.Rail<$T>)srcRail).$apply$G((long)(offset$151455))));
                
                //#line 757 "x10/regionarray/DistArray.x10"
                final $U t$151457 = (($U)((($U)
                                            ((x10.core.fun.Fun_0_1<$T,$U>)this.op).$apply(t$151456, $T))));
                
                //#line 757 "x10/regionarray/DistArray.x10"
                ((x10.core.Rail<$U>)newRail).$set__1x10$lang$Rail$$T$G((long)(offset$151455), (($U)(t$151457)));
            }
            
            //#line 759 "x10/regionarray/DistArray.x10"
            final x10.regionarray.DistArray.LocalState alloc$150411 = ((x10.regionarray.DistArray.LocalState)(new x10.regionarray.DistArray.LocalState<$U>((java.lang.System[]) null, $U)));
            
            //#line 759 "x10/regionarray/DistArray.x10"
            final x10.regionarray.Dist t$151460 = ((x10.regionarray.Dist)(this.dist));
            
            //#line 759 "x10/regionarray/DistArray.x10"
            alloc$150411.x10$regionarray$DistArray$LocalState$$init$S(((x10.regionarray.Dist)(t$151460)), ((x10.core.Rail)(newRail)), (x10.regionarray.DistArray.LocalState.__1$1x10$regionarray$DistArray$LocalState$$T$2) null);
            
            //#line 759 "x10/regionarray/DistArray.x10"
            return alloc$150411;
        }
        
        public x10.regionarray.DistArray<$T> out$$;
        public x10.regionarray.Dist dist;
        public x10.core.fun.Fun_0_1<$T,$U> op;
        
        public $Closure$229(final x10.rtt.Type $T, final x10.rtt.Type $U, final x10.regionarray.DistArray<$T> out$$, final x10.regionarray.Dist dist, final x10.core.fun.Fun_0_1<$T,$U> op, __0$1x10$regionarray$DistArray$$Closure$229$$T$2__2$1x10$regionarray$DistArray$$Closure$229$$T$3x10$regionarray$DistArray$$Closure$229$$U$2 $dummy) {
            x10.regionarray.DistArray.$Closure$229.$initParams(this, $T, $U);
             {
                ((x10.regionarray.DistArray.$Closure$229<$T, $U>)this).out$$ = out$$;
                ((x10.regionarray.DistArray.$Closure$229<$T, $U>)this).dist = ((x10.regionarray.Dist)(dist));
                ((x10.regionarray.DistArray.$Closure$229<$T, $U>)this).op = ((x10.core.fun.Fun_0_1)(op));
            }
        }
        
    }
    
    @x10.runtime.impl.java.X10Generated
    final public static class $Closure$230<$T, $U> extends x10.core.Ref implements x10.core.fun.VoidFun_0_0, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<$Closure$230> $RTT = 
            x10.rtt.StaticVoidFunType.<$Closure$230> make($Closure$230.class,
                                                          2,
                                                          new x10.rtt.Type[] {
                                                              x10.core.fun.VoidFun_0_0.$RTT
                                                          });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { if (i == 0) return $T; if (i == 1) return $U; return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static <$T, $U> x10.serialization.X10JavaSerializable $_deserialize_body(x10.regionarray.DistArray.$Closure$230<$T, $U> $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            $_obj.$T = (x10.rtt.Type) $deserializer.readObject();
            $_obj.$U = (x10.rtt.Type) $deserializer.readObject();
            $_obj.dist = $deserializer.readObject();
            $_obj.dst = $deserializer.readObject();
            $_obj.op = $deserializer.readObject();
            $_obj.out$$ = $deserializer.readObject();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.regionarray.DistArray.$Closure$230 $_obj = new x10.regionarray.DistArray.$Closure$230((java.lang.System[]) null, (x10.rtt.Type) null, (x10.rtt.Type) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            $serializer.write(this.$T);
            $serializer.write(this.$U);
            $serializer.write(this.dist);
            $serializer.write(this.dst);
            $serializer.write(this.op);
            $serializer.write(this.out$$);
            
        }
        
        // constructor just for allocation
        public $Closure$230(final java.lang.System[] $dummy, final x10.rtt.Type $T, final x10.rtt.Type $U) {
            x10.regionarray.DistArray.$Closure$230.$initParams(this, $T, $U);
            
        }
        
        private x10.rtt.Type $T;
        private x10.rtt.Type $U;
        
        // initializer of type parameters
        public static void $initParams(final $Closure$230 $this, final x10.rtt.Type $T, final x10.rtt.Type $U) {
            $this.$T = $T;
            $this.$U = $U;
            
        }
        // synthetic type for parameter mangling
        public static final class __0$1x10$regionarray$DistArray$$Closure$230$$T$2__2$1x10$regionarray$DistArray$$Closure$230$$U$2__3$1x10$regionarray$DistArray$$Closure$230$$T$3x10$regionarray$DistArray$$Closure$230$$U$2 {}
        
    
        
        public void $apply() {
            
            //#line 777 "x10/regionarray/DistArray.x10"
            try {{
                
                //#line 778 "x10/regionarray/DistArray.x10"
                final x10.regionarray.Dist t$151469 = ((x10.regionarray.Dist)(this.dist));
                
                //#line 778 "x10/regionarray/DistArray.x10"
                final x10.regionarray.Region reg$151470 = ((x10.regionarray.Region)(t$151469.$apply(((x10.lang.Place)(x10.x10rt.X10RT.here())))));
                
                //#line 779 "x10/regionarray/DistArray.x10"
                final x10.regionarray.DistArray this$151471 = ((x10.regionarray.DistArray)(this.out$$));
                
                //#line 779 "x10/regionarray/DistArray.x10"
                final x10.regionarray.Region localRegion$151472 = ((x10.regionarray.Region)(((x10.regionarray.DistArray<$T>)this$151471).localRegion));
                
                //#line 780 "x10/regionarray/DistArray.x10"
                final x10.regionarray.DistArray this$151473 = ((x10.regionarray.DistArray)(this.out$$));
                
                //#line 780 "x10/regionarray/DistArray.x10"
                final x10.core.Rail srcRail$151474 = ((x10.core.Rail)(((x10.regionarray.DistArray<$T>)this$151473).raw));
                
                //#line 781 "x10/regionarray/DistArray.x10"
                final x10.core.Rail dstRail$151475 = ((x10.core.Rail)(((x10.regionarray.DistArray<$U>)this.dst).raw));
                
                //#line 782 "x10/regionarray/DistArray.x10"
                final x10.lang.Iterator pt$151466 = reg$151470.iterator();
                
                //#line 782 "x10/regionarray/DistArray.x10"
                for (;
                     true;
                     ) {
                    
                    //#line 782 "x10/regionarray/DistArray.x10"
                    final boolean t$151467 = ((x10.lang.Iterator<x10.lang.Point>)pt$151466).hasNext$O();
                    
                    //#line 782 "x10/regionarray/DistArray.x10"
                    if (!(t$151467)) {
                        
                        //#line 782 "x10/regionarray/DistArray.x10"
                        break;
                    }
                    
                    //#line 782 "x10/regionarray/DistArray.x10"
                    final x10.lang.Point pt$151462 = ((x10.lang.Point)(((x10.lang.Iterator<x10.lang.Point>)pt$151466).next$G()));
                    
                    //#line 783 "x10/regionarray/DistArray.x10"
                    final long offset$151463 = localRegion$151472.indexOf$O(((x10.lang.Point)(pt$151462)));
                    
                    //#line 784 "x10/regionarray/DistArray.x10"
                    final $T t$151464 = (($T)(((x10.core.Rail<$T>)srcRail$151474).$apply$G((long)(offset$151463))));
                    
                    //#line 784 "x10/regionarray/DistArray.x10"
                    final $U t$151465 = (($U)((($U)
                                                ((x10.core.fun.Fun_0_1<$T,$U>)this.op).$apply(t$151464, $T))));
                    
                    //#line 784 "x10/regionarray/DistArray.x10"
                    ((x10.core.Rail<$U>)dstRail$151475).$set__1x10$lang$Rail$$T$G((long)(offset$151463), (($U)(t$151465)));
                }
            }}catch (java.lang.Error __lowerer__var__0__) {
                
                //#line 777 "x10/regionarray/DistArray.x10"
                throw __lowerer__var__0__;
            }catch (java.lang.Throwable __lowerer__var__1__) {
                
                //#line 777 "x10/regionarray/DistArray.x10"
                throw x10.rtt.Types.EXCEPTION.isInstance(__lowerer__var__1__) ? (java.lang.RuntimeException)(__lowerer__var__1__) : new x10.lang.WrappedThrowable(__lowerer__var__1__);
            }
        }
        
        public x10.regionarray.DistArray<$T> out$$;
        public x10.regionarray.Dist dist;
        public x10.regionarray.DistArray<$U> dst;
        public x10.core.fun.Fun_0_1<$T,$U> op;
        
        public $Closure$230(final x10.rtt.Type $T, final x10.rtt.Type $U, final x10.regionarray.DistArray<$T> out$$, final x10.regionarray.Dist dist, final x10.regionarray.DistArray<$U> dst, final x10.core.fun.Fun_0_1<$T,$U> op, __0$1x10$regionarray$DistArray$$Closure$230$$T$2__2$1x10$regionarray$DistArray$$Closure$230$$U$2__3$1x10$regionarray$DistArray$$Closure$230$$T$3x10$regionarray$DistArray$$Closure$230$$U$2 $dummy) {
            x10.regionarray.DistArray.$Closure$230.$initParams(this, $T, $U);
             {
                ((x10.regionarray.DistArray.$Closure$230<$T, $U>)this).out$$ = out$$;
                ((x10.regionarray.DistArray.$Closure$230<$T, $U>)this).dist = ((x10.regionarray.Dist)(dist));
                ((x10.regionarray.DistArray.$Closure$230<$T, $U>)this).dst = ((x10.regionarray.DistArray)(dst));
                ((x10.regionarray.DistArray.$Closure$230<$T, $U>)this).op = ((x10.core.fun.Fun_0_1)(op));
            }
        }
        
    }
    
    @x10.runtime.impl.java.X10Generated
    final public static class $Closure$231<$T, $U> extends x10.core.Ref implements x10.core.fun.VoidFun_0_0, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<$Closure$231> $RTT = 
            x10.rtt.StaticVoidFunType.<$Closure$231> make($Closure$231.class,
                                                          2,
                                                          new x10.rtt.Type[] {
                                                              x10.core.fun.VoidFun_0_0.$RTT
                                                          });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { if (i == 0) return $T; if (i == 1) return $U; return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static <$T, $U> x10.serialization.X10JavaSerializable $_deserialize_body(x10.regionarray.DistArray.$Closure$231<$T, $U> $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            $_obj.$T = (x10.rtt.Type) $deserializer.readObject();
            $_obj.$U = (x10.rtt.Type) $deserializer.readObject();
            $_obj.dist = $deserializer.readObject();
            $_obj.dst = $deserializer.readObject();
            $_obj.filter = $deserializer.readObject();
            $_obj.op = $deserializer.readObject();
            $_obj.out$$ = $deserializer.readObject();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.regionarray.DistArray.$Closure$231 $_obj = new x10.regionarray.DistArray.$Closure$231((java.lang.System[]) null, (x10.rtt.Type) null, (x10.rtt.Type) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            $serializer.write(this.$T);
            $serializer.write(this.$U);
            $serializer.write(this.dist);
            $serializer.write(this.dst);
            $serializer.write(this.filter);
            $serializer.write(this.op);
            $serializer.write(this.out$$);
            
        }
        
        // constructor just for allocation
        public $Closure$231(final java.lang.System[] $dummy, final x10.rtt.Type $T, final x10.rtt.Type $U) {
            x10.regionarray.DistArray.$Closure$231.$initParams(this, $T, $U);
            
        }
        
        private x10.rtt.Type $T;
        private x10.rtt.Type $U;
        
        // initializer of type parameters
        public static void $initParams(final $Closure$231 $this, final x10.rtt.Type $T, final x10.rtt.Type $U) {
            $this.$T = $T;
            $this.$U = $U;
            
        }
        // synthetic type for parameter mangling
        public static final class __0$1x10$regionarray$DistArray$$Closure$231$$T$2__3$1x10$regionarray$DistArray$$Closure$231$$U$2__4$1x10$regionarray$DistArray$$Closure$231$$T$3x10$regionarray$DistArray$$Closure$231$$U$2 {}
        
    
        
        public void $apply() {
            
            //#line 807 "x10/regionarray/DistArray.x10"
            try {{
                
                //#line 808 "x10/regionarray/DistArray.x10"
                final x10.regionarray.Dist t$151483 = ((x10.regionarray.Dist)(this.dist));
                
                //#line 808 "x10/regionarray/DistArray.x10"
                final x10.regionarray.Region reg$151484 = ((x10.regionarray.Region)(t$151483.$apply(((x10.lang.Place)(x10.x10rt.X10RT.here())))));
                
                //#line 809 "x10/regionarray/DistArray.x10"
                final x10.regionarray.DistArray this$151485 = ((x10.regionarray.DistArray)(this.out$$));
                
                //#line 809 "x10/regionarray/DistArray.x10"
                final x10.regionarray.Region localRegion$151486 = ((x10.regionarray.Region)(((x10.regionarray.DistArray<$T>)this$151485).localRegion));
                
                //#line 810 "x10/regionarray/DistArray.x10"
                final x10.regionarray.Region freg$151487 = ((x10.regionarray.Region)(reg$151484.$and(((x10.regionarray.Region)(this.filter)))));
                
                //#line 811 "x10/regionarray/DistArray.x10"
                final x10.regionarray.DistArray this$151488 = ((x10.regionarray.DistArray)(this.out$$));
                
                //#line 811 "x10/regionarray/DistArray.x10"
                final x10.core.Rail srcRail$151489 = ((x10.core.Rail)(((x10.regionarray.DistArray<$T>)this$151488).raw));
                
                //#line 812 "x10/regionarray/DistArray.x10"
                final x10.core.Rail dstRail$151490 = ((x10.core.Rail)(((x10.regionarray.DistArray<$U>)this.dst).raw));
                
                //#line 813 "x10/regionarray/DistArray.x10"
                final x10.lang.Iterator pt$151480 = freg$151487.iterator();
                
                //#line 813 "x10/regionarray/DistArray.x10"
                for (;
                     true;
                     ) {
                    
                    //#line 813 "x10/regionarray/DistArray.x10"
                    final boolean t$151481 = ((x10.lang.Iterator<x10.lang.Point>)pt$151480).hasNext$O();
                    
                    //#line 813 "x10/regionarray/DistArray.x10"
                    if (!(t$151481)) {
                        
                        //#line 813 "x10/regionarray/DistArray.x10"
                        break;
                    }
                    
                    //#line 813 "x10/regionarray/DistArray.x10"
                    final x10.lang.Point pt$151476 = ((x10.lang.Point)(((x10.lang.Iterator<x10.lang.Point>)pt$151480).next$G()));
                    
                    //#line 814 "x10/regionarray/DistArray.x10"
                    final long offset$151477 = localRegion$151486.indexOf$O(((x10.lang.Point)(pt$151476)));
                    
                    //#line 815 "x10/regionarray/DistArray.x10"
                    final $T t$151478 = (($T)(((x10.core.Rail<$T>)srcRail$151489).$apply$G((long)(offset$151477))));
                    
                    //#line 815 "x10/regionarray/DistArray.x10"
                    final $U t$151479 = (($U)((($U)
                                                ((x10.core.fun.Fun_0_1<$T,$U>)this.op).$apply(t$151478, $T))));
                    
                    //#line 815 "x10/regionarray/DistArray.x10"
                    ((x10.core.Rail<$U>)dstRail$151490).$set__1x10$lang$Rail$$T$G((long)(offset$151477), (($U)(t$151479)));
                }
            }}catch (java.lang.Error __lowerer__var__0__) {
                
                //#line 807 "x10/regionarray/DistArray.x10"
                throw __lowerer__var__0__;
            }catch (java.lang.Throwable __lowerer__var__1__) {
                
                //#line 807 "x10/regionarray/DistArray.x10"
                throw x10.rtt.Types.EXCEPTION.isInstance(__lowerer__var__1__) ? (java.lang.RuntimeException)(__lowerer__var__1__) : new x10.lang.WrappedThrowable(__lowerer__var__1__);
            }
        }
        
        public x10.regionarray.DistArray<$T> out$$;
        public x10.regionarray.Dist dist;
        public x10.regionarray.Region filter;
        public x10.regionarray.DistArray<$U> dst;
        public x10.core.fun.Fun_0_1<$T,$U> op;
        
        public $Closure$231(final x10.rtt.Type $T, final x10.rtt.Type $U, final x10.regionarray.DistArray<$T> out$$, final x10.regionarray.Dist dist, final x10.regionarray.Region filter, final x10.regionarray.DistArray<$U> dst, final x10.core.fun.Fun_0_1<$T,$U> op, __0$1x10$regionarray$DistArray$$Closure$231$$T$2__3$1x10$regionarray$DistArray$$Closure$231$$U$2__4$1x10$regionarray$DistArray$$Closure$231$$T$3x10$regionarray$DistArray$$Closure$231$$U$2 $dummy) {
            x10.regionarray.DistArray.$Closure$231.$initParams(this, $T, $U);
             {
                ((x10.regionarray.DistArray.$Closure$231<$T, $U>)this).out$$ = out$$;
                ((x10.regionarray.DistArray.$Closure$231<$T, $U>)this).dist = ((x10.regionarray.Dist)(dist));
                ((x10.regionarray.DistArray.$Closure$231<$T, $U>)this).filter = ((x10.regionarray.Region)(filter));
                ((x10.regionarray.DistArray.$Closure$231<$T, $U>)this).dst = ((x10.regionarray.DistArray)(dst));
                ((x10.regionarray.DistArray.$Closure$231<$T, $U>)this).op = ((x10.core.fun.Fun_0_1)(op));
            }
        }
        
    }
    
    @x10.runtime.impl.java.X10Generated
    final public static class $Closure$232<$T, $S, $U> extends x10.core.Ref implements x10.core.fun.Fun_0_0, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<$Closure$232> $RTT = 
            x10.rtt.StaticFunType.<$Closure$232> make($Closure$232.class,
                                                      3,
                                                      new x10.rtt.Type[] {
                                                          x10.rtt.ParameterizedType.make(x10.core.fun.Fun_0_0.$RTT, x10.rtt.ParameterizedType.make(x10.regionarray.DistArray.LocalState.$RTT, x10.rtt.UnresolvedType.PARAM(1)))
                                                      });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { if (i == 0) return $T; if (i == 1) return $S; if (i == 2) return $U; return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static <$T, $S, $U> x10.serialization.X10JavaSerializable $_deserialize_body(x10.regionarray.DistArray.$Closure$232<$T, $S, $U> $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            $_obj.$T = (x10.rtt.Type) $deserializer.readObject();
            $_obj.$S = (x10.rtt.Type) $deserializer.readObject();
            $_obj.$U = (x10.rtt.Type) $deserializer.readObject();
            $_obj.dist = $deserializer.readObject();
            $_obj.op = $deserializer.readObject();
            $_obj.out$$ = $deserializer.readObject();
            $_obj.src = $deserializer.readObject();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.regionarray.DistArray.$Closure$232 $_obj = new x10.regionarray.DistArray.$Closure$232((java.lang.System[]) null, (x10.rtt.Type) null, (x10.rtt.Type) null, (x10.rtt.Type) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            $serializer.write(this.$T);
            $serializer.write(this.$S);
            $serializer.write(this.$U);
            $serializer.write(this.dist);
            $serializer.write(this.op);
            $serializer.write(this.out$$);
            $serializer.write(this.src);
            
        }
        
        // constructor just for allocation
        public $Closure$232(final java.lang.System[] $dummy, final x10.rtt.Type $T, final x10.rtt.Type $S, final x10.rtt.Type $U) {
            x10.regionarray.DistArray.$Closure$232.$initParams(this, $T, $S, $U);
            
        }
        
        // bridge for method abstract public ()=>U.operator()():U
        public x10.regionarray.DistArray.LocalState $apply$G() {
            return $apply();
        }
        
        private x10.rtt.Type $T;
        private x10.rtt.Type $S;
        private x10.rtt.Type $U;
        
        // initializer of type parameters
        public static void $initParams(final $Closure$232 $this, final x10.rtt.Type $T, final x10.rtt.Type $S, final x10.rtt.Type $U) {
            $this.$T = $T;
            $this.$S = $S;
            $this.$U = $U;
            
        }
        // synthetic type for parameter mangling for __0$1x10$regionarray$DistArray$$Closure$232$$T$2__1$1x10$regionarray$DistArray$$Closure$232$$U$2__3$1x10$regionarray$DistArray$$Closure$232$$T$3x10$regionarray$DistArray$$Closure$232$$U$3x10$regionarray$DistArray$$Closure$232$$S$2
        public static final class $_8b30f567 {}
        
    
        
        public x10.regionarray.DistArray.LocalState $apply() {
            
            //#line 837 "x10/regionarray/DistArray.x10"
            final x10.regionarray.DistArray this$150706 = ((x10.regionarray.DistArray)(this.out$$));
            
            //#line 837 "x10/regionarray/DistArray.x10"
            final x10.core.Rail src1Rail = ((x10.core.Rail)(((x10.regionarray.DistArray<$T>)this$150706).raw));
            
            //#line 838 "x10/regionarray/DistArray.x10"
            final x10.core.Rail src2Rail = ((x10.core.Rail)(((x10.regionarray.DistArray<$U>)this.src).raw));
            
            //#line 839 "x10/regionarray/DistArray.x10"
            final x10.regionarray.DistArray this$150709 = ((x10.regionarray.DistArray)(this.out$$));
            
            //#line 839 "x10/regionarray/DistArray.x10"
            final x10.regionarray.Region localRegion = ((x10.regionarray.Region)(((x10.regionarray.DistArray<$T>)this$150709).localRegion));
            
            //#line 840 "x10/regionarray/DistArray.x10"
            final long t$151113 = localRegion.size$O();
            
            //#line 840 "x10/regionarray/DistArray.x10"
            final x10.core.Rail newRail = ((x10.core.Rail)(x10.core.Rail.<$S>makeUnsafe($S, ((long)(t$151113)), false)));
            
            //#line 841 "x10/regionarray/DistArray.x10"
            final x10.regionarray.Dist t$151114 = ((x10.regionarray.Dist)(this.dist));
            
            //#line 841 "x10/regionarray/DistArray.x10"
            final x10.regionarray.Region reg = ((x10.regionarray.Region)(t$151114.$apply(((x10.lang.Place)(x10.x10rt.X10RT.here())))));
            
            //#line 842 "x10/regionarray/DistArray.x10"
            final x10.lang.Iterator pt$151496 = reg.iterator();
            
            //#line 842 "x10/regionarray/DistArray.x10"
            for (;
                 true;
                 ) {
                
                //#line 842 "x10/regionarray/DistArray.x10"
                final boolean t$151497 = ((x10.lang.Iterator<x10.lang.Point>)pt$151496).hasNext$O();
                
                //#line 842 "x10/regionarray/DistArray.x10"
                if (!(t$151497)) {
                    
                    //#line 842 "x10/regionarray/DistArray.x10"
                    break;
                }
                
                //#line 842 "x10/regionarray/DistArray.x10"
                final x10.lang.Point pt$151491 = ((x10.lang.Point)(((x10.lang.Iterator<x10.lang.Point>)pt$151496).next$G()));
                
                //#line 843 "x10/regionarray/DistArray.x10"
                final long offset$151492 = localRegion.indexOf$O(((x10.lang.Point)(pt$151491)));
                
                //#line 844 "x10/regionarray/DistArray.x10"
                final $T t$151493 = (($T)(((x10.core.Rail<$T>)src1Rail).$apply$G((long)(offset$151492))));
                
                //#line 844 "x10/regionarray/DistArray.x10"
                final $U t$151494 = (($U)(((x10.core.Rail<$U>)src2Rail).$apply$G((long)(offset$151492))));
                
                //#line 844 "x10/regionarray/DistArray.x10"
                final $S t$151495 = (($S)((($S)
                                            ((x10.core.fun.Fun_0_2<$T,$U,$S>)this.op).$apply(t$151493, $T, t$151494, $U))));
                
                //#line 844 "x10/regionarray/DistArray.x10"
                ((x10.core.Rail<$S>)newRail).$set__1x10$lang$Rail$$T$G((long)(offset$151492), (($S)(t$151495)));
            }
            
            //#line 846 "x10/regionarray/DistArray.x10"
            final x10.regionarray.DistArray.LocalState alloc$150413 = ((x10.regionarray.DistArray.LocalState)(new x10.regionarray.DistArray.LocalState<$S>((java.lang.System[]) null, $S)));
            
            //#line 846 "x10/regionarray/DistArray.x10"
            final x10.regionarray.Dist t$151498 = ((x10.regionarray.Dist)(this.dist));
            
            //#line 846 "x10/regionarray/DistArray.x10"
            alloc$150413.x10$regionarray$DistArray$LocalState$$init$S(((x10.regionarray.Dist)(t$151498)), ((x10.core.Rail)(newRail)), (x10.regionarray.DistArray.LocalState.__1$1x10$regionarray$DistArray$LocalState$$T$2) null);
            
            //#line 846 "x10/regionarray/DistArray.x10"
            return alloc$150413;
        }
        
        public x10.regionarray.DistArray<$T> out$$;
        public x10.regionarray.DistArray<$U> src;
        public x10.regionarray.Dist dist;
        public x10.core.fun.Fun_0_2<$T,$U,$S> op;
        
        public $Closure$232(final x10.rtt.Type $T, final x10.rtt.Type $S, final x10.rtt.Type $U, final x10.regionarray.DistArray<$T> out$$, final x10.regionarray.DistArray<$U> src, final x10.regionarray.Dist dist, final x10.core.fun.Fun_0_2<$T,$U,$S> op, $_8b30f567 $dummy) {
            x10.regionarray.DistArray.$Closure$232.$initParams(this, $T, $S, $U);
             {
                ((x10.regionarray.DistArray.$Closure$232<$T, $S, $U>)this).out$$ = out$$;
                ((x10.regionarray.DistArray.$Closure$232<$T, $S, $U>)this).src = ((x10.regionarray.DistArray)(src));
                ((x10.regionarray.DistArray.$Closure$232<$T, $S, $U>)this).dist = ((x10.regionarray.Dist)(dist));
                ((x10.regionarray.DistArray.$Closure$232<$T, $S, $U>)this).op = ((x10.core.fun.Fun_0_2)(op));
            }
        }
        
    }
    
    @x10.runtime.impl.java.X10Generated
    final public static class $Closure$233<$T, $S, $U> extends x10.core.Ref implements x10.core.fun.VoidFun_0_0, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<$Closure$233> $RTT = 
            x10.rtt.StaticVoidFunType.<$Closure$233> make($Closure$233.class,
                                                          3,
                                                          new x10.rtt.Type[] {
                                                              x10.core.fun.VoidFun_0_0.$RTT
                                                          });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { if (i == 0) return $T; if (i == 1) return $S; if (i == 2) return $U; return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static <$T, $S, $U> x10.serialization.X10JavaSerializable $_deserialize_body(x10.regionarray.DistArray.$Closure$233<$T, $S, $U> $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            $_obj.$T = (x10.rtt.Type) $deserializer.readObject();
            $_obj.$S = (x10.rtt.Type) $deserializer.readObject();
            $_obj.$U = (x10.rtt.Type) $deserializer.readObject();
            $_obj.dist = $deserializer.readObject();
            $_obj.dst = $deserializer.readObject();
            $_obj.op = $deserializer.readObject();
            $_obj.out$$ = $deserializer.readObject();
            $_obj.src = $deserializer.readObject();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.regionarray.DistArray.$Closure$233 $_obj = new x10.regionarray.DistArray.$Closure$233((java.lang.System[]) null, (x10.rtt.Type) null, (x10.rtt.Type) null, (x10.rtt.Type) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            $serializer.write(this.$T);
            $serializer.write(this.$S);
            $serializer.write(this.$U);
            $serializer.write(this.dist);
            $serializer.write(this.dst);
            $serializer.write(this.op);
            $serializer.write(this.out$$);
            $serializer.write(this.src);
            
        }
        
        // constructor just for allocation
        public $Closure$233(final java.lang.System[] $dummy, final x10.rtt.Type $T, final x10.rtt.Type $S, final x10.rtt.Type $U) {
            x10.regionarray.DistArray.$Closure$233.$initParams(this, $T, $S, $U);
            
        }
        
        private x10.rtt.Type $T;
        private x10.rtt.Type $S;
        private x10.rtt.Type $U;
        
        // initializer of type parameters
        public static void $initParams(final $Closure$233 $this, final x10.rtt.Type $T, final x10.rtt.Type $S, final x10.rtt.Type $U) {
            $this.$T = $T;
            $this.$S = $S;
            $this.$U = $U;
            
        }
        // synthetic type for parameter mangling for __0$1x10$regionarray$DistArray$$Closure$233$$T$2__2$1x10$regionarray$DistArray$$Closure$233$$U$2__3$1x10$regionarray$DistArray$$Closure$233$$S$2__4$1x10$regionarray$DistArray$$Closure$233$$T$3x10$regionarray$DistArray$$Closure$233$$U$3x10$regionarray$DistArray$$Closure$233$$S$2
        public static final class $_d69e2961 {}
        
    
        
        public void $apply() {
            
            //#line 865 "x10/regionarray/DistArray.x10"
            try {{
                
                //#line 866 "x10/regionarray/DistArray.x10"
                final x10.regionarray.Dist t$151508 = ((x10.regionarray.Dist)(this.dist));
                
                //#line 866 "x10/regionarray/DistArray.x10"
                final x10.regionarray.Region reg$151509 = ((x10.regionarray.Region)(t$151508.$apply(((x10.lang.Place)(x10.x10rt.X10RT.here())))));
                
                //#line 867 "x10/regionarray/DistArray.x10"
                final x10.regionarray.DistArray this$151510 = ((x10.regionarray.DistArray)(this.out$$));
                
                //#line 867 "x10/regionarray/DistArray.x10"
                final x10.regionarray.Region localRegion$151511 = ((x10.regionarray.Region)(((x10.regionarray.DistArray<$T>)this$151510).localRegion));
                
                //#line 868 "x10/regionarray/DistArray.x10"
                final x10.regionarray.DistArray this$151512 = ((x10.regionarray.DistArray)(this.out$$));
                
                //#line 868 "x10/regionarray/DistArray.x10"
                final x10.core.Rail src1Rail$151513 = ((x10.core.Rail)(((x10.regionarray.DistArray<$T>)this$151512).raw));
                
                //#line 869 "x10/regionarray/DistArray.x10"
                final x10.core.Rail src2Rail$151514 = ((x10.core.Rail)(((x10.regionarray.DistArray<$U>)this.src).raw));
                
                //#line 870 "x10/regionarray/DistArray.x10"
                final x10.core.Rail dstRail$151515 = ((x10.core.Rail)(((x10.regionarray.DistArray<$S>)this.dst).raw));
                
                //#line 871 "x10/regionarray/DistArray.x10"
                final x10.lang.Iterator pt$151505 = reg$151509.iterator();
                
                //#line 871 "x10/regionarray/DistArray.x10"
                for (;
                     true;
                     ) {
                    
                    //#line 871 "x10/regionarray/DistArray.x10"
                    final boolean t$151506 = ((x10.lang.Iterator<x10.lang.Point>)pt$151505).hasNext$O();
                    
                    //#line 871 "x10/regionarray/DistArray.x10"
                    if (!(t$151506)) {
                        
                        //#line 871 "x10/regionarray/DistArray.x10"
                        break;
                    }
                    
                    //#line 871 "x10/regionarray/DistArray.x10"
                    final x10.lang.Point pt$151500 = ((x10.lang.Point)(((x10.lang.Iterator<x10.lang.Point>)pt$151505).next$G()));
                    
                    //#line 872 "x10/regionarray/DistArray.x10"
                    final long offset$151501 = localRegion$151511.indexOf$O(((x10.lang.Point)(pt$151500)));
                    
                    //#line 873 "x10/regionarray/DistArray.x10"
                    final $T t$151502 = (($T)(((x10.core.Rail<$T>)src1Rail$151513).$apply$G((long)(offset$151501))));
                    
                    //#line 873 "x10/regionarray/DistArray.x10"
                    final $U t$151503 = (($U)(((x10.core.Rail<$U>)src2Rail$151514).$apply$G((long)(offset$151501))));
                    
                    //#line 873 "x10/regionarray/DistArray.x10"
                    final $S t$151504 = (($S)((($S)
                                                ((x10.core.fun.Fun_0_2<$T,$U,$S>)this.op).$apply(t$151502, $T, t$151503, $U))));
                    
                    //#line 873 "x10/regionarray/DistArray.x10"
                    ((x10.core.Rail<$S>)dstRail$151515).$set__1x10$lang$Rail$$T$G((long)(offset$151501), (($S)(t$151504)));
                }
            }}catch (java.lang.Error __lowerer__var__0__) {
                
                //#line 865 "x10/regionarray/DistArray.x10"
                throw __lowerer__var__0__;
            }catch (java.lang.Throwable __lowerer__var__1__) {
                
                //#line 865 "x10/regionarray/DistArray.x10"
                throw x10.rtt.Types.EXCEPTION.isInstance(__lowerer__var__1__) ? (java.lang.RuntimeException)(__lowerer__var__1__) : new x10.lang.WrappedThrowable(__lowerer__var__1__);
            }
        }
        
        public x10.regionarray.DistArray<$T> out$$;
        public x10.regionarray.Dist dist;
        public x10.regionarray.DistArray<$U> src;
        public x10.regionarray.DistArray<$S> dst;
        public x10.core.fun.Fun_0_2<$T,$U,$S> op;
        
        public $Closure$233(final x10.rtt.Type $T, final x10.rtt.Type $S, final x10.rtt.Type $U, final x10.regionarray.DistArray<$T> out$$, final x10.regionarray.Dist dist, final x10.regionarray.DistArray<$U> src, final x10.regionarray.DistArray<$S> dst, final x10.core.fun.Fun_0_2<$T,$U,$S> op, $_d69e2961 $dummy) {
            x10.regionarray.DistArray.$Closure$233.$initParams(this, $T, $S, $U);
             {
                ((x10.regionarray.DistArray.$Closure$233<$T, $S, $U>)this).out$$ = out$$;
                ((x10.regionarray.DistArray.$Closure$233<$T, $S, $U>)this).dist = ((x10.regionarray.Dist)(dist));
                ((x10.regionarray.DistArray.$Closure$233<$T, $S, $U>)this).src = ((x10.regionarray.DistArray)(src));
                ((x10.regionarray.DistArray.$Closure$233<$T, $S, $U>)this).dst = ((x10.regionarray.DistArray)(dst));
                ((x10.regionarray.DistArray.$Closure$233<$T, $S, $U>)this).op = ((x10.core.fun.Fun_0_2)(op));
            }
        }
        
    }
    
    @x10.runtime.impl.java.X10Generated
    final public static class $Closure$234<$T, $S, $U> extends x10.core.Ref implements x10.core.fun.VoidFun_0_0, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<$Closure$234> $RTT = 
            x10.rtt.StaticVoidFunType.<$Closure$234> make($Closure$234.class,
                                                          3,
                                                          new x10.rtt.Type[] {
                                                              x10.core.fun.VoidFun_0_0.$RTT
                                                          });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { if (i == 0) return $T; if (i == 1) return $S; if (i == 2) return $U; return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static <$T, $S, $U> x10.serialization.X10JavaSerializable $_deserialize_body(x10.regionarray.DistArray.$Closure$234<$T, $S, $U> $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            $_obj.$T = (x10.rtt.Type) $deserializer.readObject();
            $_obj.$S = (x10.rtt.Type) $deserializer.readObject();
            $_obj.$U = (x10.rtt.Type) $deserializer.readObject();
            $_obj.dist = $deserializer.readObject();
            $_obj.dst = $deserializer.readObject();
            $_obj.filter = $deserializer.readObject();
            $_obj.op = $deserializer.readObject();
            $_obj.out$$ = $deserializer.readObject();
            $_obj.src = $deserializer.readObject();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.regionarray.DistArray.$Closure$234 $_obj = new x10.regionarray.DistArray.$Closure$234((java.lang.System[]) null, (x10.rtt.Type) null, (x10.rtt.Type) null, (x10.rtt.Type) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            $serializer.write(this.$T);
            $serializer.write(this.$S);
            $serializer.write(this.$U);
            $serializer.write(this.dist);
            $serializer.write(this.dst);
            $serializer.write(this.filter);
            $serializer.write(this.op);
            $serializer.write(this.out$$);
            $serializer.write(this.src);
            
        }
        
        // constructor just for allocation
        public $Closure$234(final java.lang.System[] $dummy, final x10.rtt.Type $T, final x10.rtt.Type $S, final x10.rtt.Type $U) {
            x10.regionarray.DistArray.$Closure$234.$initParams(this, $T, $S, $U);
            
        }
        
        private x10.rtt.Type $T;
        private x10.rtt.Type $S;
        private x10.rtt.Type $U;
        
        // initializer of type parameters
        public static void $initParams(final $Closure$234 $this, final x10.rtt.Type $T, final x10.rtt.Type $S, final x10.rtt.Type $U) {
            $this.$T = $T;
            $this.$S = $S;
            $this.$U = $U;
            
        }
        // synthetic type for parameter mangling for __0$1x10$regionarray$DistArray$$Closure$234$$T$2__3$1x10$regionarray$DistArray$$Closure$234$$U$2__4$1x10$regionarray$DistArray$$Closure$234$$S$2__5$1x10$regionarray$DistArray$$Closure$234$$T$3x10$regionarray$DistArray$$Closure$234$$U$3x10$regionarray$DistArray$$Closure$234$$S$2
        public static final class $_e582bc9a {}
        
    
        
        public void $apply() {
            
            //#line 896 "x10/regionarray/DistArray.x10"
            try {{
                
                //#line 897 "x10/regionarray/DistArray.x10"
                final x10.regionarray.Dist t$151524 = ((x10.regionarray.Dist)(this.dist));
                
                //#line 897 "x10/regionarray/DistArray.x10"
                final x10.regionarray.Region reg$151525 = ((x10.regionarray.Region)(t$151524.$apply(((x10.lang.Place)(x10.x10rt.X10RT.here())))));
                
                //#line 898 "x10/regionarray/DistArray.x10"
                final x10.regionarray.DistArray this$151526 = ((x10.regionarray.DistArray)(this.out$$));
                
                //#line 898 "x10/regionarray/DistArray.x10"
                final x10.regionarray.Region localRegion$151527 = ((x10.regionarray.Region)(((x10.regionarray.DistArray<$T>)this$151526).localRegion));
                
                //#line 899 "x10/regionarray/DistArray.x10"
                final x10.regionarray.Region freg$151528 = ((x10.regionarray.Region)(reg$151525.$and(((x10.regionarray.Region)(this.filter)))));
                
                //#line 900 "x10/regionarray/DistArray.x10"
                final x10.regionarray.DistArray this$151529 = ((x10.regionarray.DistArray)(this.out$$));
                
                //#line 900 "x10/regionarray/DistArray.x10"
                final x10.core.Rail src1Rail$151530 = ((x10.core.Rail)(((x10.regionarray.DistArray<$T>)this$151529).raw));
                
                //#line 901 "x10/regionarray/DistArray.x10"
                final x10.core.Rail src2Rail$151531 = ((x10.core.Rail)(((x10.regionarray.DistArray<$U>)this.src).raw));
                
                //#line 902 "x10/regionarray/DistArray.x10"
                final x10.core.Rail dstRail$151532 = ((x10.core.Rail)(((x10.regionarray.DistArray<$S>)this.dst).raw));
                
                //#line 903 "x10/regionarray/DistArray.x10"
                final x10.lang.Iterator pt$151521 = freg$151528.iterator();
                
                //#line 903 "x10/regionarray/DistArray.x10"
                for (;
                     true;
                     ) {
                    
                    //#line 903 "x10/regionarray/DistArray.x10"
                    final boolean t$151522 = ((x10.lang.Iterator<x10.lang.Point>)pt$151521).hasNext$O();
                    
                    //#line 903 "x10/regionarray/DistArray.x10"
                    if (!(t$151522)) {
                        
                        //#line 903 "x10/regionarray/DistArray.x10"
                        break;
                    }
                    
                    //#line 903 "x10/regionarray/DistArray.x10"
                    final x10.lang.Point pt$151516 = ((x10.lang.Point)(((x10.lang.Iterator<x10.lang.Point>)pt$151521).next$G()));
                    
                    //#line 904 "x10/regionarray/DistArray.x10"
                    final long offset$151517 = localRegion$151527.indexOf$O(((x10.lang.Point)(pt$151516)));
                    
                    //#line 905 "x10/regionarray/DistArray.x10"
                    final $T t$151518 = (($T)(((x10.core.Rail<$T>)src1Rail$151530).$apply$G((long)(offset$151517))));
                    
                    //#line 905 "x10/regionarray/DistArray.x10"
                    final $U t$151519 = (($U)(((x10.core.Rail<$U>)src2Rail$151531).$apply$G((long)(offset$151517))));
                    
                    //#line 905 "x10/regionarray/DistArray.x10"
                    final $S t$151520 = (($S)((($S)
                                                ((x10.core.fun.Fun_0_2<$T,$U,$S>)this.op).$apply(t$151518, $T, t$151519, $U))));
                    
                    //#line 905 "x10/regionarray/DistArray.x10"
                    ((x10.core.Rail<$S>)dstRail$151532).$set__1x10$lang$Rail$$T$G((long)(offset$151517), (($S)(t$151520)));
                }
            }}catch (java.lang.Error __lowerer__var__0__) {
                
                //#line 896 "x10/regionarray/DistArray.x10"
                throw __lowerer__var__0__;
            }catch (java.lang.Throwable __lowerer__var__1__) {
                
                //#line 896 "x10/regionarray/DistArray.x10"
                throw x10.rtt.Types.EXCEPTION.isInstance(__lowerer__var__1__) ? (java.lang.RuntimeException)(__lowerer__var__1__) : new x10.lang.WrappedThrowable(__lowerer__var__1__);
            }
        }
        
        public x10.regionarray.DistArray<$T> out$$;
        public x10.regionarray.Dist dist;
        public x10.regionarray.Region filter;
        public x10.regionarray.DistArray<$U> src;
        public x10.regionarray.DistArray<$S> dst;
        public x10.core.fun.Fun_0_2<$T,$U,$S> op;
        
        public $Closure$234(final x10.rtt.Type $T, final x10.rtt.Type $S, final x10.rtt.Type $U, final x10.regionarray.DistArray<$T> out$$, final x10.regionarray.Dist dist, final x10.regionarray.Region filter, final x10.regionarray.DistArray<$U> src, final x10.regionarray.DistArray<$S> dst, final x10.core.fun.Fun_0_2<$T,$U,$S> op, $_e582bc9a $dummy) {
            x10.regionarray.DistArray.$Closure$234.$initParams(this, $T, $S, $U);
             {
                ((x10.regionarray.DistArray.$Closure$234<$T, $S, $U>)this).out$$ = out$$;
                ((x10.regionarray.DistArray.$Closure$234<$T, $S, $U>)this).dist = ((x10.regionarray.Dist)(dist));
                ((x10.regionarray.DistArray.$Closure$234<$T, $S, $U>)this).filter = ((x10.regionarray.Region)(filter));
                ((x10.regionarray.DistArray.$Closure$234<$T, $S, $U>)this).src = ((x10.regionarray.DistArray)(src));
                ((x10.regionarray.DistArray.$Closure$234<$T, $S, $U>)this).dst = ((x10.regionarray.DistArray)(dst));
                ((x10.regionarray.DistArray.$Closure$234<$T, $S, $U>)this).op = ((x10.core.fun.Fun_0_2)(op));
            }
        }
        
    }
    
    @x10.runtime.impl.java.X10Generated
    final public static class $Closure$235<$T, $U> extends x10.core.Ref implements x10.core.fun.VoidFun_0_0, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<$Closure$235> $RTT = 
            x10.rtt.StaticVoidFunType.<$Closure$235> make($Closure$235.class,
                                                          2,
                                                          new x10.rtt.Type[] {
                                                              x10.core.fun.VoidFun_0_0.$RTT
                                                          });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { if (i == 0) return $T; if (i == 1) return $U; return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static <$T, $U> x10.serialization.X10JavaSerializable $_deserialize_body(x10.regionarray.DistArray.$Closure$235<$T, $U> $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            $_obj.$T = (x10.rtt.Type) $deserializer.readObject();
            $_obj.$U = (x10.rtt.Type) $deserializer.readObject();
            $_obj.dist = $deserializer.readObject();
            $_obj.lop = $deserializer.readObject();
            $_obj.out$$ = $deserializer.readObject();
            $_obj.unit = $deserializer.readObject();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.regionarray.DistArray.$Closure$235 $_obj = new x10.regionarray.DistArray.$Closure$235((java.lang.System[]) null, (x10.rtt.Type) null, (x10.rtt.Type) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            $serializer.write(this.$T);
            $serializer.write(this.$U);
            $serializer.write(this.dist);
            $serializer.write(this.lop);
            $serializer.write(this.out$$);
            $serializer.write(this.unit);
            
        }
        
        // constructor just for allocation
        public $Closure$235(final java.lang.System[] $dummy, final x10.rtt.Type $T, final x10.rtt.Type $U) {
            x10.regionarray.DistArray.$Closure$235.$initParams(this, $T, $U);
            
        }
        
        private x10.rtt.Type $T;
        private x10.rtt.Type $U;
        
        // initializer of type parameters
        public static void $initParams(final $Closure$235 $this, final x10.rtt.Type $T, final x10.rtt.Type $U) {
            $this.$T = $T;
            $this.$U = $U;
            
        }
        // synthetic type for parameter mangling
        public static final class __0$1x10$regionarray$DistArray$$Closure$235$$T$2__2x10$regionarray$DistArray$$Closure$235$$U__3$1x10$regionarray$DistArray$$Closure$235$$U$3x10$regionarray$DistArray$$Closure$235$$T$3x10$regionarray$DistArray$$Closure$235$$U$2 {}
        
    
        
        public void $apply() {
            
            //#line 947 "x10/regionarray/DistArray.x10"
            try {{
                
                //#line 948 "x10/regionarray/DistArray.x10"
                final x10.regionarray.Dist t$151541 = ((x10.regionarray.Dist)(this.dist));
                
                //#line 948 "x10/regionarray/DistArray.x10"
                final x10.regionarray.Region reg$151542 = ((x10.regionarray.Region)(t$151541.$apply(((x10.lang.Place)(x10.x10rt.X10RT.here())))));
                
                //#line 949 "x10/regionarray/DistArray.x10"
                final x10.regionarray.DistArray this$151543 = ((x10.regionarray.DistArray)(this.out$$));
                
                //#line 949 "x10/regionarray/DistArray.x10"
                final x10.regionarray.Region localRegion$151544 = ((x10.regionarray.Region)(((x10.regionarray.DistArray<$T>)this$151543).localRegion));
                
                //#line 950 "x10/regionarray/DistArray.x10"
                $U localRes$151545 = (($U)(this.unit));
                
                //#line 951 "x10/regionarray/DistArray.x10"
                final x10.regionarray.DistArray this$151546 = ((x10.regionarray.DistArray)(this.out$$));
                
                //#line 951 "x10/regionarray/DistArray.x10"
                final x10.core.Rail rail$151547 = ((x10.core.Rail)(((x10.regionarray.DistArray<$T>)this$151546).raw));
                
                //#line 952 "x10/regionarray/DistArray.x10"
                final x10.lang.Iterator pt$151538 = reg$151542.iterator();
                
                //#line 952 "x10/regionarray/DistArray.x10"
                for (;
                     true;
                     ) {
                    
                    //#line 952 "x10/regionarray/DistArray.x10"
                    final boolean t$151539 = ((x10.lang.Iterator<x10.lang.Point>)pt$151538).hasNext$O();
                    
                    //#line 952 "x10/regionarray/DistArray.x10"
                    if (!(t$151539)) {
                        
                        //#line 952 "x10/regionarray/DistArray.x10"
                        break;
                    }
                    
                    //#line 952 "x10/regionarray/DistArray.x10"
                    final x10.lang.Point pt$151533 = ((x10.lang.Point)(((x10.lang.Iterator<x10.lang.Point>)pt$151538).next$G()));
                    
                    //#line 953 "x10/regionarray/DistArray.x10"
                    final long t$151535 = localRegion$151544.indexOf$O(((x10.lang.Point)(pt$151533)));
                    
                    //#line 953 "x10/regionarray/DistArray.x10"
                    final $T t$151536 = (($T)(((x10.core.Rail<$T>)rail$151547).$apply$G((long)(t$151535))));
                    
                    //#line 953 "x10/regionarray/DistArray.x10"
                    final $U t$151537 = (($U)((($U)
                                                ((x10.core.fun.Fun_0_2<$U,$T,$U>)this.lop).$apply(localRes$151545, $U, t$151536, $T))));
                    
                    //#line 953 "x10/regionarray/DistArray.x10"
                    localRes$151545 = (($U)(t$151537));
                }
                
                //#line 955 "x10/regionarray/DistArray.x10"
                x10.xrx.Runtime.<$U> makeOffer__0x10$xrx$Runtime$$T($U, (($U)(localRes$151545)));
            }}catch (java.lang.Error __lowerer__var__0__) {
                
                //#line 947 "x10/regionarray/DistArray.x10"
                throw __lowerer__var__0__;
            }catch (java.lang.Throwable __lowerer__var__1__) {
                
                //#line 947 "x10/regionarray/DistArray.x10"
                throw x10.rtt.Types.EXCEPTION.isInstance(__lowerer__var__1__) ? (java.lang.RuntimeException)(__lowerer__var__1__) : new x10.lang.WrappedThrowable(__lowerer__var__1__);
            }
        }
        
        public x10.regionarray.DistArray<$T> out$$;
        public x10.regionarray.Dist dist;
        public $U unit;
        public x10.core.fun.Fun_0_2<$U,$T,$U> lop;
        
        public $Closure$235(final x10.rtt.Type $T, final x10.rtt.Type $U, final x10.regionarray.DistArray<$T> out$$, final x10.regionarray.Dist dist, final $U unit, final x10.core.fun.Fun_0_2<$U,$T,$U> lop, __0$1x10$regionarray$DistArray$$Closure$235$$T$2__2x10$regionarray$DistArray$$Closure$235$$U__3$1x10$regionarray$DistArray$$Closure$235$$U$3x10$regionarray$DistArray$$Closure$235$$T$3x10$regionarray$DistArray$$Closure$235$$U$2 $dummy) {
            x10.regionarray.DistArray.$Closure$235.$initParams(this, $T, $U);
             {
                ((x10.regionarray.DistArray.$Closure$235<$T, $U>)this).out$$ = out$$;
                ((x10.regionarray.DistArray.$Closure$235<$T, $U>)this).dist = ((x10.regionarray.Dist)(dist));
                ((x10.regionarray.DistArray.$Closure$235<$T, $U>)this).unit = (($U)(unit));
                ((x10.regionarray.DistArray.$Closure$235<$T, $U>)this).lop = ((x10.core.fun.Fun_0_2)(lop));
            }
        }
        
    }
    
    @x10.runtime.impl.java.X10Generated
    final public static class $Closure$236<$T> extends x10.core.Ref implements x10.core.fun.VoidFun_0_0, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<$Closure$236> $RTT = 
            x10.rtt.StaticVoidFunType.<$Closure$236> make($Closure$236.class,
                                                          1,
                                                          new x10.rtt.Type[] {
                                                              x10.core.fun.VoidFun_0_0.$RTT
                                                          });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { if (i == 0) return $T; return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static <$T> x10.serialization.X10JavaSerializable $_deserialize_body(x10.regionarray.DistArray.$Closure$236<$T> $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            $_obj.$T = (x10.rtt.Type) $deserializer.readObject();
            $_obj.localHandle = $deserializer.readObject();
            $_obj.out$$ = $deserializer.readObject();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.regionarray.DistArray.$Closure$236 $_obj = new x10.regionarray.DistArray.$Closure$236((java.lang.System[]) null, (x10.rtt.Type) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            $serializer.write(this.$T);
            $serializer.write(this.localHandle);
            $serializer.write(this.out$$);
            
        }
        
        // constructor just for allocation
        public $Closure$236(final java.lang.System[] $dummy, final x10.rtt.Type $T) {
            x10.regionarray.DistArray.$Closure$236.$initParams(this, $T);
            
        }
        
        private x10.rtt.Type $T;
        
        // initializer of type parameters
        public static void $initParams(final $Closure$236 $this, final x10.rtt.Type $T) {
            $this.$T = $T;
            
        }
        // synthetic type for parameter mangling
        public static final class __0$1x10$regionarray$DistArray$$Closure$236$$T$2__1$1x10$regionarray$DistArray$LocalState$1x10$regionarray$DistArray$$Closure$236$$T$2$2 {}
        
    
        
        public void $apply() {
            
            //#line 969 "x10/regionarray/DistArray.x10"
            try {{
                
                //#line 970 "x10/regionarray/DistArray.x10"
                final x10.lang.PlaceLocalHandle t$151162 = ((x10.lang.PlaceLocalHandle)(this.localHandle));
                
                //#line 970 "x10/regionarray/DistArray.x10"
                final x10.regionarray.DistArray.LocalState t$151163 = ((x10.regionarray.DistArray.LocalState)(((x10.lang.PlaceLocalHandle<x10.regionarray.DistArray.LocalState<$T>>)t$151162).$apply$G()));
                
                //#line 970 "x10/regionarray/DistArray.x10"
                final x10.regionarray.GhostManager ghostManager = ((x10.regionarray.GhostManager)(((x10.regionarray.DistArray.LocalState<$T>)t$151163).ghostManager));
                
                //#line 971 "x10/regionarray/DistArray.x10"
                ghostManager.sendGhosts(((x10.regionarray.Ghostable)(this.out$$)));
                
                //#line 972 "x10/regionarray/DistArray.x10"
                ghostManager.waitOnGhosts();
            }}catch (java.lang.Error __lowerer__var__1__) {
                
                //#line 969 "x10/regionarray/DistArray.x10"
                throw __lowerer__var__1__;
            }catch (java.lang.Throwable __lowerer__var__2__) {
                
                //#line 969 "x10/regionarray/DistArray.x10"
                throw x10.rtt.Types.EXCEPTION.isInstance(__lowerer__var__2__) ? (java.lang.RuntimeException)(__lowerer__var__2__) : new x10.lang.WrappedThrowable(__lowerer__var__2__);
            }
        }
        
        public x10.regionarray.DistArray<$T> out$$;
        public x10.lang.PlaceLocalHandle<x10.regionarray.DistArray.LocalState<$T>> localHandle;
        
        public $Closure$236(final x10.rtt.Type $T, final x10.regionarray.DistArray<$T> out$$, final x10.lang.PlaceLocalHandle<x10.regionarray.DistArray.LocalState<$T>> localHandle, __0$1x10$regionarray$DistArray$$Closure$236$$T$2__1$1x10$regionarray$DistArray$LocalState$1x10$regionarray$DistArray$$Closure$236$$T$2$2 $dummy) {
            x10.regionarray.DistArray.$Closure$236.$initParams(this, $T);
             {
                ((x10.regionarray.DistArray.$Closure$236<$T>)this).out$$ = out$$;
                ((x10.regionarray.DistArray.$Closure$236<$T>)this).localHandle = ((x10.lang.PlaceLocalHandle)(localHandle));
            }
        }
        
    }
    
    @x10.runtime.impl.java.X10Generated
    final public static class $Closure$237<$T> extends x10.core.Ref implements x10.core.fun.VoidFun_0_0, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<$Closure$237> $RTT = 
            x10.rtt.StaticVoidFunType.<$Closure$237> make($Closure$237.class,
                                                          1,
                                                          new x10.rtt.Type[] {
                                                              x10.core.fun.VoidFun_0_0.$RTT
                                                          });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { if (i == 0) return $T; return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static <$T> x10.serialization.X10JavaSerializable $_deserialize_body(x10.regionarray.DistArray.$Closure$237<$T> $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            $_obj.$T = (x10.rtt.Type) $deserializer.readObject();
            $_obj.__lowerer__var__0__ = $deserializer.readObject();
            $_obj.localHandle = $deserializer.readObject();
            $_obj.out$$ = $deserializer.readObject();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.regionarray.DistArray.$Closure$237 $_obj = new x10.regionarray.DistArray.$Closure$237((java.lang.System[]) null, (x10.rtt.Type) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            $serializer.write(this.$T);
            $serializer.write(this.__lowerer__var__0__);
            $serializer.write(this.localHandle);
            $serializer.write(this.out$$);
            
        }
        
        // constructor just for allocation
        public $Closure$237(final java.lang.System[] $dummy, final x10.rtt.Type $T) {
            x10.regionarray.DistArray.$Closure$237.$initParams(this, $T);
            
        }
        
        private x10.rtt.Type $T;
        
        // initializer of type parameters
        public static void $initParams(final $Closure$237 $this, final x10.rtt.Type $T) {
            $this.$T = $T;
            
        }
        // synthetic type for parameter mangling
        public static final class __0$1x10$regionarray$DistArray$$Closure$237$$T$2__2$1x10$regionarray$DistArray$LocalState$1x10$regionarray$DistArray$$Closure$237$$T$2$2 {}
        
    
        
        public void $apply() {
            
            //#line 969 "x10/regionarray/DistArray.x10"
            try {{
                
                //#line 969 "x10/regionarray/DistArray.x10"
                for (
                     //#line 969 "x10/regionarray/DistArray.x10"
                     final x10.lang.Iterator place$151698 = this.__lowerer__var__0__.restriction(((x10.lang.Place)(x10.x10rt.X10RT.here()))).region.iterator();
                     ((x10.lang.Iterator<x10.lang.Point>)place$151698).hasNext$O();
                     ) {
                    
                    //#line 969 "x10/regionarray/DistArray.x10"
                    final x10.lang.Point place = ((x10.lang.Point)(((x10.lang.Iterator<x10.lang.Point>)place$151698).next$G()));
                    
                    //#line 969 "x10/regionarray/DistArray.x10"
                    x10.xrx.Runtime.runAsync(((x10.lang.Place)(x10.x10rt.X10RT.here())), ((x10.core.fun.VoidFun_0_0)(new x10.regionarray.DistArray.$Closure$236<$T>($T, ((x10.regionarray.DistArray)(this.out$$)), ((x10.lang.PlaceLocalHandle<x10.regionarray.DistArray.LocalState<$T>>)(this.localHandle)), (x10.regionarray.DistArray.$Closure$236.__0$1x10$regionarray$DistArray$$Closure$236$$T$2__1$1x10$regionarray$DistArray$LocalState$1x10$regionarray$DistArray$$Closure$236$$T$2$2) null))), ((x10.xrx.Runtime.Profile)(null)));
                }
            }}catch (java.lang.Error __lowerer__var__4__) {
                
                //#line 969 "x10/regionarray/DistArray.x10"
                throw __lowerer__var__4__;
            }catch (java.lang.Throwable __lowerer__var__5__) {
                
                //#line 969 "x10/regionarray/DistArray.x10"
                throw x10.rtt.Types.EXCEPTION.isInstance(__lowerer__var__5__) ? (java.lang.RuntimeException)(__lowerer__var__5__) : new x10.lang.WrappedThrowable(__lowerer__var__5__);
            }
        }
        
        public x10.regionarray.DistArray<$T> out$$;
        public x10.regionarray.Dist __lowerer__var__0__;
        public x10.lang.PlaceLocalHandle<x10.regionarray.DistArray.LocalState<$T>> localHandle;
        
        public $Closure$237(final x10.rtt.Type $T, final x10.regionarray.DistArray<$T> out$$, final x10.regionarray.Dist __lowerer__var__0__, final x10.lang.PlaceLocalHandle<x10.regionarray.DistArray.LocalState<$T>> localHandle, __0$1x10$regionarray$DistArray$$Closure$237$$T$2__2$1x10$regionarray$DistArray$LocalState$1x10$regionarray$DistArray$$Closure$237$$T$2$2 $dummy) {
            x10.regionarray.DistArray.$Closure$237.$initParams(this, $T);
             {
                ((x10.regionarray.DistArray.$Closure$237<$T>)this).out$$ = ((x10.regionarray.DistArray)(out$$));
                ((x10.regionarray.DistArray.$Closure$237<$T>)this).__lowerer__var__0__ = ((x10.regionarray.Dist)(__lowerer__var__0__));
                ((x10.regionarray.DistArray.$Closure$237<$T>)this).localHandle = ((x10.lang.PlaceLocalHandle)(localHandle));
            }
        }
        
    }
    
    @x10.runtime.impl.java.X10Generated
    final public static class $Closure$238<$T> extends x10.core.Ref implements x10.core.fun.VoidFun_0_0, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<$Closure$238> $RTT = 
            x10.rtt.StaticVoidFunType.<$Closure$238> make($Closure$238.class,
                                                          1,
                                                          new x10.rtt.Type[] {
                                                              x10.core.fun.VoidFun_0_0.$RTT
                                                          });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { if (i == 0) return $T; return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static <$T> x10.serialization.X10JavaSerializable $_deserialize_body(x10.regionarray.DistArray.$Closure$238<$T> $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            $_obj.$T = (x10.rtt.Type) $deserializer.readObject();
            $_obj.localHandle = $deserializer.readObject();
            $_obj.neighborPortion = $deserializer.readObject();
            $_obj.out$$ = $deserializer.readObject();
            $_obj.phase = $deserializer.readByte();
            $_obj.shift = $deserializer.readObject();
            $_obj.sourcePlace = $deserializer.readObject();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.regionarray.DistArray.$Closure$238 $_obj = new x10.regionarray.DistArray.$Closure$238((java.lang.System[]) null, (x10.rtt.Type) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            $serializer.write(this.$T);
            $serializer.write(this.localHandle);
            $serializer.write(this.neighborPortion);
            $serializer.write(this.out$$);
            $serializer.write(this.phase);
            $serializer.write(this.shift);
            $serializer.write(this.sourcePlace);
            
        }
        
        // constructor just for allocation
        public $Closure$238(final java.lang.System[] $dummy, final x10.rtt.Type $T) {
            x10.regionarray.DistArray.$Closure$238.$initParams(this, $T);
            
        }
        
        private x10.rtt.Type $T;
        
        // initializer of type parameters
        public static void $initParams(final $Closure$238 $this, final x10.rtt.Type $T) {
            $this.$T = $T;
            
        }
        // synthetic type for parameter mangling
        public static final class __0$1x10$regionarray$DistArray$$Closure$238$$T$2__1$1x10$regionarray$DistArray$LocalState$1x10$regionarray$DistArray$$Closure$238$$T$2$2__3$1x10$regionarray$DistArray$$Closure$238$$T$2 {}
        
    
        
        public void $apply() {
            
            //#line 1014 "x10/regionarray/DistArray.x10"
            try {{
                
                //#line 1015 "x10/regionarray/DistArray.x10"
                final x10.lang.PlaceLocalHandle t$151221 = ((x10.lang.PlaceLocalHandle)(this.localHandle));
                
                //#line 1015 "x10/regionarray/DistArray.x10"
                final x10.regionarray.DistArray.LocalState t$151222 = ((x10.regionarray.DistArray.LocalState)(((x10.lang.PlaceLocalHandle<x10.regionarray.DistArray.LocalState<$T>>)t$151221).$apply$G()));
                
                //#line 1015 "x10/regionarray/DistArray.x10"
                final x10.regionarray.GhostManager ghostManager = ((x10.regionarray.GhostManager)(((x10.regionarray.DistArray.LocalState<$T>)t$151222).ghostManager));
                {
                    
                    //#line 1016 "x10/regionarray/DistArray.x10"
                    x10.xrx.Runtime.ensureNotInAtomic();
                    
                    //#line 1016 "x10/regionarray/DistArray.x10"
                    try {{
                        
                        //#line 1016 "x10/regionarray/DistArray.x10"
                        x10.xrx.Runtime.enterAtomic();
                        
                        //#line 1016 "x10/regionarray/DistArray.x10"
                        while (true) {
                            
                            //#line 1016 "x10/regionarray/DistArray.x10"
                            if (((byte) ghostManager.currentPhase$O()) == ((byte) this.phase)) {
                                {
                                    
                                }
                                
                                //#line 1016 "x10/regionarray/DistArray.x10"
                                break;
                            }
                            
                            //#line 1016 "x10/regionarray/DistArray.x10"
                            x10.xrx.Runtime.awaitAtomic();
                        }
                    }}finally {{
                          
                          //#line 1016 "x10/regionarray/DistArray.x10"
                          x10.xrx.Runtime.exitAtomic();
                      }}
                    }
                
                //#line 1017 "x10/regionarray/DistArray.x10"
                final x10.regionarray.Array local2 = ((x10.regionarray.Array)(((x10.regionarray.Array<$T>)
                                                                                ((x10.regionarray.DistArray<$T>)this.out$$).getLocalPortion())));
                
                //#line 1018 "x10/regionarray/DistArray.x10"
                final x10.regionarray.Region t$151223 = ((x10.regionarray.Region)(((x10.regionarray.Array<$T>)this.neighborPortion).region));
                
                //#line 1018 "x10/regionarray/DistArray.x10"
                final x10.regionarray.Region t$149752 = ((x10.regionarray.Region)
                                                          t$151223);
                
                //#line 1018 "x10/regionarray/DistArray.x10"
                final boolean t$151224 = t$149752.rect;
                
                //#line 1018 "x10/regionarray/DistArray.x10"
                boolean t$151229 = ((boolean) t$151224) == ((boolean) true);
                
                //#line 1018 "x10/regionarray/DistArray.x10"
                if (t$151229) {
                    
                    //#line 1018 "x10/regionarray/DistArray.x10"
                    final long t$151227 = t$149752.rank;
                    
                    //#line 1018 "x10/regionarray/DistArray.x10"
                    final x10.regionarray.Dist t$151225 = ((x10.regionarray.Dist)(((x10.regionarray.DistArray<$T>)this.out$$).dist));
                    
                    //#line 1018 "x10/regionarray/DistArray.x10"
                    final x10.regionarray.Region t$151226 = ((x10.regionarray.Region)(t$151225.region));
                    
                    //#line 1018 "x10/regionarray/DistArray.x10"
                    final long t$151228 = t$151226.rank;
                    
                    //#line 1018 "x10/regionarray/DistArray.x10"
                    t$151229 = ((long) t$151227) == ((long) t$151228);
                }
                
                //#line 1018 "x10/regionarray/DistArray.x10"
                final boolean t$151232 = !(t$151229);
                
                //#line 1018 "x10/regionarray/DistArray.x10"
                if (t$151232) {
                    
                    //#line 1018 "x10/regionarray/DistArray.x10"
                    final x10.lang.FailedDynamicCheckException t$151231 = new x10.lang.FailedDynamicCheckException("x10.regionarray.Region{self.rect==true, self.rank==this(:x10.regionarray.DistArray).dist.region.rank}");
                    
                    //#line 1018 "x10/regionarray/DistArray.x10"
                    throw t$151231;
                }
                
                //#line 1018 "x10/regionarray/DistArray.x10"
                ((x10.regionarray.Array<$T>)local2).copy__0$1x10$regionarray$Array$$T$2(((x10.regionarray.Array)(this.neighborPortion)), ((x10.regionarray.Region)(t$149752)));
                
                //#line 1019 "x10/regionarray/DistArray.x10"
                final x10.lang.Point t$151233 = ((x10.lang.Point)(this.shift.$minus()));
                
                //#line 1019 "x10/regionarray/DistArray.x10"
                ghostManager.setNeighborReceived(((x10.lang.Place)(this.sourcePlace)), ((x10.lang.Point)(t$151233)));
                }}catch (java.lang.Error __lowerer__var__0__) {
                    
                    //#line 1014 "x10/regionarray/DistArray.x10"
                    throw __lowerer__var__0__;
                }catch (java.lang.Throwable __lowerer__var__1__) {
                    
                    //#line 1014 "x10/regionarray/DistArray.x10"
                    throw x10.rtt.Types.EXCEPTION.isInstance(__lowerer__var__1__) ? (java.lang.RuntimeException)(__lowerer__var__1__) : new x10.lang.WrappedThrowable(__lowerer__var__1__);
                }
            }
        
        public x10.regionarray.DistArray<$T> out$$;
        public x10.lang.PlaceLocalHandle<x10.regionarray.DistArray.LocalState<$T>> localHandle;
        public byte phase;
        public x10.regionarray.Array<$T> neighborPortion;
        public x10.lang.Point shift;
        public x10.lang.Place sourcePlace;
        
        public $Closure$238(final x10.rtt.Type $T, final x10.regionarray.DistArray<$T> out$$, final x10.lang.PlaceLocalHandle<x10.regionarray.DistArray.LocalState<$T>> localHandle, final byte phase, final x10.regionarray.Array<$T> neighborPortion, final x10.lang.Point shift, final x10.lang.Place sourcePlace, __0$1x10$regionarray$DistArray$$Closure$238$$T$2__1$1x10$regionarray$DistArray$LocalState$1x10$regionarray$DistArray$$Closure$238$$T$2$2__3$1x10$regionarray$DistArray$$Closure$238$$T$2 $dummy) {
            x10.regionarray.DistArray.$Closure$238.$initParams(this, $T);
             {
                ((x10.regionarray.DistArray.$Closure$238<$T>)this).out$$ = out$$;
                ((x10.regionarray.DistArray.$Closure$238<$T>)this).localHandle = ((x10.lang.PlaceLocalHandle)(localHandle));
                ((x10.regionarray.DistArray.$Closure$238<$T>)this).phase = phase;
                ((x10.regionarray.DistArray.$Closure$238<$T>)this).neighborPortion = ((x10.regionarray.Array)(neighborPortion));
                ((x10.regionarray.DistArray.$Closure$238<$T>)this).shift = ((x10.lang.Point)(shift));
                ((x10.regionarray.DistArray.$Closure$238<$T>)this).sourcePlace = ((x10.lang.Place)(sourcePlace));
            }
        }
        
        }
        
    @x10.runtime.impl.java.X10Generated
    final public static class $Closure$239<$T> extends x10.core.Ref implements x10.core.fun.VoidFun_0_0, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<$Closure$239> $RTT = 
            x10.rtt.StaticVoidFunType.<$Closure$239> make($Closure$239.class,
                                                          1,
                                                          new x10.rtt.Type[] {
                                                              x10.core.fun.VoidFun_0_0.$RTT
                                                          });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { if (i == 0) return $T; return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static <$T> x10.serialization.X10JavaSerializable $_deserialize_body(x10.regionarray.DistArray.$Closure$239<$T> $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            $_obj.$T = (x10.rtt.Type) $deserializer.readObject();
            $_obj.localHandle = $deserializer.readObject();
            $_obj.neighborPortion = $deserializer.readObject();
            $_obj.out$$ = $deserializer.readObject();
            $_obj.phase = $deserializer.readByte();
            $_obj.shift = $deserializer.readObject();
            $_obj.sourcePlace = $deserializer.readObject();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.regionarray.DistArray.$Closure$239 $_obj = new x10.regionarray.DistArray.$Closure$239((java.lang.System[]) null, (x10.rtt.Type) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            $serializer.write(this.$T);
            $serializer.write(this.localHandle);
            $serializer.write(this.neighborPortion);
            $serializer.write(this.out$$);
            $serializer.write(this.phase);
            $serializer.write(this.shift);
            $serializer.write(this.sourcePlace);
            
        }
        
        // constructor just for allocation
        public $Closure$239(final java.lang.System[] $dummy, final x10.rtt.Type $T) {
            x10.regionarray.DistArray.$Closure$239.$initParams(this, $T);
            
        }
        
        private x10.rtt.Type $T;
        
        // initializer of type parameters
        public static void $initParams(final $Closure$239 $this, final x10.rtt.Type $T) {
            $this.$T = $T;
            
        }
        // synthetic type for parameter mangling
        public static final class __0$1x10$regionarray$DistArray$$Closure$239$$T$2__1$1x10$regionarray$DistArray$LocalState$1x10$regionarray$DistArray$$Closure$239$$T$2$2__3$1x10$regionarray$DistArray$$Closure$239$$T$2 {}
        
    
        
        public void $apply() {
            
            //#line 1037 "x10/regionarray/DistArray.x10"
            try {{
                
                //#line 1038 "x10/regionarray/DistArray.x10"
                final x10.lang.PlaceLocalHandle t$151289 = ((x10.lang.PlaceLocalHandle)(this.localHandle));
                
                //#line 1038 "x10/regionarray/DistArray.x10"
                final x10.regionarray.DistArray.LocalState t$151290 = ((x10.regionarray.DistArray.LocalState)(((x10.lang.PlaceLocalHandle<x10.regionarray.DistArray.LocalState<$T>>)t$151289).$apply$G()));
                
                //#line 1038 "x10/regionarray/DistArray.x10"
                final x10.regionarray.GhostManager ghostManager = ((x10.regionarray.GhostManager)(((x10.regionarray.DistArray.LocalState<$T>)t$151290).ghostManager));
                {
                    
                    //#line 1039 "x10/regionarray/DistArray.x10"
                    x10.xrx.Runtime.ensureNotInAtomic();
                    
                    //#line 1039 "x10/regionarray/DistArray.x10"
                    try {{
                        
                        //#line 1039 "x10/regionarray/DistArray.x10"
                        x10.xrx.Runtime.enterAtomic();
                        
                        //#line 1039 "x10/regionarray/DistArray.x10"
                        while (true) {
                            
                            //#line 1039 "x10/regionarray/DistArray.x10"
                            if (((byte) ghostManager.currentPhase$O()) == ((byte) this.phase)) {
                                {
                                    
                                }
                                
                                //#line 1039 "x10/regionarray/DistArray.x10"
                                break;
                            }
                            
                            //#line 1039 "x10/regionarray/DistArray.x10"
                            x10.xrx.Runtime.awaitAtomic();
                        }
                    }}finally {{
                          
                          //#line 1039 "x10/regionarray/DistArray.x10"
                          x10.xrx.Runtime.exitAtomic();
                      }}
                    }
                
                //#line 1040 "x10/regionarray/DistArray.x10"
                final x10.regionarray.Array t$151291 = ((x10.regionarray.Array)(((x10.regionarray.Array<$T>)
                                                                                  ((x10.regionarray.DistArray<$T>)this.out$$).getLocalPortion())));
                
                //#line 1040 "x10/regionarray/DistArray.x10"
                final x10.regionarray.Array t$149767 = ((x10.regionarray.Array<$T>)
                                                         t$151291);
                
                //#line 1040 "x10/regionarray/DistArray.x10"
                final boolean t$151292 = ((x10.regionarray.Array<$T>)t$149767).rect;
                
                //#line 1040 "x10/regionarray/DistArray.x10"
                boolean t$151294 = ((boolean) t$151292) == ((boolean) true);
                
                //#line 1040 "x10/regionarray/DistArray.x10"
                if (t$151294) {
                    
                    //#line 1040 "x10/regionarray/DistArray.x10"
                    final long t$151293 = ((x10.regionarray.Array<$T>)t$149767).rank;
                    
                    //#line 1040 "x10/regionarray/DistArray.x10"
                    t$151294 = ((long) t$151293) == ((long) 3L);
                }
                
                //#line 1040 "x10/regionarray/DistArray.x10"
                final boolean t$151297 = !(t$151294);
                
                //#line 1040 "x10/regionarray/DistArray.x10"
                if (t$151297) {
                    
                    //#line 1040 "x10/regionarray/DistArray.x10"
                    final x10.lang.FailedDynamicCheckException t$151296 = new x10.lang.FailedDynamicCheckException("x10.regionarray.Array[T]{self.rect==true, self.rank==3L}");
                    
                    //#line 1040 "x10/regionarray/DistArray.x10"
                    throw t$151296;
                }
                
                //#line 1041 "x10/regionarray/DistArray.x10"
                final x10.regionarray.Region t$151298 = ((x10.regionarray.Region)(((x10.regionarray.Array<$T>)this.neighborPortion).region));
                
                //#line 1041 "x10/regionarray/DistArray.x10"
                ((x10.regionarray.Array<$T>)t$149767).copy__0$1x10$regionarray$Array$$T$2(((x10.regionarray.Array)(this.neighborPortion)), ((x10.regionarray.Region)(t$151298)));
                
                //#line 1042 "x10/regionarray/DistArray.x10"
                final x10.lang.Point t$151299 = ((x10.lang.Point)(this.shift.$minus()));
                
                //#line 1042 "x10/regionarray/DistArray.x10"
                ghostManager.setNeighborReceived(((x10.lang.Place)(this.sourcePlace)), ((x10.lang.Point)(t$151299)));
                }}catch (java.lang.Error __lowerer__var__0__) {
                    
                    //#line 1037 "x10/regionarray/DistArray.x10"
                    throw __lowerer__var__0__;
                }catch (java.lang.Throwable __lowerer__var__1__) {
                    
                    //#line 1037 "x10/regionarray/DistArray.x10"
                    throw x10.rtt.Types.EXCEPTION.isInstance(__lowerer__var__1__) ? (java.lang.RuntimeException)(__lowerer__var__1__) : new x10.lang.WrappedThrowable(__lowerer__var__1__);
                }
            }
        
        public x10.regionarray.DistArray<$T> out$$;
        public x10.lang.PlaceLocalHandle<x10.regionarray.DistArray.LocalState<$T>> localHandle;
        public byte phase;
        public x10.regionarray.Array<$T> neighborPortion;
        public x10.lang.Point shift;
        public x10.lang.Place sourcePlace;
        
        public $Closure$239(final x10.rtt.Type $T, final x10.regionarray.DistArray<$T> out$$, final x10.lang.PlaceLocalHandle<x10.regionarray.DistArray.LocalState<$T>> localHandle, final byte phase, final x10.regionarray.Array<$T> neighborPortion, final x10.lang.Point shift, final x10.lang.Place sourcePlace, __0$1x10$regionarray$DistArray$$Closure$239$$T$2__1$1x10$regionarray$DistArray$LocalState$1x10$regionarray$DistArray$$Closure$239$$T$2$2__3$1x10$regionarray$DistArray$$Closure$239$$T$2 $dummy) {
            x10.regionarray.DistArray.$Closure$239.$initParams(this, $T);
             {
                ((x10.regionarray.DistArray.$Closure$239<$T>)this).out$$ = out$$;
                ((x10.regionarray.DistArray.$Closure$239<$T>)this).localHandle = ((x10.lang.PlaceLocalHandle)(localHandle));
                ((x10.regionarray.DistArray.$Closure$239<$T>)this).phase = phase;
                ((x10.regionarray.DistArray.$Closure$239<$T>)this).neighborPortion = ((x10.regionarray.Array)(neighborPortion));
                ((x10.regionarray.DistArray.$Closure$239<$T>)this).shift = ((x10.lang.Point)(shift));
                ((x10.regionarray.DistArray.$Closure$239<$T>)this).sourcePlace = ((x10.lang.Place)(sourcePlace));
            }
        }
        
        }
        
    }
    
    
    
    
    
    