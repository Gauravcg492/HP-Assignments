package x10.glb;

/**
 * <p>
 * A TaskQueue[Queue, Z] (Z is the type of the result, Queue is the concrete type of TaskQueue).
 * The way as it is today (with Queue as one of the required generic types) 
 * is because performance issue, i.e., compiler can replace TaskQueue with Queue
 * at the compile time, thus saving a virtual function loop up whenever it is called within GLB. No semantic benefits.
 * represents the user-defined data-structure maintained at each place by the
 * GLB implementation. It is recommended to have an associated {@link TaskBag} to facilitate the split/merge methods. 
 */
@x10.runtime.impl.java.X10Generated
public interface TaskQueue<$Queue, $R> extends x10.core.Any
{
    public static final x10.rtt.RuntimeType<TaskQueue> $RTT = 
        x10.rtt.NamedType.<TaskQueue> make("x10.glb.TaskQueue",
                                           TaskQueue.class,
                                           2);
    
    

    
    
    //#line 27 "x10/glb/TaskQueue.x10"
    boolean process$Z(final long n, final x10.glb.Context context, x10.rtt.Type t1);
    
    
    //#line 34 "x10/glb/TaskQueue.x10"
    /**
     * Split the current TaskBag
     * @return null if TaskBag is too small to return
     *         TaskBag split
     */
    x10.glb.TaskBag split();
    
    
    //#line 41 "x10/glb/TaskQueue.x10"
    /**
     * Merge TaskBag into the current task bag , thus 
     * changing the state of current taskbag.
     * @param tb incoming TaskBag
     */
    void merge(final x10.glb.TaskBag tb);
    
    
    //#line 48 "x10/glb/TaskQueue.x10"
    /**
     * Returns the number of task items that have been prcoessed.
     * This method is used to keep track of task item statistics (i.e. a hint), whether it is
     * implemented faithfully is not important.
     */
    long count$O();
    
    
    //#line 54 "x10/glb/TaskQueue.x10"
    /**
     * Returns the computation result.
     * @return computation result
     */
    x10.glb.GLBResult getResult();
    
    
    //#line 62 "x10/glb/TaskQueue.x10"
    /**
     * Auxiliary function that user can overwrite to print the statistics one cares about,
     * e.g., computation time. This function will be called only after all the calculation
     * and results reduction are done.
     */
    void printLog();
}

