package x10.glb;

/**
 * <p>Class that collects lifeline statistics of GLB
 * </p>
 */
@x10.runtime.impl.java.X10Generated
final public class Logger extends x10.core.Ref implements x10.serialization.X10JavaSerializable
{
    public static final x10.rtt.RuntimeType<Logger> $RTT = 
        x10.rtt.NamedType.<Logger> make("x10.glb.Logger",
                                        Logger.class);
    
    public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
    
    public x10.rtt.Type<?> $getParam(int i) { return null; }
    
    private Object writeReplace() throws java.io.ObjectStreamException {
        return new x10.serialization.SerializationProxy(this);
    }
    
    public static x10.serialization.X10JavaSerializable $_deserialize_body(x10.glb.Logger $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
        $_obj.lastStartStopLiveTimeStamp = $deserializer.readLong();
        $_obj.lifelineNodesReceived = $deserializer.readLong();
        $_obj.lifelineStealsAttempted = $deserializer.readLong();
        $_obj.lifelineStealsPerpetrated = $deserializer.readLong();
        $_obj.lifelineStealsReceived = $deserializer.readLong();
        $_obj.lifelineStealsSuffered = $deserializer.readLong();
        $_obj.nodesCount = $deserializer.readLong();
        $_obj.nodesGiven = $deserializer.readLong();
        $_obj.nodesReceived = $deserializer.readLong();
        $_obj.startTime = $deserializer.readLong();
        $_obj.stealsAttempted = $deserializer.readLong();
        $_obj.stealsPerpetrated = $deserializer.readLong();
        $_obj.stealsReceived = $deserializer.readLong();
        $_obj.stealsSuffered = $deserializer.readLong();
        $_obj.timeAlive = $deserializer.readLong();
        $_obj.timeDead = $deserializer.readLong();
        $_obj.timeReference = $deserializer.readLong();
        return $_obj;
    }
    
    public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
        x10.glb.Logger $_obj = new x10.glb.Logger((java.lang.System[]) null);
        $deserializer.record_reference($_obj);
        return $_deserialize_body($_obj, $deserializer);
    }
    
    public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
        $serializer.write(this.lastStartStopLiveTimeStamp);
        $serializer.write(this.lifelineNodesReceived);
        $serializer.write(this.lifelineStealsAttempted);
        $serializer.write(this.lifelineStealsPerpetrated);
        $serializer.write(this.lifelineStealsReceived);
        $serializer.write(this.lifelineStealsSuffered);
        $serializer.write(this.nodesCount);
        $serializer.write(this.nodesGiven);
        $serializer.write(this.nodesReceived);
        $serializer.write(this.startTime);
        $serializer.write(this.stealsAttempted);
        $serializer.write(this.stealsPerpetrated);
        $serializer.write(this.stealsReceived);
        $serializer.write(this.stealsSuffered);
        $serializer.write(this.timeAlive);
        $serializer.write(this.timeDead);
        $serializer.write(this.timeReference);
        
    }
    
    // constructor just for allocation
    public Logger(final java.lang.System[] $dummy) {
        
    }
    
    

    
    //#line 21 "x10/glb/Logger.x10"
    public long nodesCount;
    
    //#line 22 "x10/glb/Logger.x10"
    public long nodesGiven;
    
    //#line 23 "x10/glb/Logger.x10"
    public long lifelineNodesReceived;
    
    //#line 26 "x10/glb/Logger.x10"
    public long stealsAttempted;
    
    //#line 27 "x10/glb/Logger.x10"
    public long stealsPerpetrated;
    
    //#line 28 "x10/glb/Logger.x10"
    public long stealsReceived;
    
    //#line 29 "x10/glb/Logger.x10"
    public long stealsSuffered;
    
    //#line 30 "x10/glb/Logger.x10"
    public long nodesReceived;
    
    //#line 33 "x10/glb/Logger.x10"
    public long lifelineStealsAttempted;
    
    //#line 34 "x10/glb/Logger.x10"
    public long lifelineStealsPerpetrated;
    
    //#line 35 "x10/glb/Logger.x10"
    public long lifelineStealsReceived;
    
    //#line 36 "x10/glb/Logger.x10"
    public long lifelineStealsSuffered;
    
    //#line 40 "x10/glb/Logger.x10"
    public long lastStartStopLiveTimeStamp;
    
    //#line 41 "x10/glb/Logger.x10"
    public long timeAlive;
    
    //#line 42 "x10/glb/Logger.x10"
    public long timeDead;
    
    //#line 43 "x10/glb/Logger.x10"
    public long startTime;
    
    //#line 44 "x10/glb/Logger.x10"
    public long timeReference;
    
    
    //#line 52 "x10/glb/Logger.x10"
    /**
     * Constructor
     * @param b true, called when prior-calculation; false, called when post-calculation
     */
    // creation method for java code (1-phase java constructor)
    public Logger(final boolean b) {
        this((java.lang.System[]) null);
        x10$glb$Logger$$init$S(b);
    }
    
    // constructor for non-virtual call
    final public x10.glb.Logger x10$glb$Logger$$init$S(final boolean b) {
         {
            
            //#line 52 "x10/glb/Logger.x10"
            
            
            //#line 18 "x10/glb/Logger.x10"
            this.__fieldInitializers_x10_glb_Logger();
            
            //#line 53 "x10/glb/Logger.x10"
            if (b) {
                
                //#line 53 "x10/glb/Logger.x10"
                final x10.util.Team t$128199 = ((x10.util.Team)(x10.util.Team.get$WORLD()));
                
                //#line 53 "x10/glb/Logger.x10"
                t$128199.barrier();
            }
            
            //#line 40 . "x10/lang/System.x10"
            final long t$128200 = java.lang.System.nanoTime();
            
            //#line 54 "x10/glb/Logger.x10"
            this.timeReference = t$128200;
        }
        return this;
    }
    
    
    
    //#line 61 "x10/glb/Logger.x10"
    /**
     * Timer is started before processing, which includes calculation, distribution and requesting/rejects tasks
     */
    public void startLive() {
        
        //#line 62 "x10/glb/Logger.x10"
        final long time = java.lang.System.nanoTime();
        
        //#line 63 "x10/glb/Logger.x10"
        final long t$128201 = this.startTime;
        
        //#line 63 "x10/glb/Logger.x10"
        final boolean t$128202 = ((long) t$128201) == ((long) 0L);
        
        //#line 63 "x10/glb/Logger.x10"
        if (t$128202) {
            
            //#line 63 "x10/glb/Logger.x10"
            this.startTime = time;
        }
        
        //#line 64 "x10/glb/Logger.x10"
        final long t$128203 = this.lastStartStopLiveTimeStamp;
        
        //#line 64 "x10/glb/Logger.x10"
        final boolean t$128208 = ((t$128203) >= (((long)(0L))));
        
        //#line 64 "x10/glb/Logger.x10"
        if (t$128208) {
            
            //#line 65 "x10/glb/Logger.x10"
            final long t$128205 = this.timeDead;
            
            //#line 65 "x10/glb/Logger.x10"
            final long t$128204 = this.lastStartStopLiveTimeStamp;
            
            //#line 65 "x10/glb/Logger.x10"
            final long t$128206 = ((time) - (((long)(t$128204))));
            
            //#line 65 "x10/glb/Logger.x10"
            final long t$128207 = ((t$128205) + (((long)(t$128206))));
            
            //#line 65 "x10/glb/Logger.x10"
            this.timeDead = t$128207;
        }
        
        //#line 67 "x10/glb/Logger.x10"
        this.lastStartStopLiveTimeStamp = time;
    }
    
    
    //#line 73 "x10/glb/Logger.x10"
    /**
     * Timer is stopped when running out of tasks and failing to steal any task
     */
    public void stopLive() {
        
        //#line 74 "x10/glb/Logger.x10"
        final long time = java.lang.System.nanoTime();
        
        //#line 75 "x10/glb/Logger.x10"
        final long t$128210 = this.timeAlive;
        
        //#line 75 "x10/glb/Logger.x10"
        final long t$128209 = this.lastStartStopLiveTimeStamp;
        
        //#line 75 "x10/glb/Logger.x10"
        final long t$128211 = ((time) - (((long)(t$128209))));
        
        //#line 75 "x10/glb/Logger.x10"
        final long t$128212 = ((t$128210) + (((long)(t$128211))));
        
        //#line 75 "x10/glb/Logger.x10"
        this.timeAlive = t$128212;
        
        //#line 76 "x10/glb/Logger.x10"
        this.lastStartStopLiveTimeStamp = time;
    }
    
    
    //#line 83 "x10/glb/Logger.x10"
    /**
     * Aggregate stats for all places
     * @param logs log from every place
     */
    public void collect__0$1x10$glb$Logger$2(final x10.core.Rail logs) {
        
        //#line 84 "x10/glb/Logger.x10"
        final long size$121113 = ((x10.core.Rail<x10.glb.Logger>)logs).size;
        
        //#line 84 "x10/glb/Logger.x10"
        long idx$128356 = 0L;
        {
            
            //#line 84 "x10/glb/Logger.x10"
            final x10.glb.Logger[] logs$value$128359 = ((x10.glb.Logger[])logs.value);
            
            //#line 84 "x10/glb/Logger.x10"
            for (;
                 true;
                 ) {
                
                //#line 84 "x10/glb/Logger.x10"
                final boolean t$128358 = ((idx$128356) < (((long)(size$121113))));
                
                //#line 84 "x10/glb/Logger.x10"
                if (!(t$128358)) {
                    
                    //#line 84 "x10/glb/Logger.x10"
                    break;
                }
                
                //#line 84 "x10/glb/Logger.x10"
                final x10.glb.Logger l$128353 = ((x10.glb.Logger)(((x10.glb.Logger)logs$value$128359[(int)idx$128356])));
                
                //#line 84 "x10/glb/Logger.x10"
                this.add(((x10.glb.Logger)(l$128353)));
                
                //#line 84 "x10/glb/Logger.x10"
                final long t$128355 = ((idx$128356) + (((long)(1L))));
                
                //#line 84 "x10/glb/Logger.x10"
                idx$128356 = t$128355;
            }
        }
    }
    
    
    //#line 90 "x10/glb/Logger.x10"
    /**
     * Print out the actual workload re-distribution by showing the steals that were carried out.
     */
    public void stats() {
        
        //#line 91 "x10/glb/Logger.x10"
        final x10.io.Printer t$128226 = ((x10.io.Printer)(x10.io.Console.get$OUT()));
        
        //#line 91 "x10/glb/Logger.x10"
        final long t$128219 = this.nodesGiven;
        
        //#line 91 "x10/glb/Logger.x10"
        final java.lang.String t$128220 = (((x10.core.Long.$box(t$128219))) + (" Task items stolen = "));
        
        //#line 91 "x10/glb/Logger.x10"
        final long t$128221 = this.nodesReceived;
        
        //#line 91 "x10/glb/Logger.x10"
        final java.lang.String t$128222 = ((t$128220) + ((x10.core.Long.$box(t$128221))));
        
        //#line 91 "x10/glb/Logger.x10"
        final java.lang.String t$128223 = ((t$128222) + (" (direct) + "));
        
        //#line 92 "x10/glb/Logger.x10"
        final long t$128224 = this.lifelineNodesReceived;
        
        //#line 91 "x10/glb/Logger.x10"
        final java.lang.String t$128225 = ((t$128223) + ((x10.core.Long.$box(t$128224))));
        
        //#line 91 "x10/glb/Logger.x10"
        final java.lang.String t$128227 = ((t$128225) + (" (lifeline)."));
        
        //#line 91 "x10/glb/Logger.x10"
        t$128226.println(((java.lang.Object)(t$128227)));
        
        //#line 93 "x10/glb/Logger.x10"
        final x10.io.Printer t$128229 = ((x10.io.Printer)(x10.io.Console.get$OUT()));
        
        //#line 93 "x10/glb/Logger.x10"
        final long t$128228 = this.stealsPerpetrated;
        
        //#line 93 "x10/glb/Logger.x10"
        final java.lang.String t$128230 = (((x10.core.Long.$box(t$128228))) + (" successful direct steals."));
        
        //#line 93 "x10/glb/Logger.x10"
        t$128229.println(((java.lang.Object)(t$128230)));
        
        //#line 94 "x10/glb/Logger.x10"
        final x10.io.Printer t$128232 = ((x10.io.Printer)(x10.io.Console.get$OUT()));
        
        //#line 94 "x10/glb/Logger.x10"
        final long t$128231 = this.lifelineStealsPerpetrated;
        
        //#line 94 "x10/glb/Logger.x10"
        final java.lang.String t$128233 = (((x10.core.Long.$box(t$128231))) + (" successful lifeline steals."));
        
        //#line 94 "x10/glb/Logger.x10"
        t$128232.println(((java.lang.Object)(t$128233)));
    }
    
    
    //#line 104 "x10/glb/Logger.x10"
    /**
     * Gets part of the string.
     * @param str original string
     * @param start starting index of the string
     * @param end ending index of the string
     * @return string from start to end
     */
    public static java.lang.String sub(final java.lang.String str, final int start, final int end) {
        
        //#line 104 "x10/glb/Logger.x10"
        final int t$128234 = (str).length();
        
        //#line 104 "x10/glb/Logger.x10"
        final int t$128235 = java.lang.Math.min(((int)(end)),((int)(t$128234)));
        
        //#line 104 "x10/glb/Logger.x10"
        final java.lang.String t$128236 = (str).substring(((int)(start)), ((int)(t$128235)));
        
        //#line 104 "x10/glb/Logger.x10"
        return t$128236;
    }
    
    
    //#line 110 "x10/glb/Logger.x10"
    /**
     * Sum up stat with another logger
     * @param other another logger to sum up with
     */
    public void add(final x10.glb.Logger other) {
        
        //#line 111 "x10/glb/Logger.x10"
        final long t$128237 = this.nodesCount;
        
        //#line 111 "x10/glb/Logger.x10"
        final long t$128238 = other.nodesCount;
        
        //#line 111 "x10/glb/Logger.x10"
        final long t$128239 = ((t$128237) + (((long)(t$128238))));
        
        //#line 111 "x10/glb/Logger.x10"
        this.nodesCount = t$128239;
        
        //#line 112 "x10/glb/Logger.x10"
        final long t$128240 = this.nodesGiven;
        
        //#line 112 "x10/glb/Logger.x10"
        final long t$128241 = other.nodesGiven;
        
        //#line 112 "x10/glb/Logger.x10"
        final long t$128242 = ((t$128240) + (((long)(t$128241))));
        
        //#line 112 "x10/glb/Logger.x10"
        this.nodesGiven = t$128242;
        
        //#line 113 "x10/glb/Logger.x10"
        final long t$128243 = this.nodesReceived;
        
        //#line 113 "x10/glb/Logger.x10"
        final long t$128244 = other.nodesReceived;
        
        //#line 113 "x10/glb/Logger.x10"
        final long t$128245 = ((t$128243) + (((long)(t$128244))));
        
        //#line 113 "x10/glb/Logger.x10"
        this.nodesReceived = t$128245;
        
        //#line 114 "x10/glb/Logger.x10"
        final long t$128246 = this.stealsPerpetrated;
        
        //#line 114 "x10/glb/Logger.x10"
        final long t$128247 = other.stealsPerpetrated;
        
        //#line 114 "x10/glb/Logger.x10"
        final long t$128248 = ((t$128246) + (((long)(t$128247))));
        
        //#line 114 "x10/glb/Logger.x10"
        this.stealsPerpetrated = t$128248;
        
        //#line 115 "x10/glb/Logger.x10"
        final long t$128249 = this.lifelineNodesReceived;
        
        //#line 115 "x10/glb/Logger.x10"
        final long t$128250 = other.lifelineNodesReceived;
        
        //#line 115 "x10/glb/Logger.x10"
        final long t$128251 = ((t$128249) + (((long)(t$128250))));
        
        //#line 115 "x10/glb/Logger.x10"
        this.lifelineNodesReceived = t$128251;
        
        //#line 116 "x10/glb/Logger.x10"
        final long t$128252 = this.lifelineStealsPerpetrated;
        
        //#line 116 "x10/glb/Logger.x10"
        final long t$128253 = other.lifelineStealsPerpetrated;
        
        //#line 116 "x10/glb/Logger.x10"
        final long t$128254 = ((t$128252) + (((long)(t$128253))));
        
        //#line 116 "x10/glb/Logger.x10"
        this.lifelineStealsPerpetrated = t$128254;
    }
    
    
    //#line 123 "x10/glb/Logger.x10"
    /**
     * Print out more detailed lifeline stats when verbose flag turned on
     * @param verbose verbose flag true when {@link GLBParameters} show glb flag is on.
     */
    public x10.glb.Logger get(final boolean verbose) {
        
        //#line 124 "x10/glb/Logger.x10"
        if (verbose) {
            
            //#line 125 "x10/glb/Logger.x10"
            final x10.io.Printer t$128350 = ((x10.io.Printer)(x10.io.Console.get$OUT()));
            
            //#line 125 "x10/glb/Logger.x10"
            final long t$128255 = x10.x10rt.X10RT.here().id;
            
            //#line 125 "x10/glb/Logger.x10"
            final java.lang.String t$128256 = (("") + ((x10.core.Long.$box(t$128255))));
            
            //#line 125 "x10/glb/Logger.x10"
            final java.lang.String t$128261 = ((t$128256) + (" -> "));
            
            //#line 126 "x10/glb/Logger.x10"
            final long t$128257 = this.timeAlive;
            
            //#line 126 "x10/glb/Logger.x10"
            final double t$128258 = ((double)(long)(((long)(t$128257))));
            
            //#line 126 "x10/glb/Logger.x10"
            final double t$128259 = ((t$128258) / (((double)(1.0E9))));
            
            //#line 126 "x10/glb/Logger.x10"
            final java.lang.String t$128260 = (("") + ((x10.core.Double.$box(t$128259))));
            
            //#line 126 "x10/glb/Logger.x10"
            final java.lang.String t$128262 = x10.glb.Logger.sub(((java.lang.String)(t$128260)), (int)(0), (int)(6));
            
            //#line 125 "x10/glb/Logger.x10"
            final java.lang.String t$128263 = ((t$128261) + (t$128262));
            
            //#line 125 "x10/glb/Logger.x10"
            final java.lang.String t$128268 = ((t$128263) + (" : "));
            
            //#line 127 "x10/glb/Logger.x10"
            final long t$128264 = this.timeDead;
            
            //#line 127 "x10/glb/Logger.x10"
            final double t$128265 = ((double)(long)(((long)(t$128264))));
            
            //#line 127 "x10/glb/Logger.x10"
            final double t$128266 = ((t$128265) / (((double)(1.0E9))));
            
            //#line 127 "x10/glb/Logger.x10"
            final java.lang.String t$128267 = (("") + ((x10.core.Double.$box(t$128266))));
            
            //#line 127 "x10/glb/Logger.x10"
            final java.lang.String t$128269 = x10.glb.Logger.sub(((java.lang.String)(t$128267)), (int)(0), (int)(6));
            
            //#line 125 "x10/glb/Logger.x10"
            final java.lang.String t$128270 = ((t$128268) + (t$128269));
            
            //#line 125 "x10/glb/Logger.x10"
            final java.lang.String t$128277 = ((t$128270) + (" : "));
            
            //#line 128 "x10/glb/Logger.x10"
            final long t$128271 = this.timeAlive;
            
            //#line 128 "x10/glb/Logger.x10"
            final long t$128272 = this.timeDead;
            
            //#line 128 "x10/glb/Logger.x10"
            final long t$128273 = ((t$128271) + (((long)(t$128272))));
            
            //#line 128 "x10/glb/Logger.x10"
            final double t$128274 = ((double)(long)(((long)(t$128273))));
            
            //#line 128 "x10/glb/Logger.x10"
            final double t$128275 = ((t$128274) / (((double)(1.0E9))));
            
            //#line 128 "x10/glb/Logger.x10"
            final java.lang.String t$128276 = (("") + ((x10.core.Double.$box(t$128275))));
            
            //#line 128 "x10/glb/Logger.x10"
            final java.lang.String t$128278 = x10.glb.Logger.sub(((java.lang.String)(t$128276)), (int)(0), (int)(6));
            
            //#line 125 "x10/glb/Logger.x10"
            final java.lang.String t$128279 = ((t$128277) + (t$128278));
            
            //#line 125 "x10/glb/Logger.x10"
            final java.lang.String t$128289 = ((t$128279) + (" : "));
            
            //#line 129 "x10/glb/Logger.x10"
            final long t$128280 = this.timeAlive;
            
            //#line 129 "x10/glb/Logger.x10"
            final double t$128281 = ((double)(long)(((long)(t$128280))));
            
            //#line 129 "x10/glb/Logger.x10"
            final double t$128285 = ((100.0) * (((double)(t$128281))));
            
            //#line 129 "x10/glb/Logger.x10"
            final long t$128282 = this.timeAlive;
            
            //#line 129 "x10/glb/Logger.x10"
            final long t$128283 = this.timeDead;
            
            //#line 129 "x10/glb/Logger.x10"
            final long t$128284 = ((t$128282) + (((long)(t$128283))));
            
            //#line 129 "x10/glb/Logger.x10"
            final double t$128286 = ((double)(long)(((long)(t$128284))));
            
            //#line 129 "x10/glb/Logger.x10"
            final double t$128287 = ((t$128285) / (((double)(t$128286))));
            
            //#line 129 "x10/glb/Logger.x10"
            final java.lang.String t$128288 = (("") + ((x10.core.Double.$box(t$128287))));
            
            //#line 129 "x10/glb/Logger.x10"
            final java.lang.String t$128290 = x10.glb.Logger.sub(((java.lang.String)(t$128288)), (int)(0), (int)(6));
            
            //#line 125 "x10/glb/Logger.x10"
            final java.lang.String t$128291 = ((t$128289) + (t$128290));
            
            //#line 125 "x10/glb/Logger.x10"
            final java.lang.String t$128292 = ((t$128291) + ("%"));
            
            //#line 125 "x10/glb/Logger.x10"
            final java.lang.String t$128299 = ((t$128292) + (" :: "));
            
            //#line 130 "x10/glb/Logger.x10"
            final long t$128293 = this.startTime;
            
            //#line 130 "x10/glb/Logger.x10"
            final long t$128294 = this.timeReference;
            
            //#line 130 "x10/glb/Logger.x10"
            final long t$128295 = ((t$128293) - (((long)(t$128294))));
            
            //#line 130 "x10/glb/Logger.x10"
            final double t$128296 = ((double)(long)(((long)(t$128295))));
            
            //#line 130 "x10/glb/Logger.x10"
            final double t$128297 = ((t$128296) / (((double)(1.0E9))));
            
            //#line 130 "x10/glb/Logger.x10"
            final java.lang.String t$128298 = (("") + ((x10.core.Double.$box(t$128297))));
            
            //#line 130 "x10/glb/Logger.x10"
            final java.lang.String t$128300 = x10.glb.Logger.sub(((java.lang.String)(t$128298)), (int)(0), (int)(6));
            
            //#line 125 "x10/glb/Logger.x10"
            final java.lang.String t$128301 = ((t$128299) + (t$128300));
            
            //#line 125 "x10/glb/Logger.x10"
            final java.lang.String t$128308 = ((t$128301) + (" : "));
            
            //#line 131 "x10/glb/Logger.x10"
            final long t$128302 = this.lastStartStopLiveTimeStamp;
            
            //#line 131 "x10/glb/Logger.x10"
            final long t$128303 = this.timeReference;
            
            //#line 131 "x10/glb/Logger.x10"
            final long t$128304 = ((t$128302) - (((long)(t$128303))));
            
            //#line 131 "x10/glb/Logger.x10"
            final double t$128305 = ((double)(long)(((long)(t$128304))));
            
            //#line 131 "x10/glb/Logger.x10"
            final double t$128306 = ((t$128305) / (((double)(1.0E9))));
            
            //#line 131 "x10/glb/Logger.x10"
            final java.lang.String t$128307 = (("") + ((x10.core.Double.$box(t$128306))));
            
            //#line 131 "x10/glb/Logger.x10"
            final java.lang.String t$128309 = x10.glb.Logger.sub(((java.lang.String)(t$128307)), (int)(0), (int)(6));
            
            //#line 125 "x10/glb/Logger.x10"
            final java.lang.String t$128310 = ((t$128308) + (t$128309));
            
            //#line 125 "x10/glb/Logger.x10"
            final java.lang.String t$128311 = ((t$128310) + (" :: "));
            
            //#line 132 "x10/glb/Logger.x10"
            final long t$128312 = this.nodesCount;
            
            //#line 125 "x10/glb/Logger.x10"
            final java.lang.String t$128313 = ((t$128311) + ((x10.core.Long.$box(t$128312))));
            
            //#line 125 "x10/glb/Logger.x10"
            final java.lang.String t$128314 = ((t$128313) + (" :: "));
            
            //#line 133 "x10/glb/Logger.x10"
            final long t$128315 = this.nodesGiven;
            
            //#line 125 "x10/glb/Logger.x10"
            final java.lang.String t$128316 = ((t$128314) + ((x10.core.Long.$box(t$128315))));
            
            //#line 125 "x10/glb/Logger.x10"
            final java.lang.String t$128317 = ((t$128316) + (" : "));
            
            //#line 134 "x10/glb/Logger.x10"
            final long t$128318 = this.nodesReceived;
            
            //#line 125 "x10/glb/Logger.x10"
            final java.lang.String t$128319 = ((t$128317) + ((x10.core.Long.$box(t$128318))));
            
            //#line 125 "x10/glb/Logger.x10"
            final java.lang.String t$128320 = ((t$128319) + (" : "));
            
            //#line 135 "x10/glb/Logger.x10"
            final long t$128321 = this.lifelineNodesReceived;
            
            //#line 125 "x10/glb/Logger.x10"
            final java.lang.String t$128322 = ((t$128320) + ((x10.core.Long.$box(t$128321))));
            
            //#line 125 "x10/glb/Logger.x10"
            final java.lang.String t$128323 = ((t$128322) + (" :: "));
            
            //#line 136 "x10/glb/Logger.x10"
            final long t$128324 = this.stealsReceived;
            
            //#line 125 "x10/glb/Logger.x10"
            final java.lang.String t$128325 = ((t$128323) + ((x10.core.Long.$box(t$128324))));
            
            //#line 125 "x10/glb/Logger.x10"
            final java.lang.String t$128326 = ((t$128325) + (" : "));
            
            //#line 137 "x10/glb/Logger.x10"
            final long t$128327 = this.lifelineStealsReceived;
            
            //#line 125 "x10/glb/Logger.x10"
            final java.lang.String t$128328 = ((t$128326) + ((x10.core.Long.$box(t$128327))));
            
            //#line 125 "x10/glb/Logger.x10"
            final java.lang.String t$128329 = ((t$128328) + (" :: "));
            
            //#line 138 "x10/glb/Logger.x10"
            final long t$128330 = this.stealsSuffered;
            
            //#line 125 "x10/glb/Logger.x10"
            final java.lang.String t$128331 = ((t$128329) + ((x10.core.Long.$box(t$128330))));
            
            //#line 125 "x10/glb/Logger.x10"
            final java.lang.String t$128332 = ((t$128331) + (" : "));
            
            //#line 139 "x10/glb/Logger.x10"
            final long t$128333 = this.lifelineStealsSuffered;
            
            //#line 125 "x10/glb/Logger.x10"
            final java.lang.String t$128334 = ((t$128332) + ((x10.core.Long.$box(t$128333))));
            
            //#line 125 "x10/glb/Logger.x10"
            final java.lang.String t$128335 = ((t$128334) + (" :: "));
            
            //#line 140 "x10/glb/Logger.x10"
            final long t$128336 = this.stealsAttempted;
            
            //#line 125 "x10/glb/Logger.x10"
            final java.lang.String t$128337 = ((t$128335) + ((x10.core.Long.$box(t$128336))));
            
            //#line 125 "x10/glb/Logger.x10"
            final java.lang.String t$128340 = ((t$128337) + (" : "));
            
            //#line 141 "x10/glb/Logger.x10"
            final long t$128338 = this.stealsAttempted;
            
            //#line 141 "x10/glb/Logger.x10"
            final long t$128339 = this.stealsPerpetrated;
            
            //#line 141 "x10/glb/Logger.x10"
            final long t$128341 = ((t$128338) - (((long)(t$128339))));
            
            //#line 125 "x10/glb/Logger.x10"
            final java.lang.String t$128342 = ((t$128340) + ((x10.core.Long.$box(t$128341))));
            
            //#line 125 "x10/glb/Logger.x10"
            final java.lang.String t$128343 = ((t$128342) + (" :: "));
            
            //#line 142 "x10/glb/Logger.x10"
            final long t$128344 = this.lifelineStealsAttempted;
            
            //#line 125 "x10/glb/Logger.x10"
            final java.lang.String t$128345 = ((t$128343) + ((x10.core.Long.$box(t$128344))));
            
            //#line 125 "x10/glb/Logger.x10"
            final java.lang.String t$128348 = ((t$128345) + (" : "));
            
            //#line 143 "x10/glb/Logger.x10"
            final long t$128346 = this.lifelineStealsAttempted;
            
            //#line 143 "x10/glb/Logger.x10"
            final long t$128347 = this.lifelineStealsPerpetrated;
            
            //#line 143 "x10/glb/Logger.x10"
            final long t$128349 = ((t$128346) - (((long)(t$128347))));
            
            //#line 125 "x10/glb/Logger.x10"
            final java.lang.String t$128351 = ((t$128348) + ((x10.core.Long.$box(t$128349))));
            
            //#line 125 "x10/glb/Logger.x10"
            t$128350.println(((java.lang.Object)(t$128351)));
        }
        
        //#line 145 "x10/glb/Logger.x10"
        return this;
    }
    
    
    //#line 18 "x10/glb/Logger.x10"
    final public x10.glb.Logger x10$glb$Logger$$this$x10$glb$Logger() {
        
        //#line 18 "x10/glb/Logger.x10"
        return x10.glb.Logger.this;
    }
    
    
    //#line 18 "x10/glb/Logger.x10"
    final public void __fieldInitializers_x10_glb_Logger() {
        
        //#line 18 "x10/glb/Logger.x10"
        this.nodesCount = 0L;
        
        //#line 18 "x10/glb/Logger.x10"
        this.nodesGiven = 0L;
        
        //#line 18 "x10/glb/Logger.x10"
        this.lifelineNodesReceived = 0L;
        
        //#line 18 "x10/glb/Logger.x10"
        this.stealsAttempted = 0L;
        
        //#line 18 "x10/glb/Logger.x10"
        this.stealsPerpetrated = 0L;
        
        //#line 18 "x10/glb/Logger.x10"
        this.stealsReceived = 0L;
        
        //#line 18 "x10/glb/Logger.x10"
        this.stealsSuffered = 0L;
        
        //#line 18 "x10/glb/Logger.x10"
        this.nodesReceived = 0L;
        
        //#line 18 "x10/glb/Logger.x10"
        this.lifelineStealsAttempted = 0L;
        
        //#line 18 "x10/glb/Logger.x10"
        this.lifelineStealsPerpetrated = 0L;
        
        //#line 18 "x10/glb/Logger.x10"
        this.lifelineStealsReceived = 0L;
        
        //#line 18 "x10/glb/Logger.x10"
        this.lifelineStealsSuffered = 0L;
        
        //#line 18 "x10/glb/Logger.x10"
        this.lastStartStopLiveTimeStamp = -1L;
        
        //#line 18 "x10/glb/Logger.x10"
        this.timeAlive = 0L;
        
        //#line 18 "x10/glb/Logger.x10"
        this.timeDead = 0L;
        
        //#line 18 "x10/glb/Logger.x10"
        this.startTime = 0L;
    }
}

