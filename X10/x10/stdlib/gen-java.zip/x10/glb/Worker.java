package x10.glb;


/**
 * The local runner for the GLB framework. An instance of this class runs at each
 * place and provides the context within which user-specified tasks execute and
 * are load balanced across all places.
 * @param <Queue> Concrete TaskQueue type
 * @param <R> Result type.
 */
@x10.runtime.impl.java.X10Generated
final public class Worker<$Queue, $R> extends x10.core.Ref implements x10.serialization.X10JavaSerializable
{
    public static final x10.rtt.RuntimeType<Worker> $RTT = 
        x10.rtt.NamedType.<Worker> make("x10.glb.Worker",
                                        Worker.class,
                                        2);
    
    public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
    
    public x10.rtt.Type<?> $getParam(int i) { if (i == 0) return $Queue; if (i == 1) return $R; return null; }
    
    private Object writeReplace() throws java.io.ObjectStreamException {
        return new x10.serialization.SerializationProxy(this);
    }
    
    public static <$Queue, $R> x10.serialization.X10JavaSerializable $_deserialize_body(x10.glb.Worker<$Queue, $R> $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
        $_obj.$Queue = (x10.rtt.Type) $deserializer.readObject();
        $_obj.$R = (x10.rtt.Type) $deserializer.readObject();
        $_obj.P = $deserializer.readLong();
        $_obj.context = $deserializer.readObject();
        $_obj.lifelineThieves = $deserializer.readObject();
        $_obj.lifelines = $deserializer.readObject();
        $_obj.lifelinesActivated = $deserializer.readObject();
        $_obj.logger = $deserializer.readObject();
        $_obj.m = $deserializer.readInt();
        $_obj.n = $deserializer.readInt();
        $_obj.queue = $deserializer.readObject();
        $_obj.random = $deserializer.readObject();
        $_obj.thieves = $deserializer.readObject();
        $_obj.victims = $deserializer.readObject();
        $_obj.w = $deserializer.readInt();
        return $_obj;
    }
    
    public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
        x10.glb.Worker $_obj = new x10.glb.Worker((java.lang.System[]) null, (x10.rtt.Type) null, (x10.rtt.Type) null);
        $deserializer.record_reference($_obj);
        return $_deserialize_body($_obj, $deserializer);
    }
    
    public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
        $serializer.write(this.$Queue);
        $serializer.write(this.$R);
        $serializer.write(this.P);
        $serializer.write(this.context);
        $serializer.write(this.lifelineThieves);
        $serializer.write(this.lifelines);
        $serializer.write(this.lifelinesActivated);
        $serializer.write(this.logger);
        $serializer.write(this.m);
        $serializer.write(this.n);
        $serializer.write(this.queue);
        $serializer.write(this.random);
        $serializer.write(this.thieves);
        $serializer.write(this.victims);
        $serializer.write(this.w);
        
    }
    
    // constructor just for allocation
    public Worker(final java.lang.System[] $dummy, final x10.rtt.Type $Queue, final x10.rtt.Type $R) {
        x10.glb.Worker.$initParams(this, $Queue, $R);
        
    }
    
    private x10.rtt.Type $Queue;
    private x10.rtt.Type $R;
    
    // initializer of type parameters
    public static void $initParams(final Worker $this, final x10.rtt.Type $Queue, final x10.rtt.Type $R) {
        $this.$Queue = $Queue;
        $this.$R = $R;
        
    }
    // synthetic type for parameter mangling
    public static final class __0$1x10$glb$Worker$$Queue$2 {}
    

    
    //#line 29 "x10/glb/Worker.x10"
    /** TaskQueue, responsible for crunching numbers */
    public $Queue queue;
    
    //#line 32 "x10/glb/Worker.x10"
    /** Read as I am the "lifeline buddy" of my "lifelineThieves" */
    public x10.glb.FixedSizeStack<x10.core.Long> lifelineThieves;
    
    //#line 36 "x10/glb/Worker.x10"
    /** Thieves that send stealing requests*/
    public x10.glb.FixedSizeStack<x10.core.Long> thieves;
    
    //#line 39 "x10/glb/Worker.x10"
    /** Lifeline buddies */
    public x10.core.Rail<x10.core.Long> lifelines;
    
    //#line 45 "x10/glb/Worker.x10"
    /** The data structure to keep a key invariant: 
     * At any time, at most one message has been sent on an
     * outgoing lifeline (and hence at most one message has
     * been received on an incoming lifeline).*/
    public x10.core.Rail<x10.core.Boolean> lifelinesActivated;
    
    //#line 50 "x10/glb/Worker.x10"
    /** The granularity of tasks to run in a batch before starts to probe network to respond to work-stealing 
     * requests. The smaller n is, the more responsive to the work-stealing requests; on the other hand, less focused
     * on computation */
    public int n;
    
    //#line 53 "x10/glb/Worker.x10"
    /** Number of random victims to probe before sending requests to lifeline buddy*/
    public int w;
    
    //#line 56 "x10/glb/Worker.x10"
    /** Maximum number of random victims */
    public int m;
    
    //#line 60 "x10/glb/Worker.x10"
    /** Random number, used when picking a non-lifeline victim/buddy. Important to seed with place id, otherwise
      BG/Q, the random sequence will be exactly same at different places*/
    public x10.util.Random random;
    
    //#line 64 "x10/glb/Worker.x10"
    /** Random buddies, a runner first probes its random buddy, only when none of the random buddies responds
     *  it starts to probe its lifeline buddies */
    public x10.core.Rail<x10.core.Long> victims;
    
    //#line 67 "x10/glb/Worker.x10"
    /** Logger to record the work-stealing status */
    public x10.glb.Logger logger;
    
    //#line 70 "x10/glb/Worker.x10"
    /** Variables used for synchronization, made sure not to be optimized out by the compiler */
    volatile public transient boolean active;
    
    //#line 71 "x10/glb/Worker.x10"
    volatile public transient boolean empty;
    
    //#line 72 "x10/glb/Worker.x10"
    volatile public transient boolean waiting;
    
    //#line 75 "x10/glb/Worker.x10"
    public long P;
    
    //#line 78 "x10/glb/Worker.x10"
    public x10.glb.Context<$Queue, $R> context;
    
    
    //#line 90 "x10/glb/Worker.x10"
    /**
     * Class constructor
     * @param init function closure to init the local {@link TaskQueue}
     * @param n same to this.n
     * @param w same to this.w
     * @param m same to this.m
     * @param l power of lifeline graph
     * @param z base of lifeline graph
     * @param tree true if the workload is dynamically generated, false if the workload can be statically generated
     */
    // creation method for java code (1-phase java constructor)
    public Worker(final x10.rtt.Type $Queue, final x10.rtt.Type $R, final x10.core.fun.Fun_0_0<$Queue> init, final int n, final int w, final int l, final int z, final int m, final boolean tree, __0$1x10$glb$Worker$$Queue$2 $dummy) {
        this((java.lang.System[]) null, $Queue, $R);
        x10$glb$Worker$$init$S(init, n, w, l, z, m, tree, (x10.glb.Worker.__0$1x10$glb$Worker$$Queue$2) null);
    }
    
    // constructor for non-virtual call
    final public x10.glb.Worker<$Queue, $R> x10$glb$Worker$$init$S(final x10.core.fun.Fun_0_0<$Queue> init, final int n, final int w, final int l, final int z, final int m, final boolean tree, __0$1x10$glb$Worker$$Queue$2 $dummy) {
         {
            
            //#line 90 "x10/glb/Worker.x10"
            
            
            //#line 27 "x10/glb/Worker.x10"
            this.__fieldInitializers_x10_glb_Worker();
            
            //#line 91 "x10/glb/Worker.x10"
            ((x10.glb.Worker<$Queue, $R>)this).n = n;
            
            //#line 92 "x10/glb/Worker.x10"
            ((x10.glb.Worker<$Queue, $R>)this).w = w;
            
            //#line 93 "x10/glb/Worker.x10"
            ((x10.glb.Worker<$Queue, $R>)this).m = m;
            
            //#line 94 "x10/glb/Worker.x10"
            final long t$128549 = ((long)(((int)(z))));
            
            //#line 94 "x10/glb/Worker.x10"
            final x10.core.Rail t$128550 = ((x10.core.Rail)(new x10.core.Rail<x10.core.Long>(x10.rtt.Types.LONG, t$128549, (x10.core.Long.$box(-1L)), (x10.core.Rail.__1x10$lang$Rail$$T) null)));
            
            //#line 94 "x10/glb/Worker.x10"
            ((x10.glb.Worker<$Queue, $R>)this).lifelines = ((x10.core.Rail)(t$128550));
            
            //#line 96 "x10/glb/Worker.x10"
            final long h = ((long)x10.x10rt.X10RT.hereId());
            
            //#line 98 "x10/glb/Worker.x10"
            final long t$128551 = ((long)(((int)(m))));
            
            //#line 98 "x10/glb/Worker.x10"
            final x10.core.Rail t$128552 = ((x10.core.Rail)(new x10.core.Rail<x10.core.Long>(x10.rtt.Types.LONG, t$128551)));
            
            //#line 98 "x10/glb/Worker.x10"
            ((x10.glb.Worker<$Queue, $R>)this).victims = ((x10.core.Rail)(t$128552));
            
            //#line 99 "x10/glb/Worker.x10"
            final long t$128553 = this.P;
            
            //#line 99 "x10/glb/Worker.x10"
            final boolean t$128567 = ((t$128553) > (((long)(1L))));
            
            //#line 99 "x10/glb/Worker.x10"
            if (t$128567) {
                
                //#line 99 "x10/glb/Worker.x10"
                long i = 0L;
                
                //#line 99 "x10/glb/Worker.x10"
                for (;
                     true;
                     ) {
                    
                    //#line 99 "x10/glb/Worker.x10"
                    final long t$128556 = ((long)(((int)(m))));
                    
                    //#line 99 "x10/glb/Worker.x10"
                    final boolean t$128566 = ((i) < (((long)(t$128556))));
                    
                    //#line 99 "x10/glb/Worker.x10"
                    if (!(t$128566)) {
                        
                        //#line 99 "x10/glb/Worker.x10"
                        break;
                    }
                    
                    //#line 100 "x10/glb/Worker.x10"
                    while (true) {
                        
                        //#line 100 "x10/glb/Worker.x10"
                        final x10.core.Rail t$129019 = ((x10.core.Rail)(this.victims));
                        
                        //#line 100 "x10/glb/Worker.x10"
                        final x10.util.Random t$129021 = ((x10.util.Random)(this.random));
                        
                        //#line 100 "x10/glb/Worker.x10"
                        final long t$129022 = this.P;
                        
                        //#line 100 "x10/glb/Worker.x10"
                        final long t$129023 = t$129021.nextLong$O((long)(t$129022));
                        
                        //#line 100 "x10/glb/Worker.x10"
                        final long t$129024 = x10.core.Long.$unbox(((long[])t$129019.value)[(int)i] = t$129023);
                        
                        //#line 100 "x10/glb/Worker.x10"
                        final boolean t$129025 = ((long) t$129024) == ((long) h);
                        
                        //#line 100 "x10/glb/Worker.x10"
                        if (!(t$129025)) {
                            
                            //#line 100 "x10/glb/Worker.x10"
                            break;
                        }
                    }
                    
                    //#line 99 "x10/glb/Worker.x10"
                    final long t$129027 = ((i) + (((long)(1L))));
                    
                    //#line 99 "x10/glb/Worker.x10"
                    i = t$129027;
                }
            }
            
            //#line 104 "x10/glb/Worker.x10"
            long x = 1L;
            
            //#line 105 "x10/glb/Worker.x10"
            long t = 0L;
            
            //#line 106 "x10/glb/Worker.x10"
            long j$129082 = 0L;
            
            //#line 106 "x10/glb/Worker.x10"
            for (;
                 true;
                 ) {
                
                //#line 106 "x10/glb/Worker.x10"
                final long t$129084 = ((long)(((int)(z))));
                
                //#line 106 "x10/glb/Worker.x10"
                final boolean t$129085 = ((j$129082) < (((long)(t$129084))));
                
                //#line 106 "x10/glb/Worker.x10"
                if (!(t$129085)) {
                    
                    //#line 106 "x10/glb/Worker.x10"
                    break;
                }
                
                //#line 107 "x10/glb/Worker.x10"
                long v$129061 = h;
                
                //#line 108 "x10/glb/Worker.x10"
                long k$129057 = 1L;
                
                //#line 108 "x10/glb/Worker.x10"
                for (;
                     true;
                     ) {
                    
                    //#line 108 "x10/glb/Worker.x10"
                    final long t$129059 = ((long)(((int)(l))));
                    
                    //#line 108 "x10/glb/Worker.x10"
                    final boolean t$129060 = ((k$129057) < (((long)(t$129059))));
                    
                    //#line 108 "x10/glb/Worker.x10"
                    if (!(t$129060)) {
                        
                        //#line 108 "x10/glb/Worker.x10"
                        break;
                    }
                    
                    //#line 109 "x10/glb/Worker.x10"
                    final long t$129031 = ((long)(((int)(l))));
                    
                    //#line 109 "x10/glb/Worker.x10"
                    final long t$129032 = ((x) * (((long)(t$129031))));
                    
                    //#line 109 "x10/glb/Worker.x10"
                    final long t$129033 = ((v$129061) % (((long)(t$129032))));
                    
                    //#line 109 "x10/glb/Worker.x10"
                    final long t$129034 = ((v$129061) - (((long)(t$129033))));
                    
                    //#line 109 "x10/glb/Worker.x10"
                    final long t$129037 = ((long)(((int)(l))));
                    
                    //#line 109 "x10/glb/Worker.x10"
                    final long t$129038 = ((x) * (((long)(t$129037))));
                    
                    //#line 109 "x10/glb/Worker.x10"
                    final long t$129039 = ((v$129061) + (((long)(t$129038))));
                    
                    //#line 109 "x10/glb/Worker.x10"
                    final long t$129041 = ((t$129039) - (((long)(x))));
                    
                    //#line 109 "x10/glb/Worker.x10"
                    final long t$129043 = ((long)(((int)(l))));
                    
                    //#line 109 "x10/glb/Worker.x10"
                    final long t$129044 = ((x) * (((long)(t$129043))));
                    
                    //#line 109 "x10/glb/Worker.x10"
                    final long t$129045 = ((t$129041) % (((long)(t$129044))));
                    
                    //#line 109 "x10/glb/Worker.x10"
                    final long t$129046 = ((t$129034) + (((long)(t$129045))));
                    
                    //#line 109 "x10/glb/Worker.x10"
                    v$129061 = t$129046;
                    
                    //#line 110 "x10/glb/Worker.x10"
                    final long t$129048 = this.P;
                    
                    //#line 110 "x10/glb/Worker.x10"
                    final boolean t$129049 = ((v$129061) < (((long)(t$129048))));
                    
                    //#line 110 "x10/glb/Worker.x10"
                    if (t$129049) {
                        
                        //#line 111 "x10/glb/Worker.x10"
                        final x10.core.Rail t$129050 = ((x10.core.Rail)(this.lifelines));
                        
                        //#line 111 "x10/glb/Worker.x10"
                        final long pre$129051 = t;
                        
                        //#line 111 "x10/glb/Worker.x10"
                        final long t$129053 = ((t) + (((long)(1L))));
                        
                        //#line 111 "x10/glb/Worker.x10"
                        t = t$129053;
                        
                        //#line 111 "x10/glb/Worker.x10"
                        ((long[])t$129050.value)[(int)pre$129051] = v$129061;
                        
                        //#line 112 "x10/glb/Worker.x10"
                        break;
                    }
                    
                    //#line 108 "x10/glb/Worker.x10"
                    final long t$129056 = ((k$129057) + (((long)(1L))));
                    
                    //#line 108 "x10/glb/Worker.x10"
                    k$129057 = t$129056;
                }
                
                //#line 115 "x10/glb/Worker.x10"
                final long t$129063 = ((long)(((int)(l))));
                
                //#line 115 "x10/glb/Worker.x10"
                final long t$129064 = ((x) * (((long)(t$129063))));
                
                //#line 115 "x10/glb/Worker.x10"
                x = t$129064;
                
                //#line 106 "x10/glb/Worker.x10"
                final long t$129066 = ((j$129082) + (((long)(1L))));
                
                //#line 106 "x10/glb/Worker.x10"
                j$129082 = t$129066;
            }
            
            //#line 118 "x10/glb/Worker.x10"
            final $Queue t$128609 = (($Queue)(((x10.core.fun.Fun_0_0<$Queue>)init).$apply$G()));
            
            //#line 118 "x10/glb/Worker.x10"
            ((x10.glb.Worker<$Queue, $R>)this).queue = (($Queue)(t$128609));
            
            //#line 119 "x10/glb/Worker.x10"
            final x10.glb.FixedSizeStack alloc$119062 = ((x10.glb.FixedSizeStack)(new x10.glb.FixedSizeStack<x10.core.Long>((java.lang.System[]) null, x10.rtt.Types.LONG)));
            
            //#line 119 "x10/glb/Worker.x10"
            final x10.core.Rail t$129086 = ((x10.core.Rail)(this.lifelines));
            
            //#line 119 "x10/glb/Worker.x10"
            final long t$129087 = ((x10.core.Rail<x10.core.Long>)t$129086).size;
            
            //#line 119 "x10/glb/Worker.x10"
            final long t$129088 = ((t$129087) + (((long)(3L))));
            
            //#line 119 "x10/glb/Worker.x10"
            alloc$119062.x10$glb$FixedSizeStack$$init$S(t$129088);
            
            //#line 119 "x10/glb/Worker.x10"
            ((x10.glb.Worker<$Queue, $R>)this).lifelineThieves = ((x10.glb.FixedSizeStack)(alloc$119062));
            
            //#line 120 "x10/glb/Worker.x10"
            final x10.glb.FixedSizeStack alloc$119063 = ((x10.glb.FixedSizeStack)(new x10.glb.FixedSizeStack<x10.core.Long>((java.lang.System[]) null, x10.rtt.Types.LONG)));
            
            //#line 120 "x10/glb/Worker.x10"
            final long t$129089 = this.P;
            
            //#line 120 "x10/glb/Worker.x10"
            alloc$119063.x10$glb$FixedSizeStack$$init$S(((long)(t$129089)));
            
            //#line 120 "x10/glb/Worker.x10"
            ((x10.glb.Worker<$Queue, $R>)this).thieves = ((x10.glb.FixedSizeStack)(alloc$119063));
            
            //#line 121 "x10/glb/Worker.x10"
            final long t$128614 = this.P;
            
            //#line 121 "x10/glb/Worker.x10"
            final x10.core.Rail t$128615 = ((x10.core.Rail)(new x10.core.Rail<x10.core.Boolean>(x10.rtt.Types.BOOLEAN, ((long)(t$128614)))));
            
            //#line 121 "x10/glb/Worker.x10"
            ((x10.glb.Worker<$Queue, $R>)this).lifelinesActivated = ((x10.core.Rail)(t$128615));
            
            //#line 123 "x10/glb/Worker.x10"
            if (tree) {
                
                //#line 125 "x10/glb/Worker.x10"
                final long t$128616 = ((3L) * (((long)(h))));
                
                //#line 125 "x10/glb/Worker.x10"
                final long t$128617 = ((t$128616) + (((long)(1L))));
                
                //#line 125 "x10/glb/Worker.x10"
                final long t$128618 = this.P;
                
                //#line 125 "x10/glb/Worker.x10"
                final boolean t$128625 = ((t$128617) < (((long)(t$128618))));
                
                //#line 125 "x10/glb/Worker.x10"
                if (t$128625) {
                    
                    //#line 125 "x10/glb/Worker.x10"
                    final x10.glb.FixedSizeStack this$128361 = ((x10.glb.FixedSizeStack)(this.lifelineThieves));
                    
                    //#line 125 "x10/glb/Worker.x10"
                    final long t$128619 = ((3L) * (((long)(h))));
                    
                    //#line 125 "x10/glb/Worker.x10"
                    final long t$128360 = ((t$128619) + (((long)(1L))));
                    
                    //#line 49 . "x10/glb/FixedSizeStack.x10"
                    final x10.core.Rail t$129067 = ((x10.core.Rail)(((x10.glb.FixedSizeStack<x10.core.Long>)this$128361).data));
                    
                    //#line 49 . "x10/glb/FixedSizeStack.x10"
                    final long t$129068 = ((x10.glb.FixedSizeStack<x10.core.Long>)this$128361).size;
                    
                    //#line 49 . "x10/glb/FixedSizeStack.x10"
                    final long t$129069 = ((t$129068) + (((long)(1L))));
                    
                    //#line 49 . "x10/glb/FixedSizeStack.x10"
                    final long t$129070 = ((x10.glb.FixedSizeStack<x10.core.Long>)this$128361).size = t$129069;
                    
                    //#line 49 . "x10/glb/FixedSizeStack.x10"
                    final long t$129071 = ((t$129070) - (((long)(1L))));
                    
                    //#line 49 . "x10/glb/FixedSizeStack.x10"
                    ((long[])t$129067.value)[(int)t$129071] = t$128360;
                }
                
                //#line 126 "x10/glb/Worker.x10"
                final long t$128626 = ((3L) * (((long)(h))));
                
                //#line 126 "x10/glb/Worker.x10"
                final long t$128627 = ((t$128626) + (((long)(2L))));
                
                //#line 126 "x10/glb/Worker.x10"
                final long t$128628 = this.P;
                
                //#line 126 "x10/glb/Worker.x10"
                final boolean t$128635 = ((t$128627) < (((long)(t$128628))));
                
                //#line 126 "x10/glb/Worker.x10"
                if (t$128635) {
                    
                    //#line 126 "x10/glb/Worker.x10"
                    final x10.glb.FixedSizeStack this$128364 = ((x10.glb.FixedSizeStack)(this.lifelineThieves));
                    
                    //#line 126 "x10/glb/Worker.x10"
                    final long t$128629 = ((3L) * (((long)(h))));
                    
                    //#line 126 "x10/glb/Worker.x10"
                    final long t$128363 = ((t$128629) + (((long)(2L))));
                    
                    //#line 49 . "x10/glb/FixedSizeStack.x10"
                    final x10.core.Rail t$129072 = ((x10.core.Rail)(((x10.glb.FixedSizeStack<x10.core.Long>)this$128364).data));
                    
                    //#line 49 . "x10/glb/FixedSizeStack.x10"
                    final long t$129073 = ((x10.glb.FixedSizeStack<x10.core.Long>)this$128364).size;
                    
                    //#line 49 . "x10/glb/FixedSizeStack.x10"
                    final long t$129074 = ((t$129073) + (((long)(1L))));
                    
                    //#line 49 . "x10/glb/FixedSizeStack.x10"
                    final long t$129075 = ((x10.glb.FixedSizeStack<x10.core.Long>)this$128364).size = t$129074;
                    
                    //#line 49 . "x10/glb/FixedSizeStack.x10"
                    final long t$129076 = ((t$129075) - (((long)(1L))));
                    
                    //#line 49 . "x10/glb/FixedSizeStack.x10"
                    ((long[])t$129072.value)[(int)t$129076] = t$128363;
                }
                
                //#line 127 "x10/glb/Worker.x10"
                final long t$128636 = ((3L) * (((long)(h))));
                
                //#line 127 "x10/glb/Worker.x10"
                final long t$128637 = ((t$128636) + (((long)(3L))));
                
                //#line 127 "x10/glb/Worker.x10"
                final long t$128638 = this.P;
                
                //#line 127 "x10/glb/Worker.x10"
                final boolean t$128645 = ((t$128637) < (((long)(t$128638))));
                
                //#line 127 "x10/glb/Worker.x10"
                if (t$128645) {
                    
                    //#line 127 "x10/glb/Worker.x10"
                    final x10.glb.FixedSizeStack this$128367 = ((x10.glb.FixedSizeStack)(this.lifelineThieves));
                    
                    //#line 127 "x10/glb/Worker.x10"
                    final long t$128639 = ((3L) * (((long)(h))));
                    
                    //#line 127 "x10/glb/Worker.x10"
                    final long t$128366 = ((t$128639) + (((long)(3L))));
                    
                    //#line 49 . "x10/glb/FixedSizeStack.x10"
                    final x10.core.Rail t$129077 = ((x10.core.Rail)(((x10.glb.FixedSizeStack<x10.core.Long>)this$128367).data));
                    
                    //#line 49 . "x10/glb/FixedSizeStack.x10"
                    final long t$129078 = ((x10.glb.FixedSizeStack<x10.core.Long>)this$128367).size;
                    
                    //#line 49 . "x10/glb/FixedSizeStack.x10"
                    final long t$129079 = ((t$129078) + (((long)(1L))));
                    
                    //#line 49 . "x10/glb/FixedSizeStack.x10"
                    final long t$129080 = ((x10.glb.FixedSizeStack<x10.core.Long>)this$128367).size = t$129079;
                    
                    //#line 49 . "x10/glb/FixedSizeStack.x10"
                    final long t$129081 = ((t$129080) - (((long)(1L))));
                    
                    //#line 49 . "x10/glb/FixedSizeStack.x10"
                    ((long[])t$129077.value)[(int)t$129081] = t$128366;
                }
                
                //#line 128 "x10/glb/Worker.x10"
                final boolean t$128649 = ((h) > (((long)(0L))));
                
                //#line 128 "x10/glb/Worker.x10"
                if (t$128649) {
                    
                    //#line 128 "x10/glb/Worker.x10"
                    final x10.core.Rail t$128647 = ((x10.core.Rail)(this.lifelinesActivated));
                    
                    //#line 128 "x10/glb/Worker.x10"
                    final long t$128646 = ((h) - (((long)(1L))));
                    
                    //#line 128 "x10/glb/Worker.x10"
                    final long t$128648 = ((t$128646) / (((long)(3L))));
                    
                    //#line 128 "x10/glb/Worker.x10"
                    ((boolean[])t$128647.value)[(int)t$128648] = true;
                }
            }
            
            //#line 131 "x10/glb/Worker.x10"
            final x10.glb.Logger alloc$119064 = ((x10.glb.Logger)(new x10.glb.Logger((java.lang.System[]) null)));
            
            //#line 131 "x10/glb/Worker.x10"
            alloc$119064.x10$glb$Logger$$init$S(((boolean)(true)));
            
            //#line 131 "x10/glb/Worker.x10"
            ((x10.glb.Worker<$Queue, $R>)this).logger = ((x10.glb.Logger)(alloc$119064));
        }
        return this;
    }
    
    
    
    //#line 142 "x10/glb/Worker.x10"
    /**
     * Main process function of Worker. It does 4 things:
     * (1) execute at most n tasks 
     * (2) respond to stealing requests
     * (3) when not worth sharing tasks, reject the stealing requests 
     * (4) when running out of tasks, steal from others
     * @param st the place local handle of Worker
     */
    final public void processStack__0$1x10$glb$Worker$1x10$glb$Worker$$Queue$3x10$glb$Worker$$R$2$2(final x10.lang.PlaceLocalHandle st) {
        
        //#line 143 "x10/glb/Worker.x10"
        boolean t$128722 = false;
        
        //#line 143 "x10/glb/Worker.x10"
        do  {
            
            //#line 144 "x10/glb/Worker.x10"
            while (true) {
                
                //#line 144 "x10/glb/Worker.x10"
                final $Queue t$129193 = (($Queue)(this.queue));
                
                //#line 144 "x10/glb/Worker.x10"
                final int t$129194 = this.n;
                
                //#line 144 "x10/glb/Worker.x10"
                final long t$129195 = ((long)(((int)(t$129194))));
                
                //#line 144 "x10/glb/Worker.x10"
                final x10.glb.Context t$129196 = ((x10.glb.Context)(this.context));
                
                //#line 144 "x10/glb/Worker.x10"
                final boolean t$129197 = x10.core.Boolean.$unbox(((x10.glb.TaskQueue<$Queue, $R>)x10.rtt.Types.conversion(x10.rtt.ParameterizedType.make(x10.glb.TaskQueue.$RTT, $Queue, $R),t$129193)).process$Z((long)(t$129195), ((x10.glb.Context)(t$129196)), x10.rtt.ParameterizedType.make(x10.glb.Context.$RTT, $Queue, $R)));
                
                //#line 144 "x10/glb/Worker.x10"
                if (!(t$129197)) {
                    
                    //#line 144 "x10/glb/Worker.x10"
                    break;
                }
                
                //#line 145 "x10/glb/Worker.x10"
                x10.xrx.Runtime.probe();
                
                //#line 146 "x10/glb/Worker.x10"
                final x10.glb.Worker this$129166 = ((x10.glb.Worker)(this));
                
                //#line 146 "x10/glb/Worker.x10"
                final x10.lang.PlaceLocalHandle st$129167 = ((x10.lang.PlaceLocalHandle)(st));
                
                //#line 186 . "x10/glb/Worker.x10"
                x10.glb.TaskBag loot$129152 =  null;
                
                //#line 187 . "x10/glb/Worker.x10"
                while (true) {
                    
                    //#line 187 . "x10/glb/Worker.x10"
                    final x10.glb.FixedSizeStack this$129153 = ((x10.glb.FixedSizeStack)(((x10.glb.Worker<$Queue, $R>)this$129166).thieves));
                    
                    //#line 55 .. "x10/glb/FixedSizeStack.x10"
                    final long t$129154 = ((x10.glb.FixedSizeStack<x10.core.Long>)this$129153).size;
                    
                    //#line 187 . "x10/glb/Worker.x10"
                    boolean t$129155 = ((t$129154) > (((long)(0L))));
                    
                    //#line 187 . "x10/glb/Worker.x10"
                    if (!(t$129155)) {
                        
                        //#line 187 . "x10/glb/Worker.x10"
                        final x10.glb.FixedSizeStack this$129156 = ((x10.glb.FixedSizeStack)(((x10.glb.Worker<$Queue, $R>)this$129166).lifelineThieves));
                        
                        //#line 55 .. "x10/glb/FixedSizeStack.x10"
                        final long t$129157 = ((x10.glb.FixedSizeStack<x10.core.Long>)this$129156).size;
                        
                        //#line 187 . "x10/glb/Worker.x10"
                        t$129155 = ((t$129157) > (((long)(0L))));
                    }
                    
                    //#line 187 . "x10/glb/Worker.x10"
                    boolean t$129158 = t$129155;
                    
                    //#line 187 . "x10/glb/Worker.x10"
                    if (t$129155) {
                        
                        //#line 187 . "x10/glb/Worker.x10"
                        final $Queue t$129159 = (($Queue)(((x10.glb.Worker<$Queue, $R>)this$129166).queue));
                        
                        //#line 187 . "x10/glb/Worker.x10"
                        final x10.glb.TaskBag t$129160 = ((x10.glb.TaskQueue<$Queue, $R>)x10.rtt.Types.conversion(x10.rtt.ParameterizedType.make(x10.glb.TaskQueue.$RTT, $Queue, $R),t$129159)).split();
                        
                        //#line 187 . "x10/glb/Worker.x10"
                        final x10.glb.TaskBag t$129161 = loot$129152 = ((x10.glb.TaskBag)(t$129160));
                        
                        //#line 187 . "x10/glb/Worker.x10"
                        t$129158 = ((t$129161) != (null));
                    }
                    
                    //#line 187 . "x10/glb/Worker.x10"
                    if (!(t$129158)) {
                        
                        //#line 187 . "x10/glb/Worker.x10"
                        break;
                    }
                    
                    //#line 188 . "x10/glb/Worker.x10"
                    final x10.lang.PlaceLocalHandle st$129130 = ((x10.lang.PlaceLocalHandle)(st$129167));
                    
                    //#line 188 . "x10/glb/Worker.x10"
                    final x10.glb.TaskBag loot$129131 = ((x10.glb.TaskBag)(loot$129152));
                    
                    //#line 162 .. "x10/glb/Worker.x10"
                    final long victim$129092 = ((long)x10.x10rt.X10RT.hereId());
                    
                    //#line 163 .. "x10/glb/Worker.x10"
                    final x10.glb.Logger obj$129093 = ((x10.glb.Logger)(((x10.glb.Worker<$Queue, $R>)this$129166).logger));
                    
                    //#line 163 .. "x10/glb/Worker.x10"
                    final long t$129094 = obj$129093.nodesGiven;
                    
                    //#line 163 .. "x10/glb/Worker.x10"
                    final long t$129095 = loot$129152.size$O();
                    
                    //#line 163 .. "x10/glb/Worker.x10"
                    final long t$129096 = ((t$129094) + (((long)(t$129095))));
                    
                    //#line 163 .. "x10/glb/Worker.x10"
                    obj$129093.nodesGiven = t$129096;
                    
                    //#line 164 .. "x10/glb/Worker.x10"
                    final x10.glb.FixedSizeStack this$129097 = ((x10.glb.FixedSizeStack)(((x10.glb.Worker<$Queue, $R>)this$129166).thieves));
                    
                    //#line 55 ... "x10/glb/FixedSizeStack.x10"
                    final long t$129098 = ((x10.glb.FixedSizeStack<x10.core.Long>)this$129097).size;
                    
                    //#line 164 .. "x10/glb/Worker.x10"
                    final boolean t$129099 = ((t$129098) > (((long)(0L))));
                    
                    //#line 164 .. "x10/glb/Worker.x10"
                    if (t$129099) {
                        
                        //#line 165 .. "x10/glb/Worker.x10"
                        final x10.glb.FixedSizeStack this$129100 = ((x10.glb.FixedSizeStack)(((x10.glb.Worker<$Queue, $R>)this$129166).thieves));
                        
                        //#line 44 ... "x10/glb/FixedSizeStack.x10"
                        final x10.core.Rail t$129101 = ((x10.core.Rail)(((x10.glb.FixedSizeStack<x10.core.Long>)this$129100).data));
                        
                        //#line 44 ... "x10/glb/FixedSizeStack.x10"
                        final long t$129102 = ((x10.glb.FixedSizeStack<x10.core.Long>)this$129100).size;
                        
                        //#line 44 ... "x10/glb/FixedSizeStack.x10"
                        final long t$129103 = ((t$129102) - (((long)(1L))));
                        
                        //#line 44 ... "x10/glb/FixedSizeStack.x10"
                        final long t$129104 = ((x10.glb.FixedSizeStack<x10.core.Long>)this$129100).size = t$129103;
                        
                        //#line 165 .. "x10/glb/Worker.x10"
                        final long thief$129105 = ((long[])t$129101.value)[(int)t$129104];
                        
                        //#line 166 .. "x10/glb/Worker.x10"
                        final boolean t$129106 = ((thief$129105) >= (((long)(0L))));
                        
                        //#line 166 .. "x10/glb/Worker.x10"
                        if (t$129106) {
                            
                            //#line 167 .. "x10/glb/Worker.x10"
                            final x10.glb.Logger obj$129107 = ((x10.glb.Logger)(((x10.glb.Worker<$Queue, $R>)this$129166).logger));
                            
                            //#line 167 .. "x10/glb/Worker.x10"
                            final long t$129108 = obj$129107.lifelineStealsSuffered;
                            
                            //#line 167 .. "x10/glb/Worker.x10"
                            final long t$129109 = ((t$129108) + (((long)(1L))));
                            
                            //#line 167 .. "x10/glb/Worker.x10"
                            obj$129107.lifelineStealsSuffered = t$129109;
                            
                            //#line 168 .. "x10/glb/Worker.x10"
                            final x10.lang.Place alloc$129110 = ((x10.lang.Place)(new x10.lang.Place((java.lang.System[]) null)));
                            
                            //#line 168 .. "x10/glb/Worker.x10"
                            alloc$129110.x10$lang$Place$$init$S(((long)(thief$129105)));
                            
                            //#line 168 .. "x10/glb/Worker.x10"
                            x10.xrx.Runtime.runUncountedAsync(((x10.lang.Place)(alloc$129110)), ((x10.core.fun.VoidFun_0_0)(new x10.glb.Worker.$Closure$70<$Queue, $R>($Queue, $R, st$129130, loot$129131, victim$129092, (x10.glb.Worker.$Closure$70.__0$1x10$glb$Worker$1x10$glb$Worker$$Closure$70$$Queue$3x10$glb$Worker$$Closure$70$$R$2$2) null))), ((x10.xrx.Runtime.Profile)(null)));
                        } else {
                            
                            //#line 170 .. "x10/glb/Worker.x10"
                            final x10.glb.Logger obj$129113 = ((x10.glb.Logger)(((x10.glb.Worker<$Queue, $R>)this$129166).logger));
                            
                            //#line 170 .. "x10/glb/Worker.x10"
                            final long t$129114 = obj$129113.stealsSuffered;
                            
                            //#line 170 .. "x10/glb/Worker.x10"
                            final long t$129115 = ((t$129114) + (((long)(1L))));
                            
                            //#line 170 .. "x10/glb/Worker.x10"
                            obj$129113.stealsSuffered = t$129115;
                            
                            //#line 171 .. "x10/glb/Worker.x10"
                            final x10.lang.Place alloc$129116 = ((x10.lang.Place)(new x10.lang.Place((java.lang.System[]) null)));
                            
                            //#line 171 .. "x10/glb/Worker.x10"
                            final long t$129090 = (-(thief$129105));
                            
                            //#line 171 .. "x10/glb/Worker.x10"
                            final long t$129091 = ((t$129090) - (((long)(1L))));
                            
                            //#line 171 .. "x10/glb/Worker.x10"
                            alloc$129116.x10$lang$Place$$init$S(t$129091);
                            
                            //#line 171 .. "x10/glb/Worker.x10"
                            x10.xrx.Runtime.runUncountedAsync(((x10.lang.Place)(alloc$129116)), ((x10.core.fun.VoidFun_0_0)(new x10.glb.Worker.$Closure$71<$Queue, $R>($Queue, $R, st$129130, loot$129131, (x10.glb.Worker.$Closure$71.__0$1x10$glb$Worker$1x10$glb$Worker$$Closure$71$$Queue$3x10$glb$Worker$$Closure$71$$R$2$2) null))), ((x10.xrx.Runtime.Profile)(null)));
                        }
                    } else {
                        
                        //#line 174 .. "x10/glb/Worker.x10"
                        final x10.glb.Logger obj$129119 = ((x10.glb.Logger)(((x10.glb.Worker<$Queue, $R>)this$129166).logger));
                        
                        //#line 174 .. "x10/glb/Worker.x10"
                        final long t$129120 = obj$129119.lifelineStealsSuffered;
                        
                        //#line 174 .. "x10/glb/Worker.x10"
                        final long t$129121 = ((t$129120) + (((long)(1L))));
                        
                        //#line 174 .. "x10/glb/Worker.x10"
                        obj$129119.lifelineStealsSuffered = t$129121;
                        
                        //#line 175 .. "x10/glb/Worker.x10"
                        final x10.glb.FixedSizeStack this$129122 = ((x10.glb.FixedSizeStack)(((x10.glb.Worker<$Queue, $R>)this$129166).lifelineThieves));
                        
                        //#line 44 ... "x10/glb/FixedSizeStack.x10"
                        final x10.core.Rail t$129123 = ((x10.core.Rail)(((x10.glb.FixedSizeStack<x10.core.Long>)this$129122).data));
                        
                        //#line 44 ... "x10/glb/FixedSizeStack.x10"
                        final long t$129124 = ((x10.glb.FixedSizeStack<x10.core.Long>)this$129122).size;
                        
                        //#line 44 ... "x10/glb/FixedSizeStack.x10"
                        final long t$129125 = ((t$129124) - (((long)(1L))));
                        
                        //#line 44 ... "x10/glb/FixedSizeStack.x10"
                        final long t$129126 = ((x10.glb.FixedSizeStack<x10.core.Long>)this$129122).size = t$129125;
                        
                        //#line 175 .. "x10/glb/Worker.x10"
                        final long thief$129127 = ((long[])t$129123.value)[(int)t$129126];
                        
                        //#line 176 .. "x10/glb/Worker.x10"
                        final x10.lang.Place alloc$129128 = ((x10.lang.Place)(new x10.lang.Place((java.lang.System[]) null)));
                        
                        //#line 176 .. "x10/glb/Worker.x10"
                        alloc$129128.x10$lang$Place$$init$S(((long)(thief$129127)));
                        
                        //#line 176 .. "x10/glb/Worker.x10"
                        x10.xrx.Runtime.runAsync(((x10.lang.Place)(alloc$129128)), ((x10.core.fun.VoidFun_0_0)(new x10.glb.Worker.$Closure$72<$Queue, $R>($Queue, $R, st$129130, loot$129131, victim$129092, (x10.glb.Worker.$Closure$72.__0$1x10$glb$Worker$1x10$glb$Worker$$Closure$72$$Queue$3x10$glb$Worker$$Closure$72$$R$2$2) null))), ((x10.xrx.Runtime.Profile)(null)));
                    }
                }
                
                //#line 147 "x10/glb/Worker.x10"
                final x10.glb.Worker this$129168 = ((x10.glb.Worker)(this));
                
                //#line 147 "x10/glb/Worker.x10"
                final x10.lang.PlaceLocalHandle st$129169 = ((x10.lang.PlaceLocalHandle)(st));
                
                //#line 198 . "x10/glb/Worker.x10"
                while (true) {
                    
                    //#line 198 . "x10/glb/Worker.x10"
                    final x10.glb.FixedSizeStack this$129163 = ((x10.glb.FixedSizeStack)(((x10.glb.Worker<$Queue, $R>)this$129168).thieves));
                    
                    //#line 55 .. "x10/glb/FixedSizeStack.x10"
                    final long t$129164 = ((x10.glb.FixedSizeStack<x10.core.Long>)this$129163).size;
                    
                    //#line 198 . "x10/glb/Worker.x10"
                    final boolean t$129165 = ((t$129164) > (((long)(0L))));
                    
                    //#line 198 . "x10/glb/Worker.x10"
                    if (!(t$129165)) {
                        
                        //#line 198 . "x10/glb/Worker.x10"
                        break;
                    }
                    
                    //#line 199 . "x10/glb/Worker.x10"
                    final x10.glb.FixedSizeStack this$129139 = ((x10.glb.FixedSizeStack)(((x10.glb.Worker<$Queue, $R>)this$129168).thieves));
                    
                    //#line 44 .. "x10/glb/FixedSizeStack.x10"
                    final x10.core.Rail t$129140 = ((x10.core.Rail)(((x10.glb.FixedSizeStack<x10.core.Long>)this$129139).data));
                    
                    //#line 44 .. "x10/glb/FixedSizeStack.x10"
                    final long t$129141 = ((x10.glb.FixedSizeStack<x10.core.Long>)this$129139).size;
                    
                    //#line 44 .. "x10/glb/FixedSizeStack.x10"
                    final long t$129142 = ((t$129141) - (((long)(1L))));
                    
                    //#line 44 .. "x10/glb/FixedSizeStack.x10"
                    final long t$129143 = ((x10.glb.FixedSizeStack<x10.core.Long>)this$129139).size = t$129142;
                    
                    //#line 199 . "x10/glb/Worker.x10"
                    final long thief$129144 = ((long[])t$129140.value)[(int)t$129143];
                    
                    //#line 200 . "x10/glb/Worker.x10"
                    final boolean t$129145 = ((thief$129144) >= (((long)(0L))));
                    
                    //#line 200 . "x10/glb/Worker.x10"
                    if (t$129145) {
                        
                        //#line 201 . "x10/glb/Worker.x10"
                        final x10.glb.FixedSizeStack this$129146 = ((x10.glb.FixedSizeStack)(((x10.glb.Worker<$Queue, $R>)this$129168).lifelineThieves));
                        
                        //#line 49 .. "x10/glb/FixedSizeStack.x10"
                        final x10.core.Rail t$129132 = ((x10.core.Rail)(((x10.glb.FixedSizeStack<x10.core.Long>)this$129146).data));
                        
                        //#line 49 .. "x10/glb/FixedSizeStack.x10"
                        final long t$129133 = ((x10.glb.FixedSizeStack<x10.core.Long>)this$129146).size;
                        
                        //#line 49 .. "x10/glb/FixedSizeStack.x10"
                        final long t$129134 = ((t$129133) + (((long)(1L))));
                        
                        //#line 49 .. "x10/glb/FixedSizeStack.x10"
                        final long t$129135 = ((x10.glb.FixedSizeStack<x10.core.Long>)this$129146).size = t$129134;
                        
                        //#line 49 .. "x10/glb/FixedSizeStack.x10"
                        final long t$129136 = ((t$129135) - (((long)(1L))));
                        
                        //#line 49 .. "x10/glb/FixedSizeStack.x10"
                        ((long[])t$129132.value)[(int)t$129136] = thief$129144;
                        
                        //#line 202 . "x10/glb/Worker.x10"
                        final x10.lang.Place alloc$129148 = ((x10.lang.Place)(new x10.lang.Place((java.lang.System[]) null)));
                        
                        //#line 202 . "x10/glb/Worker.x10"
                        alloc$129148.x10$lang$Place$$init$S(((long)(thief$129144)));
                        
                        //#line 202 . "x10/glb/Worker.x10"
                        x10.xrx.Runtime.runUncountedAsync(((x10.lang.Place)(alloc$129148)), ((x10.core.fun.VoidFun_0_0)(new x10.glb.Worker.$Closure$73<$Queue, $R>($Queue, $R, st$129169, (x10.glb.Worker.$Closure$73.__0$1x10$glb$Worker$1x10$glb$Worker$$Closure$73$$Queue$3x10$glb$Worker$$Closure$73$$R$2$2) null))), ((x10.xrx.Runtime.Profile)(null)));
                    } else {
                        
                        //#line 204 . "x10/glb/Worker.x10"
                        final x10.lang.Place alloc$129150 = ((x10.lang.Place)(new x10.lang.Place((java.lang.System[]) null)));
                        
                        //#line 204 . "x10/glb/Worker.x10"
                        final long t$129137 = (-(thief$129144));
                        
                        //#line 204 . "x10/glb/Worker.x10"
                        final long t$129138 = ((t$129137) - (((long)(1L))));
                        
                        //#line 204 . "x10/glb/Worker.x10"
                        alloc$129150.x10$lang$Place$$init$S(t$129138);
                        
                        //#line 204 . "x10/glb/Worker.x10"
                        x10.xrx.Runtime.runUncountedAsync(((x10.lang.Place)(alloc$129150)), ((x10.core.fun.VoidFun_0_0)(new x10.glb.Worker.$Closure$74<$Queue, $R>($Queue, $R, st$129169, (x10.glb.Worker.$Closure$74.__0$1x10$glb$Worker$1x10$glb$Worker$$Closure$74$$Queue$3x10$glb$Worker$$Closure$74$$R$2$2) null))), ((x10.xrx.Runtime.Profile)(null)));
                    }
                }
            }
            
            //#line 149 "x10/glb/Worker.x10"
            final x10.glb.Worker this$129198 = ((x10.glb.Worker)(this));
            
            //#line 149 "x10/glb/Worker.x10"
            final x10.lang.PlaceLocalHandle st$129199 = ((x10.lang.PlaceLocalHandle)(st));
            
            //#line 198 . "x10/glb/Worker.x10"
            while (true) {
                
                //#line 198 . "x10/glb/Worker.x10"
                final x10.glb.FixedSizeStack this$129190 = ((x10.glb.FixedSizeStack)(((x10.glb.Worker<$Queue, $R>)this$129198).thieves));
                
                //#line 55 .. "x10/glb/FixedSizeStack.x10"
                final long t$129191 = ((x10.glb.FixedSizeStack<x10.core.Long>)this$129190).size;
                
                //#line 198 . "x10/glb/Worker.x10"
                final boolean t$129192 = ((t$129191) > (((long)(0L))));
                
                //#line 198 . "x10/glb/Worker.x10"
                if (!(t$129192)) {
                    
                    //#line 198 . "x10/glb/Worker.x10"
                    break;
                }
                
                //#line 199 . "x10/glb/Worker.x10"
                final x10.glb.FixedSizeStack this$129177 = ((x10.glb.FixedSizeStack)(((x10.glb.Worker<$Queue, $R>)this$129198).thieves));
                
                //#line 44 .. "x10/glb/FixedSizeStack.x10"
                final x10.core.Rail t$129178 = ((x10.core.Rail)(((x10.glb.FixedSizeStack<x10.core.Long>)this$129177).data));
                
                //#line 44 .. "x10/glb/FixedSizeStack.x10"
                final long t$129179 = ((x10.glb.FixedSizeStack<x10.core.Long>)this$129177).size;
                
                //#line 44 .. "x10/glb/FixedSizeStack.x10"
                final long t$129180 = ((t$129179) - (((long)(1L))));
                
                //#line 44 .. "x10/glb/FixedSizeStack.x10"
                final long t$129181 = ((x10.glb.FixedSizeStack<x10.core.Long>)this$129177).size = t$129180;
                
                //#line 199 . "x10/glb/Worker.x10"
                final long thief$129182 = ((long[])t$129178.value)[(int)t$129181];
                
                //#line 200 . "x10/glb/Worker.x10"
                final boolean t$129183 = ((thief$129182) >= (((long)(0L))));
                
                //#line 200 . "x10/glb/Worker.x10"
                if (t$129183) {
                    
                    //#line 201 . "x10/glb/Worker.x10"
                    final x10.glb.FixedSizeStack this$129184 = ((x10.glb.FixedSizeStack)(((x10.glb.Worker<$Queue, $R>)this$129198).lifelineThieves));
                    
                    //#line 49 .. "x10/glb/FixedSizeStack.x10"
                    final x10.core.Rail t$129170 = ((x10.core.Rail)(((x10.glb.FixedSizeStack<x10.core.Long>)this$129184).data));
                    
                    //#line 49 .. "x10/glb/FixedSizeStack.x10"
                    final long t$129171 = ((x10.glb.FixedSizeStack<x10.core.Long>)this$129184).size;
                    
                    //#line 49 .. "x10/glb/FixedSizeStack.x10"
                    final long t$129172 = ((t$129171) + (((long)(1L))));
                    
                    //#line 49 .. "x10/glb/FixedSizeStack.x10"
                    final long t$129173 = ((x10.glb.FixedSizeStack<x10.core.Long>)this$129184).size = t$129172;
                    
                    //#line 49 .. "x10/glb/FixedSizeStack.x10"
                    final long t$129174 = ((t$129173) - (((long)(1L))));
                    
                    //#line 49 .. "x10/glb/FixedSizeStack.x10"
                    ((long[])t$129170.value)[(int)t$129174] = thief$129182;
                    
                    //#line 202 . "x10/glb/Worker.x10"
                    final x10.lang.Place alloc$129186 = ((x10.lang.Place)(new x10.lang.Place((java.lang.System[]) null)));
                    
                    //#line 202 . "x10/glb/Worker.x10"
                    alloc$129186.x10$lang$Place$$init$S(((long)(thief$129182)));
                    
                    //#line 202 . "x10/glb/Worker.x10"
                    x10.xrx.Runtime.runUncountedAsync(((x10.lang.Place)(alloc$129186)), ((x10.core.fun.VoidFun_0_0)(new x10.glb.Worker.$Closure$75<$Queue, $R>($Queue, $R, st$129199, (x10.glb.Worker.$Closure$75.__0$1x10$glb$Worker$1x10$glb$Worker$$Closure$75$$Queue$3x10$glb$Worker$$Closure$75$$R$2$2) null))), ((x10.xrx.Runtime.Profile)(null)));
                } else {
                    
                    //#line 204 . "x10/glb/Worker.x10"
                    final x10.lang.Place alloc$129188 = ((x10.lang.Place)(new x10.lang.Place((java.lang.System[]) null)));
                    
                    //#line 204 . "x10/glb/Worker.x10"
                    final long t$129175 = (-(thief$129182));
                    
                    //#line 204 . "x10/glb/Worker.x10"
                    final long t$129176 = ((t$129175) - (((long)(1L))));
                    
                    //#line 204 . "x10/glb/Worker.x10"
                    alloc$129188.x10$lang$Place$$init$S(t$129176);
                    
                    //#line 204 . "x10/glb/Worker.x10"
                    x10.xrx.Runtime.runUncountedAsync(((x10.lang.Place)(alloc$129188)), ((x10.core.fun.VoidFun_0_0)(new x10.glb.Worker.$Closure$76<$Queue, $R>($Queue, $R, st$129199, (x10.glb.Worker.$Closure$76.__0$1x10$glb$Worker$1x10$glb$Worker$$Closure$76$$Queue$3x10$glb$Worker$$Closure$76$$R$2$2) null))), ((x10.xrx.Runtime.Profile)(null)));
                }
            }
            
            //#line 150 "x10/glb/Worker.x10"
            final boolean t$128723 = this.steal__0$1x10$glb$Worker$1x10$glb$Worker$$Queue$3x10$glb$Worker$$R$2$2$O(((x10.lang.PlaceLocalHandle)(st)));
            
            //#line 143 "x10/glb/Worker.x10"
            t$128722 = t$128723;
        }while(t$128722); 
    }
    
    
    //#line 161 "x10/glb/Worker.x10"
    /**
     * Send out the workload to thieves. At this point, either thieves or lifelinetheives 
     * is non-empty (or both are non-empty). Note sending workload to the lifeline thieve
     * is the only place that uses async (instead of uncounted async as in other places),
     * which means when only all lifeline requests are responded can the framework be terminated.
     * @param st place local handle of LJR
     * @param loot the taskbag(aka workload) to send out
     */
    public void give__0$1x10$glb$Worker$1x10$glb$Worker$$Queue$3x10$glb$Worker$$R$2$2(final x10.lang.PlaceLocalHandle st, final x10.glb.TaskBag loot) {
        
        //#line 162 "x10/glb/Worker.x10"
        final long victim = ((long)x10.x10rt.X10RT.hereId());
        
        //#line 163 "x10/glb/Worker.x10"
        final x10.glb.Logger obj$118700 = ((x10.glb.Logger)(this.logger));
        
        //#line 163 "x10/glb/Worker.x10"
        final long t$128724 = obj$118700.nodesGiven;
        
        //#line 163 "x10/glb/Worker.x10"
        final long t$128725 = loot.size$O();
        
        //#line 163 "x10/glb/Worker.x10"
        final long t$128726 = ((t$128724) + (((long)(t$128725))));
        
        //#line 163 "x10/glb/Worker.x10"
        obj$118700.nodesGiven = t$128726;
        
        //#line 164 "x10/glb/Worker.x10"
        final x10.glb.FixedSizeStack this$128422 = ((x10.glb.FixedSizeStack)(this.thieves));
        
        //#line 55 . "x10/glb/FixedSizeStack.x10"
        final long t$128727 = ((x10.glb.FixedSizeStack<x10.core.Long>)this$128422).size;
        
        //#line 164 "x10/glb/Worker.x10"
        final boolean t$128750 = ((t$128727) > (((long)(0L))));
        
        //#line 164 "x10/glb/Worker.x10"
        if (t$128750) {
            
            //#line 165 "x10/glb/Worker.x10"
            final x10.glb.FixedSizeStack this$128424 = ((x10.glb.FixedSizeStack)(this.thieves));
            
            //#line 44 . "x10/glb/FixedSizeStack.x10"
            final x10.core.Rail t$128730 = ((x10.core.Rail)(((x10.glb.FixedSizeStack<x10.core.Long>)this$128424).data));
            
            //#line 44 . "x10/glb/FixedSizeStack.x10"
            final long t$128728 = ((x10.glb.FixedSizeStack<x10.core.Long>)this$128424).size;
            
            //#line 44 . "x10/glb/FixedSizeStack.x10"
            final long t$128729 = ((t$128728) - (((long)(1L))));
            
            //#line 44 . "x10/glb/FixedSizeStack.x10"
            final long t$128731 = ((x10.glb.FixedSizeStack<x10.core.Long>)this$128424).size = t$128729;
            
            //#line 165 "x10/glb/Worker.x10"
            final long thief = ((long[])t$128730.value)[(int)t$128731];
            
            //#line 166 "x10/glb/Worker.x10"
            final boolean t$128742 = ((thief) >= (((long)(0L))));
            
            //#line 166 "x10/glb/Worker.x10"
            if (t$128742) {
                
                //#line 167 "x10/glb/Worker.x10"
                final x10.glb.Logger obj$118722 = ((x10.glb.Logger)(this.logger));
                
                //#line 167 "x10/glb/Worker.x10"
                final long t$128732 = obj$118722.lifelineStealsSuffered;
                
                //#line 167 "x10/glb/Worker.x10"
                final long t$128733 = ((t$128732) + (((long)(1L))));
                
                //#line 167 "x10/glb/Worker.x10"
                obj$118722.lifelineStealsSuffered = t$128733;
                
                //#line 168 "x10/glb/Worker.x10"
                final x10.lang.Place alloc$119065 = ((x10.lang.Place)(new x10.lang.Place((java.lang.System[]) null)));
                
                //#line 168 "x10/glb/Worker.x10"
                alloc$119065.x10$lang$Place$$init$S(((long)(thief)));
                
                //#line 168 "x10/glb/Worker.x10"
                x10.xrx.Runtime.runUncountedAsync(((x10.lang.Place)(alloc$119065)), ((x10.core.fun.VoidFun_0_0)(new x10.glb.Worker.$Closure$77<$Queue, $R>($Queue, $R, st, loot, victim, (x10.glb.Worker.$Closure$77.__0$1x10$glb$Worker$1x10$glb$Worker$$Closure$77$$Queue$3x10$glb$Worker$$Closure$77$$R$2$2) null))), ((x10.xrx.Runtime.Profile)(null)));
            } else {
                
                //#line 170 "x10/glb/Worker.x10"
                final x10.glb.Logger obj$118730 = ((x10.glb.Logger)(this.logger));
                
                //#line 170 "x10/glb/Worker.x10"
                final long t$128736 = obj$118730.stealsSuffered;
                
                //#line 170 "x10/glb/Worker.x10"
                final long t$128737 = ((t$128736) + (((long)(1L))));
                
                //#line 170 "x10/glb/Worker.x10"
                obj$118730.stealsSuffered = t$128737;
                
                //#line 171 "x10/glb/Worker.x10"
                final x10.lang.Place alloc$119066 = ((x10.lang.Place)(new x10.lang.Place((java.lang.System[]) null)));
                
                //#line 171 "x10/glb/Worker.x10"
                final long t$129200 = (-(thief));
                
                //#line 171 "x10/glb/Worker.x10"
                final long t$129201 = ((t$129200) - (((long)(1L))));
                
                //#line 171 "x10/glb/Worker.x10"
                alloc$119066.x10$lang$Place$$init$S(t$129201);
                
                //#line 171 "x10/glb/Worker.x10"
                x10.xrx.Runtime.runUncountedAsync(((x10.lang.Place)(alloc$119066)), ((x10.core.fun.VoidFun_0_0)(new x10.glb.Worker.$Closure$78<$Queue, $R>($Queue, $R, st, loot, (x10.glb.Worker.$Closure$78.__0$1x10$glb$Worker$1x10$glb$Worker$$Closure$78$$Queue$3x10$glb$Worker$$Closure$78$$R$2$2) null))), ((x10.xrx.Runtime.Profile)(null)));
            }
        } else {
            
            //#line 174 "x10/glb/Worker.x10"
            final x10.glb.Logger obj$118752 = ((x10.glb.Logger)(this.logger));
            
            //#line 174 "x10/glb/Worker.x10"
            final long t$128743 = obj$118752.lifelineStealsSuffered;
            
            //#line 174 "x10/glb/Worker.x10"
            final long t$128744 = ((t$128743) + (((long)(1L))));
            
            //#line 174 "x10/glb/Worker.x10"
            obj$118752.lifelineStealsSuffered = t$128744;
            
            //#line 175 "x10/glb/Worker.x10"
            final x10.glb.FixedSizeStack this$128426 = ((x10.glb.FixedSizeStack)(this.lifelineThieves));
            
            //#line 44 . "x10/glb/FixedSizeStack.x10"
            final x10.core.Rail t$128747 = ((x10.core.Rail)(((x10.glb.FixedSizeStack<x10.core.Long>)this$128426).data));
            
            //#line 44 . "x10/glb/FixedSizeStack.x10"
            final long t$128745 = ((x10.glb.FixedSizeStack<x10.core.Long>)this$128426).size;
            
            //#line 44 . "x10/glb/FixedSizeStack.x10"
            final long t$128746 = ((t$128745) - (((long)(1L))));
            
            //#line 44 . "x10/glb/FixedSizeStack.x10"
            final long t$128748 = ((x10.glb.FixedSizeStack<x10.core.Long>)this$128426).size = t$128746;
            
            //#line 175 "x10/glb/Worker.x10"
            final long thief = ((long[])t$128747.value)[(int)t$128748];
            
            //#line 176 "x10/glb/Worker.x10"
            final x10.lang.Place alloc$119067 = ((x10.lang.Place)(new x10.lang.Place((java.lang.System[]) null)));
            
            //#line 176 "x10/glb/Worker.x10"
            alloc$119067.x10$lang$Place$$init$S(((long)(thief)));
            
            //#line 176 "x10/glb/Worker.x10"
            x10.xrx.Runtime.runAsync(((x10.lang.Place)(alloc$119067)), ((x10.core.fun.VoidFun_0_0)(new x10.glb.Worker.$Closure$79<$Queue, $R>($Queue, $R, st, loot, victim, (x10.glb.Worker.$Closure$79.__0$1x10$glb$Worker$1x10$glb$Worker$$Closure$79$$Queue$3x10$glb$Worker$$Closure$79$$R$2$2) null))), ((x10.xrx.Runtime.Profile)(null)));
        }
    }
    
    
    //#line 185 "x10/glb/Worker.x10"
    /**
     * Distribute works to (lifeline) thieves by calling the 
     * {@link #give(st:PlaceLocalHandle[Worker[Queue, R]], loot:TaskBag) method
     * @param st place local handle of Worker
     */
    public void distribute__0$1x10$glb$Worker$1x10$glb$Worker$$Queue$3x10$glb$Worker$$R$2$2(final x10.lang.PlaceLocalHandle st) {
        
        //#line 186 "x10/glb/Worker.x10"
        x10.glb.TaskBag loot =  null;
        
        //#line 187 "x10/glb/Worker.x10"
        while (true) {
            
            //#line 187 "x10/glb/Worker.x10"
            final x10.glb.FixedSizeStack this$128428 = ((x10.glb.FixedSizeStack)(this.thieves));
            
            //#line 55 . "x10/glb/FixedSizeStack.x10"
            final long t$128751 = ((x10.glb.FixedSizeStack<x10.core.Long>)this$128428).size;
            
            //#line 187 "x10/glb/Worker.x10"
            boolean t$128753 = ((t$128751) > (((long)(0L))));
            
            //#line 187 "x10/glb/Worker.x10"
            if (!(t$128753)) {
                
                //#line 187 "x10/glb/Worker.x10"
                final x10.glb.FixedSizeStack this$128430 = ((x10.glb.FixedSizeStack)(this.lifelineThieves));
                
                //#line 55 . "x10/glb/FixedSizeStack.x10"
                final long t$128752 = ((x10.glb.FixedSizeStack<x10.core.Long>)this$128430).size;
                
                //#line 187 "x10/glb/Worker.x10"
                t$128753 = ((t$128752) > (((long)(0L))));
            }
            
            //#line 187 "x10/glb/Worker.x10"
            boolean t$128757 = t$128753;
            
            //#line 187 "x10/glb/Worker.x10"
            if (t$128753) {
                
                //#line 187 "x10/glb/Worker.x10"
                final $Queue t$128754 = (($Queue)(this.queue));
                
                //#line 187 "x10/glb/Worker.x10"
                final x10.glb.TaskBag t$128755 = ((x10.glb.TaskQueue<$Queue, $R>)x10.rtt.Types.conversion(x10.rtt.ParameterizedType.make(x10.glb.TaskQueue.$RTT, $Queue, $R),t$128754)).split();
                
                //#line 187 "x10/glb/Worker.x10"
                final x10.glb.TaskBag t$128756 = loot = ((x10.glb.TaskBag)(t$128755));
                
                //#line 187 "x10/glb/Worker.x10"
                t$128757 = ((t$128756) != (null));
            }
            
            //#line 187 "x10/glb/Worker.x10"
            if (!(t$128757)) {
                
                //#line 187 "x10/glb/Worker.x10"
                break;
            }
            
            //#line 188 "x10/glb/Worker.x10"
            final x10.glb.Worker this$129242 = ((x10.glb.Worker)(this));
            
            //#line 188 "x10/glb/Worker.x10"
            final x10.lang.PlaceLocalHandle st$129243 = ((x10.lang.PlaceLocalHandle)(st));
            
            //#line 188 "x10/glb/Worker.x10"
            final x10.glb.TaskBag loot$129244 = ((x10.glb.TaskBag)(loot));
            
            //#line 162 . "x10/glb/Worker.x10"
            final long victim$129204 = ((long)x10.x10rt.X10RT.hereId());
            
            //#line 163 . "x10/glb/Worker.x10"
            final x10.glb.Logger obj$129205 = ((x10.glb.Logger)(((x10.glb.Worker<$Queue, $R>)this$129242).logger));
            
            //#line 163 . "x10/glb/Worker.x10"
            final long t$129206 = obj$129205.nodesGiven;
            
            //#line 163 . "x10/glb/Worker.x10"
            final long t$129207 = loot.size$O();
            
            //#line 163 . "x10/glb/Worker.x10"
            final long t$129208 = ((t$129206) + (((long)(t$129207))));
            
            //#line 163 . "x10/glb/Worker.x10"
            obj$129205.nodesGiven = t$129208;
            
            //#line 164 . "x10/glb/Worker.x10"
            final x10.glb.FixedSizeStack this$129209 = ((x10.glb.FixedSizeStack)(((x10.glb.Worker<$Queue, $R>)this$129242).thieves));
            
            //#line 55 .. "x10/glb/FixedSizeStack.x10"
            final long t$129210 = ((x10.glb.FixedSizeStack<x10.core.Long>)this$129209).size;
            
            //#line 164 . "x10/glb/Worker.x10"
            final boolean t$129211 = ((t$129210) > (((long)(0L))));
            
            //#line 164 . "x10/glb/Worker.x10"
            if (t$129211) {
                
                //#line 165 . "x10/glb/Worker.x10"
                final x10.glb.FixedSizeStack this$129212 = ((x10.glb.FixedSizeStack)(((x10.glb.Worker<$Queue, $R>)this$129242).thieves));
                
                //#line 44 .. "x10/glb/FixedSizeStack.x10"
                final x10.core.Rail t$129213 = ((x10.core.Rail)(((x10.glb.FixedSizeStack<x10.core.Long>)this$129212).data));
                
                //#line 44 .. "x10/glb/FixedSizeStack.x10"
                final long t$129214 = ((x10.glb.FixedSizeStack<x10.core.Long>)this$129212).size;
                
                //#line 44 .. "x10/glb/FixedSizeStack.x10"
                final long t$129215 = ((t$129214) - (((long)(1L))));
                
                //#line 44 .. "x10/glb/FixedSizeStack.x10"
                final long t$129216 = ((x10.glb.FixedSizeStack<x10.core.Long>)this$129212).size = t$129215;
                
                //#line 165 . "x10/glb/Worker.x10"
                final long thief$129217 = ((long[])t$129213.value)[(int)t$129216];
                
                //#line 166 . "x10/glb/Worker.x10"
                final boolean t$129218 = ((thief$129217) >= (((long)(0L))));
                
                //#line 166 . "x10/glb/Worker.x10"
                if (t$129218) {
                    
                    //#line 167 . "x10/glb/Worker.x10"
                    final x10.glb.Logger obj$129219 = ((x10.glb.Logger)(((x10.glb.Worker<$Queue, $R>)this$129242).logger));
                    
                    //#line 167 . "x10/glb/Worker.x10"
                    final long t$129220 = obj$129219.lifelineStealsSuffered;
                    
                    //#line 167 . "x10/glb/Worker.x10"
                    final long t$129221 = ((t$129220) + (((long)(1L))));
                    
                    //#line 167 . "x10/glb/Worker.x10"
                    obj$129219.lifelineStealsSuffered = t$129221;
                    
                    //#line 168 . "x10/glb/Worker.x10"
                    final x10.lang.Place alloc$129222 = ((x10.lang.Place)(new x10.lang.Place((java.lang.System[]) null)));
                    
                    //#line 168 . "x10/glb/Worker.x10"
                    alloc$129222.x10$lang$Place$$init$S(((long)(thief$129217)));
                    
                    //#line 168 . "x10/glb/Worker.x10"
                    x10.xrx.Runtime.runUncountedAsync(((x10.lang.Place)(alloc$129222)), ((x10.core.fun.VoidFun_0_0)(new x10.glb.Worker.$Closure$80<$Queue, $R>($Queue, $R, st$129243, loot$129244, victim$129204, (x10.glb.Worker.$Closure$80.__0$1x10$glb$Worker$1x10$glb$Worker$$Closure$80$$Queue$3x10$glb$Worker$$Closure$80$$R$2$2) null))), ((x10.xrx.Runtime.Profile)(null)));
                } else {
                    
                    //#line 170 . "x10/glb/Worker.x10"
                    final x10.glb.Logger obj$129225 = ((x10.glb.Logger)(((x10.glb.Worker<$Queue, $R>)this$129242).logger));
                    
                    //#line 170 . "x10/glb/Worker.x10"
                    final long t$129226 = obj$129225.stealsSuffered;
                    
                    //#line 170 . "x10/glb/Worker.x10"
                    final long t$129227 = ((t$129226) + (((long)(1L))));
                    
                    //#line 170 . "x10/glb/Worker.x10"
                    obj$129225.stealsSuffered = t$129227;
                    
                    //#line 171 . "x10/glb/Worker.x10"
                    final x10.lang.Place alloc$129228 = ((x10.lang.Place)(new x10.lang.Place((java.lang.System[]) null)));
                    
                    //#line 171 . "x10/glb/Worker.x10"
                    final long t$129202 = (-(thief$129217));
                    
                    //#line 171 . "x10/glb/Worker.x10"
                    final long t$129203 = ((t$129202) - (((long)(1L))));
                    
                    //#line 171 . "x10/glb/Worker.x10"
                    alloc$129228.x10$lang$Place$$init$S(t$129203);
                    
                    //#line 171 . "x10/glb/Worker.x10"
                    x10.xrx.Runtime.runUncountedAsync(((x10.lang.Place)(alloc$129228)), ((x10.core.fun.VoidFun_0_0)(new x10.glb.Worker.$Closure$81<$Queue, $R>($Queue, $R, st$129243, loot$129244, (x10.glb.Worker.$Closure$81.__0$1x10$glb$Worker$1x10$glb$Worker$$Closure$81$$Queue$3x10$glb$Worker$$Closure$81$$R$2$2) null))), ((x10.xrx.Runtime.Profile)(null)));
                }
            } else {
                
                //#line 174 . "x10/glb/Worker.x10"
                final x10.glb.Logger obj$129231 = ((x10.glb.Logger)(((x10.glb.Worker<$Queue, $R>)this$129242).logger));
                
                //#line 174 . "x10/glb/Worker.x10"
                final long t$129232 = obj$129231.lifelineStealsSuffered;
                
                //#line 174 . "x10/glb/Worker.x10"
                final long t$129233 = ((t$129232) + (((long)(1L))));
                
                //#line 174 . "x10/glb/Worker.x10"
                obj$129231.lifelineStealsSuffered = t$129233;
                
                //#line 175 . "x10/glb/Worker.x10"
                final x10.glb.FixedSizeStack this$129234 = ((x10.glb.FixedSizeStack)(((x10.glb.Worker<$Queue, $R>)this$129242).lifelineThieves));
                
                //#line 44 .. "x10/glb/FixedSizeStack.x10"
                final x10.core.Rail t$129235 = ((x10.core.Rail)(((x10.glb.FixedSizeStack<x10.core.Long>)this$129234).data));
                
                //#line 44 .. "x10/glb/FixedSizeStack.x10"
                final long t$129236 = ((x10.glb.FixedSizeStack<x10.core.Long>)this$129234).size;
                
                //#line 44 .. "x10/glb/FixedSizeStack.x10"
                final long t$129237 = ((t$129236) - (((long)(1L))));
                
                //#line 44 .. "x10/glb/FixedSizeStack.x10"
                final long t$129238 = ((x10.glb.FixedSizeStack<x10.core.Long>)this$129234).size = t$129237;
                
                //#line 175 . "x10/glb/Worker.x10"
                final long thief$129239 = ((long[])t$129235.value)[(int)t$129238];
                
                //#line 176 . "x10/glb/Worker.x10"
                final x10.lang.Place alloc$129240 = ((x10.lang.Place)(new x10.lang.Place((java.lang.System[]) null)));
                
                //#line 176 . "x10/glb/Worker.x10"
                alloc$129240.x10$lang$Place$$init$S(((long)(thief$129239)));
                
                //#line 176 . "x10/glb/Worker.x10"
                x10.xrx.Runtime.runAsync(((x10.lang.Place)(alloc$129240)), ((x10.core.fun.VoidFun_0_0)(new x10.glb.Worker.$Closure$82<$Queue, $R>($Queue, $R, st$129243, loot$129244, victim$129204, (x10.glb.Worker.$Closure$82.__0$1x10$glb$Worker$1x10$glb$Worker$$Closure$82$$Queue$3x10$glb$Worker$$Closure$82$$R$2$2) null))), ((x10.xrx.Runtime.Profile)(null)));
            }
        }
    }
    
    
    //#line 197 "x10/glb/Worker.x10"
    /**
     * Rejecting thieves when no task to share (or worth sharing). Note, never reject lifeline thief,
     * instead put it into the lifelineThieves stack,
     * @param st place local handle of Worker
     */
    public void reject__0$1x10$glb$Worker$1x10$glb$Worker$$Queue$3x10$glb$Worker$$R$2$2(final x10.lang.PlaceLocalHandle st) {
        
        //#line 198 "x10/glb/Worker.x10"
        while (true) {
            
            //#line 198 "x10/glb/Worker.x10"
            final x10.glb.FixedSizeStack this$128452 = ((x10.glb.FixedSizeStack)(this.thieves));
            
            //#line 55 . "x10/glb/FixedSizeStack.x10"
            final long t$128786 = ((x10.glb.FixedSizeStack<x10.core.Long>)this$128452).size;
            
            //#line 198 "x10/glb/Worker.x10"
            final boolean t$128801 = ((t$128786) > (((long)(0L))));
            
            //#line 198 "x10/glb/Worker.x10"
            if (!(t$128801)) {
                
                //#line 198 "x10/glb/Worker.x10"
                break;
            }
            
            //#line 199 "x10/glb/Worker.x10"
            final x10.glb.FixedSizeStack this$129252 = ((x10.glb.FixedSizeStack)(this.thieves));
            
            //#line 44 . "x10/glb/FixedSizeStack.x10"
            final x10.core.Rail t$129253 = ((x10.core.Rail)(((x10.glb.FixedSizeStack<x10.core.Long>)this$129252).data));
            
            //#line 44 . "x10/glb/FixedSizeStack.x10"
            final long t$129254 = ((x10.glb.FixedSizeStack<x10.core.Long>)this$129252).size;
            
            //#line 44 . "x10/glb/FixedSizeStack.x10"
            final long t$129255 = ((t$129254) - (((long)(1L))));
            
            //#line 44 . "x10/glb/FixedSizeStack.x10"
            final long t$129256 = ((x10.glb.FixedSizeStack<x10.core.Long>)this$129252).size = t$129255;
            
            //#line 199 "x10/glb/Worker.x10"
            final long thief$129257 = ((long[])t$129253.value)[(int)t$129256];
            
            //#line 200 "x10/glb/Worker.x10"
            final boolean t$129258 = ((thief$129257) >= (((long)(0L))));
            
            //#line 200 "x10/glb/Worker.x10"
            if (t$129258) {
                
                //#line 201 "x10/glb/Worker.x10"
                final x10.glb.FixedSizeStack this$129259 = ((x10.glb.FixedSizeStack)(this.lifelineThieves));
                
                //#line 49 . "x10/glb/FixedSizeStack.x10"
                final x10.core.Rail t$129245 = ((x10.core.Rail)(((x10.glb.FixedSizeStack<x10.core.Long>)this$129259).data));
                
                //#line 49 . "x10/glb/FixedSizeStack.x10"
                final long t$129246 = ((x10.glb.FixedSizeStack<x10.core.Long>)this$129259).size;
                
                //#line 49 . "x10/glb/FixedSizeStack.x10"
                final long t$129247 = ((t$129246) + (((long)(1L))));
                
                //#line 49 . "x10/glb/FixedSizeStack.x10"
                final long t$129248 = ((x10.glb.FixedSizeStack<x10.core.Long>)this$129259).size = t$129247;
                
                //#line 49 . "x10/glb/FixedSizeStack.x10"
                final long t$129249 = ((t$129248) - (((long)(1L))));
                
                //#line 49 . "x10/glb/FixedSizeStack.x10"
                ((long[])t$129245.value)[(int)t$129249] = thief$129257;
                
                //#line 202 "x10/glb/Worker.x10"
                final x10.lang.Place alloc$129261 = ((x10.lang.Place)(new x10.lang.Place((java.lang.System[]) null)));
                
                //#line 202 "x10/glb/Worker.x10"
                alloc$129261.x10$lang$Place$$init$S(((long)(thief$129257)));
                
                //#line 202 "x10/glb/Worker.x10"
                x10.xrx.Runtime.runUncountedAsync(((x10.lang.Place)(alloc$129261)), ((x10.core.fun.VoidFun_0_0)(new x10.glb.Worker.$Closure$83<$Queue, $R>($Queue, $R, st, (x10.glb.Worker.$Closure$83.__0$1x10$glb$Worker$1x10$glb$Worker$$Closure$83$$Queue$3x10$glb$Worker$$Closure$83$$R$2$2) null))), ((x10.xrx.Runtime.Profile)(null)));
            } else {
                
                //#line 204 "x10/glb/Worker.x10"
                final x10.lang.Place alloc$129263 = ((x10.lang.Place)(new x10.lang.Place((java.lang.System[]) null)));
                
                //#line 204 "x10/glb/Worker.x10"
                final long t$129250 = (-(thief$129257));
                
                //#line 204 "x10/glb/Worker.x10"
                final long t$129251 = ((t$129250) - (((long)(1L))));
                
                //#line 204 "x10/glb/Worker.x10"
                alloc$129263.x10$lang$Place$$init$S(t$129251);
                
                //#line 204 "x10/glb/Worker.x10"
                x10.xrx.Runtime.runUncountedAsync(((x10.lang.Place)(alloc$129263)), ((x10.core.fun.VoidFun_0_0)(new x10.glb.Worker.$Closure$84<$Queue, $R>($Queue, $R, st, (x10.glb.Worker.$Closure$84.__0$1x10$glb$Worker$1x10$glb$Worker$$Closure$84$$Queue$3x10$glb$Worker$$Closure$84$$R$2$2) null))), ((x10.xrx.Runtime.Profile)(null)));
            }
        }
    }
    
    
    //#line 221 "x10/glb/Worker.x10"
    /**
     * Send out steal requests.
     * It does following things:
     * (1) Probes w random victims and send out stealing requests by calling into 
     * {@link #request(st:PlaceLocalHandle[Worker[Queue, R]], thief:Long, lifeline:Boolean)}
     * (2) If probing random victims fails, resort to lifeline buddies
     * In both case, it sends out the request and wait on the thieves' response, which either comes from
     * (i){@link #reject(PlaceLocalHandle[Worker[Queue, R]])} when victim has no workload to share
     * or (ii) {@link #give(PlaceLocalHandle[Worker[Queue, R]]],TaskBag)} when victim gives the workload
     * 
     * @param st PHL for Worker
     */
    public boolean steal__0$1x10$glb$Worker$1x10$glb$Worker$$Queue$3x10$glb$Worker$$R$2$2$O(final x10.lang.PlaceLocalHandle st) {
        
        //#line 222 "x10/glb/Worker.x10"
        final long t$128802 = this.P;
        
        //#line 222 "x10/glb/Worker.x10"
        final boolean t$128803 = ((long) t$128802) == ((long) 1L);
        
        //#line 222 "x10/glb/Worker.x10"
        if (t$128803) {
            
            //#line 222 "x10/glb/Worker.x10"
            return false;
        }
        
        //#line 223 "x10/glb/Worker.x10"
        final long p = ((long)x10.x10rt.X10RT.hereId());
        
        //#line 224 "x10/glb/Worker.x10"
        ((x10.glb.Worker<$Queue, $R>)this).empty = true;
        
        //#line 225 "x10/glb/Worker.x10"
        long i$129298 = 0L;
        
        //#line 225 "x10/glb/Worker.x10"
        for (;
             true;
             ) {
            
            //#line 225 "x10/glb/Worker.x10"
            final int t$129300 = this.w;
            
            //#line 225 "x10/glb/Worker.x10"
            final long t$129301 = ((long)(((int)(t$129300))));
            
            //#line 225 "x10/glb/Worker.x10"
            boolean t$129302 = ((i$129298) < (((long)(t$129301))));
            
            //#line 225 "x10/glb/Worker.x10"
            if (t$129302) {
                
                //#line 225 "x10/glb/Worker.x10"
                t$129302 = this.empty;
            }
            
            //#line 225 "x10/glb/Worker.x10"
            if (!(t$129302)) {
                
                //#line 225 "x10/glb/Worker.x10"
                break;
            }
            
            //#line 226 "x10/glb/Worker.x10"
            final x10.glb.Logger obj$129265 = ((x10.glb.Logger)(this.logger));
            
            //#line 226 "x10/glb/Worker.x10"
            final long t$129266 = obj$129265.stealsAttempted;
            
            //#line 226 "x10/glb/Worker.x10"
            final long t$129267 = ((t$129266) + (((long)(1L))));
            
            //#line 226 "x10/glb/Worker.x10"
            obj$129265.stealsAttempted = t$129267;
            
            //#line 227 "x10/glb/Worker.x10"
            ((x10.glb.Worker<$Queue, $R>)this).waiting = true;
            
            //#line 228 "x10/glb/Worker.x10"
            final x10.glb.Logger t$129268 = ((x10.glb.Logger)(this.logger));
            
            //#line 228 "x10/glb/Worker.x10"
            t$129268.stopLive();
            
            //#line 229 "x10/glb/Worker.x10"
            final x10.core.Rail t$129269 = ((x10.core.Rail)(this.victims));
            
            //#line 229 "x10/glb/Worker.x10"
            final x10.util.Random t$129270 = ((x10.util.Random)(this.random));
            
            //#line 229 "x10/glb/Worker.x10"
            final int t$129271 = this.m;
            
            //#line 229 "x10/glb/Worker.x10"
            final int t$129272 = t$129270.nextInt$O((int)(t$129271));
            
            //#line 229 "x10/glb/Worker.x10"
            final long t$129273 = ((long)(((int)(t$129272))));
            
            //#line 229 "x10/glb/Worker.x10"
            final long v$129274 = ((long[])t$129269.value)[(int)t$129273];
            
            //#line 230 "x10/glb/Worker.x10"
            final x10.lang.Place alloc$129275 = ((x10.lang.Place)(new x10.lang.Place((java.lang.System[]) null)));
            
            //#line 230 "x10/glb/Worker.x10"
            alloc$129275.x10$lang$Place$$init$S(((long)(v$129274)));
            
            //#line 230 "x10/glb/Worker.x10"
            x10.xrx.Runtime.runUncountedAsync(((x10.lang.Place)(alloc$129275)), ((x10.core.fun.VoidFun_0_0)(new x10.glb.Worker.$Closure$85<$Queue, $R>($Queue, $R, st, p, (x10.glb.Worker.$Closure$85.__0$1x10$glb$Worker$1x10$glb$Worker$$Closure$85$$Queue$3x10$glb$Worker$$Closure$85$$R$2$2) null))), ((x10.xrx.Runtime.Profile)(null)));
            
            //#line 231 "x10/glb/Worker.x10"
            while (true) {
                
                //#line 231 "x10/glb/Worker.x10"
                final boolean t$129277 = this.waiting;
                
                //#line 231 "x10/glb/Worker.x10"
                if (!(t$129277)) {
                    
                    //#line 231 "x10/glb/Worker.x10"
                    break;
                }
                
                //#line 231 "x10/glb/Worker.x10"
                x10.xrx.Runtime.probe();
            }
            
            //#line 232 "x10/glb/Worker.x10"
            final x10.glb.Logger t$129278 = ((x10.glb.Logger)(this.logger));
            
            //#line 232 "x10/glb/Worker.x10"
            t$129278.startLive();
            
            //#line 225 "x10/glb/Worker.x10"
            final long t$129280 = ((i$129298) + (((long)(1L))));
            
            //#line 225 "x10/glb/Worker.x10"
            i$129298 = t$129280;
        }
        
        //#line 234 "x10/glb/Worker.x10"
        long i$129304 = 0L;
        
        //#line 234 "x10/glb/Worker.x10"
        for (;
             true;
             ) {
            
            //#line 234 "x10/glb/Worker.x10"
            final x10.core.Rail t$129306 = ((x10.core.Rail)(this.lifelines));
            
            //#line 234 "x10/glb/Worker.x10"
            final long t$129307 = ((x10.core.Rail<x10.core.Long>)t$129306).size;
            
            //#line 234 "x10/glb/Worker.x10"
            boolean t$129308 = ((i$129304) < (((long)(t$129307))));
            
            //#line 234 "x10/glb/Worker.x10"
            if (t$129308) {
                
                //#line 234 "x10/glb/Worker.x10"
                t$129308 = this.empty;
            }
            
            //#line 234 "x10/glb/Worker.x10"
            boolean t$129309 = t$129308;
            
            //#line 234 "x10/glb/Worker.x10"
            if (t$129308) {
                
                //#line 234 "x10/glb/Worker.x10"
                final x10.core.Rail t$129310 = ((x10.core.Rail)(this.lifelines));
                
                //#line 234 "x10/glb/Worker.x10"
                final long t$129312 = ((long[])t$129310.value)[(int)i$129304];
                
                //#line 234 "x10/glb/Worker.x10"
                t$129309 = ((0L) <= (((long)(t$129312))));
            }
            
            //#line 234 "x10/glb/Worker.x10"
            if (!(t$129309)) {
                
                //#line 234 "x10/glb/Worker.x10"
                break;
            }
            
            //#line 235 "x10/glb/Worker.x10"
            final x10.core.Rail t$129281 = ((x10.core.Rail)(this.lifelines));
            
            //#line 235 "x10/glb/Worker.x10"
            final long lifeline$129283 = ((long[])t$129281.value)[(int)i$129304];
            
            //#line 236 "x10/glb/Worker.x10"
            final x10.core.Rail t$129284 = ((x10.core.Rail)(this.lifelinesActivated));
            
            //#line 236 "x10/glb/Worker.x10"
            final boolean t$129285 = ((boolean[])t$129284.value)[(int)lifeline$129283];
            
            //#line 236 "x10/glb/Worker.x10"
            final boolean t$129286 = !(t$129285);
            
            //#line 236 "x10/glb/Worker.x10"
            if (t$129286) {
                
                //#line 237 "x10/glb/Worker.x10"
                final x10.glb.Logger obj$129287 = ((x10.glb.Logger)(this.logger));
                
                //#line 237 "x10/glb/Worker.x10"
                final long t$129288 = obj$129287.lifelineStealsAttempted;
                
                //#line 237 "x10/glb/Worker.x10"
                final long t$129289 = ((t$129288) + (((long)(1L))));
                
                //#line 237 "x10/glb/Worker.x10"
                obj$129287.lifelineStealsAttempted = t$129289;
                
                //#line 238 "x10/glb/Worker.x10"
                final x10.core.Rail t$129290 = ((x10.core.Rail)(this.lifelinesActivated));
                
                //#line 238 "x10/glb/Worker.x10"
                ((boolean[])t$129290.value)[(int)lifeline$129283] = true;
                
                //#line 239 "x10/glb/Worker.x10"
                ((x10.glb.Worker<$Queue, $R>)this).waiting = true;
                
                //#line 240 "x10/glb/Worker.x10"
                final x10.glb.Logger t$129291 = ((x10.glb.Logger)(this.logger));
                
                //#line 240 "x10/glb/Worker.x10"
                t$129291.stopLive();
                
                //#line 241 "x10/glb/Worker.x10"
                final x10.lang.Place alloc$129292 = ((x10.lang.Place)(new x10.lang.Place((java.lang.System[]) null)));
                
                //#line 241 "x10/glb/Worker.x10"
                alloc$129292.x10$lang$Place$$init$S(((long)(lifeline$129283)));
                
                //#line 241 "x10/glb/Worker.x10"
                x10.xrx.Runtime.runUncountedAsync(((x10.lang.Place)(alloc$129292)), ((x10.core.fun.VoidFun_0_0)(new x10.glb.Worker.$Closure$86<$Queue, $R>($Queue, $R, st, p, (x10.glb.Worker.$Closure$86.__0$1x10$glb$Worker$1x10$glb$Worker$$Closure$86$$Queue$3x10$glb$Worker$$Closure$86$$R$2$2) null))), ((x10.xrx.Runtime.Profile)(null)));
                
                //#line 242 "x10/glb/Worker.x10"
                while (true) {
                    
                    //#line 242 "x10/glb/Worker.x10"
                    final boolean t$129294 = this.waiting;
                    
                    //#line 242 "x10/glb/Worker.x10"
                    if (!(t$129294)) {
                        
                        //#line 242 "x10/glb/Worker.x10"
                        break;
                    }
                    
                    //#line 242 "x10/glb/Worker.x10"
                    x10.xrx.Runtime.probe();
                }
                
                //#line 243 "x10/glb/Worker.x10"
                final x10.glb.Logger t$129295 = ((x10.glb.Logger)(this.logger));
                
                //#line 243 "x10/glb/Worker.x10"
                t$129295.startLive();
            }
            
            //#line 234 "x10/glb/Worker.x10"
            final long t$129297 = ((i$129304) + (((long)(1L))));
            
            //#line 234 "x10/glb/Worker.x10"
            i$129304 = t$129297;
        }
        
        //#line 246 "x10/glb/Worker.x10"
        final boolean t$128847 = this.empty;
        
        //#line 246 "x10/glb/Worker.x10"
        final boolean t$128848 = !(t$128847);
        
        //#line 246 "x10/glb/Worker.x10"
        return t$128848;
    }
    
    
    //#line 256 "x10/glb/Worker.x10"
    /**
     * Remote thief sending requests to local LJR. When empty or waiting for more work,
     * reject non-lifeline thief right away. Note, never reject lifeline thief.
     * @param st PLH for Woker
     * @param thief place id of thief
     * @param lifeline if I am the lifeline buddy of the remote thief
     */
    public void request__0$1x10$glb$Worker$1x10$glb$Worker$$Queue$3x10$glb$Worker$$R$2$2(final x10.lang.PlaceLocalHandle st, final long thief, final boolean lifeline) {
        
        //#line 257 "x10/glb/Worker.x10"
        try {{
            
            //#line 258 "x10/glb/Worker.x10"
            if (lifeline) {
                
                //#line 258 "x10/glb/Worker.x10"
                final x10.glb.Logger obj$118853 = ((x10.glb.Logger)(this.logger));
                
                //#line 258 "x10/glb/Worker.x10"
                final long t$128849 = obj$118853.lifelineStealsReceived;
                
                //#line 258 "x10/glb/Worker.x10"
                final long t$128850 = ((t$128849) + (((long)(1L))));
                
                //#line 258 "x10/glb/Worker.x10"
                obj$118853.lifelineStealsReceived = t$128850;
            } else {
                
                //#line 258 "x10/glb/Worker.x10"
                final x10.glb.Logger obj$118861 = ((x10.glb.Logger)(this.logger));
                
                //#line 258 "x10/glb/Worker.x10"
                final long t$128851 = obj$118861.stealsReceived;
                
                //#line 258 "x10/glb/Worker.x10"
                final long t$128852 = ((t$128851) + (((long)(1L))));
                
                //#line 258 "x10/glb/Worker.x10"
                obj$118861.stealsReceived = t$128852;
            }
            
            //#line 259 "x10/glb/Worker.x10"
            boolean t$128853 = this.empty;
            
            //#line 259 "x10/glb/Worker.x10"
            if (!(t$128853)) {
                
                //#line 259 "x10/glb/Worker.x10"
                t$128853 = this.waiting;
            }
            
            //#line 259 "x10/glb/Worker.x10"
            if (t$128853) {
                
                //#line 260 "x10/glb/Worker.x10"
                if (lifeline) {
                    
                    //#line 260 "x10/glb/Worker.x10"
                    final x10.glb.FixedSizeStack this$128460 = ((x10.glb.FixedSizeStack)(this.lifelineThieves));
                    
                    //#line 49 . "x10/glb/FixedSizeStack.x10"
                    final x10.core.Rail t$129314 = ((x10.core.Rail)(((x10.glb.FixedSizeStack<x10.core.Long>)this$128460).data));
                    
                    //#line 49 . "x10/glb/FixedSizeStack.x10"
                    final long t$129315 = ((x10.glb.FixedSizeStack<x10.core.Long>)this$128460).size;
                    
                    //#line 49 . "x10/glb/FixedSizeStack.x10"
                    final long t$129316 = ((t$129315) + (((long)(1L))));
                    
                    //#line 49 . "x10/glb/FixedSizeStack.x10"
                    final long t$129317 = ((x10.glb.FixedSizeStack<x10.core.Long>)this$128460).size = t$129316;
                    
                    //#line 49 . "x10/glb/FixedSizeStack.x10"
                    final long t$129318 = ((t$129317) - (((long)(1L))));
                    
                    //#line 49 . "x10/glb/FixedSizeStack.x10"
                    ((long[])t$129314.value)[(int)t$129318] = thief;
                }
                
                //#line 261 "x10/glb/Worker.x10"
                final x10.lang.Place alloc$119072 = ((x10.lang.Place)(new x10.lang.Place((java.lang.System[]) null)));
                
                //#line 261 "x10/glb/Worker.x10"
                alloc$119072.x10$lang$Place$$init$S(((long)(thief)));
                
                //#line 261 "x10/glb/Worker.x10"
                x10.xrx.Runtime.runUncountedAsync(((x10.lang.Place)(alloc$119072)), ((x10.core.fun.VoidFun_0_0)(new x10.glb.Worker.$Closure$87<$Queue, $R>($Queue, $R, st, (x10.glb.Worker.$Closure$87.__0$1x10$glb$Worker$1x10$glb$Worker$$Closure$87$$Queue$3x10$glb$Worker$$Closure$87$$R$2$2) null))), ((x10.xrx.Runtime.Profile)(null)));
            } else {
                
                //#line 263 "x10/glb/Worker.x10"
                if (lifeline) {
                    
                    //#line 263 "x10/glb/Worker.x10"
                    final x10.glb.FixedSizeStack this$128463 = ((x10.glb.FixedSizeStack)(this.thieves));
                    
                    //#line 49 . "x10/glb/FixedSizeStack.x10"
                    final x10.core.Rail t$129319 = ((x10.core.Rail)(((x10.glb.FixedSizeStack<x10.core.Long>)this$128463).data));
                    
                    //#line 49 . "x10/glb/FixedSizeStack.x10"
                    final long t$129320 = ((x10.glb.FixedSizeStack<x10.core.Long>)this$128463).size;
                    
                    //#line 49 . "x10/glb/FixedSizeStack.x10"
                    final long t$129321 = ((t$129320) + (((long)(1L))));
                    
                    //#line 49 . "x10/glb/FixedSizeStack.x10"
                    final long t$129322 = ((x10.glb.FixedSizeStack<x10.core.Long>)this$128463).size = t$129321;
                    
                    //#line 49 . "x10/glb/FixedSizeStack.x10"
                    final long t$129323 = ((t$129322) - (((long)(1L))));
                    
                    //#line 49 . "x10/glb/FixedSizeStack.x10"
                    ((long[])t$129319.value)[(int)t$129323] = thief;
                } else {
                    
                    //#line 263 "x10/glb/Worker.x10"
                    final x10.glb.FixedSizeStack this$128466 = ((x10.glb.FixedSizeStack)(this.thieves));
                    
                    //#line 263 "x10/glb/Worker.x10"
                    final long t$128865 = (-(thief));
                    
                    //#line 263 "x10/glb/Worker.x10"
                    final long t$128465 = ((t$128865) - (((long)(1L))));
                    
                    //#line 49 . "x10/glb/FixedSizeStack.x10"
                    final x10.core.Rail t$129324 = ((x10.core.Rail)(((x10.glb.FixedSizeStack<x10.core.Long>)this$128466).data));
                    
                    //#line 49 . "x10/glb/FixedSizeStack.x10"
                    final long t$129325 = ((x10.glb.FixedSizeStack<x10.core.Long>)this$128466).size;
                    
                    //#line 49 . "x10/glb/FixedSizeStack.x10"
                    final long t$129326 = ((t$129325) + (((long)(1L))));
                    
                    //#line 49 . "x10/glb/FixedSizeStack.x10"
                    final long t$129327 = ((x10.glb.FixedSizeStack<x10.core.Long>)this$128466).size = t$129326;
                    
                    //#line 49 . "x10/glb/FixedSizeStack.x10"
                    final long t$129328 = ((t$129327) - (((long)(1L))));
                    
                    //#line 49 . "x10/glb/FixedSizeStack.x10"
                    ((long[])t$129324.value)[(int)t$129328] = t$128465;
                }
            }
        }}catch (final java.lang.Throwable v) {
            
            //#line 266 "x10/glb/Worker.x10"
            x10.glb.Worker.error(((java.lang.Throwable)(v)));
        }
    }
    
    
    //#line 275 "x10/glb/Worker.x10"
    /**
     * Merge current Worker's taskbag with incoming task bag.
     * @param loot task bag to merge
     * @param lifeline if it is from a lifeline buddy
     */
    final public void processLoot(final x10.glb.TaskBag loot, final boolean lifeline) {
        
        //#line 276 "x10/glb/Worker.x10"
        final long n = loot.size$O();
        
        //#line 277 "x10/glb/Worker.x10"
        if (lifeline) {
            
            //#line 278 "x10/glb/Worker.x10"
            final x10.glb.Logger obj$118883 = ((x10.glb.Logger)(this.logger));
            
            //#line 278 "x10/glb/Worker.x10"
            final long t$128872 = obj$118883.lifelineStealsPerpetrated;
            
            //#line 278 "x10/glb/Worker.x10"
            final long t$128873 = ((t$128872) + (((long)(1L))));
            
            //#line 278 "x10/glb/Worker.x10"
            obj$118883.lifelineStealsPerpetrated = t$128873;
            
            //#line 279 "x10/glb/Worker.x10"
            final x10.glb.Logger obj$118891 = ((x10.glb.Logger)(this.logger));
            
            //#line 279 "x10/glb/Worker.x10"
            final long t$128874 = obj$118891.lifelineNodesReceived;
            
            //#line 279 "x10/glb/Worker.x10"
            final long t$128875 = ((t$128874) + (((long)(n))));
            
            //#line 279 "x10/glb/Worker.x10"
            obj$118891.lifelineNodesReceived = t$128875;
        } else {
            
            //#line 281 "x10/glb/Worker.x10"
            final x10.glb.Logger obj$118899 = ((x10.glb.Logger)(this.logger));
            
            //#line 281 "x10/glb/Worker.x10"
            final long t$128876 = obj$118899.stealsPerpetrated;
            
            //#line 281 "x10/glb/Worker.x10"
            final long t$128877 = ((t$128876) + (((long)(1L))));
            
            //#line 281 "x10/glb/Worker.x10"
            obj$118899.stealsPerpetrated = t$128877;
            
            //#line 282 "x10/glb/Worker.x10"
            final x10.glb.Logger obj$118907 = ((x10.glb.Logger)(this.logger));
            
            //#line 282 "x10/glb/Worker.x10"
            final long t$128878 = obj$118907.nodesReceived;
            
            //#line 282 "x10/glb/Worker.x10"
            final long t$128879 = ((t$128878) + (((long)(n))));
            
            //#line 282 "x10/glb/Worker.x10"
            obj$118907.nodesReceived = t$128879;
        }
        
        //#line 284 "x10/glb/Worker.x10"
        final $Queue t$128880 = (($Queue)(this.queue));
        
        //#line 284 "x10/glb/Worker.x10"
        ((x10.glb.TaskQueue<$Queue, $R>)x10.rtt.Types.conversion(x10.rtt.ParameterizedType.make(x10.glb.TaskQueue.$RTT, $Queue, $R),t$128880)).merge(((x10.glb.TaskBag)(loot)));
    }
    
    
    //#line 294 "x10/glb/Worker.x10"
    /**
     * Deal workload to the theif. If the thief is active already, simply merge the taskbag. If the thief is inactive,
     * the thief gets reactiveated again.
     * @param st: PLH for Worker
     * @param loot Task to share
     * @param source victim id
     */
    public void deal__0$1x10$glb$Worker$1x10$glb$Worker$$Queue$3x10$glb$Worker$$R$2$2(final x10.lang.PlaceLocalHandle st, final x10.glb.TaskBag loot, final long source) {
        
        //#line 295 "x10/glb/Worker.x10"
        try {{
            
            //#line 296 "x10/glb/Worker.x10"
            final boolean lifeline = ((source) >= (((long)(0L))));
            
            //#line 297 "x10/glb/Worker.x10"
            if (lifeline) {
                
                //#line 297 "x10/glb/Worker.x10"
                final x10.core.Rail t$128881 = ((x10.core.Rail)(this.lifelinesActivated));
                
                //#line 297 "x10/glb/Worker.x10"
                ((boolean[])t$128881.value)[(int)source] = false;
            }
            
            //#line 298 "x10/glb/Worker.x10"
            ((x10.glb.Worker<$Queue, $R>)this).empty = false;
            
            //#line 299 "x10/glb/Worker.x10"
            final boolean t$128905 = this.active;
            
            //#line 299 "x10/glb/Worker.x10"
            if (t$128905) {
                
                //#line 300 "x10/glb/Worker.x10"
                final x10.glb.Worker this$128475 = ((x10.glb.Worker)(this));
                
                //#line 276 . "x10/glb/Worker.x10"
                final long n$129329 = loot.size$O();
                
                //#line 277 . "x10/glb/Worker.x10"
                if (lifeline) {
                    
                    //#line 278 . "x10/glb/Worker.x10"
                    final x10.glb.Logger obj$129330 = ((x10.glb.Logger)(((x10.glb.Worker<$Queue, $R>)this$128475).logger));
                    
                    //#line 278 . "x10/glb/Worker.x10"
                    final long t$129331 = obj$129330.lifelineStealsPerpetrated;
                    
                    //#line 278 . "x10/glb/Worker.x10"
                    final long t$129332 = ((t$129331) + (((long)(1L))));
                    
                    //#line 278 . "x10/glb/Worker.x10"
                    obj$129330.lifelineStealsPerpetrated = t$129332;
                    
                    //#line 279 . "x10/glb/Worker.x10"
                    final x10.glb.Logger obj$129333 = ((x10.glb.Logger)(((x10.glb.Worker<$Queue, $R>)this$128475).logger));
                    
                    //#line 279 . "x10/glb/Worker.x10"
                    final long t$129334 = obj$129333.lifelineNodesReceived;
                    
                    //#line 279 . "x10/glb/Worker.x10"
                    final long t$129335 = ((t$129334) + (((long)(n$129329))));
                    
                    //#line 279 . "x10/glb/Worker.x10"
                    obj$129333.lifelineNodesReceived = t$129335;
                } else {
                    
                    //#line 281 . "x10/glb/Worker.x10"
                    final x10.glb.Logger obj$129336 = ((x10.glb.Logger)(((x10.glb.Worker<$Queue, $R>)this$128475).logger));
                    
                    //#line 281 . "x10/glb/Worker.x10"
                    final long t$129337 = obj$129336.stealsPerpetrated;
                    
                    //#line 281 . "x10/glb/Worker.x10"
                    final long t$129338 = ((t$129337) + (((long)(1L))));
                    
                    //#line 281 . "x10/glb/Worker.x10"
                    obj$129336.stealsPerpetrated = t$129338;
                    
                    //#line 282 . "x10/glb/Worker.x10"
                    final x10.glb.Logger obj$129339 = ((x10.glb.Logger)(((x10.glb.Worker<$Queue, $R>)this$128475).logger));
                    
                    //#line 282 . "x10/glb/Worker.x10"
                    final long t$129340 = obj$129339.nodesReceived;
                    
                    //#line 282 . "x10/glb/Worker.x10"
                    final long t$129341 = ((t$129340) + (((long)(n$129329))));
                    
                    //#line 282 . "x10/glb/Worker.x10"
                    obj$129339.nodesReceived = t$129341;
                }
                
                //#line 284 . "x10/glb/Worker.x10"
                final $Queue t$129342 = (($Queue)(((x10.glb.Worker<$Queue, $R>)this$128475).queue));
                
                //#line 284 . "x10/glb/Worker.x10"
                ((x10.glb.TaskQueue<$Queue, $R>)x10.rtt.Types.conversion(x10.rtt.ParameterizedType.make(x10.glb.TaskQueue.$RTT, $Queue, $R),t$129342)).merge(((x10.glb.TaskBag)(loot)));
            } else {
                
                //#line 302 "x10/glb/Worker.x10"
                ((x10.glb.Worker<$Queue, $R>)this).active = true;
                
                //#line 303 "x10/glb/Worker.x10"
                final x10.glb.Logger t$128891 = ((x10.glb.Logger)(this.logger));
                
                //#line 303 "x10/glb/Worker.x10"
                t$128891.startLive();
                
                //#line 304 "x10/glb/Worker.x10"
                final x10.glb.Worker this$128484 = ((x10.glb.Worker)(this));
                
                //#line 276 . "x10/glb/Worker.x10"
                final long n$129343 = loot.size$O();
                
                //#line 277 . "x10/glb/Worker.x10"
                if (lifeline) {
                    
                    //#line 278 . "x10/glb/Worker.x10"
                    final x10.glb.Logger obj$129344 = ((x10.glb.Logger)(((x10.glb.Worker<$Queue, $R>)this$128484).logger));
                    
                    //#line 278 . "x10/glb/Worker.x10"
                    final long t$129345 = obj$129344.lifelineStealsPerpetrated;
                    
                    //#line 278 . "x10/glb/Worker.x10"
                    final long t$129346 = ((t$129345) + (((long)(1L))));
                    
                    //#line 278 . "x10/glb/Worker.x10"
                    obj$129344.lifelineStealsPerpetrated = t$129346;
                    
                    //#line 279 . "x10/glb/Worker.x10"
                    final x10.glb.Logger obj$129347 = ((x10.glb.Logger)(((x10.glb.Worker<$Queue, $R>)this$128484).logger));
                    
                    //#line 279 . "x10/glb/Worker.x10"
                    final long t$129348 = obj$129347.lifelineNodesReceived;
                    
                    //#line 279 . "x10/glb/Worker.x10"
                    final long t$129349 = ((t$129348) + (((long)(n$129343))));
                    
                    //#line 279 . "x10/glb/Worker.x10"
                    obj$129347.lifelineNodesReceived = t$129349;
                } else {
                    
                    //#line 281 . "x10/glb/Worker.x10"
                    final x10.glb.Logger obj$129350 = ((x10.glb.Logger)(((x10.glb.Worker<$Queue, $R>)this$128484).logger));
                    
                    //#line 281 . "x10/glb/Worker.x10"
                    final long t$129351 = obj$129350.stealsPerpetrated;
                    
                    //#line 281 . "x10/glb/Worker.x10"
                    final long t$129352 = ((t$129351) + (((long)(1L))));
                    
                    //#line 281 . "x10/glb/Worker.x10"
                    obj$129350.stealsPerpetrated = t$129352;
                    
                    //#line 282 . "x10/glb/Worker.x10"
                    final x10.glb.Logger obj$129353 = ((x10.glb.Logger)(((x10.glb.Worker<$Queue, $R>)this$128484).logger));
                    
                    //#line 282 . "x10/glb/Worker.x10"
                    final long t$129354 = obj$129353.nodesReceived;
                    
                    //#line 282 . "x10/glb/Worker.x10"
                    final long t$129355 = ((t$129354) + (((long)(n$129343))));
                    
                    //#line 282 . "x10/glb/Worker.x10"
                    obj$129353.nodesReceived = t$129355;
                }
                
                //#line 284 . "x10/glb/Worker.x10"
                final $Queue t$129356 = (($Queue)(((x10.glb.Worker<$Queue, $R>)this$128484).queue));
                
                //#line 284 . "x10/glb/Worker.x10"
                ((x10.glb.TaskQueue<$Queue, $R>)x10.rtt.Types.conversion(x10.rtt.ParameterizedType.make(x10.glb.TaskQueue.$RTT, $Queue, $R),t$129356)).merge(((x10.glb.TaskBag)(loot)));
                
                //#line 306 "x10/glb/Worker.x10"
                this.processStack__0$1x10$glb$Worker$1x10$glb$Worker$$Queue$3x10$glb$Worker$$R$2$2(((x10.lang.PlaceLocalHandle)(st)));
                
                //#line 307 "x10/glb/Worker.x10"
                final x10.glb.Logger t$128901 = ((x10.glb.Logger)(this.logger));
                
                //#line 307 "x10/glb/Worker.x10"
                t$128901.stopLive();
                
                //#line 308 "x10/glb/Worker.x10"
                ((x10.glb.Worker<$Queue, $R>)this).active = false;
                
                //#line 309 "x10/glb/Worker.x10"
                final x10.glb.Logger t$128903 = ((x10.glb.Logger)(this.logger));
                
                //#line 309 "x10/glb/Worker.x10"
                final $Queue t$128902 = (($Queue)(this.queue));
                
                //#line 309 "x10/glb/Worker.x10"
                final long t$128904 = ((x10.glb.TaskQueue<$Queue, $R>)x10.rtt.Types.conversion(x10.rtt.ParameterizedType.make(x10.glb.TaskQueue.$RTT, $Queue, $R),t$128902)).count$O();
                
                //#line 309 "x10/glb/Worker.x10"
                t$128903.nodesCount = t$128904;
            }
        }}catch (final java.lang.Throwable v) {
            
            //#line 312 "x10/glb/Worker.x10"
            x10.glb.Worker.error(((java.lang.Throwable)(v)));
        }
    }
    
    
    //#line 324 "x10/glb/Worker.x10"
    /**
     * Entry point when workload is only known dynamically . The workflow is terminated when 
     * (1) No one has work to do
     * (2) Lifeline steals are responded
     * @param place local handle for Worker
     * @param start init method used in {@link TaskQueue}, note the workload is not allocated, because
     * the workload can only be self-generated.
     */
    public void main__0$1x10$glb$Worker$1x10$glb$Worker$$Queue$3x10$glb$Worker$$R$2$2(final x10.lang.PlaceLocalHandle st, final x10.core.fun.VoidFun_0_0 start) {
        {
            
            //#line 325 "x10/glb/Worker.x10"
            x10.xrx.Runtime.ensureNotInAtomic();
            
            //#line 325 "x10/glb/Worker.x10"
            final x10.xrx.FinishState fs$129543 = x10.xrx.Runtime.startFinish((int)(x10.compiler.Pragma.FINISH_DENSE));
            
            //#line 325 "x10/glb/Worker.x10"
            try {{
                {
                    
                    //#line 326 "x10/glb/Worker.x10"
                    try {{
                        
                        //#line 327 "x10/glb/Worker.x10"
                        ((x10.glb.Worker<$Queue, $R>)this).empty = false;
                        
                        //#line 328 "x10/glb/Worker.x10"
                        ((x10.glb.Worker<$Queue, $R>)this).active = true;
                        
                        //#line 329 "x10/glb/Worker.x10"
                        final x10.glb.Logger t$128906 = ((x10.glb.Logger)(this.logger));
                        
                        //#line 329 "x10/glb/Worker.x10"
                        t$128906.startLive();
                        
                        //#line 330 "x10/glb/Worker.x10"
                        ((x10.core.fun.VoidFun_0_0)start).$apply();
                        
                        //#line 331 "x10/glb/Worker.x10"
                        this.processStack__0$1x10$glb$Worker$1x10$glb$Worker$$Queue$3x10$glb$Worker$$R$2$2(((x10.lang.PlaceLocalHandle)(st)));
                        
                        //#line 332 "x10/glb/Worker.x10"
                        final x10.glb.Logger t$128907 = ((x10.glb.Logger)(this.logger));
                        
                        //#line 332 "x10/glb/Worker.x10"
                        t$128907.stopLive();
                        
                        //#line 333 "x10/glb/Worker.x10"
                        ((x10.glb.Worker<$Queue, $R>)this).active = false;
                        
                        //#line 334 "x10/glb/Worker.x10"
                        final x10.glb.Logger t$128909 = ((x10.glb.Logger)(this.logger));
                        
                        //#line 334 "x10/glb/Worker.x10"
                        final $Queue t$128908 = (($Queue)(this.queue));
                        
                        //#line 334 "x10/glb/Worker.x10"
                        final long t$128910 = ((x10.glb.TaskQueue<$Queue, $R>)x10.rtt.Types.conversion(x10.rtt.ParameterizedType.make(x10.glb.TaskQueue.$RTT, $Queue, $R),t$128908)).count$O();
                        
                        //#line 334 "x10/glb/Worker.x10"
                        t$128909.nodesCount = t$128910;
                    }}catch (final java.lang.Throwable v) {
                        
                        //#line 336 "x10/glb/Worker.x10"
                        x10.glb.Worker.error(((java.lang.Throwable)(v)));
                    }
                }
            }}catch (java.lang.Throwable ct$129540) {
                
                //#line 325 "x10/glb/Worker.x10"
                x10.xrx.Runtime.pushException(((java.lang.Throwable)(ct$129540)));
                
                //#line 325 "x10/glb/Worker.x10"
                throw new java.lang.RuntimeException();
            }finally {{
                 
                 //#line 325 "x10/glb/Worker.x10"
                 x10.xrx.Runtime.stopFinish(((x10.xrx.FinishState)(fs$129543)));
             }}
            }
        }
    
    
    //#line 348 "x10/glb/Worker.x10"
    /**
     * Entry point when workload can be known statically. The workflow is terminated when 
     * (1) No one has work to do
     * (2) Lifeline steals are responded
     * @param place local handle for Worker. Note the workload is assumed to be allocated already in the {@link TaskQueue}
     * constructor.
     */
    public void main__0$1x10$glb$Worker$1x10$glb$Worker$$Queue$3x10$glb$Worker$$R$2$2(final x10.lang.PlaceLocalHandle st) {
        
        //#line 349 "x10/glb/Worker.x10"
        try {{
            
            //#line 350 "x10/glb/Worker.x10"
            ((x10.glb.Worker<$Queue, $R>)this).empty = false;
            
            //#line 351 "x10/glb/Worker.x10"
            ((x10.glb.Worker<$Queue, $R>)this).active = true;
            
            //#line 352 "x10/glb/Worker.x10"
            final x10.glb.Logger t$128911 = ((x10.glb.Logger)(this.logger));
            
            //#line 352 "x10/glb/Worker.x10"
            t$128911.startLive();
            
            //#line 353 "x10/glb/Worker.x10"
            this.processStack__0$1x10$glb$Worker$1x10$glb$Worker$$Queue$3x10$glb$Worker$$R$2$2(((x10.lang.PlaceLocalHandle)(st)));
            
            //#line 354 "x10/glb/Worker.x10"
            final x10.glb.Logger t$128912 = ((x10.glb.Logger)(this.logger));
            
            //#line 354 "x10/glb/Worker.x10"
            t$128912.stopLive();
            
            //#line 355 "x10/glb/Worker.x10"
            ((x10.glb.Worker<$Queue, $R>)this).active = false;
            
            //#line 356 "x10/glb/Worker.x10"
            final x10.glb.Logger t$128914 = ((x10.glb.Logger)(this.logger));
            
            //#line 356 "x10/glb/Worker.x10"
            final $Queue t$128913 = (($Queue)(this.queue));
            
            //#line 356 "x10/glb/Worker.x10"
            final long t$128915 = ((x10.glb.TaskQueue<$Queue, $R>)x10.rtt.Types.conversion(x10.rtt.ParameterizedType.make(x10.glb.TaskQueue.$RTT, $Queue, $R),t$128913)).count$O();
            
            //#line 356 "x10/glb/Worker.x10"
            t$128914.nodesCount = t$128915;
        }}catch (final java.lang.Throwable v) {
            
            //#line 358 "x10/glb/Worker.x10"
            x10.glb.Worker.error(((java.lang.Throwable)(v)));
        }
    }
    
    
    //#line 366 "x10/glb/Worker.x10"
    /**
     * Print exceptions
     * @param v exeception
     */
    public static void error(final java.lang.Throwable v) {
        
        //#line 367 "x10/glb/Worker.x10"
        final java.lang.String t$128916 = (("Exception at ") + (x10.x10rt.X10RT.here()));
        
        //#line 367 "x10/glb/Worker.x10"
        java.lang.System.err.println(t$128916);
        
        //#line 368 "x10/glb/Worker.x10"
        v.printStackTrace();
    }
    
    
    //#line 374 "x10/glb/Worker.x10"
    /**
     * Min helper function
     */
    public static long min$O(final long i, final long j) {
        
        //#line 374 "x10/glb/Worker.x10"
        final boolean t$128917 = ((i) < (((long)(j))));
        
        //#line 374 "x10/glb/Worker.x10"
        long t$128918 =  0;
        
        //#line 374 "x10/glb/Worker.x10"
        if (t$128917) {
            
            //#line 374 "x10/glb/Worker.x10"
            t$128918 = i;
        } else {
            
            //#line 374 "x10/glb/Worker.x10"
            t$128918 = j;
        }
        
        //#line 374 "x10/glb/Worker.x10"
        return t$128918;
    }
    
    
    //#line 403 "x10/glb/Worker.x10"
    /**
     * Internal method used by {@link GLB} to start Worker at each place when the 
     * workload is known statically.
     * @param st PLH of Worker
     */
    public static <$Queue, $R>void broadcast__0$1x10$glb$Worker$1x10$glb$Worker$$Queue$3x10$glb$Worker$$R$2$2(final x10.rtt.Type $Queue, final x10.rtt.Type $R, final x10.lang.PlaceLocalHandle<x10.glb.Worker<$Queue, $R>> st) {
        
        //#line 404 "x10/glb/Worker.x10"
        final long P = ((long)x10.x10rt.X10RT.numPlaces());
        {
            
            //#line 405 "x10/glb/Worker.x10"
            x10.xrx.Runtime.ensureNotInAtomic();
            
            //#line 405 "x10/glb/Worker.x10"
            final x10.xrx.FinishState fs$129560 = x10.xrx.Runtime.startFinish((int)(x10.compiler.Pragma.FINISH_DENSE));
            
            //#line 405 "x10/glb/Worker.x10"
            try {{
                {
                    
                    //#line 406 "x10/glb/Worker.x10"
                    final boolean t$128941 = ((P) < (((long)(256L))));
                    
                    //#line 406 "x10/glb/Worker.x10"
                    if (t$128941) {
                        
                        //#line 407 "x10/glb/Worker.x10"
                        long i = 0L;
                        
                        //#line 407 "x10/glb/Worker.x10"
                        for (;
                             true;
                             ) {
                            
                            //#line 407 "x10/glb/Worker.x10"
                            final boolean t$128926 = ((i) < (((long)(P))));
                            
                            //#line 407 "x10/glb/Worker.x10"
                            if (!(t$128926)) {
                                
                                //#line 407 "x10/glb/Worker.x10"
                                break;
                            }
                            
                            //#line 408 "x10/glb/Worker.x10"
                            final x10.lang.Place alloc$129358 = ((x10.lang.Place)(new x10.lang.Place((java.lang.System[]) null)));
                            
                            //#line 408 "x10/glb/Worker.x10"
                            alloc$129358.x10$lang$Place$$init$S(i);
                            
                            //#line 408 "x10/glb/Worker.x10"
                            x10.xrx.Runtime.runAsync(((x10.lang.Place)(alloc$129358)), ((x10.core.fun.VoidFun_0_0)(new x10.glb.Worker.$Closure$88<$Queue, $R>($Queue, $R, st, (x10.glb.Worker.$Closure$88.__0$1x10$glb$Worker$1x10$glb$Worker$$Closure$88$$Queue$3x10$glb$Worker$$Closure$88$$R$2$2) null))), ((x10.xrx.Runtime.Profile)(null)));
                            
                            //#line 407 "x10/glb/Worker.x10"
                            final long t$129361 = ((i) + (((long)(1L))));
                            
                            //#line 407 "x10/glb/Worker.x10"
                            i = t$129361;
                        }
                    } else {
                        
                        //#line 411 "x10/glb/Worker.x10"
                        long i = ((P) - (((long)(1L))));
                        
                        //#line 411 "x10/glb/Worker.x10"
                        for (;
                             true;
                             ) {
                            
                            //#line 411 "x10/glb/Worker.x10"
                            final boolean t$128940 = ((i) >= (((long)(0L))));
                            
                            //#line 411 "x10/glb/Worker.x10"
                            if (!(t$128940)) {
                                
                                //#line 411 "x10/glb/Worker.x10"
                                break;
                            }
                            
                            //#line 412 "x10/glb/Worker.x10"
                            final x10.lang.Place alloc$129371 = ((x10.lang.Place)(new x10.lang.Place((java.lang.System[]) null)));
                            
                            //#line 412 "x10/glb/Worker.x10"
                            alloc$129371.x10$lang$Place$$init$S(i);
                            
                            //#line 412 "x10/glb/Worker.x10"
                            x10.xrx.Runtime.runAsync(((x10.lang.Place)(alloc$129371)), ((x10.core.fun.VoidFun_0_0)(new x10.glb.Worker.$Closure$90<$Queue, $R>($Queue, $R, st, (x10.glb.Worker.$Closure$90.__0$1x10$glb$Worker$1x10$glb$Worker$$Closure$90$$Queue$3x10$glb$Worker$$Closure$90$$R$2$2) null))), ((x10.xrx.Runtime.Profile)(null)));
                            
                            //#line 411 "x10/glb/Worker.x10"
                            final long t$129376 = ((i) - (((long)(32L))));
                            
                            //#line 411 "x10/glb/Worker.x10"
                            i = t$129376;
                        }
                    }
                }
            }}catch (java.lang.Throwable ct$129557) {
                
                //#line 405 "x10/glb/Worker.x10"
                x10.xrx.Runtime.pushException(((java.lang.Throwable)(ct$129557)));
                
                //#line 405 "x10/glb/Worker.x10"
                throw new java.lang.RuntimeException();
            }finally {{
                 
                 //#line 405 "x10/glb/Worker.x10"
                 x10.xrx.Runtime.stopFinish(((x10.xrx.FinishState)(fs$129560)));
             }}
            }
        }
    
    
    //#line 427 "x10/glb/Worker.x10"
    /**
     * Initialize Context object at every place
     * @param st: PLH of Worker
     */
    public static <$Queue, $R>void initContexts__0$1x10$glb$Worker$1x10$glb$Worker$$Queue$3x10$glb$Worker$$R$2$2(final x10.rtt.Type $Queue, final x10.rtt.Type $R, final x10.lang.PlaceLocalHandle<x10.glb.Worker<$Queue, $R>> st) {
        
        //#line 428 "x10/glb/Worker.x10"
        final long P = ((long)x10.x10rt.X10RT.numPlaces());
        {
            
            //#line 429 "x10/glb/Worker.x10"
            x10.xrx.Runtime.ensureNotInAtomic();
            
            //#line 429 "x10/glb/Worker.x10"
            final x10.xrx.FinishState fs$129577 = x10.xrx.Runtime.startFinish((int)(x10.compiler.Pragma.FINISH_DENSE));
            
            //#line 429 "x10/glb/Worker.x10"
            try {{
                {
                    
                    //#line 430 "x10/glb/Worker.x10"
                    final boolean t$128963 = ((P) < (((long)(256L))));
                    
                    //#line 430 "x10/glb/Worker.x10"
                    if (t$128963) {
                        
                        //#line 431 "x10/glb/Worker.x10"
                        long i = 0L;
                        
                        //#line 431 "x10/glb/Worker.x10"
                        for (;
                             true;
                             ) {
                            
                            //#line 431 "x10/glb/Worker.x10"
                            final boolean t$128948 = ((i) < (((long)(P))));
                            
                            //#line 431 "x10/glb/Worker.x10"
                            if (!(t$128948)) {
                                
                                //#line 431 "x10/glb/Worker.x10"
                                break;
                            }
                            
                            //#line 432 "x10/glb/Worker.x10"
                            final x10.lang.Place alloc$129381 = ((x10.lang.Place)(new x10.lang.Place((java.lang.System[]) null)));
                            
                            //#line 432 "x10/glb/Worker.x10"
                            alloc$129381.x10$lang$Place$$init$S(i);
                            
                            //#line 432 "x10/glb/Worker.x10"
                            x10.xrx.Runtime.runAsync(((x10.lang.Place)(alloc$129381)), ((x10.core.fun.VoidFun_0_0)(new x10.glb.Worker.$Closure$91<$Queue, $R>($Queue, $R, st, (x10.glb.Worker.$Closure$91.__0$1x10$glb$Worker$1x10$glb$Worker$$Closure$91$$Queue$3x10$glb$Worker$$Closure$91$$R$2$2) null))), ((x10.xrx.Runtime.Profile)(null)));
                            
                            //#line 431 "x10/glb/Worker.x10"
                            final long t$129385 = ((i) + (((long)(1L))));
                            
                            //#line 431 "x10/glb/Worker.x10"
                            i = t$129385;
                        }
                    } else {
                        
                        //#line 435 "x10/glb/Worker.x10"
                        long i = ((P) - (((long)(1L))));
                        
                        //#line 435 "x10/glb/Worker.x10"
                        for (;
                             true;
                             ) {
                            
                            //#line 435 "x10/glb/Worker.x10"
                            final boolean t$128962 = ((i) >= (((long)(0L))));
                            
                            //#line 435 "x10/glb/Worker.x10"
                            if (!(t$128962)) {
                                
                                //#line 435 "x10/glb/Worker.x10"
                                break;
                            }
                            
                            //#line 436 "x10/glb/Worker.x10"
                            final x10.lang.Place alloc$129399 = ((x10.lang.Place)(new x10.lang.Place((java.lang.System[]) null)));
                            
                            //#line 436 "x10/glb/Worker.x10"
                            alloc$129399.x10$lang$Place$$init$S(i);
                            
                            //#line 436 "x10/glb/Worker.x10"
                            x10.xrx.Runtime.runAsync(((x10.lang.Place)(alloc$129399)), ((x10.core.fun.VoidFun_0_0)(new x10.glb.Worker.$Closure$93<$Queue, $R>($Queue, $R, st, (x10.glb.Worker.$Closure$93.__0$1x10$glb$Worker$1x10$glb$Worker$$Closure$93$$Queue$3x10$glb$Worker$$Closure$93$$R$2$2) null))), ((x10.xrx.Runtime.Profile)(null)));
                            
                            //#line 435 "x10/glb/Worker.x10"
                            final long t$129404 = ((i) - (((long)(32L))));
                            
                            //#line 435 "x10/glb/Worker.x10"
                            i = t$129404;
                        }
                    }
                }
            }}catch (java.lang.Throwable ct$129574) {
                
                //#line 429 "x10/glb/Worker.x10"
                x10.xrx.Runtime.pushException(((java.lang.Throwable)(ct$129574)));
                
                //#line 429 "x10/glb/Worker.x10"
                throw new java.lang.RuntimeException();
            }finally {{
                 
                 //#line 429 "x10/glb/Worker.x10"
                 x10.xrx.Runtime.stopFinish(((x10.xrx.FinishState)(fs$129577)));
             }}
            }
        }
    
    
    //#line 451 "x10/glb/Worker.x10"
    /**
     * Returns yield point
     */
    public x10.core.fun.VoidFun_0_1 getYieldPoint() {
        
        //#line 452 "x10/glb/Worker.x10"
        final x10.core.fun.VoidFun_0_1 t$129015 = ((x10.core.fun.VoidFun_0_1)(new x10.glb.Worker.$Closure$99<$Queue, $R>($Queue, $R, ((x10.glb.Worker<$Queue, $R>)(this)), (x10.glb.Worker.$Closure$99.__0$1x10$glb$Worker$$Closure$99$$Queue$3x10$glb$Worker$$Closure$99$$R$2) null)));
        
        //#line 452 "x10/glb/Worker.x10"
        return t$129015;
    }
    
    
    //#line 459 "x10/glb/Worker.x10"
    /**
     * Set the context object
     * @param st PLH of Worker
     */
    public void setContext__0$1x10$glb$Worker$1x10$glb$Worker$$Queue$3x10$glb$Worker$$R$2$2(final x10.lang.PlaceLocalHandle st) {
        
        //#line 461 "x10/glb/Worker.x10"
        final x10.glb.Context alloc$119079 = ((x10.glb.Context)(new x10.glb.Context<$Queue, $R>((java.lang.System[]) null, $Queue, $R)));
        
        //#line 25 .. "x10/glb/Context.x10"
        final x10.lang.PlaceLocalHandle t$129481 = (x10.lang.PlaceLocalHandle<x10.glb.Worker<$Queue, $R>>) x10.rtt.Types.zeroValue(x10.rtt.ParameterizedType.make(x10.lang.PlaceLocalHandle.$RTT, x10.rtt.ParameterizedType.make(x10.glb.Worker.$RTT, $Queue, $R)));
        
        //#line 20 .. "x10/glb/Context.x10"
        ((x10.glb.Context<$Queue, $R>)alloc$119079).st = t$129481;
        
        //#line 31 . "x10/glb/Context.x10"
        ((x10.glb.Context<$Queue, $R>)alloc$119079).st = ((x10.lang.PlaceLocalHandle)(st));
        
        //#line 461 "x10/glb/Worker.x10"
        ((x10.glb.Worker<$Queue, $R>)this).context = ((x10.glb.Context)(alloc$119079));
    }
    
    
    //#line 27 "x10/glb/Worker.x10"
    final public x10.glb.Worker x10$glb$Worker$$this$x10$glb$Worker() {
        
        //#line 27 "x10/glb/Worker.x10"
        return x10.glb.Worker.this;
    }
    
    
    //#line 27 "x10/glb/Worker.x10"
    final public void __fieldInitializers_x10_glb_Worker() {
        
        //#line 60 "x10/glb/Worker.x10"
        final x10.util.Random alloc$119080 = ((x10.util.Random)(new x10.util.Random((java.lang.System[]) null)));
        
        //#line 60 "x10/glb/Worker.x10"
        final int t$129017 = x10.x10rt.X10RT.hereId();
        
        //#line 60 "x10/glb/Worker.x10"
        final long seed$128543 = ((long)(((int)(t$129017))));
        
        //#line 24 ... "x10/util/Random.x10"
        alloc$119080.seed = 0L;
        
        //#line 24 ... "x10/util/Random.x10"
        alloc$119080.storedGaussian = 0.0;
        
        //#line 24 ... "x10/util/Random.x10"
        alloc$119080.haveStoredGaussian = false;
        
        //#line 36 .. "x10/util/Random.x10"
        alloc$119080.seed = seed$128543;
        
        //#line 37 .. "x10/util/Random.x10"
        alloc$119080.gamma = -7046029254386353131L;
        
        //#line 27 "x10/glb/Worker.x10"
        ((x10.glb.Worker<$Queue, $R>)this).random = ((x10.util.Random)(alloc$119080));
        
        //#line 27 "x10/glb/Worker.x10"
        ((x10.glb.Worker<$Queue, $R>)this).active = false;
        
        //#line 27 "x10/glb/Worker.x10"
        ((x10.glb.Worker<$Queue, $R>)this).empty = true;
        
        //#line 27 "x10/glb/Worker.x10"
        ((x10.glb.Worker<$Queue, $R>)this).waiting = false;
        
        //#line 75 "x10/glb/Worker.x10"
        final long t$129018 = ((long)x10.x10rt.X10RT.numPlaces());
        
        //#line 27 "x10/glb/Worker.x10"
        ((x10.glb.Worker<$Queue, $R>)this).P = t$129018;
        
        //#line 27 "x10/glb/Worker.x10"
        ((x10.glb.Worker<$Queue, $R>)this).context = null;
    }
    
    @x10.runtime.impl.java.X10Generated
    final public static class $Closure$70<$Queue, $R> extends x10.core.Ref implements x10.core.fun.VoidFun_0_0, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<$Closure$70> $RTT = 
            x10.rtt.StaticVoidFunType.<$Closure$70> make($Closure$70.class,
                                                         2,
                                                         new x10.rtt.Type[] {
                                                             x10.core.fun.VoidFun_0_0.$RTT
                                                         });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { if (i == 0) return $Queue; if (i == 1) return $R; return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static <$Queue, $R> x10.serialization.X10JavaSerializable $_deserialize_body(x10.glb.Worker.$Closure$70<$Queue, $R> $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            $_obj.$Queue = (x10.rtt.Type) $deserializer.readObject();
            $_obj.$R = (x10.rtt.Type) $deserializer.readObject();
            $_obj.loot$129131 = $deserializer.readObject();
            $_obj.st$129130 = $deserializer.readObject();
            $_obj.victim$129092 = $deserializer.readLong();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.glb.Worker.$Closure$70 $_obj = new x10.glb.Worker.$Closure$70((java.lang.System[]) null, (x10.rtt.Type) null, (x10.rtt.Type) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            $serializer.write(this.$Queue);
            $serializer.write(this.$R);
            $serializer.write(this.loot$129131);
            $serializer.write(this.st$129130);
            $serializer.write(this.victim$129092);
            
        }
        
        // constructor just for allocation
        public $Closure$70(final java.lang.System[] $dummy, final x10.rtt.Type $Queue, final x10.rtt.Type $R) {
            x10.glb.Worker.$Closure$70.$initParams(this, $Queue, $R);
            
        }
        
        private x10.rtt.Type $Queue;
        private x10.rtt.Type $R;
        
        // initializer of type parameters
        public static void $initParams(final $Closure$70 $this, final x10.rtt.Type $Queue, final x10.rtt.Type $R) {
            $this.$Queue = $Queue;
            $this.$R = $R;
            
        }
        // synthetic type for parameter mangling
        public static final class __0$1x10$glb$Worker$1x10$glb$Worker$$Closure$70$$Queue$3x10$glb$Worker$$Closure$70$$R$2$2 {}
        
    
        
        public void $apply() {
            
            //#line 168 .. "x10/glb/Worker.x10"
            final x10.glb.Worker t$129111 = ((x10.lang.PlaceLocalHandle<x10.glb.Worker<$Queue, $R>>)this.st$129130).$apply$G();
            
            //#line 168 .. "x10/glb/Worker.x10"
            ((x10.glb.Worker<$Queue, $R>)t$129111).deal__0$1x10$glb$Worker$1x10$glb$Worker$$Queue$3x10$glb$Worker$$R$2$2(((x10.lang.PlaceLocalHandle)(this.st$129130)), ((x10.glb.TaskBag)(this.loot$129131)), (long)(this.victim$129092));
            
            //#line 168 .. "x10/glb/Worker.x10"
            final x10.glb.Worker t$129112 = ((x10.lang.PlaceLocalHandle<x10.glb.Worker<$Queue, $R>>)this.st$129130).$apply$G();
            
            //#line 168 .. "x10/glb/Worker.x10"
            ((x10.glb.Worker<$Queue, $R>)t$129112).waiting = false;
        }
        
        public x10.lang.PlaceLocalHandle<x10.glb.Worker<$Queue, $R>> st$129130;
        public x10.glb.TaskBag loot$129131;
        public long victim$129092;
        
        public $Closure$70(final x10.rtt.Type $Queue, final x10.rtt.Type $R, final x10.lang.PlaceLocalHandle<x10.glb.Worker<$Queue, $R>> st$129130, final x10.glb.TaskBag loot$129131, final long victim$129092, __0$1x10$glb$Worker$1x10$glb$Worker$$Closure$70$$Queue$3x10$glb$Worker$$Closure$70$$R$2$2 $dummy) {
            x10.glb.Worker.$Closure$70.$initParams(this, $Queue, $R);
             {
                ((x10.glb.Worker.$Closure$70<$Queue, $R>)this).st$129130 = ((x10.lang.PlaceLocalHandle)(st$129130));
                ((x10.glb.Worker.$Closure$70<$Queue, $R>)this).loot$129131 = ((x10.glb.TaskBag)(loot$129131));
                ((x10.glb.Worker.$Closure$70<$Queue, $R>)this).victim$129092 = victim$129092;
            }
        }
        
    }
    
    @x10.runtime.impl.java.X10Generated
    final public static class $Closure$71<$Queue, $R> extends x10.core.Ref implements x10.core.fun.VoidFun_0_0, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<$Closure$71> $RTT = 
            x10.rtt.StaticVoidFunType.<$Closure$71> make($Closure$71.class,
                                                         2,
                                                         new x10.rtt.Type[] {
                                                             x10.core.fun.VoidFun_0_0.$RTT
                                                         });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { if (i == 0) return $Queue; if (i == 1) return $R; return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static <$Queue, $R> x10.serialization.X10JavaSerializable $_deserialize_body(x10.glb.Worker.$Closure$71<$Queue, $R> $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            $_obj.$Queue = (x10.rtt.Type) $deserializer.readObject();
            $_obj.$R = (x10.rtt.Type) $deserializer.readObject();
            $_obj.loot$129131 = $deserializer.readObject();
            $_obj.st$129130 = $deserializer.readObject();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.glb.Worker.$Closure$71 $_obj = new x10.glb.Worker.$Closure$71((java.lang.System[]) null, (x10.rtt.Type) null, (x10.rtt.Type) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            $serializer.write(this.$Queue);
            $serializer.write(this.$R);
            $serializer.write(this.loot$129131);
            $serializer.write(this.st$129130);
            
        }
        
        // constructor just for allocation
        public $Closure$71(final java.lang.System[] $dummy, final x10.rtt.Type $Queue, final x10.rtt.Type $R) {
            x10.glb.Worker.$Closure$71.$initParams(this, $Queue, $R);
            
        }
        
        private x10.rtt.Type $Queue;
        private x10.rtt.Type $R;
        
        // initializer of type parameters
        public static void $initParams(final $Closure$71 $this, final x10.rtt.Type $Queue, final x10.rtt.Type $R) {
            $this.$Queue = $Queue;
            $this.$R = $R;
            
        }
        // synthetic type for parameter mangling
        public static final class __0$1x10$glb$Worker$1x10$glb$Worker$$Closure$71$$Queue$3x10$glb$Worker$$Closure$71$$R$2$2 {}
        
    
        
        public void $apply() {
            
            //#line 171 .. "x10/glb/Worker.x10"
            final x10.glb.Worker t$129117 = ((x10.lang.PlaceLocalHandle<x10.glb.Worker<$Queue, $R>>)this.st$129130).$apply$G();
            
            //#line 171 .. "x10/glb/Worker.x10"
            ((x10.glb.Worker<$Queue, $R>)t$129117).deal__0$1x10$glb$Worker$1x10$glb$Worker$$Queue$3x10$glb$Worker$$R$2$2(((x10.lang.PlaceLocalHandle)(this.st$129130)), ((x10.glb.TaskBag)(this.loot$129131)), (long)(-1L));
            
            //#line 171 .. "x10/glb/Worker.x10"
            final x10.glb.Worker t$129118 = ((x10.lang.PlaceLocalHandle<x10.glb.Worker<$Queue, $R>>)this.st$129130).$apply$G();
            
            //#line 171 .. "x10/glb/Worker.x10"
            ((x10.glb.Worker<$Queue, $R>)t$129118).waiting = false;
        }
        
        public x10.lang.PlaceLocalHandle<x10.glb.Worker<$Queue, $R>> st$129130;
        public x10.glb.TaskBag loot$129131;
        
        public $Closure$71(final x10.rtt.Type $Queue, final x10.rtt.Type $R, final x10.lang.PlaceLocalHandle<x10.glb.Worker<$Queue, $R>> st$129130, final x10.glb.TaskBag loot$129131, __0$1x10$glb$Worker$1x10$glb$Worker$$Closure$71$$Queue$3x10$glb$Worker$$Closure$71$$R$2$2 $dummy) {
            x10.glb.Worker.$Closure$71.$initParams(this, $Queue, $R);
             {
                ((x10.glb.Worker.$Closure$71<$Queue, $R>)this).st$129130 = ((x10.lang.PlaceLocalHandle)(st$129130));
                ((x10.glb.Worker.$Closure$71<$Queue, $R>)this).loot$129131 = ((x10.glb.TaskBag)(loot$129131));
            }
        }
        
    }
    
    @x10.runtime.impl.java.X10Generated
    final public static class $Closure$72<$Queue, $R> extends x10.core.Ref implements x10.core.fun.VoidFun_0_0, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<$Closure$72> $RTT = 
            x10.rtt.StaticVoidFunType.<$Closure$72> make($Closure$72.class,
                                                         2,
                                                         new x10.rtt.Type[] {
                                                             x10.core.fun.VoidFun_0_0.$RTT
                                                         });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { if (i == 0) return $Queue; if (i == 1) return $R; return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static <$Queue, $R> x10.serialization.X10JavaSerializable $_deserialize_body(x10.glb.Worker.$Closure$72<$Queue, $R> $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            $_obj.$Queue = (x10.rtt.Type) $deserializer.readObject();
            $_obj.$R = (x10.rtt.Type) $deserializer.readObject();
            $_obj.loot$129131 = $deserializer.readObject();
            $_obj.st$129130 = $deserializer.readObject();
            $_obj.victim$129092 = $deserializer.readLong();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.glb.Worker.$Closure$72 $_obj = new x10.glb.Worker.$Closure$72((java.lang.System[]) null, (x10.rtt.Type) null, (x10.rtt.Type) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            $serializer.write(this.$Queue);
            $serializer.write(this.$R);
            $serializer.write(this.loot$129131);
            $serializer.write(this.st$129130);
            $serializer.write(this.victim$129092);
            
        }
        
        // constructor just for allocation
        public $Closure$72(final java.lang.System[] $dummy, final x10.rtt.Type $Queue, final x10.rtt.Type $R) {
            x10.glb.Worker.$Closure$72.$initParams(this, $Queue, $R);
            
        }
        
        private x10.rtt.Type $Queue;
        private x10.rtt.Type $R;
        
        // initializer of type parameters
        public static void $initParams(final $Closure$72 $this, final x10.rtt.Type $Queue, final x10.rtt.Type $R) {
            $this.$Queue = $Queue;
            $this.$R = $R;
            
        }
        // synthetic type for parameter mangling
        public static final class __0$1x10$glb$Worker$1x10$glb$Worker$$Closure$72$$Queue$3x10$glb$Worker$$Closure$72$$R$2$2 {}
        
    
        
        public void $apply() {
            
            //#line 176 .. "x10/glb/Worker.x10"
            try {{
                
                //#line 176 .. "x10/glb/Worker.x10"
                final x10.glb.Worker t$129129 = ((x10.lang.PlaceLocalHandle<x10.glb.Worker<$Queue, $R>>)this.st$129130).$apply$G();
                
                //#line 176 .. "x10/glb/Worker.x10"
                ((x10.glb.Worker<$Queue, $R>)t$129129).deal__0$1x10$glb$Worker$1x10$glb$Worker$$Queue$3x10$glb$Worker$$R$2$2(((x10.lang.PlaceLocalHandle)(this.st$129130)), ((x10.glb.TaskBag)(this.loot$129131)), (long)(this.victim$129092));
            }}catch (java.lang.Error __lowerer__var__0__) {
                
                //#line 176 .. "x10/glb/Worker.x10"
                throw __lowerer__var__0__;
            }catch (java.lang.Throwable __lowerer__var__1__) {
                
                //#line 176 .. "x10/glb/Worker.x10"
                throw x10.rtt.Types.EXCEPTION.isInstance(__lowerer__var__1__) ? (java.lang.RuntimeException)(__lowerer__var__1__) : new x10.lang.WrappedThrowable(__lowerer__var__1__);
            }
        }
        
        public x10.lang.PlaceLocalHandle<x10.glb.Worker<$Queue, $R>> st$129130;
        public x10.glb.TaskBag loot$129131;
        public long victim$129092;
        
        public $Closure$72(final x10.rtt.Type $Queue, final x10.rtt.Type $R, final x10.lang.PlaceLocalHandle<x10.glb.Worker<$Queue, $R>> st$129130, final x10.glb.TaskBag loot$129131, final long victim$129092, __0$1x10$glb$Worker$1x10$glb$Worker$$Closure$72$$Queue$3x10$glb$Worker$$Closure$72$$R$2$2 $dummy) {
            x10.glb.Worker.$Closure$72.$initParams(this, $Queue, $R);
             {
                ((x10.glb.Worker.$Closure$72<$Queue, $R>)this).st$129130 = ((x10.lang.PlaceLocalHandle)(st$129130));
                ((x10.glb.Worker.$Closure$72<$Queue, $R>)this).loot$129131 = ((x10.glb.TaskBag)(loot$129131));
                ((x10.glb.Worker.$Closure$72<$Queue, $R>)this).victim$129092 = victim$129092;
            }
        }
        
    }
    
    @x10.runtime.impl.java.X10Generated
    final public static class $Closure$73<$Queue, $R> extends x10.core.Ref implements x10.core.fun.VoidFun_0_0, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<$Closure$73> $RTT = 
            x10.rtt.StaticVoidFunType.<$Closure$73> make($Closure$73.class,
                                                         2,
                                                         new x10.rtt.Type[] {
                                                             x10.core.fun.VoidFun_0_0.$RTT
                                                         });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { if (i == 0) return $Queue; if (i == 1) return $R; return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static <$Queue, $R> x10.serialization.X10JavaSerializable $_deserialize_body(x10.glb.Worker.$Closure$73<$Queue, $R> $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            $_obj.$Queue = (x10.rtt.Type) $deserializer.readObject();
            $_obj.$R = (x10.rtt.Type) $deserializer.readObject();
            $_obj.st$129169 = $deserializer.readObject();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.glb.Worker.$Closure$73 $_obj = new x10.glb.Worker.$Closure$73((java.lang.System[]) null, (x10.rtt.Type) null, (x10.rtt.Type) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            $serializer.write(this.$Queue);
            $serializer.write(this.$R);
            $serializer.write(this.st$129169);
            
        }
        
        // constructor just for allocation
        public $Closure$73(final java.lang.System[] $dummy, final x10.rtt.Type $Queue, final x10.rtt.Type $R) {
            x10.glb.Worker.$Closure$73.$initParams(this, $Queue, $R);
            
        }
        
        private x10.rtt.Type $Queue;
        private x10.rtt.Type $R;
        
        // initializer of type parameters
        public static void $initParams(final $Closure$73 $this, final x10.rtt.Type $Queue, final x10.rtt.Type $R) {
            $this.$Queue = $Queue;
            $this.$R = $R;
            
        }
        // synthetic type for parameter mangling
        public static final class __0$1x10$glb$Worker$1x10$glb$Worker$$Closure$73$$Queue$3x10$glb$Worker$$Closure$73$$R$2$2 {}
        
    
        
        public void $apply() {
            
            //#line 202 . "x10/glb/Worker.x10"
            final x10.glb.Worker t$129149 = ((x10.lang.PlaceLocalHandle<x10.glb.Worker<$Queue, $R>>)this.st$129169).$apply$G();
            
            //#line 202 . "x10/glb/Worker.x10"
            ((x10.glb.Worker<$Queue, $R>)t$129149).waiting = false;
        }
        
        public x10.lang.PlaceLocalHandle<x10.glb.Worker<$Queue, $R>> st$129169;
        
        public $Closure$73(final x10.rtt.Type $Queue, final x10.rtt.Type $R, final x10.lang.PlaceLocalHandle<x10.glb.Worker<$Queue, $R>> st$129169, __0$1x10$glb$Worker$1x10$glb$Worker$$Closure$73$$Queue$3x10$glb$Worker$$Closure$73$$R$2$2 $dummy) {
            x10.glb.Worker.$Closure$73.$initParams(this, $Queue, $R);
             {
                ((x10.glb.Worker.$Closure$73<$Queue, $R>)this).st$129169 = ((x10.lang.PlaceLocalHandle)(st$129169));
            }
        }
        
    }
    
    @x10.runtime.impl.java.X10Generated
    final public static class $Closure$74<$Queue, $R> extends x10.core.Ref implements x10.core.fun.VoidFun_0_0, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<$Closure$74> $RTT = 
            x10.rtt.StaticVoidFunType.<$Closure$74> make($Closure$74.class,
                                                         2,
                                                         new x10.rtt.Type[] {
                                                             x10.core.fun.VoidFun_0_0.$RTT
                                                         });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { if (i == 0) return $Queue; if (i == 1) return $R; return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static <$Queue, $R> x10.serialization.X10JavaSerializable $_deserialize_body(x10.glb.Worker.$Closure$74<$Queue, $R> $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            $_obj.$Queue = (x10.rtt.Type) $deserializer.readObject();
            $_obj.$R = (x10.rtt.Type) $deserializer.readObject();
            $_obj.st$129169 = $deserializer.readObject();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.glb.Worker.$Closure$74 $_obj = new x10.glb.Worker.$Closure$74((java.lang.System[]) null, (x10.rtt.Type) null, (x10.rtt.Type) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            $serializer.write(this.$Queue);
            $serializer.write(this.$R);
            $serializer.write(this.st$129169);
            
        }
        
        // constructor just for allocation
        public $Closure$74(final java.lang.System[] $dummy, final x10.rtt.Type $Queue, final x10.rtt.Type $R) {
            x10.glb.Worker.$Closure$74.$initParams(this, $Queue, $R);
            
        }
        
        private x10.rtt.Type $Queue;
        private x10.rtt.Type $R;
        
        // initializer of type parameters
        public static void $initParams(final $Closure$74 $this, final x10.rtt.Type $Queue, final x10.rtt.Type $R) {
            $this.$Queue = $Queue;
            $this.$R = $R;
            
        }
        // synthetic type for parameter mangling
        public static final class __0$1x10$glb$Worker$1x10$glb$Worker$$Closure$74$$Queue$3x10$glb$Worker$$Closure$74$$R$2$2 {}
        
    
        
        public void $apply() {
            
            //#line 204 . "x10/glb/Worker.x10"
            final x10.glb.Worker t$129151 = ((x10.lang.PlaceLocalHandle<x10.glb.Worker<$Queue, $R>>)this.st$129169).$apply$G();
            
            //#line 204 . "x10/glb/Worker.x10"
            ((x10.glb.Worker<$Queue, $R>)t$129151).waiting = false;
        }
        
        public x10.lang.PlaceLocalHandle<x10.glb.Worker<$Queue, $R>> st$129169;
        
        public $Closure$74(final x10.rtt.Type $Queue, final x10.rtt.Type $R, final x10.lang.PlaceLocalHandle<x10.glb.Worker<$Queue, $R>> st$129169, __0$1x10$glb$Worker$1x10$glb$Worker$$Closure$74$$Queue$3x10$glb$Worker$$Closure$74$$R$2$2 $dummy) {
            x10.glb.Worker.$Closure$74.$initParams(this, $Queue, $R);
             {
                ((x10.glb.Worker.$Closure$74<$Queue, $R>)this).st$129169 = ((x10.lang.PlaceLocalHandle)(st$129169));
            }
        }
        
    }
    
    @x10.runtime.impl.java.X10Generated
    final public static class $Closure$75<$Queue, $R> extends x10.core.Ref implements x10.core.fun.VoidFun_0_0, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<$Closure$75> $RTT = 
            x10.rtt.StaticVoidFunType.<$Closure$75> make($Closure$75.class,
                                                         2,
                                                         new x10.rtt.Type[] {
                                                             x10.core.fun.VoidFun_0_0.$RTT
                                                         });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { if (i == 0) return $Queue; if (i == 1) return $R; return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static <$Queue, $R> x10.serialization.X10JavaSerializable $_deserialize_body(x10.glb.Worker.$Closure$75<$Queue, $R> $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            $_obj.$Queue = (x10.rtt.Type) $deserializer.readObject();
            $_obj.$R = (x10.rtt.Type) $deserializer.readObject();
            $_obj.st$129199 = $deserializer.readObject();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.glb.Worker.$Closure$75 $_obj = new x10.glb.Worker.$Closure$75((java.lang.System[]) null, (x10.rtt.Type) null, (x10.rtt.Type) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            $serializer.write(this.$Queue);
            $serializer.write(this.$R);
            $serializer.write(this.st$129199);
            
        }
        
        // constructor just for allocation
        public $Closure$75(final java.lang.System[] $dummy, final x10.rtt.Type $Queue, final x10.rtt.Type $R) {
            x10.glb.Worker.$Closure$75.$initParams(this, $Queue, $R);
            
        }
        
        private x10.rtt.Type $Queue;
        private x10.rtt.Type $R;
        
        // initializer of type parameters
        public static void $initParams(final $Closure$75 $this, final x10.rtt.Type $Queue, final x10.rtt.Type $R) {
            $this.$Queue = $Queue;
            $this.$R = $R;
            
        }
        // synthetic type for parameter mangling
        public static final class __0$1x10$glb$Worker$1x10$glb$Worker$$Closure$75$$Queue$3x10$glb$Worker$$Closure$75$$R$2$2 {}
        
    
        
        public void $apply() {
            
            //#line 202 . "x10/glb/Worker.x10"
            final x10.glb.Worker t$129187 = ((x10.lang.PlaceLocalHandle<x10.glb.Worker<$Queue, $R>>)this.st$129199).$apply$G();
            
            //#line 202 . "x10/glb/Worker.x10"
            ((x10.glb.Worker<$Queue, $R>)t$129187).waiting = false;
        }
        
        public x10.lang.PlaceLocalHandle<x10.glb.Worker<$Queue, $R>> st$129199;
        
        public $Closure$75(final x10.rtt.Type $Queue, final x10.rtt.Type $R, final x10.lang.PlaceLocalHandle<x10.glb.Worker<$Queue, $R>> st$129199, __0$1x10$glb$Worker$1x10$glb$Worker$$Closure$75$$Queue$3x10$glb$Worker$$Closure$75$$R$2$2 $dummy) {
            x10.glb.Worker.$Closure$75.$initParams(this, $Queue, $R);
             {
                ((x10.glb.Worker.$Closure$75<$Queue, $R>)this).st$129199 = ((x10.lang.PlaceLocalHandle)(st$129199));
            }
        }
        
    }
    
    @x10.runtime.impl.java.X10Generated
    final public static class $Closure$76<$Queue, $R> extends x10.core.Ref implements x10.core.fun.VoidFun_0_0, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<$Closure$76> $RTT = 
            x10.rtt.StaticVoidFunType.<$Closure$76> make($Closure$76.class,
                                                         2,
                                                         new x10.rtt.Type[] {
                                                             x10.core.fun.VoidFun_0_0.$RTT
                                                         });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { if (i == 0) return $Queue; if (i == 1) return $R; return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static <$Queue, $R> x10.serialization.X10JavaSerializable $_deserialize_body(x10.glb.Worker.$Closure$76<$Queue, $R> $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            $_obj.$Queue = (x10.rtt.Type) $deserializer.readObject();
            $_obj.$R = (x10.rtt.Type) $deserializer.readObject();
            $_obj.st$129199 = $deserializer.readObject();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.glb.Worker.$Closure$76 $_obj = new x10.glb.Worker.$Closure$76((java.lang.System[]) null, (x10.rtt.Type) null, (x10.rtt.Type) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            $serializer.write(this.$Queue);
            $serializer.write(this.$R);
            $serializer.write(this.st$129199);
            
        }
        
        // constructor just for allocation
        public $Closure$76(final java.lang.System[] $dummy, final x10.rtt.Type $Queue, final x10.rtt.Type $R) {
            x10.glb.Worker.$Closure$76.$initParams(this, $Queue, $R);
            
        }
        
        private x10.rtt.Type $Queue;
        private x10.rtt.Type $R;
        
        // initializer of type parameters
        public static void $initParams(final $Closure$76 $this, final x10.rtt.Type $Queue, final x10.rtt.Type $R) {
            $this.$Queue = $Queue;
            $this.$R = $R;
            
        }
        // synthetic type for parameter mangling
        public static final class __0$1x10$glb$Worker$1x10$glb$Worker$$Closure$76$$Queue$3x10$glb$Worker$$Closure$76$$R$2$2 {}
        
    
        
        public void $apply() {
            
            //#line 204 . "x10/glb/Worker.x10"
            final x10.glb.Worker t$129189 = ((x10.lang.PlaceLocalHandle<x10.glb.Worker<$Queue, $R>>)this.st$129199).$apply$G();
            
            //#line 204 . "x10/glb/Worker.x10"
            ((x10.glb.Worker<$Queue, $R>)t$129189).waiting = false;
        }
        
        public x10.lang.PlaceLocalHandle<x10.glb.Worker<$Queue, $R>> st$129199;
        
        public $Closure$76(final x10.rtt.Type $Queue, final x10.rtt.Type $R, final x10.lang.PlaceLocalHandle<x10.glb.Worker<$Queue, $R>> st$129199, __0$1x10$glb$Worker$1x10$glb$Worker$$Closure$76$$Queue$3x10$glb$Worker$$Closure$76$$R$2$2 $dummy) {
            x10.glb.Worker.$Closure$76.$initParams(this, $Queue, $R);
             {
                ((x10.glb.Worker.$Closure$76<$Queue, $R>)this).st$129199 = ((x10.lang.PlaceLocalHandle)(st$129199));
            }
        }
        
    }
    
    @x10.runtime.impl.java.X10Generated
    final public static class $Closure$77<$Queue, $R> extends x10.core.Ref implements x10.core.fun.VoidFun_0_0, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<$Closure$77> $RTT = 
            x10.rtt.StaticVoidFunType.<$Closure$77> make($Closure$77.class,
                                                         2,
                                                         new x10.rtt.Type[] {
                                                             x10.core.fun.VoidFun_0_0.$RTT
                                                         });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { if (i == 0) return $Queue; if (i == 1) return $R; return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static <$Queue, $R> x10.serialization.X10JavaSerializable $_deserialize_body(x10.glb.Worker.$Closure$77<$Queue, $R> $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            $_obj.$Queue = (x10.rtt.Type) $deserializer.readObject();
            $_obj.$R = (x10.rtt.Type) $deserializer.readObject();
            $_obj.loot = $deserializer.readObject();
            $_obj.st = $deserializer.readObject();
            $_obj.victim = $deserializer.readLong();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.glb.Worker.$Closure$77 $_obj = new x10.glb.Worker.$Closure$77((java.lang.System[]) null, (x10.rtt.Type) null, (x10.rtt.Type) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            $serializer.write(this.$Queue);
            $serializer.write(this.$R);
            $serializer.write(this.loot);
            $serializer.write(this.st);
            $serializer.write(this.victim);
            
        }
        
        // constructor just for allocation
        public $Closure$77(final java.lang.System[] $dummy, final x10.rtt.Type $Queue, final x10.rtt.Type $R) {
            x10.glb.Worker.$Closure$77.$initParams(this, $Queue, $R);
            
        }
        
        private x10.rtt.Type $Queue;
        private x10.rtt.Type $R;
        
        // initializer of type parameters
        public static void $initParams(final $Closure$77 $this, final x10.rtt.Type $Queue, final x10.rtt.Type $R) {
            $this.$Queue = $Queue;
            $this.$R = $R;
            
        }
        // synthetic type for parameter mangling
        public static final class __0$1x10$glb$Worker$1x10$glb$Worker$$Closure$77$$Queue$3x10$glb$Worker$$Closure$77$$R$2$2 {}
        
    
        
        public void $apply() {
            
            //#line 168 "x10/glb/Worker.x10"
            final x10.glb.Worker t$128734 = ((x10.lang.PlaceLocalHandle<x10.glb.Worker<$Queue, $R>>)this.st).$apply$G();
            
            //#line 168 "x10/glb/Worker.x10"
            ((x10.glb.Worker<$Queue, $R>)t$128734).deal__0$1x10$glb$Worker$1x10$glb$Worker$$Queue$3x10$glb$Worker$$R$2$2(((x10.lang.PlaceLocalHandle)(this.st)), ((x10.glb.TaskBag)(this.loot)), (long)(this.victim));
            
            //#line 168 "x10/glb/Worker.x10"
            final x10.glb.Worker t$128735 = ((x10.lang.PlaceLocalHandle<x10.glb.Worker<$Queue, $R>>)this.st).$apply$G();
            
            //#line 168 "x10/glb/Worker.x10"
            ((x10.glb.Worker<$Queue, $R>)t$128735).waiting = false;
        }
        
        public x10.lang.PlaceLocalHandle<x10.glb.Worker<$Queue, $R>> st;
        public x10.glb.TaskBag loot;
        public long victim;
        
        public $Closure$77(final x10.rtt.Type $Queue, final x10.rtt.Type $R, final x10.lang.PlaceLocalHandle<x10.glb.Worker<$Queue, $R>> st, final x10.glb.TaskBag loot, final long victim, __0$1x10$glb$Worker$1x10$glb$Worker$$Closure$77$$Queue$3x10$glb$Worker$$Closure$77$$R$2$2 $dummy) {
            x10.glb.Worker.$Closure$77.$initParams(this, $Queue, $R);
             {
                ((x10.glb.Worker.$Closure$77<$Queue, $R>)this).st = ((x10.lang.PlaceLocalHandle)(st));
                ((x10.glb.Worker.$Closure$77<$Queue, $R>)this).loot = ((x10.glb.TaskBag)(loot));
                ((x10.glb.Worker.$Closure$77<$Queue, $R>)this).victim = victim;
            }
        }
        
    }
    
    @x10.runtime.impl.java.X10Generated
    final public static class $Closure$78<$Queue, $R> extends x10.core.Ref implements x10.core.fun.VoidFun_0_0, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<$Closure$78> $RTT = 
            x10.rtt.StaticVoidFunType.<$Closure$78> make($Closure$78.class,
                                                         2,
                                                         new x10.rtt.Type[] {
                                                             x10.core.fun.VoidFun_0_0.$RTT
                                                         });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { if (i == 0) return $Queue; if (i == 1) return $R; return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static <$Queue, $R> x10.serialization.X10JavaSerializable $_deserialize_body(x10.glb.Worker.$Closure$78<$Queue, $R> $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            $_obj.$Queue = (x10.rtt.Type) $deserializer.readObject();
            $_obj.$R = (x10.rtt.Type) $deserializer.readObject();
            $_obj.loot = $deserializer.readObject();
            $_obj.st = $deserializer.readObject();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.glb.Worker.$Closure$78 $_obj = new x10.glb.Worker.$Closure$78((java.lang.System[]) null, (x10.rtt.Type) null, (x10.rtt.Type) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            $serializer.write(this.$Queue);
            $serializer.write(this.$R);
            $serializer.write(this.loot);
            $serializer.write(this.st);
            
        }
        
        // constructor just for allocation
        public $Closure$78(final java.lang.System[] $dummy, final x10.rtt.Type $Queue, final x10.rtt.Type $R) {
            x10.glb.Worker.$Closure$78.$initParams(this, $Queue, $R);
            
        }
        
        private x10.rtt.Type $Queue;
        private x10.rtt.Type $R;
        
        // initializer of type parameters
        public static void $initParams(final $Closure$78 $this, final x10.rtt.Type $Queue, final x10.rtt.Type $R) {
            $this.$Queue = $Queue;
            $this.$R = $R;
            
        }
        // synthetic type for parameter mangling
        public static final class __0$1x10$glb$Worker$1x10$glb$Worker$$Closure$78$$Queue$3x10$glb$Worker$$Closure$78$$R$2$2 {}
        
    
        
        public void $apply() {
            
            //#line 171 "x10/glb/Worker.x10"
            final x10.glb.Worker t$128740 = ((x10.lang.PlaceLocalHandle<x10.glb.Worker<$Queue, $R>>)this.st).$apply$G();
            
            //#line 171 "x10/glb/Worker.x10"
            ((x10.glb.Worker<$Queue, $R>)t$128740).deal__0$1x10$glb$Worker$1x10$glb$Worker$$Queue$3x10$glb$Worker$$R$2$2(((x10.lang.PlaceLocalHandle)(this.st)), ((x10.glb.TaskBag)(this.loot)), (long)(-1L));
            
            //#line 171 "x10/glb/Worker.x10"
            final x10.glb.Worker t$128741 = ((x10.lang.PlaceLocalHandle<x10.glb.Worker<$Queue, $R>>)this.st).$apply$G();
            
            //#line 171 "x10/glb/Worker.x10"
            ((x10.glb.Worker<$Queue, $R>)t$128741).waiting = false;
        }
        
        public x10.lang.PlaceLocalHandle<x10.glb.Worker<$Queue, $R>> st;
        public x10.glb.TaskBag loot;
        
        public $Closure$78(final x10.rtt.Type $Queue, final x10.rtt.Type $R, final x10.lang.PlaceLocalHandle<x10.glb.Worker<$Queue, $R>> st, final x10.glb.TaskBag loot, __0$1x10$glb$Worker$1x10$glb$Worker$$Closure$78$$Queue$3x10$glb$Worker$$Closure$78$$R$2$2 $dummy) {
            x10.glb.Worker.$Closure$78.$initParams(this, $Queue, $R);
             {
                ((x10.glb.Worker.$Closure$78<$Queue, $R>)this).st = ((x10.lang.PlaceLocalHandle)(st));
                ((x10.glb.Worker.$Closure$78<$Queue, $R>)this).loot = ((x10.glb.TaskBag)(loot));
            }
        }
        
    }
    
    @x10.runtime.impl.java.X10Generated
    final public static class $Closure$79<$Queue, $R> extends x10.core.Ref implements x10.core.fun.VoidFun_0_0, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<$Closure$79> $RTT = 
            x10.rtt.StaticVoidFunType.<$Closure$79> make($Closure$79.class,
                                                         2,
                                                         new x10.rtt.Type[] {
                                                             x10.core.fun.VoidFun_0_0.$RTT
                                                         });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { if (i == 0) return $Queue; if (i == 1) return $R; return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static <$Queue, $R> x10.serialization.X10JavaSerializable $_deserialize_body(x10.glb.Worker.$Closure$79<$Queue, $R> $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            $_obj.$Queue = (x10.rtt.Type) $deserializer.readObject();
            $_obj.$R = (x10.rtt.Type) $deserializer.readObject();
            $_obj.loot = $deserializer.readObject();
            $_obj.st = $deserializer.readObject();
            $_obj.victim = $deserializer.readLong();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.glb.Worker.$Closure$79 $_obj = new x10.glb.Worker.$Closure$79((java.lang.System[]) null, (x10.rtt.Type) null, (x10.rtt.Type) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            $serializer.write(this.$Queue);
            $serializer.write(this.$R);
            $serializer.write(this.loot);
            $serializer.write(this.st);
            $serializer.write(this.victim);
            
        }
        
        // constructor just for allocation
        public $Closure$79(final java.lang.System[] $dummy, final x10.rtt.Type $Queue, final x10.rtt.Type $R) {
            x10.glb.Worker.$Closure$79.$initParams(this, $Queue, $R);
            
        }
        
        private x10.rtt.Type $Queue;
        private x10.rtt.Type $R;
        
        // initializer of type parameters
        public static void $initParams(final $Closure$79 $this, final x10.rtt.Type $Queue, final x10.rtt.Type $R) {
            $this.$Queue = $Queue;
            $this.$R = $R;
            
        }
        // synthetic type for parameter mangling
        public static final class __0$1x10$glb$Worker$1x10$glb$Worker$$Closure$79$$Queue$3x10$glb$Worker$$Closure$79$$R$2$2 {}
        
    
        
        public void $apply() {
            
            //#line 176 "x10/glb/Worker.x10"
            try {{
                
                //#line 176 "x10/glb/Worker.x10"
                final x10.glb.Worker t$128749 = ((x10.lang.PlaceLocalHandle<x10.glb.Worker<$Queue, $R>>)this.st).$apply$G();
                
                //#line 176 "x10/glb/Worker.x10"
                ((x10.glb.Worker<$Queue, $R>)t$128749).deal__0$1x10$glb$Worker$1x10$glb$Worker$$Queue$3x10$glb$Worker$$R$2$2(((x10.lang.PlaceLocalHandle)(this.st)), ((x10.glb.TaskBag)(this.loot)), (long)(this.victim));
            }}catch (java.lang.Error __lowerer__var__0__) {
                
                //#line 176 "x10/glb/Worker.x10"
                throw __lowerer__var__0__;
            }catch (java.lang.Throwable __lowerer__var__1__) {
                
                //#line 176 "x10/glb/Worker.x10"
                throw x10.rtt.Types.EXCEPTION.isInstance(__lowerer__var__1__) ? (java.lang.RuntimeException)(__lowerer__var__1__) : new x10.lang.WrappedThrowable(__lowerer__var__1__);
            }
        }
        
        public x10.lang.PlaceLocalHandle<x10.glb.Worker<$Queue, $R>> st;
        public x10.glb.TaskBag loot;
        public long victim;
        
        public $Closure$79(final x10.rtt.Type $Queue, final x10.rtt.Type $R, final x10.lang.PlaceLocalHandle<x10.glb.Worker<$Queue, $R>> st, final x10.glb.TaskBag loot, final long victim, __0$1x10$glb$Worker$1x10$glb$Worker$$Closure$79$$Queue$3x10$glb$Worker$$Closure$79$$R$2$2 $dummy) {
            x10.glb.Worker.$Closure$79.$initParams(this, $Queue, $R);
             {
                ((x10.glb.Worker.$Closure$79<$Queue, $R>)this).st = ((x10.lang.PlaceLocalHandle)(st));
                ((x10.glb.Worker.$Closure$79<$Queue, $R>)this).loot = ((x10.glb.TaskBag)(loot));
                ((x10.glb.Worker.$Closure$79<$Queue, $R>)this).victim = victim;
            }
        }
        
    }
    
    @x10.runtime.impl.java.X10Generated
    final public static class $Closure$80<$Queue, $R> extends x10.core.Ref implements x10.core.fun.VoidFun_0_0, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<$Closure$80> $RTT = 
            x10.rtt.StaticVoidFunType.<$Closure$80> make($Closure$80.class,
                                                         2,
                                                         new x10.rtt.Type[] {
                                                             x10.core.fun.VoidFun_0_0.$RTT
                                                         });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { if (i == 0) return $Queue; if (i == 1) return $R; return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static <$Queue, $R> x10.serialization.X10JavaSerializable $_deserialize_body(x10.glb.Worker.$Closure$80<$Queue, $R> $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            $_obj.$Queue = (x10.rtt.Type) $deserializer.readObject();
            $_obj.$R = (x10.rtt.Type) $deserializer.readObject();
            $_obj.loot$129244 = $deserializer.readObject();
            $_obj.st$129243 = $deserializer.readObject();
            $_obj.victim$129204 = $deserializer.readLong();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.glb.Worker.$Closure$80 $_obj = new x10.glb.Worker.$Closure$80((java.lang.System[]) null, (x10.rtt.Type) null, (x10.rtt.Type) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            $serializer.write(this.$Queue);
            $serializer.write(this.$R);
            $serializer.write(this.loot$129244);
            $serializer.write(this.st$129243);
            $serializer.write(this.victim$129204);
            
        }
        
        // constructor just for allocation
        public $Closure$80(final java.lang.System[] $dummy, final x10.rtt.Type $Queue, final x10.rtt.Type $R) {
            x10.glb.Worker.$Closure$80.$initParams(this, $Queue, $R);
            
        }
        
        private x10.rtt.Type $Queue;
        private x10.rtt.Type $R;
        
        // initializer of type parameters
        public static void $initParams(final $Closure$80 $this, final x10.rtt.Type $Queue, final x10.rtt.Type $R) {
            $this.$Queue = $Queue;
            $this.$R = $R;
            
        }
        // synthetic type for parameter mangling
        public static final class __0$1x10$glb$Worker$1x10$glb$Worker$$Closure$80$$Queue$3x10$glb$Worker$$Closure$80$$R$2$2 {}
        
    
        
        public void $apply() {
            
            //#line 168 . "x10/glb/Worker.x10"
            final x10.glb.Worker t$129223 = ((x10.lang.PlaceLocalHandle<x10.glb.Worker<$Queue, $R>>)this.st$129243).$apply$G();
            
            //#line 168 . "x10/glb/Worker.x10"
            ((x10.glb.Worker<$Queue, $R>)t$129223).deal__0$1x10$glb$Worker$1x10$glb$Worker$$Queue$3x10$glb$Worker$$R$2$2(((x10.lang.PlaceLocalHandle)(this.st$129243)), ((x10.glb.TaskBag)(this.loot$129244)), (long)(this.victim$129204));
            
            //#line 168 . "x10/glb/Worker.x10"
            final x10.glb.Worker t$129224 = ((x10.lang.PlaceLocalHandle<x10.glb.Worker<$Queue, $R>>)this.st$129243).$apply$G();
            
            //#line 168 . "x10/glb/Worker.x10"
            ((x10.glb.Worker<$Queue, $R>)t$129224).waiting = false;
        }
        
        public x10.lang.PlaceLocalHandle<x10.glb.Worker<$Queue, $R>> st$129243;
        public x10.glb.TaskBag loot$129244;
        public long victim$129204;
        
        public $Closure$80(final x10.rtt.Type $Queue, final x10.rtt.Type $R, final x10.lang.PlaceLocalHandle<x10.glb.Worker<$Queue, $R>> st$129243, final x10.glb.TaskBag loot$129244, final long victim$129204, __0$1x10$glb$Worker$1x10$glb$Worker$$Closure$80$$Queue$3x10$glb$Worker$$Closure$80$$R$2$2 $dummy) {
            x10.glb.Worker.$Closure$80.$initParams(this, $Queue, $R);
             {
                ((x10.glb.Worker.$Closure$80<$Queue, $R>)this).st$129243 = ((x10.lang.PlaceLocalHandle)(st$129243));
                ((x10.glb.Worker.$Closure$80<$Queue, $R>)this).loot$129244 = ((x10.glb.TaskBag)(loot$129244));
                ((x10.glb.Worker.$Closure$80<$Queue, $R>)this).victim$129204 = victim$129204;
            }
        }
        
    }
    
    @x10.runtime.impl.java.X10Generated
    final public static class $Closure$81<$Queue, $R> extends x10.core.Ref implements x10.core.fun.VoidFun_0_0, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<$Closure$81> $RTT = 
            x10.rtt.StaticVoidFunType.<$Closure$81> make($Closure$81.class,
                                                         2,
                                                         new x10.rtt.Type[] {
                                                             x10.core.fun.VoidFun_0_0.$RTT
                                                         });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { if (i == 0) return $Queue; if (i == 1) return $R; return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static <$Queue, $R> x10.serialization.X10JavaSerializable $_deserialize_body(x10.glb.Worker.$Closure$81<$Queue, $R> $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            $_obj.$Queue = (x10.rtt.Type) $deserializer.readObject();
            $_obj.$R = (x10.rtt.Type) $deserializer.readObject();
            $_obj.loot$129244 = $deserializer.readObject();
            $_obj.st$129243 = $deserializer.readObject();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.glb.Worker.$Closure$81 $_obj = new x10.glb.Worker.$Closure$81((java.lang.System[]) null, (x10.rtt.Type) null, (x10.rtt.Type) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            $serializer.write(this.$Queue);
            $serializer.write(this.$R);
            $serializer.write(this.loot$129244);
            $serializer.write(this.st$129243);
            
        }
        
        // constructor just for allocation
        public $Closure$81(final java.lang.System[] $dummy, final x10.rtt.Type $Queue, final x10.rtt.Type $R) {
            x10.glb.Worker.$Closure$81.$initParams(this, $Queue, $R);
            
        }
        
        private x10.rtt.Type $Queue;
        private x10.rtt.Type $R;
        
        // initializer of type parameters
        public static void $initParams(final $Closure$81 $this, final x10.rtt.Type $Queue, final x10.rtt.Type $R) {
            $this.$Queue = $Queue;
            $this.$R = $R;
            
        }
        // synthetic type for parameter mangling
        public static final class __0$1x10$glb$Worker$1x10$glb$Worker$$Closure$81$$Queue$3x10$glb$Worker$$Closure$81$$R$2$2 {}
        
    
        
        public void $apply() {
            
            //#line 171 . "x10/glb/Worker.x10"
            final x10.glb.Worker t$129229 = ((x10.lang.PlaceLocalHandle<x10.glb.Worker<$Queue, $R>>)this.st$129243).$apply$G();
            
            //#line 171 . "x10/glb/Worker.x10"
            ((x10.glb.Worker<$Queue, $R>)t$129229).deal__0$1x10$glb$Worker$1x10$glb$Worker$$Queue$3x10$glb$Worker$$R$2$2(((x10.lang.PlaceLocalHandle)(this.st$129243)), ((x10.glb.TaskBag)(this.loot$129244)), (long)(-1L));
            
            //#line 171 . "x10/glb/Worker.x10"
            final x10.glb.Worker t$129230 = ((x10.lang.PlaceLocalHandle<x10.glb.Worker<$Queue, $R>>)this.st$129243).$apply$G();
            
            //#line 171 . "x10/glb/Worker.x10"
            ((x10.glb.Worker<$Queue, $R>)t$129230).waiting = false;
        }
        
        public x10.lang.PlaceLocalHandle<x10.glb.Worker<$Queue, $R>> st$129243;
        public x10.glb.TaskBag loot$129244;
        
        public $Closure$81(final x10.rtt.Type $Queue, final x10.rtt.Type $R, final x10.lang.PlaceLocalHandle<x10.glb.Worker<$Queue, $R>> st$129243, final x10.glb.TaskBag loot$129244, __0$1x10$glb$Worker$1x10$glb$Worker$$Closure$81$$Queue$3x10$glb$Worker$$Closure$81$$R$2$2 $dummy) {
            x10.glb.Worker.$Closure$81.$initParams(this, $Queue, $R);
             {
                ((x10.glb.Worker.$Closure$81<$Queue, $R>)this).st$129243 = ((x10.lang.PlaceLocalHandle)(st$129243));
                ((x10.glb.Worker.$Closure$81<$Queue, $R>)this).loot$129244 = ((x10.glb.TaskBag)(loot$129244));
            }
        }
        
    }
    
    @x10.runtime.impl.java.X10Generated
    final public static class $Closure$82<$Queue, $R> extends x10.core.Ref implements x10.core.fun.VoidFun_0_0, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<$Closure$82> $RTT = 
            x10.rtt.StaticVoidFunType.<$Closure$82> make($Closure$82.class,
                                                         2,
                                                         new x10.rtt.Type[] {
                                                             x10.core.fun.VoidFun_0_0.$RTT
                                                         });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { if (i == 0) return $Queue; if (i == 1) return $R; return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static <$Queue, $R> x10.serialization.X10JavaSerializable $_deserialize_body(x10.glb.Worker.$Closure$82<$Queue, $R> $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            $_obj.$Queue = (x10.rtt.Type) $deserializer.readObject();
            $_obj.$R = (x10.rtt.Type) $deserializer.readObject();
            $_obj.loot$129244 = $deserializer.readObject();
            $_obj.st$129243 = $deserializer.readObject();
            $_obj.victim$129204 = $deserializer.readLong();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.glb.Worker.$Closure$82 $_obj = new x10.glb.Worker.$Closure$82((java.lang.System[]) null, (x10.rtt.Type) null, (x10.rtt.Type) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            $serializer.write(this.$Queue);
            $serializer.write(this.$R);
            $serializer.write(this.loot$129244);
            $serializer.write(this.st$129243);
            $serializer.write(this.victim$129204);
            
        }
        
        // constructor just for allocation
        public $Closure$82(final java.lang.System[] $dummy, final x10.rtt.Type $Queue, final x10.rtt.Type $R) {
            x10.glb.Worker.$Closure$82.$initParams(this, $Queue, $R);
            
        }
        
        private x10.rtt.Type $Queue;
        private x10.rtt.Type $R;
        
        // initializer of type parameters
        public static void $initParams(final $Closure$82 $this, final x10.rtt.Type $Queue, final x10.rtt.Type $R) {
            $this.$Queue = $Queue;
            $this.$R = $R;
            
        }
        // synthetic type for parameter mangling
        public static final class __0$1x10$glb$Worker$1x10$glb$Worker$$Closure$82$$Queue$3x10$glb$Worker$$Closure$82$$R$2$2 {}
        
    
        
        public void $apply() {
            
            //#line 176 . "x10/glb/Worker.x10"
            try {{
                
                //#line 176 . "x10/glb/Worker.x10"
                final x10.glb.Worker t$129241 = ((x10.lang.PlaceLocalHandle<x10.glb.Worker<$Queue, $R>>)this.st$129243).$apply$G();
                
                //#line 176 . "x10/glb/Worker.x10"
                ((x10.glb.Worker<$Queue, $R>)t$129241).deal__0$1x10$glb$Worker$1x10$glb$Worker$$Queue$3x10$glb$Worker$$R$2$2(((x10.lang.PlaceLocalHandle)(this.st$129243)), ((x10.glb.TaskBag)(this.loot$129244)), (long)(this.victim$129204));
            }}catch (java.lang.Error __lowerer__var__0__) {
                
                //#line 176 . "x10/glb/Worker.x10"
                throw __lowerer__var__0__;
            }catch (java.lang.Throwable __lowerer__var__1__) {
                
                //#line 176 . "x10/glb/Worker.x10"
                throw x10.rtt.Types.EXCEPTION.isInstance(__lowerer__var__1__) ? (java.lang.RuntimeException)(__lowerer__var__1__) : new x10.lang.WrappedThrowable(__lowerer__var__1__);
            }
        }
        
        public x10.lang.PlaceLocalHandle<x10.glb.Worker<$Queue, $R>> st$129243;
        public x10.glb.TaskBag loot$129244;
        public long victim$129204;
        
        public $Closure$82(final x10.rtt.Type $Queue, final x10.rtt.Type $R, final x10.lang.PlaceLocalHandle<x10.glb.Worker<$Queue, $R>> st$129243, final x10.glb.TaskBag loot$129244, final long victim$129204, __0$1x10$glb$Worker$1x10$glb$Worker$$Closure$82$$Queue$3x10$glb$Worker$$Closure$82$$R$2$2 $dummy) {
            x10.glb.Worker.$Closure$82.$initParams(this, $Queue, $R);
             {
                ((x10.glb.Worker.$Closure$82<$Queue, $R>)this).st$129243 = ((x10.lang.PlaceLocalHandle)(st$129243));
                ((x10.glb.Worker.$Closure$82<$Queue, $R>)this).loot$129244 = ((x10.glb.TaskBag)(loot$129244));
                ((x10.glb.Worker.$Closure$82<$Queue, $R>)this).victim$129204 = victim$129204;
            }
        }
        
    }
    
    @x10.runtime.impl.java.X10Generated
    final public static class $Closure$83<$Queue, $R> extends x10.core.Ref implements x10.core.fun.VoidFun_0_0, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<$Closure$83> $RTT = 
            x10.rtt.StaticVoidFunType.<$Closure$83> make($Closure$83.class,
                                                         2,
                                                         new x10.rtt.Type[] {
                                                             x10.core.fun.VoidFun_0_0.$RTT
                                                         });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { if (i == 0) return $Queue; if (i == 1) return $R; return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static <$Queue, $R> x10.serialization.X10JavaSerializable $_deserialize_body(x10.glb.Worker.$Closure$83<$Queue, $R> $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            $_obj.$Queue = (x10.rtt.Type) $deserializer.readObject();
            $_obj.$R = (x10.rtt.Type) $deserializer.readObject();
            $_obj.st = $deserializer.readObject();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.glb.Worker.$Closure$83 $_obj = new x10.glb.Worker.$Closure$83((java.lang.System[]) null, (x10.rtt.Type) null, (x10.rtt.Type) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            $serializer.write(this.$Queue);
            $serializer.write(this.$R);
            $serializer.write(this.st);
            
        }
        
        // constructor just for allocation
        public $Closure$83(final java.lang.System[] $dummy, final x10.rtt.Type $Queue, final x10.rtt.Type $R) {
            x10.glb.Worker.$Closure$83.$initParams(this, $Queue, $R);
            
        }
        
        private x10.rtt.Type $Queue;
        private x10.rtt.Type $R;
        
        // initializer of type parameters
        public static void $initParams(final $Closure$83 $this, final x10.rtt.Type $Queue, final x10.rtt.Type $R) {
            $this.$Queue = $Queue;
            $this.$R = $R;
            
        }
        // synthetic type for parameter mangling
        public static final class __0$1x10$glb$Worker$1x10$glb$Worker$$Closure$83$$Queue$3x10$glb$Worker$$Closure$83$$R$2$2 {}
        
    
        
        public void $apply() {
            
            //#line 202 "x10/glb/Worker.x10"
            final x10.glb.Worker t$129262 = ((x10.lang.PlaceLocalHandle<x10.glb.Worker<$Queue, $R>>)this.st).$apply$G();
            
            //#line 202 "x10/glb/Worker.x10"
            ((x10.glb.Worker<$Queue, $R>)t$129262).waiting = false;
        }
        
        public x10.lang.PlaceLocalHandle<x10.glb.Worker<$Queue, $R>> st;
        
        public $Closure$83(final x10.rtt.Type $Queue, final x10.rtt.Type $R, final x10.lang.PlaceLocalHandle<x10.glb.Worker<$Queue, $R>> st, __0$1x10$glb$Worker$1x10$glb$Worker$$Closure$83$$Queue$3x10$glb$Worker$$Closure$83$$R$2$2 $dummy) {
            x10.glb.Worker.$Closure$83.$initParams(this, $Queue, $R);
             {
                ((x10.glb.Worker.$Closure$83<$Queue, $R>)this).st = ((x10.lang.PlaceLocalHandle)(st));
            }
        }
        
    }
    
    @x10.runtime.impl.java.X10Generated
    final public static class $Closure$84<$Queue, $R> extends x10.core.Ref implements x10.core.fun.VoidFun_0_0, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<$Closure$84> $RTT = 
            x10.rtt.StaticVoidFunType.<$Closure$84> make($Closure$84.class,
                                                         2,
                                                         new x10.rtt.Type[] {
                                                             x10.core.fun.VoidFun_0_0.$RTT
                                                         });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { if (i == 0) return $Queue; if (i == 1) return $R; return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static <$Queue, $R> x10.serialization.X10JavaSerializable $_deserialize_body(x10.glb.Worker.$Closure$84<$Queue, $R> $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            $_obj.$Queue = (x10.rtt.Type) $deserializer.readObject();
            $_obj.$R = (x10.rtt.Type) $deserializer.readObject();
            $_obj.st = $deserializer.readObject();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.glb.Worker.$Closure$84 $_obj = new x10.glb.Worker.$Closure$84((java.lang.System[]) null, (x10.rtt.Type) null, (x10.rtt.Type) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            $serializer.write(this.$Queue);
            $serializer.write(this.$R);
            $serializer.write(this.st);
            
        }
        
        // constructor just for allocation
        public $Closure$84(final java.lang.System[] $dummy, final x10.rtt.Type $Queue, final x10.rtt.Type $R) {
            x10.glb.Worker.$Closure$84.$initParams(this, $Queue, $R);
            
        }
        
        private x10.rtt.Type $Queue;
        private x10.rtt.Type $R;
        
        // initializer of type parameters
        public static void $initParams(final $Closure$84 $this, final x10.rtt.Type $Queue, final x10.rtt.Type $R) {
            $this.$Queue = $Queue;
            $this.$R = $R;
            
        }
        // synthetic type for parameter mangling
        public static final class __0$1x10$glb$Worker$1x10$glb$Worker$$Closure$84$$Queue$3x10$glb$Worker$$Closure$84$$R$2$2 {}
        
    
        
        public void $apply() {
            
            //#line 204 "x10/glb/Worker.x10"
            final x10.glb.Worker t$129264 = ((x10.lang.PlaceLocalHandle<x10.glb.Worker<$Queue, $R>>)this.st).$apply$G();
            
            //#line 204 "x10/glb/Worker.x10"
            ((x10.glb.Worker<$Queue, $R>)t$129264).waiting = false;
        }
        
        public x10.lang.PlaceLocalHandle<x10.glb.Worker<$Queue, $R>> st;
        
        public $Closure$84(final x10.rtt.Type $Queue, final x10.rtt.Type $R, final x10.lang.PlaceLocalHandle<x10.glb.Worker<$Queue, $R>> st, __0$1x10$glb$Worker$1x10$glb$Worker$$Closure$84$$Queue$3x10$glb$Worker$$Closure$84$$R$2$2 $dummy) {
            x10.glb.Worker.$Closure$84.$initParams(this, $Queue, $R);
             {
                ((x10.glb.Worker.$Closure$84<$Queue, $R>)this).st = ((x10.lang.PlaceLocalHandle)(st));
            }
        }
        
    }
    
    @x10.runtime.impl.java.X10Generated
    final public static class $Closure$85<$Queue, $R> extends x10.core.Ref implements x10.core.fun.VoidFun_0_0, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<$Closure$85> $RTT = 
            x10.rtt.StaticVoidFunType.<$Closure$85> make($Closure$85.class,
                                                         2,
                                                         new x10.rtt.Type[] {
                                                             x10.core.fun.VoidFun_0_0.$RTT
                                                         });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { if (i == 0) return $Queue; if (i == 1) return $R; return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static <$Queue, $R> x10.serialization.X10JavaSerializable $_deserialize_body(x10.glb.Worker.$Closure$85<$Queue, $R> $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            $_obj.$Queue = (x10.rtt.Type) $deserializer.readObject();
            $_obj.$R = (x10.rtt.Type) $deserializer.readObject();
            $_obj.p = $deserializer.readLong();
            $_obj.st = $deserializer.readObject();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.glb.Worker.$Closure$85 $_obj = new x10.glb.Worker.$Closure$85((java.lang.System[]) null, (x10.rtt.Type) null, (x10.rtt.Type) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            $serializer.write(this.$Queue);
            $serializer.write(this.$R);
            $serializer.write(this.p);
            $serializer.write(this.st);
            
        }
        
        // constructor just for allocation
        public $Closure$85(final java.lang.System[] $dummy, final x10.rtt.Type $Queue, final x10.rtt.Type $R) {
            x10.glb.Worker.$Closure$85.$initParams(this, $Queue, $R);
            
        }
        
        private x10.rtt.Type $Queue;
        private x10.rtt.Type $R;
        
        // initializer of type parameters
        public static void $initParams(final $Closure$85 $this, final x10.rtt.Type $Queue, final x10.rtt.Type $R) {
            $this.$Queue = $Queue;
            $this.$R = $R;
            
        }
        // synthetic type for parameter mangling
        public static final class __0$1x10$glb$Worker$1x10$glb$Worker$$Closure$85$$Queue$3x10$glb$Worker$$Closure$85$$R$2$2 {}
        
    
        
        public void $apply() {
            
            //#line 230 "x10/glb/Worker.x10"
            final x10.glb.Worker t$129276 = ((x10.lang.PlaceLocalHandle<x10.glb.Worker<$Queue, $R>>)this.st).$apply$G();
            
            //#line 230 "x10/glb/Worker.x10"
            ((x10.glb.Worker<$Queue, $R>)t$129276).request__0$1x10$glb$Worker$1x10$glb$Worker$$Queue$3x10$glb$Worker$$R$2$2(((x10.lang.PlaceLocalHandle)(this.st)), (long)(this.p), (boolean)(false));
        }
        
        public x10.lang.PlaceLocalHandle<x10.glb.Worker<$Queue, $R>> st;
        public long p;
        
        public $Closure$85(final x10.rtt.Type $Queue, final x10.rtt.Type $R, final x10.lang.PlaceLocalHandle<x10.glb.Worker<$Queue, $R>> st, final long p, __0$1x10$glb$Worker$1x10$glb$Worker$$Closure$85$$Queue$3x10$glb$Worker$$Closure$85$$R$2$2 $dummy) {
            x10.glb.Worker.$Closure$85.$initParams(this, $Queue, $R);
             {
                ((x10.glb.Worker.$Closure$85<$Queue, $R>)this).st = ((x10.lang.PlaceLocalHandle)(st));
                ((x10.glb.Worker.$Closure$85<$Queue, $R>)this).p = p;
            }
        }
        
    }
    
    @x10.runtime.impl.java.X10Generated
    final public static class $Closure$86<$Queue, $R> extends x10.core.Ref implements x10.core.fun.VoidFun_0_0, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<$Closure$86> $RTT = 
            x10.rtt.StaticVoidFunType.<$Closure$86> make($Closure$86.class,
                                                         2,
                                                         new x10.rtt.Type[] {
                                                             x10.core.fun.VoidFun_0_0.$RTT
                                                         });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { if (i == 0) return $Queue; if (i == 1) return $R; return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static <$Queue, $R> x10.serialization.X10JavaSerializable $_deserialize_body(x10.glb.Worker.$Closure$86<$Queue, $R> $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            $_obj.$Queue = (x10.rtt.Type) $deserializer.readObject();
            $_obj.$R = (x10.rtt.Type) $deserializer.readObject();
            $_obj.p = $deserializer.readLong();
            $_obj.st = $deserializer.readObject();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.glb.Worker.$Closure$86 $_obj = new x10.glb.Worker.$Closure$86((java.lang.System[]) null, (x10.rtt.Type) null, (x10.rtt.Type) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            $serializer.write(this.$Queue);
            $serializer.write(this.$R);
            $serializer.write(this.p);
            $serializer.write(this.st);
            
        }
        
        // constructor just for allocation
        public $Closure$86(final java.lang.System[] $dummy, final x10.rtt.Type $Queue, final x10.rtt.Type $R) {
            x10.glb.Worker.$Closure$86.$initParams(this, $Queue, $R);
            
        }
        
        private x10.rtt.Type $Queue;
        private x10.rtt.Type $R;
        
        // initializer of type parameters
        public static void $initParams(final $Closure$86 $this, final x10.rtt.Type $Queue, final x10.rtt.Type $R) {
            $this.$Queue = $Queue;
            $this.$R = $R;
            
        }
        // synthetic type for parameter mangling
        public static final class __0$1x10$glb$Worker$1x10$glb$Worker$$Closure$86$$Queue$3x10$glb$Worker$$Closure$86$$R$2$2 {}
        
    
        
        public void $apply() {
            
            //#line 241 "x10/glb/Worker.x10"
            final x10.glb.Worker t$129293 = ((x10.lang.PlaceLocalHandle<x10.glb.Worker<$Queue, $R>>)this.st).$apply$G();
            
            //#line 241 "x10/glb/Worker.x10"
            ((x10.glb.Worker<$Queue, $R>)t$129293).request__0$1x10$glb$Worker$1x10$glb$Worker$$Queue$3x10$glb$Worker$$R$2$2(((x10.lang.PlaceLocalHandle)(this.st)), (long)(this.p), (boolean)(true));
        }
        
        public x10.lang.PlaceLocalHandle<x10.glb.Worker<$Queue, $R>> st;
        public long p;
        
        public $Closure$86(final x10.rtt.Type $Queue, final x10.rtt.Type $R, final x10.lang.PlaceLocalHandle<x10.glb.Worker<$Queue, $R>> st, final long p, __0$1x10$glb$Worker$1x10$glb$Worker$$Closure$86$$Queue$3x10$glb$Worker$$Closure$86$$R$2$2 $dummy) {
            x10.glb.Worker.$Closure$86.$initParams(this, $Queue, $R);
             {
                ((x10.glb.Worker.$Closure$86<$Queue, $R>)this).st = ((x10.lang.PlaceLocalHandle)(st));
                ((x10.glb.Worker.$Closure$86<$Queue, $R>)this).p = p;
            }
        }
        
    }
    
    @x10.runtime.impl.java.X10Generated
    final public static class $Closure$87<$Queue, $R> extends x10.core.Ref implements x10.core.fun.VoidFun_0_0, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<$Closure$87> $RTT = 
            x10.rtt.StaticVoidFunType.<$Closure$87> make($Closure$87.class,
                                                         2,
                                                         new x10.rtt.Type[] {
                                                             x10.core.fun.VoidFun_0_0.$RTT
                                                         });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { if (i == 0) return $Queue; if (i == 1) return $R; return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static <$Queue, $R> x10.serialization.X10JavaSerializable $_deserialize_body(x10.glb.Worker.$Closure$87<$Queue, $R> $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            $_obj.$Queue = (x10.rtt.Type) $deserializer.readObject();
            $_obj.$R = (x10.rtt.Type) $deserializer.readObject();
            $_obj.st = $deserializer.readObject();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.glb.Worker.$Closure$87 $_obj = new x10.glb.Worker.$Closure$87((java.lang.System[]) null, (x10.rtt.Type) null, (x10.rtt.Type) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            $serializer.write(this.$Queue);
            $serializer.write(this.$R);
            $serializer.write(this.st);
            
        }
        
        // constructor just for allocation
        public $Closure$87(final java.lang.System[] $dummy, final x10.rtt.Type $Queue, final x10.rtt.Type $R) {
            x10.glb.Worker.$Closure$87.$initParams(this, $Queue, $R);
            
        }
        
        private x10.rtt.Type $Queue;
        private x10.rtt.Type $R;
        
        // initializer of type parameters
        public static void $initParams(final $Closure$87 $this, final x10.rtt.Type $Queue, final x10.rtt.Type $R) {
            $this.$Queue = $Queue;
            $this.$R = $R;
            
        }
        // synthetic type for parameter mangling
        public static final class __0$1x10$glb$Worker$1x10$glb$Worker$$Closure$87$$Queue$3x10$glb$Worker$$Closure$87$$R$2$2 {}
        
    
        
        public void $apply() {
            
            //#line 261 "x10/glb/Worker.x10"
            final x10.glb.Worker t$128859 = ((x10.lang.PlaceLocalHandle<x10.glb.Worker<$Queue, $R>>)this.st).$apply$G();
            
            //#line 261 "x10/glb/Worker.x10"
            ((x10.glb.Worker<$Queue, $R>)t$128859).waiting = false;
        }
        
        public x10.lang.PlaceLocalHandle<x10.glb.Worker<$Queue, $R>> st;
        
        public $Closure$87(final x10.rtt.Type $Queue, final x10.rtt.Type $R, final x10.lang.PlaceLocalHandle<x10.glb.Worker<$Queue, $R>> st, __0$1x10$glb$Worker$1x10$glb$Worker$$Closure$87$$Queue$3x10$glb$Worker$$Closure$87$$R$2$2 $dummy) {
            x10.glb.Worker.$Closure$87.$initParams(this, $Queue, $R);
             {
                ((x10.glb.Worker.$Closure$87<$Queue, $R>)this).st = ((x10.lang.PlaceLocalHandle)(st));
            }
        }
        
    }
    
    @x10.runtime.impl.java.X10Generated
    final public static class $Closure$88<$Queue, $R> extends x10.core.Ref implements x10.core.fun.VoidFun_0_0, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<$Closure$88> $RTT = 
            x10.rtt.StaticVoidFunType.<$Closure$88> make($Closure$88.class,
                                                         2,
                                                         new x10.rtt.Type[] {
                                                             x10.core.fun.VoidFun_0_0.$RTT
                                                         });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { if (i == 0) return $Queue; if (i == 1) return $R; return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static <$Queue, $R> x10.serialization.X10JavaSerializable $_deserialize_body(x10.glb.Worker.$Closure$88<$Queue, $R> $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            $_obj.$Queue = (x10.rtt.Type) $deserializer.readObject();
            $_obj.$R = (x10.rtt.Type) $deserializer.readObject();
            $_obj.st = $deserializer.readObject();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.glb.Worker.$Closure$88 $_obj = new x10.glb.Worker.$Closure$88((java.lang.System[]) null, (x10.rtt.Type) null, (x10.rtt.Type) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            $serializer.write(this.$Queue);
            $serializer.write(this.$R);
            $serializer.write(this.st);
            
        }
        
        // constructor just for allocation
        public $Closure$88(final java.lang.System[] $dummy, final x10.rtt.Type $Queue, final x10.rtt.Type $R) {
            x10.glb.Worker.$Closure$88.$initParams(this, $Queue, $R);
            
        }
        
        private x10.rtt.Type $Queue;
        private x10.rtt.Type $R;
        
        // initializer of type parameters
        public static void $initParams(final $Closure$88 $this, final x10.rtt.Type $Queue, final x10.rtt.Type $R) {
            $this.$Queue = $Queue;
            $this.$R = $R;
            
        }
        // synthetic type for parameter mangling
        public static final class __0$1x10$glb$Worker$1x10$glb$Worker$$Closure$88$$Queue$3x10$glb$Worker$$Closure$88$$R$2$2 {}
        
    
        
        public void $apply() {
            
            //#line 408 "x10/glb/Worker.x10"
            try {{
                
                //#line 408 "x10/glb/Worker.x10"
                final x10.glb.Worker t$129359 = ((x10.lang.PlaceLocalHandle<x10.glb.Worker<$Queue, $R>>)this.st).$apply$G();
                
                //#line 408 "x10/glb/Worker.x10"
                ((x10.glb.Worker<$Queue, $R>)t$129359).main__0$1x10$glb$Worker$1x10$glb$Worker$$Queue$3x10$glb$Worker$$R$2$2(((x10.lang.PlaceLocalHandle)(this.st)));
            }}catch (java.lang.Error __lowerer__var__0__) {
                
                //#line 408 "x10/glb/Worker.x10"
                throw __lowerer__var__0__;
            }catch (java.lang.Throwable __lowerer__var__1__) {
                
                //#line 408 "x10/glb/Worker.x10"
                throw x10.rtt.Types.EXCEPTION.isInstance(__lowerer__var__1__) ? (java.lang.RuntimeException)(__lowerer__var__1__) : new x10.lang.WrappedThrowable(__lowerer__var__1__);
            }
        }
        
        public x10.lang.PlaceLocalHandle<x10.glb.Worker<$Queue, $R>> st;
        
        public $Closure$88(final x10.rtt.Type $Queue, final x10.rtt.Type $R, final x10.lang.PlaceLocalHandle<x10.glb.Worker<$Queue, $R>> st, __0$1x10$glb$Worker$1x10$glb$Worker$$Closure$88$$Queue$3x10$glb$Worker$$Closure$88$$R$2$2 $dummy) {
            x10.glb.Worker.$Closure$88.$initParams(this, $Queue, $R);
             {
                ((x10.glb.Worker.$Closure$88<$Queue, $R>)this).st = ((x10.lang.PlaceLocalHandle)(st));
            }
        }
        
    }
    
    @x10.runtime.impl.java.X10Generated
    final public static class $Closure$89<$Queue, $R> extends x10.core.Ref implements x10.core.fun.VoidFun_0_0, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<$Closure$89> $RTT = 
            x10.rtt.StaticVoidFunType.<$Closure$89> make($Closure$89.class,
                                                         2,
                                                         new x10.rtt.Type[] {
                                                             x10.core.fun.VoidFun_0_0.$RTT
                                                         });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { if (i == 0) return $Queue; if (i == 1) return $R; return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static <$Queue, $R> x10.serialization.X10JavaSerializable $_deserialize_body(x10.glb.Worker.$Closure$89<$Queue, $R> $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            $_obj.$Queue = (x10.rtt.Type) $deserializer.readObject();
            $_obj.$R = (x10.rtt.Type) $deserializer.readObject();
            $_obj.st = $deserializer.readObject();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.glb.Worker.$Closure$89 $_obj = new x10.glb.Worker.$Closure$89((java.lang.System[]) null, (x10.rtt.Type) null, (x10.rtt.Type) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            $serializer.write(this.$Queue);
            $serializer.write(this.$R);
            $serializer.write(this.st);
            
        }
        
        // constructor just for allocation
        public $Closure$89(final java.lang.System[] $dummy, final x10.rtt.Type $Queue, final x10.rtt.Type $R) {
            x10.glb.Worker.$Closure$89.$initParams(this, $Queue, $R);
            
        }
        
        private x10.rtt.Type $Queue;
        private x10.rtt.Type $R;
        
        // initializer of type parameters
        public static void $initParams(final $Closure$89 $this, final x10.rtt.Type $Queue, final x10.rtt.Type $R) {
            $this.$Queue = $Queue;
            $this.$R = $R;
            
        }
        // synthetic type for parameter mangling
        public static final class __0$1x10$glb$Worker$1x10$glb$Worker$$Closure$89$$Queue$3x10$glb$Worker$$Closure$89$$R$2$2 {}
        
    
        
        public void $apply() {
            
            //#line 416 "x10/glb/Worker.x10"
            try {{
                
                //#line 416 "x10/glb/Worker.x10"
                final x10.glb.Worker t$129364 = ((x10.lang.PlaceLocalHandle<x10.glb.Worker<$Queue, $R>>)this.st).$apply$G();
                
                //#line 416 "x10/glb/Worker.x10"
                ((x10.glb.Worker<$Queue, $R>)t$129364).main__0$1x10$glb$Worker$1x10$glb$Worker$$Queue$3x10$glb$Worker$$R$2$2(((x10.lang.PlaceLocalHandle)(this.st)));
            }}catch (java.lang.Error __lowerer__var__0__) {
                
                //#line 416 "x10/glb/Worker.x10"
                throw __lowerer__var__0__;
            }catch (java.lang.Throwable __lowerer__var__1__) {
                
                //#line 416 "x10/glb/Worker.x10"
                throw x10.rtt.Types.EXCEPTION.isInstance(__lowerer__var__1__) ? (java.lang.RuntimeException)(__lowerer__var__1__) : new x10.lang.WrappedThrowable(__lowerer__var__1__);
            }
        }
        
        public x10.lang.PlaceLocalHandle<x10.glb.Worker<$Queue, $R>> st;
        
        public $Closure$89(final x10.rtt.Type $Queue, final x10.rtt.Type $R, final x10.lang.PlaceLocalHandle<x10.glb.Worker<$Queue, $R>> st, __0$1x10$glb$Worker$1x10$glb$Worker$$Closure$89$$Queue$3x10$glb$Worker$$Closure$89$$R$2$2 $dummy) {
            x10.glb.Worker.$Closure$89.$initParams(this, $Queue, $R);
             {
                ((x10.glb.Worker.$Closure$89<$Queue, $R>)this).st = ((x10.lang.PlaceLocalHandle)(st));
            }
        }
        
    }
    
    @x10.runtime.impl.java.X10Generated
    final public static class $Closure$90<$Queue, $R> extends x10.core.Ref implements x10.core.fun.VoidFun_0_0, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<$Closure$90> $RTT = 
            x10.rtt.StaticVoidFunType.<$Closure$90> make($Closure$90.class,
                                                         2,
                                                         new x10.rtt.Type[] {
                                                             x10.core.fun.VoidFun_0_0.$RTT
                                                         });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { if (i == 0) return $Queue; if (i == 1) return $R; return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static <$Queue, $R> x10.serialization.X10JavaSerializable $_deserialize_body(x10.glb.Worker.$Closure$90<$Queue, $R> $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            $_obj.$Queue = (x10.rtt.Type) $deserializer.readObject();
            $_obj.$R = (x10.rtt.Type) $deserializer.readObject();
            $_obj.st = $deserializer.readObject();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.glb.Worker.$Closure$90 $_obj = new x10.glb.Worker.$Closure$90((java.lang.System[]) null, (x10.rtt.Type) null, (x10.rtt.Type) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            $serializer.write(this.$Queue);
            $serializer.write(this.$R);
            $serializer.write(this.st);
            
        }
        
        // constructor just for allocation
        public $Closure$90(final java.lang.System[] $dummy, final x10.rtt.Type $Queue, final x10.rtt.Type $R) {
            x10.glb.Worker.$Closure$90.$initParams(this, $Queue, $R);
            
        }
        
        private x10.rtt.Type $Queue;
        private x10.rtt.Type $R;
        
        // initializer of type parameters
        public static void $initParams(final $Closure$90 $this, final x10.rtt.Type $Queue, final x10.rtt.Type $R) {
            $this.$Queue = $Queue;
            $this.$R = $R;
            
        }
        // synthetic type for parameter mangling
        public static final class __0$1x10$glb$Worker$1x10$glb$Worker$$Closure$90$$Queue$3x10$glb$Worker$$Closure$90$$R$2$2 {}
        
    
        
        public void $apply() {
            
            //#line 412 "x10/glb/Worker.x10"
            try {{
                
                //#line 413 "x10/glb/Worker.x10"
                final long max$129372 = ((long)x10.x10rt.X10RT.hereId());
                
                //#line 414 "x10/glb/Worker.x10"
                final long t$129373 = ((max$129372) - (((long)(31L))));
                
                //#line 414 "x10/glb/Worker.x10"
                final long min$129374 = java.lang.Math.max(((long)(t$129373)),((long)(0L)));
                
                //#line 415 "x10/glb/Worker.x10"
                long j$129367 = min$129374;
                
                //#line 415 "x10/glb/Worker.x10"
                for (;
                     true;
                     ) {
                    
                    //#line 415 "x10/glb/Worker.x10"
                    final boolean t$129369 = ((j$129367) <= (((long)(max$129372))));
                    
                    //#line 415 "x10/glb/Worker.x10"
                    if (!(t$129369)) {
                        
                        //#line 415 "x10/glb/Worker.x10"
                        break;
                    }
                    
                    //#line 416 "x10/glb/Worker.x10"
                    final x10.lang.Place alloc$129363 = ((x10.lang.Place)(new x10.lang.Place((java.lang.System[]) null)));
                    
                    //#line 416 "x10/glb/Worker.x10"
                    alloc$129363.x10$lang$Place$$init$S(j$129367);
                    
                    //#line 416 "x10/glb/Worker.x10"
                    x10.xrx.Runtime.runAsync(((x10.lang.Place)(alloc$129363)), ((x10.core.fun.VoidFun_0_0)(new x10.glb.Worker.$Closure$89<$Queue, $R>($Queue, $R, ((x10.lang.PlaceLocalHandle<x10.glb.Worker<$Queue, $R>>)(this.st)), (x10.glb.Worker.$Closure$89.__0$1x10$glb$Worker$1x10$glb$Worker$$Closure$89$$Queue$3x10$glb$Worker$$Closure$89$$R$2$2) null))), ((x10.xrx.Runtime.Profile)(null)));
                    
                    //#line 415 "x10/glb/Worker.x10"
                    final long t$129366 = ((j$129367) + (((long)(1L))));
                    
                    //#line 415 "x10/glb/Worker.x10"
                    j$129367 = t$129366;
                }
            }}catch (java.lang.Error __lowerer__var__0__) {
                
                //#line 412 "x10/glb/Worker.x10"
                throw __lowerer__var__0__;
            }catch (java.lang.Throwable __lowerer__var__1__) {
                
                //#line 412 "x10/glb/Worker.x10"
                throw x10.rtt.Types.EXCEPTION.isInstance(__lowerer__var__1__) ? (java.lang.RuntimeException)(__lowerer__var__1__) : new x10.lang.WrappedThrowable(__lowerer__var__1__);
            }
        }
        
        public x10.lang.PlaceLocalHandle<x10.glb.Worker<$Queue, $R>> st;
        
        public $Closure$90(final x10.rtt.Type $Queue, final x10.rtt.Type $R, final x10.lang.PlaceLocalHandle<x10.glb.Worker<$Queue, $R>> st, __0$1x10$glb$Worker$1x10$glb$Worker$$Closure$90$$Queue$3x10$glb$Worker$$Closure$90$$R$2$2 $dummy) {
            x10.glb.Worker.$Closure$90.$initParams(this, $Queue, $R);
             {
                ((x10.glb.Worker.$Closure$90<$Queue, $R>)this).st = ((x10.lang.PlaceLocalHandle)(st));
            }
        }
        
    }
    
    @x10.runtime.impl.java.X10Generated
    final public static class $Closure$91<$Queue, $R> extends x10.core.Ref implements x10.core.fun.VoidFun_0_0, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<$Closure$91> $RTT = 
            x10.rtt.StaticVoidFunType.<$Closure$91> make($Closure$91.class,
                                                         2,
                                                         new x10.rtt.Type[] {
                                                             x10.core.fun.VoidFun_0_0.$RTT
                                                         });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { if (i == 0) return $Queue; if (i == 1) return $R; return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static <$Queue, $R> x10.serialization.X10JavaSerializable $_deserialize_body(x10.glb.Worker.$Closure$91<$Queue, $R> $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            $_obj.$Queue = (x10.rtt.Type) $deserializer.readObject();
            $_obj.$R = (x10.rtt.Type) $deserializer.readObject();
            $_obj.st = $deserializer.readObject();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.glb.Worker.$Closure$91 $_obj = new x10.glb.Worker.$Closure$91((java.lang.System[]) null, (x10.rtt.Type) null, (x10.rtt.Type) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            $serializer.write(this.$Queue);
            $serializer.write(this.$R);
            $serializer.write(this.st);
            
        }
        
        // constructor just for allocation
        public $Closure$91(final java.lang.System[] $dummy, final x10.rtt.Type $Queue, final x10.rtt.Type $R) {
            x10.glb.Worker.$Closure$91.$initParams(this, $Queue, $R);
            
        }
        
        private x10.rtt.Type $Queue;
        private x10.rtt.Type $R;
        
        // initializer of type parameters
        public static void $initParams(final $Closure$91 $this, final x10.rtt.Type $Queue, final x10.rtt.Type $R) {
            $this.$Queue = $Queue;
            $this.$R = $R;
            
        }
        // synthetic type for parameter mangling
        public static final class __0$1x10$glb$Worker$1x10$glb$Worker$$Closure$91$$Queue$3x10$glb$Worker$$Closure$91$$R$2$2 {}
        
    
        
        public void $apply() {
            
            //#line 432 "x10/glb/Worker.x10"
            try {{
                
                //#line 432 "x10/glb/Worker.x10"
                final x10.glb.Worker this$129382 = ((x10.lang.PlaceLocalHandle<x10.glb.Worker<$Queue, $R>>)this.st).$apply$G();
                
                //#line 461 . "x10/glb/Worker.x10"
                final x10.glb.Context alloc$129378 = ((x10.glb.Context)(new x10.glb.Context<$Queue, $R>((java.lang.System[]) null, $Queue, $R)));
                
                //#line 25 ... "x10/glb/Context.x10"
                final x10.lang.PlaceLocalHandle t$129377 = (x10.lang.PlaceLocalHandle<x10.glb.Worker<$Queue, $R>>) x10.rtt.Types.zeroValue(x10.rtt.ParameterizedType.make(x10.lang.PlaceLocalHandle.$RTT, x10.rtt.ParameterizedType.make(x10.glb.Worker.$RTT, $Queue, $R)));
                
                //#line 20 ... "x10/glb/Context.x10"
                ((x10.glb.Context<$Queue, $R>)alloc$129378).st = t$129377;
                
                //#line 31 .. "x10/glb/Context.x10"
                ((x10.glb.Context<$Queue, $R>)alloc$129378).st = ((x10.lang.PlaceLocalHandle)(this.st));
                
                //#line 461 . "x10/glb/Worker.x10"
                ((x10.glb.Worker<$Queue, $R>)this$129382).context = ((x10.glb.Context)(alloc$129378));
            }}catch (java.lang.Error __lowerer__var__0__) {
                
                //#line 432 "x10/glb/Worker.x10"
                throw __lowerer__var__0__;
            }catch (java.lang.Throwable __lowerer__var__1__) {
                
                //#line 432 "x10/glb/Worker.x10"
                throw x10.rtt.Types.EXCEPTION.isInstance(__lowerer__var__1__) ? (java.lang.RuntimeException)(__lowerer__var__1__) : new x10.lang.WrappedThrowable(__lowerer__var__1__);
            }
        }
        
        public x10.lang.PlaceLocalHandle<x10.glb.Worker<$Queue, $R>> st;
        
        public $Closure$91(final x10.rtt.Type $Queue, final x10.rtt.Type $R, final x10.lang.PlaceLocalHandle<x10.glb.Worker<$Queue, $R>> st, __0$1x10$glb$Worker$1x10$glb$Worker$$Closure$91$$Queue$3x10$glb$Worker$$Closure$91$$R$2$2 $dummy) {
            x10.glb.Worker.$Closure$91.$initParams(this, $Queue, $R);
             {
                ((x10.glb.Worker.$Closure$91<$Queue, $R>)this).st = ((x10.lang.PlaceLocalHandle)(st));
            }
        }
        
    }
    
    @x10.runtime.impl.java.X10Generated
    final public static class $Closure$92<$Queue, $R> extends x10.core.Ref implements x10.core.fun.VoidFun_0_0, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<$Closure$92> $RTT = 
            x10.rtt.StaticVoidFunType.<$Closure$92> make($Closure$92.class,
                                                         2,
                                                         new x10.rtt.Type[] {
                                                             x10.core.fun.VoidFun_0_0.$RTT
                                                         });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { if (i == 0) return $Queue; if (i == 1) return $R; return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static <$Queue, $R> x10.serialization.X10JavaSerializable $_deserialize_body(x10.glb.Worker.$Closure$92<$Queue, $R> $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            $_obj.$Queue = (x10.rtt.Type) $deserializer.readObject();
            $_obj.$R = (x10.rtt.Type) $deserializer.readObject();
            $_obj.st = $deserializer.readObject();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.glb.Worker.$Closure$92 $_obj = new x10.glb.Worker.$Closure$92((java.lang.System[]) null, (x10.rtt.Type) null, (x10.rtt.Type) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            $serializer.write(this.$Queue);
            $serializer.write(this.$R);
            $serializer.write(this.st);
            
        }
        
        // constructor just for allocation
        public $Closure$92(final java.lang.System[] $dummy, final x10.rtt.Type $Queue, final x10.rtt.Type $R) {
            x10.glb.Worker.$Closure$92.$initParams(this, $Queue, $R);
            
        }
        
        private x10.rtt.Type $Queue;
        private x10.rtt.Type $R;
        
        // initializer of type parameters
        public static void $initParams(final $Closure$92 $this, final x10.rtt.Type $Queue, final x10.rtt.Type $R) {
            $this.$Queue = $Queue;
            $this.$R = $R;
            
        }
        // synthetic type for parameter mangling
        public static final class __0$1x10$glb$Worker$1x10$glb$Worker$$Closure$92$$Queue$3x10$glb$Worker$$Closure$92$$R$2$2 {}
        
    
        
        public void $apply() {
            
            //#line 440 "x10/glb/Worker.x10"
            try {{
                
                //#line 440 "x10/glb/Worker.x10"
                final x10.glb.Worker this$129391 = ((x10.lang.PlaceLocalHandle<x10.glb.Worker<$Queue, $R>>)this.st).$apply$G();
                
                //#line 461 . "x10/glb/Worker.x10"
                final x10.glb.Context alloc$129387 = ((x10.glb.Context)(new x10.glb.Context<$Queue, $R>((java.lang.System[]) null, $Queue, $R)));
                
                //#line 25 ... "x10/glb/Context.x10"
                final x10.lang.PlaceLocalHandle t$129386 = (x10.lang.PlaceLocalHandle<x10.glb.Worker<$Queue, $R>>) x10.rtt.Types.zeroValue(x10.rtt.ParameterizedType.make(x10.lang.PlaceLocalHandle.$RTT, x10.rtt.ParameterizedType.make(x10.glb.Worker.$RTT, $Queue, $R)));
                
                //#line 20 ... "x10/glb/Context.x10"
                ((x10.glb.Context<$Queue, $R>)alloc$129387).st = t$129386;
                
                //#line 31 .. "x10/glb/Context.x10"
                ((x10.glb.Context<$Queue, $R>)alloc$129387).st = ((x10.lang.PlaceLocalHandle)(this.st));
                
                //#line 461 . "x10/glb/Worker.x10"
                ((x10.glb.Worker<$Queue, $R>)this$129391).context = ((x10.glb.Context)(alloc$129387));
            }}catch (java.lang.Error __lowerer__var__0__) {
                
                //#line 440 "x10/glb/Worker.x10"
                throw __lowerer__var__0__;
            }catch (java.lang.Throwable __lowerer__var__1__) {
                
                //#line 440 "x10/glb/Worker.x10"
                throw x10.rtt.Types.EXCEPTION.isInstance(__lowerer__var__1__) ? (java.lang.RuntimeException)(__lowerer__var__1__) : new x10.lang.WrappedThrowable(__lowerer__var__1__);
            }
        }
        
        public x10.lang.PlaceLocalHandle<x10.glb.Worker<$Queue, $R>> st;
        
        public $Closure$92(final x10.rtt.Type $Queue, final x10.rtt.Type $R, final x10.lang.PlaceLocalHandle<x10.glb.Worker<$Queue, $R>> st, __0$1x10$glb$Worker$1x10$glb$Worker$$Closure$92$$Queue$3x10$glb$Worker$$Closure$92$$R$2$2 $dummy) {
            x10.glb.Worker.$Closure$92.$initParams(this, $Queue, $R);
             {
                ((x10.glb.Worker.$Closure$92<$Queue, $R>)this).st = ((x10.lang.PlaceLocalHandle)(st));
            }
        }
        
    }
    
    @x10.runtime.impl.java.X10Generated
    final public static class $Closure$93<$Queue, $R> extends x10.core.Ref implements x10.core.fun.VoidFun_0_0, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<$Closure$93> $RTT = 
            x10.rtt.StaticVoidFunType.<$Closure$93> make($Closure$93.class,
                                                         2,
                                                         new x10.rtt.Type[] {
                                                             x10.core.fun.VoidFun_0_0.$RTT
                                                         });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { if (i == 0) return $Queue; if (i == 1) return $R; return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static <$Queue, $R> x10.serialization.X10JavaSerializable $_deserialize_body(x10.glb.Worker.$Closure$93<$Queue, $R> $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            $_obj.$Queue = (x10.rtt.Type) $deserializer.readObject();
            $_obj.$R = (x10.rtt.Type) $deserializer.readObject();
            $_obj.st = $deserializer.readObject();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.glb.Worker.$Closure$93 $_obj = new x10.glb.Worker.$Closure$93((java.lang.System[]) null, (x10.rtt.Type) null, (x10.rtt.Type) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            $serializer.write(this.$Queue);
            $serializer.write(this.$R);
            $serializer.write(this.st);
            
        }
        
        // constructor just for allocation
        public $Closure$93(final java.lang.System[] $dummy, final x10.rtt.Type $Queue, final x10.rtt.Type $R) {
            x10.glb.Worker.$Closure$93.$initParams(this, $Queue, $R);
            
        }
        
        private x10.rtt.Type $Queue;
        private x10.rtt.Type $R;
        
        // initializer of type parameters
        public static void $initParams(final $Closure$93 $this, final x10.rtt.Type $Queue, final x10.rtt.Type $R) {
            $this.$Queue = $Queue;
            $this.$R = $R;
            
        }
        // synthetic type for parameter mangling
        public static final class __0$1x10$glb$Worker$1x10$glb$Worker$$Closure$93$$Queue$3x10$glb$Worker$$Closure$93$$R$2$2 {}
        
    
        
        public void $apply() {
            
            //#line 436 "x10/glb/Worker.x10"
            try {{
                
                //#line 437 "x10/glb/Worker.x10"
                final long max$129400 = ((long)x10.x10rt.X10RT.hereId());
                
                //#line 438 "x10/glb/Worker.x10"
                final long t$129401 = ((max$129400) - (((long)(31L))));
                
                //#line 438 "x10/glb/Worker.x10"
                final long min$129402 = java.lang.Math.max(((long)(t$129401)),((long)(0L)));
                
                //#line 439 "x10/glb/Worker.x10"
                long j$129395 = min$129402;
                
                //#line 439 "x10/glb/Worker.x10"
                for (;
                     true;
                     ) {
                    
                    //#line 439 "x10/glb/Worker.x10"
                    final boolean t$129397 = ((j$129395) <= (((long)(max$129400))));
                    
                    //#line 439 "x10/glb/Worker.x10"
                    if (!(t$129397)) {
                        
                        //#line 439 "x10/glb/Worker.x10"
                        break;
                    }
                    
                    //#line 440 "x10/glb/Worker.x10"
                    final x10.lang.Place alloc$129390 = ((x10.lang.Place)(new x10.lang.Place((java.lang.System[]) null)));
                    
                    //#line 440 "x10/glb/Worker.x10"
                    alloc$129390.x10$lang$Place$$init$S(j$129395);
                    
                    //#line 440 "x10/glb/Worker.x10"
                    x10.xrx.Runtime.runAsync(((x10.lang.Place)(alloc$129390)), ((x10.core.fun.VoidFun_0_0)(new x10.glb.Worker.$Closure$92<$Queue, $R>($Queue, $R, ((x10.lang.PlaceLocalHandle<x10.glb.Worker<$Queue, $R>>)(this.st)), (x10.glb.Worker.$Closure$92.__0$1x10$glb$Worker$1x10$glb$Worker$$Closure$92$$Queue$3x10$glb$Worker$$Closure$92$$R$2$2) null))), ((x10.xrx.Runtime.Profile)(null)));
                    
                    //#line 439 "x10/glb/Worker.x10"
                    final long t$129394 = ((j$129395) + (((long)(1L))));
                    
                    //#line 439 "x10/glb/Worker.x10"
                    j$129395 = t$129394;
                }
            }}catch (java.lang.Error __lowerer__var__0__) {
                
                //#line 436 "x10/glb/Worker.x10"
                throw __lowerer__var__0__;
            }catch (java.lang.Throwable __lowerer__var__1__) {
                
                //#line 436 "x10/glb/Worker.x10"
                throw x10.rtt.Types.EXCEPTION.isInstance(__lowerer__var__1__) ? (java.lang.RuntimeException)(__lowerer__var__1__) : new x10.lang.WrappedThrowable(__lowerer__var__1__);
            }
        }
        
        public x10.lang.PlaceLocalHandle<x10.glb.Worker<$Queue, $R>> st;
        
        public $Closure$93(final x10.rtt.Type $Queue, final x10.rtt.Type $R, final x10.lang.PlaceLocalHandle<x10.glb.Worker<$Queue, $R>> st, __0$1x10$glb$Worker$1x10$glb$Worker$$Closure$93$$Queue$3x10$glb$Worker$$Closure$93$$R$2$2 $dummy) {
            x10.glb.Worker.$Closure$93.$initParams(this, $Queue, $R);
             {
                ((x10.glb.Worker.$Closure$93<$Queue, $R>)this).st = ((x10.lang.PlaceLocalHandle)(st));
            }
        }
        
    }
    
    @x10.runtime.impl.java.X10Generated
    final public static class $Closure$94<$Queue, $R> extends x10.core.Ref implements x10.core.fun.VoidFun_0_0, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<$Closure$94> $RTT = 
            x10.rtt.StaticVoidFunType.<$Closure$94> make($Closure$94.class,
                                                         2,
                                                         new x10.rtt.Type[] {
                                                             x10.core.fun.VoidFun_0_0.$RTT
                                                         });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { if (i == 0) return $Queue; if (i == 1) return $R; return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static <$Queue, $R> x10.serialization.X10JavaSerializable $_deserialize_body(x10.glb.Worker.$Closure$94<$Queue, $R> $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            $_obj.$Queue = (x10.rtt.Type) $deserializer.readObject();
            $_obj.$R = (x10.rtt.Type) $deserializer.readObject();
            $_obj.loot$129446 = $deserializer.readObject();
            $_obj.st$129445 = $deserializer.readObject();
            $_obj.victim$129407 = $deserializer.readLong();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.glb.Worker.$Closure$94 $_obj = new x10.glb.Worker.$Closure$94((java.lang.System[]) null, (x10.rtt.Type) null, (x10.rtt.Type) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            $serializer.write(this.$Queue);
            $serializer.write(this.$R);
            $serializer.write(this.loot$129446);
            $serializer.write(this.st$129445);
            $serializer.write(this.victim$129407);
            
        }
        
        // constructor just for allocation
        public $Closure$94(final java.lang.System[] $dummy, final x10.rtt.Type $Queue, final x10.rtt.Type $R) {
            x10.glb.Worker.$Closure$94.$initParams(this, $Queue, $R);
            
        }
        
        private x10.rtt.Type $Queue;
        private x10.rtt.Type $R;
        
        // initializer of type parameters
        public static void $initParams(final $Closure$94 $this, final x10.rtt.Type $Queue, final x10.rtt.Type $R) {
            $this.$Queue = $Queue;
            $this.$R = $R;
            
        }
        // synthetic type for parameter mangling
        public static final class __0$1x10$glb$Worker$1x10$glb$Worker$$Closure$94$$Queue$3x10$glb$Worker$$Closure$94$$R$2$2 {}
        
    
        
        public void $apply() {
            
            //#line 168 .. "x10/glb/Worker.x10"
            final x10.glb.Worker t$129426 = ((x10.lang.PlaceLocalHandle<x10.glb.Worker<$Queue, $R>>)this.st$129445).$apply$G();
            
            //#line 168 .. "x10/glb/Worker.x10"
            ((x10.glb.Worker<$Queue, $R>)t$129426).deal__0$1x10$glb$Worker$1x10$glb$Worker$$Queue$3x10$glb$Worker$$R$2$2(((x10.lang.PlaceLocalHandle)(this.st$129445)), ((x10.glb.TaskBag)(this.loot$129446)), (long)(this.victim$129407));
            
            //#line 168 .. "x10/glb/Worker.x10"
            final x10.glb.Worker t$129427 = ((x10.lang.PlaceLocalHandle<x10.glb.Worker<$Queue, $R>>)this.st$129445).$apply$G();
            
            //#line 168 .. "x10/glb/Worker.x10"
            ((x10.glb.Worker<$Queue, $R>)t$129427).waiting = false;
        }
        
        public x10.lang.PlaceLocalHandle<x10.glb.Worker<$Queue, $R>> st$129445;
        public x10.glb.TaskBag loot$129446;
        public long victim$129407;
        
        public $Closure$94(final x10.rtt.Type $Queue, final x10.rtt.Type $R, final x10.lang.PlaceLocalHandle<x10.glb.Worker<$Queue, $R>> st$129445, final x10.glb.TaskBag loot$129446, final long victim$129407, __0$1x10$glb$Worker$1x10$glb$Worker$$Closure$94$$Queue$3x10$glb$Worker$$Closure$94$$R$2$2 $dummy) {
            x10.glb.Worker.$Closure$94.$initParams(this, $Queue, $R);
             {
                ((x10.glb.Worker.$Closure$94<$Queue, $R>)this).st$129445 = ((x10.lang.PlaceLocalHandle)(st$129445));
                ((x10.glb.Worker.$Closure$94<$Queue, $R>)this).loot$129446 = ((x10.glb.TaskBag)(loot$129446));
                ((x10.glb.Worker.$Closure$94<$Queue, $R>)this).victim$129407 = victim$129407;
            }
        }
        
    }
    
    @x10.runtime.impl.java.X10Generated
    final public static class $Closure$95<$Queue, $R> extends x10.core.Ref implements x10.core.fun.VoidFun_0_0, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<$Closure$95> $RTT = 
            x10.rtt.StaticVoidFunType.<$Closure$95> make($Closure$95.class,
                                                         2,
                                                         new x10.rtt.Type[] {
                                                             x10.core.fun.VoidFun_0_0.$RTT
                                                         });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { if (i == 0) return $Queue; if (i == 1) return $R; return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static <$Queue, $R> x10.serialization.X10JavaSerializable $_deserialize_body(x10.glb.Worker.$Closure$95<$Queue, $R> $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            $_obj.$Queue = (x10.rtt.Type) $deserializer.readObject();
            $_obj.$R = (x10.rtt.Type) $deserializer.readObject();
            $_obj.loot$129446 = $deserializer.readObject();
            $_obj.st$129445 = $deserializer.readObject();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.glb.Worker.$Closure$95 $_obj = new x10.glb.Worker.$Closure$95((java.lang.System[]) null, (x10.rtt.Type) null, (x10.rtt.Type) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            $serializer.write(this.$Queue);
            $serializer.write(this.$R);
            $serializer.write(this.loot$129446);
            $serializer.write(this.st$129445);
            
        }
        
        // constructor just for allocation
        public $Closure$95(final java.lang.System[] $dummy, final x10.rtt.Type $Queue, final x10.rtt.Type $R) {
            x10.glb.Worker.$Closure$95.$initParams(this, $Queue, $R);
            
        }
        
        private x10.rtt.Type $Queue;
        private x10.rtt.Type $R;
        
        // initializer of type parameters
        public static void $initParams(final $Closure$95 $this, final x10.rtt.Type $Queue, final x10.rtt.Type $R) {
            $this.$Queue = $Queue;
            $this.$R = $R;
            
        }
        // synthetic type for parameter mangling
        public static final class __0$1x10$glb$Worker$1x10$glb$Worker$$Closure$95$$Queue$3x10$glb$Worker$$Closure$95$$R$2$2 {}
        
    
        
        public void $apply() {
            
            //#line 171 .. "x10/glb/Worker.x10"
            final x10.glb.Worker t$129432 = ((x10.lang.PlaceLocalHandle<x10.glb.Worker<$Queue, $R>>)this.st$129445).$apply$G();
            
            //#line 171 .. "x10/glb/Worker.x10"
            ((x10.glb.Worker<$Queue, $R>)t$129432).deal__0$1x10$glb$Worker$1x10$glb$Worker$$Queue$3x10$glb$Worker$$R$2$2(((x10.lang.PlaceLocalHandle)(this.st$129445)), ((x10.glb.TaskBag)(this.loot$129446)), (long)(-1L));
            
            //#line 171 .. "x10/glb/Worker.x10"
            final x10.glb.Worker t$129433 = ((x10.lang.PlaceLocalHandle<x10.glb.Worker<$Queue, $R>>)this.st$129445).$apply$G();
            
            //#line 171 .. "x10/glb/Worker.x10"
            ((x10.glb.Worker<$Queue, $R>)t$129433).waiting = false;
        }
        
        public x10.lang.PlaceLocalHandle<x10.glb.Worker<$Queue, $R>> st$129445;
        public x10.glb.TaskBag loot$129446;
        
        public $Closure$95(final x10.rtt.Type $Queue, final x10.rtt.Type $R, final x10.lang.PlaceLocalHandle<x10.glb.Worker<$Queue, $R>> st$129445, final x10.glb.TaskBag loot$129446, __0$1x10$glb$Worker$1x10$glb$Worker$$Closure$95$$Queue$3x10$glb$Worker$$Closure$95$$R$2$2 $dummy) {
            x10.glb.Worker.$Closure$95.$initParams(this, $Queue, $R);
             {
                ((x10.glb.Worker.$Closure$95<$Queue, $R>)this).st$129445 = ((x10.lang.PlaceLocalHandle)(st$129445));
                ((x10.glb.Worker.$Closure$95<$Queue, $R>)this).loot$129446 = ((x10.glb.TaskBag)(loot$129446));
            }
        }
        
    }
    
    @x10.runtime.impl.java.X10Generated
    final public static class $Closure$96<$Queue, $R> extends x10.core.Ref implements x10.core.fun.VoidFun_0_0, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<$Closure$96> $RTT = 
            x10.rtt.StaticVoidFunType.<$Closure$96> make($Closure$96.class,
                                                         2,
                                                         new x10.rtt.Type[] {
                                                             x10.core.fun.VoidFun_0_0.$RTT
                                                         });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { if (i == 0) return $Queue; if (i == 1) return $R; return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static <$Queue, $R> x10.serialization.X10JavaSerializable $_deserialize_body(x10.glb.Worker.$Closure$96<$Queue, $R> $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            $_obj.$Queue = (x10.rtt.Type) $deserializer.readObject();
            $_obj.$R = (x10.rtt.Type) $deserializer.readObject();
            $_obj.loot$129446 = $deserializer.readObject();
            $_obj.st$129445 = $deserializer.readObject();
            $_obj.victim$129407 = $deserializer.readLong();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.glb.Worker.$Closure$96 $_obj = new x10.glb.Worker.$Closure$96((java.lang.System[]) null, (x10.rtt.Type) null, (x10.rtt.Type) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            $serializer.write(this.$Queue);
            $serializer.write(this.$R);
            $serializer.write(this.loot$129446);
            $serializer.write(this.st$129445);
            $serializer.write(this.victim$129407);
            
        }
        
        // constructor just for allocation
        public $Closure$96(final java.lang.System[] $dummy, final x10.rtt.Type $Queue, final x10.rtt.Type $R) {
            x10.glb.Worker.$Closure$96.$initParams(this, $Queue, $R);
            
        }
        
        private x10.rtt.Type $Queue;
        private x10.rtt.Type $R;
        
        // initializer of type parameters
        public static void $initParams(final $Closure$96 $this, final x10.rtt.Type $Queue, final x10.rtt.Type $R) {
            $this.$Queue = $Queue;
            $this.$R = $R;
            
        }
        // synthetic type for parameter mangling
        public static final class __0$1x10$glb$Worker$1x10$glb$Worker$$Closure$96$$Queue$3x10$glb$Worker$$Closure$96$$R$2$2 {}
        
    
        
        public void $apply() {
            
            //#line 176 .. "x10/glb/Worker.x10"
            try {{
                
                //#line 176 .. "x10/glb/Worker.x10"
                final x10.glb.Worker t$129444 = ((x10.lang.PlaceLocalHandle<x10.glb.Worker<$Queue, $R>>)this.st$129445).$apply$G();
                
                //#line 176 .. "x10/glb/Worker.x10"
                ((x10.glb.Worker<$Queue, $R>)t$129444).deal__0$1x10$glb$Worker$1x10$glb$Worker$$Queue$3x10$glb$Worker$$R$2$2(((x10.lang.PlaceLocalHandle)(this.st$129445)), ((x10.glb.TaskBag)(this.loot$129446)), (long)(this.victim$129407));
            }}catch (java.lang.Error __lowerer__var__0__) {
                
                //#line 176 .. "x10/glb/Worker.x10"
                throw __lowerer__var__0__;
            }catch (java.lang.Throwable __lowerer__var__1__) {
                
                //#line 176 .. "x10/glb/Worker.x10"
                throw x10.rtt.Types.EXCEPTION.isInstance(__lowerer__var__1__) ? (java.lang.RuntimeException)(__lowerer__var__1__) : new x10.lang.WrappedThrowable(__lowerer__var__1__);
            }
        }
        
        public x10.lang.PlaceLocalHandle<x10.glb.Worker<$Queue, $R>> st$129445;
        public x10.glb.TaskBag loot$129446;
        public long victim$129407;
        
        public $Closure$96(final x10.rtt.Type $Queue, final x10.rtt.Type $R, final x10.lang.PlaceLocalHandle<x10.glb.Worker<$Queue, $R>> st$129445, final x10.glb.TaskBag loot$129446, final long victim$129407, __0$1x10$glb$Worker$1x10$glb$Worker$$Closure$96$$Queue$3x10$glb$Worker$$Closure$96$$R$2$2 $dummy) {
            x10.glb.Worker.$Closure$96.$initParams(this, $Queue, $R);
             {
                ((x10.glb.Worker.$Closure$96<$Queue, $R>)this).st$129445 = ((x10.lang.PlaceLocalHandle)(st$129445));
                ((x10.glb.Worker.$Closure$96<$Queue, $R>)this).loot$129446 = ((x10.glb.TaskBag)(loot$129446));
                ((x10.glb.Worker.$Closure$96<$Queue, $R>)this).victim$129407 = victim$129407;
            }
        }
        
    }
    
    @x10.runtime.impl.java.X10Generated
    final public static class $Closure$97<$Queue, $R> extends x10.core.Ref implements x10.core.fun.VoidFun_0_0, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<$Closure$97> $RTT = 
            x10.rtt.StaticVoidFunType.<$Closure$97> make($Closure$97.class,
                                                         2,
                                                         new x10.rtt.Type[] {
                                                             x10.core.fun.VoidFun_0_0.$RTT
                                                         });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { if (i == 0) return $Queue; if (i == 1) return $R; return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static <$Queue, $R> x10.serialization.X10JavaSerializable $_deserialize_body(x10.glb.Worker.$Closure$97<$Queue, $R> $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            $_obj.$Queue = (x10.rtt.Type) $deserializer.readObject();
            $_obj.$R = (x10.rtt.Type) $deserializer.readObject();
            $_obj.st$128527 = $deserializer.readObject();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.glb.Worker.$Closure$97 $_obj = new x10.glb.Worker.$Closure$97((java.lang.System[]) null, (x10.rtt.Type) null, (x10.rtt.Type) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            $serializer.write(this.$Queue);
            $serializer.write(this.$R);
            $serializer.write(this.st$128527);
            
        }
        
        // constructor just for allocation
        public $Closure$97(final java.lang.System[] $dummy, final x10.rtt.Type $Queue, final x10.rtt.Type $R) {
            x10.glb.Worker.$Closure$97.$initParams(this, $Queue, $R);
            
        }
        
        private x10.rtt.Type $Queue;
        private x10.rtt.Type $R;
        
        // initializer of type parameters
        public static void $initParams(final $Closure$97 $this, final x10.rtt.Type $Queue, final x10.rtt.Type $R) {
            $this.$Queue = $Queue;
            $this.$R = $R;
            
        }
        // synthetic type for parameter mangling
        public static final class __0$1x10$glb$Worker$1x10$glb$Worker$$Closure$97$$Queue$3x10$glb$Worker$$Closure$97$$R$2$2 {}
        
    
        
        public void $apply() {
            
            //#line 202 . "x10/glb/Worker.x10"
            final x10.glb.Worker t$129464 = ((x10.lang.PlaceLocalHandle<x10.glb.Worker<$Queue, $R>>)this.st$128527).$apply$G();
            
            //#line 202 . "x10/glb/Worker.x10"
            ((x10.glb.Worker<$Queue, $R>)t$129464).waiting = false;
        }
        
        public x10.lang.PlaceLocalHandle<x10.glb.Worker<$Queue, $R>> st$128527;
        
        public $Closure$97(final x10.rtt.Type $Queue, final x10.rtt.Type $R, final x10.lang.PlaceLocalHandle<x10.glb.Worker<$Queue, $R>> st$128527, __0$1x10$glb$Worker$1x10$glb$Worker$$Closure$97$$Queue$3x10$glb$Worker$$Closure$97$$R$2$2 $dummy) {
            x10.glb.Worker.$Closure$97.$initParams(this, $Queue, $R);
             {
                ((x10.glb.Worker.$Closure$97<$Queue, $R>)this).st$128527 = ((x10.lang.PlaceLocalHandle)(st$128527));
            }
        }
        
    }
    
    @x10.runtime.impl.java.X10Generated
    final public static class $Closure$98<$Queue, $R> extends x10.core.Ref implements x10.core.fun.VoidFun_0_0, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<$Closure$98> $RTT = 
            x10.rtt.StaticVoidFunType.<$Closure$98> make($Closure$98.class,
                                                         2,
                                                         new x10.rtt.Type[] {
                                                             x10.core.fun.VoidFun_0_0.$RTT
                                                         });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { if (i == 0) return $Queue; if (i == 1) return $R; return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static <$Queue, $R> x10.serialization.X10JavaSerializable $_deserialize_body(x10.glb.Worker.$Closure$98<$Queue, $R> $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            $_obj.$Queue = (x10.rtt.Type) $deserializer.readObject();
            $_obj.$R = (x10.rtt.Type) $deserializer.readObject();
            $_obj.st$128527 = $deserializer.readObject();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.glb.Worker.$Closure$98 $_obj = new x10.glb.Worker.$Closure$98((java.lang.System[]) null, (x10.rtt.Type) null, (x10.rtt.Type) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            $serializer.write(this.$Queue);
            $serializer.write(this.$R);
            $serializer.write(this.st$128527);
            
        }
        
        // constructor just for allocation
        public $Closure$98(final java.lang.System[] $dummy, final x10.rtt.Type $Queue, final x10.rtt.Type $R) {
            x10.glb.Worker.$Closure$98.$initParams(this, $Queue, $R);
            
        }
        
        private x10.rtt.Type $Queue;
        private x10.rtt.Type $R;
        
        // initializer of type parameters
        public static void $initParams(final $Closure$98 $this, final x10.rtt.Type $Queue, final x10.rtt.Type $R) {
            $this.$Queue = $Queue;
            $this.$R = $R;
            
        }
        // synthetic type for parameter mangling
        public static final class __0$1x10$glb$Worker$1x10$glb$Worker$$Closure$98$$Queue$3x10$glb$Worker$$Closure$98$$R$2$2 {}
        
    
        
        public void $apply() {
            
            //#line 204 . "x10/glb/Worker.x10"
            final x10.glb.Worker t$129466 = ((x10.lang.PlaceLocalHandle<x10.glb.Worker<$Queue, $R>>)this.st$128527).$apply$G();
            
            //#line 204 . "x10/glb/Worker.x10"
            ((x10.glb.Worker<$Queue, $R>)t$129466).waiting = false;
        }
        
        public x10.lang.PlaceLocalHandle<x10.glb.Worker<$Queue, $R>> st$128527;
        
        public $Closure$98(final x10.rtt.Type $Queue, final x10.rtt.Type $R, final x10.lang.PlaceLocalHandle<x10.glb.Worker<$Queue, $R>> st$128527, __0$1x10$glb$Worker$1x10$glb$Worker$$Closure$98$$Queue$3x10$glb$Worker$$Closure$98$$R$2$2 $dummy) {
            x10.glb.Worker.$Closure$98.$initParams(this, $Queue, $R);
             {
                ((x10.glb.Worker.$Closure$98<$Queue, $R>)this).st$128527 = ((x10.lang.PlaceLocalHandle)(st$128527));
            }
        }
        
    }
    
    @x10.runtime.impl.java.X10Generated
    final public static class $Closure$99<$Queue, $R> extends x10.core.Ref implements x10.core.fun.VoidFun_0_1, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<$Closure$99> $RTT = 
            x10.rtt.StaticVoidFunType.<$Closure$99> make($Closure$99.class,
                                                         2,
                                                         new x10.rtt.Type[] {
                                                             x10.rtt.ParameterizedType.make(x10.core.fun.VoidFun_0_1.$RTT, x10.rtt.ParameterizedType.make(x10.lang.PlaceLocalHandle.$RTT, x10.rtt.ParameterizedType.make(x10.glb.Worker.$RTT, x10.rtt.UnresolvedType.PARAM(0), x10.rtt.UnresolvedType.PARAM(1))))
                                                         });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { if (i == 0) return $Queue; if (i == 1) return $R; return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static <$Queue, $R> x10.serialization.X10JavaSerializable $_deserialize_body(x10.glb.Worker.$Closure$99<$Queue, $R> $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            $_obj.$Queue = (x10.rtt.Type) $deserializer.readObject();
            $_obj.$R = (x10.rtt.Type) $deserializer.readObject();
            $_obj.out$$ = $deserializer.readObject();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.glb.Worker.$Closure$99 $_obj = new x10.glb.Worker.$Closure$99((java.lang.System[]) null, (x10.rtt.Type) null, (x10.rtt.Type) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            $serializer.write(this.$Queue);
            $serializer.write(this.$R);
            $serializer.write(this.out$$);
            
        }
        
        // constructor just for allocation
        public $Closure$99(final java.lang.System[] $dummy, final x10.rtt.Type $Queue, final x10.rtt.Type $R) {
            x10.glb.Worker.$Closure$99.$initParams(this, $Queue, $R);
            
        }
        
        // dispatcher for method abstract public (Z1)=>void.operator()(a1:Z1):void
        public java.lang.Object $apply(final java.lang.Object a1, final x10.rtt.Type t1) {
            $apply__0$1x10$glb$Worker$1x10$glb$Worker$$Closure$99$$Queue$3x10$glb$Worker$$Closure$99$$R$2$2((x10.lang.PlaceLocalHandle)a1); return null;
            
        }
        
        // dispatcher for method abstract public (Z1)=>void.operator()(a1:Z1):void
        public void $apply$V(final java.lang.Object a1, final x10.rtt.Type t1) {
            $apply__0$1x10$glb$Worker$1x10$glb$Worker$$Closure$99$$Queue$3x10$glb$Worker$$Closure$99$$R$2$2((x10.lang.PlaceLocalHandle)a1);
            
        }
        
        private x10.rtt.Type $Queue;
        private x10.rtt.Type $R;
        
        // initializer of type parameters
        public static void $initParams(final $Closure$99 $this, final x10.rtt.Type $Queue, final x10.rtt.Type $R) {
            $this.$Queue = $Queue;
            $this.$R = $R;
            
        }
        // synthetic type for parameter mangling
        public static final class __0$1x10$glb$Worker$$Closure$99$$Queue$3x10$glb$Worker$$Closure$99$$R$2 {}
        
    
        
        public void $apply__0$1x10$glb$Worker$1x10$glb$Worker$$Closure$99$$Queue$3x10$glb$Worker$$Closure$99$$R$2$2(final x10.lang.PlaceLocalHandle st) {
            
            //#line 452 "x10/glb/Worker.x10"
            x10.xrx.Runtime.probe();
            
            //#line 452 "x10/glb/Worker.x10"
            final x10.glb.Worker this$128502 = ((x10.glb.Worker)(this.out$$));
            
            //#line 452 "x10/glb/Worker.x10"
            final x10.lang.PlaceLocalHandle st$128500 = ((x10.lang.PlaceLocalHandle)(st));
            
            //#line 186 . "x10/glb/Worker.x10"
            x10.glb.TaskBag loot$129467 =  null;
            
            //#line 187 . "x10/glb/Worker.x10"
            while (true) {
                
                //#line 187 . "x10/glb/Worker.x10"
                final x10.glb.FixedSizeStack this$129468 = ((x10.glb.FixedSizeStack)(((x10.glb.Worker<$Queue, $R>)this$128502).thieves));
                
                //#line 55 .. "x10/glb/FixedSizeStack.x10"
                final long t$129469 = ((x10.glb.FixedSizeStack<x10.core.Long>)this$129468).size;
                
                //#line 187 . "x10/glb/Worker.x10"
                boolean t$129470 = ((t$129469) > (((long)(0L))));
                
                //#line 187 . "x10/glb/Worker.x10"
                if (!(t$129470)) {
                    
                    //#line 187 . "x10/glb/Worker.x10"
                    final x10.glb.FixedSizeStack this$129471 = ((x10.glb.FixedSizeStack)(((x10.glb.Worker<$Queue, $R>)this$128502).lifelineThieves));
                    
                    //#line 55 .. "x10/glb/FixedSizeStack.x10"
                    final long t$129472 = ((x10.glb.FixedSizeStack<x10.core.Long>)this$129471).size;
                    
                    //#line 187 . "x10/glb/Worker.x10"
                    t$129470 = ((t$129472) > (((long)(0L))));
                }
                
                //#line 187 . "x10/glb/Worker.x10"
                boolean t$129473 = t$129470;
                
                //#line 187 . "x10/glb/Worker.x10"
                if (t$129470) {
                    
                    //#line 187 . "x10/glb/Worker.x10"
                    final $Queue t$129474 = (($Queue)(((x10.glb.Worker<$Queue, $R>)this$128502).queue));
                    
                    //#line 187 . "x10/glb/Worker.x10"
                    final x10.glb.TaskBag t$129475 = ((x10.glb.TaskQueue<$Queue, $R>)x10.rtt.Types.conversion(x10.rtt.ParameterizedType.make(x10.glb.TaskQueue.$RTT, $Queue, $R),t$129474)).split();
                    
                    //#line 187 . "x10/glb/Worker.x10"
                    final x10.glb.TaskBag t$129476 = loot$129467 = ((x10.glb.TaskBag)(t$129475));
                    
                    //#line 187 . "x10/glb/Worker.x10"
                    t$129473 = ((t$129476) != (null));
                }
                
                //#line 187 . "x10/glb/Worker.x10"
                if (!(t$129473)) {
                    
                    //#line 187 . "x10/glb/Worker.x10"
                    break;
                }
                
                //#line 188 . "x10/glb/Worker.x10"
                final x10.lang.PlaceLocalHandle st$129445 = ((x10.lang.PlaceLocalHandle)(st$128500));
                
                //#line 188 . "x10/glb/Worker.x10"
                final x10.glb.TaskBag loot$129446 = ((x10.glb.TaskBag)(loot$129467));
                
                //#line 162 .. "x10/glb/Worker.x10"
                final long victim$129407 = ((long)x10.x10rt.X10RT.hereId());
                
                //#line 163 .. "x10/glb/Worker.x10"
                final x10.glb.Logger obj$129408 = ((x10.glb.Logger)(((x10.glb.Worker<$Queue, $R>)this$128502).logger));
                
                //#line 163 .. "x10/glb/Worker.x10"
                final long t$129409 = obj$129408.nodesGiven;
                
                //#line 163 .. "x10/glb/Worker.x10"
                final long t$129410 = loot$129467.size$O();
                
                //#line 163 .. "x10/glb/Worker.x10"
                final long t$129411 = ((t$129409) + (((long)(t$129410))));
                
                //#line 163 .. "x10/glb/Worker.x10"
                obj$129408.nodesGiven = t$129411;
                
                //#line 164 .. "x10/glb/Worker.x10"
                final x10.glb.FixedSizeStack this$129412 = ((x10.glb.FixedSizeStack)(((x10.glb.Worker<$Queue, $R>)this$128502).thieves));
                
                //#line 55 ... "x10/glb/FixedSizeStack.x10"
                final long t$129413 = ((x10.glb.FixedSizeStack<x10.core.Long>)this$129412).size;
                
                //#line 164 .. "x10/glb/Worker.x10"
                final boolean t$129414 = ((t$129413) > (((long)(0L))));
                
                //#line 164 .. "x10/glb/Worker.x10"
                if (t$129414) {
                    
                    //#line 165 .. "x10/glb/Worker.x10"
                    final x10.glb.FixedSizeStack this$129415 = ((x10.glb.FixedSizeStack)(((x10.glb.Worker<$Queue, $R>)this$128502).thieves));
                    
                    //#line 44 ... "x10/glb/FixedSizeStack.x10"
                    final x10.core.Rail t$129416 = ((x10.core.Rail)(((x10.glb.FixedSizeStack<x10.core.Long>)this$129415).data));
                    
                    //#line 44 ... "x10/glb/FixedSizeStack.x10"
                    final long t$129417 = ((x10.glb.FixedSizeStack<x10.core.Long>)this$129415).size;
                    
                    //#line 44 ... "x10/glb/FixedSizeStack.x10"
                    final long t$129418 = ((t$129417) - (((long)(1L))));
                    
                    //#line 44 ... "x10/glb/FixedSizeStack.x10"
                    final long t$129419 = ((x10.glb.FixedSizeStack<x10.core.Long>)this$129415).size = t$129418;
                    
                    //#line 165 .. "x10/glb/Worker.x10"
                    final long thief$129420 = ((long[])t$129416.value)[(int)t$129419];
                    
                    //#line 166 .. "x10/glb/Worker.x10"
                    final boolean t$129421 = ((thief$129420) >= (((long)(0L))));
                    
                    //#line 166 .. "x10/glb/Worker.x10"
                    if (t$129421) {
                        
                        //#line 167 .. "x10/glb/Worker.x10"
                        final x10.glb.Logger obj$129422 = ((x10.glb.Logger)(((x10.glb.Worker<$Queue, $R>)this$128502).logger));
                        
                        //#line 167 .. "x10/glb/Worker.x10"
                        final long t$129423 = obj$129422.lifelineStealsSuffered;
                        
                        //#line 167 .. "x10/glb/Worker.x10"
                        final long t$129424 = ((t$129423) + (((long)(1L))));
                        
                        //#line 167 .. "x10/glb/Worker.x10"
                        obj$129422.lifelineStealsSuffered = t$129424;
                        
                        //#line 168 .. "x10/glb/Worker.x10"
                        final x10.lang.Place alloc$129425 = ((x10.lang.Place)(new x10.lang.Place((java.lang.System[]) null)));
                        
                        //#line 168 .. "x10/glb/Worker.x10"
                        alloc$129425.x10$lang$Place$$init$S(((long)(thief$129420)));
                        
                        //#line 168 .. "x10/glb/Worker.x10"
                        x10.xrx.Runtime.runUncountedAsync(((x10.lang.Place)(alloc$129425)), ((x10.core.fun.VoidFun_0_0)(new x10.glb.Worker.$Closure$94<$Queue, $R>($Queue, $R, st$129445, loot$129446, victim$129407, (x10.glb.Worker.$Closure$94.__0$1x10$glb$Worker$1x10$glb$Worker$$Closure$94$$Queue$3x10$glb$Worker$$Closure$94$$R$2$2) null))), ((x10.xrx.Runtime.Profile)(null)));
                    } else {
                        
                        //#line 170 .. "x10/glb/Worker.x10"
                        final x10.glb.Logger obj$129428 = ((x10.glb.Logger)(((x10.glb.Worker<$Queue, $R>)this$128502).logger));
                        
                        //#line 170 .. "x10/glb/Worker.x10"
                        final long t$129429 = obj$129428.stealsSuffered;
                        
                        //#line 170 .. "x10/glb/Worker.x10"
                        final long t$129430 = ((t$129429) + (((long)(1L))));
                        
                        //#line 170 .. "x10/glb/Worker.x10"
                        obj$129428.stealsSuffered = t$129430;
                        
                        //#line 171 .. "x10/glb/Worker.x10"
                        final x10.lang.Place alloc$129431 = ((x10.lang.Place)(new x10.lang.Place((java.lang.System[]) null)));
                        
                        //#line 171 .. "x10/glb/Worker.x10"
                        final long t$129405 = (-(thief$129420));
                        
                        //#line 171 .. "x10/glb/Worker.x10"
                        final long t$129406 = ((t$129405) - (((long)(1L))));
                        
                        //#line 171 .. "x10/glb/Worker.x10"
                        alloc$129431.x10$lang$Place$$init$S(t$129406);
                        
                        //#line 171 .. "x10/glb/Worker.x10"
                        x10.xrx.Runtime.runUncountedAsync(((x10.lang.Place)(alloc$129431)), ((x10.core.fun.VoidFun_0_0)(new x10.glb.Worker.$Closure$95<$Queue, $R>($Queue, $R, st$129445, loot$129446, (x10.glb.Worker.$Closure$95.__0$1x10$glb$Worker$1x10$glb$Worker$$Closure$95$$Queue$3x10$glb$Worker$$Closure$95$$R$2$2) null))), ((x10.xrx.Runtime.Profile)(null)));
                    }
                } else {
                    
                    //#line 174 .. "x10/glb/Worker.x10"
                    final x10.glb.Logger obj$129434 = ((x10.glb.Logger)(((x10.glb.Worker<$Queue, $R>)this$128502).logger));
                    
                    //#line 174 .. "x10/glb/Worker.x10"
                    final long t$129435 = obj$129434.lifelineStealsSuffered;
                    
                    //#line 174 .. "x10/glb/Worker.x10"
                    final long t$129436 = ((t$129435) + (((long)(1L))));
                    
                    //#line 174 .. "x10/glb/Worker.x10"
                    obj$129434.lifelineStealsSuffered = t$129436;
                    
                    //#line 175 .. "x10/glb/Worker.x10"
                    final x10.glb.FixedSizeStack this$129437 = ((x10.glb.FixedSizeStack)(((x10.glb.Worker<$Queue, $R>)this$128502).lifelineThieves));
                    
                    //#line 44 ... "x10/glb/FixedSizeStack.x10"
                    final x10.core.Rail t$129438 = ((x10.core.Rail)(((x10.glb.FixedSizeStack<x10.core.Long>)this$129437).data));
                    
                    //#line 44 ... "x10/glb/FixedSizeStack.x10"
                    final long t$129439 = ((x10.glb.FixedSizeStack<x10.core.Long>)this$129437).size;
                    
                    //#line 44 ... "x10/glb/FixedSizeStack.x10"
                    final long t$129440 = ((t$129439) - (((long)(1L))));
                    
                    //#line 44 ... "x10/glb/FixedSizeStack.x10"
                    final long t$129441 = ((x10.glb.FixedSizeStack<x10.core.Long>)this$129437).size = t$129440;
                    
                    //#line 175 .. "x10/glb/Worker.x10"
                    final long thief$129442 = ((long[])t$129438.value)[(int)t$129441];
                    
                    //#line 176 .. "x10/glb/Worker.x10"
                    final x10.lang.Place alloc$129443 = ((x10.lang.Place)(new x10.lang.Place((java.lang.System[]) null)));
                    
                    //#line 176 .. "x10/glb/Worker.x10"
                    alloc$129443.x10$lang$Place$$init$S(((long)(thief$129442)));
                    
                    //#line 176 .. "x10/glb/Worker.x10"
                    x10.xrx.Runtime.runAsync(((x10.lang.Place)(alloc$129443)), ((x10.core.fun.VoidFun_0_0)(new x10.glb.Worker.$Closure$96<$Queue, $R>($Queue, $R, st$129445, loot$129446, victim$129407, (x10.glb.Worker.$Closure$96.__0$1x10$glb$Worker$1x10$glb$Worker$$Closure$96$$Queue$3x10$glb$Worker$$Closure$96$$R$2$2) null))), ((x10.xrx.Runtime.Profile)(null)));
                }
            }
            
            //#line 452 "x10/glb/Worker.x10"
            final x10.glb.Worker this$128531 = ((x10.glb.Worker)(this.out$$));
            
            //#line 452 "x10/glb/Worker.x10"
            final x10.lang.PlaceLocalHandle st$128527 = ((x10.lang.PlaceLocalHandle)(st));
            
            //#line 198 . "x10/glb/Worker.x10"
            while (true) {
                
                //#line 198 . "x10/glb/Worker.x10"
                final x10.glb.FixedSizeStack this$129478 = ((x10.glb.FixedSizeStack)(((x10.glb.Worker<$Queue, $R>)this$128531).thieves));
                
                //#line 55 .. "x10/glb/FixedSizeStack.x10"
                final long t$129479 = ((x10.glb.FixedSizeStack<x10.core.Long>)this$129478).size;
                
                //#line 198 . "x10/glb/Worker.x10"
                final boolean t$129480 = ((t$129479) > (((long)(0L))));
                
                //#line 198 . "x10/glb/Worker.x10"
                if (!(t$129480)) {
                    
                    //#line 198 . "x10/glb/Worker.x10"
                    break;
                }
                
                //#line 199 . "x10/glb/Worker.x10"
                final x10.glb.FixedSizeStack this$129454 = ((x10.glb.FixedSizeStack)(((x10.glb.Worker<$Queue, $R>)this$128531).thieves));
                
                //#line 44 .. "x10/glb/FixedSizeStack.x10"
                final x10.core.Rail t$129455 = ((x10.core.Rail)(((x10.glb.FixedSizeStack<x10.core.Long>)this$129454).data));
                
                //#line 44 .. "x10/glb/FixedSizeStack.x10"
                final long t$129456 = ((x10.glb.FixedSizeStack<x10.core.Long>)this$129454).size;
                
                //#line 44 .. "x10/glb/FixedSizeStack.x10"
                final long t$129457 = ((t$129456) - (((long)(1L))));
                
                //#line 44 .. "x10/glb/FixedSizeStack.x10"
                final long t$129458 = ((x10.glb.FixedSizeStack<x10.core.Long>)this$129454).size = t$129457;
                
                //#line 199 . "x10/glb/Worker.x10"
                final long thief$129459 = ((long[])t$129455.value)[(int)t$129458];
                
                //#line 200 . "x10/glb/Worker.x10"
                final boolean t$129460 = ((thief$129459) >= (((long)(0L))));
                
                //#line 200 . "x10/glb/Worker.x10"
                if (t$129460) {
                    
                    //#line 201 . "x10/glb/Worker.x10"
                    final x10.glb.FixedSizeStack this$129461 = ((x10.glb.FixedSizeStack)(((x10.glb.Worker<$Queue, $R>)this$128531).lifelineThieves));
                    
                    //#line 49 .. "x10/glb/FixedSizeStack.x10"
                    final x10.core.Rail t$129447 = ((x10.core.Rail)(((x10.glb.FixedSizeStack<x10.core.Long>)this$129461).data));
                    
                    //#line 49 .. "x10/glb/FixedSizeStack.x10"
                    final long t$129448 = ((x10.glb.FixedSizeStack<x10.core.Long>)this$129461).size;
                    
                    //#line 49 .. "x10/glb/FixedSizeStack.x10"
                    final long t$129449 = ((t$129448) + (((long)(1L))));
                    
                    //#line 49 .. "x10/glb/FixedSizeStack.x10"
                    final long t$129450 = ((x10.glb.FixedSizeStack<x10.core.Long>)this$129461).size = t$129449;
                    
                    //#line 49 .. "x10/glb/FixedSizeStack.x10"
                    final long t$129451 = ((t$129450) - (((long)(1L))));
                    
                    //#line 49 .. "x10/glb/FixedSizeStack.x10"
                    ((long[])t$129447.value)[(int)t$129451] = thief$129459;
                    
                    //#line 202 . "x10/glb/Worker.x10"
                    final x10.lang.Place alloc$129463 = ((x10.lang.Place)(new x10.lang.Place((java.lang.System[]) null)));
                    
                    //#line 202 . "x10/glb/Worker.x10"
                    alloc$129463.x10$lang$Place$$init$S(((long)(thief$129459)));
                    
                    //#line 202 . "x10/glb/Worker.x10"
                    x10.xrx.Runtime.runUncountedAsync(((x10.lang.Place)(alloc$129463)), ((x10.core.fun.VoidFun_0_0)(new x10.glb.Worker.$Closure$97<$Queue, $R>($Queue, $R, st$128527, (x10.glb.Worker.$Closure$97.__0$1x10$glb$Worker$1x10$glb$Worker$$Closure$97$$Queue$3x10$glb$Worker$$Closure$97$$R$2$2) null))), ((x10.xrx.Runtime.Profile)(null)));
                } else {
                    
                    //#line 204 . "x10/glb/Worker.x10"
                    final x10.lang.Place alloc$129465 = ((x10.lang.Place)(new x10.lang.Place((java.lang.System[]) null)));
                    
                    //#line 204 . "x10/glb/Worker.x10"
                    final long t$129452 = (-(thief$129459));
                    
                    //#line 204 . "x10/glb/Worker.x10"
                    final long t$129453 = ((t$129452) - (((long)(1L))));
                    
                    //#line 204 . "x10/glb/Worker.x10"
                    alloc$129465.x10$lang$Place$$init$S(t$129453);
                    
                    //#line 204 . "x10/glb/Worker.x10"
                    x10.xrx.Runtime.runUncountedAsync(((x10.lang.Place)(alloc$129465)), ((x10.core.fun.VoidFun_0_0)(new x10.glb.Worker.$Closure$98<$Queue, $R>($Queue, $R, st$128527, (x10.glb.Worker.$Closure$98.__0$1x10$glb$Worker$1x10$glb$Worker$$Closure$98$$Queue$3x10$glb$Worker$$Closure$98$$R$2$2) null))), ((x10.xrx.Runtime.Profile)(null)));
                }
            }
        }
        
        public x10.glb.Worker<$Queue, $R> out$$;
        
        public $Closure$99(final x10.rtt.Type $Queue, final x10.rtt.Type $R, final x10.glb.Worker<$Queue, $R> out$$, __0$1x10$glb$Worker$$Closure$99$$Queue$3x10$glb$Worker$$Closure$99$$R$2 $dummy) {
            x10.glb.Worker.$Closure$99.$initParams(this, $Queue, $R);
             {
                ((x10.glb.Worker.$Closure$99<$Queue, $R>)this).out$$ = out$$;
            }
        }
        
    }
    
    }
    
    