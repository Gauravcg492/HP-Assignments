package x10.glb;

/**
 * <p> An interfact that exposes the yield method.
 * </p>
 */
@x10.runtime.impl.java.X10Generated
public interface ContextI extends x10.core.Any
{
    public static final x10.rtt.RuntimeType<ContextI> $RTT = 
        x10.rtt.NamedType.<ContextI> make("x10.glb.ContextI", ContextI.class);
    
    

    
    
    //#line 23 "x10/glb/ContextI.x10"
    /**
     * Yield method
     */
    void yielding();
}

