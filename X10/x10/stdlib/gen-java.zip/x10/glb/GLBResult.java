package x10.glb;

@x10.runtime.impl.java.X10Generated
abstract public class GLBResult<$R> extends x10.core.Ref implements x10.serialization.X10JavaSerializable
{
    public static final x10.rtt.RuntimeType<GLBResult> $RTT = 
        x10.rtt.NamedType.<GLBResult> make("x10.glb.GLBResult",
                                           GLBResult.class,
                                           1);
    
    public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
    
    public x10.rtt.Type<?> $getParam(int i) { if (i == 0) return $R; return null; }
    
    public static <$R> x10.serialization.X10JavaSerializable $_deserialize_body(x10.glb.GLBResult<$R> $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
        $_obj.$R = (x10.rtt.Type) $deserializer.readObject();
        $_obj.op = $deserializer.readInt();
        $_obj.result = $deserializer.readObject();
        return $_obj;
    }
    
    public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
        return null;
    }
    
    public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
        $serializer.write(this.$R);
        $serializer.write(this.op);
        $serializer.write(this.result);
        
    }
    
    // constructor just for allocation
    public GLBResult(final java.lang.System[] $dummy, final x10.rtt.Type $R) {
        x10.glb.GLBResult.$initParams(this, $R);
        
    }
    
    private x10.rtt.Type $R;
    
    // initializer of type parameters
    public static void $initParams(final GLBResult $this, final x10.rtt.Type $R) {
        $this.$R = $R;
        
    }
    

    
    //#line 19 "x10/glb/GLBResult.x10"
    /**
     * Backing storage of result.
     */
    public x10.core.Rail<$R> result;
    
    //#line 24 "x10/glb/GLBResult.x10"
    /**
     * Reduction operator. Numbered the same as the operator defined in {@link x10.util.Team}
     */
    public int op;
    
    
    //#line 29 "x10/glb/GLBResult.x10"
    /**
     * Return the operator. See {@link x10.util.Team}
     */
    abstract public int getReduceOperator$O();
    
    
    //#line 35 "x10/glb/GLBResult.x10"
    /**
     * Returns the result from local {@link TaskQueue}. User must not reclaim the Rail returned by this method
     * @return Local computation result
     */
    abstract public x10.core.Rail getResult();
    
    
    //#line 43 "x10/glb/GLBResult.x10"
    /**
     * User-defined display method for the result.
     * @param result to display
     */
    abstract public void display__0$1x10$glb$GLBResult$$R$2(final x10.core.Rail result);
    
    
    //#line 49 "x10/glb/GLBResult.x10"
    /**
     * Internal method used by {@link GLB}, it only retrieves the result from user once,
     * and the following references are all via the backing Rail.
     */
    public x10.core.Rail submitResult() {
        
        //#line 50 "x10/glb/GLBResult.x10"
        final x10.core.Rail t$128192 = ((x10.core.Rail)(this.result));
        
        //#line 50 "x10/glb/GLBResult.x10"
        final boolean t$128194 = ((t$128192) == (null));
        
        //#line 50 "x10/glb/GLBResult.x10"
        if (t$128194) {
            
            //#line 51 "x10/glb/GLBResult.x10"
            final x10.core.Rail t$128193 = ((x10.core.Rail<$R>)
                                             this.getResult());
            
            //#line 51 "x10/glb/GLBResult.x10"
            ((x10.glb.GLBResult<$R>)this).result = ((x10.core.Rail)(t$128193));
        }
        
        //#line 53 "x10/glb/GLBResult.x10"
        final x10.core.Rail t$128195 = ((x10.core.Rail)(this.result));
        
        //#line 53 "x10/glb/GLBResult.x10"
        return t$128195;
    }
    
    
    //#line 14 "x10/glb/GLBResult.x10"
    final public x10.glb.GLBResult x10$glb$GLBResult$$this$x10$glb$GLBResult() {
        
        //#line 14 "x10/glb/GLBResult.x10"
        return x10.glb.GLBResult.this;
    }
    
    
    //#line 14 "x10/glb/GLBResult.x10"
    
    // constructor for non-virtual call
    final public x10.glb.GLBResult<$R> x10$glb$GLBResult$$init$S() {
         {
            
            //#line 14 "x10/glb/GLBResult.x10"
            
            
            //#line 14 "x10/glb/GLBResult.x10"
            final x10.glb.GLBResult this$128190 = this;
            
            //#line 14 "x10/glb/GLBResult.x10"
            ((x10.glb.GLBResult<$R>)this$128190).result = null;
            
            //#line 14 "x10/glb/GLBResult.x10"
            ((x10.glb.GLBResult<$R>)this$128190).op = -1;
        }
        return this;
    }
    
    
    
    //#line 14 "x10/glb/GLBResult.x10"
    final public void __fieldInitializers_x10_glb_GLBResult() {
        
        //#line 14 "x10/glb/GLBResult.x10"
        ((x10.glb.GLBResult<$R>)this).result = null;
        
        //#line 14 "x10/glb/GLBResult.x10"
        ((x10.glb.GLBResult<$R>)this).op = -1;
    }
}

