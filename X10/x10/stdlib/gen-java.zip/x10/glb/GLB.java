package x10.glb;


/**
 * <p>The top level class of the Global Load Balancing (GLB) framework.
 * </p>
 */
@x10.runtime.impl.java.X10Generated
final public class GLB<$Queue, $R> extends x10.core.Ref implements x10.serialization.X10JavaSerializable
{
    public static final x10.rtt.RuntimeType<GLB> $RTT = 
        x10.rtt.NamedType.<GLB> make("x10.glb.GLB",
                                     GLB.class,
                                     2);
    
    public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
    
    public x10.rtt.Type<?> $getParam(int i) { if (i == 0) return $Queue; if (i == 1) return $R; return null; }
    
    private Object writeReplace() throws java.io.ObjectStreamException {
        return new x10.serialization.SerializationProxy(this);
    }
    
    public static <$Queue, $R> x10.serialization.X10JavaSerializable $_deserialize_body(x10.glb.GLB<$Queue, $R> $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
        $_obj.$Queue = (x10.rtt.Type) $deserializer.readObject();
        $_obj.$R = (x10.rtt.Type) $deserializer.readObject();
        $_obj.P = $deserializer.readLong();
        $_obj.collectResultTime = $deserializer.readLong();
        $_obj.crunchNumberTime = $deserializer.readLong();
        $_obj.glbParams = $deserializer.readObject();
        $_obj.plh = $deserializer.readObject();
        $_obj.rootGlbR = $deserializer.readObject();
        $_obj.setupTime = $deserializer.readLong();
        return $_obj;
    }
    
    public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
        x10.glb.GLB $_obj = new x10.glb.GLB((java.lang.System[]) null, (x10.rtt.Type) null, (x10.rtt.Type) null);
        $deserializer.record_reference($_obj);
        return $_deserialize_body($_obj, $deserializer);
    }
    
    public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
        $serializer.write(this.$Queue);
        $serializer.write(this.$R);
        $serializer.write(this.P);
        $serializer.write(this.collectResultTime);
        $serializer.write(this.crunchNumberTime);
        $serializer.write(this.glbParams);
        $serializer.write(this.plh);
        $serializer.write(this.rootGlbR);
        $serializer.write(this.setupTime);
        
    }
    
    // constructor just for allocation
    public GLB(final java.lang.System[] $dummy, final x10.rtt.Type $Queue, final x10.rtt.Type $R) {
        x10.glb.GLB.$initParams(this, $Queue, $R);
        
    }
    
    private x10.rtt.Type $Queue;
    private x10.rtt.Type $R;
    
    // initializer of type parameters
    public static void $initParams(final GLB $this, final x10.rtt.Type $Queue, final x10.rtt.Type $R) {
        $this.$Queue = $Queue;
        $this.$R = $R;
        
    }
    // synthetic type for parameter mangling
    public static final class __0$1x10$glb$GLB$$Queue$2 {}
    

    
    //#line 25 "x10/glb/GLB.x10"
    /**
     * Number of places.
     */
    public long P;
    
    //#line 29 "x10/glb/GLB.x10"
    /**
     * Home PlaceLocalHandle of {@link Worker}
     */
    public x10.lang.PlaceLocalHandle<x10.glb.Worker<$Queue, $R>> plh;
    
    //#line 34 "x10/glb/GLB.x10"
    /**
     * Workload initialization time.
     */
    public long setupTime;
    
    //#line 38 "x10/glb/GLB.x10"
    /**
     * Computation time.
     */
    public long crunchNumberTime;
    
    //#line 42 "x10/glb/GLB.x10"
    /**
     * Result collection time.
     */
    public long collectResultTime;
    
    //#line 47 "x10/glb/GLB.x10"
    /**
     * {@link GLBResult at root. Used as a vehicle to collect results.}
     */
    public x10.glb.GLBResult<$R> rootGlbR;
    
    
    //#line 52 "x10/glb/GLB.x10"
    /**
     * Min helper method.
     */
    public static long min$O(final long i, final long j) {
        
        //#line 52 "x10/glb/GLB.x10"
        final boolean t$127532 = ((i) < (((long)(j))));
        
        //#line 52 "x10/glb/GLB.x10"
        long t$127533 =  0;
        
        //#line 52 "x10/glb/GLB.x10"
        if (t$127532) {
            
            //#line 52 "x10/glb/GLB.x10"
            t$127533 = i;
        } else {
            
            //#line 52 "x10/glb/GLB.x10"
            t$127533 = j;
        }
        
        //#line 52 "x10/glb/GLB.x10"
        return t$127533;
    }
    
    
    //#line 57 "x10/glb/GLB.x10"
    /**
     * GLB Parameters. {@link GLBParameters}
     */
    public x10.glb.GLBParameters glbParams;
    
    
    //#line 65 "x10/glb/GLB.x10"
    /**
     * Constructor
     * @param init function closure that can initialize {@link TaskQueue}
     * @param glbParams GLB parameters
     * @tree true if workload is dynamically generated, false if workload can be known upfront. 
     */
    // creation method for java code (1-phase java constructor)
    public GLB(final x10.rtt.Type $Queue, final x10.rtt.Type $R, final x10.core.fun.Fun_0_0<$Queue> init, final x10.glb.GLBParameters glbParams, final boolean tree, __0$1x10$glb$GLB$$Queue$2 $dummy) {
        this((java.lang.System[]) null, $Queue, $R);
        x10$glb$GLB$$init$S(init, glbParams, tree, (x10.glb.GLB.__0$1x10$glb$GLB$$Queue$2) null);
    }
    
    // constructor for non-virtual call
    final public x10.glb.GLB<$Queue, $R> x10$glb$GLB$$init$S(final x10.core.fun.Fun_0_0<$Queue> init, final x10.glb.GLBParameters glbParams, final boolean tree, __0$1x10$glb$GLB$$Queue$2 $dummy) {
         {
            
            //#line 65 "x10/glb/GLB.x10"
            
            
            //#line 21 "x10/glb/GLB.x10"
            this.__fieldInitializers_x10_glb_GLB();
            
            //#line 66 "x10/glb/GLB.x10"
            ((x10.glb.GLB<$Queue, $R>)this).glbParams = ((x10.glb.GLBParameters)(glbParams));
            
            //#line 40 . "x10/lang/System.x10"
            final long t$127535 = java.lang.System.nanoTime();
            
            //#line 67 "x10/glb/GLB.x10"
            ((x10.glb.GLB<$Queue, $R>)this).setupTime = t$127535;
            
            //#line 68 "x10/glb/GLB.x10"
            final x10.lang.PlaceGroup t$127541 = ((x10.lang.PlaceGroup)(x10.lang.Place.places()));
            
            //#line 69 "x10/glb/GLB.x10"
            final x10.core.fun.Fun_0_0 t$127542 = ((x10.core.fun.Fun_0_0)(new x10.glb.GLB.$Closure$61<$Queue, $R>($Queue, $R, glbParams, init, tree, (x10.glb.GLB.$Closure$61.__1$1x10$glb$GLB$$Closure$61$$Queue$2) null)));
            
            //#line 68 "x10/glb/GLB.x10"
            final x10.lang.PlaceLocalHandle t$127543 = x10.lang.PlaceLocalHandle.<x10.glb.Worker<$Queue, $R>> makeFlat__1$1x10$lang$PlaceLocalHandle$$T$2(x10.rtt.ParameterizedType.make(x10.glb.Worker.$RTT, $Queue, $R), ((x10.lang.PlaceGroup)(t$127541)), ((x10.core.fun.Fun_0_0)(t$127542)));
            
            //#line 68 "x10/glb/GLB.x10"
            ((x10.glb.GLB<$Queue, $R>)this).plh = ((x10.lang.PlaceLocalHandle)(t$127543));
            
            //#line 70 "x10/glb/GLB.x10"
            final x10.lang.PlaceLocalHandle t$127544 = ((x10.lang.PlaceLocalHandle)(this.plh));
            
            //#line 70 "x10/glb/GLB.x10"
            x10.glb.Worker.<$Queue, $R> initContexts__0$1x10$glb$Worker$1x10$glb$Worker$$Queue$3x10$glb$Worker$$R$2$2($Queue, $R, ((x10.lang.PlaceLocalHandle)(t$127544)));
            
            //#line 40 . "x10/lang/System.x10"
            final long t$127545 = java.lang.System.nanoTime();
            
            //#line 71 "x10/glb/GLB.x10"
            final long t$127546 = this.setupTime;
            
            //#line 71 "x10/glb/GLB.x10"
            final long t$127547 = ((t$127545) - (((long)(t$127546))));
            
            //#line 71 "x10/glb/GLB.x10"
            ((x10.glb.GLB<$Queue, $R>)this).setupTime = t$127547;
        }
        return this;
    }
    
    
    
    //#line 77 "x10/glb/GLB.x10"
    /**
     * Returns Home {@link TaskQueue}
     */
    public $Queue taskQueue$G() {
        
        //#line 77 "x10/glb/GLB.x10"
        final x10.lang.PlaceLocalHandle t$127548 = ((x10.lang.PlaceLocalHandle)(this.plh));
        
        //#line 77 "x10/glb/GLB.x10"
        final x10.glb.Worker t$127549 = ((x10.lang.PlaceLocalHandle<x10.glb.Worker<$Queue, $R>>)t$127548).$apply$G();
        
        //#line 77 "x10/glb/GLB.x10"
        final $Queue t$127550 = (($Queue)(((x10.glb.Worker<$Queue, $R>)t$127549).queue));
        
        //#line 77 "x10/glb/GLB.x10"
        return t$127550;
    }
    
    
    //#line 84 "x10/glb/GLB.x10"
    /**
     * Run method. This method is called when users does not know the workload upfront.
     * @param start The method that (Root) initializes the workload that can start computation.
     * Other places first get their workload by stealing.
     */
    public x10.core.Rail run(final x10.core.fun.VoidFun_0_0 start) {
        
        //#line 40 . "x10/lang/System.x10"
        final long t$127551 = java.lang.System.nanoTime();
        
        //#line 85 "x10/glb/GLB.x10"
        ((x10.glb.GLB<$Queue, $R>)this).crunchNumberTime = t$127551;
        
        //#line 86 "x10/glb/GLB.x10"
        final x10.lang.PlaceLocalHandle t$127552 = ((x10.lang.PlaceLocalHandle)(this.plh));
        
        //#line 86 "x10/glb/GLB.x10"
        final x10.glb.Worker t$127553 = ((x10.lang.PlaceLocalHandle<x10.glb.Worker<$Queue, $R>>)t$127552).$apply$G();
        
        //#line 86 "x10/glb/GLB.x10"
        final x10.lang.PlaceLocalHandle t$127554 = ((x10.lang.PlaceLocalHandle)(this.plh));
        
        //#line 86 "x10/glb/GLB.x10"
        ((x10.glb.Worker<$Queue, $R>)t$127553).main__0$1x10$glb$Worker$1x10$glb$Worker$$Queue$3x10$glb$Worker$$R$2$2(((x10.lang.PlaceLocalHandle)(t$127554)), ((x10.core.fun.VoidFun_0_0)(start)));
        
        //#line 40 . "x10/lang/System.x10"
        final long t$127555 = java.lang.System.nanoTime();
        
        //#line 87 "x10/glb/GLB.x10"
        final long t$127556 = this.crunchNumberTime;
        
        //#line 87 "x10/glb/GLB.x10"
        final long t$127557 = ((t$127555) - (((long)(t$127556))));
        
        //#line 87 "x10/glb/GLB.x10"
        ((x10.glb.GLB<$Queue, $R>)this).crunchNumberTime = t$127557;
        
        //#line 88 "x10/glb/GLB.x10"
        final x10.core.Rail r = ((x10.core.Rail<$R>)
                                  this.collectResults());
        
        //#line 90 "x10/glb/GLB.x10"
        this.end__0$1x10$glb$GLB$$R$2(((x10.core.Rail)(r)));
        
        //#line 91 "x10/glb/GLB.x10"
        return r;
    }
    
    
    //#line 98 "x10/glb/GLB.x10"
    /**
     * Run method. This method is called when users can know the workload upfront and initialize the
     * workload in {@link TaskQueue}
     */
    public x10.core.Rail runParallel() {
        
        //#line 40 . "x10/lang/System.x10"
        final long t$127558 = java.lang.System.nanoTime();
        
        //#line 99 "x10/glb/GLB.x10"
        ((x10.glb.GLB<$Queue, $R>)this).crunchNumberTime = t$127558;
        
        //#line 100 "x10/glb/GLB.x10"
        final x10.lang.PlaceLocalHandle t$127559 = ((x10.lang.PlaceLocalHandle)(this.plh));
        
        //#line 100 "x10/glb/GLB.x10"
        x10.glb.Worker.<$Queue, $R> broadcast__0$1x10$glb$Worker$1x10$glb$Worker$$Queue$3x10$glb$Worker$$R$2$2($Queue, $R, ((x10.lang.PlaceLocalHandle)(t$127559)));
        
        //#line 40 . "x10/lang/System.x10"
        final long t$127560 = java.lang.System.nanoTime();
        
        //#line 101 "x10/glb/GLB.x10"
        final long t$127561 = this.crunchNumberTime;
        
        //#line 101 "x10/glb/GLB.x10"
        final long t$127562 = ((t$127560) - (((long)(t$127561))));
        
        //#line 101 "x10/glb/GLB.x10"
        ((x10.glb.GLB<$Queue, $R>)this).crunchNumberTime = t$127562;
        
        //#line 102 "x10/glb/GLB.x10"
        final x10.core.Rail r = ((x10.core.Rail<$R>)
                                  this.collectResults());
        
        //#line 103 "x10/glb/GLB.x10"
        this.end__0$1x10$glb$GLB$$R$2(((x10.core.Rail)(r)));
        
        //#line 104 "x10/glb/GLB.x10"
        return r;
    }
    
    
    //#line 113 "x10/glb/GLB.x10"
    /**
     * Print various GLB-related information, including result; time spent in initialization, computation 
     * and result collection; any user specified log information (per place); and GLB statistics.
     * @param r result to print
     */
    private void end__0$1x10$glb$GLB$$R$2(final x10.core.Rail r) {
        
        //#line 114 "x10/glb/GLB.x10"
        final x10.glb.GLBParameters t$127563 = ((x10.glb.GLBParameters)(this.glbParams));
        
        //#line 114 "x10/glb/GLB.x10"
        final int t$127564 = t$127563.v;
        
        //#line 114 "x10/glb/GLB.x10"
        final int t$127565 = ((t$127564) & (((int)(1))));
        
        //#line 114 "x10/glb/GLB.x10"
        final boolean t$127567 = ((int) t$127565) != ((int) 0);
        
        //#line 114 "x10/glb/GLB.x10"
        if (t$127567) {
            
            //#line 115 "x10/glb/GLB.x10"
            final x10.glb.GLBResult t$127566 = ((x10.glb.GLBResult)(this.rootGlbR));
            
            //#line 115 "x10/glb/GLB.x10"
            ((x10.glb.GLBResult<$R>)t$127566).display__0$1x10$glb$GLBResult$$R$2(((x10.core.Rail)(r)));
        }
        
        //#line 117 "x10/glb/GLB.x10"
        final x10.glb.GLBParameters t$127568 = ((x10.glb.GLBParameters)(this.glbParams));
        
        //#line 117 "x10/glb/GLB.x10"
        final int t$127569 = t$127568.v;
        
        //#line 117 "x10/glb/GLB.x10"
        final int t$127570 = ((t$127569) & (((int)(2))));
        
        //#line 117 "x10/glb/GLB.x10"
        final boolean t$127586 = ((int) t$127570) != ((int) 0);
        
        //#line 117 "x10/glb/GLB.x10"
        if (t$127586) {
            
            //#line 118 "x10/glb/GLB.x10"
            final x10.io.Printer t$127574 = ((x10.io.Printer)(x10.io.Console.get$OUT()));
            
            //#line 118 "x10/glb/GLB.x10"
            final long t$127571 = this.setupTime;
            
            //#line 118 "x10/glb/GLB.x10"
            final double t$127572 = ((double)(long)(((long)(t$127571))));
            
            //#line 118 "x10/glb/GLB.x10"
            final double t$127573 = ((t$127572) / (((double)(1.0E9))));
            
            //#line 118 "x10/glb/GLB.x10"
            final java.lang.String t$127575 = (("Setup time(s):") + ((x10.core.Double.$box(t$127573))));
            
            //#line 118 "x10/glb/GLB.x10"
            t$127574.println(((java.lang.Object)(t$127575)));
            
            //#line 119 "x10/glb/GLB.x10"
            final x10.io.Printer t$127579 = ((x10.io.Printer)(x10.io.Console.get$OUT()));
            
            //#line 119 "x10/glb/GLB.x10"
            final long t$127576 = this.crunchNumberTime;
            
            //#line 119 "x10/glb/GLB.x10"
            final double t$127577 = ((double)(long)(((long)(t$127576))));
            
            //#line 119 "x10/glb/GLB.x10"
            final double t$127578 = ((t$127577) / (((double)(1.0E9))));
            
            //#line 119 "x10/glb/GLB.x10"
            final java.lang.String t$127580 = (("Process time(s):") + ((x10.core.Double.$box(t$127578))));
            
            //#line 119 "x10/glb/GLB.x10"
            t$127579.println(((java.lang.Object)(t$127580)));
            
            //#line 120 "x10/glb/GLB.x10"
            final x10.io.Printer t$127584 = ((x10.io.Printer)(x10.io.Console.get$OUT()));
            
            //#line 120 "x10/glb/GLB.x10"
            final long t$127581 = this.collectResultTime;
            
            //#line 120 "x10/glb/GLB.x10"
            final double t$127582 = ((double)(long)(((long)(t$127581))));
            
            //#line 120 "x10/glb/GLB.x10"
            final double t$127583 = ((t$127582) / (((double)(1.0E9))));
            
            //#line 120 "x10/glb/GLB.x10"
            final java.lang.String t$127585 = (("Result reduce time(s):") + ((x10.core.Double.$box(t$127583))));
            
            //#line 120 "x10/glb/GLB.x10"
            t$127584.println(((java.lang.Object)(t$127585)));
        }
        
        //#line 126 "x10/glb/GLB.x10"
        final x10.glb.GLBParameters t$127587 = ((x10.glb.GLBParameters)(this.glbParams));
        
        //#line 126 "x10/glb/GLB.x10"
        final int t$127588 = t$127587.v;
        
        //#line 126 "x10/glb/GLB.x10"
        final int t$127589 = ((t$127588) & (((int)(4))));
        
        //#line 126 "x10/glb/GLB.x10"
        final boolean t$127591 = ((int) t$127589) != ((int) 0);
        
        //#line 126 "x10/glb/GLB.x10"
        if (t$127591) {
            
            //#line 127 "x10/glb/GLB.x10"
            final x10.lang.PlaceLocalHandle t$127590 = ((x10.lang.PlaceLocalHandle)(this.plh));
            
            //#line 127 "x10/glb/GLB.x10"
            this.printLog__0$1x10$glb$Worker$1x10$glb$GLB$$Queue$3x10$glb$GLB$$R$2$2(((x10.lang.PlaceLocalHandle)(t$127590)));
        }
        
        //#line 129 "x10/glb/GLB.x10"
        final x10.glb.GLBParameters t$127592 = ((x10.glb.GLBParameters)(this.glbParams));
        
        //#line 129 "x10/glb/GLB.x10"
        final int t$127593 = t$127592.v;
        
        //#line 129 "x10/glb/GLB.x10"
        final int t$127594 = ((t$127593) & (((int)(8))));
        
        //#line 129 "x10/glb/GLB.x10"
        final boolean t$127596 = ((int) t$127594) != ((int) 0);
        
        //#line 129 "x10/glb/GLB.x10"
        if (t$127596) {
            
            //#line 130 "x10/glb/GLB.x10"
            final x10.lang.PlaceLocalHandle t$127595 = ((x10.lang.PlaceLocalHandle)(this.plh));
            
            //#line 130 "x10/glb/GLB.x10"
            this.collectLifelineStatus__0$1x10$glb$Worker$1x10$glb$GLB$$Queue$3x10$glb$GLB$$R$2$2(((x10.lang.PlaceLocalHandle)(t$127595)));
        }
    }
    
    public static <$Queue, $R>void end$P__0$1x10$glb$GLB$$R$2__1$1x10$glb$GLB$$Queue$3x10$glb$GLB$$R$2(final x10.rtt.Type $Queue, final x10.rtt.Type $R, final x10.core.Rail<$R> r, final x10.glb.GLB<$Queue, $R> GLB) {
        ((x10.glb.GLB<$Queue, $R>)GLB).end__0$1x10$glb$GLB$$R$2(((x10.core.Rail)(r)));
    }
    
    
    //#line 138 "x10/glb/GLB.x10"
    /**
     * Collect GLB statistics
     * @param st PlaceLocalHandle for {@link Worker}
     */
    private void collectLifelineStatus__0$1x10$glb$Worker$1x10$glb$GLB$$Queue$3x10$glb$GLB$$R$2$2(final x10.lang.PlaceLocalHandle st) {
        
        //#line 139 "x10/glb/GLB.x10"
        final x10.core.Rail logs;
        
        //#line 141 "x10/glb/GLB.x10"
        final long t$127597 = this.P;
        
        //#line 141 "x10/glb/GLB.x10"
        final boolean t$127608 = ((t$127597) >= (((long)(1024L))));
        
        //#line 141 "x10/glb/GLB.x10"
        if (t$127608) {
            
            //#line 142 "x10/glb/GLB.x10"
            final long t$127598 = this.P;
            
            //#line 142 "x10/glb/GLB.x10"
            final long t$127602 = ((t$127598) / (((long)(32L))));
            
            //#line 142 "x10/glb/GLB.x10"
            final x10.core.fun.Fun_0_1 t$127603 = ((x10.core.fun.Fun_0_1)(new x10.glb.GLB.$Closure$65<$Queue, $R>($Queue, $R, ((x10.glb.GLB<$Queue, $R>)(this)), this.P, st, (x10.glb.GLB.$Closure$65.__0$1x10$glb$GLB$$Closure$65$$Queue$3x10$glb$GLB$$Closure$65$$R$2__2$1x10$glb$Worker$1x10$glb$GLB$$Closure$65$$Queue$3x10$glb$GLB$$Closure$65$$R$2$2) null)));
            
            //#line 142 "x10/glb/GLB.x10"
            final x10.core.Rail t$127604 = ((x10.core.Rail)(new x10.core.Rail<x10.glb.Logger>(x10.glb.Logger.$RTT, t$127602, ((x10.core.fun.Fun_0_1)(t$127603)), (x10.core.Rail.__1$1x10$lang$Long$3x10$lang$Rail$$T$2) null)));
            
            //#line 142 "x10/glb/GLB.x10"
            logs = ((x10.core.Rail)(t$127604));
        } else {
            
            //#line 151 "x10/glb/GLB.x10"
            final long t$127605 = this.P;
            
            //#line 151 "x10/glb/GLB.x10"
            final x10.core.fun.Fun_0_1 t$127606 = ((x10.core.fun.Fun_0_1)(new x10.glb.GLB.$Closure$67<$Queue, $R>($Queue, $R, ((x10.glb.GLB<$Queue, $R>)(this)), st, (x10.glb.GLB.$Closure$67.__0$1x10$glb$GLB$$Closure$67$$Queue$3x10$glb$GLB$$Closure$67$$R$2__1$1x10$glb$Worker$1x10$glb$GLB$$Closure$67$$Queue$3x10$glb$GLB$$Closure$67$$R$2$2) null)));
            
            //#line 151 "x10/glb/GLB.x10"
            final x10.core.Rail t$127607 = ((x10.core.Rail)(new x10.core.Rail<x10.glb.Logger>(x10.glb.Logger.$RTT, ((long)(t$127605)), ((x10.core.fun.Fun_0_1)(t$127606)), (x10.core.Rail.__1$1x10$lang$Long$3x10$lang$Rail$$T$2) null)));
            
            //#line 151 "x10/glb/GLB.x10"
            logs = ((x10.core.Rail)(t$127607));
        }
        
        //#line 153 "x10/glb/GLB.x10"
        final x10.glb.Logger log = ((x10.glb.Logger)(new x10.glb.Logger((java.lang.System[]) null)));
        
        //#line 153 "x10/glb/GLB.x10"
        log.x10$glb$Logger$$init$S(((boolean)(false)));
        
        //#line 154 "x10/glb/GLB.x10"
        log.collect__0$1x10$glb$Logger$2(((x10.core.Rail)(logs)));
        
        //#line 155 "x10/glb/GLB.x10"
        log.stats();
    }
    
    public static <$Queue, $R>void collectLifelineStatus$P__0$1x10$glb$Worker$1x10$glb$GLB$$Queue$3x10$glb$GLB$$R$2$2__1$1x10$glb$GLB$$Queue$3x10$glb$GLB$$R$2(final x10.rtt.Type $Queue, final x10.rtt.Type $R, final x10.lang.PlaceLocalHandle<x10.glb.Worker<$Queue, $R>> st, final x10.glb.GLB<$Queue, $R> GLB) {
        ((x10.glb.GLB<$Queue, $R>)GLB).collectLifelineStatus__0$1x10$glb$Worker$1x10$glb$GLB$$Queue$3x10$glb$GLB$$R$2$2(((x10.lang.PlaceLocalHandle)(st)));
    }
    
    
    //#line 162 "x10/glb/GLB.x10"
    /**
     * Collect results from all places and reduce them to the final result.
     * @return Final result.
     */
    public x10.core.Rail collectResults() {
        
        //#line 40 . "x10/lang/System.x10"
        final long t$127609 = java.lang.System.nanoTime();
        
        //#line 163 "x10/glb/GLB.x10"
        ((x10.glb.GLB<$Queue, $R>)this).collectResultTime = t$127609;
        
        //#line 166 "x10/glb/GLB.x10"
        final x10.lang.PlaceLocalHandle t$127610 = ((x10.lang.PlaceLocalHandle)(this.plh));
        
        //#line 166 "x10/glb/GLB.x10"
        final x10.glb.Worker t$127611 = ((x10.lang.PlaceLocalHandle<x10.glb.Worker<$Queue, $R>>)t$127610).$apply$G();
        
        //#line 166 "x10/glb/GLB.x10"
        final $Queue t$127612 = (($Queue)(((x10.glb.Worker<$Queue, $R>)t$127611).queue));
        
        //#line 166 "x10/glb/GLB.x10"
        final x10.glb.GLBResult t$127613 = ((x10.glb.GLBResult<$R>)
                                             ((x10.glb.TaskQueue<$Queue, $R>)x10.rtt.Types.conversion(x10.rtt.ParameterizedType.make(x10.glb.TaskQueue.$RTT, $Queue, $R),t$127612)).getResult());
        
        //#line 166 "x10/glb/GLB.x10"
        ((x10.glb.GLB<$Queue, $R>)this).rootGlbR = ((x10.glb.GLBResult)(t$127613));
        
        //#line 167 "x10/glb/GLB.x10"
        final x10.glb.GLBResult t$127614 = ((x10.glb.GLBResult)(this.rootGlbR));
        
        //#line 167 "x10/glb/GLB.x10"
        final x10.core.GlobalRef resultGlobal = ((x10.core.GlobalRef)(new x10.core.GlobalRef<x10.glb.GLBResult<$R>>(x10.rtt.ParameterizedType.make(x10.glb.GLBResult.$RTT, $R), t$127614, (x10.core.GlobalRef.__0x10$lang$GlobalRef$$T) null)));
        
        //#line 168 "x10/glb/GLB.x10"
        final x10.glb.GLBResult t$127615 = ((x10.glb.GLBResult)(this.rootGlbR));
        
        //#line 168 "x10/glb/GLB.x10"
        final x10.core.Rail tmpRail = ((x10.core.Rail<$R>)
                                        ((x10.glb.GLBResult<$R>)t$127615).submitResult());
        
        //#line 169 "x10/glb/GLB.x10"
        final x10.lang.PlaceLocalHandle tmpPlh = ((x10.lang.PlaceLocalHandle)(this.plh));
        
        //#line 172 "x10/glb/GLB.x10"
        final x10.lang.PlaceGroup t$127640 = ((x10.lang.PlaceGroup)(x10.lang.Place.places()));
        
        //#line 172 "x10/glb/GLB.x10"
        final x10.core.fun.VoidFun_0_0 t$127641 = ((x10.core.fun.VoidFun_0_0)(new x10.glb.GLB.$Closure$68<$Queue, $R>($Queue, $R, resultGlobal, tmpPlh, (x10.glb.GLB.$Closure$68.__0$1x10$glb$GLBResult$1x10$glb$GLB$$Closure$68$$R$2$2__1$1x10$glb$Worker$1x10$glb$GLB$$Closure$68$$Queue$3x10$glb$GLB$$Closure$68$$R$2$2) null)));
        
        //#line 172 "x10/glb/GLB.x10"
        t$127640.broadcastFlat(((x10.core.fun.VoidFun_0_0)(t$127641)));
        
        //#line 40 . "x10/lang/System.x10"
        final long t$127642 = java.lang.System.nanoTime();
        
        //#line 192 "x10/glb/GLB.x10"
        final long t$127643 = this.collectResultTime;
        
        //#line 192 "x10/glb/GLB.x10"
        final long t$127644 = ((t$127642) - (((long)(t$127643))));
        
        //#line 192 "x10/glb/GLB.x10"
        ((x10.glb.GLB<$Queue, $R>)this).collectResultTime = t$127644;
        
        //#line 194 "x10/glb/GLB.x10"
        return tmpRail;
    }
    
    
    //#line 203 "x10/glb/GLB.x10"
    /**
     * Print logging information on each place if user is interested in collecting per place
     * information, i.e., statistics instrumented.
     * @param st PLH for {@link Worker}
     */
    private void printLog__0$1x10$glb$Worker$1x10$glb$GLB$$Queue$3x10$glb$GLB$$R$2$2(final x10.lang.PlaceLocalHandle st) {
        
        //#line 204 "x10/glb/GLB.x10"
        final long P = ((long)x10.x10rt.X10RT.numPlaces());
        
        //#line 205 "x10/glb/GLB.x10"
        long i$127666 = 0L;
        
        //#line 205 "x10/glb/GLB.x10"
        for (;
             true;
             ) {
            
            //#line 205 "x10/glb/GLB.x10"
            final boolean t$127668 = ((i$127666) < (((long)(P))));
            
            //#line 205 "x10/glb/GLB.x10"
            if (!(t$127668)) {
                
                //#line 205 "x10/glb/GLB.x10"
                break;
            }
            
            //#line 206 "x10/glb/GLB.x10"
            final x10.lang.Place alloc$127661 = ((x10.lang.Place)(new x10.lang.Place((java.lang.System[]) null)));
            
            //#line 206 "x10/glb/GLB.x10"
            alloc$127661.x10$lang$Place$$init$S(i$127666);
            {
                
                //#line 206 "x10/glb/GLB.x10"
                x10.xrx.Runtime.runAt(((x10.lang.Place)(alloc$127661)), ((x10.core.fun.VoidFun_0_0)(new x10.glb.GLB.$Closure$69<$Queue, $R>($Queue, $R, st, (x10.glb.GLB.$Closure$69.__0$1x10$glb$Worker$1x10$glb$GLB$$Closure$69$$Queue$3x10$glb$GLB$$Closure$69$$R$2$2) null))), ((x10.xrx.Runtime.Profile)(null)));
            }
            
            //#line 205 "x10/glb/GLB.x10"
            final long t$127665 = ((i$127666) + (((long)(1L))));
            
            //#line 205 "x10/glb/GLB.x10"
            i$127666 = t$127665;
        }
    }
    
    public static <$Queue, $R>void printLog$P__0$1x10$glb$Worker$1x10$glb$GLB$$Queue$3x10$glb$GLB$$R$2$2__1$1x10$glb$GLB$$Queue$3x10$glb$GLB$$R$2(final x10.rtt.Type $Queue, final x10.rtt.Type $R, final x10.lang.PlaceLocalHandle<x10.glb.Worker<$Queue, $R>> st, final x10.glb.GLB<$Queue, $R> GLB) {
        ((x10.glb.GLB<$Queue, $R>)GLB).printLog__0$1x10$glb$Worker$1x10$glb$GLB$$Queue$3x10$glb$GLB$$R$2$2(((x10.lang.PlaceLocalHandle)(st)));
    }
    
    
    //#line 21 "x10/glb/GLB.x10"
    final public x10.glb.GLB x10$glb$GLB$$this$x10$glb$GLB() {
        
        //#line 21 "x10/glb/GLB.x10"
        return x10.glb.GLB.this;
    }
    
    
    //#line 21 "x10/glb/GLB.x10"
    final public void __fieldInitializers_x10_glb_GLB() {
        
        //#line 25 "x10/glb/GLB.x10"
        final long t$127653 = ((long)x10.x10rt.X10RT.numPlaces());
        
        //#line 21 "x10/glb/GLB.x10"
        ((x10.glb.GLB<$Queue, $R>)this).P = t$127653;
        
        //#line 21 "x10/glb/GLB.x10"
        ((x10.glb.GLB<$Queue, $R>)this).setupTime = 0L;
        
        //#line 21 "x10/glb/GLB.x10"
        ((x10.glb.GLB<$Queue, $R>)this).crunchNumberTime = 0L;
        
        //#line 21 "x10/glb/GLB.x10"
        ((x10.glb.GLB<$Queue, $R>)this).collectResultTime = 0L;
        
        //#line 21 "x10/glb/GLB.x10"
        ((x10.glb.GLB<$Queue, $R>)this).rootGlbR = null;
        
        //#line 57 "x10/glb/GLB.x10"
        final x10.glb.GLBParameters t$127654 = (x10.glb.GLBParameters) x10.rtt.Types.zeroValue(x10.glb.GLBParameters.$RTT);
        
        //#line 21 "x10/glb/GLB.x10"
        ((x10.glb.GLB<$Queue, $R>)this).glbParams = t$127654;
    }
    
    @x10.runtime.impl.java.X10Generated
    final public static class $Closure$61<$Queue, $R> extends x10.core.Ref implements x10.core.fun.Fun_0_0, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<$Closure$61> $RTT = 
            x10.rtt.StaticFunType.<$Closure$61> make($Closure$61.class,
                                                     2,
                                                     new x10.rtt.Type[] {
                                                         x10.rtt.ParameterizedType.make(x10.core.fun.Fun_0_0.$RTT, x10.rtt.ParameterizedType.make(x10.glb.Worker.$RTT, x10.rtt.UnresolvedType.PARAM(0), x10.rtt.UnresolvedType.PARAM(1)))
                                                     });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { if (i == 0) return $Queue; if (i == 1) return $R; return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static <$Queue, $R> x10.serialization.X10JavaSerializable $_deserialize_body(x10.glb.GLB.$Closure$61<$Queue, $R> $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            $_obj.$Queue = (x10.rtt.Type) $deserializer.readObject();
            $_obj.$R = (x10.rtt.Type) $deserializer.readObject();
            $_obj.glbParams = $deserializer.readObject();
            $_obj.init = $deserializer.readObject();
            $_obj.tree = $deserializer.readBoolean();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.glb.GLB.$Closure$61 $_obj = new x10.glb.GLB.$Closure$61((java.lang.System[]) null, (x10.rtt.Type) null, (x10.rtt.Type) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            $serializer.write(this.$Queue);
            $serializer.write(this.$R);
            $serializer.write(this.glbParams);
            $serializer.write(this.init);
            $serializer.write(this.tree);
            
        }
        
        // constructor just for allocation
        public $Closure$61(final java.lang.System[] $dummy, final x10.rtt.Type $Queue, final x10.rtt.Type $R) {
            x10.glb.GLB.$Closure$61.$initParams(this, $Queue, $R);
            
        }
        
        // bridge for method abstract public ()=>U.operator()():U
        public x10.glb.Worker $apply$G() {
            return $apply();
        }
        
        private x10.rtt.Type $Queue;
        private x10.rtt.Type $R;
        
        // initializer of type parameters
        public static void $initParams(final $Closure$61 $this, final x10.rtt.Type $Queue, final x10.rtt.Type $R) {
            $this.$Queue = $Queue;
            $this.$R = $R;
            
        }
        // synthetic type for parameter mangling
        public static final class __1$1x10$glb$GLB$$Closure$61$$Queue$2 {}
        
    
        
        public x10.glb.Worker $apply() {
            
            //#line 69 "x10/glb/GLB.x10"
            final x10.glb.Worker alloc$119499 = ((x10.glb.Worker)(new x10.glb.Worker<$Queue, $R>((java.lang.System[]) null, $Queue, $R)));
            
            //#line 69 "x10/glb/GLB.x10"
            final int t$127655 = this.glbParams.n;
            
            //#line 69 "x10/glb/GLB.x10"
            final int t$127656 = this.glbParams.w;
            
            //#line 69 "x10/glb/GLB.x10"
            final int t$127657 = this.glbParams.l;
            
            //#line 69 "x10/glb/GLB.x10"
            final int t$127658 = this.glbParams.z;
            
            //#line 69 "x10/glb/GLB.x10"
            final int t$127659 = this.glbParams.m;
            
            //#line 69 "x10/glb/GLB.x10"
            alloc$119499.x10$glb$Worker$$init$S(this.init, ((int)(t$127655)), ((int)(t$127656)), ((int)(t$127657)), ((int)(t$127658)), ((int)(t$127659)), this.tree, (x10.glb.Worker.__0$1x10$glb$Worker$$Queue$2) null);
            
            //#line 69 "x10/glb/GLB.x10"
            return alloc$119499;
        }
        
        public x10.glb.GLBParameters glbParams;
        public x10.core.fun.Fun_0_0<$Queue> init;
        public boolean tree;
        
        public $Closure$61(final x10.rtt.Type $Queue, final x10.rtt.Type $R, final x10.glb.GLBParameters glbParams, final x10.core.fun.Fun_0_0<$Queue> init, final boolean tree, __1$1x10$glb$GLB$$Closure$61$$Queue$2 $dummy) {
            x10.glb.GLB.$Closure$61.$initParams(this, $Queue, $R);
             {
                ((x10.glb.GLB.$Closure$61<$Queue, $R>)this).glbParams = ((x10.glb.GLBParameters)(glbParams));
                ((x10.glb.GLB.$Closure$61<$Queue, $R>)this).init = ((x10.core.fun.Fun_0_0)(init));
                ((x10.glb.GLB.$Closure$61<$Queue, $R>)this).tree = tree;
            }
        }
        
    }
    
    @x10.runtime.impl.java.X10Generated
    final public static class $Closure$62<$Queue, $R> extends x10.core.Ref implements x10.core.fun.Fun_0_0, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<$Closure$62> $RTT = 
            x10.rtt.StaticFunType.<$Closure$62> make($Closure$62.class,
                                                     2,
                                                     new x10.rtt.Type[] {
                                                         x10.rtt.ParameterizedType.make(x10.core.fun.Fun_0_0.$RTT, x10.glb.Logger.$RTT)
                                                     });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { if (i == 0) return $Queue; if (i == 1) return $R; return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static <$Queue, $R> x10.serialization.X10JavaSerializable $_deserialize_body(x10.glb.GLB.$Closure$62<$Queue, $R> $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            $_obj.$Queue = (x10.rtt.Type) $deserializer.readObject();
            $_obj.$R = (x10.rtt.Type) $deserializer.readObject();
            $_obj.out$$ = $deserializer.readObject();
            $_obj.st = $deserializer.readObject();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.glb.GLB.$Closure$62 $_obj = new x10.glb.GLB.$Closure$62((java.lang.System[]) null, (x10.rtt.Type) null, (x10.rtt.Type) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            $serializer.write(this.$Queue);
            $serializer.write(this.$R);
            $serializer.write(this.out$$);
            $serializer.write(this.st);
            
        }
        
        // constructor just for allocation
        public $Closure$62(final java.lang.System[] $dummy, final x10.rtt.Type $Queue, final x10.rtt.Type $R) {
            x10.glb.GLB.$Closure$62.$initParams(this, $Queue, $R);
            
        }
        
        // bridge for method abstract public ()=>U.operator()():U
        public x10.glb.Logger $apply$G() {
            return $apply();
        }
        
        private x10.rtt.Type $Queue;
        private x10.rtt.Type $R;
        
        // initializer of type parameters
        public static void $initParams(final $Closure$62 $this, final x10.rtt.Type $Queue, final x10.rtt.Type $R) {
            $this.$Queue = $Queue;
            $this.$R = $R;
            
        }
        // synthetic type for parameter mangling
        public static final class __0$1x10$glb$GLB$$Closure$62$$Queue$3x10$glb$GLB$$Closure$62$$R$2__1$1x10$glb$Worker$1x10$glb$GLB$$Closure$62$$Queue$3x10$glb$GLB$$Closure$62$$R$2$2 {}
        
    
        
        public x10.glb.Logger $apply() {
            
            //#line 145 "x10/glb/GLB.x10"
            try {{
                
                //#line 145 "x10/glb/GLB.x10"
                final x10.glb.Worker t$119309 = ((x10.lang.PlaceLocalHandle<x10.glb.Worker<$Queue, $R>>)this.st).$apply$G();
                
                //#line 145 "x10/glb/GLB.x10"
                final x10.glb.Logger t$119314 = ((x10.glb.Logger)(((x10.glb.Worker<$Queue, $R>)t$119309).logger));
                
                //#line 145 "x10/glb/GLB.x10"
                final x10.glb.GLBParameters t$119310 = ((x10.glb.GLBParameters)(((x10.glb.GLB<$Queue, $R>)this.out$$).glbParams));
                
                //#line 145 "x10/glb/GLB.x10"
                final int t$119311 = t$119310.v;
                
                //#line 145 "x10/glb/GLB.x10"
                final int t$119313 = ((t$119311) & (((int)(8))));
                
                //#line 145 "x10/glb/GLB.x10"
                final boolean t$119315 = ((int) t$119313) != ((int) 0);
                
                //#line 145 "x10/glb/GLB.x10"
                final x10.glb.Logger t$119316 = ((x10.glb.Logger)(t$119314.get((boolean)(t$119315))));
                
                //#line 145 "x10/glb/GLB.x10"
                return t$119316;
            }}catch (java.lang.Throwable __lowerer__var__0__) {
                
                //#line 145 "x10/glb/GLB.x10"
                x10.glb.Logger __lowerer__var__1__ = ((x10.glb.Logger)(x10.xrx.Runtime.<x10.glb.Logger> wrapAtChecked$G(x10.glb.Logger.$RTT, ((java.lang.Throwable)(__lowerer__var__0__)))));
                
                //#line 145 "x10/glb/GLB.x10"
                return __lowerer__var__1__;
            }
        }
        
        public x10.glb.GLB<$Queue, $R> out$$;
        public x10.lang.PlaceLocalHandle<x10.glb.Worker<$Queue, $R>> st;
        
        public $Closure$62(final x10.rtt.Type $Queue, final x10.rtt.Type $R, final x10.glb.GLB<$Queue, $R> out$$, final x10.lang.PlaceLocalHandle<x10.glb.Worker<$Queue, $R>> st, __0$1x10$glb$GLB$$Closure$62$$Queue$3x10$glb$GLB$$Closure$62$$R$2__1$1x10$glb$Worker$1x10$glb$GLB$$Closure$62$$Queue$3x10$glb$GLB$$Closure$62$$R$2$2 $dummy) {
            x10.glb.GLB.$Closure$62.$initParams(this, $Queue, $R);
             {
                ((x10.glb.GLB.$Closure$62<$Queue, $R>)this).out$$ = out$$;
                ((x10.glb.GLB.$Closure$62<$Queue, $R>)this).st = ((x10.lang.PlaceLocalHandle)(st));
            }
        }
        
    }
    
    @x10.runtime.impl.java.X10Generated
    final public static class $Closure$63<$Queue, $R> extends x10.core.Ref implements x10.core.fun.Fun_0_1, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<$Closure$63> $RTT = 
            x10.rtt.StaticFunType.<$Closure$63> make($Closure$63.class,
                                                     2,
                                                     new x10.rtt.Type[] {
                                                         x10.rtt.ParameterizedType.make(x10.core.fun.Fun_0_1.$RTT, x10.rtt.Types.LONG, x10.glb.Logger.$RTT)
                                                     });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { if (i == 0) return $Queue; if (i == 1) return $R; return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static <$Queue, $R> x10.serialization.X10JavaSerializable $_deserialize_body(x10.glb.GLB.$Closure$63<$Queue, $R> $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            $_obj.$Queue = (x10.rtt.Type) $deserializer.readObject();
            $_obj.$R = (x10.rtt.Type) $deserializer.readObject();
            $_obj.h = $deserializer.readLong();
            $_obj.out$$ = $deserializer.readObject();
            $_obj.st = $deserializer.readObject();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.glb.GLB.$Closure$63 $_obj = new x10.glb.GLB.$Closure$63((java.lang.System[]) null, (x10.rtt.Type) null, (x10.rtt.Type) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            $serializer.write(this.$Queue);
            $serializer.write(this.$R);
            $serializer.write(this.h);
            $serializer.write(this.out$$);
            $serializer.write(this.st);
            
        }
        
        // constructor just for allocation
        public $Closure$63(final java.lang.System[] $dummy, final x10.rtt.Type $Queue, final x10.rtt.Type $R) {
            x10.glb.GLB.$Closure$63.$initParams(this, $Queue, $R);
            
        }
        
        // dispatcher for method abstract public (Z1)=>U.operator()(a1:Z1):U
        public java.lang.Object $apply(final java.lang.Object a1, final x10.rtt.Type t1) {
            return $apply(x10.core.Long.$unbox(a1));
            
        }
        
        private x10.rtt.Type $Queue;
        private x10.rtt.Type $R;
        
        // initializer of type parameters
        public static void $initParams(final $Closure$63 $this, final x10.rtt.Type $Queue, final x10.rtt.Type $R) {
            $this.$Queue = $Queue;
            $this.$R = $R;
            
        }
        // synthetic type for parameter mangling
        public static final class __0$1x10$glb$GLB$$Closure$63$$Queue$3x10$glb$GLB$$Closure$63$$R$2__2$1x10$glb$Worker$1x10$glb$GLB$$Closure$63$$Queue$3x10$glb$GLB$$Closure$63$$R$2$2 {}
        
    
        
        public x10.glb.Logger $apply(final long i) {
            
            //#line 145 "x10/glb/GLB.x10"
            final long t$119308 = ((this.h) + (((long)(i))));
            
            //#line 145 "x10/glb/GLB.x10"
            final x10.lang.Place t$119317 = ((x10.lang.Place)(new x10.lang.Place((java.lang.System[]) null)));
            
            //#line 145 "x10/glb/GLB.x10"
            t$119317.x10$lang$Place$$init$S(t$119308);
            
            //#line 145 "x10/glb/GLB.x10"
            final x10.glb.Logger t$119318 = ((x10.glb.Logger)(x10.xrx.Runtime.<x10.glb.Logger> evalAt__1$1x10$xrx$Runtime$$T$2$G(x10.glb.Logger.$RTT, ((x10.lang.Place)(t$119317)), ((x10.core.fun.Fun_0_0)(new x10.glb.GLB.$Closure$62<$Queue, $R>($Queue, $R, ((x10.glb.GLB<$Queue, $R>)(this.out$$)), ((x10.lang.PlaceLocalHandle<x10.glb.Worker<$Queue, $R>>)(this.st)), (x10.glb.GLB.$Closure$62.__0$1x10$glb$GLB$$Closure$62$$Queue$3x10$glb$GLB$$Closure$62$$R$2__1$1x10$glb$Worker$1x10$glb$GLB$$Closure$62$$Queue$3x10$glb$GLB$$Closure$62$$R$2$2) null))), ((x10.xrx.Runtime.Profile)(null)))));
            
            //#line 145 "x10/glb/GLB.x10"
            return t$119318;
        }
        
        public x10.glb.GLB<$Queue, $R> out$$;
        public long h;
        public x10.lang.PlaceLocalHandle<x10.glb.Worker<$Queue, $R>> st;
        
        public $Closure$63(final x10.rtt.Type $Queue, final x10.rtt.Type $R, final x10.glb.GLB<$Queue, $R> out$$, final long h, final x10.lang.PlaceLocalHandle<x10.glb.Worker<$Queue, $R>> st, __0$1x10$glb$GLB$$Closure$63$$Queue$3x10$glb$GLB$$Closure$63$$R$2__2$1x10$glb$Worker$1x10$glb$GLB$$Closure$63$$Queue$3x10$glb$GLB$$Closure$63$$R$2$2 $dummy) {
            x10.glb.GLB.$Closure$63.$initParams(this, $Queue, $R);
             {
                ((x10.glb.GLB.$Closure$63<$Queue, $R>)this).out$$ = ((x10.glb.GLB)(out$$));
                ((x10.glb.GLB.$Closure$63<$Queue, $R>)this).h = h;
                ((x10.glb.GLB.$Closure$63<$Queue, $R>)this).st = ((x10.lang.PlaceLocalHandle)(st));
            }
        }
        
    }
    
    @x10.runtime.impl.java.X10Generated
    final public static class $Closure$64<$Queue, $R> extends x10.core.Ref implements x10.core.fun.Fun_0_0, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<$Closure$64> $RTT = 
            x10.rtt.StaticFunType.<$Closure$64> make($Closure$64.class,
                                                     2,
                                                     new x10.rtt.Type[] {
                                                         x10.rtt.ParameterizedType.make(x10.core.fun.Fun_0_0.$RTT, x10.glb.Logger.$RTT)
                                                     });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { if (i == 0) return $Queue; if (i == 1) return $R; return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static <$Queue, $R> x10.serialization.X10JavaSerializable $_deserialize_body(x10.glb.GLB.$Closure$64<$Queue, $R> $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            $_obj.$Queue = (x10.rtt.Type) $deserializer.readObject();
            $_obj.$R = (x10.rtt.Type) $deserializer.readObject();
            $_obj.P = $deserializer.readLong();
            $_obj.out$$ = $deserializer.readObject();
            $_obj.st = $deserializer.readObject();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.glb.GLB.$Closure$64 $_obj = new x10.glb.GLB.$Closure$64((java.lang.System[]) null, (x10.rtt.Type) null, (x10.rtt.Type) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            $serializer.write(this.$Queue);
            $serializer.write(this.$R);
            $serializer.write(this.P);
            $serializer.write(this.out$$);
            $serializer.write(this.st);
            
        }
        
        // constructor just for allocation
        public $Closure$64(final java.lang.System[] $dummy, final x10.rtt.Type $Queue, final x10.rtt.Type $R) {
            x10.glb.GLB.$Closure$64.$initParams(this, $Queue, $R);
            
        }
        
        // bridge for method abstract public ()=>U.operator()():U
        public x10.glb.Logger $apply$G() {
            return $apply();
        }
        
        private x10.rtt.Type $Queue;
        private x10.rtt.Type $R;
        
        // initializer of type parameters
        public static void $initParams(final $Closure$64 $this, final x10.rtt.Type $Queue, final x10.rtt.Type $R) {
            $this.$Queue = $Queue;
            $this.$R = $R;
            
        }
        // synthetic type for parameter mangling
        public static final class __0$1x10$glb$GLB$$Closure$64$$Queue$3x10$glb$GLB$$Closure$64$$R$2__2$1x10$glb$Worker$1x10$glb$GLB$$Closure$64$$Queue$3x10$glb$GLB$$Closure$64$$R$2$2 {}
        
    
        
        public x10.glb.Logger $apply() {
            
            //#line 142 "x10/glb/GLB.x10"
            try {{
                
                //#line 143 "x10/glb/GLB.x10"
                final long h = x10.x10rt.X10RT.here().id;
                
                //#line 144 "x10/glb/GLB.x10"
                final long t$119320 = this.P;
                
                //#line 144 "x10/glb/GLB.x10"
                final long t$119321 = ((t$119320) - (((long)(h))));
                
                //#line 52 . "x10/glb/GLB.x10"
                final boolean t$127599 = ((32L) < (((long)(t$119321))));
                
                //#line 52 . "x10/glb/GLB.x10"
                long t$127600 =  0;
                
                //#line 52 . "x10/glb/GLB.x10"
                if (t$127599) {
                    
                    //#line 52 . "x10/glb/GLB.x10"
                    t$127600 = 32L;
                } else {
                    
                    //#line 52 . "x10/glb/GLB.x10"
                    t$127600 = t$119321;
                }
                
                //#line 144 "x10/glb/GLB.x10"
                final long n = t$127600;
                
                //#line 145 "x10/glb/GLB.x10"
                final x10.core.fun.Fun_0_1 t$127601 = ((x10.core.fun.Fun_0_1)(new x10.glb.GLB.$Closure$63<$Queue, $R>($Queue, $R, ((x10.glb.GLB<$Queue, $R>)(this.out$$)), h, ((x10.lang.PlaceLocalHandle<x10.glb.Worker<$Queue, $R>>)(this.st)), (x10.glb.GLB.$Closure$63.__0$1x10$glb$GLB$$Closure$63$$Queue$3x10$glb$GLB$$Closure$63$$R$2__2$1x10$glb$Worker$1x10$glb$GLB$$Closure$63$$Queue$3x10$glb$GLB$$Closure$63$$R$2$2) null)));
                
                //#line 145 "x10/glb/GLB.x10"
                final x10.core.Rail logs = ((x10.core.Rail)(new x10.core.Rail<x10.glb.Logger>(x10.glb.Logger.$RTT, ((long)(n)), ((x10.core.fun.Fun_0_1)(t$127601)), (x10.core.Rail.__1$1x10$lang$Long$3x10$lang$Rail$$T$2) null)));
                
                //#line 146 "x10/glb/GLB.x10"
                final x10.glb.Logger log = ((x10.glb.Logger)(new x10.glb.Logger((java.lang.System[]) null)));
                
                //#line 146 "x10/glb/GLB.x10"
                log.x10$glb$Logger$$init$S(((boolean)(false)));
                
                //#line 147 "x10/glb/GLB.x10"
                log.collect__0$1x10$glb$Logger$2(((x10.core.Rail)(logs)));
                
                //#line 148 "x10/glb/GLB.x10"
                return log;
            }}catch (java.lang.Throwable __lowerer__var__0__) {
                
                //#line 142 "x10/glb/GLB.x10"
                x10.glb.Logger __lowerer__var__1__ = ((x10.glb.Logger)(x10.xrx.Runtime.<x10.glb.Logger> wrapAtChecked$G(x10.glb.Logger.$RTT, ((java.lang.Throwable)(__lowerer__var__0__)))));
                
                //#line 142 "x10/glb/GLB.x10"
                return __lowerer__var__1__;
            }
        }
        
        public x10.glb.GLB<$Queue, $R> out$$;
        public long P;
        public x10.lang.PlaceLocalHandle<x10.glb.Worker<$Queue, $R>> st;
        
        public $Closure$64(final x10.rtt.Type $Queue, final x10.rtt.Type $R, final x10.glb.GLB<$Queue, $R> out$$, final long P, final x10.lang.PlaceLocalHandle<x10.glb.Worker<$Queue, $R>> st, __0$1x10$glb$GLB$$Closure$64$$Queue$3x10$glb$GLB$$Closure$64$$R$2__2$1x10$glb$Worker$1x10$glb$GLB$$Closure$64$$Queue$3x10$glb$GLB$$Closure$64$$R$2$2 $dummy) {
            x10.glb.GLB.$Closure$64.$initParams(this, $Queue, $R);
             {
                ((x10.glb.GLB.$Closure$64<$Queue, $R>)this).out$$ = out$$;
                ((x10.glb.GLB.$Closure$64<$Queue, $R>)this).P = P;
                ((x10.glb.GLB.$Closure$64<$Queue, $R>)this).st = ((x10.lang.PlaceLocalHandle)(st));
            }
        }
        
    }
    
    @x10.runtime.impl.java.X10Generated
    final public static class $Closure$65<$Queue, $R> extends x10.core.Ref implements x10.core.fun.Fun_0_1, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<$Closure$65> $RTT = 
            x10.rtt.StaticFunType.<$Closure$65> make($Closure$65.class,
                                                     2,
                                                     new x10.rtt.Type[] {
                                                         x10.rtt.ParameterizedType.make(x10.core.fun.Fun_0_1.$RTT, x10.rtt.Types.LONG, x10.glb.Logger.$RTT)
                                                     });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { if (i == 0) return $Queue; if (i == 1) return $R; return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static <$Queue, $R> x10.serialization.X10JavaSerializable $_deserialize_body(x10.glb.GLB.$Closure$65<$Queue, $R> $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            $_obj.$Queue = (x10.rtt.Type) $deserializer.readObject();
            $_obj.$R = (x10.rtt.Type) $deserializer.readObject();
            $_obj.P = $deserializer.readLong();
            $_obj.out$$ = $deserializer.readObject();
            $_obj.st = $deserializer.readObject();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.glb.GLB.$Closure$65 $_obj = new x10.glb.GLB.$Closure$65((java.lang.System[]) null, (x10.rtt.Type) null, (x10.rtt.Type) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            $serializer.write(this.$Queue);
            $serializer.write(this.$R);
            $serializer.write(this.P);
            $serializer.write(this.out$$);
            $serializer.write(this.st);
            
        }
        
        // constructor just for allocation
        public $Closure$65(final java.lang.System[] $dummy, final x10.rtt.Type $Queue, final x10.rtt.Type $R) {
            x10.glb.GLB.$Closure$65.$initParams(this, $Queue, $R);
            
        }
        
        // dispatcher for method abstract public (Z1)=>U.operator()(a1:Z1):U
        public java.lang.Object $apply(final java.lang.Object a1, final x10.rtt.Type t1) {
            return $apply(x10.core.Long.$unbox(a1));
            
        }
        
        private x10.rtt.Type $Queue;
        private x10.rtt.Type $R;
        
        // initializer of type parameters
        public static void $initParams(final $Closure$65 $this, final x10.rtt.Type $Queue, final x10.rtt.Type $R) {
            $this.$Queue = $Queue;
            $this.$R = $R;
            
        }
        // synthetic type for parameter mangling
        public static final class __0$1x10$glb$GLB$$Closure$65$$Queue$3x10$glb$GLB$$Closure$65$$R$2__2$1x10$glb$Worker$1x10$glb$GLB$$Closure$65$$Queue$3x10$glb$GLB$$Closure$65$$R$2$2 {}
        
    
        
        public x10.glb.Logger $apply(final long i) {
            
            //#line 142 "x10/glb/GLB.x10"
            final long t$119319 = ((i) * (((long)(32L))));
            
            //#line 142 "x10/glb/GLB.x10"
            final x10.lang.Place t$119323 = ((x10.lang.Place)(new x10.lang.Place((java.lang.System[]) null)));
            
            //#line 142 "x10/glb/GLB.x10"
            t$119323.x10$lang$Place$$init$S(t$119319);
            
            //#line 142 "x10/glb/GLB.x10"
            final x10.glb.Logger t$119324 = ((x10.glb.Logger)(x10.xrx.Runtime.<x10.glb.Logger> evalAt__1$1x10$xrx$Runtime$$T$2$G(x10.glb.Logger.$RTT, ((x10.lang.Place)(t$119323)), ((x10.core.fun.Fun_0_0)(new x10.glb.GLB.$Closure$64<$Queue, $R>($Queue, $R, ((x10.glb.GLB<$Queue, $R>)(this.out$$)), ((long)(this.P)), ((x10.lang.PlaceLocalHandle<x10.glb.Worker<$Queue, $R>>)(this.st)), (x10.glb.GLB.$Closure$64.__0$1x10$glb$GLB$$Closure$64$$Queue$3x10$glb$GLB$$Closure$64$$R$2__2$1x10$glb$Worker$1x10$glb$GLB$$Closure$64$$Queue$3x10$glb$GLB$$Closure$64$$R$2$2) null))), ((x10.xrx.Runtime.Profile)(null)))));
            
            //#line 142 "x10/glb/GLB.x10"
            return t$119324;
        }
        
        public x10.glb.GLB<$Queue, $R> out$$;
        public long P;
        public x10.lang.PlaceLocalHandle<x10.glb.Worker<$Queue, $R>> st;
        
        public $Closure$65(final x10.rtt.Type $Queue, final x10.rtt.Type $R, final x10.glb.GLB<$Queue, $R> out$$, final long P, final x10.lang.PlaceLocalHandle<x10.glb.Worker<$Queue, $R>> st, __0$1x10$glb$GLB$$Closure$65$$Queue$3x10$glb$GLB$$Closure$65$$R$2__2$1x10$glb$Worker$1x10$glb$GLB$$Closure$65$$Queue$3x10$glb$GLB$$Closure$65$$R$2$2 $dummy) {
            x10.glb.GLB.$Closure$65.$initParams(this, $Queue, $R);
             {
                ((x10.glb.GLB.$Closure$65<$Queue, $R>)this).out$$ = ((x10.glb.GLB)(out$$));
                ((x10.glb.GLB.$Closure$65<$Queue, $R>)this).P = P;
                ((x10.glb.GLB.$Closure$65<$Queue, $R>)this).st = ((x10.lang.PlaceLocalHandle)(st));
            }
        }
        
    }
    
    @x10.runtime.impl.java.X10Generated
    final public static class $Closure$66<$Queue, $R> extends x10.core.Ref implements x10.core.fun.Fun_0_0, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<$Closure$66> $RTT = 
            x10.rtt.StaticFunType.<$Closure$66> make($Closure$66.class,
                                                     2,
                                                     new x10.rtt.Type[] {
                                                         x10.rtt.ParameterizedType.make(x10.core.fun.Fun_0_0.$RTT, x10.glb.Logger.$RTT)
                                                     });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { if (i == 0) return $Queue; if (i == 1) return $R; return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static <$Queue, $R> x10.serialization.X10JavaSerializable $_deserialize_body(x10.glb.GLB.$Closure$66<$Queue, $R> $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            $_obj.$Queue = (x10.rtt.Type) $deserializer.readObject();
            $_obj.$R = (x10.rtt.Type) $deserializer.readObject();
            $_obj.out$$ = $deserializer.readObject();
            $_obj.st = $deserializer.readObject();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.glb.GLB.$Closure$66 $_obj = new x10.glb.GLB.$Closure$66((java.lang.System[]) null, (x10.rtt.Type) null, (x10.rtt.Type) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            $serializer.write(this.$Queue);
            $serializer.write(this.$R);
            $serializer.write(this.out$$);
            $serializer.write(this.st);
            
        }
        
        // constructor just for allocation
        public $Closure$66(final java.lang.System[] $dummy, final x10.rtt.Type $Queue, final x10.rtt.Type $R) {
            x10.glb.GLB.$Closure$66.$initParams(this, $Queue, $R);
            
        }
        
        // bridge for method abstract public ()=>U.operator()():U
        public x10.glb.Logger $apply$G() {
            return $apply();
        }
        
        private x10.rtt.Type $Queue;
        private x10.rtt.Type $R;
        
        // initializer of type parameters
        public static void $initParams(final $Closure$66 $this, final x10.rtt.Type $Queue, final x10.rtt.Type $R) {
            $this.$Queue = $Queue;
            $this.$R = $R;
            
        }
        // synthetic type for parameter mangling
        public static final class __0$1x10$glb$GLB$$Closure$66$$Queue$3x10$glb$GLB$$Closure$66$$R$2__1$1x10$glb$Worker$1x10$glb$GLB$$Closure$66$$Queue$3x10$glb$GLB$$Closure$66$$R$2$2 {}
        
    
        
        public x10.glb.Logger $apply() {
            
            //#line 151 "x10/glb/GLB.x10"
            try {{
                
                //#line 151 "x10/glb/GLB.x10"
                final x10.glb.Worker t$119325 = ((x10.lang.PlaceLocalHandle<x10.glb.Worker<$Queue, $R>>)this.st).$apply$G();
                
                //#line 151 "x10/glb/GLB.x10"
                final x10.glb.Logger t$119330 = ((x10.glb.Logger)(((x10.glb.Worker<$Queue, $R>)t$119325).logger));
                
                //#line 151 "x10/glb/GLB.x10"
                final x10.glb.GLBParameters t$119326 = ((x10.glb.GLBParameters)(((x10.glb.GLB<$Queue, $R>)this.out$$).glbParams));
                
                //#line 151 "x10/glb/GLB.x10"
                final int t$119327 = t$119326.v;
                
                //#line 151 "x10/glb/GLB.x10"
                final int t$119329 = ((t$119327) & (((int)(8))));
                
                //#line 151 "x10/glb/GLB.x10"
                final boolean t$119331 = ((int) t$119329) != ((int) 0);
                
                //#line 151 "x10/glb/GLB.x10"
                final x10.glb.Logger t$119332 = ((x10.glb.Logger)(t$119330.get((boolean)(t$119331))));
                
                //#line 151 "x10/glb/GLB.x10"
                return t$119332;
            }}catch (java.lang.Throwable __lowerer__var__0__) {
                
                //#line 151 "x10/glb/GLB.x10"
                x10.glb.Logger __lowerer__var__1__ = ((x10.glb.Logger)(x10.xrx.Runtime.<x10.glb.Logger> wrapAtChecked$G(x10.glb.Logger.$RTT, ((java.lang.Throwable)(__lowerer__var__0__)))));
                
                //#line 151 "x10/glb/GLB.x10"
                return __lowerer__var__1__;
            }
        }
        
        public x10.glb.GLB<$Queue, $R> out$$;
        public x10.lang.PlaceLocalHandle<x10.glb.Worker<$Queue, $R>> st;
        
        public $Closure$66(final x10.rtt.Type $Queue, final x10.rtt.Type $R, final x10.glb.GLB<$Queue, $R> out$$, final x10.lang.PlaceLocalHandle<x10.glb.Worker<$Queue, $R>> st, __0$1x10$glb$GLB$$Closure$66$$Queue$3x10$glb$GLB$$Closure$66$$R$2__1$1x10$glb$Worker$1x10$glb$GLB$$Closure$66$$Queue$3x10$glb$GLB$$Closure$66$$R$2$2 $dummy) {
            x10.glb.GLB.$Closure$66.$initParams(this, $Queue, $R);
             {
                ((x10.glb.GLB.$Closure$66<$Queue, $R>)this).out$$ = out$$;
                ((x10.glb.GLB.$Closure$66<$Queue, $R>)this).st = ((x10.lang.PlaceLocalHandle)(st));
            }
        }
        
    }
    
    @x10.runtime.impl.java.X10Generated
    final public static class $Closure$67<$Queue, $R> extends x10.core.Ref implements x10.core.fun.Fun_0_1, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<$Closure$67> $RTT = 
            x10.rtt.StaticFunType.<$Closure$67> make($Closure$67.class,
                                                     2,
                                                     new x10.rtt.Type[] {
                                                         x10.rtt.ParameterizedType.make(x10.core.fun.Fun_0_1.$RTT, x10.rtt.Types.LONG, x10.glb.Logger.$RTT)
                                                     });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { if (i == 0) return $Queue; if (i == 1) return $R; return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static <$Queue, $R> x10.serialization.X10JavaSerializable $_deserialize_body(x10.glb.GLB.$Closure$67<$Queue, $R> $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            $_obj.$Queue = (x10.rtt.Type) $deserializer.readObject();
            $_obj.$R = (x10.rtt.Type) $deserializer.readObject();
            $_obj.out$$ = $deserializer.readObject();
            $_obj.st = $deserializer.readObject();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.glb.GLB.$Closure$67 $_obj = new x10.glb.GLB.$Closure$67((java.lang.System[]) null, (x10.rtt.Type) null, (x10.rtt.Type) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            $serializer.write(this.$Queue);
            $serializer.write(this.$R);
            $serializer.write(this.out$$);
            $serializer.write(this.st);
            
        }
        
        // constructor just for allocation
        public $Closure$67(final java.lang.System[] $dummy, final x10.rtt.Type $Queue, final x10.rtt.Type $R) {
            x10.glb.GLB.$Closure$67.$initParams(this, $Queue, $R);
            
        }
        
        // dispatcher for method abstract public (Z1)=>U.operator()(a1:Z1):U
        public java.lang.Object $apply(final java.lang.Object a1, final x10.rtt.Type t1) {
            return $apply(x10.core.Long.$unbox(a1));
            
        }
        
        private x10.rtt.Type $Queue;
        private x10.rtt.Type $R;
        
        // initializer of type parameters
        public static void $initParams(final $Closure$67 $this, final x10.rtt.Type $Queue, final x10.rtt.Type $R) {
            $this.$Queue = $Queue;
            $this.$R = $R;
            
        }
        // synthetic type for parameter mangling
        public static final class __0$1x10$glb$GLB$$Closure$67$$Queue$3x10$glb$GLB$$Closure$67$$R$2__1$1x10$glb$Worker$1x10$glb$GLB$$Closure$67$$Queue$3x10$glb$GLB$$Closure$67$$R$2$2 {}
        
    
        
        public x10.glb.Logger $apply(final long i) {
            
            //#line 151 "x10/glb/GLB.x10"
            final x10.lang.Place t$119333 = ((x10.lang.Place)(new x10.lang.Place((java.lang.System[]) null)));
            
            //#line 151 "x10/glb/GLB.x10"
            t$119333.x10$lang$Place$$init$S(((long)(i)));
            
            //#line 151 "x10/glb/GLB.x10"
            final x10.glb.Logger t$119334 = ((x10.glb.Logger)(x10.xrx.Runtime.<x10.glb.Logger> evalAt__1$1x10$xrx$Runtime$$T$2$G(x10.glb.Logger.$RTT, ((x10.lang.Place)(t$119333)), ((x10.core.fun.Fun_0_0)(new x10.glb.GLB.$Closure$66<$Queue, $R>($Queue, $R, ((x10.glb.GLB<$Queue, $R>)(this.out$$)), ((x10.lang.PlaceLocalHandle<x10.glb.Worker<$Queue, $R>>)(this.st)), (x10.glb.GLB.$Closure$66.__0$1x10$glb$GLB$$Closure$66$$Queue$3x10$glb$GLB$$Closure$66$$R$2__1$1x10$glb$Worker$1x10$glb$GLB$$Closure$66$$Queue$3x10$glb$GLB$$Closure$66$$R$2$2) null))), ((x10.xrx.Runtime.Profile)(null)))));
            
            //#line 151 "x10/glb/GLB.x10"
            return t$119334;
        }
        
        public x10.glb.GLB<$Queue, $R> out$$;
        public x10.lang.PlaceLocalHandle<x10.glb.Worker<$Queue, $R>> st;
        
        public $Closure$67(final x10.rtt.Type $Queue, final x10.rtt.Type $R, final x10.glb.GLB<$Queue, $R> out$$, final x10.lang.PlaceLocalHandle<x10.glb.Worker<$Queue, $R>> st, __0$1x10$glb$GLB$$Closure$67$$Queue$3x10$glb$GLB$$Closure$67$$R$2__1$1x10$glb$Worker$1x10$glb$GLB$$Closure$67$$Queue$3x10$glb$GLB$$Closure$67$$R$2$2 $dummy) {
            x10.glb.GLB.$Closure$67.$initParams(this, $Queue, $R);
             {
                ((x10.glb.GLB.$Closure$67<$Queue, $R>)this).out$$ = ((x10.glb.GLB)(out$$));
                ((x10.glb.GLB.$Closure$67<$Queue, $R>)this).st = ((x10.lang.PlaceLocalHandle)(st));
            }
        }
        
    }
    
    @x10.runtime.impl.java.X10Generated
    final public static class $Closure$68<$Queue, $R> extends x10.core.Ref implements x10.core.fun.VoidFun_0_0, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<$Closure$68> $RTT = 
            x10.rtt.StaticVoidFunType.<$Closure$68> make($Closure$68.class,
                                                         2,
                                                         new x10.rtt.Type[] {
                                                             x10.core.fun.VoidFun_0_0.$RTT
                                                         });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { if (i == 0) return $Queue; if (i == 1) return $R; return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static <$Queue, $R> x10.serialization.X10JavaSerializable $_deserialize_body(x10.glb.GLB.$Closure$68<$Queue, $R> $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            $_obj.$Queue = (x10.rtt.Type) $deserializer.readObject();
            $_obj.$R = (x10.rtt.Type) $deserializer.readObject();
            $_obj.resultGlobal = $deserializer.readObject();
            $_obj.tmpPlh = $deserializer.readObject();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.glb.GLB.$Closure$68 $_obj = new x10.glb.GLB.$Closure$68((java.lang.System[]) null, (x10.rtt.Type) null, (x10.rtt.Type) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            $serializer.write(this.$Queue);
            $serializer.write(this.$R);
            $serializer.write(this.resultGlobal);
            $serializer.write(this.tmpPlh);
            
        }
        
        // constructor just for allocation
        public $Closure$68(final java.lang.System[] $dummy, final x10.rtt.Type $Queue, final x10.rtt.Type $R) {
            x10.glb.GLB.$Closure$68.$initParams(this, $Queue, $R);
            
        }
        
        private x10.rtt.Type $Queue;
        private x10.rtt.Type $R;
        
        // initializer of type parameters
        public static void $initParams(final $Closure$68 $this, final x10.rtt.Type $Queue, final x10.rtt.Type $R) {
            $this.$Queue = $Queue;
            $this.$R = $R;
            
        }
        // synthetic type for parameter mangling
        public static final class __0$1x10$glb$GLBResult$1x10$glb$GLB$$Closure$68$$R$2$2__1$1x10$glb$Worker$1x10$glb$GLB$$Closure$68$$Queue$3x10$glb$GLB$$Closure$68$$R$2$2 {}
        
    
        
        public void $apply() {
            
            //#line 173 "x10/glb/GLB.x10"
            final x10.lang.Place t$127616 = ((x10.lang.Place)((this.resultGlobal).home));
            
            //#line 173 "x10/glb/GLB.x10"
            final boolean t$127639 = x10.rtt.Equality.equalsequals((x10.x10rt.X10RT.here()),(t$127616));
            
            //#line 173 "x10/glb/GLB.x10"
            if (t$127639) {
                
                //#line 174 "x10/glb/GLB.x10"
                final x10.core.GlobalRef t$119476 = ((x10.core.GlobalRef)x10.rtt.Types.asStruct(x10.rtt.ParameterizedType.make(x10.core.GlobalRef.$RTT, x10.rtt.ParameterizedType.make(x10.glb.GLBResult.$RTT, $R)),this.resultGlobal));
                
                //#line 174 "x10/glb/GLB.x10"
                final x10.lang.Place t$127617 = ((x10.lang.Place)((t$119476).home));
                
                //#line 174 "x10/glb/GLB.x10"
                final boolean t$127618 = x10.rtt.Equality.equalsequals((t$127617),(x10.x10rt.X10RT.here()));
                
                //#line 174 "x10/glb/GLB.x10"
                final boolean t$127620 = !(t$127618);
                
                //#line 174 "x10/glb/GLB.x10"
                if (t$127620) {
                    
                    //#line 174 "x10/glb/GLB.x10"
                    final x10.lang.FailedDynamicCheckException t$127619 = new x10.lang.FailedDynamicCheckException("x10.lang.GlobalRef[x10.glb.GLBResult[R]]{self.home==here}");
                    
                    //#line 174 "x10/glb/GLB.x10"
                    throw t$127619;
                }
                
                //#line 175 "x10/glb/GLB.x10"
                final x10.util.Team t$127626 = ((x10.util.Team)(x10.util.Team.get$WORLD()));
                
                //#line 175 "x10/glb/GLB.x10"
                final x10.glb.GLBResult t$127621 = (((x10.core.GlobalRef<x10.glb.GLBResult<$R>>)(t$119476))).$apply$G();
                
                //#line 175 "x10/glb/GLB.x10"
                final x10.core.Rail t$127627 = ((x10.core.Rail<$R>)
                                                 ((x10.glb.GLBResult<$R>)t$127621).submitResult());
                
                //#line 177 "x10/glb/GLB.x10"
                final x10.glb.GLBResult t$127622 = (((x10.core.GlobalRef<x10.glb.GLBResult<$R>>)(t$119476))).$apply$G();
                
                //#line 177 "x10/glb/GLB.x10"
                final x10.core.Rail t$127628 = ((x10.core.Rail<$R>)
                                                 ((x10.glb.GLBResult<$R>)t$127622).submitResult());
                
                //#line 179 "x10/glb/GLB.x10"
                final x10.glb.GLBResult t$127623 = (((x10.core.GlobalRef<x10.glb.GLBResult<$R>>)(t$119476))).$apply$G();
                
                //#line 179 "x10/glb/GLB.x10"
                final x10.core.Rail t$127624 = ((x10.core.Rail<$R>)
                                                 ((x10.glb.GLBResult<$R>)t$127623).submitResult());
                
                //#line 179 "x10/glb/GLB.x10"
                final long t$127629 = ((x10.core.Rail<$R>)t$127624).size;
                
                //#line 180 "x10/glb/GLB.x10"
                final x10.glb.GLBResult t$127625 = (((x10.core.GlobalRef<x10.glb.GLBResult<$R>>)(t$119476))).$apply$G();
                
                //#line 180 "x10/glb/GLB.x10"
                final int t$127630 = ((x10.glb.GLBResult<$R>)t$127625).getReduceOperator$O();
                
                //#line 175 "x10/glb/GLB.x10"
                ((x10.util.Team)t$127626).<$R> allreduce__0$1x10$util$Team$$T$2__2$1x10$util$Team$$T$2($R, ((x10.core.Rail)(t$127627)), (long)(0L), ((x10.core.Rail)(t$127628)), (long)(0L), (long)(t$127629), (int)(t$127630));
            } else {
                
                //#line 182 "x10/glb/GLB.x10"
                final x10.glb.Worker t$127631 = ((x10.lang.PlaceLocalHandle<x10.glb.Worker<$Queue, $R>>)this.tmpPlh).$apply$G();
                
                //#line 182 "x10/glb/GLB.x10"
                final $Queue t$127632 = (($Queue)(((x10.glb.Worker<$Queue, $R>)t$127631).queue));
                
                //#line 182 "x10/glb/GLB.x10"
                final x10.glb.GLBResult glbR = ((x10.glb.GLBResult<$R>)
                                                 ((x10.glb.TaskQueue<$Queue, $R>)x10.rtt.Types.conversion(x10.rtt.ParameterizedType.make(x10.glb.TaskQueue.$RTT, $Queue, $R),t$127632)).getResult());
                
                //#line 183 "x10/glb/GLB.x10"
                final x10.util.Team t$127634 = ((x10.util.Team)(x10.util.Team.get$WORLD()));
                
                //#line 183 "x10/glb/GLB.x10"
                final x10.core.Rail t$127635 = ((x10.core.Rail<$R>)
                                                 ((x10.glb.GLBResult<$R>)glbR).submitResult());
                
                //#line 185 "x10/glb/GLB.x10"
                final x10.core.Rail t$127636 = ((x10.core.Rail<$R>)
                                                 ((x10.glb.GLBResult<$R>)glbR).submitResult());
                
                //#line 187 "x10/glb/GLB.x10"
                final x10.core.Rail t$127633 = ((x10.core.Rail<$R>)
                                                 ((x10.glb.GLBResult<$R>)glbR).submitResult());
                
                //#line 187 "x10/glb/GLB.x10"
                final long t$127637 = ((x10.core.Rail<$R>)t$127633).size;
                
                //#line 188 "x10/glb/GLB.x10"
                final int t$127638 = ((x10.glb.GLBResult<$R>)glbR).getReduceOperator$O();
                
                //#line 183 "x10/glb/GLB.x10"
                ((x10.util.Team)t$127634).<$R> allreduce__0$1x10$util$Team$$T$2__2$1x10$util$Team$$T$2($R, ((x10.core.Rail)(t$127635)), (long)(0L), ((x10.core.Rail)(t$127636)), (long)(0L), (long)(t$127637), (int)(t$127638));
            }
        }
        
        public x10.core.GlobalRef<x10.glb.GLBResult<$R>> resultGlobal;
        public x10.lang.PlaceLocalHandle<x10.glb.Worker<$Queue, $R>> tmpPlh;
        
        public $Closure$68(final x10.rtt.Type $Queue, final x10.rtt.Type $R, final x10.core.GlobalRef<x10.glb.GLBResult<$R>> resultGlobal, final x10.lang.PlaceLocalHandle<x10.glb.Worker<$Queue, $R>> tmpPlh, __0$1x10$glb$GLBResult$1x10$glb$GLB$$Closure$68$$R$2$2__1$1x10$glb$Worker$1x10$glb$GLB$$Closure$68$$Queue$3x10$glb$GLB$$Closure$68$$R$2$2 $dummy) {
            x10.glb.GLB.$Closure$68.$initParams(this, $Queue, $R);
             {
                ((x10.glb.GLB.$Closure$68<$Queue, $R>)this).resultGlobal = ((x10.core.GlobalRef)(resultGlobal));
                ((x10.glb.GLB.$Closure$68<$Queue, $R>)this).tmpPlh = ((x10.lang.PlaceLocalHandle)(tmpPlh));
            }
        }
        
    }
    
    @x10.runtime.impl.java.X10Generated
    final public static class $Closure$69<$Queue, $R> extends x10.core.Ref implements x10.core.fun.VoidFun_0_0, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<$Closure$69> $RTT = 
            x10.rtt.StaticVoidFunType.<$Closure$69> make($Closure$69.class,
                                                         2,
                                                         new x10.rtt.Type[] {
                                                             x10.core.fun.VoidFun_0_0.$RTT
                                                         });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { if (i == 0) return $Queue; if (i == 1) return $R; return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static <$Queue, $R> x10.serialization.X10JavaSerializable $_deserialize_body(x10.glb.GLB.$Closure$69<$Queue, $R> $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            $_obj.$Queue = (x10.rtt.Type) $deserializer.readObject();
            $_obj.$R = (x10.rtt.Type) $deserializer.readObject();
            $_obj.st = $deserializer.readObject();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.glb.GLB.$Closure$69 $_obj = new x10.glb.GLB.$Closure$69((java.lang.System[]) null, (x10.rtt.Type) null, (x10.rtt.Type) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            $serializer.write(this.$Queue);
            $serializer.write(this.$R);
            $serializer.write(this.st);
            
        }
        
        // constructor just for allocation
        public $Closure$69(final java.lang.System[] $dummy, final x10.rtt.Type $Queue, final x10.rtt.Type $R) {
            x10.glb.GLB.$Closure$69.$initParams(this, $Queue, $R);
            
        }
        
        private x10.rtt.Type $Queue;
        private x10.rtt.Type $R;
        
        // initializer of type parameters
        public static void $initParams(final $Closure$69 $this, final x10.rtt.Type $Queue, final x10.rtt.Type $R) {
            $this.$Queue = $Queue;
            $this.$R = $R;
            
        }
        // synthetic type for parameter mangling
        public static final class __0$1x10$glb$Worker$1x10$glb$GLB$$Closure$69$$Queue$3x10$glb$GLB$$Closure$69$$R$2$2 {}
        
    
        
        public void $apply() {
            
            //#line 206 "x10/glb/GLB.x10"
            try {{
                
                //#line 207 "x10/glb/GLB.x10"
                final x10.glb.Worker t$127662 = ((x10.lang.PlaceLocalHandle<x10.glb.Worker<$Queue, $R>>)this.st).$apply$G();
                
                //#line 207 "x10/glb/GLB.x10"
                final $Queue t$127663 = (($Queue)(((x10.glb.Worker<$Queue, $R>)t$127662).queue));
                
                //#line 207 "x10/glb/GLB.x10"
                ((x10.glb.TaskQueue<$Queue, $R>)x10.rtt.Types.conversion(x10.rtt.ParameterizedType.make(x10.glb.TaskQueue.$RTT, $Queue, $R),t$127663)).printLog();
            }}catch (java.lang.Throwable __lowerer__var__0__) {
                
                //#line 206 "x10/glb/GLB.x10"
                int __lowerer__var__1__ = (x10.core.Int.$unbox(x10.xrx.Runtime.<x10.core.Int> wrapAtChecked$G(x10.rtt.Types.INT, ((java.lang.Throwable)(__lowerer__var__0__)))));
            }
        }
        
        public x10.lang.PlaceLocalHandle<x10.glb.Worker<$Queue, $R>> st;
        
        public $Closure$69(final x10.rtt.Type $Queue, final x10.rtt.Type $R, final x10.lang.PlaceLocalHandle<x10.glb.Worker<$Queue, $R>> st, __0$1x10$glb$Worker$1x10$glb$GLB$$Closure$69$$Queue$3x10$glb$GLB$$Closure$69$$R$2$2 $dummy) {
            x10.glb.GLB.$Closure$69.$initParams(this, $Queue, $R);
             {
                ((x10.glb.GLB.$Closure$69<$Queue, $R>)this).st = ((x10.lang.PlaceLocalHandle)(st));
            }
        }
        
    }
    
}

