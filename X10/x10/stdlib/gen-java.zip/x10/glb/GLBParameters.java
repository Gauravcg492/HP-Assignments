package x10.glb;

/**
 * A structure that captures the essence of lifeline graph structure
 */
@x10.runtime.impl.java.X10Generated
public class GLBParameters extends x10.core.Struct implements x10.serialization.X10JavaSerializable
{
    public static final x10.rtt.RuntimeType<GLBParameters> $RTT = 
        x10.rtt.NamedStructType.<GLBParameters> make("x10.glb.GLBParameters",
                                                     GLBParameters.class,
                                                     new x10.rtt.Type[] {
                                                         x10.rtt.Types.STRUCT
                                                     });
    
    public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
    
    public x10.rtt.Type<?> $getParam(int i) { return null; }
    
    private Object writeReplace() throws java.io.ObjectStreamException {
        return new x10.serialization.SerializationProxy(this);
    }
    
    public static x10.serialization.X10JavaSerializable $_deserialize_body(x10.glb.GLBParameters $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
        $_obj.l = $deserializer.readInt();
        $_obj.m = $deserializer.readInt();
        $_obj.n = $deserializer.readInt();
        $_obj.v = $deserializer.readInt();
        $_obj.w = $deserializer.readInt();
        $_obj.z = $deserializer.readInt();
        return $_obj;
    }
    
    public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
        x10.glb.GLBParameters $_obj = new x10.glb.GLBParameters((java.lang.System[]) null);
        return $_deserialize_body($_obj, $deserializer);
    }
    
    public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
        $serializer.write(this.l);
        $serializer.write(this.m);
        $serializer.write(this.n);
        $serializer.write(this.v);
        $serializer.write(this.w);
        $serializer.write(this.z);
        
    }
    
    // zero value constructor
    public GLBParameters(final java.lang.System $dummy) { this.n = 0; this.w = 0; this.l = 0; this.z = 0; this.m = 0; this.v = 0; }
    
    // constructor just for allocation
    public GLBParameters(final java.lang.System[] $dummy) {
        
    }
    
    
    // properties
    
    //#line 17 "x10/glb/GLBParameters.x10"
    public int n;
    
    //#line 18 "x10/glb/GLBParameters.x10"
    public int w;
    
    //#line 19 "x10/glb/GLBParameters.x10"
    public int l;
    
    //#line 20 "x10/glb/GLBParameters.x10"
    public int z;
    
    //#line 21 "x10/glb/GLBParameters.x10"
    public int m;
    
    //#line 22 "x10/glb/GLBParameters.x10"
    public int v;
    

    
    
    //#line 30 "x10/glb/GLBParameters.x10"
    /**
     * Calculate power of lineline given the base and the total number of places
     * @param p total number of places in the system
     * @param l base of lifeline
     * @return power of lifeline
     */
    final public static int computeZ$O(final long p, final int l) {
        
        //#line 31 "x10/glb/GLBParameters.x10"
        int z0 = 1;
        
        //#line 32 "x10/glb/GLBParameters.x10"
        int zz = l;
        
        //#line 33 "x10/glb/GLBParameters.x10"
        while (true) {
            
            //#line 33 "x10/glb/GLBParameters.x10"
            final long t$128069 = ((long)(((int)(zz))));
            
            //#line 33 "x10/glb/GLBParameters.x10"
            final boolean t$128074 = ((t$128069) < (((long)(p))));
            
            //#line 33 "x10/glb/GLBParameters.x10"
            if (!(t$128074)) {
                
                //#line 33 "x10/glb/GLBParameters.x10"
                break;
            }
            
            //#line 34 "x10/glb/GLBParameters.x10"
            final int t$128186 = ((z0) + (((int)(1))));
            
            //#line 34 "x10/glb/GLBParameters.x10"
            z0 = t$128186;
            
            //#line 35 "x10/glb/GLBParameters.x10"
            final int t$128188 = ((zz) * (((int)(l))));
            
            //#line 35 "x10/glb/GLBParameters.x10"
            zz = t$128188;
        }
        
        //#line 37 "x10/glb/GLBParameters.x10"
        return z0;
    }
    
    
    //#line 42 "x10/glb/GLBParameters.x10"
    private static x10.glb.GLBParameters Default;
    
    //#line 47 "x10/glb/GLBParameters.x10"
    /**
     * Show computation result.
     */
    final public static int SHOW_RESULT_FLAG = 1;
    
    //#line 51 "x10/glb/GLBParameters.x10"
    /**
     * Show work initialization, computation, result collection 
     */
    final public static int SHOW_TIMING_FLAG = 2;
    
    //#line 57 "x10/glb/GLBParameters.x10"
    /**
     * Show logs produced by each task frame, i.e., each
     * task frame's computation time, yield time etc
     */
    final public static int SHOW_TASKFRAME_LOG_FLAG = 4;
    
    //#line 62 "x10/glb/GLBParameters.x10"
    /**
     * Show GLB statistics 
     */
    final public static int SHOW_GLB_FLAG = 8;
    
    
    //#line 23 "x10/glb/GLBParameters.x10"
    final public java.lang.String typeName() {
        try {
            return x10.rtt.Types.typeName(this);
        }
        catch (java.lang.Throwable exc$206304) {
            throw x10.runtime.impl.java.ThrowableUtils.ensureX10Exception(exc$206304);
        }
        
    }
    
    
    
    //#line 23 "x10/glb/GLBParameters.x10"
    final public java.lang.String toString() {
        
        //#line 23 "x10/glb/GLBParameters.x10"
        final java.lang.String t$128076 = "struct x10.glb.GLBParameters: n=";
        
        //#line 23 "x10/glb/GLBParameters.x10"
        final int t$128077 = this.n;
        
        //#line 23 "x10/glb/GLBParameters.x10"
        final java.lang.String t$128078 = ((t$128076) + ((x10.core.Int.$box(t$128077))));
        
        //#line 23 "x10/glb/GLBParameters.x10"
        final java.lang.String t$128079 = ((t$128078) + (" w="));
        
        //#line 23 "x10/glb/GLBParameters.x10"
        final int t$128080 = this.w;
        
        //#line 23 "x10/glb/GLBParameters.x10"
        final java.lang.String t$128081 = ((t$128079) + ((x10.core.Int.$box(t$128080))));
        
        //#line 23 "x10/glb/GLBParameters.x10"
        final java.lang.String t$128082 = ((t$128081) + (" l="));
        
        //#line 23 "x10/glb/GLBParameters.x10"
        final int t$128083 = this.l;
        
        //#line 23 "x10/glb/GLBParameters.x10"
        final java.lang.String t$128084 = ((t$128082) + ((x10.core.Int.$box(t$128083))));
        
        //#line 23 "x10/glb/GLBParameters.x10"
        final java.lang.String t$128085 = ((t$128084) + (" z="));
        
        //#line 23 "x10/glb/GLBParameters.x10"
        final int t$128086 = this.z;
        
        //#line 23 "x10/glb/GLBParameters.x10"
        final java.lang.String t$128087 = ((t$128085) + ((x10.core.Int.$box(t$128086))));
        
        //#line 23 "x10/glb/GLBParameters.x10"
        final java.lang.String t$128088 = ((t$128087) + (" m="));
        
        //#line 23 "x10/glb/GLBParameters.x10"
        final int t$128089 = this.m;
        
        //#line 23 "x10/glb/GLBParameters.x10"
        final java.lang.String t$128090 = ((t$128088) + ((x10.core.Int.$box(t$128089))));
        
        //#line 23 "x10/glb/GLBParameters.x10"
        final java.lang.String t$128091 = ((t$128090) + (" v="));
        
        //#line 23 "x10/glb/GLBParameters.x10"
        final int t$128092 = this.v;
        
        //#line 23 "x10/glb/GLBParameters.x10"
        final java.lang.String t$128093 = ((t$128091) + ((x10.core.Int.$box(t$128092))));
        
        //#line 23 "x10/glb/GLBParameters.x10"
        return t$128093;
    }
    
    
    //#line 23 "x10/glb/GLBParameters.x10"
    final public int hashCode() {
        
        //#line 23 "x10/glb/GLBParameters.x10"
        int result = 1;
        
        //#line 23 "x10/glb/GLBParameters.x10"
        final int t$128096 = ((8191) * (((int)(result))));
        
        //#line 23 "x10/glb/GLBParameters.x10"
        final int t$128095 = this.n;
        
        //#line 23 "x10/glb/GLBParameters.x10"
        final int t$128097 = x10.rtt.Types.hashCode(t$128095);
        
        //#line 23 "x10/glb/GLBParameters.x10"
        final int t$128098 = ((t$128096) + (((int)(t$128097))));
        
        //#line 23 "x10/glb/GLBParameters.x10"
        result = t$128098;
        
        //#line 23 "x10/glb/GLBParameters.x10"
        final int t$128101 = ((8191) * (((int)(result))));
        
        //#line 23 "x10/glb/GLBParameters.x10"
        final int t$128100 = this.w;
        
        //#line 23 "x10/glb/GLBParameters.x10"
        final int t$128102 = x10.rtt.Types.hashCode(t$128100);
        
        //#line 23 "x10/glb/GLBParameters.x10"
        final int t$128103 = ((t$128101) + (((int)(t$128102))));
        
        //#line 23 "x10/glb/GLBParameters.x10"
        result = t$128103;
        
        //#line 23 "x10/glb/GLBParameters.x10"
        final int t$128106 = ((8191) * (((int)(result))));
        
        //#line 23 "x10/glb/GLBParameters.x10"
        final int t$128105 = this.l;
        
        //#line 23 "x10/glb/GLBParameters.x10"
        final int t$128107 = x10.rtt.Types.hashCode(t$128105);
        
        //#line 23 "x10/glb/GLBParameters.x10"
        final int t$128108 = ((t$128106) + (((int)(t$128107))));
        
        //#line 23 "x10/glb/GLBParameters.x10"
        result = t$128108;
        
        //#line 23 "x10/glb/GLBParameters.x10"
        final int t$128111 = ((8191) * (((int)(result))));
        
        //#line 23 "x10/glb/GLBParameters.x10"
        final int t$128110 = this.z;
        
        //#line 23 "x10/glb/GLBParameters.x10"
        final int t$128112 = x10.rtt.Types.hashCode(t$128110);
        
        //#line 23 "x10/glb/GLBParameters.x10"
        final int t$128113 = ((t$128111) + (((int)(t$128112))));
        
        //#line 23 "x10/glb/GLBParameters.x10"
        result = t$128113;
        
        //#line 23 "x10/glb/GLBParameters.x10"
        final int t$128116 = ((8191) * (((int)(result))));
        
        //#line 23 "x10/glb/GLBParameters.x10"
        final int t$128115 = this.m;
        
        //#line 23 "x10/glb/GLBParameters.x10"
        final int t$128117 = x10.rtt.Types.hashCode(t$128115);
        
        //#line 23 "x10/glb/GLBParameters.x10"
        final int t$128118 = ((t$128116) + (((int)(t$128117))));
        
        //#line 23 "x10/glb/GLBParameters.x10"
        result = t$128118;
        
        //#line 23 "x10/glb/GLBParameters.x10"
        final int t$128121 = ((8191) * (((int)(result))));
        
        //#line 23 "x10/glb/GLBParameters.x10"
        final int t$128120 = this.v;
        
        //#line 23 "x10/glb/GLBParameters.x10"
        final int t$128122 = x10.rtt.Types.hashCode(t$128120);
        
        //#line 23 "x10/glb/GLBParameters.x10"
        final int t$128123 = ((t$128121) + (((int)(t$128122))));
        
        //#line 23 "x10/glb/GLBParameters.x10"
        result = t$128123;
        
        //#line 23 "x10/glb/GLBParameters.x10"
        return result;
    }
    
    
    //#line 23 "x10/glb/GLBParameters.x10"
    final public boolean equals(java.lang.Object other) {
        
        //#line 23 "x10/glb/GLBParameters.x10"
        final boolean t$128126 = x10.glb.GLBParameters.$RTT.isInstance(other);
        
        //#line 23 "x10/glb/GLBParameters.x10"
        final boolean t$128127 = !(t$128126);
        
        //#line 23 "x10/glb/GLBParameters.x10"
        if (t$128127) {
            
            //#line 23 "x10/glb/GLBParameters.x10"
            return false;
        }
        
        //#line 23 "x10/glb/GLBParameters.x10"
        final x10.glb.GLBParameters t$128129 = ((x10.glb.GLBParameters)x10.rtt.Types.asStruct(x10.glb.GLBParameters.$RTT,other));
        
        //#line 23 "x10/glb/GLBParameters.x10"
        final boolean t$128130 = this.equals$O(((x10.glb.GLBParameters)(t$128129)));
        
        //#line 23 "x10/glb/GLBParameters.x10"
        return t$128130;
    }
    
    
    //#line 23 "x10/glb/GLBParameters.x10"
    final public boolean equals$O(x10.glb.GLBParameters other) {
        
        //#line 23 "x10/glb/GLBParameters.x10"
        final int t$128132 = this.n;
        
        //#line 23 "x10/glb/GLBParameters.x10"
        final int t$128133 = other.n;
        
        //#line 23 "x10/glb/GLBParameters.x10"
        boolean t$128137 = ((int) t$128132) == ((int) t$128133);
        
        //#line 23 "x10/glb/GLBParameters.x10"
        if (t$128137) {
            
            //#line 23 "x10/glb/GLBParameters.x10"
            final int t$128135 = this.w;
            
            //#line 23 "x10/glb/GLBParameters.x10"
            final int t$128136 = other.w;
            
            //#line 23 "x10/glb/GLBParameters.x10"
            t$128137 = ((int) t$128135) == ((int) t$128136);
        }
        
        //#line 23 "x10/glb/GLBParameters.x10"
        boolean t$128141 = t$128137;
        
        //#line 23 "x10/glb/GLBParameters.x10"
        if (t$128137) {
            
            //#line 23 "x10/glb/GLBParameters.x10"
            final int t$128139 = this.l;
            
            //#line 23 "x10/glb/GLBParameters.x10"
            final int t$128140 = other.l;
            
            //#line 23 "x10/glb/GLBParameters.x10"
            t$128141 = ((int) t$128139) == ((int) t$128140);
        }
        
        //#line 23 "x10/glb/GLBParameters.x10"
        boolean t$128145 = t$128141;
        
        //#line 23 "x10/glb/GLBParameters.x10"
        if (t$128141) {
            
            //#line 23 "x10/glb/GLBParameters.x10"
            final int t$128143 = this.z;
            
            //#line 23 "x10/glb/GLBParameters.x10"
            final int t$128144 = other.z;
            
            //#line 23 "x10/glb/GLBParameters.x10"
            t$128145 = ((int) t$128143) == ((int) t$128144);
        }
        
        //#line 23 "x10/glb/GLBParameters.x10"
        boolean t$128149 = t$128145;
        
        //#line 23 "x10/glb/GLBParameters.x10"
        if (t$128145) {
            
            //#line 23 "x10/glb/GLBParameters.x10"
            final int t$128147 = this.m;
            
            //#line 23 "x10/glb/GLBParameters.x10"
            final int t$128148 = other.m;
            
            //#line 23 "x10/glb/GLBParameters.x10"
            t$128149 = ((int) t$128147) == ((int) t$128148);
        }
        
        //#line 23 "x10/glb/GLBParameters.x10"
        boolean t$128153 = t$128149;
        
        //#line 23 "x10/glb/GLBParameters.x10"
        if (t$128149) {
            
            //#line 23 "x10/glb/GLBParameters.x10"
            final int t$128151 = this.v;
            
            //#line 23 "x10/glb/GLBParameters.x10"
            final int t$128152 = other.v;
            
            //#line 23 "x10/glb/GLBParameters.x10"
            t$128153 = ((int) t$128151) == ((int) t$128152);
        }
        
        //#line 23 "x10/glb/GLBParameters.x10"
        return t$128153;
    }
    
    
    //#line 23 "x10/glb/GLBParameters.x10"
    final public boolean _struct_equals$O(java.lang.Object other) {
        
        //#line 23 "x10/glb/GLBParameters.x10"
        final boolean t$128156 = x10.glb.GLBParameters.$RTT.isInstance(other);
        
        //#line 23 "x10/glb/GLBParameters.x10"
        final boolean t$128157 = !(t$128156);
        
        //#line 23 "x10/glb/GLBParameters.x10"
        if (t$128157) {
            
            //#line 23 "x10/glb/GLBParameters.x10"
            return false;
        }
        
        //#line 23 "x10/glb/GLBParameters.x10"
        final x10.glb.GLBParameters t$128159 = ((x10.glb.GLBParameters)x10.rtt.Types.asStruct(x10.glb.GLBParameters.$RTT,other));
        
        //#line 23 "x10/glb/GLBParameters.x10"
        final boolean t$128160 = this._struct_equals$O(((x10.glb.GLBParameters)(t$128159)));
        
        //#line 23 "x10/glb/GLBParameters.x10"
        return t$128160;
    }
    
    
    //#line 23 "x10/glb/GLBParameters.x10"
    final public boolean _struct_equals$O(x10.glb.GLBParameters other) {
        
        //#line 23 "x10/glb/GLBParameters.x10"
        final int t$128162 = this.n;
        
        //#line 23 "x10/glb/GLBParameters.x10"
        final int t$128163 = other.n;
        
        //#line 23 "x10/glb/GLBParameters.x10"
        boolean t$128167 = ((int) t$128162) == ((int) t$128163);
        
        //#line 23 "x10/glb/GLBParameters.x10"
        if (t$128167) {
            
            //#line 23 "x10/glb/GLBParameters.x10"
            final int t$128165 = this.w;
            
            //#line 23 "x10/glb/GLBParameters.x10"
            final int t$128166 = other.w;
            
            //#line 23 "x10/glb/GLBParameters.x10"
            t$128167 = ((int) t$128165) == ((int) t$128166);
        }
        
        //#line 23 "x10/glb/GLBParameters.x10"
        boolean t$128171 = t$128167;
        
        //#line 23 "x10/glb/GLBParameters.x10"
        if (t$128167) {
            
            //#line 23 "x10/glb/GLBParameters.x10"
            final int t$128169 = this.l;
            
            //#line 23 "x10/glb/GLBParameters.x10"
            final int t$128170 = other.l;
            
            //#line 23 "x10/glb/GLBParameters.x10"
            t$128171 = ((int) t$128169) == ((int) t$128170);
        }
        
        //#line 23 "x10/glb/GLBParameters.x10"
        boolean t$128175 = t$128171;
        
        //#line 23 "x10/glb/GLBParameters.x10"
        if (t$128171) {
            
            //#line 23 "x10/glb/GLBParameters.x10"
            final int t$128173 = this.z;
            
            //#line 23 "x10/glb/GLBParameters.x10"
            final int t$128174 = other.z;
            
            //#line 23 "x10/glb/GLBParameters.x10"
            t$128175 = ((int) t$128173) == ((int) t$128174);
        }
        
        //#line 23 "x10/glb/GLBParameters.x10"
        boolean t$128179 = t$128175;
        
        //#line 23 "x10/glb/GLBParameters.x10"
        if (t$128175) {
            
            //#line 23 "x10/glb/GLBParameters.x10"
            final int t$128177 = this.m;
            
            //#line 23 "x10/glb/GLBParameters.x10"
            final int t$128178 = other.m;
            
            //#line 23 "x10/glb/GLBParameters.x10"
            t$128179 = ((int) t$128177) == ((int) t$128178);
        }
        
        //#line 23 "x10/glb/GLBParameters.x10"
        boolean t$128183 = t$128179;
        
        //#line 23 "x10/glb/GLBParameters.x10"
        if (t$128179) {
            
            //#line 23 "x10/glb/GLBParameters.x10"
            final int t$128181 = this.v;
            
            //#line 23 "x10/glb/GLBParameters.x10"
            final int t$128182 = other.v;
            
            //#line 23 "x10/glb/GLBParameters.x10"
            t$128183 = ((int) t$128181) == ((int) t$128182);
        }
        
        //#line 23 "x10/glb/GLBParameters.x10"
        return t$128183;
    }
    
    
    //#line 16 "x10/glb/GLBParameters.x10"
    final public x10.glb.GLBParameters x10$glb$GLBParameters$$this$x10$glb$GLBParameters() {
        
        //#line 16 "x10/glb/GLBParameters.x10"
        return x10.glb.GLBParameters.this;
    }
    
    
    //#line 23 "x10/glb/GLBParameters.x10"
    // creation method for java code (1-phase java constructor)
    public GLBParameters(final int n, final int w, final int l, final int z, final int m, final int v) {
        this((java.lang.System[]) null);
        x10$glb$GLBParameters$$init$S(n, w, l, z, m, v);
    }
    
    // constructor for non-virtual call
    final public x10.glb.GLBParameters x10$glb$GLBParameters$$init$S(final int n, final int w, final int l, final int z, final int m, final int v) {
         {
            
            //#line 23 "x10/glb/GLBParameters.x10"
            this.n = n;
            this.w = w;
            this.l = l;
            this.z = z;
            this.m = m;
            this.v = v;
            
        }
        return this;
    }
    
    
    
    //#line 16 "x10/glb/GLBParameters.x10"
    final public void __fieldInitializers_x10_glb_GLBParameters() {
        
    }
    
    final private static x10.core.concurrent.AtomicInteger initStatus$Default = new x10.core.concurrent.AtomicInteger(x10.runtime.impl.java.InitDispatcher.UNINITIALIZED);
    private static x10.lang.ExceptionInInitializer exception$Default;
    
    public static x10.glb.GLBParameters get$Default() {
        if (((int) x10.glb.GLBParameters.initStatus$Default.get()) == ((int) x10.runtime.impl.java.InitDispatcher.INITIALIZED)) {
            return x10.glb.GLBParameters.Default;
        }
        if (((int) x10.glb.GLBParameters.initStatus$Default.get()) == ((int) x10.runtime.impl.java.InitDispatcher.EXCEPTION_RAISED)) {
            throw x10.glb.GLBParameters.exception$Default;
        }
        if (x10.glb.GLBParameters.initStatus$Default.compareAndSet((int)(x10.runtime.impl.java.InitDispatcher.UNINITIALIZED), (int)(x10.runtime.impl.java.InitDispatcher.INITIALIZING))) {
            try {{
                x10.glb.GLBParameters.Default = ((x10.glb.GLBParameters)(new x10.glb.GLBParameters((java.lang.System[]) null).x10$glb$GLBParameters$$init$S(((int)(100)), ((int)(4)), ((int)(4)), x10.glb.GLBParameters.computeZ$O((long)(((long)x10.x10rt.X10RT.numPlaces())), (int)(4)), ((int)(1024)), ((int)(15)))));
            }}catch (java.lang.Throwable exc$128189) {
                x10.glb.GLBParameters.exception$Default = new x10.lang.ExceptionInInitializer(exc$128189);
                x10.glb.GLBParameters.initStatus$Default.set((int)(x10.runtime.impl.java.InitDispatcher.EXCEPTION_RAISED));
                x10.runtime.impl.java.InitDispatcher.lockInitialized();
                x10.runtime.impl.java.InitDispatcher.notifyInitialized();
                throw x10.glb.GLBParameters.exception$Default;
            }
            x10.glb.GLBParameters.initStatus$Default.set((int)(x10.runtime.impl.java.InitDispatcher.INITIALIZED));
            x10.runtime.impl.java.InitDispatcher.lockInitialized();
            x10.runtime.impl.java.InitDispatcher.notifyInitialized();
        } else {
            if (x10.glb.GLBParameters.initStatus$Default.get() < x10.runtime.impl.java.InitDispatcher.INITIALIZED) {
                x10.runtime.impl.java.InitDispatcher.lockInitialized();
                while (x10.glb.GLBParameters.initStatus$Default.get() < x10.runtime.impl.java.InitDispatcher.INITIALIZED) {
                    x10.runtime.impl.java.InitDispatcher.awaitInitialized();
                }
                x10.runtime.impl.java.InitDispatcher.unlockInitialized();
                if (((int) x10.glb.GLBParameters.initStatus$Default.get()) == ((int) x10.runtime.impl.java.InitDispatcher.EXCEPTION_RAISED)) {
                    throw x10.glb.GLBParameters.exception$Default;
                }
            }
        }
        return x10.glb.GLBParameters.Default;
    }
    
    public static int get$SHOW_RESULT_FLAG() {
        return x10.glb.GLBParameters.SHOW_RESULT_FLAG;
    }
    
    public static int get$SHOW_TIMING_FLAG() {
        return x10.glb.GLBParameters.SHOW_TIMING_FLAG;
    }
    
    public static int get$SHOW_TASKFRAME_LOG_FLAG() {
        return x10.glb.GLBParameters.SHOW_TASKFRAME_LOG_FLAG;
    }
    
    public static int get$SHOW_GLB_FLAG() {
        return x10.glb.GLBParameters.SHOW_GLB_FLAG;
    }
}

