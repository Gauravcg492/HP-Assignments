package x10.glb;


/**
 * <p> Context object that can be passed to user code. User code can interact with GLB library via an Context object.
 * For now, the only provided method is yield() method. User can stop processing and probe the network during computation,
 * if necessary, by calling yield() 
 * </p>
 */
@x10.runtime.impl.java.X10Generated
public class Context<$Queue, $R> extends x10.core.Ref implements x10.glb.ContextI, x10.serialization.X10JavaSerializable
{
    public static final x10.rtt.RuntimeType<Context> $RTT = 
        x10.rtt.NamedType.<Context> make("x10.glb.Context",
                                         Context.class,
                                         2,
                                         new x10.rtt.Type[] {
                                             x10.glb.ContextI.$RTT
                                         });
    
    public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
    
    public x10.rtt.Type<?> $getParam(int i) { if (i == 0) return $Queue; if (i == 1) return $R; return null; }
    
    private Object writeReplace() throws java.io.ObjectStreamException {
        return new x10.serialization.SerializationProxy(this);
    }
    
    public static <$Queue, $R> x10.serialization.X10JavaSerializable $_deserialize_body(x10.glb.Context<$Queue, $R> $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
        $_obj.$Queue = (x10.rtt.Type) $deserializer.readObject();
        $_obj.$R = (x10.rtt.Type) $deserializer.readObject();
        $_obj.st = $deserializer.readObject();
        return $_obj;
    }
    
    public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
        x10.glb.Context $_obj = new x10.glb.Context((java.lang.System[]) null, (x10.rtt.Type) null, (x10.rtt.Type) null);
        $deserializer.record_reference($_obj);
        return $_deserialize_body($_obj, $deserializer);
    }
    
    public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
        $serializer.write(this.$Queue);
        $serializer.write(this.$R);
        $serializer.write(this.st);
        
    }
    
    // constructor just for allocation
    public Context(final java.lang.System[] $dummy, final x10.rtt.Type $Queue, final x10.rtt.Type $R) {
        x10.glb.Context.$initParams(this, $Queue, $R);
        
    }
    
    private x10.rtt.Type $Queue;
    private x10.rtt.Type $R;
    
    // initializer of type parameters
    public static void $initParams(final Context $this, final x10.rtt.Type $Queue, final x10.rtt.Type $R) {
        $this.$Queue = $Queue;
        $this.$R = $R;
        
    }
    // synthetic type for parameter mangling
    public static final class __0$1x10$glb$Worker$1x10$glb$Context$$Queue$3x10$glb$Context$$R$2$2 {}
    

    
    //#line 25 "x10/glb/Context.x10"
    /**
     * PlaceLocalHandle of {@link Worker}
     */
    public x10.lang.PlaceLocalHandle<x10.glb.Worker<$Queue, $R>> st;
    
    
    //#line 30 "x10/glb/Context.x10"
    /**
     * @param st PlaceLocalHandle 
     */
    // creation method for java code (1-phase java constructor)
    public Context(final x10.rtt.Type $Queue, final x10.rtt.Type $R, final x10.lang.PlaceLocalHandle<x10.glb.Worker<$Queue, $R>> st, __0$1x10$glb$Worker$1x10$glb$Context$$Queue$3x10$glb$Context$$R$2$2 $dummy) {
        this((java.lang.System[]) null, $Queue, $R);
        x10$glb$Context$$init$S(st, (x10.glb.Context.__0$1x10$glb$Worker$1x10$glb$Context$$Queue$3x10$glb$Context$$R$2$2) null);
    }
    
    // constructor for non-virtual call
    final public x10.glb.Context<$Queue, $R> x10$glb$Context$$init$S(final x10.lang.PlaceLocalHandle<x10.glb.Worker<$Queue, $R>> st, __0$1x10$glb$Worker$1x10$glb$Context$$Queue$3x10$glb$Context$$R$2$2 $dummy) {
         {
            
            //#line 30 "x10/glb/Context.x10"
            
            
            //#line 20 "x10/glb/Context.x10"
            final x10.glb.Context this$119200 = this;
            
            //#line 25 . "x10/glb/Context.x10"
            final x10.lang.PlaceLocalHandle t$119199 = (x10.lang.PlaceLocalHandle<x10.glb.Worker<$Queue, $R>>) x10.rtt.Types.zeroValue(x10.rtt.ParameterizedType.make(x10.lang.PlaceLocalHandle.$RTT, x10.rtt.ParameterizedType.make(x10.glb.Worker.$RTT, $Queue, $R)));
            
            //#line 20 "x10/glb/Context.x10"
            ((x10.glb.Context<$Queue, $R>)this$119200).st = t$119199;
            
            //#line 31 "x10/glb/Context.x10"
            ((x10.glb.Context<$Queue, $R>)this).st = ((x10.lang.PlaceLocalHandle)(st));
        }
        return this;
    }
    
    
    
    //#line 37 "x10/glb/Context.x10"
    /**
     * Used by the user code, yield back to GLB scheduler.
     */
    public void yield() {
        
        //#line 38 "x10/glb/Context.x10"
        final x10.lang.PlaceLocalHandle t$119144 = ((x10.lang.PlaceLocalHandle)(this.st));
        
        //#line 38 "x10/glb/Context.x10"
        final x10.glb.Worker this$119082 = ((x10.lang.PlaceLocalHandle<x10.glb.Worker<$Queue, $R>>)t$119144).$apply$G();
        
        //#line 452 . "x10/glb/Worker.x10"
        final x10.core.fun.VoidFun_0_1 t$119196 = ((x10.core.fun.VoidFun_0_1)(new x10.glb.Context.$Closure$60<$Queue, $R>($Queue, $R, this$119082, (x10.glb.Context.$Closure$60.__0$1x10$glb$Context$$Closure$60$$Queue$3x10$glb$Context$$Closure$60$$R$2) null)));
        
        //#line 38 "x10/glb/Context.x10"
        final x10.lang.PlaceLocalHandle t$119197 = ((x10.lang.PlaceLocalHandle)(this.st));
        
        //#line 38 "x10/glb/Context.x10"
        ((x10.core.fun.VoidFun_0_1<x10.lang.PlaceLocalHandle<x10.glb.Worker<$Queue, $R>>>)t$119196).$apply(t$119197, x10.rtt.ParameterizedType.make(x10.lang.PlaceLocalHandle.$RTT, x10.rtt.ParameterizedType.make(x10.glb.Worker.$RTT, $Queue, $R)));
    }
    
    
    //#line 47 "x10/glb/Context.x10"
    /**
     * Implements the ConTextI interface, for potentially simplified usage of yield by the user code,
     * i.e., user doesn't have to provide type of {@link TaskQueue} and type of computation result. 
     * However, this programming style is not adopted in this version of GLB because we might need to 
     * expose TaskQueue, R type for the future usage.
     */
    public void yielding() {
        
        //#line 48 "x10/glb/Context.x10"
        this.yield();
    }
    
    
    //#line 20 "x10/glb/Context.x10"
    final public x10.glb.Context x10$glb$Context$$this$x10$glb$Context() {
        
        //#line 20 "x10/glb/Context.x10"
        return x10.glb.Context.this;
    }
    
    
    //#line 20 "x10/glb/Context.x10"
    final public void __fieldInitializers_x10_glb_Context() {
        
        //#line 25 "x10/glb/Context.x10"
        final x10.lang.PlaceLocalHandle t$119198 = (x10.lang.PlaceLocalHandle<x10.glb.Worker<$Queue, $R>>) x10.rtt.Types.zeroValue(x10.rtt.ParameterizedType.make(x10.lang.PlaceLocalHandle.$RTT, x10.rtt.ParameterizedType.make(x10.glb.Worker.$RTT, $Queue, $R)));
        
        //#line 20 "x10/glb/Context.x10"
        ((x10.glb.Context<$Queue, $R>)this).st = t$119198;
    }
    
    @x10.runtime.impl.java.X10Generated
    final public static class $Closure$55<$Queue, $R> extends x10.core.Ref implements x10.core.fun.VoidFun_0_0, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<$Closure$55> $RTT = 
            x10.rtt.StaticVoidFunType.<$Closure$55> make($Closure$55.class,
                                                         2,
                                                         new x10.rtt.Type[] {
                                                             x10.core.fun.VoidFun_0_0.$RTT
                                                         });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { if (i == 0) return $Queue; if (i == 1) return $R; return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static <$Queue, $R> x10.serialization.X10JavaSerializable $_deserialize_body(x10.glb.Context.$Closure$55<$Queue, $R> $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            $_obj.$Queue = (x10.rtt.Type) $deserializer.readObject();
            $_obj.$R = (x10.rtt.Type) $deserializer.readObject();
            $_obj.loot$119242 = $deserializer.readObject();
            $_obj.st$119241 = $deserializer.readObject();
            $_obj.victim$119203 = $deserializer.readLong();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.glb.Context.$Closure$55 $_obj = new x10.glb.Context.$Closure$55((java.lang.System[]) null, (x10.rtt.Type) null, (x10.rtt.Type) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            $serializer.write(this.$Queue);
            $serializer.write(this.$R);
            $serializer.write(this.loot$119242);
            $serializer.write(this.st$119241);
            $serializer.write(this.victim$119203);
            
        }
        
        // constructor just for allocation
        public $Closure$55(final java.lang.System[] $dummy, final x10.rtt.Type $Queue, final x10.rtt.Type $R) {
            x10.glb.Context.$Closure$55.$initParams(this, $Queue, $R);
            
        }
        
        private x10.rtt.Type $Queue;
        private x10.rtt.Type $R;
        
        // initializer of type parameters
        public static void $initParams(final $Closure$55 $this, final x10.rtt.Type $Queue, final x10.rtt.Type $R) {
            $this.$Queue = $Queue;
            $this.$R = $R;
            
        }
        // synthetic type for parameter mangling
        public static final class __0$1x10$glb$Worker$1x10$glb$Context$$Closure$55$$Queue$3x10$glb$Context$$Closure$55$$R$2$2 {}
        
    
        
        public void $apply() {
            
            //#line 168 ... "x10/glb/Worker.x10"
            final x10.glb.Worker t$119222 = ((x10.lang.PlaceLocalHandle<x10.glb.Worker<$Queue, $R>>)this.st$119241).$apply$G();
            
            //#line 168 ... "x10/glb/Worker.x10"
            ((x10.glb.Worker<$Queue, $R>)t$119222).deal__0$1x10$glb$Worker$1x10$glb$Worker$$Queue$3x10$glb$Worker$$R$2$2(((x10.lang.PlaceLocalHandle)(this.st$119241)), ((x10.glb.TaskBag)(this.loot$119242)), (long)(this.victim$119203));
            
            //#line 168 ... "x10/glb/Worker.x10"
            final x10.glb.Worker t$119223 = ((x10.lang.PlaceLocalHandle<x10.glb.Worker<$Queue, $R>>)this.st$119241).$apply$G();
            
            //#line 168 ... "x10/glb/Worker.x10"
            ((x10.glb.Worker<$Queue, $R>)t$119223).waiting = false;
        }
        
        public x10.lang.PlaceLocalHandle<x10.glb.Worker<$Queue, $R>> st$119241;
        public x10.glb.TaskBag loot$119242;
        public long victim$119203;
        
        public $Closure$55(final x10.rtt.Type $Queue, final x10.rtt.Type $R, final x10.lang.PlaceLocalHandle<x10.glb.Worker<$Queue, $R>> st$119241, final x10.glb.TaskBag loot$119242, final long victim$119203, __0$1x10$glb$Worker$1x10$glb$Context$$Closure$55$$Queue$3x10$glb$Context$$Closure$55$$R$2$2 $dummy) {
            x10.glb.Context.$Closure$55.$initParams(this, $Queue, $R);
             {
                ((x10.glb.Context.$Closure$55<$Queue, $R>)this).st$119241 = ((x10.lang.PlaceLocalHandle)(st$119241));
                ((x10.glb.Context.$Closure$55<$Queue, $R>)this).loot$119242 = ((x10.glb.TaskBag)(loot$119242));
                ((x10.glb.Context.$Closure$55<$Queue, $R>)this).victim$119203 = victim$119203;
            }
        }
        
    }
    
    @x10.runtime.impl.java.X10Generated
    final public static class $Closure$56<$Queue, $R> extends x10.core.Ref implements x10.core.fun.VoidFun_0_0, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<$Closure$56> $RTT = 
            x10.rtt.StaticVoidFunType.<$Closure$56> make($Closure$56.class,
                                                         2,
                                                         new x10.rtt.Type[] {
                                                             x10.core.fun.VoidFun_0_0.$RTT
                                                         });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { if (i == 0) return $Queue; if (i == 1) return $R; return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static <$Queue, $R> x10.serialization.X10JavaSerializable $_deserialize_body(x10.glb.Context.$Closure$56<$Queue, $R> $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            $_obj.$Queue = (x10.rtt.Type) $deserializer.readObject();
            $_obj.$R = (x10.rtt.Type) $deserializer.readObject();
            $_obj.loot$119242 = $deserializer.readObject();
            $_obj.st$119241 = $deserializer.readObject();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.glb.Context.$Closure$56 $_obj = new x10.glb.Context.$Closure$56((java.lang.System[]) null, (x10.rtt.Type) null, (x10.rtt.Type) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            $serializer.write(this.$Queue);
            $serializer.write(this.$R);
            $serializer.write(this.loot$119242);
            $serializer.write(this.st$119241);
            
        }
        
        // constructor just for allocation
        public $Closure$56(final java.lang.System[] $dummy, final x10.rtt.Type $Queue, final x10.rtt.Type $R) {
            x10.glb.Context.$Closure$56.$initParams(this, $Queue, $R);
            
        }
        
        private x10.rtt.Type $Queue;
        private x10.rtt.Type $R;
        
        // initializer of type parameters
        public static void $initParams(final $Closure$56 $this, final x10.rtt.Type $Queue, final x10.rtt.Type $R) {
            $this.$Queue = $Queue;
            $this.$R = $R;
            
        }
        // synthetic type for parameter mangling
        public static final class __0$1x10$glb$Worker$1x10$glb$Context$$Closure$56$$Queue$3x10$glb$Context$$Closure$56$$R$2$2 {}
        
    
        
        public void $apply() {
            
            //#line 171 ... "x10/glb/Worker.x10"
            final x10.glb.Worker t$119228 = ((x10.lang.PlaceLocalHandle<x10.glb.Worker<$Queue, $R>>)this.st$119241).$apply$G();
            
            //#line 171 ... "x10/glb/Worker.x10"
            ((x10.glb.Worker<$Queue, $R>)t$119228).deal__0$1x10$glb$Worker$1x10$glb$Worker$$Queue$3x10$glb$Worker$$R$2$2(((x10.lang.PlaceLocalHandle)(this.st$119241)), ((x10.glb.TaskBag)(this.loot$119242)), (long)(-1L));
            
            //#line 171 ... "x10/glb/Worker.x10"
            final x10.glb.Worker t$119229 = ((x10.lang.PlaceLocalHandle<x10.glb.Worker<$Queue, $R>>)this.st$119241).$apply$G();
            
            //#line 171 ... "x10/glb/Worker.x10"
            ((x10.glb.Worker<$Queue, $R>)t$119229).waiting = false;
        }
        
        public x10.lang.PlaceLocalHandle<x10.glb.Worker<$Queue, $R>> st$119241;
        public x10.glb.TaskBag loot$119242;
        
        public $Closure$56(final x10.rtt.Type $Queue, final x10.rtt.Type $R, final x10.lang.PlaceLocalHandle<x10.glb.Worker<$Queue, $R>> st$119241, final x10.glb.TaskBag loot$119242, __0$1x10$glb$Worker$1x10$glb$Context$$Closure$56$$Queue$3x10$glb$Context$$Closure$56$$R$2$2 $dummy) {
            x10.glb.Context.$Closure$56.$initParams(this, $Queue, $R);
             {
                ((x10.glb.Context.$Closure$56<$Queue, $R>)this).st$119241 = ((x10.lang.PlaceLocalHandle)(st$119241));
                ((x10.glb.Context.$Closure$56<$Queue, $R>)this).loot$119242 = ((x10.glb.TaskBag)(loot$119242));
            }
        }
        
    }
    
    @x10.runtime.impl.java.X10Generated
    final public static class $Closure$57<$Queue, $R> extends x10.core.Ref implements x10.core.fun.VoidFun_0_0, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<$Closure$57> $RTT = 
            x10.rtt.StaticVoidFunType.<$Closure$57> make($Closure$57.class,
                                                         2,
                                                         new x10.rtt.Type[] {
                                                             x10.core.fun.VoidFun_0_0.$RTT
                                                         });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { if (i == 0) return $Queue; if (i == 1) return $R; return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static <$Queue, $R> x10.serialization.X10JavaSerializable $_deserialize_body(x10.glb.Context.$Closure$57<$Queue, $R> $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            $_obj.$Queue = (x10.rtt.Type) $deserializer.readObject();
            $_obj.$R = (x10.rtt.Type) $deserializer.readObject();
            $_obj.loot$119242 = $deserializer.readObject();
            $_obj.st$119241 = $deserializer.readObject();
            $_obj.victim$119203 = $deserializer.readLong();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.glb.Context.$Closure$57 $_obj = new x10.glb.Context.$Closure$57((java.lang.System[]) null, (x10.rtt.Type) null, (x10.rtt.Type) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            $serializer.write(this.$Queue);
            $serializer.write(this.$R);
            $serializer.write(this.loot$119242);
            $serializer.write(this.st$119241);
            $serializer.write(this.victim$119203);
            
        }
        
        // constructor just for allocation
        public $Closure$57(final java.lang.System[] $dummy, final x10.rtt.Type $Queue, final x10.rtt.Type $R) {
            x10.glb.Context.$Closure$57.$initParams(this, $Queue, $R);
            
        }
        
        private x10.rtt.Type $Queue;
        private x10.rtt.Type $R;
        
        // initializer of type parameters
        public static void $initParams(final $Closure$57 $this, final x10.rtt.Type $Queue, final x10.rtt.Type $R) {
            $this.$Queue = $Queue;
            $this.$R = $R;
            
        }
        // synthetic type for parameter mangling
        public static final class __0$1x10$glb$Worker$1x10$glb$Context$$Closure$57$$Queue$3x10$glb$Context$$Closure$57$$R$2$2 {}
        
    
        
        public void $apply() {
            
            //#line 176 ... "x10/glb/Worker.x10"
            try {{
                
                //#line 176 ... "x10/glb/Worker.x10"
                final x10.glb.Worker t$119240 = ((x10.lang.PlaceLocalHandle<x10.glb.Worker<$Queue, $R>>)this.st$119241).$apply$G();
                
                //#line 176 ... "x10/glb/Worker.x10"
                ((x10.glb.Worker<$Queue, $R>)t$119240).deal__0$1x10$glb$Worker$1x10$glb$Worker$$Queue$3x10$glb$Worker$$R$2$2(((x10.lang.PlaceLocalHandle)(this.st$119241)), ((x10.glb.TaskBag)(this.loot$119242)), (long)(this.victim$119203));
            }}catch (java.lang.Error __lowerer__var__0__) {
                
                //#line 176 ... "x10/glb/Worker.x10"
                throw __lowerer__var__0__;
            }catch (java.lang.Throwable __lowerer__var__1__) {
                
                //#line 176 ... "x10/glb/Worker.x10"
                throw x10.rtt.Types.EXCEPTION.isInstance(__lowerer__var__1__) ? (java.lang.RuntimeException)(__lowerer__var__1__) : new x10.lang.WrappedThrowable(__lowerer__var__1__);
            }
        }
        
        public x10.lang.PlaceLocalHandle<x10.glb.Worker<$Queue, $R>> st$119241;
        public x10.glb.TaskBag loot$119242;
        public long victim$119203;
        
        public $Closure$57(final x10.rtt.Type $Queue, final x10.rtt.Type $R, final x10.lang.PlaceLocalHandle<x10.glb.Worker<$Queue, $R>> st$119241, final x10.glb.TaskBag loot$119242, final long victim$119203, __0$1x10$glb$Worker$1x10$glb$Context$$Closure$57$$Queue$3x10$glb$Context$$Closure$57$$R$2$2 $dummy) {
            x10.glb.Context.$Closure$57.$initParams(this, $Queue, $R);
             {
                ((x10.glb.Context.$Closure$57<$Queue, $R>)this).st$119241 = ((x10.lang.PlaceLocalHandle)(st$119241));
                ((x10.glb.Context.$Closure$57<$Queue, $R>)this).loot$119242 = ((x10.glb.TaskBag)(loot$119242));
                ((x10.glb.Context.$Closure$57<$Queue, $R>)this).victim$119203 = victim$119203;
            }
        }
        
    }
    
    @x10.runtime.impl.java.X10Generated
    final public static class $Closure$58<$Queue, $R> extends x10.core.Ref implements x10.core.fun.VoidFun_0_0, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<$Closure$58> $RTT = 
            x10.rtt.StaticVoidFunType.<$Closure$58> make($Closure$58.class,
                                                         2,
                                                         new x10.rtt.Type[] {
                                                             x10.core.fun.VoidFun_0_0.$RTT
                                                         });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { if (i == 0) return $Queue; if (i == 1) return $R; return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static <$Queue, $R> x10.serialization.X10JavaSerializable $_deserialize_body(x10.glb.Context.$Closure$58<$Queue, $R> $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            $_obj.$Queue = (x10.rtt.Type) $deserializer.readObject();
            $_obj.$R = (x10.rtt.Type) $deserializer.readObject();
            $_obj.st$119131 = $deserializer.readObject();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.glb.Context.$Closure$58 $_obj = new x10.glb.Context.$Closure$58((java.lang.System[]) null, (x10.rtt.Type) null, (x10.rtt.Type) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            $serializer.write(this.$Queue);
            $serializer.write(this.$R);
            $serializer.write(this.st$119131);
            
        }
        
        // constructor just for allocation
        public $Closure$58(final java.lang.System[] $dummy, final x10.rtt.Type $Queue, final x10.rtt.Type $R) {
            x10.glb.Context.$Closure$58.$initParams(this, $Queue, $R);
            
        }
        
        private x10.rtt.Type $Queue;
        private x10.rtt.Type $R;
        
        // initializer of type parameters
        public static void $initParams(final $Closure$58 $this, final x10.rtt.Type $Queue, final x10.rtt.Type $R) {
            $this.$Queue = $Queue;
            $this.$R = $R;
            
        }
        // synthetic type for parameter mangling
        public static final class __0$1x10$glb$Worker$1x10$glb$Context$$Closure$58$$Queue$3x10$glb$Context$$Closure$58$$R$2$2 {}
        
    
        
        public void $apply() {
            
            //#line 202 .. "x10/glb/Worker.x10"
            final x10.glb.Worker t$119260 = ((x10.lang.PlaceLocalHandle<x10.glb.Worker<$Queue, $R>>)this.st$119131).$apply$G();
            
            //#line 202 .. "x10/glb/Worker.x10"
            ((x10.glb.Worker<$Queue, $R>)t$119260).waiting = false;
        }
        
        public x10.lang.PlaceLocalHandle<x10.glb.Worker<$Queue, $R>> st$119131;
        
        public $Closure$58(final x10.rtt.Type $Queue, final x10.rtt.Type $R, final x10.lang.PlaceLocalHandle<x10.glb.Worker<$Queue, $R>> st$119131, __0$1x10$glb$Worker$1x10$glb$Context$$Closure$58$$Queue$3x10$glb$Context$$Closure$58$$R$2$2 $dummy) {
            x10.glb.Context.$Closure$58.$initParams(this, $Queue, $R);
             {
                ((x10.glb.Context.$Closure$58<$Queue, $R>)this).st$119131 = ((x10.lang.PlaceLocalHandle)(st$119131));
            }
        }
        
    }
    
    @x10.runtime.impl.java.X10Generated
    final public static class $Closure$59<$Queue, $R> extends x10.core.Ref implements x10.core.fun.VoidFun_0_0, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<$Closure$59> $RTT = 
            x10.rtt.StaticVoidFunType.<$Closure$59> make($Closure$59.class,
                                                         2,
                                                         new x10.rtt.Type[] {
                                                             x10.core.fun.VoidFun_0_0.$RTT
                                                         });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { if (i == 0) return $Queue; if (i == 1) return $R; return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static <$Queue, $R> x10.serialization.X10JavaSerializable $_deserialize_body(x10.glb.Context.$Closure$59<$Queue, $R> $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            $_obj.$Queue = (x10.rtt.Type) $deserializer.readObject();
            $_obj.$R = (x10.rtt.Type) $deserializer.readObject();
            $_obj.st$119131 = $deserializer.readObject();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.glb.Context.$Closure$59 $_obj = new x10.glb.Context.$Closure$59((java.lang.System[]) null, (x10.rtt.Type) null, (x10.rtt.Type) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            $serializer.write(this.$Queue);
            $serializer.write(this.$R);
            $serializer.write(this.st$119131);
            
        }
        
        // constructor just for allocation
        public $Closure$59(final java.lang.System[] $dummy, final x10.rtt.Type $Queue, final x10.rtt.Type $R) {
            x10.glb.Context.$Closure$59.$initParams(this, $Queue, $R);
            
        }
        
        private x10.rtt.Type $Queue;
        private x10.rtt.Type $R;
        
        // initializer of type parameters
        public static void $initParams(final $Closure$59 $this, final x10.rtt.Type $Queue, final x10.rtt.Type $R) {
            $this.$Queue = $Queue;
            $this.$R = $R;
            
        }
        // synthetic type for parameter mangling
        public static final class __0$1x10$glb$Worker$1x10$glb$Context$$Closure$59$$Queue$3x10$glb$Context$$Closure$59$$R$2$2 {}
        
    
        
        public void $apply() {
            
            //#line 204 .. "x10/glb/Worker.x10"
            final x10.glb.Worker t$119262 = ((x10.lang.PlaceLocalHandle<x10.glb.Worker<$Queue, $R>>)this.st$119131).$apply$G();
            
            //#line 204 .. "x10/glb/Worker.x10"
            ((x10.glb.Worker<$Queue, $R>)t$119262).waiting = false;
        }
        
        public x10.lang.PlaceLocalHandle<x10.glb.Worker<$Queue, $R>> st$119131;
        
        public $Closure$59(final x10.rtt.Type $Queue, final x10.rtt.Type $R, final x10.lang.PlaceLocalHandle<x10.glb.Worker<$Queue, $R>> st$119131, __0$1x10$glb$Worker$1x10$glb$Context$$Closure$59$$Queue$3x10$glb$Context$$Closure$59$$R$2$2 $dummy) {
            x10.glb.Context.$Closure$59.$initParams(this, $Queue, $R);
             {
                ((x10.glb.Context.$Closure$59<$Queue, $R>)this).st$119131 = ((x10.lang.PlaceLocalHandle)(st$119131));
            }
        }
        
    }
    
    @x10.runtime.impl.java.X10Generated
    final public static class $Closure$60<$Queue, $R> extends x10.core.Ref implements x10.core.fun.VoidFun_0_1, x10.serialization.X10JavaSerializable
    {
        public static final x10.rtt.RuntimeType<$Closure$60> $RTT = 
            x10.rtt.StaticVoidFunType.<$Closure$60> make($Closure$60.class,
                                                         2,
                                                         new x10.rtt.Type[] {
                                                             x10.rtt.ParameterizedType.make(x10.core.fun.VoidFun_0_1.$RTT, x10.rtt.ParameterizedType.make(x10.lang.PlaceLocalHandle.$RTT, x10.rtt.ParameterizedType.make(x10.glb.Worker.$RTT, x10.rtt.UnresolvedType.PARAM(0), x10.rtt.UnresolvedType.PARAM(1))))
                                                         });
        
        public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
        
        public x10.rtt.Type<?> $getParam(int i) { if (i == 0) return $Queue; if (i == 1) return $R; return null; }
        
        private Object writeReplace() throws java.io.ObjectStreamException {
            return new x10.serialization.SerializationProxy(this);
        }
        
        public static <$Queue, $R> x10.serialization.X10JavaSerializable $_deserialize_body(x10.glb.Context.$Closure$60<$Queue, $R> $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            $_obj.$Queue = (x10.rtt.Type) $deserializer.readObject();
            $_obj.$R = (x10.rtt.Type) $deserializer.readObject();
            $_obj.this$119082 = $deserializer.readObject();
            return $_obj;
        }
        
        public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
            x10.glb.Context.$Closure$60 $_obj = new x10.glb.Context.$Closure$60((java.lang.System[]) null, (x10.rtt.Type) null, (x10.rtt.Type) null);
            $deserializer.record_reference($_obj);
            return $_deserialize_body($_obj, $deserializer);
        }
        
        public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
            $serializer.write(this.$Queue);
            $serializer.write(this.$R);
            $serializer.write(this.this$119082);
            
        }
        
        // constructor just for allocation
        public $Closure$60(final java.lang.System[] $dummy, final x10.rtt.Type $Queue, final x10.rtt.Type $R) {
            x10.glb.Context.$Closure$60.$initParams(this, $Queue, $R);
            
        }
        
        // dispatcher for method abstract public (Z1)=>void.operator()(a1:Z1):void
        public java.lang.Object $apply(final java.lang.Object a1, final x10.rtt.Type t1) {
            $apply__0$1x10$glb$Worker$1x10$glb$Context$$Closure$60$$Queue$3x10$glb$Context$$Closure$60$$R$2$2((x10.lang.PlaceLocalHandle)a1); return null;
            
        }
        
        // dispatcher for method abstract public (Z1)=>void.operator()(a1:Z1):void
        public void $apply$V(final java.lang.Object a1, final x10.rtt.Type t1) {
            $apply__0$1x10$glb$Worker$1x10$glb$Context$$Closure$60$$Queue$3x10$glb$Context$$Closure$60$$R$2$2((x10.lang.PlaceLocalHandle)a1);
            
        }
        
        private x10.rtt.Type $Queue;
        private x10.rtt.Type $R;
        
        // initializer of type parameters
        public static void $initParams(final $Closure$60 $this, final x10.rtt.Type $Queue, final x10.rtt.Type $R) {
            $this.$Queue = $Queue;
            $this.$R = $R;
            
        }
        // synthetic type for parameter mangling
        public static final class __0$1x10$glb$Context$$Closure$60$$Queue$3x10$glb$Context$$Closure$60$$R$2 {}
        
    
        
        public void $apply__0$1x10$glb$Worker$1x10$glb$Context$$Closure$60$$Queue$3x10$glb$Context$$Closure$60$$R$2$2(final x10.lang.PlaceLocalHandle st$119081) {
            
            //#line 452 . "x10/glb/Worker.x10"
            x10.xrx.Runtime.probe();
            
            //#line 452 . "x10/glb/Worker.x10"
            final x10.lang.PlaceLocalHandle st$119084 = ((x10.lang.PlaceLocalHandle)(st$119081));
            
            //#line 186 .. "x10/glb/Worker.x10"
            x10.glb.TaskBag loot$119263 =  null;
            
            //#line 187 .. "x10/glb/Worker.x10"
            while (true) {
                
                //#line 187 .. "x10/glb/Worker.x10"
                final x10.glb.FixedSizeStack this$119264 = ((x10.glb.FixedSizeStack)(((x10.glb.Worker<$Queue, $R>)this.this$119082).thieves));
                
                //#line 55 ... "x10/glb/FixedSizeStack.x10"
                final long t$119265 = ((x10.glb.FixedSizeStack<x10.core.Long>)this$119264).size;
                
                //#line 187 .. "x10/glb/Worker.x10"
                boolean t$119266 = ((t$119265) > (((long)(0L))));
                
                //#line 187 .. "x10/glb/Worker.x10"
                if (!(t$119266)) {
                    
                    //#line 187 .. "x10/glb/Worker.x10"
                    final x10.glb.FixedSizeStack this$119267 = ((x10.glb.FixedSizeStack)(((x10.glb.Worker<$Queue, $R>)this.this$119082).lifelineThieves));
                    
                    //#line 55 ... "x10/glb/FixedSizeStack.x10"
                    final long t$119268 = ((x10.glb.FixedSizeStack<x10.core.Long>)this$119267).size;
                    
                    //#line 187 .. "x10/glb/Worker.x10"
                    t$119266 = ((t$119268) > (((long)(0L))));
                }
                
                //#line 187 .. "x10/glb/Worker.x10"
                boolean t$119269 = t$119266;
                
                //#line 187 .. "x10/glb/Worker.x10"
                if (t$119266) {
                    
                    //#line 187 .. "x10/glb/Worker.x10"
                    final $Queue t$119270 = (($Queue)(((x10.glb.Worker<$Queue, $R>)this.this$119082).queue));
                    
                    //#line 187 .. "x10/glb/Worker.x10"
                    final x10.glb.TaskBag t$119271 = ((x10.glb.TaskQueue<$Queue, $R>)x10.rtt.Types.conversion(x10.rtt.ParameterizedType.make(x10.glb.TaskQueue.$RTT, $Queue, $R),t$119270)).split();
                    
                    //#line 187 .. "x10/glb/Worker.x10"
                    final x10.glb.TaskBag t$119272 = loot$119263 = ((x10.glb.TaskBag)(t$119271));
                    
                    //#line 187 .. "x10/glb/Worker.x10"
                    t$119269 = ((t$119272) != (null));
                }
                
                //#line 187 .. "x10/glb/Worker.x10"
                if (!(t$119269)) {
                    
                    //#line 187 .. "x10/glb/Worker.x10"
                    break;
                }
                
                //#line 188 .. "x10/glb/Worker.x10"
                final x10.lang.PlaceLocalHandle st$119241 = ((x10.lang.PlaceLocalHandle)(st$119084));
                
                //#line 188 .. "x10/glb/Worker.x10"
                final x10.glb.TaskBag loot$119242 = ((x10.glb.TaskBag)(loot$119263));
                
                //#line 162 ... "x10/glb/Worker.x10"
                final long victim$119203 = ((long)x10.x10rt.X10RT.hereId());
                
                //#line 163 ... "x10/glb/Worker.x10"
                final x10.glb.Logger obj$119204 = ((x10.glb.Logger)(((x10.glb.Worker<$Queue, $R>)this.this$119082).logger));
                
                //#line 163 ... "x10/glb/Worker.x10"
                final long t$119205 = obj$119204.nodesGiven;
                
                //#line 163 ... "x10/glb/Worker.x10"
                final long t$119206 = loot$119263.size$O();
                
                //#line 163 ... "x10/glb/Worker.x10"
                final long t$119207 = ((t$119205) + (((long)(t$119206))));
                
                //#line 163 ... "x10/glb/Worker.x10"
                obj$119204.nodesGiven = t$119207;
                
                //#line 164 ... "x10/glb/Worker.x10"
                final x10.glb.FixedSizeStack this$119208 = ((x10.glb.FixedSizeStack)(((x10.glb.Worker<$Queue, $R>)this.this$119082).thieves));
                
                //#line 55 .... "x10/glb/FixedSizeStack.x10"
                final long t$119209 = ((x10.glb.FixedSizeStack<x10.core.Long>)this$119208).size;
                
                //#line 164 ... "x10/glb/Worker.x10"
                final boolean t$119210 = ((t$119209) > (((long)(0L))));
                
                //#line 164 ... "x10/glb/Worker.x10"
                if (t$119210) {
                    
                    //#line 165 ... "x10/glb/Worker.x10"
                    final x10.glb.FixedSizeStack this$119211 = ((x10.glb.FixedSizeStack)(((x10.glb.Worker<$Queue, $R>)this.this$119082).thieves));
                    
                    //#line 44 .... "x10/glb/FixedSizeStack.x10"
                    final x10.core.Rail t$119212 = ((x10.core.Rail)(((x10.glb.FixedSizeStack<x10.core.Long>)this$119211).data));
                    
                    //#line 44 .... "x10/glb/FixedSizeStack.x10"
                    final long t$119213 = ((x10.glb.FixedSizeStack<x10.core.Long>)this$119211).size;
                    
                    //#line 44 .... "x10/glb/FixedSizeStack.x10"
                    final long t$119214 = ((t$119213) - (((long)(1L))));
                    
                    //#line 44 .... "x10/glb/FixedSizeStack.x10"
                    final long t$119215 = ((x10.glb.FixedSizeStack<x10.core.Long>)this$119211).size = t$119214;
                    
                    //#line 165 ... "x10/glb/Worker.x10"
                    final long thief$119216 = ((long[])t$119212.value)[(int)t$119215];
                    
                    //#line 166 ... "x10/glb/Worker.x10"
                    final boolean t$119217 = ((thief$119216) >= (((long)(0L))));
                    
                    //#line 166 ... "x10/glb/Worker.x10"
                    if (t$119217) {
                        
                        //#line 167 ... "x10/glb/Worker.x10"
                        final x10.glb.Logger obj$119218 = ((x10.glb.Logger)(((x10.glb.Worker<$Queue, $R>)this.this$119082).logger));
                        
                        //#line 167 ... "x10/glb/Worker.x10"
                        final long t$119219 = obj$119218.lifelineStealsSuffered;
                        
                        //#line 167 ... "x10/glb/Worker.x10"
                        final long t$119220 = ((t$119219) + (((long)(1L))));
                        
                        //#line 167 ... "x10/glb/Worker.x10"
                        obj$119218.lifelineStealsSuffered = t$119220;
                        
                        //#line 168 ... "x10/glb/Worker.x10"
                        final x10.lang.Place alloc$119221 = ((x10.lang.Place)(new x10.lang.Place((java.lang.System[]) null)));
                        
                        //#line 168 ... "x10/glb/Worker.x10"
                        alloc$119221.x10$lang$Place$$init$S(((long)(thief$119216)));
                        
                        //#line 168 ... "x10/glb/Worker.x10"
                        x10.xrx.Runtime.runUncountedAsync(((x10.lang.Place)(alloc$119221)), ((x10.core.fun.VoidFun_0_0)(new x10.glb.Context.$Closure$55<$Queue, $R>($Queue, $R, st$119241, loot$119242, victim$119203, (x10.glb.Context.$Closure$55.__0$1x10$glb$Worker$1x10$glb$Context$$Closure$55$$Queue$3x10$glb$Context$$Closure$55$$R$2$2) null))), ((x10.xrx.Runtime.Profile)(null)));
                    } else {
                        
                        //#line 170 ... "x10/glb/Worker.x10"
                        final x10.glb.Logger obj$119224 = ((x10.glb.Logger)(((x10.glb.Worker<$Queue, $R>)this.this$119082).logger));
                        
                        //#line 170 ... "x10/glb/Worker.x10"
                        final long t$119225 = obj$119224.stealsSuffered;
                        
                        //#line 170 ... "x10/glb/Worker.x10"
                        final long t$119226 = ((t$119225) + (((long)(1L))));
                        
                        //#line 170 ... "x10/glb/Worker.x10"
                        obj$119224.stealsSuffered = t$119226;
                        
                        //#line 171 ... "x10/glb/Worker.x10"
                        final x10.lang.Place alloc$119227 = ((x10.lang.Place)(new x10.lang.Place((java.lang.System[]) null)));
                        
                        //#line 171 ... "x10/glb/Worker.x10"
                        final long t$119201 = (-(thief$119216));
                        
                        //#line 171 ... "x10/glb/Worker.x10"
                        final long t$119202 = ((t$119201) - (((long)(1L))));
                        
                        //#line 171 ... "x10/glb/Worker.x10"
                        alloc$119227.x10$lang$Place$$init$S(t$119202);
                        
                        //#line 171 ... "x10/glb/Worker.x10"
                        x10.xrx.Runtime.runUncountedAsync(((x10.lang.Place)(alloc$119227)), ((x10.core.fun.VoidFun_0_0)(new x10.glb.Context.$Closure$56<$Queue, $R>($Queue, $R, st$119241, loot$119242, (x10.glb.Context.$Closure$56.__0$1x10$glb$Worker$1x10$glb$Context$$Closure$56$$Queue$3x10$glb$Context$$Closure$56$$R$2$2) null))), ((x10.xrx.Runtime.Profile)(null)));
                    }
                } else {
                    
                    //#line 174 ... "x10/glb/Worker.x10"
                    final x10.glb.Logger obj$119230 = ((x10.glb.Logger)(((x10.glb.Worker<$Queue, $R>)this.this$119082).logger));
                    
                    //#line 174 ... "x10/glb/Worker.x10"
                    final long t$119231 = obj$119230.lifelineStealsSuffered;
                    
                    //#line 174 ... "x10/glb/Worker.x10"
                    final long t$119232 = ((t$119231) + (((long)(1L))));
                    
                    //#line 174 ... "x10/glb/Worker.x10"
                    obj$119230.lifelineStealsSuffered = t$119232;
                    
                    //#line 175 ... "x10/glb/Worker.x10"
                    final x10.glb.FixedSizeStack this$119233 = ((x10.glb.FixedSizeStack)(((x10.glb.Worker<$Queue, $R>)this.this$119082).lifelineThieves));
                    
                    //#line 44 .... "x10/glb/FixedSizeStack.x10"
                    final x10.core.Rail t$119234 = ((x10.core.Rail)(((x10.glb.FixedSizeStack<x10.core.Long>)this$119233).data));
                    
                    //#line 44 .... "x10/glb/FixedSizeStack.x10"
                    final long t$119235 = ((x10.glb.FixedSizeStack<x10.core.Long>)this$119233).size;
                    
                    //#line 44 .... "x10/glb/FixedSizeStack.x10"
                    final long t$119236 = ((t$119235) - (((long)(1L))));
                    
                    //#line 44 .... "x10/glb/FixedSizeStack.x10"
                    final long t$119237 = ((x10.glb.FixedSizeStack<x10.core.Long>)this$119233).size = t$119236;
                    
                    //#line 175 ... "x10/glb/Worker.x10"
                    final long thief$119238 = ((long[])t$119234.value)[(int)t$119237];
                    
                    //#line 176 ... "x10/glb/Worker.x10"
                    final x10.lang.Place alloc$119239 = ((x10.lang.Place)(new x10.lang.Place((java.lang.System[]) null)));
                    
                    //#line 176 ... "x10/glb/Worker.x10"
                    alloc$119239.x10$lang$Place$$init$S(((long)(thief$119238)));
                    
                    //#line 176 ... "x10/glb/Worker.x10"
                    x10.xrx.Runtime.runAsync(((x10.lang.Place)(alloc$119239)), ((x10.core.fun.VoidFun_0_0)(new x10.glb.Context.$Closure$57<$Queue, $R>($Queue, $R, st$119241, loot$119242, victim$119203, (x10.glb.Context.$Closure$57.__0$1x10$glb$Worker$1x10$glb$Context$$Closure$57$$Queue$3x10$glb$Context$$Closure$57$$R$2$2) null))), ((x10.xrx.Runtime.Profile)(null)));
                }
            }
            
            //#line 452 . "x10/glb/Worker.x10"
            final x10.lang.PlaceLocalHandle st$119131 = ((x10.lang.PlaceLocalHandle)(st$119081));
            
            //#line 198 .. "x10/glb/Worker.x10"
            while (true) {
                
                //#line 198 .. "x10/glb/Worker.x10"
                final x10.glb.FixedSizeStack this$119274 = ((x10.glb.FixedSizeStack)(((x10.glb.Worker<$Queue, $R>)this.this$119082).thieves));
                
                //#line 55 ... "x10/glb/FixedSizeStack.x10"
                final long t$119275 = ((x10.glb.FixedSizeStack<x10.core.Long>)this$119274).size;
                
                //#line 198 .. "x10/glb/Worker.x10"
                final boolean t$119276 = ((t$119275) > (((long)(0L))));
                
                //#line 198 .. "x10/glb/Worker.x10"
                if (!(t$119276)) {
                    
                    //#line 198 .. "x10/glb/Worker.x10"
                    break;
                }
                
                //#line 199 .. "x10/glb/Worker.x10"
                final x10.glb.FixedSizeStack this$119250 = ((x10.glb.FixedSizeStack)(((x10.glb.Worker<$Queue, $R>)this.this$119082).thieves));
                
                //#line 44 ... "x10/glb/FixedSizeStack.x10"
                final x10.core.Rail t$119251 = ((x10.core.Rail)(((x10.glb.FixedSizeStack<x10.core.Long>)this$119250).data));
                
                //#line 44 ... "x10/glb/FixedSizeStack.x10"
                final long t$119252 = ((x10.glb.FixedSizeStack<x10.core.Long>)this$119250).size;
                
                //#line 44 ... "x10/glb/FixedSizeStack.x10"
                final long t$119253 = ((t$119252) - (((long)(1L))));
                
                //#line 44 ... "x10/glb/FixedSizeStack.x10"
                final long t$119254 = ((x10.glb.FixedSizeStack<x10.core.Long>)this$119250).size = t$119253;
                
                //#line 199 .. "x10/glb/Worker.x10"
                final long thief$119255 = ((long[])t$119251.value)[(int)t$119254];
                
                //#line 200 .. "x10/glb/Worker.x10"
                final boolean t$119256 = ((thief$119255) >= (((long)(0L))));
                
                //#line 200 .. "x10/glb/Worker.x10"
                if (t$119256) {
                    
                    //#line 201 .. "x10/glb/Worker.x10"
                    final x10.glb.FixedSizeStack this$119257 = ((x10.glb.FixedSizeStack)(((x10.glb.Worker<$Queue, $R>)this.this$119082).lifelineThieves));
                    
                    //#line 49 ... "x10/glb/FixedSizeStack.x10"
                    final x10.core.Rail t$119243 = ((x10.core.Rail)(((x10.glb.FixedSizeStack<x10.core.Long>)this$119257).data));
                    
                    //#line 49 ... "x10/glb/FixedSizeStack.x10"
                    final long t$119244 = ((x10.glb.FixedSizeStack<x10.core.Long>)this$119257).size;
                    
                    //#line 49 ... "x10/glb/FixedSizeStack.x10"
                    final long t$119245 = ((t$119244) + (((long)(1L))));
                    
                    //#line 49 ... "x10/glb/FixedSizeStack.x10"
                    final long t$119246 = ((x10.glb.FixedSizeStack<x10.core.Long>)this$119257).size = t$119245;
                    
                    //#line 49 ... "x10/glb/FixedSizeStack.x10"
                    final long t$119247 = ((t$119246) - (((long)(1L))));
                    
                    //#line 49 ... "x10/glb/FixedSizeStack.x10"
                    ((long[])t$119243.value)[(int)t$119247] = thief$119255;
                    
                    //#line 202 .. "x10/glb/Worker.x10"
                    final x10.lang.Place alloc$119259 = ((x10.lang.Place)(new x10.lang.Place((java.lang.System[]) null)));
                    
                    //#line 202 .. "x10/glb/Worker.x10"
                    alloc$119259.x10$lang$Place$$init$S(((long)(thief$119255)));
                    
                    //#line 202 .. "x10/glb/Worker.x10"
                    x10.xrx.Runtime.runUncountedAsync(((x10.lang.Place)(alloc$119259)), ((x10.core.fun.VoidFun_0_0)(new x10.glb.Context.$Closure$58<$Queue, $R>($Queue, $R, st$119131, (x10.glb.Context.$Closure$58.__0$1x10$glb$Worker$1x10$glb$Context$$Closure$58$$Queue$3x10$glb$Context$$Closure$58$$R$2$2) null))), ((x10.xrx.Runtime.Profile)(null)));
                } else {
                    
                    //#line 204 .. "x10/glb/Worker.x10"
                    final x10.lang.Place alloc$119261 = ((x10.lang.Place)(new x10.lang.Place((java.lang.System[]) null)));
                    
                    //#line 204 .. "x10/glb/Worker.x10"
                    final long t$119248 = (-(thief$119255));
                    
                    //#line 204 .. "x10/glb/Worker.x10"
                    final long t$119249 = ((t$119248) - (((long)(1L))));
                    
                    //#line 204 .. "x10/glb/Worker.x10"
                    alloc$119261.x10$lang$Place$$init$S(t$119249);
                    
                    //#line 204 .. "x10/glb/Worker.x10"
                    x10.xrx.Runtime.runUncountedAsync(((x10.lang.Place)(alloc$119261)), ((x10.core.fun.VoidFun_0_0)(new x10.glb.Context.$Closure$59<$Queue, $R>($Queue, $R, st$119131, (x10.glb.Context.$Closure$59.__0$1x10$glb$Worker$1x10$glb$Context$$Closure$59$$Queue$3x10$glb$Context$$Closure$59$$R$2$2) null))), ((x10.xrx.Runtime.Profile)(null)));
                }
            }
        }
        
        public x10.glb.Worker<$Queue, $R> this$119082;
        
        public $Closure$60(final x10.rtt.Type $Queue, final x10.rtt.Type $R, final x10.glb.Worker<$Queue, $R> this$119082, __0$1x10$glb$Context$$Closure$60$$Queue$3x10$glb$Context$$Closure$60$$R$2 $dummy) {
            x10.glb.Context.$Closure$60.$initParams(this, $Queue, $R);
             {
                ((x10.glb.Context.$Closure$60<$Queue, $R>)this).this$119082 = this$119082;
            }
        }
        
    }
    
}

