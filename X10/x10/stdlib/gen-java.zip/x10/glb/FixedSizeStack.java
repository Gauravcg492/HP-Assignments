package x10.glb;


/**
 * <p> Stack implementation via an backing Rail.
 * </p>
 */
@x10.runtime.impl.java.X10Generated
final public class FixedSizeStack<$T> extends x10.core.Ref implements x10.serialization.X10JavaSerializable
{
    public static final x10.rtt.RuntimeType<FixedSizeStack> $RTT = 
        x10.rtt.NamedType.<FixedSizeStack> make("x10.glb.FixedSizeStack",
                                                FixedSizeStack.class,
                                                1);
    
    public x10.rtt.RuntimeType<?> $getRTT() { return $RTT; }
    
    public x10.rtt.Type<?> $getParam(int i) { if (i == 0) return $T; return null; }
    
    private Object writeReplace() throws java.io.ObjectStreamException {
        return new x10.serialization.SerializationProxy(this);
    }
    
    public static <$T> x10.serialization.X10JavaSerializable $_deserialize_body(x10.glb.FixedSizeStack<$T> $_obj, x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
        $_obj.$T = (x10.rtt.Type) $deserializer.readObject();
        $_obj.data = $deserializer.readObject();
        $_obj.size = $deserializer.readLong();
        return $_obj;
    }
    
    public static x10.serialization.X10JavaSerializable $_deserializer(x10.serialization.X10JavaDeserializer $deserializer) throws java.io.IOException {
        x10.glb.FixedSizeStack $_obj = new x10.glb.FixedSizeStack((java.lang.System[]) null, (x10.rtt.Type) null);
        $deserializer.record_reference($_obj);
        return $_deserialize_body($_obj, $deserializer);
    }
    
    public void $_serialize(x10.serialization.X10JavaSerializer $serializer) throws java.io.IOException {
        $serializer.write(this.$T);
        $serializer.write(this.data);
        $serializer.write(this.size);
        
    }
    
    // constructor just for allocation
    public FixedSizeStack(final java.lang.System[] $dummy, final x10.rtt.Type $T) {
        x10.glb.FixedSizeStack.$initParams(this, $T);
        
    }
    
    private x10.rtt.Type $T;
    
    // initializer of type parameters
    public static void $initParams(final FixedSizeStack $this, final x10.rtt.Type $T) {
        $this.$T = $T;
        
    }
    

    
    //#line 25 "x10/glb/FixedSizeStack.x10"
    /**
     * Backing Rail.
     */
    public x10.core.Rail<$T> data;
    
    //#line 29 "x10/glb/FixedSizeStack.x10"
    /**
     * Number of elements in the stack.
     */
    public long size;
    
    
    //#line 35 "x10/glb/FixedSizeStack.x10"
    /**
     * Constructor
     * @param n size of the backing Rail.
     */
    // creation method for java code (1-phase java constructor)
    public FixedSizeStack(final x10.rtt.Type $T, final long n) {
        this((java.lang.System[]) null, $T);
        x10$glb$FixedSizeStack$$init$S(n);
    }
    
    // constructor for non-virtual call
    final public x10.glb.FixedSizeStack<$T> x10$glb$FixedSizeStack$$init$S(final long n) {
         {
            
            //#line 35 "x10/glb/FixedSizeStack.x10"
            
            
            //#line 20 "x10/glb/FixedSizeStack.x10"
            final x10.glb.FixedSizeStack this$119307 = this;
            
            //#line 20 "x10/glb/FixedSizeStack.x10"
            ((x10.glb.FixedSizeStack<$T>)this$119307).size = 0L;
            
            //#line 36 "x10/glb/FixedSizeStack.x10"
            final x10.core.Rail t$119295 = ((x10.core.Rail)(new x10.core.Rail<$T>($T, ((long)(n)))));
            
            //#line 36 "x10/glb/FixedSizeStack.x10"
            ((x10.glb.FixedSizeStack<$T>)this).data = ((x10.core.Rail)(t$119295));
            
            //#line 37 "x10/glb/FixedSizeStack.x10"
            ((x10.glb.FixedSizeStack<$T>)this).size = 0L;
        }
        return this;
    }
    
    
    
    //#line 44 "x10/glb/FixedSizeStack.x10"
    /**
     * Pop method, returns the top of the stack
     * @return top of the stack
     */
    public $T pop$G() {
        
        //#line 44 "x10/glb/FixedSizeStack.x10"
        final x10.core.Rail t$119298 = ((x10.core.Rail)(this.data));
        
        //#line 44 "x10/glb/FixedSizeStack.x10"
        final long t$119296 = this.size;
        
        //#line 44 "x10/glb/FixedSizeStack.x10"
        final long t$119297 = ((t$119296) - (((long)(1L))));
        
        //#line 44 "x10/glb/FixedSizeStack.x10"
        final long t$119299 = ((x10.glb.FixedSizeStack<$T>)this).size = t$119297;
        
        //#line 44 "x10/glb/FixedSizeStack.x10"
        final $T t$119300 = (($T)(((x10.core.Rail<$T>)t$119298).$apply$G((long)(t$119299))));
        
        //#line 44 "x10/glb/FixedSizeStack.x10"
        return t$119300;
    }
    
    
    //#line 49 "x10/glb/FixedSizeStack.x10"
    /**
     * Push method, pushes the element on top of the stack
     */
    public void push__0x10$glb$FixedSizeStack$$T(final $T t) {
        
        //#line 49 "x10/glb/FixedSizeStack.x10"
        final x10.core.Rail t$119304 = ((x10.core.Rail)(this.data));
        
        //#line 49 "x10/glb/FixedSizeStack.x10"
        final long t$119301 = this.size;
        
        //#line 49 "x10/glb/FixedSizeStack.x10"
        final long t$119302 = ((t$119301) + (((long)(1L))));
        
        //#line 49 "x10/glb/FixedSizeStack.x10"
        final long t$119303 = ((x10.glb.FixedSizeStack<$T>)this).size = t$119302;
        
        //#line 49 "x10/glb/FixedSizeStack.x10"
        final long t$119305 = ((t$119303) - (((long)(1L))));
        
        //#line 49 "x10/glb/FixedSizeStack.x10"
        ((x10.core.Rail<$T>)t$119304).$set__1x10$lang$Rail$$T$G((long)(t$119305), (($T)(t)));
    }
    
    
    //#line 55 "x10/glb/FixedSizeStack.x10"
    /**
     * Returns the number of elements in the stack
     * @return number of elements in the stack
     */
    public long size$O() {
        
        //#line 55 "x10/glb/FixedSizeStack.x10"
        final long t$119306 = this.size;
        
        //#line 55 "x10/glb/FixedSizeStack.x10"
        return t$119306;
    }
    
    
    //#line 20 "x10/glb/FixedSizeStack.x10"
    final public x10.glb.FixedSizeStack x10$glb$FixedSizeStack$$this$x10$glb$FixedSizeStack() {
        
        //#line 20 "x10/glb/FixedSizeStack.x10"
        return x10.glb.FixedSizeStack.this;
    }
    
    
    //#line 20 "x10/glb/FixedSizeStack.x10"
    final public void __fieldInitializers_x10_glb_FixedSizeStack() {
        
        //#line 20 "x10/glb/FixedSizeStack.x10"
        ((x10.glb.FixedSizeStack<$T>)this).size = 0L;
    }
}

