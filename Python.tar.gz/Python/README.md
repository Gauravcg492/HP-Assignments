# HP OpenMP Exercises
## A Total of 3 exercises are present
### To run the exercises
Please type the below command
`$ python3 exercise(exercise_num)`