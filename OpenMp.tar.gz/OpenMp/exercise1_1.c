/*
Write a simple program that prints hello world in C
*/

#include<stdio.h>

int main(){
    int id = 0;
    printf("Hello World\nID: %d\n",id);
    return 0;
}