# HP OpenMP Exercises
## A Total of 9 exercises are present
### To run the exercises
`$ make`

The make file will generate the executables of all the exercises.

Run `$ ./ex(exercise_num)` to run the individual exercises.

### Exceptions
`./ex1_1`

`./ex1_2`