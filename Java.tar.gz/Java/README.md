# HP Java Exercises
## A Total of 9 exercises are present
### To run the exercises
`$ make`

The make file will generate the class of all the exercises.

Run `$ java Exercise(exercise_num)` to run the individual exercises.